/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ public class MySQLTransientConnectionException extends MySQLTransientException
/*    */ {
/*    */   public MySQLTransientConnectionException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 30 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLTransientConnectionException(String reason, String SQLState) {
/* 34 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLTransientConnectionException(String reason) {
/* 38 */     super(reason);
/*    */   }
/*    */ 
/*    */   public MySQLTransientConnectionException()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLTransientConnectionException
 * JD-Core Version:    0.6.0
 */