/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ public class MySQLDataException extends MySQLNonTransientException
/*    */ {
/*    */   public MySQLDataException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MySQLDataException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 33 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLDataException(String reason, String SQLState) {
/* 37 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLDataException(String reason) {
/* 41 */     super(reason);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLDataException
 * JD-Core Version:    0.6.0
 */