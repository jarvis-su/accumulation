package com.acs.eppic.messageservice;

public abstract interface MessageServiceMBean
{
  public abstract String getConfigName();

  public abstract boolean isStarted();

  public abstract boolean isServiceEnabled();

  public abstract String getSystemId();

  public abstract String getSystemPort();

  public abstract String getMonitorHost();

  public abstract String getMonitorPort();

  public abstract String getMonitorUrlPath();

  public abstract void setMonitorHost(String paramString);

  public abstract void setMonitorPort(String paramString);

  public abstract void setMonitorUrlPath(String paramString);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.MessageServiceMBean
 * JD-Core Version:    0.6.0
 */