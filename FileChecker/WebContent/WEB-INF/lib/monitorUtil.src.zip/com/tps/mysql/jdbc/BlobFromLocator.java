/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.sql.Blob;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class BlobFromLocator
/*     */   implements Blob
/*     */ {
/*  55 */   private List primaryKeyColumns = null;
/*     */ 
/*  57 */   private List primaryKeyValues = null;
/*     */   private ResultSet creatorResultSet;
/*  62 */   private String blobColumnName = null;
/*     */ 
/*  64 */   private String tableName = null;
/*     */ 
/*  66 */   private int numColsInResultSet = 0;
/*     */ 
/*  68 */   private int numPrimaryKeys = 0;
/*     */   private String quotedId;
/*     */ 
/*     */   BlobFromLocator(ResultSet creatorResultSetToSet, int blobColumnIndex)
/*     */     throws SQLException
/*     */   {
/*  77 */     this.creatorResultSet = creatorResultSetToSet;
/*     */ 
/*  79 */     this.numColsInResultSet = this.creatorResultSet.fields.length;
/*  80 */     this.quotedId = this.creatorResultSet.connection.getMetaData().getIdentifierQuoteString();
/*     */ 
/*  83 */     if (this.numColsInResultSet > 1) {
/*  84 */       this.primaryKeyColumns = new ArrayList();
/*  85 */       this.primaryKeyValues = new ArrayList();
/*     */ 
/*  87 */       for (int i = 0; i < this.numColsInResultSet; i++)
/*  88 */         if (this.creatorResultSet.fields[i].isPrimaryKey()) {
/*  89 */           StringBuffer keyName = new StringBuffer();
/*  90 */           keyName.append(this.quotedId);
/*     */ 
/*  92 */           String originalColumnName = this.creatorResultSet.fields[i].getOriginalName();
/*     */ 
/*  95 */           if ((originalColumnName != null) && (originalColumnName.length() > 0))
/*     */           {
/*  97 */             keyName.append(originalColumnName);
/*     */           }
/*  99 */           else keyName.append(this.creatorResultSet.fields[i].getName());
/*     */ 
/* 103 */           keyName.append(this.quotedId);
/*     */ 
/* 105 */           this.primaryKeyColumns.add(keyName.toString());
/* 106 */           this.primaryKeyValues.add(this.creatorResultSet.getString(i + 1));
/*     */         }
/*     */     }
/*     */     else
/*     */     {
/* 111 */       notEnoughInformationInQuery();
/*     */     }
/*     */ 
/* 114 */     this.numPrimaryKeys = this.primaryKeyColumns.size();
/*     */ 
/* 116 */     if (this.numPrimaryKeys == 0) {
/* 117 */       notEnoughInformationInQuery();
/*     */     }
/*     */ 
/* 120 */     if (this.creatorResultSet.fields[0].getOriginalTableName() != null) {
/* 121 */       StringBuffer tableNameBuffer = new StringBuffer();
/*     */ 
/* 123 */       String databaseName = this.creatorResultSet.fields[0].getDatabaseName();
/*     */ 
/* 126 */       if ((databaseName != null) && (databaseName.length() > 0)) {
/* 127 */         tableNameBuffer.append(this.quotedId);
/* 128 */         tableNameBuffer.append(databaseName);
/* 129 */         tableNameBuffer.append(this.quotedId);
/* 130 */         tableNameBuffer.append('.');
/*     */       }
/*     */ 
/* 133 */       tableNameBuffer.append(this.quotedId);
/* 134 */       tableNameBuffer.append(this.creatorResultSet.fields[0].getOriginalTableName());
/*     */ 
/* 136 */       tableNameBuffer.append(this.quotedId);
/*     */ 
/* 138 */       this.tableName = tableNameBuffer.toString();
/*     */     } else {
/* 140 */       StringBuffer tableNameBuffer = new StringBuffer();
/*     */ 
/* 142 */       tableNameBuffer.append(this.quotedId);
/* 143 */       tableNameBuffer.append(this.creatorResultSet.fields[0].getTableName());
/*     */ 
/* 145 */       tableNameBuffer.append(this.quotedId);
/*     */ 
/* 147 */       this.tableName = tableNameBuffer.toString();
/*     */     }
/*     */ 
/* 150 */     this.blobColumnName = (this.quotedId + this.creatorResultSet.getString(blobColumnIndex) + this.quotedId);
/*     */   }
/*     */ 
/*     */   private void notEnoughInformationInQuery() throws SQLException
/*     */   {
/* 155 */     throw SQLError.createSQLException("Emulated BLOB locators must come from a ResultSet with only one table selected, and all primary keys selected", "S1000");
/*     */   }
/*     */ 
/*     */   public OutputStream setBinaryStream(long indexToWriteAt)
/*     */     throws SQLException
/*     */   {
/* 165 */     throw new NotImplemented();
/*     */   }
/*     */ 
/*     */   public InputStream getBinaryStream()
/*     */     throws SQLException
/*     */   {
/* 178 */     return new BufferedInputStream(new BlobFromLocator.LocatorInputStream(this), this.creatorResultSet.connection.getLocatorFetchBufferSize());
/*     */   }
/*     */ 
/*     */   public int setBytes(long writeAt, byte[] bytes, int offset, int length)
/*     */     throws SQLException
/*     */   {
/* 187 */     PreparedStatement pStmt = null;
/*     */ 
/* 189 */     if (offset + length > bytes.length) {
/* 190 */       length = bytes.length - offset;
/*     */     }
/*     */ 
/* 193 */     byte[] bytesToWrite = new byte[length];
/* 194 */     System.arraycopy(bytes, offset, bytesToWrite, 0, length);
/*     */ 
/* 197 */     StringBuffer query = new StringBuffer("UPDATE ");
/* 198 */     query.append(this.tableName);
/* 199 */     query.append(" SET ");
/* 200 */     query.append(this.blobColumnName);
/* 201 */     query.append(" = INSERT(");
/* 202 */     query.append(this.blobColumnName);
/* 203 */     query.append(", ");
/* 204 */     query.append(writeAt);
/* 205 */     query.append(", ");
/* 206 */     query.append(length);
/* 207 */     query.append(", ?) WHERE ");
/*     */ 
/* 209 */     query.append((String)this.primaryKeyColumns.get(0));
/* 210 */     query.append(" = ?");
/*     */ 
/* 212 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 213 */       query.append(" AND ");
/* 214 */       query.append((String)this.primaryKeyColumns.get(i));
/* 215 */       query.append(" = ?");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 220 */       pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());
/*     */ 
/* 223 */       pStmt.setBytes(1, bytesToWrite);
/*     */ 
/* 225 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 226 */         pStmt.setString(i + 2, (String)this.primaryKeyValues.get(i));
/*     */       }
/*     */ 
/* 229 */       int rowsUpdated = pStmt.executeUpdate();
/*     */ 
/* 231 */       if (rowsUpdated != 1) {
/* 232 */         throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 237 */       if (pStmt != null) {
/*     */         try {
/* 239 */           pStmt.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 244 */         pStmt = null;
/*     */       }
/*     */     }
/*     */ 
/* 248 */     return (int)length();
/*     */   }
/*     */ 
/*     */   public int setBytes(long writeAt, byte[] bytes)
/*     */     throws SQLException
/*     */   {
/* 255 */     return setBytes(writeAt, bytes, 0, bytes.length);
/*     */   }
/*     */ 
/*     */   public byte[] getBytes(long pos, int length)
/*     */     throws SQLException
/*     */   {
/* 274 */     java.sql.ResultSet blobRs = null;
/* 275 */     PreparedStatement pStmt = null;
/*     */     try
/*     */     {
/* 279 */       pStmt = createGetBytesStatement();
/*     */ 
/* 281 */       arrayOfByte = getBytesInternal(pStmt, pos, length);
/*     */     }
/*     */     finally
/*     */     {
/*     */       byte[] arrayOfByte;
/* 283 */       if (blobRs != null) {
/*     */         try {
/* 285 */           blobRs.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 290 */         blobRs = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long length()
/*     */     throws SQLException
/*     */   {
/* 305 */     java.sql.ResultSet blobRs = null;
/* 306 */     PreparedStatement pStmt = null;
/*     */ 
/* 309 */     StringBuffer query = new StringBuffer("SELECT LENGTH(");
/* 310 */     query.append(this.blobColumnName);
/* 311 */     query.append(") FROM ");
/* 312 */     query.append(this.tableName);
/* 313 */     query.append(" WHERE ");
/*     */ 
/* 315 */     query.append((String)this.primaryKeyColumns.get(0));
/* 316 */     query.append(" = ?");
/*     */ 
/* 318 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 319 */       query.append(" AND ");
/* 320 */       query.append((String)this.primaryKeyColumns.get(i));
/* 321 */       query.append(" = ?");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 326 */       pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());
/*     */ 
/* 329 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 330 */         pStmt.setString(i + 1, (String)this.primaryKeyValues.get(i));
/*     */       }
/*     */ 
/* 333 */       blobRs = pStmt.executeQuery();
/*     */ 
/* 335 */       if (blobRs.next()) {
/* 336 */         i = blobRs.getLong(1); jsr 22;
/*     */       }
/*     */ 
/* 339 */       throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000");
/*     */     }
/*     */     finally
/*     */     {
/* 343 */       if (blobRs != null) {
/*     */         try {
/* 345 */           blobRs.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 350 */         blobRs = null;
/*     */       }
/*     */ 
/* 353 */       if (pStmt != null) {
/*     */         try {
/* 355 */           pStmt.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 360 */         pStmt = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public long position(Blob pattern, long start)
/*     */     throws SQLException
/*     */   {
/* 380 */     return position(pattern.getBytes(0L, (int)pattern.length()), start);
/*     */   }
/*     */ 
/*     */   public long position(byte[] pattern, long start)
/*     */     throws SQLException
/*     */   {
/* 387 */     java.sql.ResultSet blobRs = null;
/* 388 */     PreparedStatement pStmt = null;
/*     */ 
/* 391 */     StringBuffer query = new StringBuffer("SELECT LOCATE(");
/* 392 */     query.append("?, ");
/* 393 */     query.append(this.blobColumnName);
/* 394 */     query.append(", ");
/* 395 */     query.append(start);
/* 396 */     query.append(") FROM ");
/* 397 */     query.append(this.tableName);
/* 398 */     query.append(" WHERE ");
/*     */ 
/* 400 */     query.append((String)this.primaryKeyColumns.get(0));
/* 401 */     query.append(" = ?");
/*     */ 
/* 403 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 404 */       query.append(" AND ");
/* 405 */       query.append((String)this.primaryKeyColumns.get(i));
/* 406 */       query.append(" = ?");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 411 */       pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());
/*     */ 
/* 413 */       pStmt.setBytes(1, pattern);
/*     */ 
/* 415 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 416 */         pStmt.setString(i + 2, (String)this.primaryKeyValues.get(i));
/*     */       }
/*     */ 
/* 419 */       blobRs = pStmt.executeQuery();
/*     */ 
/* 421 */       if (blobRs.next()) {
/* 422 */         i = blobRs.getLong(1); jsr 22;
/*     */       }
/*     */ 
/* 425 */       throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000");
/*     */     }
/*     */     finally
/*     */     {
/* 429 */       if (blobRs != null) {
/*     */         try {
/* 431 */           blobRs.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 436 */         blobRs = null;
/*     */       }
/*     */ 
/* 439 */       if (pStmt != null) {
/*     */         try {
/* 441 */           pStmt.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 446 */         pStmt = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void truncate(long length)
/*     */     throws SQLException
/*     */   {
/* 455 */     PreparedStatement pStmt = null;
/*     */ 
/* 458 */     StringBuffer query = new StringBuffer("UPDATE ");
/* 459 */     query.append(this.tableName);
/* 460 */     query.append(" SET ");
/* 461 */     query.append(this.blobColumnName);
/* 462 */     query.append(" = LEFT(");
/* 463 */     query.append(this.blobColumnName);
/* 464 */     query.append(", ");
/* 465 */     query.append(length);
/* 466 */     query.append(") WHERE ");
/*     */ 
/* 468 */     query.append((String)this.primaryKeyColumns.get(0));
/* 469 */     query.append(" = ?");
/*     */ 
/* 471 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 472 */       query.append(" AND ");
/* 473 */       query.append((String)this.primaryKeyColumns.get(i));
/* 474 */       query.append(" = ?");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 479 */       pStmt = this.creatorResultSet.connection.prepareStatement(query.toString());
/*     */ 
/* 482 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 483 */         pStmt.setString(i + 1, (String)this.primaryKeyValues.get(i));
/*     */       }
/*     */ 
/* 486 */       int rowsUpdated = pStmt.executeUpdate();
/*     */ 
/* 488 */       if (rowsUpdated != 1) {
/* 489 */         throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000");
/*     */       }
/*     */     }
/*     */     finally
/*     */     {
/* 494 */       if (pStmt != null) {
/*     */         try {
/* 496 */           pStmt.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 501 */         pStmt = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   PreparedStatement createGetBytesStatement() throws SQLException {
/* 507 */     StringBuffer query = new StringBuffer("SELECT SUBSTRING(");
/*     */ 
/* 509 */     query.append(this.blobColumnName);
/* 510 */     query.append(", ");
/* 511 */     query.append("?");
/* 512 */     query.append(", ");
/* 513 */     query.append("?");
/* 514 */     query.append(") FROM ");
/* 515 */     query.append(this.tableName);
/* 516 */     query.append(" WHERE ");
/*     */ 
/* 518 */     query.append((String)this.primaryKeyColumns.get(0));
/* 519 */     query.append(" = ?");
/*     */ 
/* 521 */     for (int i = 1; i < this.numPrimaryKeys; i++) {
/* 522 */       query.append(" AND ");
/* 523 */       query.append((String)this.primaryKeyColumns.get(i));
/* 524 */       query.append(" = ?");
/*     */     }
/*     */ 
/* 527 */     return this.creatorResultSet.connection.prepareStatement(query.toString());
/*     */   }
/*     */ 
/*     */   byte[] getBytesInternal(PreparedStatement pStmt, long pos, int length)
/*     */     throws SQLException
/*     */   {
/* 534 */     java.sql.ResultSet blobRs = null;
/*     */     try
/*     */     {
/* 538 */       pStmt.setLong(1, pos);
/* 539 */       pStmt.setInt(2, length);
/*     */ 
/* 541 */       for (int i = 0; i < this.numPrimaryKeys; i++) {
/* 542 */         pStmt.setString(i + 3, (String)this.primaryKeyValues.get(i));
/*     */       }
/*     */ 
/* 545 */       blobRs = pStmt.executeQuery();
/*     */ 
/* 547 */       if (blobRs.next()) {
/* 548 */         i = ((ResultSet)blobRs).getBytes(1, true); jsr 22;
/*     */       }
/*     */ 
/* 551 */       throw SQLError.createSQLException("BLOB data not found! Did primary keys change?", "S1000");
/*     */     }
/*     */     finally
/*     */     {
/* 555 */       if (blobRs != null) {
/*     */         try {
/* 557 */           blobRs.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/* 562 */         blobRs = null;
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.BlobFromLocator
 * JD-Core Version:    0.6.0
 */