package com.ibm.wsdl.extensions.http;

import javax.wsdl.extensions.http.HTTPOperation;
import javax.xml.namespace.QName;

public class HTTPOperationImpl
  implements HTTPOperation
{
  protected QName elementType = HTTPConstants.Q_ELEM_HTTP_OPERATION;
  protected Boolean required = null;
  protected String locationURI = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setLocationURI(String paramString)
  {
    this.locationURI = paramString;
  }

  public String getLocationURI()
  {
    return this.locationURI;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("HTTPOperation (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.locationURI != null)
      localStringBuffer.append("\nlocationURI=" + this.locationURI);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.http.HTTPOperationImpl
 * JD-Core Version:    0.6.0
 */