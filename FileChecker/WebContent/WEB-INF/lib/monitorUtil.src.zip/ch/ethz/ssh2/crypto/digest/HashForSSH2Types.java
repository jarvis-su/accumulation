/*    */ package ch.ethz.ssh2.crypto.digest;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class HashForSSH2Types
/*    */ {
/*    */   Digest md;
/*    */ 
/*    */   public HashForSSH2Types(Digest md)
/*    */   {
/* 18 */     this.md = md;
/*    */   }
/*    */ 
/*    */   public HashForSSH2Types(String type)
/*    */   {
/* 23 */     if (type.equals("SHA1"))
/*    */     {
/* 25 */       this.md = new SHA1();
/*    */     }
/* 27 */     else if (type.equals("MD5"))
/*    */     {
/* 29 */       this.md = new MD5();
/*    */     }
/*    */     else
/* 32 */       throw new IllegalArgumentException("Unknown algorithm " + type);
/*    */   }
/*    */ 
/*    */   public void updateByte(byte b)
/*    */   {
/* 38 */     byte[] tmp = new byte[1];
/* 39 */     tmp[0] = b;
/* 40 */     this.md.update(tmp);
/*    */   }
/*    */ 
/*    */   public void updateBytes(byte[] b)
/*    */   {
/* 45 */     this.md.update(b);
/*    */   }
/*    */ 
/*    */   public void updateUINT32(int v)
/*    */   {
/* 50 */     this.md.update((byte)(v >> 24));
/* 51 */     this.md.update((byte)(v >> 16));
/* 52 */     this.md.update((byte)(v >> 8));
/* 53 */     this.md.update((byte)v);
/*    */   }
/*    */ 
/*    */   public void updateByteString(byte[] b)
/*    */   {
/* 58 */     updateUINT32(b.length);
/* 59 */     updateBytes(b);
/*    */   }
/*    */ 
/*    */   public void updateBigInt(BigInteger b)
/*    */   {
/* 64 */     updateByteString(b.toByteArray());
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/* 69 */     this.md.reset();
/*    */   }
/*    */ 
/*    */   public int getDigestLength()
/*    */   {
/* 74 */     return this.md.getDigestLength();
/*    */   }
/*    */ 
/*    */   public byte[] getDigest()
/*    */   {
/* 79 */     byte[] tmp = new byte[this.md.getDigestLength()];
/* 80 */     getDigest(tmp);
/* 81 */     return tmp;
/*    */   }
/*    */ 
/*    */   public void getDigest(byte[] out)
/*    */   {
/* 86 */     getDigest(out, 0);
/*    */   }
/*    */ 
/*    */   public void getDigest(byte[] out, int off)
/*    */   {
/* 91 */     this.md.digest(out, off);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.HashForSSH2Types
 * JD-Core Version:    0.6.0
 */