package com.mysql.jdbc;

abstract interface OutputStreamWatcher
{
  public abstract void streamClosed(WatchableOutputStream paramWatchableOutputStream);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.OutputStreamWatcher
 * JD-Core Version:    0.6.0
 */