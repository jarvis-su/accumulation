/*      */ package ch.ethz.ssh2.channel;
/*      */ 
/*      */ import ch.ethz.ssh2.log.Logger;
/*      */ import ch.ethz.ssh2.packets.PacketChannelOpenConfirmation;
/*      */ import ch.ethz.ssh2.packets.PacketChannelOpenFailure;
/*      */ import ch.ethz.ssh2.packets.PacketGlobalCancelForwardRequest;
/*      */ import ch.ethz.ssh2.packets.PacketGlobalForwardRequest;
/*      */ import ch.ethz.ssh2.packets.PacketOpenDirectTCPIPChannel;
/*      */ import ch.ethz.ssh2.packets.PacketOpenSessionChannel;
/*      */ import ch.ethz.ssh2.packets.PacketSessionExecCommand;
/*      */ import ch.ethz.ssh2.packets.PacketSessionPtyRequest;
/*      */ import ch.ethz.ssh2.packets.PacketSessionStartShell;
/*      */ import ch.ethz.ssh2.packets.PacketSessionSubsystemRequest;
/*      */ import ch.ethz.ssh2.packets.PacketSessionX11Request;
/*      */ import ch.ethz.ssh2.packets.TypesReader;
/*      */ import ch.ethz.ssh2.transport.MessageHandler;
/*      */ import ch.ethz.ssh2.transport.TransportManager;
/*      */ import java.io.IOException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class ChannelManager
/*      */   implements MessageHandler
/*      */ {
/*   36 */   private static final Logger log = Logger.getLogger(ChannelManager.class);
/*      */ 
/*   38 */   private HashMap x11_magic_cookies = new HashMap();
/*      */   private TransportManager tm;
/*   42 */   private Vector channels = new Vector();
/*   43 */   private int nextLocalChannel = 100;
/*   44 */   private boolean shutdown = false;
/*   45 */   private int globalSuccessCounter = 0;
/*   46 */   private int globalFailedCounter = 0;
/*      */ 
/*   48 */   private HashMap remoteForwardings = new HashMap();
/*      */ 
/*   50 */   private Vector listenerThreads = new Vector();
/*      */ 
/*   52 */   private boolean listenerThreadsAllowed = true;
/*      */ 
/*      */   public ChannelManager(TransportManager tm)
/*      */   {
/*   56 */     this.tm = tm;
/*   57 */     tm.registerMessageHandler(this, 80, 100);
/*      */   }
/*      */ 
/*      */   private Channel getChannel(int id)
/*      */   {
/*   62 */     synchronized (this.channels)
/*      */     {
/*   64 */       for (int i = 0; i < this.channels.size(); i++)
/*      */       {
/*   66 */         Channel c = (Channel)this.channels.elementAt(i);
/*   67 */         if (c.localID == id)
/*   68 */           return c;
/*      */       }
/*      */     }
/*   71 */     return null;
/*      */   }
/*      */ 
/*      */   private void removeChannel(int id)
/*      */   {
/*   76 */     synchronized (this.channels)
/*      */     {
/*   78 */       for (int i = 0; i < this.channels.size(); i++)
/*      */       {
/*   80 */         Channel c = (Channel)this.channels.elementAt(i);
/*   81 */         if (c.localID != id)
/*      */           continue;
/*   83 */         this.channels.removeElementAt(i);
/*   84 */         break;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int addChannel(Channel c)
/*      */   {
/*   92 */     synchronized (this.channels)
/*      */     {
/*   94 */       this.channels.addElement(c);
/*   95 */       return this.nextLocalChannel++;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void waitUntilChannelOpen(Channel c) throws IOException
/*      */   {
/*  101 */     synchronized (c)
/*      */     {
/*  103 */       while (c.state == 1)
/*      */       {
/*      */         try
/*      */         {
/*  107 */           c.wait();
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */       }
/*      */ 
/*  114 */       if (c.state != 2)
/*      */       {
/*  116 */         removeChannel(c.localID);
/*      */ 
/*  118 */         String detail = c.getReasonClosed();
/*      */ 
/*  120 */         if (detail == null) {
/*  121 */           detail = "state: " + c.state;
/*      */         }
/*  123 */         throw new IOException("Could not open channel (" + detail + ")");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void waitForGlobalSuccessOrFailure() throws IOException
/*      */   {
/*  130 */     synchronized (this.channels)
/*      */     {
/*  132 */       while ((this.globalSuccessCounter == 0) && (this.globalFailedCounter == 0))
/*      */       {
/*  134 */         if (this.shutdown)
/*      */         {
/*  136 */           throw new IOException("The connection is being shutdown");
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  141 */           this.channels.wait();
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */       }
/*      */ 
/*  148 */       if (this.globalFailedCounter != 0)
/*      */       {
/*  150 */         throw new IOException("The server denied the request (did you enable port forwarding?)");
/*      */       }
/*      */ 
/*  153 */       if (this.globalSuccessCounter == 0)
/*      */       {
/*  155 */         throw new IOException("Illegal state.");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void waitForChannelSuccessOrFailure(Channel c)
/*      */     throws IOException
/*      */   {
/*  163 */     synchronized (c)
/*      */     {
/*  165 */       while ((c.successCounter == 0) && (c.failedCounter == 0))
/*      */       {
/*  167 */         if (c.state != 2)
/*      */         {
/*  169 */           String detail = c.getReasonClosed();
/*      */ 
/*  171 */           if (detail == null) {
/*  172 */             detail = "state: " + c.state;
/*      */           }
/*  174 */           throw new IOException("This SSH2 channel is not open (" + detail + ")");
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/*  179 */           c.wait();
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */       }
/*      */ 
/*  186 */       if (c.failedCounter != 0)
/*      */       {
/*  188 */         throw new IOException("The server denied the request.");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerX11Cookie(String hexFakeCookie, X11ServerData data)
/*      */   {
/*  195 */     synchronized (this.x11_magic_cookies)
/*      */     {
/*  197 */       this.x11_magic_cookies.put(hexFakeCookie, data);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void unRegisterX11Cookie(String hexFakeCookie, boolean killChannels)
/*      */   {
/*  203 */     if (hexFakeCookie == null) {
/*  204 */       throw new IllegalStateException("hexFakeCookie may not be null");
/*      */     }
/*  206 */     synchronized (this.x11_magic_cookies)
/*      */     {
/*  208 */       this.x11_magic_cookies.remove(hexFakeCookie);
/*      */     }
/*      */ 
/*  211 */     if (!killChannels) {
/*  212 */       return;
/*      */     }
/*  214 */     if (log.isEnabled())
/*  215 */       log.log(50, "Closing all X11 channels for the given fake cookie");
/*      */     Vector channel_copy;
/*  219 */     synchronized (this.channels)
/*      */     {
/*  221 */       channel_copy = (Vector)this.channels.clone();
/*      */     }
/*      */ 
/*  224 */     for (int i = 0; i < channel_copy.size(); i++)
/*      */     {
/*  226 */       Channel c = (Channel)channel_copy.elementAt(i);
/*      */ 
/*  228 */       synchronized (c)
/*      */       {
/*  230 */         if (!hexFakeCookie.equals(c.hexX11FakeCookie)) {
/*  231 */           continue;
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/*  236 */         closeChannel(c, "Closing X11 channel since the corresponding session is closing", true);
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public X11ServerData checkX11Cookie(String hexFakeCookie)
/*      */   {
/*  246 */     synchronized (this.x11_magic_cookies)
/*      */     {
/*  248 */       if (hexFakeCookie != null)
/*  249 */         return (X11ServerData)this.x11_magic_cookies.get(hexFakeCookie);
/*      */     }
/*  251 */     return null;
/*      */   }
/*      */ 
/*      */   public void closeAllChannels()
/*      */   {
/*  256 */     if (log.isEnabled())
/*  257 */       log.log(50, "Closing all channels");
/*      */     Vector channel_copy;
/*  261 */     synchronized (this.channels)
/*      */     {
/*  263 */       channel_copy = (Vector)this.channels.clone();
/*      */     }
/*      */ 
/*  266 */     for (int i = 0; i < channel_copy.size(); i++)
/*      */     {
/*  268 */       Channel c = (Channel)channel_copy.elementAt(i);
/*      */       try
/*      */       {
/*  271 */         closeChannel(c, "Closing all channels", true);
/*      */       }
/*      */       catch (IOException localIOException)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void closeChannel(Channel c, String reason, boolean force) throws IOException
/*      */   {
/*  281 */     byte[] msg = new byte[5];
/*      */ 
/*  283 */     synchronized (c)
/*      */     {
/*  285 */       if (force)
/*      */       {
/*  287 */         c.state = 4;
/*  288 */         c.EOF = true;
/*      */       }
/*      */ 
/*  291 */       c.setReasonClosed(reason);
/*      */ 
/*  293 */       msg[0] = 97;
/*  294 */       msg[1] = (byte)(c.remoteID >> 24);
/*  295 */       msg[2] = (byte)(c.remoteID >> 16);
/*  296 */       msg[3] = (byte)(c.remoteID >> 8);
/*  297 */       msg[4] = (byte)c.remoteID;
/*      */ 
/*  299 */       c.notifyAll();
/*      */     }
/*      */ 
/*  302 */     synchronized (c.channelSendLock)
/*      */     {
/*  304 */       if (c.closeMessageSent)
/*  305 */         return;
/*  306 */       this.tm.sendMessage(msg);
/*  307 */       c.closeMessageSent = true;
/*      */     }
/*      */ 
/*  310 */     if (log.isEnabled())
/*  311 */       log.log(50, "Sent SSH_MSG_CHANNEL_CLOSE (channel " + c.localID + ")");
/*      */   }
/*      */ 
/*      */   public void sendEOF(Channel c) throws IOException
/*      */   {
/*  316 */     byte[] msg = new byte[5];
/*      */ 
/*  318 */     synchronized (c)
/*      */     {
/*  320 */       if (c.state != 2) {
/*  321 */         return;
/*      */       }
/*  323 */       msg[0] = 96;
/*  324 */       msg[1] = (byte)(c.remoteID >> 24);
/*  325 */       msg[2] = (byte)(c.remoteID >> 16);
/*  326 */       msg[3] = (byte)(c.remoteID >> 8);
/*  327 */       msg[4] = (byte)c.remoteID;
/*      */     }
/*      */ 
/*  330 */     synchronized (c.channelSendLock)
/*      */     {
/*  332 */       if (c.closeMessageSent)
/*  333 */         return;
/*  334 */       this.tm.sendMessage(msg);
/*      */     }
/*      */ 
/*  337 */     if (log.isEnabled())
/*  338 */       log.log(50, "Sent EOF (Channel " + c.localID + "/" + c.remoteID + ")");
/*      */   }
/*      */ 
/*      */   public void sendOpenConfirmation(Channel c) throws IOException
/*      */   {
/*  343 */     PacketChannelOpenConfirmation pcoc = null;
/*      */ 
/*  345 */     synchronized (c)
/*      */     {
/*  347 */       if (c.state != 1) {
/*  348 */         return;
/*      */       }
/*  350 */       c.state = 2;
/*      */ 
/*  352 */       pcoc = new PacketChannelOpenConfirmation(c.remoteID, c.localID, c.localWindow, c.localMaxPacketSize);
/*      */     }
/*      */ 
/*  355 */     synchronized (c.channelSendLock)
/*      */     {
/*  357 */       if (c.closeMessageSent)
/*  358 */         return;
/*  359 */       this.tm.sendMessage(pcoc.getPayload());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void sendData(Channel c, byte[] buffer, int pos, int len) throws IOException
/*      */   {
/*  365 */     while (len > 0)
/*      */     {
/*  367 */       int thislen = 0;
/*      */       byte[] msg;
/*  370 */       synchronized (c)
/*      */       {
/*      */         while (true)
/*      */         {
/*  374 */           if (c.state == 4) {
/*  375 */             throw new IOException("SSH channel is closed. (" + c.getReasonClosed() + ")");
/*      */           }
/*  377 */           if (c.state != 2) {
/*  378 */             throw new IOException("SSH channel in strange state. (" + c.state + ")");
/*      */           }
/*  380 */           if (c.remoteWindow != 0L) {
/*      */             break;
/*      */           }
/*      */           try
/*      */           {
/*  385 */             c.wait();
/*      */           }
/*      */           catch (InterruptedException localInterruptedException)
/*      */           {
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  394 */         thislen = c.remoteWindow >= len ? len : (int)c.remoteWindow;
/*      */ 
/*  396 */         int estimatedMaxDataLen = c.remoteMaxPacketSize - (this.tm.getPacketOverheadEstimate() + 9);
/*      */ 
/*  400 */         if (estimatedMaxDataLen <= 0)
/*      */         {
/*  402 */           estimatedMaxDataLen = 1;
/*      */         }
/*      */ 
/*  405 */         if (thislen > estimatedMaxDataLen) {
/*  406 */           thislen = estimatedMaxDataLen;
/*      */         }
/*  408 */         c.remoteWindow -= thislen;
/*      */ 
/*  410 */         msg = new byte[9 + thislen];
/*      */ 
/*  412 */         msg[0] = 94;
/*  413 */         msg[1] = (byte)(c.remoteID >> 24);
/*  414 */         msg[2] = (byte)(c.remoteID >> 16);
/*  415 */         msg[3] = (byte)(c.remoteID >> 8);
/*  416 */         msg[4] = (byte)c.remoteID;
/*  417 */         msg[5] = (byte)(thislen >> 24);
/*  418 */         msg[6] = (byte)(thislen >> 16);
/*  419 */         msg[7] = (byte)(thislen >> 8);
/*  420 */         msg[8] = (byte)thislen;
/*      */ 
/*  422 */         System.arraycopy(buffer, pos, msg, 9, thislen);
/*      */       }
/*      */ 
/*  425 */       synchronized (c.channelSendLock)
/*      */       {
/*  427 */         if (c.closeMessageSent) {
/*  428 */           throw new IOException("SSH channel is closed. (" + c.getReasonClosed() + ")");
/*      */         }
/*  430 */         this.tm.sendMessage(msg);
/*      */       }
/*      */ 
/*  433 */       pos += thislen;
/*  434 */       len -= thislen;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int requestGlobalForward(String bindAddress, int bindPort, String targetAddress, int targetPort)
/*      */     throws IOException
/*      */   {
/*  441 */     RemoteForwardingData rfd = new RemoteForwardingData();
/*      */ 
/*  443 */     rfd.bindAddress = bindAddress;
/*  444 */     rfd.bindPort = bindPort;
/*  445 */     rfd.targetAddress = targetAddress;
/*  446 */     rfd.targetPort = targetPort;
/*      */ 
/*  448 */     synchronized (this.remoteForwardings)
/*      */     {
/*  450 */       Integer key = new Integer(bindPort);
/*      */ 
/*  452 */       if (this.remoteForwardings.get(key) != null)
/*      */       {
/*  454 */         throw new IOException("There is already a forwarding for remote port " + bindPort);
/*      */       }
/*      */ 
/*  457 */       this.remoteForwardings.put(key, rfd);
/*      */     }
/*      */ 
/*  460 */     synchronized (this.channels)
/*      */     {
/*  462 */       this.globalSuccessCounter = (this.globalFailedCounter = 0);
/*      */     }
/*      */ 
/*  465 */     PacketGlobalForwardRequest pgf = new PacketGlobalForwardRequest(true, bindAddress, bindPort);
/*  466 */     this.tm.sendMessage(pgf.getPayload());
/*      */ 
/*  468 */     if (log.isEnabled()) {
/*  469 */       log.log(50, "Requesting a remote forwarding ('" + bindAddress + "', " + bindPort + ")");
/*      */     }
/*      */     try
/*      */     {
/*  473 */       waitForGlobalSuccessOrFailure();
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  477 */       synchronized (this.remoteForwardings)
/*      */       {
/*  479 */         this.remoteForwardings.remove(rfd);
/*      */       }
/*  481 */       throw e;
/*      */     }
/*      */ 
/*  484 */     return bindPort;
/*      */   }
/*      */ 
/*      */   public void requestCancelGlobalForward(int bindPort) throws IOException
/*      */   {
/*  489 */     RemoteForwardingData rfd = null;
/*      */ 
/*  491 */     synchronized (this.remoteForwardings)
/*      */     {
/*  493 */       rfd = (RemoteForwardingData)this.remoteForwardings.get(new Integer(bindPort));
/*      */ 
/*  495 */       if (rfd == null) {
/*  496 */         throw new IOException("Sorry, there is no known remote forwarding for remote port " + bindPort);
/*      */       }
/*      */     }
/*  499 */     synchronized (this.channels)
/*      */     {
/*  501 */       this.globalSuccessCounter = (this.globalFailedCounter = 0);
/*      */     }
/*      */ 
/*  504 */     PacketGlobalCancelForwardRequest pgcf = new PacketGlobalCancelForwardRequest(true, rfd.bindAddress, 
/*  505 */       rfd.bindPort);
/*  506 */     this.tm.sendMessage(pgcf.getPayload());
/*      */ 
/*  508 */     if (log.isEnabled()) {
/*  509 */       log.log(50, "Requesting cancelation of remote forward ('" + rfd.bindAddress + "', " + rfd.bindPort + ")");
/*      */     }
/*  511 */     waitForGlobalSuccessOrFailure();
/*      */ 
/*  515 */     synchronized (this.remoteForwardings)
/*      */     {
/*  517 */       this.remoteForwardings.remove(rfd);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void registerThread(IChannelWorkerThread thr) throws IOException
/*      */   {
/*  523 */     synchronized (this.listenerThreads)
/*      */     {
/*  525 */       if (!this.listenerThreadsAllowed)
/*  526 */         throw new IOException("Too late, this connection is closed.");
/*  527 */       this.listenerThreads.addElement(thr);
/*      */     }
/*      */   }
/*      */ 
/*      */   public Channel openDirectTCPIPChannel(String host_to_connect, int port_to_connect, String originator_IP_address, int originator_port)
/*      */     throws IOException
/*      */   {
/*  534 */     Channel c = new Channel(this);
/*      */ 
/*  536 */     synchronized (c)
/*      */     {
/*  538 */       c.localID = addChannel(c);
/*      */     }
/*      */ 
/*  542 */     PacketOpenDirectTCPIPChannel dtc = new PacketOpenDirectTCPIPChannel(c.localID, c.localWindow, 
/*  543 */       c.localMaxPacketSize, host_to_connect, port_to_connect, originator_IP_address, originator_port);
/*      */ 
/*  545 */     this.tm.sendMessage(dtc.getPayload());
/*      */ 
/*  547 */     waitUntilChannelOpen(c);
/*      */ 
/*  549 */     return c;
/*      */   }
/*      */ 
/*      */   public Channel openSessionChannel() throws IOException
/*      */   {
/*  554 */     Channel c = new Channel(this);
/*      */ 
/*  556 */     synchronized (c)
/*      */     {
/*  558 */       c.localID = addChannel(c);
/*      */     }
/*      */ 
/*  562 */     if (log.isEnabled()) {
/*  563 */       log.log(50, "Sending SSH_MSG_CHANNEL_OPEN (Channel " + c.localID + ")");
/*      */     }
/*  565 */     PacketOpenSessionChannel smo = new PacketOpenSessionChannel(c.localID, c.localWindow, c.localMaxPacketSize);
/*  566 */     this.tm.sendMessage(smo.getPayload());
/*      */ 
/*  568 */     waitUntilChannelOpen(c);
/*      */ 
/*  570 */     return c;
/*      */   }
/*      */ 
/*      */   public void requestPTY(Channel c, String term, int term_width_characters, int term_height_characters, int term_width_pixels, int term_height_pixels, byte[] terminal_modes)
/*      */     throws IOException
/*      */   {
/*      */     PacketSessionPtyRequest spr;
/*  578 */     synchronized (c)
/*      */     {
/*  580 */       if (c.state != 2) {
/*  581 */         throw new IOException("Cannot request PTY on this channel (" + c.getReasonClosed() + ")");
/*      */       }
/*  583 */       spr = new PacketSessionPtyRequest(c.remoteID, true, term, term_width_characters, term_height_characters, 
/*  584 */         term_width_pixels, term_height_pixels, terminal_modes);
/*      */ 
/*  586 */       c.successCounter = (c.failedCounter = 0);
/*      */     }
/*      */ 
/*  589 */     synchronized (c.channelSendLock)
/*      */     {
/*  591 */       if (c.closeMessageSent)
/*  592 */         throw new IOException("Cannot request PTY on this channel (" + c.getReasonClosed() + ")");
/*  593 */       this.tm.sendMessage(spr.getPayload());
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  598 */       waitForChannelSuccessOrFailure(c);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  602 */       throw ((IOException)new IOException("PTY request failed").initCause(e));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void requestX11(Channel c, boolean singleConnection, String x11AuthenticationProtocol, String x11AuthenticationCookie, int x11ScreenNumber)
/*      */     throws IOException
/*      */   {
/*      */     PacketSessionX11Request psr;
/*  611 */     synchronized (c)
/*      */     {
/*  613 */       if (c.state != 2) {
/*  614 */         throw new IOException("Cannot request X11 on this channel (" + c.getReasonClosed() + ")");
/*      */       }
/*  616 */       psr = new PacketSessionX11Request(c.remoteID, true, singleConnection, x11AuthenticationProtocol, 
/*  617 */         x11AuthenticationCookie, x11ScreenNumber);
/*      */ 
/*  619 */       c.successCounter = (c.failedCounter = 0);
/*      */     }
/*      */ 
/*  622 */     synchronized (c.channelSendLock)
/*      */     {
/*  624 */       if (c.closeMessageSent)
/*  625 */         throw new IOException("Cannot request X11 on this channel (" + c.getReasonClosed() + ")");
/*  626 */       this.tm.sendMessage(psr.getPayload());
/*      */     }
/*      */ 
/*  629 */     if (log.isEnabled()) {
/*  630 */       log.log(50, "Requesting X11 forwarding (Channel " + c.localID + "/" + c.remoteID + ")");
/*      */     }
/*      */     try
/*      */     {
/*  634 */       waitForChannelSuccessOrFailure(c);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  638 */       throw ((IOException)new IOException("The X11 request failed.").initCause(e));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void requestSubSystem(Channel c, String subSystemName)
/*      */     throws IOException
/*      */   {
/*      */     PacketSessionSubsystemRequest ssr;
/*  646 */     synchronized (c)
/*      */     {
/*  648 */       if (c.state != 2) {
/*  649 */         throw new IOException("Cannot request subsystem on this channel (" + c.getReasonClosed() + ")");
/*      */       }
/*  651 */       ssr = new PacketSessionSubsystemRequest(c.remoteID, true, subSystemName);
/*      */ 
/*  653 */       c.successCounter = (c.failedCounter = 0);
/*      */     }
/*      */ 
/*  656 */     synchronized (c.channelSendLock)
/*      */     {
/*  658 */       if (c.closeMessageSent)
/*  659 */         throw new IOException("Cannot request subsystem on this channel (" + c.getReasonClosed() + ")");
/*  660 */       this.tm.sendMessage(ssr.getPayload());
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  665 */       waitForChannelSuccessOrFailure(c);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  669 */       throw ((IOException)new IOException("The subsystem request failed.").initCause(e));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void requestExecCommand(Channel c, String cmd)
/*      */     throws IOException
/*      */   {
/*      */     PacketSessionExecCommand sm;
/*  677 */     synchronized (c)
/*      */     {
/*  679 */       if (c.state != 2) {
/*  680 */         throw new IOException("Cannot execute command on this channel (" + c.getReasonClosed() + ")");
/*      */       }
/*  682 */       sm = new PacketSessionExecCommand(c.remoteID, true, cmd);
/*      */ 
/*  684 */       c.successCounter = (c.failedCounter = 0);
/*      */     }
/*      */ 
/*  687 */     synchronized (c.channelSendLock)
/*      */     {
/*  689 */       if (c.closeMessageSent)
/*  690 */         throw new IOException("Cannot execute command on this channel (" + c.getReasonClosed() + ")");
/*  691 */       this.tm.sendMessage(sm.getPayload());
/*      */     }
/*      */ 
/*  694 */     if (log.isEnabled()) {
/*  695 */       log.log(50, "Executing command (channel " + c.localID + ", '" + cmd + "')");
/*      */     }
/*      */     try
/*      */     {
/*  699 */       waitForChannelSuccessOrFailure(c);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  703 */       throw ((IOException)new IOException("The execute request failed.").initCause(e));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void requestShell(Channel c)
/*      */     throws IOException
/*      */   {
/*      */     PacketSessionStartShell sm;
/*  711 */     synchronized (c)
/*      */     {
/*  713 */       if (c.state != 2) {
/*  714 */         throw new IOException("Cannot start shell on this channel (" + c.getReasonClosed() + ")");
/*      */       }
/*  716 */       sm = new PacketSessionStartShell(c.remoteID, true);
/*      */ 
/*  718 */       c.successCounter = (c.failedCounter = 0);
/*      */     }
/*      */ 
/*  721 */     synchronized (c.channelSendLock)
/*      */     {
/*  723 */       if (c.closeMessageSent)
/*  724 */         throw new IOException("Cannot start shell on this channel (" + c.getReasonClosed() + ")");
/*  725 */       this.tm.sendMessage(sm.getPayload());
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  730 */       waitForChannelSuccessOrFailure(c);
/*      */     }
/*      */     catch (IOException e)
/*      */     {
/*  734 */       throw ((IOException)new IOException("The shell request failed.").initCause(e));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void msgChannelExtendedData(byte[] msg, int msglen) throws IOException
/*      */   {
/*  740 */     if (msglen <= 13) {
/*  741 */       throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong size (" + msglen + ")");
/*      */     }
/*  743 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/*  744 */     int dataType = (msg[5] & 0xFF) << 24 | (msg[6] & 0xFF) << 16 | (msg[7] & 0xFF) << 8 | msg[8] & 0xFF;
/*  745 */     int len = (msg[9] & 0xFF) << 24 | (msg[10] & 0xFF) << 16 | (msg[11] & 0xFF) << 8 | msg[12] & 0xFF;
/*      */ 
/*  747 */     Channel c = getChannel(id);
/*      */ 
/*  749 */     if (c == null) {
/*  750 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_EXTENDED_DATA message for non-existent channel " + id);
/*      */     }
/*  752 */     if (dataType != 1) {
/*  753 */       throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has unknown type (" + dataType + ")");
/*      */     }
/*  755 */     if (len != msglen - 13) {
/*  756 */       throw new IOException("SSH_MSG_CHANNEL_EXTENDED_DATA message has wrong len (calculated " + (msglen - 13) + 
/*  757 */         ", got " + len + ")");
/*      */     }
/*  759 */     if (log.isEnabled()) {
/*  760 */       log.log(80, "Got SSH_MSG_CHANNEL_EXTENDED_DATA (channel " + id + ", " + len + ")");
/*      */     }
/*  762 */     synchronized (c)
/*      */     {
/*  764 */       if (c.state == 4) {
/*  765 */         return;
/*      */       }
/*  767 */       if (c.state != 2) {
/*  768 */         throw new IOException("Got SSH_MSG_CHANNEL_EXTENDED_DATA, but channel is not in correct state (" + 
/*  769 */           c.state + ")");
/*      */       }
/*  771 */       if (c.localWindow < len) {
/*  772 */         throw new IOException("Remote sent too much data, does not fit into window.");
/*      */       }
/*  774 */       c.localWindow -= len;
/*      */ 
/*  776 */       System.arraycopy(msg, 13, c.stderrBuffer, c.stderrWritepos, len);
/*  777 */       c.stderrWritepos += len;
/*      */ 
/*  779 */       c.notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public int waitForCondition(Channel c, long timeout, int condition_mask)
/*      */   {
/*  797 */     long end_time = 0L;
/*  798 */     boolean end_time_set = false;
/*      */ 
/*  800 */     synchronized (c)
/*      */     {
/*      */       while (true)
/*      */       {
/*  804 */         int current_cond = 0;
/*      */ 
/*  806 */         int stdoutAvail = c.stdoutWritepos - c.stdoutReadpos;
/*  807 */         int stderrAvail = c.stderrWritepos - c.stderrReadpos;
/*      */ 
/*  809 */         if (stdoutAvail > 0) {
/*  810 */           current_cond |= 4;
/*      */         }
/*  812 */         if (stderrAvail > 0) {
/*  813 */           current_cond |= 8;
/*      */         }
/*  815 */         if (c.EOF) {
/*  816 */           current_cond |= 16;
/*      */         }
/*  818 */         if (c.getExitStatus() != null) {
/*  819 */           current_cond |= 32;
/*      */         }
/*  821 */         if (c.getExitSignal() != null) {
/*  822 */           current_cond |= 64;
/*      */         }
/*  824 */         if (c.state == 4) {
/*  825 */           return current_cond | 0x2 | 0x10;
/*      */         }
/*  827 */         if ((current_cond & condition_mask) != 0) {
/*  828 */           return current_cond;
/*      */         }
/*  830 */         if (timeout > 0L)
/*      */         {
/*  832 */           if (!end_time_set)
/*      */           {
/*  834 */             end_time = System.currentTimeMillis() + timeout;
/*  835 */             end_time_set = true;
/*      */           }
/*      */           else
/*      */           {
/*  839 */             timeout = end_time - System.currentTimeMillis();
/*      */ 
/*  841 */             if (timeout <= 0L) {
/*  842 */               return current_cond | 0x1;
/*      */             }
/*      */           }
/*      */         }
/*      */         try
/*      */         {
/*  848 */           if (timeout > 0L) {
/*  849 */             c.wait(timeout); continue;
/*      */           }
/*  851 */           c.wait();
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getAvailable(Channel c, boolean extended) throws IOException
/*      */   {
/*  862 */     synchronized (c)
/*      */     {
/*      */       int avail;
/*      */       int avail;
/*  866 */       if (extended)
/*  867 */         avail = c.stderrWritepos - c.stderrReadpos;
/*      */       else {
/*  869 */         avail = c.stdoutWritepos - c.stdoutReadpos;
/*      */       }
/*  871 */       return c.EOF ? -1 : avail > 0 ? avail : 0;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getChannelData(Channel c, boolean extended, byte[] target, int off, int len) throws IOException
/*      */   {
/*  877 */     int copylen = 0;
/*  878 */     int increment = 0;
/*  879 */     int remoteID = 0;
/*  880 */     int localID = 0;
/*      */ 
/*  882 */     synchronized (c)
/*      */     {
/*  884 */       int stdoutAvail = 0;
/*  885 */       int stderrAvail = 0;
/*      */       while (true)
/*      */       {
/*  894 */         stdoutAvail = c.stdoutWritepos - c.stdoutReadpos;
/*  895 */         stderrAvail = c.stderrWritepos - c.stderrReadpos;
/*      */ 
/*  897 */         if ((!extended) && (stdoutAvail != 0)) {
/*      */           break;
/*      */         }
/*  900 */         if ((extended) && (stderrAvail != 0))
/*      */         {
/*      */           break;
/*      */         }
/*      */ 
/*  905 */         if ((c.EOF) || (c.state != 2)) {
/*  906 */           return -1;
/*      */         }
/*      */         try
/*      */         {
/*  910 */           c.wait();
/*      */         }
/*      */         catch (InterruptedException localInterruptedException)
/*      */         {
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  919 */       if (!extended)
/*      */       {
/*  921 */         copylen = stdoutAvail > len ? len : stdoutAvail;
/*  922 */         System.arraycopy(c.stdoutBuffer, c.stdoutReadpos, target, off, copylen);
/*  923 */         c.stdoutReadpos += copylen;
/*      */ 
/*  925 */         if (c.stdoutReadpos != c.stdoutWritepos)
/*      */         {
/*  927 */           System.arraycopy(c.stdoutBuffer, c.stdoutReadpos, c.stdoutBuffer, 0, c.stdoutWritepos - 
/*  928 */             c.stdoutReadpos);
/*      */         }
/*  930 */         c.stdoutWritepos -= c.stdoutReadpos;
/*  931 */         c.stdoutReadpos = 0;
/*      */       }
/*      */       else
/*      */       {
/*  935 */         copylen = stderrAvail > len ? len : stderrAvail;
/*  936 */         System.arraycopy(c.stderrBuffer, c.stderrReadpos, target, off, copylen);
/*  937 */         c.stderrReadpos += copylen;
/*      */ 
/*  939 */         if (c.stderrReadpos != c.stderrWritepos)
/*      */         {
/*  941 */           System.arraycopy(c.stderrBuffer, c.stderrReadpos, c.stderrBuffer, 0, c.stderrWritepos - 
/*  942 */             c.stderrReadpos);
/*      */         }
/*  944 */         c.stderrWritepos -= c.stderrReadpos;
/*  945 */         c.stderrReadpos = 0;
/*      */       }
/*      */ 
/*  948 */       if (c.state != 2) {
/*  949 */         return copylen;
/*      */       }
/*  951 */       if (c.localWindow < 15000)
/*      */       {
/*  953 */         int minFreeSpace = Math.min(30000 - c.stdoutWritepos, 30000 - 
/*  954 */           c.stderrWritepos);
/*      */ 
/*  956 */         increment = minFreeSpace - c.localWindow;
/*  957 */         c.localWindow = minFreeSpace;
/*      */       }
/*      */ 
/*  960 */       remoteID = c.remoteID;
/*  961 */       localID = c.localID;
/*      */     }
/*      */ 
/*  970 */     if (increment > 0)
/*      */     {
/*  972 */       if (log.isEnabled()) {
/*  973 */         log.log(80, "Sending SSH_MSG_CHANNEL_WINDOW_ADJUST (channel " + localID + ", " + increment + ")");
/*      */       }
/*  975 */       synchronized (c.channelSendLock)
/*      */       {
/*  977 */         byte[] msg = c.msgWindowAdjust;
/*      */ 
/*  979 */         msg[0] = 93;
/*  980 */         msg[1] = (byte)(remoteID >> 24);
/*  981 */         msg[2] = (byte)(remoteID >> 16);
/*  982 */         msg[3] = (byte)(remoteID >> 8);
/*  983 */         msg[4] = (byte)remoteID;
/*  984 */         msg[5] = (byte)(increment >> 24);
/*  985 */         msg[6] = (byte)(increment >> 16);
/*  986 */         msg[7] = (byte)(increment >> 8);
/*  987 */         msg[8] = (byte)increment;
/*      */ 
/*  989 */         if (!c.closeMessageSent) {
/*  990 */           this.tm.sendMessage(msg);
/*      */         }
/*      */       }
/*      */     }
/*  994 */     return copylen;
/*      */   }
/*      */ 
/*      */   public void msgChannelData(byte[] msg, int msglen) throws IOException
/*      */   {
/*  999 */     if (msglen <= 9) {
/* 1000 */       throw new IOException("SSH_MSG_CHANNEL_DATA message has wrong size (" + msglen + ")");
/*      */     }
/* 1002 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/* 1003 */     int len = (msg[5] & 0xFF) << 24 | (msg[6] & 0xFF) << 16 | (msg[7] & 0xFF) << 8 | msg[8] & 0xFF;
/*      */ 
/* 1005 */     Channel c = getChannel(id);
/*      */ 
/* 1007 */     if (c == null) {
/* 1008 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_DATA message for non-existent channel " + id);
/*      */     }
/* 1010 */     if (len != msglen - 9) {
/* 1011 */       throw new IOException("SSH_MSG_CHANNEL_DATA message has wrong len (calculated " + (msglen - 9) + ", got " + 
/* 1012 */         len + ")");
/*      */     }
/* 1014 */     if (log.isEnabled()) {
/* 1015 */       log.log(80, "Got SSH_MSG_CHANNEL_DATA (channel " + id + ", " + len + ")");
/*      */     }
/* 1017 */     synchronized (c)
/*      */     {
/* 1019 */       if (c.state == 4) {
/* 1020 */         return;
/*      */       }
/* 1022 */       if (c.state != 2) {
/* 1023 */         throw new IOException("Got SSH_MSG_CHANNEL_DATA, but channel is not in correct state (" + c.state + ")");
/*      */       }
/* 1025 */       if (c.localWindow < len) {
/* 1026 */         throw new IOException("Remote sent too much data, does not fit into window.");
/*      */       }
/* 1028 */       c.localWindow -= len;
/*      */ 
/* 1030 */       System.arraycopy(msg, 9, c.stdoutBuffer, c.stdoutWritepos, len);
/* 1031 */       c.stdoutWritepos += len;
/*      */ 
/* 1033 */       c.notifyAll();
/*      */     }
/*      */   }
/*      */ 
/*      */   public void msgChannelWindowAdjust(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1039 */     if (msglen != 9) {
/* 1040 */       throw new IOException("SSH_MSG_CHANNEL_WINDOW_ADJUST message has wrong size (" + msglen + ")");
/*      */     }
/* 1042 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/* 1043 */     int windowChange = (msg[5] & 0xFF) << 24 | (msg[6] & 0xFF) << 16 | (msg[7] & 0xFF) << 8 | msg[8] & 0xFF;
/*      */ 
/* 1045 */     Channel c = getChannel(id);
/*      */ 
/* 1047 */     if (c == null) {
/* 1048 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_WINDOW_ADJUST message for non-existent channel " + id);
/*      */     }
/* 1050 */     synchronized (c)
/*      */     {
/* 1052 */       long huge = 4294967295L;
/*      */ 
/* 1054 */       c.remoteWindow += (windowChange & 0xFFFFFFFF);
/*      */ 
/* 1058 */       if (c.remoteWindow > 4294967295L) {
/* 1059 */         c.remoteWindow = 4294967295L;
/*      */       }
/* 1061 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1064 */     if (log.isEnabled())
/* 1065 */       log.log(80, "Got SSH_MSG_CHANNEL_WINDOW_ADJUST (channel " + id + ", " + windowChange + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelOpen(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1070 */     TypesReader tr = new TypesReader(msg, 0, msglen);
/*      */ 
/* 1072 */     tr.readByte();
/* 1073 */     String channelType = tr.readString();
/* 1074 */     int remoteID = tr.readUINT32();
/* 1075 */     int remoteWindow = tr.readUINT32();
/* 1076 */     int remoteMaxPacketSize = tr.readUINT32();
/*      */ 
/* 1078 */     if ("x11".equals(channelType))
/*      */     {
/* 1080 */       synchronized (this.x11_magic_cookies)
/*      */       {
/* 1084 */         if (this.x11_magic_cookies.size() == 0)
/*      */         {
/* 1086 */           PacketChannelOpenFailure pcof = new PacketChannelOpenFailure(remoteID, 
/* 1087 */             1, "X11 forwarding not activated", "");
/*      */ 
/* 1089 */           this.tm.sendAsynchronousMessage(pcof.getPayload());
/*      */ 
/* 1091 */           if (log.isEnabled()) {
/* 1092 */             log.log(20, "Unexpected X11 request, denying it!");
/*      */           }
/* 1094 */           return;
/*      */         }
/*      */       }
/*      */ 
/* 1098 */       String remoteOriginatorAddress = tr.readString();
/* 1099 */       int remoteOriginatorPort = tr.readUINT32();
/*      */ 
/* 1101 */       Channel c = new Channel(this);
/*      */ 
/* 1103 */       synchronized (c)
/*      */       {
/* 1105 */         c.remoteID = remoteID;
/* 1106 */         c.remoteWindow = (remoteWindow & 0xFFFFFFFF);
/* 1107 */         c.remoteMaxPacketSize = remoteMaxPacketSize;
/* 1108 */         c.localID = addChannel(c);
/*      */       }
/*      */ 
/* 1115 */       RemoteX11AcceptThread rxat = new RemoteX11AcceptThread(c, remoteOriginatorAddress, remoteOriginatorPort);
/* 1116 */       rxat.setDaemon(true);
/* 1117 */       rxat.start();
/*      */ 
/* 1119 */       return;
/*      */     }
/*      */ 
/* 1122 */     if ("forwarded-tcpip".equals(channelType))
/*      */     {
/* 1124 */       String remoteConnectedAddress = tr.readString();
/* 1125 */       int remoteConnectedPort = tr.readUINT32();
/* 1126 */       String remoteOriginatorAddress = tr.readString();
/* 1127 */       int remoteOriginatorPort = tr.readUINT32();
/*      */ 
/* 1129 */       RemoteForwardingData rfd = null;
/*      */ 
/* 1131 */       synchronized (this.remoteForwardings)
/*      */       {
/* 1133 */         rfd = (RemoteForwardingData)this.remoteForwardings.get(new Integer(remoteConnectedPort));
/*      */       }
/*      */ 
/* 1136 */       if (rfd == null)
/*      */       {
/* 1138 */         PacketChannelOpenFailure pcof = new PacketChannelOpenFailure(remoteID, 
/* 1139 */           1, 
/* 1140 */           "No thanks, unknown port in forwarded-tcpip request", "");
/*      */ 
/* 1144 */         this.tm.sendAsynchronousMessage(pcof.getPayload());
/*      */ 
/* 1146 */         if (log.isEnabled()) {
/* 1147 */           log.log(20, "Unexpected forwarded-tcpip request, denying it!");
/*      */         }
/* 1149 */         return;
/*      */       }
/*      */ 
/* 1152 */       Channel c = new Channel(this);
/*      */ 
/* 1154 */       synchronized (c)
/*      */       {
/* 1156 */         c.remoteID = remoteID;
/* 1157 */         c.remoteWindow = (remoteWindow & 0xFFFFFFFF);
/* 1158 */         c.remoteMaxPacketSize = remoteMaxPacketSize;
/* 1159 */         c.localID = addChannel(c);
/*      */       }
/*      */ 
/* 1166 */       RemoteAcceptThread rat = new RemoteAcceptThread(c, remoteConnectedAddress, remoteConnectedPort, 
/* 1167 */         remoteOriginatorAddress, remoteOriginatorPort, rfd.targetAddress, rfd.targetPort);
/*      */ 
/* 1169 */       rat.setDaemon(true);
/* 1170 */       rat.start();
/*      */ 
/* 1172 */       return;
/*      */     }
/*      */ 
/* 1177 */     PacketChannelOpenFailure pcof = new PacketChannelOpenFailure(remoteID, 3, 
/* 1178 */       "Unknown channel type", "");
/*      */ 
/* 1180 */     this.tm.sendAsynchronousMessage(pcof.getPayload());
/*      */ 
/* 1182 */     if (log.isEnabled())
/* 1183 */       log.log(20, "The peer tried to open an unsupported channel type (" + channelType + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelRequest(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1188 */     TypesReader tr = new TypesReader(msg, 0, msglen);
/*      */ 
/* 1190 */     tr.readByte();
/* 1191 */     int id = tr.readUINT32();
/*      */ 
/* 1193 */     Channel c = getChannel(id);
/*      */ 
/* 1195 */     if (c == null) {
/* 1196 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_REQUEST message for non-existent channel " + id);
/*      */     }
/* 1198 */     String type = tr.readString("US-ASCII");
/* 1199 */     boolean wantReply = tr.readBoolean();
/*      */ 
/* 1201 */     if (log.isEnabled()) {
/* 1202 */       log.log(80, "Got SSH_MSG_CHANNEL_REQUEST (channel " + id + ", '" + type + "')");
/*      */     }
/* 1204 */     if (type.equals("exit-status"))
/*      */     {
/* 1206 */       if (wantReply) {
/* 1207 */         throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message, 'want reply' is true");
/*      */       }
/* 1209 */       int exit_status = tr.readUINT32();
/*      */ 
/* 1211 */       if (tr.remain() != 0) {
/* 1212 */         throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");
/*      */       }
/* 1214 */       synchronized (c)
/*      */       {
/* 1216 */         c.exit_status = new Integer(exit_status);
/* 1217 */         c.notifyAll();
/*      */       }
/*      */ 
/* 1220 */       if (log.isEnabled()) {
/* 1221 */         log.log(50, "Got EXIT STATUS (channel " + id + ", status " + exit_status + ")");
/*      */       }
/* 1223 */       return;
/*      */     }
/*      */ 
/* 1226 */     if (type.equals("exit-signal"))
/*      */     {
/* 1228 */       if (wantReply) {
/* 1229 */         throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message, 'want reply' is true");
/*      */       }
/* 1231 */       String signame = tr.readString("US-ASCII");
/* 1232 */       tr.readBoolean();
/* 1233 */       tr.readString();
/* 1234 */       tr.readString();
/*      */ 
/* 1236 */       if (tr.remain() != 0) {
/* 1237 */         throw new IOException("Badly formatted SSH_MSG_CHANNEL_REQUEST message");
/*      */       }
/* 1239 */       synchronized (c)
/*      */       {
/* 1241 */         c.exit_signal = signame;
/* 1242 */         c.notifyAll();
/*      */       }
/*      */ 
/* 1245 */       if (log.isEnabled()) {
/* 1246 */         log.log(50, "Got EXIT SIGNAL (channel " + id + ", signal " + signame + ")");
/*      */       }
/* 1248 */       return;
/*      */     }
/*      */ 
/* 1255 */     if (wantReply)
/*      */     {
/* 1257 */       byte[] reply = new byte[5];
/*      */ 
/* 1259 */       reply[0] = 100;
/* 1260 */       reply[1] = (byte)(c.remoteID >> 24);
/* 1261 */       reply[2] = (byte)(c.remoteID >> 16);
/* 1262 */       reply[3] = (byte)(c.remoteID >> 8);
/* 1263 */       reply[4] = (byte)c.remoteID;
/*      */ 
/* 1265 */       this.tm.sendAsynchronousMessage(reply);
/*      */     }
/*      */ 
/* 1268 */     if (log.isEnabled())
/* 1269 */       log.log(50, "Channel request '" + type + "' is not known, ignoring it");
/*      */   }
/*      */ 
/*      */   public void msgChannelEOF(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1274 */     if (msglen != 5) {
/* 1275 */       throw new IOException("SSH_MSG_CHANNEL_EOF message has wrong size (" + msglen + ")");
/*      */     }
/* 1277 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/*      */ 
/* 1279 */     Channel c = getChannel(id);
/*      */ 
/* 1281 */     if (c == null) {
/* 1282 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_EOF message for non-existent channel " + id);
/*      */     }
/* 1284 */     synchronized (c)
/*      */     {
/* 1286 */       c.EOF = true;
/* 1287 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1290 */     if (log.isEnabled())
/* 1291 */       log.log(50, "Got SSH_MSG_CHANNEL_EOF (channel " + id + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelClose(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1296 */     if (msglen != 5) {
/* 1297 */       throw new IOException("SSH_MSG_CHANNEL_CLOSE message has wrong size (" + msglen + ")");
/*      */     }
/* 1299 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/*      */ 
/* 1301 */     Channel c = getChannel(id);
/*      */ 
/* 1303 */     if (c == null) {
/* 1304 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_CLOSE message for non-existent channel " + id);
/*      */     }
/* 1306 */     synchronized (c)
/*      */     {
/* 1308 */       c.EOF = true;
/* 1309 */       c.state = 4;
/* 1310 */       c.setReasonClosed("Close requested by remote");
/* 1311 */       c.closeMessageRecv = true;
/*      */ 
/* 1313 */       removeChannel(c.localID);
/*      */ 
/* 1315 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1318 */     if (log.isEnabled())
/* 1319 */       log.log(50, "Got SSH_MSG_CHANNEL_CLOSE (channel " + id + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelSuccess(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1324 */     if (msglen != 5) {
/* 1325 */       throw new IOException("SSH_MSG_CHANNEL_SUCCESS message has wrong size (" + msglen + ")");
/*      */     }
/* 1327 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/*      */ 
/* 1329 */     Channel c = getChannel(id);
/*      */ 
/* 1331 */     if (c == null) {
/* 1332 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_SUCCESS message for non-existent channel " + id);
/*      */     }
/* 1334 */     synchronized (c)
/*      */     {
/* 1336 */       c.successCounter += 1;
/* 1337 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1340 */     if (log.isEnabled())
/* 1341 */       log.log(80, "Got SSH_MSG_CHANNEL_SUCCESS (channel " + id + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelFailure(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1346 */     if (msglen != 5) {
/* 1347 */       throw new IOException("SSH_MSG_CHANNEL_FAILURE message has wrong size (" + msglen + ")");
/*      */     }
/* 1349 */     int id = (msg[1] & 0xFF) << 24 | (msg[2] & 0xFF) << 16 | (msg[3] & 0xFF) << 8 | msg[4] & 0xFF;
/*      */ 
/* 1351 */     Channel c = getChannel(id);
/*      */ 
/* 1353 */     if (c == null) {
/* 1354 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_FAILURE message for non-existent channel " + id);
/*      */     }
/* 1356 */     synchronized (c)
/*      */     {
/* 1358 */       c.failedCounter += 1;
/* 1359 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1362 */     if (log.isEnabled())
/* 1363 */       log.log(50, "Got SSH_MSG_CHANNEL_FAILURE (channel " + id + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelOpenConfirmation(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1368 */     PacketChannelOpenConfirmation sm = new PacketChannelOpenConfirmation(msg, 0, msglen);
/*      */ 
/* 1370 */     Channel c = getChannel(sm.recipientChannelID);
/*      */ 
/* 1372 */     if (c == null) {
/* 1373 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for non-existent channel " + 
/* 1374 */         sm.recipientChannelID);
/*      */     }
/* 1376 */     synchronized (c)
/*      */     {
/* 1378 */       if (c.state != 1) {
/* 1379 */         throw new IOException("Unexpected SSH_MSG_CHANNEL_OPEN_CONFIRMATION message for channel " + 
/* 1380 */           sm.recipientChannelID);
/*      */       }
/* 1382 */       c.remoteID = sm.senderChannelID;
/* 1383 */       c.remoteWindow = (sm.initialWindowSize & 0xFFFFFFFF);
/* 1384 */       c.remoteMaxPacketSize = sm.maxPacketSize;
/* 1385 */       c.state = 2;
/* 1386 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1389 */     if (log.isEnabled())
/* 1390 */       log.log(50, "Got SSH_MSG_CHANNEL_OPEN_CONFIRMATION (channel " + sm.recipientChannelID + " / remote: " + 
/* 1391 */         sm.senderChannelID + ")");
/*      */   }
/*      */ 
/*      */   public void msgChannelOpenFailure(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1396 */     if (msglen < 5) {
/* 1397 */       throw new IOException("SSH_MSG_CHANNEL_OPEN_FAILURE message has wrong size (" + msglen + ")");
/*      */     }
/* 1399 */     TypesReader tr = new TypesReader(msg, 0, msglen);
/*      */ 
/* 1401 */     tr.readByte();
/* 1402 */     int id = tr.readUINT32();
/*      */ 
/* 1404 */     Channel c = getChannel(id);
/*      */ 
/* 1406 */     if (c == null) {
/* 1407 */       throw new IOException("Unexpected SSH_MSG_CHANNEL_OPEN_FAILURE message for non-existent channel " + id);
/*      */     }
/* 1409 */     int reasonCode = tr.readUINT32();
/* 1410 */     String description = tr.readString("UTF-8");
/*      */ 
/* 1412 */     String reasonCodeSymbolicName = null;
/*      */ 
/* 1414 */     switch (reasonCode)
/*      */     {
/*      */     case 1:
/* 1417 */       reasonCodeSymbolicName = "SSH_OPEN_ADMINISTRATIVELY_PROHIBITED";
/* 1418 */       break;
/*      */     case 2:
/* 1420 */       reasonCodeSymbolicName = "SSH_OPEN_CONNECT_FAILED";
/* 1421 */       break;
/*      */     case 3:
/* 1423 */       reasonCodeSymbolicName = "SSH_OPEN_UNKNOWN_CHANNEL_TYPE";
/* 1424 */       break;
/*      */     case 4:
/* 1426 */       reasonCodeSymbolicName = "SSH_OPEN_RESOURCE_SHORTAGE";
/* 1427 */       break;
/*      */     default:
/* 1429 */       reasonCodeSymbolicName = "UNKNOWN REASON CODE (" + reasonCode + ")";
/*      */     }
/*      */ 
/* 1432 */     StringBuffer descriptionBuffer = new StringBuffer();
/* 1433 */     descriptionBuffer.append(description);
/*      */ 
/* 1435 */     for (int i = 0; i < descriptionBuffer.length(); i++)
/*      */     {
/* 1437 */       char cc = descriptionBuffer.charAt(i);
/*      */ 
/* 1439 */       if ((cc >= ' ') && (cc <= '~'))
/*      */         continue;
/* 1441 */       descriptionBuffer.setCharAt(i, 65533);
/*      */     }
/*      */ 
/* 1444 */     synchronized (c)
/*      */     {
/* 1446 */       c.EOF = true;
/* 1447 */       c.state = 4;
/* 1448 */       c.setReasonClosed("The server refused to open the channel (" + reasonCodeSymbolicName + ", '" + 
/* 1449 */         descriptionBuffer.toString() + "')");
/* 1450 */       c.notifyAll();
/*      */     }
/*      */ 
/* 1453 */     if (log.isEnabled())
/* 1454 */       log.log(50, "Got SSH_MSG_CHANNEL_OPEN_FAILURE (channel " + id + ")");
/*      */   }
/*      */ 
/*      */   public void msgGlobalRequest(byte[] msg, int msglen)
/*      */     throws IOException
/*      */   {
/* 1461 */     TypesReader tr = new TypesReader(msg, 0, msglen);
/*      */ 
/* 1463 */     tr.readByte();
/* 1464 */     String requestName = tr.readString();
/* 1465 */     boolean wantReply = tr.readBoolean();
/*      */ 
/* 1467 */     if (wantReply)
/*      */     {
/* 1469 */       byte[] reply_failure = new byte[1];
/* 1470 */       reply_failure[0] = 82;
/*      */ 
/* 1472 */       this.tm.sendAsynchronousMessage(reply_failure);
/*      */     }
/*      */ 
/* 1477 */     if (log.isEnabled())
/* 1478 */       log.log(80, "Got SSH_MSG_GLOBAL_REQUEST (" + requestName + ")");
/*      */   }
/*      */ 
/*      */   public void msgGlobalSuccess() throws IOException
/*      */   {
/* 1483 */     synchronized (this.channels)
/*      */     {
/* 1485 */       this.globalSuccessCounter += 1;
/* 1486 */       this.channels.notifyAll();
/*      */     }
/*      */ 
/* 1489 */     if (log.isEnabled())
/* 1490 */       log.log(80, "Got SSH_MSG_REQUEST_SUCCESS");
/*      */   }
/*      */ 
/*      */   public void msgGlobalFailure() throws IOException
/*      */   {
/* 1495 */     synchronized (this.channels)
/*      */     {
/* 1497 */       this.globalFailedCounter += 1;
/* 1498 */       this.channels.notifyAll();
/*      */     }
/*      */ 
/* 1501 */     if (log.isEnabled())
/* 1502 */       log.log(80, "Got SSH_MSG_REQUEST_FAILURE");
/*      */   }
/*      */ 
/*      */   public void handleMessage(byte[] msg, int msglen) throws IOException
/*      */   {
/* 1507 */     if (msg == null)
/*      */     {
/* 1509 */       if (log.isEnabled()) {
/* 1510 */         log.log(50, "HandleMessage: got shutdown");
/*      */       }
/* 1512 */       synchronized (this.listenerThreads)
/*      */       {
/* 1514 */         for (int i = 0; i < this.listenerThreads.size(); i++)
/*      */         {
/* 1516 */           IChannelWorkerThread lat = (IChannelWorkerThread)this.listenerThreads.elementAt(i);
/* 1517 */           lat.stopWorking();
/*      */         }
/* 1519 */         this.listenerThreadsAllowed = false;
/*      */       }
/*      */ 
/* 1522 */       synchronized (this.channels)
/*      */       {
/* 1524 */         this.shutdown = true;
/*      */ 
/* 1526 */         for (int i = 0; i < this.channels.size(); i++)
/*      */         {
/* 1528 */           Channel c = (Channel)this.channels.elementAt(i);
/* 1529 */           synchronized (c)
/*      */           {
/* 1531 */             c.EOF = true;
/* 1532 */             c.state = 4;
/* 1533 */             c.setReasonClosed("The connection is being shutdown");
/* 1534 */             c.closeMessageRecv = true;
/*      */ 
/* 1540 */             c.notifyAll();
/*      */           }
/*      */         }
/*      */ 
/* 1544 */         this.channels.setSize(0);
/* 1545 */         this.channels.trimToSize();
/* 1546 */         this.channels.notifyAll();
/* 1547 */         return;
/*      */       }
/*      */     }
/*      */ 
/* 1551 */     switch (msg[0])
/*      */     {
/*      */     case 91:
/* 1554 */       msgChannelOpenConfirmation(msg, msglen);
/* 1555 */       break;
/*      */     case 93:
/* 1557 */       msgChannelWindowAdjust(msg, msglen);
/* 1558 */       break;
/*      */     case 94:
/* 1560 */       msgChannelData(msg, msglen);
/* 1561 */       break;
/*      */     case 95:
/* 1563 */       msgChannelExtendedData(msg, msglen);
/* 1564 */       break;
/*      */     case 98:
/* 1566 */       msgChannelRequest(msg, msglen);
/* 1567 */       break;
/*      */     case 96:
/* 1569 */       msgChannelEOF(msg, msglen);
/* 1570 */       break;
/*      */     case 90:
/* 1572 */       msgChannelOpen(msg, msglen);
/* 1573 */       break;
/*      */     case 97:
/* 1575 */       msgChannelClose(msg, msglen);
/* 1576 */       break;
/*      */     case 99:
/* 1578 */       msgChannelSuccess(msg, msglen);
/* 1579 */       break;
/*      */     case 100:
/* 1581 */       msgChannelFailure(msg, msglen);
/* 1582 */       break;
/*      */     case 92:
/* 1584 */       msgChannelOpenFailure(msg, msglen);
/* 1585 */       break;
/*      */     case 80:
/* 1587 */       msgGlobalRequest(msg, msglen);
/* 1588 */       break;
/*      */     case 81:
/* 1590 */       msgGlobalSuccess();
/* 1591 */       break;
/*      */     case 82:
/* 1593 */       msgGlobalFailure();
/* 1594 */       break;
/*      */     case 83:
/*      */     case 84:
/*      */     case 85:
/*      */     case 86:
/*      */     case 87:
/*      */     case 88:
/*      */     case 89:
/*      */     default:
/* 1596 */       throw new IOException("Cannot handle unknown channel message " + (msg[0] & 0xFF));
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.ChannelManager
 * JD-Core Version:    0.6.0
 */