/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectOutputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.text.DateFormat;
/*      */ import java.text.ParsePosition;
/*      */ import java.text.SimpleDateFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ 
/*      */ public class PreparedStatement extends Statement
/*      */   implements java.sql.PreparedStatement
/*      */ {
/*  305 */   private static final byte[] HEX_DIGITS = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
/*      */ 
/*  349 */   protected boolean batchHasPlainStatements = false;
/*      */ 
/*  351 */   private DatabaseMetaData dbmd = null;
/*      */ 
/*  357 */   protected char firstCharOfStmt = '\000';
/*      */ 
/*  360 */   protected boolean hasLimitClause = false;
/*      */ 
/*  363 */   protected boolean isLoadDataQuery = false;
/*      */ 
/*  365 */   private boolean[] isNull = null;
/*      */ 
/*  367 */   private boolean[] isStream = null;
/*      */ 
/*  369 */   protected int numberOfExecutions = 0;
/*      */ 
/*  372 */   protected String originalSql = null;
/*      */   protected int parameterCount;
/*      */   protected MysqlParameterMetadata parameterMetaData;
/*  379 */   private InputStream[] parameterStreams = null;
/*      */ 
/*  381 */   private byte[][] parameterValues = (byte[][])null;
/*      */   private PreparedStatement.ParseInfo parseInfo;
/*      */   private java.sql.ResultSetMetaData pstmtResultMetaData;
/*  387 */   private byte[][] staticSqlStrings = (byte[][])null;
/*      */ 
/*  389 */   private byte[] streamConvertBuf = new byte[4096];
/*      */ 
/*  391 */   private int[] streamLengths = null;
/*      */ 
/*  393 */   private SimpleDateFormat tsdf = null;
/*      */ 
/*  398 */   protected boolean useTrueBoolean = false;
/*      */   private boolean usingAnsiMode;
/*      */   private String batchedValuesClause;
/*      */ 
/*      */   private static int readFully(Reader reader, char[] buf, int length)
/*      */     throws IOException
/*      */   {
/*  328 */     int numCharsRead = 0;
/*      */ 
/*  330 */     while (numCharsRead < length) {
/*  331 */       int count = reader.read(buf, numCharsRead, length - numCharsRead);
/*      */ 
/*  333 */       if (count < 0)
/*      */       {
/*      */         break;
/*      */       }
/*  337 */       numCharsRead += count;
/*      */     }
/*      */ 
/*  340 */     return numCharsRead;
/*      */   }
/*      */ 
/*      */   protected PreparedStatement(Connection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  417 */     super(conn, catalog);
/*      */   }
/*      */ 
/*      */   public PreparedStatement(Connection conn, String sql, String catalog)
/*      */     throws SQLException
/*      */   {
/*  435 */     super(conn, catalog);
/*      */ 
/*  437 */     if (sql == null) {
/*  438 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.0"), "S1009");
/*      */     }
/*      */ 
/*  442 */     this.originalSql = sql;
/*      */ 
/*  444 */     this.dbmd = this.connection.getMetaData();
/*      */ 
/*  446 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */ 
/*  448 */     this.parseInfo = new PreparedStatement.ParseInfo(this, sql, this.connection, this.dbmd, this.charEncoding, this.charConverter);
/*      */ 
/*  451 */     initializeFromParseInfo();
/*      */   }
/*      */ 
/*      */   public PreparedStatement(Connection conn, String sql, String catalog, PreparedStatement.ParseInfo cachedParseInfo)
/*      */     throws SQLException
/*      */   {
/*  471 */     super(conn, catalog);
/*      */ 
/*  473 */     if (sql == null) {
/*  474 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.1"), "S1009");
/*      */     }
/*      */ 
/*  478 */     this.originalSql = sql;
/*      */ 
/*  480 */     this.dbmd = this.connection.getMetaData();
/*      */ 
/*  482 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*      */ 
/*  484 */     this.parseInfo = cachedParseInfo;
/*      */ 
/*  486 */     this.usingAnsiMode = (!this.connection.useAnsiQuotedIdentifiers());
/*      */ 
/*  488 */     initializeFromParseInfo();
/*      */   }
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  500 */     if (this.batchedArgs == null) {
/*  501 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */ 
/*  504 */     this.batchedArgs.add(new PreparedStatement.BatchParams(this, this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull));
/*      */   }
/*      */ 
/*      */   public synchronized void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  510 */     this.batchHasPlainStatements = true;
/*      */ 
/*  512 */     super.addBatch(sql);
/*      */   }
/*      */ 
/*      */   protected String asSql() throws SQLException {
/*  516 */     return asSql(false);
/*      */   }
/*      */ 
/*      */   protected String asSql(boolean quoteStreamsAndUnknowns) throws SQLException {
/*  520 */     if (this.isClosed) {
/*  521 */       return "statement has been closed, no further internal information available";
/*      */     }
/*      */ 
/*  524 */     StringBuffer buf = new StringBuffer();
/*      */     try
/*      */     {
/*  527 */       for (int i = 0; i < this.parameterCount; i++) {
/*  528 */         if (this.charEncoding != null) {
/*  529 */           buf.append(new String(this.staticSqlStrings[i], this.charEncoding));
/*      */         }
/*      */         else {
/*  532 */           buf.append(new String(this.staticSqlStrings[i]));
/*      */         }
/*      */ 
/*  535 */         if ((this.parameterValues[i] == null) && (this.isStream[i] == 0)) {
/*  536 */           if (quoteStreamsAndUnknowns) {
/*  537 */             buf.append("'");
/*      */           }
/*      */ 
/*  540 */           buf.append("** NOT SPECIFIED **");
/*      */ 
/*  542 */           if (quoteStreamsAndUnknowns)
/*  543 */             buf.append("'");
/*      */         }
/*  545 */         else if (this.isStream[i] != 0) {
/*  546 */           if (quoteStreamsAndUnknowns) {
/*  547 */             buf.append("'");
/*      */           }
/*      */ 
/*  550 */           buf.append("** STREAM DATA **");
/*      */ 
/*  552 */           if (quoteStreamsAndUnknowns) {
/*  553 */             buf.append("'");
/*      */           }
/*      */         }
/*  556 */         else if (this.charConverter != null) {
/*  557 */           buf.append(this.charConverter.toString(this.parameterValues[i]));
/*      */         }
/*  560 */         else if (this.charEncoding != null) {
/*  561 */           buf.append(new String(this.parameterValues[i], this.charEncoding));
/*      */         }
/*      */         else {
/*  564 */           buf.append(StringUtils.toAsciiString(this.parameterValues[i]));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  571 */       if (this.charEncoding != null) {
/*  572 */         buf.append(new String(this.staticSqlStrings[this.parameterCount], this.charEncoding));
/*      */       }
/*      */       else
/*      */       {
/*  576 */         buf.append(StringUtils.toAsciiString(this.staticSqlStrings[this.parameterCount]));
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException uue)
/*      */     {
/*  581 */       throw new RuntimeException(Messages.getString("PreparedStatement.32") + this.charEncoding + Messages.getString("PreparedStatement.33"));
/*      */     }
/*      */ 
/*  587 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   public synchronized void clearBatch() throws SQLException {
/*  591 */     this.batchHasPlainStatements = false;
/*      */ 
/*  593 */     super.clearBatch();
/*      */   }
/*      */ 
/*      */   public synchronized void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  607 */     checkClosed();
/*      */ 
/*  609 */     for (int i = 0; i < this.parameterValues.length; i++) {
/*  610 */       this.parameterValues[i] = null;
/*  611 */       this.parameterStreams[i] = null;
/*  612 */       this.isStream[i] = false;
/*  613 */       this.isNull[i] = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */     throws SQLException
/*      */   {
/*  624 */     realClose(true, true);
/*      */   }
/*      */ 
/*      */   private final void escapeblockFast(byte[] buf, Buffer packet, int size) throws SQLException
/*      */   {
/*  629 */     int lastwritten = 0;
/*      */ 
/*  631 */     for (int i = 0; i < size; i++) {
/*  632 */       byte b = buf[i];
/*      */ 
/*  634 */       if (b == 0)
/*      */       {
/*  636 */         if (i > lastwritten) {
/*  637 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*  641 */         packet.writeByte(92);
/*  642 */         packet.writeByte(48);
/*  643 */         lastwritten = i + 1;
/*      */       } else {
/*  645 */         if ((b != 92) && (b != 39) && ((this.usingAnsiMode) || (b != 34))) {
/*      */           continue;
/*      */         }
/*  648 */         if (i > lastwritten) {
/*  649 */           packet.writeBytesNoNull(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*  654 */         packet.writeByte(92);
/*  655 */         lastwritten = i;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  661 */     if (lastwritten < size)
/*  662 */       packet.writeBytesNoNull(buf, lastwritten, size - lastwritten);
/*      */   }
/*      */ 
/*      */   private final void escapeblockFast(byte[] buf, ByteArrayOutputStream bytesOut, int size)
/*      */   {
/*  668 */     int lastwritten = 0;
/*      */ 
/*  670 */     for (int i = 0; i < size; i++) {
/*  671 */       byte b = buf[i];
/*      */ 
/*  673 */       if (b == 0)
/*      */       {
/*  675 */         if (i > lastwritten) {
/*  676 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*  680 */         bytesOut.write(92);
/*  681 */         bytesOut.write(48);
/*  682 */         lastwritten = i + 1;
/*      */       } else {
/*  684 */         if ((b != 92) && (b != 39) && ((this.usingAnsiMode) || (b != 34))) {
/*      */           continue;
/*      */         }
/*  687 */         if (i > lastwritten) {
/*  688 */           bytesOut.write(buf, lastwritten, i - lastwritten);
/*      */         }
/*      */ 
/*  692 */         bytesOut.write(92);
/*  693 */         lastwritten = i;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  699 */     if (lastwritten < size)
/*  700 */       bytesOut.write(buf, lastwritten, size - lastwritten);
/*      */   }
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/*  716 */     if ((this.connection.isReadOnly()) && (this.firstCharOfStmt != 'S')) {
/*  717 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009");
/*      */     }
/*      */ 
/*  722 */     checkClosed();
/*      */ 
/*  724 */     ResultSet rs = null;
/*      */ 
/*  726 */     synchronized (this.connection.getMutex()) {
/*  727 */       clearWarnings();
/*      */ 
/*  729 */       this.batchedGeneratedKeys = null;
/*      */ 
/*  731 */       Buffer sendPacket = fillSendPacket();
/*      */ 
/*  733 */       String oldCatalog = null;
/*      */ 
/*  735 */       if (!this.connection.getCatalog().equals(this.currentCatalog)) {
/*  736 */         oldCatalog = this.connection.getCatalog();
/*  737 */         this.connection.setCatalog(this.currentCatalog);
/*      */       }
/*      */ 
/*  740 */       boolean oldInfoMsgState = false;
/*      */ 
/*  742 */       if (this.retrieveGeneratedKeys) {
/*  743 */         oldInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*  744 */         this.connection.setReadInfoMsgEnabled(true);
/*      */       }
/*      */ 
/*  756 */       if (this.connection.useMaxRows()) {
/*  757 */         int rowLimit = -1;
/*      */ 
/*  759 */         if (this.firstCharOfStmt == 'S') {
/*  760 */           if (this.hasLimitClause) {
/*  761 */             rowLimit = this.maxRows;
/*      */           }
/*  763 */           else if (this.maxRows <= 0) {
/*  764 */             this.connection.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */           }
/*      */           else
/*      */           {
/*  770 */             this.connection.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/*  782 */           this.connection.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */         }
/*      */ 
/*  790 */         rs = executeInternal(rowLimit, sendPacket, createStreamingResultSet(), this.firstCharOfStmt == 'S', true, false);
/*      */       }
/*      */       else
/*      */       {
/*  794 */         rs = executeInternal(-1, sendPacket, createStreamingResultSet(), this.firstCharOfStmt == 'S', true, false);
/*      */       }
/*      */ 
/*  799 */       if (this.retrieveGeneratedKeys) {
/*  800 */         this.connection.setReadInfoMsgEnabled(oldInfoMsgState);
/*  801 */         rs.setFirstCharOfQuery('R');
/*      */       }
/*      */ 
/*  804 */       if (oldCatalog != null) {
/*  805 */         this.connection.setCatalog(oldCatalog);
/*      */       }
/*      */ 
/*  808 */       this.lastInsertId = rs.getUpdateID();
/*      */ 
/*  810 */       if (rs != null) {
/*  811 */         this.results = rs;
/*      */       }
/*      */     }
/*      */ 
/*  815 */     return (rs != null) && (rs.reallyResult());
/*      */   }
/*      */ 
/*      */   public int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/*  833 */     checkClosed();
/*      */ 
/*  835 */     if (this.connection.isReadOnly()) {
/*  836 */       throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
/*      */     }
/*      */ 
/*  841 */     synchronized (this.connection.getMutex()) {
/*      */       try {
/*  843 */         clearWarnings();
/*      */ 
/*  845 */         if ((!this.batchHasPlainStatements) && (this.connection.getRewriteBatchedStatements()))
/*      */         {
/*  847 */           if (StringUtils.startsWithIgnoreCaseAndWs(this.originalSql, "INSERT"))
/*      */           {
/*  849 */             arrayOfInt = executeBatchedInserts();
/*      */ 
/*  855 */             clearBatch(); return arrayOfInt;
/*      */           }
/*      */         }
/*  853 */         int[] arrayOfInt = executeBatchSerially();
/*      */ 
/*  855 */         clearBatch(); return arrayOfInt; } finally { clearBatch();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int[] executeBatchedInserts()
/*      */     throws SQLException
/*      */   {
/*  870 */     String valuesClause = extractValuesClause();
/*      */ 
/*  872 */     Connection locallyScopedConn = this.connection;
/*      */ 
/*  874 */     if (valuesClause == null) {
/*  875 */       return executeBatchSerially();
/*      */     }
/*      */ 
/*  878 */     int numBatchedArgs = this.batchedArgs.size();
/*      */ 
/*  880 */     if (this.retrieveGeneratedKeys) {
/*  881 */       this.batchedGeneratedKeys = new ArrayList(numBatchedArgs);
/*      */     }
/*      */ 
/*  884 */     int numValuesPerBatch = computeBatchSize(numBatchedArgs);
/*      */ 
/*  886 */     if (numBatchedArgs < numValuesPerBatch) {
/*  887 */       numValuesPerBatch = numBatchedArgs;
/*      */     }
/*      */ 
/*  890 */     java.sql.PreparedStatement batchedStatement = null;
/*      */ 
/*  892 */     if (this.retrieveGeneratedKeys) {
/*  893 */       batchedStatement = locallyScopedConn.prepareStatement(generateBatchedInsertSQL(valuesClause, numValuesPerBatch), 1);
/*      */     }
/*      */     else
/*      */     {
/*  897 */       batchedStatement = locallyScopedConn.prepareStatement(generateBatchedInsertSQL(valuesClause, numValuesPerBatch));
/*      */     }
/*      */ 
/*  902 */     int batchedParamIndex = 1;
/*  903 */     int updateCountRunningTotal = 0;
/*  904 */     int numberToExecuteAsMultiValue = 0;
/*  905 */     int batchCounter = 0;
/*      */ 
/*  907 */     if (numBatchedArgs < numValuesPerBatch)
/*  908 */       numberToExecuteAsMultiValue = numBatchedArgs;
/*      */     else {
/*  910 */       numberToExecuteAsMultiValue = numBatchedArgs / numValuesPerBatch;
/*      */     }
/*      */ 
/*  913 */     int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch;
/*      */ 
/*  915 */     for (int i = 0; i < numberArgsToExecute; i++) {
/*  916 */       if ((i != 0) && (i % numValuesPerBatch == 0)) {
/*  917 */         updateCountRunningTotal += batchedStatement.executeUpdate();
/*      */ 
/*  919 */         getBatchedGeneratedKeys(batchedStatement);
/*  920 */         batchedStatement.clearParameters();
/*  921 */         batchedParamIndex = 1;
/*      */       }
/*      */ 
/*  925 */       PreparedStatement.BatchParams paramArg = (PreparedStatement.BatchParams)this.batchedArgs.get(batchCounter++);
/*      */ 
/*  928 */       batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, paramArg);
/*      */     }
/*      */ 
/*  932 */     updateCountRunningTotal += batchedStatement.executeUpdate();
/*  933 */     getBatchedGeneratedKeys(batchedStatement);
/*      */ 
/*  935 */     numValuesPerBatch = numBatchedArgs - batchCounter;
/*      */ 
/*  937 */     if (numValuesPerBatch > 0)
/*      */     {
/*  939 */       batchedStatement = locallyScopedConn.prepareStatement(generateBatchedInsertSQL(valuesClause, numValuesPerBatch), 1);
/*      */ 
/*  942 */       batchedParamIndex = 1;
/*      */ 
/*  944 */       while (batchCounter < numBatchedArgs)
/*      */       {
/*  946 */         PreparedStatement.BatchParams paramArg = (PreparedStatement.BatchParams)this.batchedArgs.get(batchCounter++);
/*      */ 
/*  948 */         batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, paramArg);
/*      */       }
/*      */ 
/*  952 */       updateCountRunningTotal += batchedStatement.executeUpdate();
/*  953 */       getBatchedGeneratedKeys(batchedStatement);
/*      */     }
/*      */ 
/*  956 */     int[] updateCounts = new int[this.batchedArgs.size()];
/*      */ 
/*  958 */     for (int i = 0; i < this.batchedArgs.size(); i++) {
/*  959 */       updateCounts[i] = 1;
/*      */     }
/*      */ 
/*  962 */     return updateCounts;
/*      */   }
/*      */ 
/*      */   protected int computeBatchSize(int numBatchedArgs) {
/*  966 */     long sizeOfEntireBatch = 0L;
/*  967 */     long maxSizeOfParameterSet = 0L;
/*      */ 
/*  969 */     for (int i = 0; i < numBatchedArgs; i++) {
/*  970 */       PreparedStatement.BatchParams paramArg = (PreparedStatement.BatchParams)this.batchedArgs.get(i);
/*      */ 
/*  973 */       boolean[] isNullBatch = paramArg.isNull;
/*  974 */       boolean[] isStreamBatch = paramArg.isStream;
/*      */ 
/*  976 */       long sizeOfParameterSet = 0L;
/*      */ 
/*  978 */       for (int j = 0; j < isNullBatch.length; j++) {
/*  979 */         if (isNullBatch[j] != 0)
/*      */           continue;
/*  981 */         if (isStreamBatch[j] != 0) {
/*  982 */           int streamLength = paramArg.streamLengths[j];
/*      */ 
/*  984 */           if (streamLength != -1) {
/*  985 */             sizeOfParameterSet += streamLength * 2;
/*      */           } else {
/*  987 */             int paramLength = paramArg.parameterStrings[j].length;
/*  988 */             sizeOfParameterSet += paramLength;
/*      */           }
/*      */         } else {
/*  991 */           sizeOfParameterSet += 4L;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1004 */       sizeOfParameterSet += this.batchedValuesClause.length() + 1;
/* 1005 */       sizeOfEntireBatch += sizeOfParameterSet;
/*      */ 
/* 1007 */       if (sizeOfParameterSet > maxSizeOfParameterSet) {
/* 1008 */         maxSizeOfParameterSet = sizeOfParameterSet;
/*      */       }
/*      */     }
/*      */ 
/* 1012 */     int maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */ 
/* 1014 */     if (sizeOfEntireBatch < maxAllowedPacket - this.originalSql.length()) {
/* 1015 */       return numBatchedArgs;
/*      */     }
/*      */ 
/* 1018 */     return (int)Math.max(1L, (maxAllowedPacket - this.originalSql.length()) / maxSizeOfParameterSet);
/*      */   }
/*      */ 
/*      */   protected int[] executeBatchSerially()
/*      */     throws SQLException
/*      */   {
/* 1030 */     Connection locallyScopedConn = this.connection;
/*      */ 
/* 1032 */     if (locallyScopedConn == null) {
/* 1033 */       checkClosed();
/*      */     }
/*      */ 
/* 1036 */     int[] updateCounts = null;
/*      */ 
/* 1038 */     if (this.batchedArgs != null) {
/* 1039 */       int nbrCommands = this.batchedArgs.size();
/* 1040 */       updateCounts = new int[nbrCommands];
/*      */ 
/* 1042 */       for (int i = 0; i < nbrCommands; i++) {
/* 1043 */         updateCounts[i] = -3;
/*      */       }
/*      */ 
/* 1046 */       SQLException sqlEx = null;
/*      */ 
/* 1048 */       int commandIndex = 0;
/*      */ 
/* 1050 */       if (this.retrieveGeneratedKeys) {
/* 1051 */         this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */       }
/*      */ 
/* 1054 */       for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/* 1055 */         Object arg = this.batchedArgs.get(commandIndex);
/*      */ 
/* 1057 */         if ((arg instanceof String)) {
/* 1058 */           updateCounts[commandIndex] = executeUpdate((String)arg);
/*      */         } else {
/* 1060 */           PreparedStatement.BatchParams paramArg = (PreparedStatement.BatchParams)arg;
/*      */           try
/*      */           {
/* 1063 */             updateCounts[commandIndex] = executeUpdate(paramArg.parameterStrings, paramArg.parameterStreams, paramArg.isStream, paramArg.streamLengths, paramArg.isNull, true);
/*      */ 
/* 1068 */             if (this.retrieveGeneratedKeys) {
/* 1069 */               java.sql.ResultSet rs = null;
/*      */               try
/*      */               {
/* 1072 */                 rs = getGeneratedKeysInternal();
/*      */ 
/* 1074 */                 while (rs.next())
/* 1075 */                   this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
/*      */               }
/*      */               finally
/*      */               {
/* 1079 */                 if (rs != null)
/* 1080 */                   rs.close();
/*      */               }
/*      */             }
/*      */           }
/*      */           catch (SQLException ex) {
/* 1085 */             updateCounts[commandIndex] = -3;
/*      */ 
/* 1087 */             if (this.continueBatchOnError) {
/* 1088 */               sqlEx = ex;
/*      */             } else {
/* 1090 */               int[] newUpdateCounts = new int[commandIndex];
/* 1091 */               System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */ 
/* 1094 */               throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1102 */       if (sqlEx != null) {
/* 1103 */         throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1108 */     return updateCounts != null ? updateCounts : new int[0];
/*      */   }
/*      */   protected ResultSet executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, boolean unpackFields, boolean isBatch) throws SQLException {
/* 1135 */     this.wasCancelled = false;
/*      */ 
/* 1137 */     Connection locallyScopedConnection = this.connection;
/*      */ 
/* 1139 */     this.numberOfExecutions += 1;
/*      */ 
/* 1143 */     Statement.CancelTask timeoutTask = null;
/*      */     ResultSet rs;
/*      */     try {
/* 1146 */       if ((this.timeoutInMillis != 0) && (locallyScopedConnection.versionMeetsMinimum(5, 0, 0)))
/*      */       {
/* 1148 */         timeoutTask = new Statement.CancelTask(this);
/* 1149 */         Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */       }
/*      */ 
/* 1153 */       rs = locallyScopedConnection.execSQL(this, null, maxRowsToRetrieve, sendPacket, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, unpackFields, isBatch);
/*      */ 
/* 1158 */       if (timeoutTask != null) {
/* 1159 */         timeoutTask.cancel();
/* 1160 */         timeoutTask = null;
/*      */       }
/*      */ 
/* 1163 */       if (this.wasCancelled) {
/* 1164 */         this.wasCancelled = false;
/* 1165 */         throw new MySQLTimeoutException();
/*      */       }
/*      */     } finally {
/* 1168 */       if (timeoutTask != null) {
/* 1169 */         timeoutTask.cancel();
/*      */       }
/*      */     }
/*      */ 
/* 1173 */     return rs;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/* 1186 */     checkClosed();
/*      */ 
/* 1188 */     Connection locallyScopedConn = this.connection;
/*      */ 
/* 1190 */     checkForDml(this.originalSql, this.firstCharOfStmt);
/*      */ 
/* 1192 */     Statement.CachedResultSetMetaData cachedMetadata = null;
/*      */ 
/* 1198 */     synchronized (locallyScopedConn.getMutex()) {
/* 1199 */       clearWarnings();
/*      */ 
/* 1201 */       this.batchedGeneratedKeys = null;
/*      */ 
/* 1203 */       Buffer sendPacket = fillSendPacket();
/*      */ 
/* 1205 */       if ((this.results != null) && 
/* 1206 */         (!this.connection.getHoldResultsOpenOverStatementClose()) && 
/* 1207 */         (!this.holdResultsOpenOverClose)) {
/* 1208 */         this.results.realClose(false);
/*      */       }
/*      */ 
/* 1213 */       String oldCatalog = null;
/*      */ 
/* 1215 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1216 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1217 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */ 
/* 1223 */       if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1224 */         cachedMetadata = getCachedMetaData(this.originalSql);
/*      */       }
/*      */ 
/* 1227 */       if (locallyScopedConn.useMaxRows())
/*      */       {
/* 1234 */         if (this.hasLimitClause) {
/* 1235 */           this.results = executeInternal(this.maxRows, sendPacket, createStreamingResultSet(), true, cachedMetadata == null, false);
/*      */         }
/*      */         else
/*      */         {
/* 1239 */           if (this.maxRows <= 0) {
/* 1240 */             locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */           }
/*      */           else
/*      */           {
/* 1248 */             locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */           }
/*      */ 
/* 1257 */           this.results = executeInternal(-1, sendPacket, createStreamingResultSet(), true, cachedMetadata == null, false);
/*      */ 
/* 1261 */           if (oldCatalog != null)
/* 1262 */             this.connection.setCatalog(oldCatalog);
/*      */         }
/*      */       }
/*      */       else {
/* 1266 */         this.results = executeInternal(-1, sendPacket, createStreamingResultSet(), true, cachedMetadata == null, false);
/*      */       }
/*      */ 
/* 1271 */       if (oldCatalog != null) {
/* 1272 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */     }
/*      */ 
/* 1276 */     this.lastInsertId = this.results.getUpdateID();
/*      */ 
/* 1278 */     if (cachedMetadata != null) {
/* 1279 */       initializeResultsMetadataFromCache(this.originalSql, cachedMetadata, this.results);
/*      */     }
/* 1282 */     else if (this.connection.getCacheResultSetMetadata()) {
/* 1283 */       initializeResultsMetadataFromCache(this.originalSql, null, this.results);
/*      */     }
/*      */ 
/* 1288 */     return this.results;
/*      */   }
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/* 1303 */     return executeUpdate(true, false);
/*      */   }
/*      */ 
/*      */   protected int executeUpdate(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 1313 */     if (clearBatchedGeneratedKeysAndWarnings) {
/* 1314 */       clearWarnings();
/* 1315 */       this.batchedGeneratedKeys = null;
/*      */     }
/*      */ 
/* 1318 */     return executeUpdate(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths, this.isNull, isBatch);
/*      */   }
/*      */ 
/*      */   protected int executeUpdate(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths, boolean[] batchedIsNull, boolean isReallyBatch)
/*      */     throws SQLException
/*      */   {
/* 1346 */     checkClosed();
/*      */ 
/* 1348 */     Connection locallyScopedConn = this.connection;
/*      */ 
/* 1350 */     if (locallyScopedConn.isReadOnly()) {
/* 1351 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009");
/*      */     }
/*      */ 
/* 1356 */     if ((this.firstCharOfStmt == 'S') && (StringUtils.startsWithIgnoreCaseAndWs(this.originalSql, "SELECT")))
/*      */     {
/* 1359 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03");
/*      */     }
/*      */ 
/* 1363 */     if ((this.results != null) && 
/* 1364 */       (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1365 */       this.results.realClose(false);
/*      */     }
/*      */ 
/* 1369 */     ResultSet rs = null;
/*      */ 
/* 1374 */     synchronized (locallyScopedConn.getMutex()) {
/* 1375 */       Buffer sendPacket = fillSendPacket(batchedParameterStrings, batchedParameterStreams, batchedIsStream, batchedStreamLengths);
/*      */ 
/* 1379 */       String oldCatalog = null;
/*      */ 
/* 1381 */       if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1382 */         oldCatalog = locallyScopedConn.getCatalog();
/* 1383 */         locallyScopedConn.setCatalog(this.currentCatalog);
/*      */       }
/*      */ 
/* 1389 */       if (locallyScopedConn.useMaxRows()) {
/* 1390 */         locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */       }
/*      */ 
/* 1397 */       boolean oldInfoMsgState = false;
/*      */ 
/* 1399 */       if (this.retrieveGeneratedKeys) {
/* 1400 */         oldInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/* 1401 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */       }
/*      */ 
/* 1404 */       rs = executeInternal(-1, sendPacket, false, false, true, isReallyBatch);
/*      */ 
/* 1406 */       if (this.retrieveGeneratedKeys) {
/* 1407 */         locallyScopedConn.setReadInfoMsgEnabled(oldInfoMsgState);
/* 1408 */         rs.setFirstCharOfQuery(this.firstCharOfStmt);
/*      */       }
/*      */ 
/* 1411 */       if (oldCatalog != null) {
/* 1412 */         locallyScopedConn.setCatalog(oldCatalog);
/*      */       }
/*      */     }
/*      */ 
/* 1416 */     this.results = rs;
/*      */ 
/* 1418 */     this.updateCount = rs.getUpdateCount();
/*      */ 
/* 1420 */     int truncatedUpdateCount = 0;
/*      */ 
/* 1422 */     if (this.updateCount > 2147483647L)
/* 1423 */       truncatedUpdateCount = 2147483647;
/*      */     else {
/* 1425 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     }
/*      */ 
/* 1428 */     this.lastInsertId = rs.getUpdateID();
/*      */ 
/* 1430 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */   private String extractValuesClause() throws SQLException {
/* 1434 */     if (this.batchedValuesClause == null) {
/* 1435 */       String quoteCharStr = this.connection.getMetaData().getIdentifierQuoteString();
/*      */ 
/* 1438 */       int indexOfValues = -1;
/*      */ 
/* 1440 */       if (quoteCharStr.length() > 0) {
/* 1441 */         indexOfValues = StringUtils.indexOfIgnoreCaseRespectQuotes(0, this.originalSql, "VALUES ", quoteCharStr.charAt(0), false);
/*      */       }
/*      */       else {
/* 1444 */         indexOfValues = StringUtils.indexOfIgnoreCase(0, this.originalSql, "VALUES ");
/*      */       }
/*      */ 
/* 1448 */       if (indexOfValues == -1) {
/* 1449 */         return null;
/*      */       }
/*      */ 
/* 1452 */       int indexOfFirstParen = this.originalSql.indexOf('(', indexOfValues + 7);
/*      */ 
/* 1455 */       if (indexOfFirstParen == -1) {
/* 1456 */         return null;
/*      */       }
/*      */ 
/* 1459 */       int indexOfLastParen = this.originalSql.lastIndexOf(')');
/*      */ 
/* 1461 */       if (indexOfLastParen == -1) {
/* 1462 */         return null;
/*      */       }
/*      */ 
/* 1465 */       this.batchedValuesClause = this.originalSql.substring(indexOfFirstParen, indexOfLastParen + 1);
/*      */     }
/*      */ 
/* 1469 */     return this.batchedValuesClause;
/*      */   }
/*      */ 
/*      */   protected Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/* 1482 */     return fillSendPacket(this.parameterValues, this.parameterStreams, this.isStream, this.streamLengths);
/*      */   }
/*      */ 
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/* 1506 */     Buffer sendPacket = this.connection.getIO().getSharedSendPacket();
/*      */ 
/* 1508 */     sendPacket.clear();
/*      */ 
/* 1510 */     sendPacket.writeByte(3);
/*      */ 
/* 1512 */     boolean useStreamLengths = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/* 1519 */     int ensurePacketSize = 0;
/*      */ 
/* 1521 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 1522 */       if ((batchedIsStream[i] != 0) && (useStreamLengths)) {
/* 1523 */         ensurePacketSize += batchedStreamLengths[i];
/*      */       }
/*      */     }
/*      */ 
/* 1527 */     if (ensurePacketSize != 0) {
/* 1528 */       sendPacket.ensureCapacity(ensurePacketSize);
/*      */     }
/*      */ 
/* 1531 */     for (int i = 0; i < batchedParameterStrings.length; i++) {
/* 1532 */       if ((batchedParameterStrings[i] == null) && (batchedParameterStreams[i] == null))
/*      */       {
/* 1534 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.40") + (i + 1), "07001");
/*      */       }
/*      */ 
/* 1539 */       sendPacket.writeBytesNoNull(this.staticSqlStrings[i]);
/*      */ 
/* 1541 */       if (batchedIsStream[i] != 0) {
/* 1542 */         streamToBytes(sendPacket, batchedParameterStreams[i], true, batchedStreamLengths[i], useStreamLengths);
/*      */       }
/*      */       else {
/* 1545 */         sendPacket.writeBytesNoNull(batchedParameterStrings[i]);
/*      */       }
/*      */     }
/*      */ 
/* 1549 */     sendPacket.writeBytesNoNull(this.staticSqlStrings[batchedParameterStrings.length]);
/*      */ 
/* 1552 */     return sendPacket;
/*      */   }
/*      */ 
/*      */   private String generateBatchedInsertSQL(String valuesClause, int numBatches) {
/* 1556 */     StringBuffer newStatementSql = new StringBuffer(this.originalSql.length() + numBatches * (valuesClause.length() + 1));
/*      */ 
/* 1560 */     newStatementSql.append(this.originalSql);
/*      */ 
/* 1562 */     for (int i = 0; i < numBatches - 1; i++) {
/* 1563 */       newStatementSql.append(',');
/* 1564 */       newStatementSql.append(valuesClause);
/*      */     }
/*      */ 
/* 1567 */     return newStatementSql.toString();
/*      */   }
/*      */ 
/*      */   public byte[] getBytesRepresentation(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1583 */     if (this.isStream[parameterIndex] != 0) {
/* 1584 */       return streamToBytes(this.parameterStreams[parameterIndex], false, this.streamLengths[parameterIndex], this.connection.getUseStreamLengthsInPrepStmts());
/*      */     }
/*      */ 
/* 1589 */     byte[] parameterVal = this.parameterValues[parameterIndex];
/*      */ 
/* 1591 */     if (parameterVal == null) {
/* 1592 */       return null;
/*      */     }
/*      */ 
/* 1595 */     if ((parameterVal[0] == 39) && (parameterVal[(parameterVal.length - 1)] == 39))
/*      */     {
/* 1597 */       byte[] valNoQuotes = new byte[parameterVal.length - 2];
/* 1598 */       System.arraycopy(parameterVal, 1, valNoQuotes, 0, parameterVal.length - 2);
/*      */ 
/* 1601 */       return valNoQuotes;
/*      */     }
/*      */ 
/* 1604 */     return parameterVal;
/*      */   }
/*      */ 
/*      */   private final String getDateTimePattern(String dt, boolean toTime)
/*      */     throws Exception
/*      */   {
/* 1614 */     int dtLength = dt != null ? dt.length() : 0;
/*      */ 
/* 1616 */     if ((dtLength >= 8) && (dtLength <= 10)) {
/* 1617 */       int dashCount = 0;
/* 1618 */       boolean isDateOnly = true;
/*      */ 
/* 1620 */       for (int i = 0; i < dtLength; i++) {
/* 1621 */         char c = dt.charAt(i);
/*      */ 
/* 1623 */         if ((!Character.isDigit(c)) && (c != '-')) {
/* 1624 */           isDateOnly = false;
/*      */ 
/* 1626 */           break;
/*      */         }
/*      */ 
/* 1629 */         if (c == '-') {
/* 1630 */           dashCount++;
/*      */         }
/*      */       }
/*      */ 
/* 1634 */       if ((isDateOnly) && (dashCount == 2)) {
/* 1635 */         return "yyyy-MM-dd";
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1642 */     boolean colonsOnly = true;
/*      */ 
/* 1644 */     for (int i = 0; i < dtLength; i++) {
/* 1645 */       char c = dt.charAt(i);
/*      */ 
/* 1647 */       if ((!Character.isDigit(c)) && (c != ':')) {
/* 1648 */         colonsOnly = false;
/*      */ 
/* 1650 */         break;
/*      */       }
/*      */     }
/*      */ 
/* 1654 */     if (colonsOnly) {
/* 1655 */       return "HH:mm:ss";
/*      */     }
/*      */ 
/* 1664 */     StringReader reader = new StringReader(dt + " ");
/* 1665 */     ArrayList vec = new ArrayList();
/* 1666 */     ArrayList vecRemovelist = new ArrayList();
/* 1667 */     Object[] nv = new Object[3];
/*      */ 
/* 1669 */     nv[0] = new Character('y');
/* 1670 */     nv[1] = new StringBuffer();
/* 1671 */     nv[2] = new Integer(0);
/* 1672 */     vec.add(nv);
/*      */ 
/* 1674 */     if (toTime) {
/* 1675 */       nv = new Object[3];
/* 1676 */       nv[0] = new Character('h');
/* 1677 */       nv[1] = new StringBuffer();
/* 1678 */       nv[2] = new Integer(0);
/* 1679 */       vec.add(nv);
/*      */     }
/*      */     int z;
/* 1682 */     while ((z = reader.read()) != -1) {
/* 1683 */       char separator = (char)z;
/* 1684 */       int maxvecs = vec.size();
/*      */ 
/* 1686 */       for (int count = 0; count < maxvecs; count++) {
/* 1687 */         Object[] v = (Object[])vec.get(count);
/* 1688 */         int n = ((Integer)v[2]).intValue();
/* 1689 */         char c = getSuccessor(((Character)v[0]).charValue(), n);
/*      */ 
/* 1691 */         if (!Character.isLetterOrDigit(separator)) {
/* 1692 */           if ((c == ((Character)v[0]).charValue()) && (c != 'S')) {
/* 1693 */             vecRemovelist.add(v);
/*      */           } else {
/* 1695 */             ((StringBuffer)v[1]).append(separator);
/*      */ 
/* 1697 */             if ((c == 'X') || (c == 'Y'))
/* 1698 */               v[2] = new Integer(4);
/*      */           }
/*      */         }
/*      */         else {
/* 1702 */           if (c == 'X') {
/* 1703 */             c = 'y';
/* 1704 */             nv = new Object[3];
/* 1705 */             nv[1] = new StringBuffer(((StringBuffer)v[1]).toString()).append('M');
/*      */ 
/* 1707 */             nv[0] = new Character('M');
/* 1708 */             nv[2] = new Integer(1);
/* 1709 */             vec.add(nv);
/* 1710 */           } else if (c == 'Y') {
/* 1711 */             c = 'M';
/* 1712 */             nv = new Object[3];
/* 1713 */             nv[1] = new StringBuffer(((StringBuffer)v[1]).toString()).append('d');
/*      */ 
/* 1715 */             nv[0] = new Character('d');
/* 1716 */             nv[2] = new Integer(1);
/* 1717 */             vec.add(nv);
/*      */           }
/*      */ 
/* 1720 */           ((StringBuffer)v[1]).append(c);
/*      */ 
/* 1722 */           if (c == ((Character)v[0]).charValue()) {
/* 1723 */             v[2] = new Integer(n + 1);
/*      */           } else {
/* 1725 */             v[0] = new Character(c);
/* 1726 */             v[2] = new Integer(1);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1731 */       int size = vecRemovelist.size();
/*      */ 
/* 1733 */       for (int i = 0; i < size; i++) {
/* 1734 */         Object[] v = (Object[])vecRemovelist.get(i);
/* 1735 */         vec.remove(v);
/*      */       }
/*      */ 
/* 1738 */       vecRemovelist.clear();
/*      */     }
/*      */ 
/* 1741 */     int size = vec.size();
/*      */ 
/* 1743 */     for (int i = 0; i < size; i++) {
/* 1744 */       Object[] v = (Object[])vec.get(i);
/* 1745 */       char c = ((Character)v[0]).charValue();
/* 1746 */       int n = ((Integer)v[2]).intValue();
/*      */ 
/* 1748 */       boolean bk = getSuccessor(c, n) != c;
/* 1749 */       boolean atEnd = ((c == 's') || (c == 'm') || ((c == 'h') && (toTime))) && (bk);
/* 1750 */       boolean finishesAtDate = (bk) && (c == 'd') && (!toTime);
/* 1751 */       boolean containsEnd = ((StringBuffer)v[1]).toString().indexOf('W') != -1;
/*      */ 
/* 1754 */       if (((!atEnd) && (!finishesAtDate)) || (containsEnd)) {
/* 1755 */         vecRemovelist.add(v);
/*      */       }
/*      */     }
/*      */ 
/* 1759 */     size = vecRemovelist.size();
/*      */ 
/* 1761 */     for (int i = 0; i < size; i++) {
/* 1762 */       vec.remove(vecRemovelist.get(i));
/*      */     }
/*      */ 
/* 1765 */     vecRemovelist.clear();
/* 1766 */     Object[] v = (Object[])vec.get(0);
/*      */ 
/* 1768 */     StringBuffer format = (StringBuffer)v[1];
/* 1769 */     format.setLength(format.length() - 1);
/*      */ 
/* 1771 */     return format.toString();
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 1786 */     if (!StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(this.originalSql, "SELECT"))
/*      */     {
/* 1788 */       return null;
/*      */     }
/*      */ 
/* 1791 */     PreparedStatement mdStmt = null;
/* 1792 */     java.sql.ResultSet mdRs = null;
/*      */ 
/* 1794 */     if (this.pstmtResultMetaData == null) {
/*      */       try {
/* 1796 */         mdStmt = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog, this.parseInfo);
/*      */ 
/* 1799 */         mdStmt.setMaxRows(0);
/*      */ 
/* 1801 */         int paramCount = this.parameterValues.length;
/*      */ 
/* 1803 */         for (int i = 1; i <= paramCount; i++) {
/* 1804 */           mdStmt.setString(i, "");
/*      */         }
/*      */ 
/* 1807 */         boolean hadResults = mdStmt.execute();
/*      */ 
/* 1809 */         if (hadResults) {
/* 1810 */           mdRs = mdStmt.getResultSet();
/*      */ 
/* 1812 */           this.pstmtResultMetaData = mdRs.getMetaData();
/*      */         } else {
/* 1814 */           this.pstmtResultMetaData = new ResultSetMetaData(new Field[0], this.connection.getUseOldAliasMetadataBehavior());
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 1819 */         SQLException sqlExRethrow = null;
/*      */ 
/* 1821 */         if (mdRs != null) {
/*      */           try {
/* 1823 */             mdRs.close();
/*      */           } catch (SQLException sqlEx) {
/* 1825 */             sqlExRethrow = sqlEx;
/*      */           }
/*      */ 
/* 1828 */           mdRs = null;
/*      */         }
/*      */ 
/* 1831 */         if (mdStmt != null) {
/*      */           try {
/* 1833 */             mdStmt.close();
/*      */           } catch (SQLException sqlEx) {
/* 1835 */             sqlExRethrow = sqlEx;
/*      */           }
/*      */ 
/* 1838 */           mdStmt = null;
/*      */         }
/*      */ 
/* 1841 */         if (sqlExRethrow != null) {
/* 1842 */           throw sqlExRethrow;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1847 */     return this.pstmtResultMetaData;
/*      */   }
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 1855 */     if (this.parameterMetaData == null) {
/* 1856 */       this.parameterMetaData = new MysqlParameterMetadata(null, this.parameterCount);
/*      */     }
/*      */ 
/* 1860 */     return this.parameterMetaData;
/*      */   }
/*      */ 
/*      */   PreparedStatement.ParseInfo getParseInfo() {
/* 1864 */     return this.parseInfo;
/*      */   }
/*      */ 
/*      */   private final char getSuccessor(char c, int n) {
/* 1868 */     return (c == 's') && (n < 2) ? 's' : c == 'm' ? 's' : (c == 'm') && (n < 2) ? 'm' : c == 'H' ? 'm' : (c == 'H') && (n < 2) ? 'H' : c == 'd' ? 'H' : (c == 'd') && (n < 2) ? 'd' : c == 'M' ? 'd' : (c == 'M') && (n < 3) ? 'M' : (c == 'M') && (n == 2) ? 'Y' : c == 'y' ? 'M' : (c == 'y') && (n < 4) ? 'y' : (c == 'y') && (n == 2) ? 'X' : 'W';
/*      */   }
/*      */ 
/*      */   private final void hexEscapeBlock(byte[] buf, Buffer packet, int size)
/*      */     throws SQLException
/*      */   {
/* 1894 */     for (int i = 0; i < size; i++) {
/* 1895 */       byte b = buf[i];
/* 1896 */       int lowBits = (b & 0xFF) / 16;
/* 1897 */       int highBits = (b & 0xFF) % 16;
/*      */ 
/* 1899 */       packet.writeByte(HEX_DIGITS[lowBits]);
/* 1900 */       packet.writeByte(HEX_DIGITS[highBits]);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void initializeFromParseInfo() throws SQLException {
/* 1905 */     this.staticSqlStrings = this.parseInfo.staticSql;
/* 1906 */     this.hasLimitClause = this.parseInfo.foundLimitClause;
/* 1907 */     this.isLoadDataQuery = this.parseInfo.foundLoadData;
/* 1908 */     this.firstCharOfStmt = this.parseInfo.firstStmtChar;
/*      */ 
/* 1910 */     this.parameterCount = (this.staticSqlStrings.length - 1);
/*      */ 
/* 1912 */     this.parameterValues = new byte[this.parameterCount][];
/* 1913 */     this.parameterStreams = new InputStream[this.parameterCount];
/* 1914 */     this.isStream = new boolean[this.parameterCount];
/* 1915 */     this.streamLengths = new int[this.parameterCount];
/* 1916 */     this.isNull = new boolean[this.parameterCount];
/*      */ 
/* 1918 */     clearParameters();
/*      */ 
/* 1920 */     for (int j = 0; j < this.parameterCount; j++)
/* 1921 */       this.isStream[j] = false;
/*      */   }
/*      */ 
/*      */   boolean isNull(int paramIndex)
/*      */   {
/* 1926 */     return this.isNull[paramIndex];
/*      */   }
/*      */ 
/*      */   private final int readblock(InputStream i, byte[] b) throws SQLException {
/*      */     try {
/* 1931 */       return i.read(b); } catch (Throwable E) {
/*      */     }
/* 1933 */     throw SQLError.createSQLException(Messages.getString("PreparedStatement.56") + E.getClass().getName(), "S1000");
/*      */   }
/*      */ 
/*      */   private final int readblock(InputStream i, byte[] b, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 1941 */       int lengthToRead = length;
/*      */ 
/* 1943 */       if (lengthToRead > b.length) {
/* 1944 */         lengthToRead = b.length;
/*      */       }
/*      */ 
/* 1947 */       return i.read(b, 0, lengthToRead); } catch (Throwable E) {
/*      */     }
/* 1949 */     throw SQLError.createSQLException(Messages.getString("PreparedStatement.55") + E.getClass().getName(), "S1000");
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 1965 */     if ((this.useUsageAdvisor) && 
/* 1966 */       (this.numberOfExecutions <= 1)) {
/* 1967 */       String message = Messages.getString("PreparedStatement.43");
/*      */ 
/* 1969 */       this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */     }
/*      */ 
/* 1977 */     super.realClose(calledExplicitly, closeOpenResults);
/*      */ 
/* 1979 */     this.dbmd = null;
/* 1980 */     this.originalSql = null;
/* 1981 */     this.staticSqlStrings = ((byte[][])null);
/* 1982 */     this.parameterValues = ((byte[][])null);
/* 1983 */     this.parameterStreams = null;
/* 1984 */     this.isStream = null;
/* 1985 */     this.streamLengths = null;
/* 1986 */     this.isNull = null;
/* 1987 */     this.streamConvertBuf = null;
/*      */   }
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 2004 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2031 */     if (x == null)
/* 2032 */       setNull(parameterIndex, 12);
/*      */     else
/* 2034 */       setBinaryStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 2052 */     if (x == null)
/* 2053 */       setNull(parameterIndex, 3);
/*      */     else
/* 2055 */       setInternal(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString(x)));
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2082 */     if (x == null) {
/* 2083 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 2085 */       int parameterIndexOffset = getParameterIndexOffset();
/*      */ 
/* 2087 */       if ((parameterIndex < 1) || (parameterIndex > this.staticSqlStrings.length))
/*      */       {
/* 2089 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.2") + parameterIndex + Messages.getString("PreparedStatement.3") + this.staticSqlStrings.length + Messages.getString("PreparedStatement.4"), "S1009");
/*      */       }
/*      */ 
/* 2094 */       if ((parameterIndexOffset == -1) && (parameterIndex == 1)) {
/* 2095 */         throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009");
/*      */       }
/*      */ 
/* 2100 */       this.parameterStreams[(parameterIndex - 1 + parameterIndexOffset)] = x;
/* 2101 */       this.isStream[(parameterIndex - 1 + parameterIndexOffset)] = true;
/* 2102 */       this.streamLengths[(parameterIndex - 1 + parameterIndexOffset)] = length;
/* 2103 */       this.isNull[(parameterIndex - 1 + parameterIndexOffset)] = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBlob(int i, Blob x)
/*      */     throws SQLException
/*      */   {
/* 2119 */     if (x == null) {
/* 2120 */       setNull(i, 2004);
/*      */     } else {
/* 2122 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */ 
/* 2124 */       bytesOut.write(39);
/* 2125 */       escapeblockFast(x.getBytes(1L, (int)x.length()), bytesOut, (int)x.length());
/*      */ 
/* 2127 */       bytesOut.write(39);
/*      */ 
/* 2129 */       setInternal(i, bytesOut.toByteArray());
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 2146 */     if (this.useTrueBoolean)
/* 2147 */       setInternal(parameterIndex, x ? "1" : "0");
/*      */     else
/* 2149 */       setInternal(parameterIndex, x ? "'t'" : "'f'");
/*      */   }
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 2166 */     setInternal(parameterIndex, String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 2183 */     setBytes(parameterIndex, x, true, true);
/*      */   }
/*      */ 
/*      */   protected void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars)
/*      */     throws SQLException
/*      */   {
/* 2189 */     if (x == null) {
/* 2190 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 2192 */       String connectionEncoding = this.connection.getEncoding();
/*      */ 
/* 2194 */       if ((this.connection.isNoBackslashEscapesSet()) || ((escapeForMBChars) && (this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding))))
/*      */       {
/* 2202 */         ByteArrayOutputStream bOut = new ByteArrayOutputStream(x.length * 2 + 3);
/*      */ 
/* 2204 */         bOut.write(120);
/* 2205 */         bOut.write(39);
/*      */ 
/* 2207 */         for (int i = 0; i < x.length; i++) {
/* 2208 */           int lowBits = (x[i] & 0xFF) / 16;
/* 2209 */           int highBits = (x[i] & 0xFF) % 16;
/*      */ 
/* 2211 */           bOut.write(HEX_DIGITS[lowBits]);
/* 2212 */           bOut.write(HEX_DIGITS[highBits]);
/*      */         }
/*      */ 
/* 2215 */         bOut.write(39);
/*      */ 
/* 2217 */         setInternal(parameterIndex, bOut.toByteArray());
/*      */ 
/* 2219 */         return;
/*      */       }
/*      */ 
/* 2223 */       int numBytes = x.length;
/*      */ 
/* 2225 */       int pad = 2;
/*      */ 
/* 2227 */       boolean needsIntroducer = (checkForIntroducer) && (this.connection.versionMeetsMinimum(4, 1, 0));
/*      */ 
/* 2230 */       if (needsIntroducer) {
/* 2231 */         pad += 7;
/*      */       }
/*      */ 
/* 2234 */       ByteArrayOutputStream bOut = new ByteArrayOutputStream(numBytes + pad);
/*      */ 
/* 2237 */       if (needsIntroducer) {
/* 2238 */         bOut.write(95);
/* 2239 */         bOut.write(98);
/* 2240 */         bOut.write(105);
/* 2241 */         bOut.write(110);
/* 2242 */         bOut.write(97);
/* 2243 */         bOut.write(114);
/* 2244 */         bOut.write(121);
/*      */       }
/* 2246 */       bOut.write(39);
/*      */ 
/* 2248 */       for (int i = 0; i < numBytes; i++) {
/* 2249 */         byte b = x[i];
/*      */ 
/* 2251 */         switch (b) {
/*      */         case 0:
/* 2253 */           bOut.write(92);
/* 2254 */           bOut.write(48);
/*      */ 
/* 2256 */           break;
/*      */         case 10:
/* 2259 */           bOut.write(92);
/* 2260 */           bOut.write(110);
/*      */ 
/* 2262 */           break;
/*      */         case 13:
/* 2265 */           bOut.write(92);
/* 2266 */           bOut.write(114);
/*      */ 
/* 2268 */           break;
/*      */         case 92:
/* 2271 */           bOut.write(92);
/* 2272 */           bOut.write(92);
/*      */ 
/* 2274 */           break;
/*      */         case 39:
/* 2277 */           bOut.write(92);
/* 2278 */           bOut.write(39);
/*      */ 
/* 2280 */           break;
/*      */         case 34:
/* 2283 */           bOut.write(92);
/* 2284 */           bOut.write(34);
/*      */ 
/* 2286 */           break;
/*      */         case 26:
/* 2289 */           bOut.write(92);
/* 2290 */           bOut.write(90);
/*      */ 
/* 2292 */           break;
/*      */         default:
/* 2295 */           bOut.write(b);
/*      */         }
/*      */       }
/*      */ 
/* 2299 */       bOut.write(39);
/*      */ 
/* 2301 */       setInternal(parameterIndex, bOut.toByteArray());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes)
/*      */     throws SQLException
/*      */   {
/* 2319 */     byte[] parameterWithQuotes = new byte[parameterAsBytes.length + 2];
/* 2320 */     parameterWithQuotes[0] = 39;
/* 2321 */     System.arraycopy(parameterAsBytes, 0, parameterWithQuotes, 1, parameterAsBytes.length);
/*      */ 
/* 2323 */     parameterWithQuotes[(parameterAsBytes.length + 1)] = 39;
/*      */ 
/* 2325 */     setInternal(parameterIndex, parameterWithQuotes);
/*      */   }
/*      */ 
/*      */   protected void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes) throws SQLException
/*      */   {
/* 2330 */     setInternal(parameterIndex, parameterAsBytes);
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2358 */       if (reader == null) {
/* 2359 */         setNull(parameterIndex, -1);
/*      */       } else {
/* 2361 */         char[] c = null;
/* 2362 */         int len = 0;
/*      */ 
/* 2364 */         boolean useLength = this.connection.getUseStreamLengthsInPrepStmts();
/*      */ 
/* 2367 */         String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */ 
/* 2369 */         if ((useLength) && (length != -1)) {
/* 2370 */           c = new char[length];
/*      */ 
/* 2372 */           int numCharsRead = readFully(reader, c, length);
/*      */ 
/* 2377 */           if (forcedEncoding == null)
/* 2378 */             setString(parameterIndex, new String(c, 0, numCharsRead));
/*      */           else
/*      */             try {
/* 2381 */               setBytes(parameterIndex, new String(c, 0, numCharsRead).getBytes(forcedEncoding));
/*      */             }
/*      */             catch (UnsupportedEncodingException uee)
/*      */             {
/* 2385 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
/*      */             }
/*      */         }
/*      */         else
/*      */         {
/* 2390 */           c = new char[4096];
/*      */ 
/* 2392 */           StringBuffer buf = new StringBuffer();
/*      */ 
/* 2394 */           while ((len = reader.read(c)) != -1) {
/* 2395 */             buf.append(c, 0, len);
/*      */           }
/*      */ 
/* 2398 */           if (forcedEncoding == null)
/* 2399 */             setString(parameterIndex, buf.toString());
/*      */           else
/*      */             try {
/* 2402 */               setBytes(parameterIndex, buf.toString().getBytes(forcedEncoding));
/*      */             }
/*      */             catch (UnsupportedEncodingException uee) {
/* 2405 */               throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
/*      */             }
/*      */         }
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/* 2412 */       throw SQLError.createSQLException(ioEx.toString(), "S1000");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setClob(int i, Clob x)
/*      */     throws SQLException
/*      */   {
/* 2429 */     if (x == null) {
/* 2430 */       setNull(i, 2005);
/*      */ 
/* 2432 */       return;
/*      */     }
/*      */ 
/* 2435 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */ 
/* 2437 */     if (forcedEncoding == null)
/* 2438 */       setString(i, x.getSubString(1L, (int)x.length()));
/*      */     else
/*      */       try {
/* 2441 */         setBytes(i, x.getSubString(1L, (int)x.length()).getBytes(forcedEncoding));
/*      */       }
/*      */       catch (UnsupportedEncodingException uee) {
/* 2444 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
/*      */       }
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 2464 */     if (x == null) {
/* 2465 */       setNull(parameterIndex, 91);
/*      */     }
/*      */     else
/*      */     {
/* 2469 */       SimpleDateFormat dateFormatter = new SimpleDateFormat("''yyyy-MM-dd''", Locale.US);
/*      */ 
/* 2471 */       setInternal(parameterIndex, dateFormatter.format(x));
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2491 */     setDate(parameterIndex, x);
/*      */   }
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 2508 */     if ((!this.connection.getAllowNanAndInf()) && ((x == (1.0D / 0.0D)) || (x == (-1.0D / 0.0D)) || (Double.isNaN(x))))
/*      */     {
/* 2511 */       throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009");
/*      */     }
/*      */ 
/* 2517 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */   }
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 2534 */     setInternal(parameterIndex, StringUtils.fixDecimalExponent(String.valueOf(x)));
/*      */   }
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 2551 */     setInternal(parameterIndex, String.valueOf(x));
/*      */   }
/*      */ 
/*      */   private final void setInternal(int paramIndex, byte[] val) throws SQLException
/*      */   {
/* 2556 */     if (this.isClosed) {
/* 2557 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.48"), "S1009");
/*      */     }
/*      */ 
/* 2561 */     int parameterIndexOffset = getParameterIndexOffset();
/*      */ 
/* 2563 */     if (paramIndex < 1) {
/* 2564 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009");
/*      */     }
/*      */ 
/* 2568 */     if (paramIndex > this.parameterCount) {
/* 2569 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + this.parameterValues.length + Messages.getString("PreparedStatement.53"), "S1009");
/*      */     }
/*      */ 
/* 2574 */     if ((parameterIndexOffset == -1) && (paramIndex == 1)) {
/* 2575 */       throw SQLError.createSQLException("Can't set IN parameter for return value of stored function call.", "S1009");
/*      */     }
/*      */ 
/* 2579 */     this.isStream[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 2580 */     this.isNull[(paramIndex - 1 + parameterIndexOffset)] = false;
/* 2581 */     this.parameterStreams[(paramIndex - 1 + parameterIndexOffset)] = null;
/* 2582 */     this.parameterValues[(paramIndex - 1 + parameterIndexOffset)] = val;
/*      */   }
/*      */ 
/*      */   private final void setInternal(int paramIndex, String val) throws SQLException
/*      */   {
/* 2587 */     checkClosed();
/*      */ 
/* 2589 */     byte[] parameterAsBytes = null;
/*      */ 
/* 2591 */     if (this.charConverter != null)
/* 2592 */       parameterAsBytes = this.charConverter.toBytes(val);
/*      */     else {
/* 2594 */       parameterAsBytes = StringUtils.getBytes(val, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
/*      */     }
/*      */ 
/* 2600 */     setInternal(paramIndex, parameterAsBytes);
/*      */   }
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 2616 */     setInternal(parameterIndex, String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 2636 */     setInternal(parameterIndex, "null");
/* 2637 */     this.isNull[(parameterIndex - 1)] = true;
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String arg)
/*      */     throws SQLException
/*      */   {
/* 2659 */     setNull(parameterIndex, sqlType);
/*      */   }
/*      */ 
/*      */   private void setNumericObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*      */     Number parameterAsNum;
/*      */     Number parameterAsNum;
/* 2665 */     if ((parameterObj instanceof Boolean)) {
/* 2666 */       parameterAsNum = ((Boolean)parameterObj).booleanValue() ? new Integer(1) : new Integer(0);
/*      */     }
/* 2669 */     else if ((parameterObj instanceof String))
/*      */     {
/*      */       Number parameterAsNum;
/*      */       Number parameterAsNum;
/*      */       Number parameterAsNum;
/*      */       Number parameterAsNum;
/*      */       Number parameterAsNum;
/*      */       Number parameterAsNum;
/* 2670 */       switch (targetSqlType) {
/*      */       case -7:
/* 2672 */         boolean parameterAsBoolean = "true".equalsIgnoreCase((String)parameterObj);
/*      */ 
/* 2675 */         parameterAsNum = parameterAsBoolean ? new Integer(1) : new Integer(0);
/*      */ 
/* 2678 */         break;
/*      */       case -6:
/*      */       case 4:
/*      */       case 5:
/* 2683 */         parameterAsNum = Integer.valueOf((String)parameterObj);
/*      */ 
/* 2686 */         break;
/*      */       case -5:
/* 2689 */         parameterAsNum = Long.valueOf((String)parameterObj);
/*      */ 
/* 2692 */         break;
/*      */       case 7:
/* 2695 */         parameterAsNum = Float.valueOf((String)parameterObj);
/*      */ 
/* 2698 */         break;
/*      */       case 6:
/*      */       case 8:
/* 2702 */         parameterAsNum = Double.valueOf((String)parameterObj);
/*      */ 
/* 2705 */         break;
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 0:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       default:
/* 2710 */         parameterAsNum = new BigDecimal((String)parameterObj); break;
/*      */       }
/*      */     }
/*      */     else {
/* 2714 */       parameterAsNum = (Number)parameterObj;
/*      */     }
/*      */ 
/* 2717 */     switch (targetSqlType) {
/*      */     case -7:
/*      */     case -6:
/*      */     case 4:
/*      */     case 5:
/* 2722 */       setInt(parameterIndex, parameterAsNum.intValue());
/*      */ 
/* 2724 */       break;
/*      */     case -5:
/* 2727 */       setLong(parameterIndex, parameterAsNum.longValue());
/*      */ 
/* 2729 */       break;
/*      */     case 7:
/* 2732 */       setFloat(parameterIndex, parameterAsNum.floatValue());
/*      */ 
/* 2734 */       break;
/*      */     case 6:
/*      */     case 8:
/* 2738 */       setDouble(parameterIndex, parameterAsNum.doubleValue());
/*      */ 
/* 2740 */       break;
/*      */     case 2:
/*      */     case 3:
/* 2745 */       if ((parameterAsNum instanceof BigDecimal)) {
/* 2746 */         BigDecimal scaledBigDecimal = null;
/*      */         try
/*      */         {
/* 2749 */           scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale);
/*      */         }
/*      */         catch (ArithmeticException ex) {
/*      */           try {
/* 2753 */             scaledBigDecimal = ((BigDecimal)parameterAsNum).setScale(scale, 4);
/*      */           }
/*      */           catch (ArithmeticException arEx)
/*      */           {
/* 2757 */             throw SQLError.createSQLException("Can't set scale of '" + scale + "' for DECIMAL argument '" + parameterAsNum + "'", "S1009");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2766 */         setBigDecimal(parameterIndex, scaledBigDecimal);
/* 2767 */       } else if ((parameterAsNum instanceof BigInteger)) {
/* 2768 */         setBigDecimal(parameterIndex, new BigDecimal((BigInteger)parameterAsNum, scale));
/*      */       }
/*      */       else
/*      */       {
/* 2774 */         setBigDecimal(parameterIndex, new BigDecimal(parameterAsNum.doubleValue()));
/*      */       }
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/*      */     case -1:
/*      */     case 0:
/*      */     case 1:
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj)
/*      */     throws SQLException
/*      */   {
/* 2796 */     if (parameterObj == null) {
/* 2797 */       setNull(parameterIndex, 1111);
/*      */     }
/* 2799 */     else if ((parameterObj instanceof Byte))
/* 2800 */       setInt(parameterIndex, ((Byte)parameterObj).intValue());
/* 2801 */     else if ((parameterObj instanceof String))
/* 2802 */       setString(parameterIndex, (String)parameterObj);
/* 2803 */     else if ((parameterObj instanceof BigDecimal))
/* 2804 */       setBigDecimal(parameterIndex, (BigDecimal)parameterObj);
/* 2805 */     else if ((parameterObj instanceof Short))
/* 2806 */       setShort(parameterIndex, ((Short)parameterObj).shortValue());
/* 2807 */     else if ((parameterObj instanceof Integer))
/* 2808 */       setInt(parameterIndex, ((Integer)parameterObj).intValue());
/* 2809 */     else if ((parameterObj instanceof Long))
/* 2810 */       setLong(parameterIndex, ((Long)parameterObj).longValue());
/* 2811 */     else if ((parameterObj instanceof Float))
/* 2812 */       setFloat(parameterIndex, ((Float)parameterObj).floatValue());
/* 2813 */     else if ((parameterObj instanceof Double))
/* 2814 */       setDouble(parameterIndex, ((Double)parameterObj).doubleValue());
/* 2815 */     else if ((parameterObj instanceof byte[]))
/* 2816 */       setBytes(parameterIndex, (byte[])parameterObj);
/* 2817 */     else if ((parameterObj instanceof java.sql.Date))
/* 2818 */       setDate(parameterIndex, (java.sql.Date)parameterObj);
/* 2819 */     else if ((parameterObj instanceof Time))
/* 2820 */       setTime(parameterIndex, (Time)parameterObj);
/* 2821 */     else if ((parameterObj instanceof Timestamp))
/* 2822 */       setTimestamp(parameterIndex, (Timestamp)parameterObj);
/* 2823 */     else if ((parameterObj instanceof Boolean)) {
/* 2824 */       setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */     }
/* 2826 */     else if ((parameterObj instanceof InputStream))
/* 2827 */       setBinaryStream(parameterIndex, (InputStream)parameterObj, -1);
/* 2828 */     else if ((parameterObj instanceof Blob))
/* 2829 */       setBlob(parameterIndex, (Blob)parameterObj);
/* 2830 */     else if ((parameterObj instanceof Clob))
/* 2831 */       setClob(parameterIndex, (Clob)parameterObj);
/* 2832 */     else if ((parameterObj instanceof java.util.Date)) {
/* 2833 */       setTimestamp(parameterIndex, new Timestamp(((java.util.Date)parameterObj).getTime()));
/*      */     }
/* 2835 */     else if ((parameterObj instanceof BigInteger))
/* 2836 */       setString(parameterIndex, parameterObj.toString());
/*      */     else
/* 2838 */       setSerializableObject(parameterIndex, parameterObj);
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 2859 */     if (!(parameterObj instanceof BigDecimal))
/* 2860 */       setObject(parameterIndex, parameterObj, targetSqlType, 0);
/*      */     else
/* 2862 */       setObject(parameterIndex, parameterObj, targetSqlType, ((BigDecimal)parameterObj).scale());
/*      */   }
/*      */ 
/*      */   public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 2898 */     if (parameterObj == null)
/* 2899 */       setNull(parameterIndex, 1111);
/*      */     else
/*      */       try {
/* 2902 */         switch (targetSqlType)
/*      */         {
/*      */         case 16:
/* 2922 */           if ((parameterObj instanceof Boolean)) {
/* 2923 */             setBoolean(parameterIndex, ((Boolean)parameterObj).booleanValue());
/*      */           }
/* 2926 */           else if ((parameterObj instanceof String)) {
/* 2927 */             setBoolean(parameterIndex, ("true".equalsIgnoreCase((String)parameterObj)) || (!"0".equalsIgnoreCase((String)parameterObj)));
/*      */           }
/* 2931 */           else if ((parameterObj instanceof Number)) {
/* 2932 */             int intValue = ((Number)parameterObj).intValue();
/*      */ 
/* 2934 */             setBoolean(parameterIndex, intValue != 0);
/*      */           }
/*      */           else
/*      */           {
/* 2938 */             throw SQLError.createSQLException("No conversion from " + parameterObj.getClass().getName() + " to Types.BOOLEAN possible.", "S1009");
/*      */           }
/*      */ 
/*      */         case -7:
/*      */         case -6:
/*      */         case -5:
/*      */         case 2:
/*      */         case 3:
/*      */         case 4:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         case 8:
/* 2954 */           setNumericObject(parameterIndex, parameterObj, targetSqlType, scale);
/*      */ 
/* 2956 */           break;
/*      */         case -1:
/*      */         case 1:
/*      */         case 12:
/* 2961 */           if ((parameterObj instanceof BigDecimal)) {
/* 2962 */             setString(parameterIndex, StringUtils.fixDecimalExponent(StringUtils.consistentToString((BigDecimal)parameterObj)));
/*      */           }
/*      */           else
/*      */           {
/* 2968 */             setString(parameterIndex, parameterObj.toString());
/*      */           }
/*      */ 
/* 2971 */           break;
/*      */         case 2005:
/* 2975 */           if ((parameterObj instanceof Clob))
/* 2976 */             setClob(parameterIndex, (Clob)parameterObj);
/*      */           else {
/* 2978 */             setString(parameterIndex, parameterObj.toString());
/*      */           }
/*      */ 
/* 2981 */           break;
/*      */         case -4:
/*      */         case -3:
/*      */         case -2:
/*      */         case 2004:
/* 2988 */           if ((parameterObj instanceof byte[]))
/* 2989 */             setBytes(parameterIndex, (byte[])parameterObj);
/* 2990 */           else if ((parameterObj instanceof Blob))
/* 2991 */             setBlob(parameterIndex, (Blob)parameterObj);
/*      */           else {
/* 2993 */             setBytes(parameterIndex, StringUtils.getBytes(parameterObj.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode()));
/*      */           }
/*      */ 
/* 3000 */           break;
/*      */         case 91:
/*      */         case 93:
/*      */           java.util.Date parameterAsDate;
/*      */           java.util.Date parameterAsDate;
/* 3007 */           if ((parameterObj instanceof String)) {
/* 3008 */             ParsePosition pp = new ParsePosition(0);
/* 3009 */             DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, false), Locale.US);
/*      */ 
/* 3011 */             parameterAsDate = sdf.parse((String)parameterObj, pp);
/*      */           } else {
/* 3013 */             parameterAsDate = (java.util.Date)parameterObj;
/*      */           }
/*      */ 
/* 3016 */           switch (targetSqlType)
/*      */           {
/*      */           case 91:
/* 3019 */             if ((parameterAsDate instanceof java.sql.Date)) {
/* 3020 */               setDate(parameterIndex, (java.sql.Date)parameterAsDate);
/*      */             }
/*      */             else {
/* 3023 */               setDate(parameterIndex, new java.sql.Date(parameterAsDate.getTime()));
/*      */             }
/*      */ 
/* 3027 */             break;
/*      */           case 93:
/* 3031 */             if ((parameterAsDate instanceof Timestamp)) {
/* 3032 */               setTimestamp(parameterIndex, (Timestamp)parameterAsDate);
/*      */             }
/*      */             else {
/* 3035 */               setTimestamp(parameterIndex, new Timestamp(parameterAsDate.getTime()));
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 3043 */           break;
/*      */         case 92:
/* 3047 */           if ((parameterObj instanceof String)) {
/* 3048 */             DateFormat sdf = new SimpleDateFormat(getDateTimePattern((String)parameterObj, true), Locale.US);
/*      */ 
/* 3050 */             setTime(parameterIndex, new Time(sdf.parse((String)parameterObj).getTime()));
/*      */           }
/* 3052 */           else if ((parameterObj instanceof Timestamp)) {
/* 3053 */             Timestamp xT = (Timestamp)parameterObj;
/* 3054 */             setTime(parameterIndex, new Time(xT.getTime()));
/*      */           } else {
/* 3056 */             setTime(parameterIndex, (Time)parameterObj);
/*      */           }
/*      */ 
/* 3059 */           break;
/*      */         case 1111:
/* 3062 */           setSerializableObject(parameterIndex, parameterObj);
/*      */ 
/* 3064 */           break;
/*      */         default:
/* 3067 */           throw SQLError.createSQLException(Messages.getString("PreparedStatement.16"), "S1000");
/*      */         }
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/* 3072 */         if ((ex instanceof SQLException)) {
/* 3073 */           throw ((SQLException)ex);
/*      */         }
/*      */ 
/* 3076 */         throw SQLError.createSQLException(Messages.getString("PreparedStatement.17") + parameterObj.getClass().toString() + Messages.getString("PreparedStatement.18") + ex.getClass().getName() + Messages.getString("PreparedStatement.19") + ex.getMessage(), "S1000");
/*      */       }
/*      */   }
/*      */ 
/*      */   private int setOneBatchedParameterSet(java.sql.PreparedStatement batchedStatement, int batchedParamIndex, PreparedStatement.BatchParams paramArg)
/*      */     throws SQLException
/*      */   {
/* 3090 */     boolean[] isNullBatch = paramArg.isNull;
/* 3091 */     boolean[] isStreamBatch = paramArg.isStream;
/*      */ 
/* 3093 */     for (int j = 0; j < isNullBatch.length; j++) {
/* 3094 */       if (isNullBatch[j] != 0) {
/* 3095 */         batchedStatement.setNull(batchedParamIndex++, 0);
/*      */       }
/* 3097 */       else if (isStreamBatch[j] != 0) {
/* 3098 */         batchedStatement.setBinaryStream(batchedParamIndex++, paramArg.parameterStreams[j], paramArg.streamLengths[j]);
/*      */       }
/*      */       else
/*      */       {
/* 3102 */         ((PreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, paramArg.parameterStrings[j]);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3109 */     return batchedParamIndex;
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 3126 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 3136 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */ 
/*      */   void setResultSetType(int typeFlag)
/*      */   {
/* 3146 */     this.resultSetType = typeFlag;
/*      */   }
/*      */ 
/*      */   protected void setRetrieveGeneratedKeys(boolean retrieveGeneratedKeys)
/*      */   {
/* 3155 */     this.retrieveGeneratedKeys = retrieveGeneratedKeys;
/*      */   }
/*      */ 
/*      */   private final void setSerializableObject(int parameterIndex, Object parameterObj)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3173 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/* 3174 */       ObjectOutputStream objectOut = new ObjectOutputStream(bytesOut);
/* 3175 */       objectOut.writeObject(parameterObj);
/* 3176 */       objectOut.flush();
/* 3177 */       objectOut.close();
/* 3178 */       bytesOut.flush();
/* 3179 */       bytesOut.close();
/*      */ 
/* 3181 */       byte[] buf = bytesOut.toByteArray();
/* 3182 */       ByteArrayInputStream bytesIn = new ByteArrayInputStream(buf);
/* 3183 */       setBinaryStream(parameterIndex, bytesIn, buf.length);
/*      */     } catch (Exception ex) {
/* 3185 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.54") + ex.getClass().getName(), "S1009");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 3204 */     setInternal(parameterIndex, String.valueOf(x));
/*      */   }
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 3222 */     if (x == null) {
/* 3223 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 3225 */       checkClosed();
/*      */ 
/* 3227 */       int stringLength = x.length();
/*      */ 
/* 3229 */       if (this.connection.isNoBackslashEscapesSet())
/*      */       {
/* 3232 */         boolean needsHexEscape = false;
/*      */ 
/* 3234 */         for (int i = 0; i < stringLength; i++) {
/* 3235 */           char c = x.charAt(i);
/*      */ 
/* 3237 */           switch (c)
/*      */           {
/*      */           case '\000':
/* 3240 */             needsHexEscape = true;
/* 3241 */             break;
/*      */           case '\n':
/* 3244 */             needsHexEscape = true;
/*      */ 
/* 3246 */             break;
/*      */           case '\r':
/* 3249 */             needsHexEscape = true;
/* 3250 */             break;
/*      */           case '\\':
/* 3253 */             needsHexEscape = true;
/*      */ 
/* 3255 */             break;
/*      */           case '\'':
/* 3258 */             needsHexEscape = true;
/*      */ 
/* 3260 */             break;
/*      */           case '"':
/* 3263 */             needsHexEscape = true;
/*      */ 
/* 3265 */             break;
/*      */           case '\032':
/* 3268 */             needsHexEscape = true;
/*      */           }
/*      */ 
/* 3272 */           if (needsHexEscape)
/*      */           {
/*      */             break;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 3279 */         if (!needsHexEscape) {
/* 3280 */           byte[] parameterAsBytes = null;
/*      */ 
/* 3282 */           StringBuffer quotedString = new StringBuffer(x.length() + 2);
/* 3283 */           quotedString.append('\'');
/* 3284 */           quotedString.append(x);
/* 3285 */           quotedString.append('\'');
/*      */ 
/* 3287 */           if (!this.isLoadDataQuery) {
/* 3288 */             parameterAsBytes = StringUtils.getBytes(quotedString.toString(), this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
/*      */           }
/*      */           else
/*      */           {
/* 3294 */             parameterAsBytes = quotedString.toString().getBytes();
/*      */           }
/*      */ 
/* 3297 */           setInternal(parameterIndex, parameterAsBytes);
/*      */         } else {
/* 3299 */           byte[] parameterAsBytes = null;
/*      */ 
/* 3301 */           if (!this.isLoadDataQuery) {
/* 3302 */             parameterAsBytes = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
/*      */           }
/*      */           else
/*      */           {
/* 3308 */             parameterAsBytes = x.getBytes();
/*      */           }
/*      */ 
/* 3311 */           setBytes(parameterIndex, parameterAsBytes);
/*      */         }
/*      */ 
/* 3314 */         return;
/*      */       }
/*      */ 
/* 3317 */       StringBuffer buf = new StringBuffer((int)(x.length() * 1.1D));
/* 3318 */       buf.append('\'');
/*      */ 
/* 3327 */       for (int i = 0; i < stringLength; i++) {
/* 3328 */         char c = x.charAt(i);
/*      */ 
/* 3330 */         switch (c) {
/*      */         case '\000':
/* 3332 */           buf.append('\\');
/* 3333 */           buf.append('0');
/*      */ 
/* 3335 */           break;
/*      */         case '\n':
/* 3338 */           buf.append('\\');
/* 3339 */           buf.append('n');
/*      */ 
/* 3341 */           break;
/*      */         case '\r':
/* 3344 */           buf.append('\\');
/* 3345 */           buf.append('r');
/*      */ 
/* 3347 */           break;
/*      */         case '\\':
/* 3350 */           buf.append('\\');
/* 3351 */           buf.append('\\');
/*      */ 
/* 3353 */           break;
/*      */         case '\'':
/* 3356 */           buf.append('\\');
/* 3357 */           buf.append('\'');
/*      */ 
/* 3359 */           break;
/*      */         case '"':
/* 3362 */           if (this.usingAnsiMode) {
/* 3363 */             buf.append('\\');
/*      */           }
/*      */ 
/* 3366 */           buf.append('"');
/*      */ 
/* 3368 */           break;
/*      */         case '\032':
/* 3371 */           buf.append('\\');
/* 3372 */           buf.append('Z');
/*      */ 
/* 3374 */           break;
/*      */         default:
/* 3377 */           buf.append(c);
/*      */         }
/*      */       }
/*      */ 
/* 3381 */       buf.append('\'');
/*      */ 
/* 3383 */       String parameterAsString = buf.toString();
/*      */ 
/* 3385 */       byte[] parameterAsBytes = null;
/*      */ 
/* 3387 */       if (!this.isLoadDataQuery) {
/* 3388 */         parameterAsBytes = StringUtils.getBytes(parameterAsString, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
/*      */       }
/*      */       else
/*      */       {
/* 3394 */         parameterAsBytes = parameterAsString.getBytes();
/*      */       }
/*      */ 
/* 3397 */       setInternal(parameterIndex, parameterAsBytes);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3417 */     setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 3434 */     setTimeInternal(parameterIndex, x, null, TimeZone.getDefault(), false);
/*      */   }
/*      */ 
/*      */   private void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 3455 */     if (x == null) {
/* 3456 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 3458 */       checkClosed();
/*      */ 
/* 3460 */       Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/* 3462 */       synchronized (sessionCalendar) {
/* 3463 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */       }
/*      */ 
/* 3470 */       setInternal(parameterIndex, "'" + x.toString() + "'");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 3490 */     setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 3507 */     setTimestampInternal(parameterIndex, x, null, TimeZone.getDefault(), false);
/*      */   }
/*      */ 
/*      */   private void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 3527 */     if (x == null) {
/* 3528 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 3530 */       checkClosed();
/*      */ 
/* 3532 */       String timestampString = null;
/*      */ 
/* 3534 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 3538 */       synchronized (sessionCalendar) {
/* 3539 */         x = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */       }
/*      */ 
/* 3546 */       if (this.tsdf == null) {
/* 3547 */         this.tsdf = new SimpleDateFormat("''yyyy-MM-dd HH:mm:ss''", Locale.US);
/*      */       }
/*      */ 
/* 3550 */       timestampString = this.tsdf.format(x);
/*      */ 
/* 3552 */       setInternal(parameterIndex, timestampString);
/*      */     }
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 3584 */     if (x == null)
/* 3585 */       setNull(parameterIndex, 12);
/*      */     else
/* 3587 */       setBinaryStream(parameterIndex, x, length);
/*      */   }
/*      */ 
/*      */   public void setURL(int parameterIndex, URL arg)
/*      */     throws SQLException
/*      */   {
/* 3595 */     if (arg != null)
/* 3596 */       setString(parameterIndex, arg.toString());
/*      */     else
/* 3598 */       setNull(parameterIndex, 1);
/*      */   }
/*      */ 
/*      */   private final void streamToBytes(Buffer packet, InputStream in, boolean escape, int streamLength, boolean useLength)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 3606 */       String connectionEncoding = this.connection.getEncoding();
/*      */ 
/* 3608 */       boolean hexEscape = false;
/*      */ 
/* 3610 */       if ((this.connection.isNoBackslashEscapesSet()) || ((this.connection.getUseUnicode()) && (connectionEncoding != null) && (CharsetMapping.isMultibyteCharset(connectionEncoding)) && (!this.connection.parserKnowsUnicode())))
/*      */       {
/* 3615 */         hexEscape = true;
/*      */       }
/*      */ 
/* 3618 */       if (streamLength == -1) {
/* 3619 */         useLength = false;
/*      */       }
/*      */ 
/* 3622 */       int bc = -1;
/*      */ 
/* 3624 */       if (useLength)
/* 3625 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       else {
/* 3627 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */ 
/* 3630 */       int lengthLeftToRead = streamLength - bc;
/*      */ 
/* 3632 */       if (hexEscape)
/* 3633 */         packet.writeStringNoNull("x");
/* 3634 */       else if (this.connection.getIO().versionMeetsMinimum(4, 1, 0)) {
/* 3635 */         packet.writeStringNoNull("_binary");
/*      */       }
/*      */ 
/* 3638 */       if (escape) {
/* 3639 */         packet.writeByte(39);
/*      */       }
/*      */ 
/* 3642 */       while (bc > 0) {
/* 3643 */         if (hexEscape)
/* 3644 */           hexEscapeBlock(this.streamConvertBuf, packet, bc);
/* 3645 */         else if (escape)
/* 3646 */           escapeblockFast(this.streamConvertBuf, packet, bc);
/*      */         else {
/* 3648 */           packet.writeBytesNoNull(this.streamConvertBuf, 0, bc);
/*      */         }
/*      */ 
/* 3651 */         if (useLength) {
/* 3652 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */ 
/* 3654 */           if (bc > 0) {
/* 3655 */             lengthLeftToRead -= bc; continue;
/*      */           }
/*      */         }
/* 3658 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */ 
/* 3662 */       if (escape)
/* 3663 */         packet.writeByte(39);
/*      */     }
/*      */     finally {
/* 3666 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 3668 */           in.close();
/*      */         }
/*      */         catch (IOException ioEx)
/*      */         {
/*      */         }
/* 3673 */         in = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private final byte[] streamToBytes(InputStream in, boolean escape, int streamLength, boolean useLength) throws SQLException
/*      */   {
/*      */     try {
/* 3681 */       if (streamLength == -1) {
/* 3682 */         useLength = false;
/*      */       }
/*      */ 
/* 3685 */       ByteArrayOutputStream bytesOut = new ByteArrayOutputStream();
/*      */ 
/* 3687 */       int bc = -1;
/*      */ 
/* 3689 */       if (useLength)
/* 3690 */         bc = readblock(in, this.streamConvertBuf, streamLength);
/*      */       else {
/* 3692 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */ 
/* 3695 */       int lengthLeftToRead = streamLength - bc;
/*      */ 
/* 3697 */       if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 3698 */         bytesOut.write(95);
/* 3699 */         bytesOut.write(98);
/* 3700 */         bytesOut.write(105);
/* 3701 */         bytesOut.write(110);
/* 3702 */         bytesOut.write(97);
/* 3703 */         bytesOut.write(114);
/* 3704 */         bytesOut.write(121);
/*      */       }
/*      */ 
/* 3707 */       if (escape) {
/* 3708 */         bytesOut.write(39);
/*      */       }
/*      */ 
/* 3711 */       while (bc > 0) {
/* 3712 */         if (escape)
/* 3713 */           escapeblockFast(this.streamConvertBuf, bytesOut, bc);
/*      */         else {
/* 3715 */           bytesOut.write(this.streamConvertBuf, 0, bc);
/*      */         }
/*      */ 
/* 3718 */         if (useLength) {
/* 3719 */           bc = readblock(in, this.streamConvertBuf, lengthLeftToRead);
/*      */ 
/* 3721 */           if (bc > 0) {
/* 3722 */             lengthLeftToRead -= bc; continue;
/*      */           }
/*      */         }
/* 3725 */         bc = readblock(in, this.streamConvertBuf);
/*      */       }
/*      */ 
/* 3729 */       if (escape) {
/* 3730 */         bytesOut.write(39);
/*      */       }
/*      */ 
/* 3733 */       arrayOfByte = bytesOut.toByteArray();
/*      */     }
/*      */     finally
/*      */     {
/*      */       byte[] arrayOfByte;
/* 3735 */       if (this.connection.getAutoClosePStmtStreams()) {
/*      */         try {
/* 3737 */           in.close();
/*      */         }
/*      */         catch (IOException ioEx)
/*      */         {
/*      */         }
/* 3742 */         in = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 3753 */     StringBuffer buf = new StringBuffer();
/* 3754 */     buf.append(super.toString());
/* 3755 */     buf.append(": ");
/*      */     try
/*      */     {
/* 3758 */       buf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 3760 */       buf.append("EXCEPTION: " + sqlEx.toString());
/*      */     }
/*      */ 
/* 3763 */     return buf.toString();
/*      */   }
/*      */ 
/*      */   protected int getParameterIndexOffset()
/*      */   {
/* 3774 */     return 0;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.PreparedStatement
 * JD-Core Version:    0.6.0
 */