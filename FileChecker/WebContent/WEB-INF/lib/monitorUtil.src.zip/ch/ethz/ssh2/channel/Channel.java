/*     */ package ch.ethz.ssh2.channel;
/*     */ 
/*     */ public class Channel
/*     */ {
/*     */   static final int STATE_OPENING = 1;
/*     */   static final int STATE_OPEN = 2;
/*     */   static final int STATE_CLOSED = 4;
/*     */   static final int CHANNEL_BUFFER_SIZE = 30000;
/*     */   final ChannelManager cm;
/*     */   final ChannelOutputStream stdinStream;
/*     */   final ChannelInputStream stdoutStream;
/*     */   final ChannelInputStream stderrStream;
/*  65 */   int localID = -1;
/*  66 */   int remoteID = -1;
/*     */ 
/*  91 */   final Object channelSendLock = new Object();
/*  92 */   boolean closeMessageSent = false;
/*     */ 
/*  99 */   final byte[] msgWindowAdjust = new byte[9];
/*     */ 
/* 104 */   int state = 1;
/*     */ 
/* 106 */   boolean closeMessageRecv = false;
/*     */ 
/* 111 */   int successCounter = 0;
/* 112 */   int failedCounter = 0;
/*     */ 
/* 114 */   int localWindow = 0;
/* 115 */   long remoteWindow = 0L;
/*     */ 
/* 117 */   int localMaxPacketSize = -1;
/* 118 */   int remoteMaxPacketSize = -1;
/*     */ 
/* 120 */   final byte[] stdoutBuffer = new byte[30000];
/* 121 */   final byte[] stderrBuffer = new byte[30000];
/*     */ 
/* 123 */   int stdoutReadpos = 0;
/* 124 */   int stdoutWritepos = 0;
/* 125 */   int stderrReadpos = 0;
/* 126 */   int stderrWritepos = 0;
/*     */ 
/* 128 */   boolean EOF = false;
/*     */   Integer exit_status;
/*     */   String exit_signal;
/*     */   String hexX11FakeCookie;
/* 143 */   private final Object reasonClosedLock = new Object();
/* 144 */   private String reasonClosed = null;
/*     */ 
/*     */   public Channel(ChannelManager cm)
/*     */   {
/* 148 */     this.cm = cm;
/*     */ 
/* 150 */     this.localWindow = 30000;
/* 151 */     this.localMaxPacketSize = 33976;
/*     */ 
/* 153 */     this.stdinStream = new ChannelOutputStream(this);
/* 154 */     this.stdoutStream = new ChannelInputStream(this, false);
/* 155 */     this.stderrStream = new ChannelInputStream(this, true);
/*     */   }
/*     */ 
/*     */   public ChannelInputStream getStderrStream()
/*     */   {
/* 162 */     return this.stderrStream;
/*     */   }
/*     */ 
/*     */   public ChannelOutputStream getStdinStream()
/*     */   {
/* 167 */     return this.stdinStream;
/*     */   }
/*     */ 
/*     */   public ChannelInputStream getStdoutStream()
/*     */   {
/* 172 */     return this.stdoutStream;
/*     */   }
/*     */ 
/*     */   public String getExitSignal()
/*     */   {
/* 177 */     synchronized (this)
/*     */     {
/* 179 */       return this.exit_signal;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Integer getExitStatus()
/*     */   {
/* 185 */     synchronized (this)
/*     */     {
/* 187 */       return this.exit_status;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getReasonClosed()
/*     */   {
/* 193 */     synchronized (this.reasonClosedLock)
/*     */     {
/* 195 */       return this.reasonClosed;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setReasonClosed(String reasonClosed)
/*     */   {
/* 201 */     synchronized (this.reasonClosedLock)
/*     */     {
/* 203 */       if (this.reasonClosed == null)
/* 204 */         this.reasonClosed = reasonClosed;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.Channel
 * JD-Core Version:    0.6.0
 */