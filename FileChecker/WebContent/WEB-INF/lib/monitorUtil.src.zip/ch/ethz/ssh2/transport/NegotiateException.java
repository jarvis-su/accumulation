package ch.ethz.ssh2.transport;

public class NegotiateException extends Exception
{
  private static final long serialVersionUID = 3689910669428143157L;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.NegotiateException
 * JD-Core Version:    0.6.0
 */