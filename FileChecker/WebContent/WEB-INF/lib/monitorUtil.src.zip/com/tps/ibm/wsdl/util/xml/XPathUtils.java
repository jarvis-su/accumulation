package com.ibm.wsdl.util.xml;

import java.util.Vector;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;

public class XPathUtils
{
  private static Node getPreviousTypedNode(Node paramNode, short paramShort)
  {
    for (paramNode = paramNode.getPreviousSibling(); (paramNode != null) && (paramNode.getNodeType() != paramShort); paramNode = paramNode.getPreviousSibling());
    return paramNode;
  }

  private static Node getNextTypedNode(Node paramNode, short paramShort)
  {
    for (paramNode = paramNode.getNextSibling(); (paramNode != null) && (paramNode.getNodeType() != paramShort); paramNode = paramNode.getNextSibling());
    return paramNode;
  }

  private static String getValue(Node paramNode, short paramShort)
  {
    switch (paramShort)
    {
    case 1:
      return ((Element)paramNode).getTagName();
    case 3:
      return ((Text)paramNode).getData();
    case 7:
      return ((ProcessingInstruction)paramNode).getData();
    }
    return "";
  }

  private static short getNodeType(Node paramNode)
  {
    return paramNode != null ? paramNode.getNodeType() : -1;
  }

  private static String getXPathFromVector(Vector paramVector)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = paramVector.size();
    for (int j = 0; j < i; j++)
    {
      Node localNode = (Node)paramVector.elementAt(j);
      short s = getNodeType(localNode);
      String str1 = getValue(localNode, s);
      int k = 1;
      for (localNode = getPreviousTypedNode(localNode, s); localNode != null; localNode = getPreviousTypedNode(localNode, s))
        if (s == 1)
        {
          if (!getValue(localNode, s).equals(str1))
            continue;
          k++;
        }
        else
        {
          k++;
        }
      int m = k > 1 ? 1 : 0;
      if (m == 0)
      {
        localNode = (Node)paramVector.elementAt(j);
        localNode = getNextTypedNode(localNode, s);
        while ((m == 0) && (localNode != null))
        {
          if (s == 1)
          {
            if (getValue(localNode, s).equals(str1))
            {
              m = 1;
              continue;
            }
            localNode = getNextTypedNode(localNode, s);
            continue;
          }
          m = 1;
        }
      }
      String str2;
      switch (s)
      {
      case 3:
        str2 = "text()";
        break;
      case 7:
        str2 = "processing-instruction()";
        break;
      default:
        str2 = str1;
      }
      if ((str2 != null) && (str2.length() > 0))
        localStringBuffer.append('/' + str2);
      if (m == 0)
        continue;
      localStringBuffer.append("[" + k + "]");
    }
    return localStringBuffer.toString();
  }

  private static Vector getVectorPathFromNode(Node paramNode)
  {
    Vector localVector = new Vector();
    while (paramNode != null)
    {
      localVector.insertElementAt(paramNode, 0);
      paramNode = paramNode.getParentNode();
    }
    return localVector;
  }

  public static String getXPathExprFromNode(Node paramNode)
    throws IllegalArgumentException
  {
    int i = getNodeType(paramNode);
    switch (i)
    {
    case 1:
    case 3:
    case 7:
      return getXPathFromVector(getVectorPathFromNode(paramNode));
    case 9:
      return "/";
    case 2:
    case 4:
    case 5:
    case 6:
    case 8:
    }
    throw new IllegalArgumentException("Only works for element, text, document, and PI nodes.");
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.xml.XPathUtils
 * JD-Core Version:    0.6.0
 */