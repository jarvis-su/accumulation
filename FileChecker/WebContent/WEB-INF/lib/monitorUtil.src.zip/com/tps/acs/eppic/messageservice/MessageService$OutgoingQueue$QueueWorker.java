/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.messageservice.web.MessageWebService;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.net.URL;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ class MessageService$OutgoingQueue$QueueWorker extends Thread
/*     */ {
/* 319 */   boolean alertQueueWait = false;
/* 320 */   boolean messageQueueWait = false;
/*     */ 
/*     */   private MessageService$OutgoingQueue$QueueWorker(MessageService.OutgoingQueue paramOutgoingQueue) {  } 
/* 322 */   public void run() { List messageList = new LinkedList();
/*     */ 
/* 325 */     while (MessageService.OutgoingQueue.access$3(this.this$1).isServiceEnabled()) {
/* 326 */       messageList.clear();
/* 327 */       synchronized (MessageService.OutgoingQueue.access$0(this.this$1)) {
/* 328 */         if (MessageService.OutgoingQueue.access$0(this.this$1).isEmpty()) {
/* 329 */           this.alertQueueWait = true;
/*     */         }
/*     */         else {
/* 332 */           this.alertQueueWait = false;
/*     */           do
/*     */           {
/* 335 */             messageList.add(MessageService.OutgoingQueue.access$0(this.this$1).removeFirst());
/*     */ 
/* 334 */             if (messageList.size() >= MessageService.access$0(MessageService.OutgoingQueue.access$3(this.this$1))) break; 
/* 334 */           }while (!MessageService.OutgoingQueue.access$0(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 339 */       synchronized (MessageService.OutgoingQueue.access$1(this.this$1)) {
/* 340 */         if (MessageService.OutgoingQueue.access$1(this.this$1).isEmpty()) {
/* 341 */           this.messageQueueWait = true;
/*     */         }
/*     */         else {
/* 344 */           this.messageQueueWait = false;
/*     */           do
/*     */           {
/* 347 */             messageList.add(MessageService.OutgoingQueue.access$1(this.this$1).removeFirst());
/*     */ 
/* 346 */             if (messageList.size() >= MessageService.access$0(MessageService.OutgoingQueue.access$3(this.this$1))) break; 
/* 346 */           }while (!MessageService.OutgoingQueue.access$1(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 352 */       if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 353 */         synchronized (this.this$1.semObj) {
/*     */           try {
/* 355 */             this.this$1.semObj.wait();
/*     */           }
/*     */           catch (InterruptedException localInterruptedException)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 362 */       MessageWebService mws = null;
/* 363 */       int sentMessages = 0;
/*     */ 
/* 365 */       while (!messageList.isEmpty()) {
/* 366 */         Message message = (Message)messageList.remove(0);
/*     */         try {
/* 368 */           if (MessageService.OutgoingQueue.access$3(this.this$1).isMonitorMode())
/* 369 */             mws = MessageService.OutgoingQueue.access$2(this.this$1).getMessageWebService(new URL(MessageService.access$1(MessageService.OutgoingQueue.access$3(this.this$1), message.getIP(), message.getPort())));
/* 370 */           else if (mws == null) {
/* 371 */             mws = MessageService.OutgoingQueue.access$2(this.this$1).getMessageWebService(new URL(MessageService.access$2(MessageService.OutgoingQueue.access$3(this.this$1))));
/*     */           }
/* 373 */           MessageService.logger.debug(getName() + "Sending Message(s)...\n" + message);
/* 374 */           mws.sendMessage(message);
/* 375 */           sentMessages++;
/*     */         } catch (Throwable e) {
/* 377 */           MessageService.logger.error("Send Message Failed" + message, e);
/* 378 */           MessageService.OutgoingQueue.access$3(this.this$1).setConnected(false);
/* 379 */           mws = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService.OutgoingQueue.QueueWorker
 * JD-Core Version:    0.6.0
 */