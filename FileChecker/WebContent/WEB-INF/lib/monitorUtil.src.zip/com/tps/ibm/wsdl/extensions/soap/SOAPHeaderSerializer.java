package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap.SOAPHeader;
import javax.wsdl.extensions.soap.SOAPHeaderFault;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPHeaderSerializer
  implements ExtensionSerializer, ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPHeader localSOAPHeader = (SOAPHeader)paramExtensibilityElement;
    if (localSOAPHeader != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "header", paramDefinition);
      paramPrintWriter.print("        <" + str);
      DOMUtils.printQualifiedAttribute("message", localSOAPHeader.getMessage(), paramDefinition, paramPrintWriter);
      DOMUtils.printAttribute("part", localSOAPHeader.getPart(), paramPrintWriter);
      DOMUtils.printAttribute("use", localSOAPHeader.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(localSOAPHeader.getEncodingStyles()), paramPrintWriter);
      DOMUtils.printAttribute("namespace", localSOAPHeader.getNamespaceURI(), paramPrintWriter);
      Boolean localBoolean = localSOAPHeader.getRequired();
      if (localBoolean != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printSoapHeaderFaults(localSOAPHeader.getSOAPHeaderFaults(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("        </" + str + '>');
    }
  }

  private static void printSoapHeaderFaults(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramList != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "headerfault", paramDefinition);
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        SOAPHeaderFault localSOAPHeaderFault = (SOAPHeaderFault)localIterator.next();
        if (localSOAPHeaderFault == null)
          continue;
        paramPrintWriter.print("          <" + str);
        DOMUtils.printQualifiedAttribute("message", localSOAPHeaderFault.getMessage(), paramDefinition, paramPrintWriter);
        DOMUtils.printAttribute("part", localSOAPHeaderFault.getPart(), paramPrintWriter);
        DOMUtils.printAttribute("use", localSOAPHeaderFault.getUse(), paramPrintWriter);
        DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(localSOAPHeaderFault.getEncodingStyles()), paramPrintWriter);
        DOMUtils.printAttribute("namespace", localSOAPHeaderFault.getNamespaceURI(), paramPrintWriter);
        Boolean localBoolean = localSOAPHeaderFault.getRequired();
        if (localBoolean != null)
          DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println("/>");
      }
    }
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPHeader localSOAPHeader = (SOAPHeader)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName localQName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (localQName != null)
      localSOAPHeader.setMessage(localQName);
    if (str1 != null)
      localSOAPHeader.setPart(str1);
    if (str2 != null)
      localSOAPHeader.setUse(str2);
    if (str3 != null)
      localSOAPHeader.setEncodingStyles(StringUtils.parseNMTokens(str3));
    if (str4 != null)
      localSOAPHeader.setNamespaceURI(str4);
    if (str5 != null)
      localSOAPHeader.setRequired(new Boolean(str5));
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(SOAPConstants.Q_ELEM_SOAP_HEADER_FAULT, localElement))
        localSOAPHeader.addSOAPHeaderFault(parseSoapHeaderFault(SOAPHeader.class, SOAPConstants.Q_ELEM_SOAP_HEADER_FAULT, localElement, paramExtensionRegistry, paramDefinition));
      else
        DOMUtils.throwWSDLException(localElement);
    return localSOAPHeader;
  }

  private static SOAPHeaderFault parseSoapHeaderFault(Class paramClass, QName paramQName, Element paramElement, ExtensionRegistry paramExtensionRegistry, Definition paramDefinition)
    throws WSDLException
  {
    SOAPHeaderFault localSOAPHeaderFault = (SOAPHeaderFault)paramExtensionRegistry.createExtension(paramClass, paramQName);
    QName localQName = DOMUtils.getQualifiedAttributeValue(paramElement, "message", "header", false, paramDefinition);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (localQName != null)
      localSOAPHeaderFault.setMessage(localQName);
    if (str1 != null)
      localSOAPHeaderFault.setPart(str1);
    if (str2 != null)
      localSOAPHeaderFault.setUse(str2);
    if (str3 != null)
      localSOAPHeaderFault.setEncodingStyles(StringUtils.parseNMTokens(str3));
    if (str4 != null)
      localSOAPHeaderFault.setNamespaceURI(str4);
    if (str5 != null)
      localSOAPHeaderFault.setRequired(new Boolean(str5));
    return localSOAPHeaderFault;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.soap.SOAPHeaderSerializer
 * JD-Core Version:    0.6.0
 */