/*     */ package com.acs.eppic.messageservice.web;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageData;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import java.net.URL;
/*     */ import java.rmi.RemoteException;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.Vector;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.NoEndPointException;
/*     */ import org.apache.axis.client.Call;
/*     */ import org.apache.axis.client.Stub;
/*     */ import org.apache.axis.constants.Style;
/*     */ import org.apache.axis.constants.Use;
/*     */ import org.apache.axis.description.OperationDesc;
/*     */ import org.apache.axis.description.ParameterDesc;
/*     */ import org.apache.axis.encoding.DeserializerFactory;
/*     */ import org.apache.axis.encoding.XMLType;
/*     */ import org.apache.axis.encoding.ser.ArrayDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.ArraySerializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.BeanSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.EnumDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.EnumSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleListDeserializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleListSerializerFactory;
/*     */ import org.apache.axis.encoding.ser.SimpleSerializerFactory;
/*     */ import org.apache.axis.soap.SOAPConstants;
/*     */ 
/*     */ public class MessageWebServiceSoapBindingStub extends Stub
/*     */   implements MessageWebService
/*     */ {
/*  11 */   private Vector cachedSerClasses = new Vector();
/*  12 */   private Vector cachedSerQNames = new Vector();
/*  13 */   private Vector cachedSerFactories = new Vector();
/*  14 */   private Vector cachedDeserFactories = new Vector();
/*     */ 
/*  19 */   static OperationDesc[] _operations = new OperationDesc[1];
/*     */ 
/*  20 */   static { _initOperationDesc1();
/*     */   }
/*     */ 
/*     */   private static void _initOperationDesc1()
/*     */   {
/*  26 */     OperationDesc oper = new OperationDesc();
/*  27 */     oper.setName("sendMessage");
/*  28 */     ParameterDesc param = new ParameterDesc(new QName("", "in0"), 1, new QName("http://message.eppic.acs.com", "Message"), Message.class, false, false);
/*  29 */     oper.addParameter(param);
/*  30 */     oper.setReturnType(XMLType.AXIS_VOID);
/*  31 */     oper.setStyle(Style.RPC);
/*  32 */     oper.setUse(Use.ENCODED);
/*  33 */     _operations[0] = oper;
/*     */   }
/*     */ 
/*     */   public MessageWebServiceSoapBindingStub() throws AxisFault
/*     */   {
/*  38 */     this(null);
/*     */   }
/*     */ 
/*     */   public MessageWebServiceSoapBindingStub(URL endpointURL, javax.xml.rpc.Service service) throws AxisFault {
/*  42 */     this(service);
/*  43 */     this.cachedEndpoint = endpointURL;
/*     */   }
/*     */ 
/*     */   public MessageWebServiceSoapBindingStub(javax.xml.rpc.Service service) throws AxisFault {
/*  47 */     if (service == null)
/*  48 */       this.service = new org.apache.axis.client.Service();
/*     */     else {
/*  50 */       this.service = service;
/*     */     }
/*  52 */     ((org.apache.axis.client.Service)this.service).setTypeMappingVersion("1.2");
/*     */ 
/*  56 */     Class beansf = BeanSerializerFactory.class;
/*  57 */     Class beandf = BeanDeserializerFactory.class;
/*  58 */     Class enumsf = EnumSerializerFactory.class;
/*  59 */     Class enumdf = EnumDeserializerFactory.class;
/*  60 */     Class arraysf = ArraySerializerFactory.class;
/*  61 */     Class arraydf = ArrayDeserializerFactory.class;
/*  62 */     Class simplesf = SimpleSerializerFactory.class;
/*  63 */     Class simpledf = SimpleDeserializerFactory.class;
/*  64 */     Class simplelistsf = SimpleListSerializerFactory.class;
/*  65 */     Class simplelistdf = SimpleListDeserializerFactory.class;
/*  66 */     QName qName = new QName("http://message.eppic.acs.com", "Message");
/*  67 */     this.cachedSerQNames.add(qName);
/*  68 */     Class cls = Message.class;
/*  69 */     this.cachedSerClasses.add(cls);
/*  70 */     this.cachedSerFactories.add(beansf);
/*  71 */     this.cachedDeserFactories.add(beandf);
/*     */ 
/*  73 */     qName = new QName("http://message.eppic.acs.com", "MessageData");
/*  74 */     this.cachedSerQNames.add(qName);
/*  75 */     cls = MessageData.class;
/*  76 */     this.cachedSerClasses.add(cls);
/*  77 */     this.cachedSerFactories.add(beansf);
/*  78 */     this.cachedDeserFactories.add(beandf);
/*     */ 
/*  80 */     qName = new QName("http://message.eppic.acs.com", "MessageType");
/*  81 */     this.cachedSerQNames.add(qName);
/*  82 */     cls = MessageType.class;
/*  83 */     this.cachedSerClasses.add(cls);
/*  84 */     this.cachedSerFactories.add(beansf);
/*  85 */     this.cachedDeserFactories.add(beandf);
/*     */   }
/*     */ 
/*     */   protected Call createCall() throws RemoteException
/*     */   {
/*     */     try {
/*  91 */       Call _call = super._createCall();
/*  92 */       if (this.maintainSessionSet) {
/*  93 */         _call.setMaintainSession(this.maintainSession);
/*     */       }
/*  95 */       if (this.cachedUsername != null) {
/*  96 */         _call.setUsername(this.cachedUsername);
/*     */       }
/*  98 */       if (this.cachedPassword != null) {
/*  99 */         _call.setPassword(this.cachedPassword);
/*     */       }
/* 101 */       if (this.cachedEndpoint != null) {
/* 102 */         _call.setTargetEndpointAddress(this.cachedEndpoint);
/*     */       }
/* 104 */       if (this.cachedTimeout != null) {
/* 105 */         _call.setTimeout(this.cachedTimeout);
/*     */       }
/* 107 */       if (this.cachedPortName != null) {
/* 108 */         _call.setPortName(this.cachedPortName);
/*     */       }
/* 110 */       Enumeration keys = this.cachedProperties.keys();
/* 111 */       while (keys.hasMoreElements()) {
/* 112 */         String key = (String)keys.nextElement();
/* 113 */         _call.setProperty(key, this.cachedProperties.get(key));
/*     */       }
/*     */ 
/* 120 */       synchronized (this) {
/* 121 */         if (firstCall())
/*     */         {
/* 123 */           _call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
/* 124 */           _call.setEncodingStyle("http://schemas.xmlsoap.org/soap/encoding/");
/* 125 */           for (int i = 0; i < this.cachedSerFactories.size(); i++) {
/* 126 */             Class cls = (Class)this.cachedSerClasses.get(i);
/* 127 */             QName qName = 
/* 128 */               (QName)this.cachedSerQNames.get(i);
/* 129 */             Object x = this.cachedSerFactories.get(i);
/* 130 */             if ((x instanceof Class)) {
/* 131 */               Class sf = 
/* 132 */                 (Class)this.cachedSerFactories.get(i);
/* 133 */               Class df = 
/* 134 */                 (Class)this.cachedDeserFactories.get(i);
/* 135 */               _call.registerTypeMapping(cls, qName, sf, df, false);
/*     */             }
/* 137 */             else if ((x instanceof javax.xml.rpc.encoding.SerializerFactory)) {
/* 138 */               org.apache.axis.encoding.SerializerFactory sf = 
/* 139 */                 (org.apache.axis.encoding.SerializerFactory)this.cachedSerFactories.get(i);
/* 140 */               DeserializerFactory df = 
/* 141 */                 (DeserializerFactory)this.cachedDeserFactories.get(i);
/* 142 */               _call.registerTypeMapping(cls, qName, sf, df, false);
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/* 147 */       return _call;
/*     */     } catch (Throwable _t) {
/*     */     }
/* 150 */     throw new AxisFault("Failure trying to get the Call object", _t);
/*     */   }
/*     */ 
/*     */   public void sendMessage(Message in0) throws RemoteException
/*     */   {
/* 155 */     if (this.cachedEndpoint == null) {
/* 156 */       throw new NoEndPointException();
/*     */     }
/* 158 */     Call _call = createCall();
/* 159 */     _call.setOperation(_operations[0]);
/* 160 */     _call.setUseSOAPAction(true);
/* 161 */     _call.setSOAPActionURI("");
/* 162 */     _call.setSOAPVersion(SOAPConstants.SOAP11_CONSTANTS);
/* 163 */     _call.setOperationName(new QName("urn:MessageWebService", "sendMessage"));
/*     */ 
/* 165 */     setRequestHeaders(_call);
/* 166 */     setAttachments(_call);
/*     */     try { Object _resp = _call.invoke(new Object[] { in0 });
/*     */ 
/* 169 */       if ((_resp instanceof RemoteException)) {
/* 170 */         throw ((RemoteException)_resp);
/*     */       }
/* 172 */       extractAttachments(_call);
/*     */     } catch (AxisFault axisFaultException) {
/* 174 */       throw axisFaultException;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.web.MessageWebServiceSoapBindingStub
 * JD-Core Version:    0.6.0
 */