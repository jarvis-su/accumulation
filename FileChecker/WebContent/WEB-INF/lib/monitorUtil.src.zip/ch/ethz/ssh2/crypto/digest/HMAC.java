/*    */ package ch.ethz.ssh2.crypto.digest;
/*    */ 
/*    */ public final class HMAC
/*    */   implements Digest
/*    */ {
/*    */   Digest md;
/*    */   byte[] k_xor_ipad;
/*    */   byte[] k_xor_opad;
/*    */   byte[] tmp;
/*    */   int size;
/*    */ 
/*    */   public HMAC(Digest md, byte[] key, int size)
/*    */   {
/* 22 */     this.md = md;
/* 23 */     this.size = size;
/*    */ 
/* 25 */     this.tmp = new byte[md.getDigestLength()];
/*    */ 
/* 27 */     int BLOCKSIZE = 64;
/*    */ 
/* 29 */     this.k_xor_ipad = new byte[BLOCKSIZE];
/* 30 */     this.k_xor_opad = new byte[BLOCKSIZE];
/*    */ 
/* 32 */     if (key.length > BLOCKSIZE)
/*    */     {
/* 34 */       md.reset();
/* 35 */       md.update(key);
/* 36 */       md.digest(this.tmp);
/* 37 */       key = this.tmp;
/*    */     }
/*    */ 
/* 40 */     System.arraycopy(key, 0, this.k_xor_ipad, 0, key.length);
/* 41 */     System.arraycopy(key, 0, this.k_xor_opad, 0, key.length);
/*    */ 
/* 43 */     for (int i = 0; i < BLOCKSIZE; i++)
/*    */     {
/*    */       int tmp117_115 = i;
/*    */       byte[] tmp117_112 = this.k_xor_ipad; tmp117_112[tmp117_115] = (byte)(tmp117_112[tmp117_115] ^ 0x36);
/*    */       int tmp130_128 = i;
/*    */       byte[] tmp130_125 = this.k_xor_opad; tmp130_125[tmp130_128] = (byte)(tmp130_125[tmp130_128] ^ 0x5C);
/*    */     }
/* 48 */     md.update(this.k_xor_ipad);
/*    */   }
/*    */ 
/*    */   public final int getDigestLength()
/*    */   {
/* 53 */     return this.size;
/*    */   }
/*    */ 
/*    */   public final void update(byte b)
/*    */   {
/* 58 */     this.md.update(b);
/*    */   }
/*    */ 
/*    */   public final void update(byte[] b)
/*    */   {
/* 63 */     this.md.update(b);
/*    */   }
/*    */ 
/*    */   public final void update(byte[] b, int off, int len)
/*    */   {
/* 68 */     this.md.update(b, off, len);
/*    */   }
/*    */ 
/*    */   public final void reset()
/*    */   {
/* 73 */     this.md.reset();
/* 74 */     this.md.update(this.k_xor_ipad);
/*    */   }
/*    */ 
/*    */   public final void digest(byte[] out)
/*    */   {
/* 79 */     digest(out, 0);
/*    */   }
/*    */ 
/*    */   public final void digest(byte[] out, int off)
/*    */   {
/* 84 */     this.md.digest(this.tmp);
/*    */ 
/* 86 */     this.md.update(this.k_xor_opad);
/* 87 */     this.md.update(this.tmp);
/*    */ 
/* 89 */     this.md.digest(this.tmp);
/*    */ 
/* 91 */     System.arraycopy(this.tmp, 0, out, off, this.size);
/*    */ 
/* 93 */     this.md.update(this.k_xor_ipad);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.HMAC
 * JD-Core Version:    0.6.0
 */