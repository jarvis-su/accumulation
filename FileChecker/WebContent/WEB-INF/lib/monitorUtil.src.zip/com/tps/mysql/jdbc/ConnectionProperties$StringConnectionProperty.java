/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class ConnectionProperties$StringConnectionProperty extends ConnectionProperties.ConnectionProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5432127962785948272L;
/*     */   private final ConnectionProperties this$0;
/*     */ 
/*     */   ConnectionProperties$StringConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, String defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 489 */     this(this$0, propertyNameToSet, defaultValueToSet, null, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */   }
/*     */ 
/*     */   ConnectionProperties$StringConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, String defaultValueToSet, String[] allowableValuesToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 507 */     super(this$0, propertyNameToSet, defaultValueToSet, allowableValuesToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */ 
/* 506 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   String getValueAsString()
/*     */   {
/* 513 */     return (String)this.valueAsObject;
/*     */   }
/*     */ 
/*     */   boolean hasValueConstraints()
/*     */   {
/* 520 */     return (this.allowableValues != null) && (this.allowableValues.length > 0);
/*     */   }
/*     */ 
/*     */   void initializeFrom(String extractedValue)
/*     */     throws SQLException
/*     */   {
/* 528 */     if (extractedValue != null) {
/* 529 */       validateStringValues(extractedValue);
/*     */ 
/* 531 */       this.valueAsObject = extractedValue;
/*     */     } else {
/* 533 */       this.valueAsObject = this.defaultValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean isRangeBased()
/*     */   {
/* 541 */     return false;
/*     */   }
/*     */ 
/*     */   void setValue(String valueFlag) {
/* 545 */     this.valueAsObject = valueFlag;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.StringConnectionProperty
 * JD-Core Version:    0.6.0
 */