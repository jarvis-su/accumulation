/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class RSAPrivateKey
/*    */ {
/*    */   private BigInteger d;
/*    */   private BigInteger e;
/*    */   private BigInteger n;
/*    */ 
/*    */   public RSAPrivateKey(BigInteger d, BigInteger e, BigInteger n)
/*    */   {
/* 19 */     this.d = d;
/* 20 */     this.e = e;
/* 21 */     this.n = n;
/*    */   }
/*    */ 
/*    */   public BigInteger getD()
/*    */   {
/* 26 */     return this.d;
/*    */   }
/*    */ 
/*    */   public BigInteger getE()
/*    */   {
/* 31 */     return this.e;
/*    */   }
/*    */ 
/*    */   public BigInteger getN()
/*    */   {
/* 36 */     return this.n;
/*    */   }
/*    */ 
/*    */   public RSAPublicKey getPublicKey()
/*    */   {
/* 41 */     return new RSAPublicKey(this.e, this.n);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.RSAPrivateKey
 * JD-Core Version:    0.6.0
 */