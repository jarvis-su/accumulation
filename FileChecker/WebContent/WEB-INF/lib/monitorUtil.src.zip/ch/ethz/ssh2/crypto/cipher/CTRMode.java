/*    */ package ch.ethz.ssh2.crypto.cipher;
/*    */ 
/*    */ public class CTRMode
/*    */   implements BlockCipher
/*    */ {
/*    */   byte[] X;
/*    */   byte[] Xenc;
/*    */   BlockCipher bc;
/*    */   int blockSize;
/*    */   boolean doEncrypt;
/* 19 */   int count = 0;
/*    */ 
/*    */   public void init(boolean forEncryption, byte[] key)
/*    */   {
/*    */   }
/*    */ 
/*    */   public CTRMode(BlockCipher tc, byte[] iv, boolean doEnc) throws IllegalArgumentException
/*    */   {
/* 27 */     this.bc = tc;
/* 28 */     this.blockSize = this.bc.getBlockSize();
/* 29 */     this.doEncrypt = doEnc;
/*    */ 
/* 31 */     if (this.blockSize != iv.length) {
/* 32 */       throw new IllegalArgumentException("IV must be " + this.blockSize + " bytes long! (currently " + iv.length + ")");
/*    */     }
/* 34 */     this.X = new byte[this.blockSize];
/* 35 */     this.Xenc = new byte[this.blockSize];
/*    */ 
/* 37 */     System.arraycopy(iv, 0, this.X, 0, this.blockSize);
/*    */   }
/*    */ 
/*    */   public final int getBlockSize()
/*    */   {
/* 42 */     return this.blockSize;
/*    */   }
/*    */ 
/*    */   public final void transformBlock(byte[] src, int srcoff, byte[] dst, int dstoff)
/*    */   {
/* 47 */     this.bc.transformBlock(this.X, 0, this.Xenc, 0);
/*    */ 
/* 49 */     for (int i = 0; i < this.blockSize; i++)
/*    */     {
/* 51 */       dst[(dstoff + i)] = (byte)(src[(srcoff + i)] ^ this.Xenc[i]);
/*    */     }
/*    */ 
/* 54 */     for (int i = this.blockSize - 1; i >= 0; i--)
/*    */     {
/*    */       int tmp76_74 = i;
/*    */       byte[] tmp76_71 = this.X; tmp76_71[tmp76_74] = (byte)(tmp76_71[tmp76_74] + 1);
/* 57 */       if (this.X[i] != 0)
/*    */         break;
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.CTRMode
 * JD-Core Version:    0.6.0
 */