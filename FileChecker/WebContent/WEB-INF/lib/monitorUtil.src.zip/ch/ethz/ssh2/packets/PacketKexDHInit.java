/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class PacketKexDHInit
/*    */ {
/*    */   byte[] payload;
/*    */   BigInteger e;
/*    */ 
/*    */   public PacketKexDHInit(BigInteger e)
/*    */   {
/* 19 */     this.e = e;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 24 */     if (this.payload == null)
/*    */     {
/* 26 */       TypesWriter tw = new TypesWriter();
/* 27 */       tw.writeByte(30);
/* 28 */       tw.writeMPInt(this.e);
/* 29 */       this.payload = tw.getBytes();
/*    */     }
/* 31 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDHInit
 * JD-Core Version:    0.6.0
 */