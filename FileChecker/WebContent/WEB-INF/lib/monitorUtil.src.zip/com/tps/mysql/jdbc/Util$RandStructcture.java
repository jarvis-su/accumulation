/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ class Util$RandStructcture
/*    */ {
/*    */   long maxValue;
/*    */   double maxValueDbl;
/*    */   long seed1;
/*    */   long seed2;
/*    */   private final Util this$0;
/*    */ 
/*    */   Util$RandStructcture(Util this$0)
/*    */   {
/* 40 */     this.this$0 = this$0;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Util.RandStructcture
 * JD-Core Version:    0.6.0
 */