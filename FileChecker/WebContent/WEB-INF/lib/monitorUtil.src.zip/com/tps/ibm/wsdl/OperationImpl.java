package com.ibm.wsdl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Fault;
import javax.wsdl.Input;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.extensions.ExtensibilityElement;
import org.w3c.dom.Element;

public class OperationImpl
  implements Operation
{
  protected String name = null;
  protected Input input = null;
  protected Output output = null;
  protected Map faults = new HashMap();
  protected OperationType style = null;
  protected List parameterOrder = null;
  protected Element docEl = null;
  protected List extElements = new Vector();
  protected boolean isUndefined = true;
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setInput(Input paramInput)
  {
    this.input = paramInput;
  }

  public Input getInput()
  {
    return this.input;
  }

  public void setOutput(Output paramOutput)
  {
    this.output = paramOutput;
  }

  public Output getOutput()
  {
    return this.output;
  }

  public void addFault(Fault paramFault)
  {
    this.faults.put(paramFault.getName(), paramFault);
  }

  public Fault getFault(String paramString)
  {
    return (Fault)this.faults.get(paramString);
  }

  public Map getFaults()
  {
    return this.faults;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public void setStyle(OperationType paramOperationType)
  {
    this.style = paramOperationType;
  }

  public OperationType getStyle()
  {
    return this.style;
  }

  public void setParameterOrdering(List paramList)
  {
    this.parameterOrder = paramList;
  }

  public List getParameterOrdering()
  {
    return this.parameterOrder;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void setUndefined(boolean paramBoolean)
  {
    this.isUndefined = paramBoolean;
  }

  public boolean isUndefined()
  {
    return this.isUndefined;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Operation: name=" + this.name);
    if (this.parameterOrder != null)
      localStringBuffer.append("\nparameterOrder=" + this.parameterOrder);
    if (this.style != null)
      localStringBuffer.append("\nstyle=" + this.style);
    if (this.input != null)
      localStringBuffer.append("\n" + this.input);
    if (this.output != null)
      localStringBuffer.append("\n" + this.output);
    if (this.faults != null)
    {
      Iterator localIterator = this.faults.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.OperationImpl
 * JD-Core Version:    0.6.0
 */