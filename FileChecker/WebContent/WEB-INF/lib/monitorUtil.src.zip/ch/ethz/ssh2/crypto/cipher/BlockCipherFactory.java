/*     */ package ch.ethz.ssh2.crypto.cipher;
/*     */ 
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class BlockCipherFactory
/*     */ {
/*  30 */   static Vector ciphers = new Vector();
/*     */ 
/*     */   static
/*     */   {
/*  36 */     ciphers.addElement(new CipherEntry("aes256-ctr", 16, 32, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  37 */     ciphers.addElement(new CipherEntry("aes192-ctr", 16, 24, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  38 */     ciphers.addElement(new CipherEntry("aes128-ctr", 16, 16, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  39 */     ciphers.addElement(new CipherEntry("blowfish-ctr", 8, 16, "ch.ethz.ssh2.crypto.cipher.BlowFish"));
/*     */ 
/*  41 */     ciphers.addElement(new CipherEntry("aes256-cbc", 16, 32, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  42 */     ciphers.addElement(new CipherEntry("aes192-cbc", 16, 24, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  43 */     ciphers.addElement(new CipherEntry("aes128-cbc", 16, 16, "ch.ethz.ssh2.crypto.cipher.AES"));
/*  44 */     ciphers.addElement(new CipherEntry("blowfish-cbc", 8, 16, "ch.ethz.ssh2.crypto.cipher.BlowFish"));
/*     */ 
/*  46 */     ciphers.addElement(new CipherEntry("3des-ctr", 8, 24, "ch.ethz.ssh2.crypto.cipher.DESede"));
/*  47 */     ciphers.addElement(new CipherEntry("3des-cbc", 8, 24, "ch.ethz.ssh2.crypto.cipher.DESede"));
/*     */   }
/*     */ 
/*     */   public static String[] getDefaultCipherList()
/*     */   {
/*  52 */     String[] list = new String[ciphers.size()];
/*  53 */     for (int i = 0; i < ciphers.size(); i++)
/*     */     {
/*  55 */       CipherEntry ce = (CipherEntry)ciphers.elementAt(i);
/*  56 */       list[i] = new String(ce.type);
/*     */     }
/*  58 */     return list;
/*     */   }
/*     */ 
/*     */   public static void checkCipherList(String[] cipherCandidates)
/*     */   {
/*  63 */     for (int i = 0; i < cipherCandidates.length; i++)
/*  64 */       getEntry(cipherCandidates[i]);
/*     */   }
/*     */ 
/*     */   public static BlockCipher createCipher(String type, boolean encrypt, byte[] key, byte[] iv)
/*     */   {
/*     */     try
/*     */     {
/*  71 */       CipherEntry ce = getEntry(type);
/*  72 */       Class cc = Class.forName(ce.cipherClass);
/*  73 */       BlockCipher bc = (BlockCipher)cc.newInstance();
/*     */ 
/*  75 */       if (type.endsWith("-cbc"))
/*     */       {
/*  77 */         bc.init(encrypt, key);
/*  78 */         return new CBCMode(bc, iv, encrypt);
/*     */       }
/*  80 */       if (type.endsWith("-ctr"))
/*     */       {
/*  82 */         bc.init(true, key);
/*  83 */         return new CTRMode(bc, iv, encrypt);
/*     */       }
/*  85 */       throw new IllegalArgumentException("Cannot instantiate " + type);
/*     */     }
/*     */     catch (Exception e) {
/*     */     }
/*  89 */     throw new IllegalArgumentException("Cannot instantiate " + type);
/*     */   }
/*     */ 
/*     */   private static CipherEntry getEntry(String type)
/*     */   {
/*  95 */     for (int i = 0; i < ciphers.size(); i++)
/*     */     {
/*  97 */       CipherEntry ce = (CipherEntry)ciphers.elementAt(i);
/*  98 */       if (ce.type.equals(type))
/*  99 */         return ce;
/*     */     }
/* 101 */     throw new IllegalArgumentException("Unkown algorithm " + type);
/*     */   }
/*     */ 
/*     */   public static int getBlockSize(String type)
/*     */   {
/* 106 */     CipherEntry ce = getEntry(type);
/* 107 */     return ce.blocksize;
/*     */   }
/*     */ 
/*     */   public static int getKeySize(String type)
/*     */   {
/* 112 */     CipherEntry ce = getEntry(type);
/* 113 */     return ce.keysize;
/*     */   }
/*     */ 
/*     */   static class CipherEntry
/*     */   {
/*     */     String type;
/*     */     int blocksize;
/*     */     int keysize;
/*     */     String cipherClass;
/*     */ 
/*     */     public CipherEntry(String type, int blockSize, int keySize, String cipherClass)
/*     */     {
/*  23 */       this.type = type;
/*  24 */       this.blocksize = blockSize;
/*  25 */       this.keysize = keySize;
/*  26 */       this.cipherClass = cipherClass;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.BlockCipherFactory
 * JD-Core Version:    0.6.0
 */