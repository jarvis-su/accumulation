/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ class Constants
/*    */ {
/* 38 */   public static final byte[] EMPTY_BYTE_ARRAY = new byte[0];
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Constants
 * JD-Core Version:    0.6.0
 */