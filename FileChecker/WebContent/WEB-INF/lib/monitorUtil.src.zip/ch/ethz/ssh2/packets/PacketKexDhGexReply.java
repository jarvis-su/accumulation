/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class PacketKexDhGexReply
/*    */ {
/*    */   byte[] payload;
/*    */   byte[] hostKey;
/*    */   BigInteger f;
/*    */   byte[] signature;
/*    */ 
/*    */   public PacketKexDhGexReply(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 24 */     this.payload = new byte[len];
/* 25 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 27 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 29 */     int packet_type = tr.readByte();
/*    */ 
/* 31 */     if (packet_type != 33) {
/* 32 */       throw new IOException("This is not a SSH_MSG_KEX_DH_GEX_REPLY! (" + packet_type + ")");
/*    */     }
/* 34 */     this.hostKey = tr.readByteString();
/* 35 */     this.f = tr.readMPINT();
/* 36 */     this.signature = tr.readByteString();
/*    */ 
/* 38 */     if (tr.remain() != 0)
/* 39 */       throw new IOException("PADDING IN SSH_MSG_KEX_DH_GEX_REPLY!");
/*    */   }
/*    */ 
/*    */   public BigInteger getF()
/*    */   {
/* 44 */     return this.f;
/*    */   }
/*    */ 
/*    */   public byte[] getHostKey()
/*    */   {
/* 49 */     return this.hostKey;
/*    */   }
/*    */ 
/*    */   public byte[] getSignature()
/*    */   {
/* 54 */     return this.signature;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDhGexReply
 * JD-Core Version:    0.6.0
 */