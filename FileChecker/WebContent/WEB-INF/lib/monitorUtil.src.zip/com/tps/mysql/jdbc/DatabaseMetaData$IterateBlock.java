/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public abstract class DatabaseMetaData$IterateBlock
/*    */ {
/*    */   DatabaseMetaData.IteratorWithCleanup iterator;
/*    */   private final DatabaseMetaData this$0;
/*    */ 
/*    */   DatabaseMetaData$IterateBlock(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i)
/*    */   {
/* 69 */     this.this$0 = this$0;
/* 70 */     this.iterator = i;
/*    */   }
/*    */ 
/*    */   public void doForAll() throws SQLException {
/*    */     try {
/* 75 */       while (this.iterator.hasNext())
/* 76 */         forEach(this.iterator.next());
/*    */     }
/*    */     finally {
/* 79 */       this.iterator.close();
/*    */     }
/*    */   }
/*    */ 
/*    */   abstract void forEach(Object paramObject)
/*    */     throws SQLException;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.IterateBlock
 * JD-Core Version:    0.6.0
 */