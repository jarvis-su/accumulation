package com.ibm.wsdl.xml;

import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOM2Writer;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.io.Writer;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.AttributeExtensible;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

public class WSDLWriterImpl
  implements WSDLWriter
{
  public void setFeature(String paramString, boolean paramBoolean)
    throws IllegalArgumentException
  {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null.");
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }

  public boolean getFeature(String paramString)
    throws IllegalArgumentException
  {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null.");
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }

  protected void printDefinition(Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramDefinition == null)
      return;
    if (paramDefinition.getPrefix("http://schemas.xmlsoap.org/wsdl/") == null)
    {
      str1 = "wsdl";
      int i = 0;
      while (paramDefinition.getNamespace(str1) != null)
        str1 = "wsdl" + i++;
      paramDefinition.addNamespace(str1, "http://schemas.xmlsoap.org/wsdl/");
    }
    String str1 = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "definitions", paramDefinition);
    paramPrintWriter.print('<' + str1);
    QName localQName = paramDefinition.getQName();
    String str2 = paramDefinition.getTargetNamespace();
    Map localMap = paramDefinition.getNamespaces();
    if (localQName != null)
      DOMUtils.printAttribute("name", localQName.getLocalPart(), paramPrintWriter);
    DOMUtils.printAttribute("targetNamespace", str2, paramPrintWriter);
    printNamespaceDeclarations(localMap, paramPrintWriter);
    paramPrintWriter.println('>');
    printDocumentation(paramDefinition.getDocumentationElement(), paramPrintWriter);
    printImports(paramDefinition.getImports(), paramDefinition, paramPrintWriter);
    printTypes(paramDefinition.getTypes(), paramDefinition, paramPrintWriter);
    printMessages(paramDefinition.getMessages(), paramDefinition, paramPrintWriter);
    printPortTypes(paramDefinition.getPortTypes(), paramDefinition, paramPrintWriter);
    printBindings(paramDefinition.getBindings(), paramDefinition, paramPrintWriter);
    printServices(paramDefinition.getServices(), paramDefinition, paramPrintWriter);
    List localList = paramDefinition.getExtensibilityElements();
    printExtensibilityElements(Definition.class, localList, paramDefinition, paramPrintWriter);
    paramPrintWriter.println("</" + str1 + '>');
    paramPrintWriter.flush();
  }

  protected void printServices(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "service", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        Service localService = (Service)localIterator.next();
        paramPrintWriter.print("  <" + str);
        QName localQName = localService.getQName();
        if (localQName != null)
          DOMUtils.printAttribute("name", localQName.getLocalPart(), paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localService.getDocumentationElement(), paramPrintWriter);
        printPorts(localService.getPorts(), paramDefinition, paramPrintWriter);
        List localList = localService.getExtensibilityElements();
        printExtensibilityElements(Service.class, localList, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("  </" + str + '>');
      }
    }
  }

  protected void printPorts(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "port", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        Port localPort = (Port)localIterator.next();
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", localPort.getName(), paramPrintWriter);
        Binding localBinding = localPort.getBinding();
        if (localBinding != null)
          DOMUtils.printQualifiedAttribute("binding", localBinding.getQName(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localPort.getDocumentationElement(), paramPrintWriter);
        List localList = localPort.getExtensibilityElements();
        printExtensibilityElements(Port.class, localList, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      }
    }
  }

  protected void printBindings(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "binding", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        Binding localBinding = (Binding)localIterator.next();
        if (localBinding.isUndefined())
          continue;
        paramPrintWriter.print("  <" + str);
        QName localQName = localBinding.getQName();
        if (localQName != null)
          DOMUtils.printAttribute("name", localQName.getLocalPart(), paramPrintWriter);
        PortType localPortType = localBinding.getPortType();
        if (localPortType != null)
          DOMUtils.printQualifiedAttribute("type", localPortType.getQName(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localBinding.getDocumentationElement(), paramPrintWriter);
        List localList = localBinding.getExtensibilityElements();
        printExtensibilityElements(Binding.class, localList, paramDefinition, paramPrintWriter);
        printBindingOperations(localBinding.getBindingOperations(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println("  </" + str + '>');
      }
    }
  }

  protected void printBindingOperations(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramList != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "operation", paramDefinition);
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        BindingOperation localBindingOperation = (BindingOperation)localIterator.next();
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", localBindingOperation.getName(), paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localBindingOperation.getDocumentationElement(), paramPrintWriter);
        List localList = localBindingOperation.getExtensibilityElements();
        printExtensibilityElements(BindingOperation.class, localList, paramDefinition, paramPrintWriter);
        printBindingInput(localBindingOperation.getBindingInput(), paramDefinition, paramPrintWriter);
        printBindingOutput(localBindingOperation.getBindingOutput(), paramDefinition, paramPrintWriter);
        printBindingFaults(localBindingOperation.getBindingFaults(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      }
    }
  }

  protected void printBindingInput(BindingInput paramBindingInput, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramBindingInput != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "input", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramBindingInput.getName(), paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramBindingInput.getDocumentationElement(), paramPrintWriter);
      List localList = paramBindingInput.getExtensibilityElements();
      printExtensibilityElements(BindingInput.class, localList, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("      </" + str + '>');
    }
  }

  protected void printBindingOutput(BindingOutput paramBindingOutput, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramBindingOutput != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "output", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramBindingOutput.getName(), paramPrintWriter);
      paramPrintWriter.println('>');
      printDocumentation(paramBindingOutput.getDocumentationElement(), paramPrintWriter);
      List localList = paramBindingOutput.getExtensibilityElements();
      printExtensibilityElements(BindingOutput.class, localList, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("      </" + str + '>');
    }
  }

  protected void printBindingFaults(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "fault", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        BindingFault localBindingFault = (BindingFault)localIterator.next();
        paramPrintWriter.print("      <" + str);
        DOMUtils.printAttribute("name", localBindingFault.getName(), paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localBindingFault.getDocumentationElement(), paramPrintWriter);
        List localList = localBindingFault.getExtensibilityElements();
        printExtensibilityElements(BindingFault.class, localList, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      }
    }
  }

  protected void printPortTypes(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "portType", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        PortType localPortType = (PortType)localIterator.next();
        if (localPortType.isUndefined())
          continue;
        paramPrintWriter.print("  <" + str);
        QName localQName = localPortType.getQName();
        if (localQName != null)
          DOMUtils.printAttribute("name", localQName.getLocalPart(), paramPrintWriter);
        printExtensibilityAttributes(PortType.class, localPortType, paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localPortType.getDocumentationElement(), paramPrintWriter);
        printOperations(localPortType.getOperations(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println("  </" + str + '>');
      }
    }
  }

  protected void printOperations(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramList != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "operation", paramDefinition);
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        Operation localOperation = (Operation)localIterator.next();
        if (localOperation.isUndefined())
          continue;
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", localOperation.getName(), paramPrintWriter);
        DOMUtils.printAttribute("parameterOrder", StringUtils.getNMTokens(localOperation.getParameterOrdering()), paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localOperation.getDocumentationElement(), paramPrintWriter);
        OperationType localOperationType = localOperation.getStyle();
        if (localOperationType == OperationType.ONE_WAY)
        {
          printInput(localOperation.getInput(), paramDefinition, paramPrintWriter);
        }
        else if (localOperationType == OperationType.SOLICIT_RESPONSE)
        {
          printOutput(localOperation.getOutput(), paramDefinition, paramPrintWriter);
          printInput(localOperation.getInput(), paramDefinition, paramPrintWriter);
        }
        else if (localOperationType == OperationType.NOTIFICATION)
        {
          printOutput(localOperation.getOutput(), paramDefinition, paramPrintWriter);
        }
        else
        {
          printInput(localOperation.getInput(), paramDefinition, paramPrintWriter);
          printOutput(localOperation.getOutput(), paramDefinition, paramPrintWriter);
        }
        printFaults(localOperation.getFaults(), paramDefinition, paramPrintWriter);
        List localList = localOperation.getExtensibilityElements();
        printExtensibilityElements(Operation.class, localList, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("    </" + str + '>');
      }
    }
  }

  protected void printInput(Input paramInput, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramInput != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "input", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramInput.getName(), paramPrintWriter);
      Message localMessage = paramInput.getMessage();
      if (localMessage != null)
        DOMUtils.printQualifiedAttribute("message", localMessage.getQName(), paramDefinition, paramPrintWriter);
      printExtensibilityAttributes(Input.class, paramInput, paramDefinition, paramPrintWriter);
      Element localElement = paramInput.getDocumentationElement();
      if (localElement == null)
      {
        paramPrintWriter.println("/>");
      }
      else
      {
        paramPrintWriter.println('>');
        printDocumentation(localElement, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      }
    }
  }

  protected void printOutput(Output paramOutput, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramOutput != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "output", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("name", paramOutput.getName(), paramPrintWriter);
      Message localMessage = paramOutput.getMessage();
      if (localMessage != null)
        DOMUtils.printQualifiedAttribute("message", localMessage.getQName(), paramDefinition, paramPrintWriter);
      printExtensibilityAttributes(Output.class, paramOutput, paramDefinition, paramPrintWriter);
      Element localElement = paramOutput.getDocumentationElement();
      if (localElement == null)
      {
        paramPrintWriter.println("/>");
      }
      else
      {
        paramPrintWriter.println('>');
        printDocumentation(localElement, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      }
    }
  }

  protected void printFaults(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "fault", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        Fault localFault = (Fault)localIterator.next();
        paramPrintWriter.print("      <" + str);
        DOMUtils.printAttribute("name", localFault.getName(), paramPrintWriter);
        Message localMessage = localFault.getMessage();
        if (localMessage != null)
          DOMUtils.printQualifiedAttribute("message", localMessage.getQName(), paramDefinition, paramPrintWriter);
        printExtensibilityAttributes(Fault.class, localFault, paramDefinition, paramPrintWriter);
        Element localElement = localFault.getDocumentationElement();
        if (localElement == null)
        {
          paramPrintWriter.println("/>");
          continue;
        }
        paramPrintWriter.println('>');
        printDocumentation(localElement, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      }
    }
  }

  protected void printMessages(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "message", paramDefinition);
      Iterator localIterator = paramMap.values().iterator();
      while (localIterator.hasNext())
      {
        Message localMessage = (Message)localIterator.next();
        if (localMessage.isUndefined())
          continue;
        paramPrintWriter.print("  <" + str);
        QName localQName = localMessage.getQName();
        if (localQName != null)
          DOMUtils.printAttribute("name", localQName.getLocalPart(), paramPrintWriter);
        paramPrintWriter.println('>');
        printDocumentation(localMessage.getDocumentationElement(), paramPrintWriter);
        printParts(localMessage.getOrderedParts(null), paramDefinition, paramPrintWriter);
        List localList = localMessage.getExtensibilityElements();
        printExtensibilityElements(Message.class, localList, paramDefinition, paramPrintWriter);
        paramPrintWriter.println("  </" + str + '>');
      }
    }
  }

  protected void printParts(List paramList, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramList != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "part", paramDefinition);
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        Part localPart = (Part)localIterator.next();
        paramPrintWriter.print("    <" + str);
        DOMUtils.printAttribute("name", localPart.getName(), paramPrintWriter);
        DOMUtils.printQualifiedAttribute("element", localPart.getElementName(), paramDefinition, paramPrintWriter);
        DOMUtils.printQualifiedAttribute("type", localPart.getTypeName(), paramDefinition, paramPrintWriter);
        printExtensibilityAttributes(Part.class, localPart, paramDefinition, paramPrintWriter);
        Element localElement = localPart.getDocumentationElement();
        if (localElement == null)
        {
          paramPrintWriter.println("/>");
          continue;
        }
        paramPrintWriter.println('>');
        printDocumentation(localElement, paramPrintWriter);
        paramPrintWriter.println("      </" + str + '>');
      }
    }
  }

  protected void printExtensibilityAttributes(Class paramClass, AttributeExtensible paramAttributeExtensible, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    Map localMap = paramAttributeExtensible.getExtensionAttributes();
    Iterator localIterator = localMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      QName localQName1 = (QName)localIterator.next();
      Object localObject1 = localMap.get(localQName1);
      String str = null;
      QName localQName2 = null;
      if ((localObject1 instanceof String))
      {
        str = (String)localObject1;
      }
      else if ((localObject1 instanceof QName))
      {
        localQName2 = (QName)localObject1;
      }
      else if ((localObject1 instanceof List))
      {
        List localList = (List)localObject1;
        int i = localList.size();
        if (i > 0)
        {
          Object localObject2 = localList.get(0);
          if ((localObject2 instanceof String))
          {
            str = StringUtils.getNMTokens(localList);
          }
          else if ((localObject2 instanceof QName))
          {
            StringBuffer localStringBuffer = new StringBuffer();
            for (int j = 0; j < i; j++)
            {
              QName localQName3 = (QName)localList.get(j);
              localStringBuffer.append((j > 0 ? " " : "") + DOMUtils.getQualifiedValue(localQName3.getNamespaceURI(), localQName3.getLocalPart(), paramDefinition));
            }
            str = localStringBuffer.toString();
          }
          else
          {
            throw new WSDLException("CONFIGURATION_ERROR", "Unknown type of extension attribute '" + localQName1 + "': " + localObject2.getClass().getName());
          }
        }
        else
        {
          str = "";
        }
      }
      else
      {
        throw new WSDLException("CONFIGURATION_ERROR", "Unknown type of extension attribute '" + localQName1 + "': " + localObject1.getClass().getName());
      }
      if (localQName2 != null)
      {
        DOMUtils.printQualifiedAttribute(localQName1, localQName2, paramDefinition, paramPrintWriter);
        continue;
      }
      DOMUtils.printQualifiedAttribute(localQName1, str, paramDefinition, paramPrintWriter);
    }
  }

  protected void printDocumentation(Element paramElement, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramElement != null)
    {
      DOM2Writer.serializeAsXML(paramElement, paramPrintWriter);
      paramPrintWriter.println();
    }
  }

  protected void printTypes(Types paramTypes, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramTypes != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "types", paramDefinition);
      paramPrintWriter.print("  <" + str);
      paramPrintWriter.println('>');
      printDocumentation(paramTypes.getDocumentationElement(), paramPrintWriter);
      List localList = paramTypes.getExtensibilityElements();
      printExtensibilityElements(Types.class, localList, paramDefinition, paramPrintWriter);
      paramPrintWriter.println("  </" + str + '>');
    }
  }

  protected void printImports(Map paramMap, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/", "import", paramDefinition);
      Iterator localIterator1 = paramMap.values().iterator();
      while (localIterator1.hasNext())
      {
        List localList = (List)localIterator1.next();
        Iterator localIterator2 = localList.iterator();
        while (localIterator2.hasNext())
        {
          Import localImport = (Import)localIterator2.next();
          paramPrintWriter.print("  <" + str);
          DOMUtils.printAttribute("namespace", localImport.getNamespaceURI(), paramPrintWriter);
          DOMUtils.printAttribute("location", localImport.getLocationURI(), paramPrintWriter);
          printExtensibilityAttributes(Import.class, localImport, paramDefinition, paramPrintWriter);
          Element localElement = localImport.getDocumentationElement();
          if (localElement == null)
          {
            paramPrintWriter.println("/>");
            continue;
          }
          paramPrintWriter.println('>');
          printDocumentation(localElement, paramPrintWriter);
          paramPrintWriter.println("      </" + str + '>');
        }
      }
    }
  }

  protected void printNamespaceDeclarations(Map paramMap, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramMap != null)
    {
      Set localSet = paramMap.keySet();
      Iterator localIterator = localSet.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (str == null)
          str = "";
        DOMUtils.printAttribute("xmlns" + (!str.equals("") ? ":" + str : ""), (String)paramMap.get(str), paramPrintWriter);
      }
    }
  }

  protected void printExtensibilityElements(Class paramClass, List paramList, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramList != null)
    {
      Iterator localIterator = paramList.iterator();
      while (localIterator.hasNext())
      {
        ExtensibilityElement localExtensibilityElement = (ExtensibilityElement)localIterator.next();
        QName localQName = localExtensibilityElement.getElementType();
        ExtensionRegistry localExtensionRegistry = paramDefinition.getExtensionRegistry();
        if (localExtensionRegistry == null)
          throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to serialize a '" + localQName + "' element in the context of a '" + paramClass.getName() + "'.");
        ExtensionSerializer localExtensionSerializer = localExtensionRegistry.querySerializer(paramClass, localQName);
        localExtensionSerializer.marshall(paramClass, localQName, localExtensibilityElement, paramPrintWriter, paramDefinition, localExtensionRegistry);
      }
    }
  }

  private static Document getDocument(InputSource paramInputSource, String paramString)
    throws WSDLException
  {
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    localDocumentBuilderFactory.setNamespaceAware(true);
    localDocumentBuilderFactory.setValidating(false);
    try
    {
      DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
      Document localDocument = localDocumentBuilder.parse(paramInputSource);
      return localDocument;
    }
    catch (Throwable localThrowable)
    {
    }
    throw new WSDLException("PARSER_ERROR", "Problem parsing '" + paramString + "'.", localThrowable);
  }

  public Document getDocument(Definition paramDefinition)
    throws WSDLException
  {
    StringWriter localStringWriter = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
    writeWSDL(paramDefinition, localPrintWriter);
    StringReader localStringReader = new StringReader(localStringWriter.toString());
    InputSource localInputSource = new InputSource(localStringReader);
    return getDocument(localInputSource, "- WSDL Document -");
  }

  public void writeWSDL(Definition paramDefinition, Writer paramWriter)
    throws WSDLException
  {
    PrintWriter localPrintWriter = new PrintWriter(paramWriter);
    String str1 = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    String str2 = DOM2Writer.java2XMLEncoding(str1);
    if (str2 == null)
      throw new WSDLException("CONFIGURATION_ERROR", "Unsupported Java encoding for writing wsdl file: '" + str1 + "'.");
    localPrintWriter.println("<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>");
    printDefinition(paramDefinition, localPrintWriter);
  }

  public void writeWSDL(Definition paramDefinition, OutputStream paramOutputStream)
    throws WSDLException
  {
    OutputStreamWriter localOutputStreamWriter = null;
    try
    {
      localOutputStreamWriter = new OutputStreamWriter(paramOutputStream, "UTF8");
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      localUnsupportedEncodingException.printStackTrace();
      localOutputStreamWriter = new OutputStreamWriter(paramOutputStream);
    }
    writeWSDL(paramDefinition, localOutputStreamWriter);
  }

  public static void main(String[] paramArrayOfString)
    throws WSDLException
  {
    if (paramArrayOfString.length == 1)
    {
      WSDLFactory localWSDLFactory = WSDLFactory.newInstance();
      WSDLReader localWSDLReader = localWSDLFactory.newWSDLReader();
      WSDLWriter localWSDLWriter = localWSDLFactory.newWSDLWriter();
      localWSDLWriter.writeWSDL(localWSDLReader.readWSDL(null, paramArrayOfString[0]), System.out);
    }
    else
    {
      System.err.println("Usage:");
      System.err.println();
      System.err.println("  java " + WSDLWriterImpl.class.getName() + " filename|URL");
      System.err.println();
      System.err.println("This test driver simply reads a WSDL document into a model (using a WSDLReader), and then serializes it back to standard out. In effect, it performs a round-trip test on the specified WSDL document.");
    }
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.xml.WSDLWriterImpl
 * JD-Core Version:    0.6.0
 */