/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class PacketKexDHReply
/*    */ {
/*    */   byte[] payload;
/*    */   byte[] hostKey;
/*    */   BigInteger f;
/*    */   byte[] signature;
/*    */ 
/*    */   public PacketKexDHReply(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 23 */     this.payload = new byte[len];
/* 24 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 26 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 28 */     int packet_type = tr.readByte();
/*    */ 
/* 30 */     if (packet_type != 31) {
/* 31 */       throw new IOException("This is not a SSH_MSG_KEXDH_REPLY! (" + 
/* 32 */         packet_type + ")");
/*    */     }
/* 34 */     this.hostKey = tr.readByteString();
/* 35 */     this.f = tr.readMPINT();
/* 36 */     this.signature = tr.readByteString();
/*    */ 
/* 38 */     if (tr.remain() != 0) throw new IOException("PADDING IN SSH_MSG_KEXDH_REPLY!");
/*    */   }
/*    */ 
/*    */   public BigInteger getF()
/*    */   {
/* 43 */     return this.f;
/*    */   }
/*    */ 
/*    */   public byte[] getHostKey()
/*    */   {
/* 48 */     return this.hostKey;
/*    */   }
/*    */ 
/*    */   public byte[] getSignature()
/*    */   {
/* 53 */     return this.signature;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDHReply
 * JD-Core Version:    0.6.0
 */