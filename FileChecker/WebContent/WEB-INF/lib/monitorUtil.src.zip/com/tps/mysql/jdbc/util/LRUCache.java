/*    */ package com.mysql.jdbc.util;
/*    */ 
/*    */ import java.util.LinkedHashMap;
/*    */ import java.util.Map.Entry;
/*    */ 
/*    */ public class LRUCache extends LinkedHashMap
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   protected int maxElements;
/*    */ 
/*    */   public LRUCache(int maxSize)
/*    */   {
/* 39 */     super(maxSize);
/* 40 */     this.maxElements = maxSize;
/*    */   }
/*    */ 
/*    */   protected boolean removeEldestEntry(Map.Entry eldest)
/*    */   {
/* 49 */     return size() > this.maxElements;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.util.LRUCache
 * JD-Core Version:    0.6.0
 */