/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketNewKeys
/*    */ {
/*    */   byte[] payload;
/*    */ 
/*    */   public PacketNewKeys()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PacketNewKeys(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 21 */     this.payload = new byte[len];
/* 22 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 24 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 26 */     int packet_type = tr.readByte();
/*    */ 
/* 28 */     if (packet_type != 21) {
/* 29 */       throw new IOException("This is not a SSH_MSG_NEWKEYS! (" + 
/* 30 */         packet_type + ")");
/*    */     }
/* 32 */     if (tr.remain() != 0)
/* 33 */       throw new IOException("Padding in SSH_MSG_NEWKEYS packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 38 */     if (this.payload == null)
/*    */     {
/* 40 */       TypesWriter tw = new TypesWriter();
/* 41 */       tw.writeByte(21);
/* 42 */       this.payload = tw.getBytes();
/*    */     }
/* 44 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketNewKeys
 * JD-Core Version:    0.6.0
 */