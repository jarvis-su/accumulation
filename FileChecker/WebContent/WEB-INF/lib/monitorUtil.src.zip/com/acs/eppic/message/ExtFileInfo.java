/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ExtFileInfo extends InfoData
/*    */ {
/*    */   private static final long serialVersionUID = 4718891861140740769L;
/*    */   private static final String FILENAME = "FILENAME";
/*    */   private static final String NUM_PROCESSED = "NUM_PROCESSED";
/*    */   private static final String NUM_REJECTED = "NUM_REJECTED";
/*    */   private static final String REC_LENGTH = "REC_LENGTH";
/*    */ 
/*    */   public ExtFileInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ExtFileInfo(HashMap map)
/*    */   {
/* 21 */     setData(map);
/*    */   }
/*    */ 
/*    */   public ExtFileInfo(String filename, int numProcessed, int numRejected, int recLength, boolean isStart) {
/* 25 */     super(isStart);
/* 26 */     setData("FILENAME", filename);
/* 27 */     setData("NUM_PROCESSED", new Integer(numProcessed));
/* 28 */     setData("NUM_REJECTED", new Integer(numRejected));
/* 29 */     setData("REC_LENGTH", new Integer(recLength));
/*    */   }
/*    */ 
/*    */   public String getFilename() {
/* 33 */     String filename = "";
/* 34 */     if (getData("FILENAME") != null) {
/* 35 */       filename = (String)getData("FILENAME");
/*    */     }
/* 37 */     return filename;
/*    */   }
/*    */ 
/*    */   public int getNumProcessed() {
/* 41 */     int retVal = -1;
/* 42 */     if (getData("NUM_PROCESSED") != null) {
/* 43 */       retVal = ((Integer)getData("NUM_PROCESSED")).intValue();
/*    */     }
/* 45 */     return retVal;
/*    */   }
/*    */ 
/*    */   public int getNumRejected() {
/* 49 */     int retVal = -1;
/* 50 */     if (getData("NUM_REJECTED") != null) {
/* 51 */       retVal = ((Integer)getData("NUM_REJECTED")).intValue();
/*    */     }
/* 53 */     return retVal;
/*    */   }
/*    */ 
/*    */   public int getRecLength() {
/* 57 */     int retVal = -1;
/* 58 */     if (getData("REC_LENGTH") != null) {
/* 59 */       retVal = ((Integer)getData("REC_LENGTH")).intValue();
/*    */     }
/* 61 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 65 */     return 
/* 66 */       super.toString() + 
/* 67 */       "  Filename: " + getFilename() + "\n" + 
/* 68 */       "  Num Records: " + getRecLength() + "\n" + 
/* 69 */       "  Num Processed: " + getNumProcessed() + "\n" + 
/* 70 */       "  Num Rejected: " + getNumRejected() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.ExtFileInfo
 * JD-Core Version:    0.6.0
 */