/*     */ package ch.ethz.ssh2.crypto.cipher;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class CipherInputStream
/*     */ {
/*     */   BlockCipher currentCipher;
/*     */   InputStream bi;
/*     */   byte[] buffer;
/*     */   byte[] enc;
/*     */   int blockSize;
/*     */   int pos;
/*  27 */   final int BUFF_SIZE = 2048;
/*  28 */   byte[] input_buffer = new byte[2048];
/*  29 */   int input_buffer_pos = 0;
/*  30 */   int input_buffer_size = 0;
/*     */ 
/*     */   public CipherInputStream(BlockCipher tc, InputStream bi)
/*     */   {
/*  34 */     this.bi = bi;
/*  35 */     changeCipher(tc);
/*     */   }
/*     */ 
/*     */   private int fill_buffer() throws IOException
/*     */   {
/*  40 */     this.input_buffer_pos = 0;
/*  41 */     this.input_buffer_size = this.bi.read(this.input_buffer, 0, 2048);
/*  42 */     return this.input_buffer_size;
/*     */   }
/*     */ 
/*     */   private int internal_read(byte[] b, int off, int len) throws IOException
/*     */   {
/*  47 */     if (this.input_buffer_size < 0) {
/*  48 */       return -1;
/*     */     }
/*  50 */     if (this.input_buffer_pos >= this.input_buffer_size)
/*     */     {
/*  52 */       if (fill_buffer() <= 0) {
/*  53 */         return -1;
/*     */       }
/*     */     }
/*  56 */     int avail = this.input_buffer_size - this.input_buffer_pos;
/*  57 */     int thiscopy = len > avail ? avail : len;
/*     */ 
/*  59 */     System.arraycopy(this.input_buffer, this.input_buffer_pos, b, off, thiscopy);
/*  60 */     this.input_buffer_pos += thiscopy;
/*     */ 
/*  62 */     return thiscopy;
/*     */   }
/*     */ 
/*     */   public void changeCipher(BlockCipher bc)
/*     */   {
/*  67 */     this.currentCipher = bc;
/*  68 */     this.blockSize = bc.getBlockSize();
/*  69 */     this.buffer = new byte[this.blockSize];
/*  70 */     this.enc = new byte[this.blockSize];
/*  71 */     this.pos = this.blockSize;
/*     */   }
/*     */ 
/*     */   private void getBlock() throws IOException
/*     */   {
/*  76 */     int n = 0;
/*  77 */     while (n < this.blockSize)
/*     */     {
/*  79 */       int len = internal_read(this.enc, n, this.blockSize - n);
/*  80 */       if (len < 0)
/*  81 */         throw new IOException("Cannot read full block, EOF reached.");
/*  82 */       n += len;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/*  87 */       this.currentCipher.transformBlock(this.enc, 0, this.buffer, 0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  91 */       throw new IOException("Error while decrypting block.");
/*     */     }
/*  93 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public int read(byte[] dst) throws IOException
/*     */   {
/*  98 */     return read(dst, 0, dst.length);
/*     */   }
/*     */ 
/*     */   public int read(byte[] dst, int off, int len) throws IOException
/*     */   {
/* 103 */     int count = 0;
/*     */ 
/* 105 */     while (len > 0)
/*     */     {
/* 107 */       if (this.pos >= this.blockSize) {
/* 108 */         getBlock();
/*     */       }
/* 110 */       int avail = this.blockSize - this.pos;
/* 111 */       int copy = Math.min(avail, len);
/* 112 */       System.arraycopy(this.buffer, this.pos, dst, off, copy);
/* 113 */       this.pos += copy;
/* 114 */       off += copy;
/* 115 */       len -= copy;
/* 116 */       count += copy;
/*     */     }
/* 118 */     return count;
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/* 123 */     if (this.pos >= this.blockSize)
/*     */     {
/* 125 */       getBlock();
/*     */     }
/* 127 */     return this.buffer[(this.pos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public int readPlain(byte[] b, int off, int len) throws IOException
/*     */   {
/* 132 */     if (this.pos != this.blockSize)
/* 133 */       throw new IOException("Cannot read plain since crypto buffer is not aligned.");
/* 134 */     int n = 0;
/* 135 */     while (n < len)
/*     */     {
/* 137 */       int cnt = internal_read(b, off + n, len - n);
/* 138 */       if (cnt < 0)
/* 139 */         throw new IOException("Cannot fill buffer, EOF reached.");
/* 140 */       n += cnt;
/*     */     }
/* 142 */     return n;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.CipherInputStream
 * JD-Core Version:    0.6.0
 */