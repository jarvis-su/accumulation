package com.ibm.wsdl.util;

import java.util.Hashtable;

public class ObjectRegistry
{
  Hashtable reg = new Hashtable();
  ObjectRegistry parent = null;

  public ObjectRegistry()
  {
  }

  public ObjectRegistry(ObjectRegistry paramObjectRegistry)
  {
    this.parent = paramObjectRegistry;
  }

  public void register(String paramString, Object paramObject)
  {
    this.reg.put(paramString, paramObject);
  }

  public void unregister(String paramString)
  {
    this.reg.remove(paramString);
  }

  public Object lookup(String paramString)
    throws IllegalArgumentException
  {
    Object localObject = this.reg.get(paramString);
    if ((localObject == null) && (this.parent != null))
      localObject = this.parent.lookup(paramString);
    if (localObject == null)
      throw new IllegalArgumentException("object '" + paramString + "' not in registry");
    return localObject;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.ObjectRegistry
 * JD-Core Version:    0.6.0
 */