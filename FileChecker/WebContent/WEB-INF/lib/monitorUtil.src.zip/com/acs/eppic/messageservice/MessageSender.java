/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import com.acs.eppic.message.ReportInfo;
/*     */ import com.acs.eppic.messageservice.web.MessageWebService;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.io.PrintStream;
/*     */ import java.net.URL;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MessageSender
/*     */ {
/*     */   protected static final String CONFIG_SOURCE_FILENAME = "com_acs_eppic_messagingservice_properties";
/*  19 */   protected static final Logger logger = Logger.getLogger("MessageService");
/*  20 */   private String systemId = "MONITOR";
/*  21 */   private String systemPort = "8080";
/*  22 */   private String serviceId = "REPORTS";
/*     */   private OutgoingQueue outgoingQueue;
/*  26 */   private int maxSendingQueueSize = 25;
/*  27 */   private int maxAlertQueueSize = 25;
/*  28 */   private int maxMessageQueueSize = 25;
/*  29 */   private int messageNotificationQueueSize = 0;
/*  30 */   private int resend_interval = 10;
/*     */ 
/*  33 */   private boolean serviceEnabled = false;
/*     */   private String monitorHost;
/*     */   private String monitorPort;
/*     */   private String monitorUrl;
/*     */   private HashMap sentMap;
/*     */ 
/*     */   public MessageSender()
/*     */   {
/*  44 */     ConfigFileReader pfr = new ConfigFileReader("com_acs_eppic_messagingservice_properties");
/*  45 */     init(pfr);
/*     */   }
/*     */ 
/*     */   public MessageSender(String configFileName)
/*     */   {
/*  53 */     ConfigFileReader pfr = new ConfigFileReader(configFileName, false);
/*  54 */     init(pfr);
/*     */   }
/*     */ 
/*     */   public MessageSender(String systemId, String serviceId, String systemPort, String monitorHost, String monitorPort, String monitorURL, int maxSendingQueueSize, int maxAlertQueueSize, int maxMessageQueueSize, int messageNotificationQueueSize)
/*     */   {
/*  75 */     this.systemId = systemId;
/*  76 */     this.serviceId = serviceId;
/*  77 */     this.systemPort = systemPort;
/*  78 */     this.monitorHost = monitorHost;
/*  79 */     this.monitorPort = monitorPort;
/*  80 */     this.monitorUrl = monitorURL;
/*  81 */     this.maxSendingQueueSize = maxSendingQueueSize;
/*  82 */     this.maxAlertQueueSize = maxAlertQueueSize;
/*  83 */     this.maxMessageQueueSize = maxMessageQueueSize;
/*  84 */     this.messageNotificationQueueSize = messageNotificationQueueSize;
/*  85 */     init(null);
/*     */   }
/*     */ 
/*     */   protected void init(ConfigFileReader pfr)
/*     */   {
/*  95 */     if (pfr != null) {
/*     */       try {
/*  97 */         this.monitorHost = pfr.readConfigValueString("service.host");
/*  98 */         this.monitorPort = pfr.readConfigValueString("service.port");
/*  99 */         this.monitorUrl = pfr.readConfigValueString("service.urlpath");
/* 100 */         this.systemId = pfr.readConfigValueString("system.name");
/* 101 */         this.systemPort = pfr.readConfigValueString("system.port");
/* 102 */         this.serviceEnabled = (pfr.readConfigValueString("service.enabled").compareToIgnoreCase("true") == 0);
/* 103 */         this.resend_interval = pfr.readConfigValueInteger("resend.interval");
/* 104 */         this.maxSendingQueueSize = pfr.readConfigValueInteger("max.send.queueSize");
/* 105 */         this.maxAlertQueueSize = pfr.readConfigValueInteger("max.alert.queueSize");
/* 106 */         this.maxMessageQueueSize = pfr.readConfigValueInteger("max.message.queueSize");
/* 107 */         this.messageNotificationQueueSize = pfr.readConfigValueInteger("message.notify.queueSize");
/*     */       } catch (Exception e) {
/* 109 */         logger.error("ERROR Starting Messaging Service.", e);
/*     */       }
/*     */     }
/* 112 */     this.outgoingQueue = new OutgoingQueue();
/*     */   }
/*     */ 
/*     */   public String getSystemId()
/*     */   {
/* 117 */     return this.systemId;
/*     */   }
/*     */ 
/*     */   public String getServiceId()
/*     */   {
/* 122 */     return this.serviceId;
/*     */   }
/*     */ 
/*     */   public String getSystemPort()
/*     */   {
/* 127 */     return this.systemPort;
/*     */   }
/*     */ 
/*     */   public boolean isServiceEnabled()
/*     */   {
/* 132 */     return this.serviceEnabled;
/*     */   }
/*     */ 
/*     */   public void setServiceEnabled(boolean isEnabled) {
/* 136 */     this.serviceEnabled = isEnabled;
/* 137 */     this.outgoingQueue.disable();
/*     */   }
/*     */ 
/*     */   private String createURL(String host, String port) {
/* 141 */     return "http://" + host.trim() + ":" + port.trim() + "/" + this.monitorUrl;
/*     */   }
/*     */ 
/*     */   private String createURL() {
/* 145 */     return createURL(this.monitorHost, this.monitorPort);
/*     */   }
/*     */ 
/*     */   public int getMaxSendingQueueSize() {
/* 149 */     return this.maxSendingQueueSize;
/*     */   }
/*     */ 
/*     */   public void setMaxSendingQueueSize(int maxSendingQueueSize) {
/* 153 */     this.maxSendingQueueSize = maxSendingQueueSize;
/*     */   }
/*     */ 
/*     */   public int getMaxAlertQueueSize() {
/* 157 */     return this.maxAlertQueueSize;
/*     */   }
/*     */ 
/*     */   public void setMaxAlertQueueSize(int maxAlertQueueSize) {
/* 161 */     this.maxAlertQueueSize = maxAlertQueueSize;
/*     */   }
/*     */ 
/*     */   public int getMaxMessageQueueSize() {
/* 165 */     return this.maxMessageQueueSize;
/*     */   }
/*     */ 
/*     */   public void setMaxMessageQueueSize(int maxMessageQueueSize) {
/* 169 */     this.maxMessageQueueSize = maxMessageQueueSize;
/*     */   }
/*     */ 
/*     */   public int getMessageNotificationQueueSize() {
/* 173 */     return this.messageNotificationQueueSize;
/*     */   }
/*     */ 
/*     */   public void setMessageNotificationQueueSize(int messageNotificationQueueSize) {
/* 177 */     this.messageNotificationQueueSize = messageNotificationQueueSize;
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message)
/*     */   {
/* 182 */     if (isServiceEnabled())
/* 183 */       this.outgoingQueue.enqueue(message);
/*     */   }
/*     */ 
/*     */   public static void usage(int argSize)
/*     */   {
/* 326 */     System.out.println("Usage:\nOPTION 1\nMessageSender [systemId] [serviceId] [systemPort] [Monitor Host] [Monitor Port] [Monitor URL] [MaxSendingQueueSize] [maxAlertQueueSize] [maxMessageQueueSize] [messageNotificationQueueSize]\n");
/*     */ 
/* 331 */     System.out.println(
/* 332 */       "OPTION 2\nMessageSender\n");
/* 333 */     System.out.println("Example:\nOPTION 1\nMessageSender CAEBT TESTSERVICE 64531 CE-FINLEY 8080 monitor/servies/MessageWebService 100 1000 1000 1\n");
/*     */ 
/* 335 */     System.out.println(
/* 336 */       "OPTION 2\nMessageSender\n");
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 340 */     if ((args.length != 10) && (args.length != 0)) {
/* 341 */       usage(args.length);
/*     */     } else {
/* 343 */       MessageSender ms = null;
/* 344 */       if (args.length == 10) {
/* 345 */         String systemId = args[0];
/* 346 */         String serviceId = args[1];
/* 347 */         String systemPort = args[2];
/* 348 */         String monitorHost = args[3];
/* 349 */         String monitorPort = args[4];
/* 350 */         String monitorURL = args[5];
/* 351 */         int maxSendingQueueSize = Integer.parseInt(args[6]);
/* 352 */         int maxAlertQueueSize = Integer.parseInt(args[7]);
/* 353 */         int maxMessageQueueSize = Integer.parseInt(args[8]);
/* 354 */         int messageNotificationQueueSize = Integer.parseInt(args[9]);
/*     */ 
/* 356 */         ms = new MessageSender(systemId, serviceId, systemPort, 
/* 357 */           monitorHost, monitorPort, monitorURL, 
/* 358 */           maxSendingQueueSize, maxAlertQueueSize, 
/* 359 */           maxMessageQueueSize, messageNotificationQueueSize);
/*     */       } else {
/* 361 */         ms = new MessageSender();
/*     */       }
/* 363 */       Message m = new Message(ms.getSystemId(), ms.getServiceId(), 4, ms.getSystemPort());
/* 364 */       m.setM_MessageData(new ReportInfo("ADMINISTRATIVEACTIVITY", false, true));
/* 365 */       ms.enqueue(m);
/*     */       try {
/* 367 */         Thread.sleep(1000L);
/*     */       } catch (InterruptedException e) {
/* 369 */         e.printStackTrace();
/*     */       }
/* 371 */       m = new Message(ms.getSystemId(), ms.getServiceId(), 4, ms.getSystemPort());
/* 372 */       m.setM_MessageData(new ReportInfo("ADMINISTRATIVEACTIVITY", false, false));
/* 373 */       ms.enqueue(m);
/*     */       try {
/* 375 */         Thread.sleep(3000L);
/*     */       } catch (InterruptedException e) {
/* 377 */         e.printStackTrace();
/*     */       }
/* 379 */       ms.setServiceEnabled(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isOkToSend(String hashKey)
/*     */   {
/* 385 */     if (!isServiceEnabled()) {
/* 386 */       return false;
/*     */     }
/*     */ 
/* 389 */     boolean sendIt = false;
/*     */ 
/* 391 */     Date d2 = new Date();
/*     */ 
/* 393 */     Date d1 = (Date)this.sentMap.get(hashKey);
/* 394 */     if ((d1 == null) || (d2.getTime() - d1.getTime() > this.resend_interval * 1000))
/*     */     {
/* 396 */       this.sentMap.put(hashKey, d2);
/* 397 */       sendIt = true;
/*     */     }
/* 399 */     return sendIt;
/*     */   }
/*     */ 
/*     */   private class OutgoingQueue
/*     */   {
/*     */     private final QueueWorker[] threads;
/*     */     private final LinkedList alertQueue;
/*     */     private final LinkedList messageQueue;
/*     */     private MessageWebServiceServiceLocator mwsl;
/* 193 */     Object semObj = new Object();
/*     */ 
/*     */     public OutgoingQueue() {
/* 196 */       this.mwsl = new MessageWebServiceServiceLocator();
/* 197 */       this.alertQueue = new LinkedList();
/* 198 */       this.messageQueue = new LinkedList();
/* 199 */       this.threads = new QueueWorker[1];
/* 200 */       for (int i = 0; i < this.threads.length; i++) {
/* 201 */         this.threads[i] = new QueueWorker(null);
/* 202 */         this.threads[i].setName("OUTGOING_QUEUE_" + i);
/* 203 */         this.threads[i].start();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void disable()
/*     */     {
/* 210 */       synchronized (this.semObj) {
/* 211 */         this.semObj.notifyAll();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void enqueue(Message message) {
/* 216 */       boolean notify = false;
/* 217 */       if ((message.getServiceId() == "HEARTBEAT") || 
/* 218 */         (message.getType().getTypeId() == 1) || 
/* 219 */         (message.getType().getTypeId() == 0))
/*     */       {
/* 221 */         synchronized (this.alertQueue) {
/* 222 */           this.alertQueue.addLast(message);
/* 223 */           if (this.alertQueue.size() <= MessageSender.this.maxAlertQueueSize)
/* 224 */             notify = true;
/*     */           else {
/* 226 */             notify = false;
/*     */           }
/*     */         }
/*     */       }
/* 230 */       synchronized (this.messageQueue) {
/* 231 */         if (this.messageQueue.size() <= MessageSender.this.maxMessageQueueSize) {
/* 232 */           this.messageQueue.addLast(message);
/* 233 */           if (this.messageQueue.size() >= MessageSender.this.messageNotificationQueueSize)
/* 234 */             notify = true;
/*     */           else {
/* 236 */             notify = false;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 241 */       if (notify)
/* 242 */         synchronized (this.semObj) {
/* 243 */           this.semObj.notifyAll();
/*     */         }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 319 */       return "CLASS: OutgoingQueue\n";
/*     */     }
/*     */ 
/*     */     private class QueueWorker extends Thread
/*     */     {
/* 253 */       boolean alertQueueWait = false;
/* 254 */       boolean messageQueueWait = false;
/*     */ 
/*     */       private QueueWorker() {  } 
/* 256 */       public void run() { List messageList = new LinkedList();
/*     */ 
/* 259 */         while (MessageSender.this.isServiceEnabled()) {
/* 260 */           messageList.clear();
/* 261 */           synchronized (MessageSender.OutgoingQueue.this.alertQueue) {
/* 262 */             if (MessageSender.OutgoingQueue.this.alertQueue.isEmpty()) {
/* 263 */               this.alertQueueWait = true;
/*     */             }
/*     */             else {
/* 266 */               this.alertQueueWait = false;
/*     */               do
/*     */               {
/* 269 */                 messageList.add(MessageSender.OutgoingQueue.this.alertQueue.removeFirst());
/*     */ 
/* 268 */                 if (messageList.size() >= MessageSender.this.maxSendingQueueSize) break; 
/* 268 */               }while (!MessageSender.OutgoingQueue.this.alertQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 273 */           synchronized (MessageSender.OutgoingQueue.this.messageQueue) {
/* 274 */             if (MessageSender.OutgoingQueue.this.messageQueue.isEmpty()) {
/* 275 */               this.messageQueueWait = true;
/*     */             }
/*     */             else {
/* 278 */               this.messageQueueWait = false;
/*     */               do
/*     */               {
/* 281 */                 messageList.add(MessageSender.OutgoingQueue.this.messageQueue.removeFirst());
/*     */ 
/* 280 */                 if (messageList.size() >= MessageSender.this.maxSendingQueueSize) break; 
/* 280 */               }while (!MessageSender.OutgoingQueue.this.messageQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 286 */           if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 287 */             synchronized (MessageSender.OutgoingQueue.this.semObj) {
/*     */               try {
/* 289 */                 MessageSender.OutgoingQueue.this.semObj.wait();
/*     */               }
/*     */               catch (InterruptedException localInterruptedException)
/*     */               {
/*     */               }
/*     */             }
/*     */           }
/* 296 */           MessageWebService mws = null;
/* 297 */           int sentMessages = 0;
/*     */ 
/* 299 */           while (!messageList.isEmpty()) {
/* 300 */             Message message = (Message)messageList.remove(0);
/*     */             try {
/* 302 */               if (mws == null) {
/* 303 */                 mws = MessageSender.OutgoingQueue.this.mwsl.getMessageWebService(new URL(MessageSender.this.createURL()));
/*     */               }
/* 305 */               MessageSender.logger.debug(getName() + "Sending Message(s)...\n" + message);
/* 306 */               mws.sendMessage(message);
/* 307 */               sentMessages++;
/*     */             } catch (Throwable e) {
/* 309 */               MessageSender.logger.error("Send Message Failed" + message, e);
/* 310 */               mws = null;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.MessageSender
 * JD-Core Version:    0.6.0
 */