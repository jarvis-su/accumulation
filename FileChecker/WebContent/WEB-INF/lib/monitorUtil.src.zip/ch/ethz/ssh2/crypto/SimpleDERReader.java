/*     */ package ch.ethz.ssh2.crypto;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class SimpleDERReader
/*     */ {
/*     */   byte[] buffer;
/*     */   int pos;
/*     */   int count;
/*     */ 
/*     */   public SimpleDERReader(byte[] b)
/*     */   {
/*  21 */     resetInput(b);
/*     */   }
/*     */ 
/*     */   public SimpleDERReader(byte[] b, int off, int len)
/*     */   {
/*  26 */     resetInput(b, off, len);
/*     */   }
/*     */ 
/*     */   public void resetInput(byte[] b)
/*     */   {
/*  31 */     resetInput(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void resetInput(byte[] b, int off, int len)
/*     */   {
/*  36 */     this.buffer = b;
/*  37 */     this.pos = off;
/*  38 */     this.count = len;
/*     */   }
/*     */ 
/*     */   private byte readByte() throws IOException
/*     */   {
/*  43 */     if (this.count <= 0)
/*  44 */       throw new IOException("DER byte array: out of data");
/*  45 */     this.count -= 1;
/*  46 */     return this.buffer[(this.pos++)];
/*     */   }
/*     */ 
/*     */   private byte[] readBytes(int len) throws IOException
/*     */   {
/*  51 */     if (len > this.count) {
/*  52 */       throw new IOException("DER byte array: out of data");
/*     */     }
/*  54 */     byte[] b = new byte[len];
/*     */ 
/*  56 */     System.arraycopy(this.buffer, this.pos, b, 0, len);
/*     */ 
/*  58 */     this.pos += len;
/*  59 */     this.count -= len;
/*     */ 
/*  61 */     return b;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */   {
/*  66 */     return this.count;
/*     */   }
/*     */ 
/*     */   private int readLength() throws IOException
/*     */   {
/*  71 */     int len = readByte() & 0xFF;
/*     */ 
/*  73 */     if ((len & 0x80) == 0) {
/*  74 */       return len;
/*     */     }
/*  76 */     int remain = len & 0x7F;
/*     */ 
/*  78 */     if (remain == 0) {
/*  79 */       return -1;
/*     */     }
/*  81 */     len = 0;
/*     */ 
/*  83 */     while (remain > 0)
/*     */     {
/*  85 */       len <<= 8;
/*  86 */       len |= readByte() & 0xFF;
/*  87 */       remain--;
/*     */     }
/*     */ 
/*  90 */     return len;
/*     */   }
/*     */ 
/*     */   public int ignoreNextObject() throws IOException
/*     */   {
/*  95 */     int type = readByte() & 0xFF;
/*     */ 
/*  97 */     int len = readLength();
/*     */ 
/*  99 */     if ((len < 0) || (len > available())) {
/* 100 */       throw new IOException("Illegal len in DER object (" + len + ")");
/*     */     }
/* 102 */     readBytes(len);
/*     */ 
/* 104 */     return type;
/*     */   }
/*     */ 
/*     */   public BigInteger readInt() throws IOException
/*     */   {
/* 109 */     int type = readByte() & 0xFF;
/*     */ 
/* 111 */     if (type != 2) {
/* 112 */       throw new IOException("Expected DER Integer, but found type " + type);
/*     */     }
/* 114 */     int len = readLength();
/*     */ 
/* 116 */     if ((len < 0) || (len > available())) {
/* 117 */       throw new IOException("Illegal len in DER object (" + len + ")");
/*     */     }
/* 119 */     byte[] b = readBytes(len);
/*     */ 
/* 121 */     BigInteger bi = new BigInteger(b);
/*     */ 
/* 123 */     return bi;
/*     */   }
/*     */ 
/*     */   public byte[] readSequenceAsByteArray() throws IOException
/*     */   {
/* 128 */     int type = readByte() & 0xFF;
/*     */ 
/* 130 */     if (type != 48) {
/* 131 */       throw new IOException("Expected DER Sequence, but found type " + type);
/*     */     }
/* 133 */     int len = readLength();
/*     */ 
/* 135 */     if ((len < 0) || (len > available())) {
/* 136 */       throw new IOException("Illegal len in DER object (" + len + ")");
/*     */     }
/* 138 */     byte[] b = readBytes(len);
/*     */ 
/* 140 */     return b;
/*     */   }
/*     */ 
/*     */   public byte[] readOctetString() throws IOException
/*     */   {
/* 145 */     int type = readByte() & 0xFF;
/*     */ 
/* 147 */     if (type != 4) {
/* 148 */       throw new IOException("Expected DER Octetstring, but found type " + type);
/*     */     }
/* 150 */     int len = readLength();
/*     */ 
/* 152 */     if ((len < 0) || (len > available())) {
/* 153 */       throw new IOException("Illegal len in DER object (" + len + ")");
/*     */     }
/* 155 */     byte[] b = readBytes(len);
/*     */ 
/* 157 */     return b;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.SimpleDERReader
 * JD-Core Version:    0.6.0
 */