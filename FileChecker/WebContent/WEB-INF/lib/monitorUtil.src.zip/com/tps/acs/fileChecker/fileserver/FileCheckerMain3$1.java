/*     */ package com.acs.fileChecker.fileserver;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ final class FileCheckerMain3$1
/*     */   implements FilenameFilter
/*     */ {
/*     */   public boolean accept(File dir, String name)
/*     */   {
/* 116 */     return Pattern.matches(this.val$regexp, name);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.fileserver.FileCheckerMain3.1
 * JD-Core Version:    0.6.0
 */