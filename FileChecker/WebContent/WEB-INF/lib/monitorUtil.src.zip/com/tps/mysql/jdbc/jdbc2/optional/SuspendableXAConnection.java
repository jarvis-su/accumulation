/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ public class SuspendableXAConnection extends MysqlPooledConnection
/*     */   implements XAConnection, XAResource
/*     */ {
/*  23 */   private static final Map XIDS_TO_PHYSICAL_CONNECTIONS = new HashMap();
/*     */   private Xid currentXid;
/*     */   private XAConnection currentXAConnection;
/*     */   private XAResource currentXAResource;
/*     */   private com.mysql.jdbc.Connection underlyingConnection;
/*     */ 
/*     */   public SuspendableXAConnection(com.mysql.jdbc.Connection connection)
/*     */   {
/*  19 */     super(connection);
/*  20 */     this.underlyingConnection = connection;
/*     */   }
/*     */ 
/*     */   private static synchronized XAConnection findConnectionForXid(com.mysql.jdbc.Connection connectionToWrap, Xid xid)
/*     */     throws SQLException
/*     */   {
/*  40 */     XAConnection conn = (XAResource)XIDS_TO_PHYSICAL_CONNECTIONS.get(xid);
/*     */ 
/*  42 */     if (conn == null) {
/*  43 */       conn = new MysqlXAConnection(connectionToWrap);
/*     */     }
/*     */ 
/*  46 */     return conn;
/*     */   }
/*     */ 
/*     */   private static synchronized void removeXAConnectionMapping(Xid xid) {
/*  50 */     XIDS_TO_PHYSICAL_CONNECTIONS.remove(xid);
/*     */   }
/*     */ 
/*     */   private synchronized void switchToXid(Xid xid) throws XAException {
/*  54 */     if (xid == null) {
/*  55 */       throw new XAException();
/*     */     }
/*     */     try
/*     */     {
/*  59 */       if (!xid.equals(this.currentXid)) {
/*  60 */         XAConnection toSwitchTo = findConnectionForXid(this.underlyingConnection, xid);
/*  61 */         this.currentXAConnection = toSwitchTo;
/*  62 */         this.currentXid = xid;
/*  63 */         this.currentXAResource = toSwitchTo.getXAResource();
/*     */       }
/*     */     } catch (SQLException sqlEx) {
/*  66 */       throw new XAException();
/*     */     }
/*     */   }
/*     */ 
/*     */   public XAResource getXAResource() throws SQLException {
/*  71 */     return this;
/*     */   }
/*     */ 
/*     */   public void commit(Xid xid, boolean arg1) throws XAException {
/*  75 */     switchToXid(xid);
/*  76 */     this.currentXAResource.commit(xid, arg1);
/*  77 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   public void end(Xid xid, int arg1) throws XAException {
/*  81 */     switchToXid(xid);
/*  82 */     this.currentXAResource.end(xid, arg1);
/*     */   }
/*     */ 
/*     */   public void forget(Xid xid) throws XAException {
/*  86 */     switchToXid(xid);
/*  87 */     this.currentXAResource.forget(xid);
/*     */ 
/*  89 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   public int getTransactionTimeout() throws XAException
/*     */   {
/*  94 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean isSameRM(XAResource xaRes) throws XAException {
/*  98 */     return xaRes == this;
/*     */   }
/*     */ 
/*     */   public int prepare(Xid xid) throws XAException {
/* 102 */     switchToXid(xid);
/* 103 */     return this.currentXAResource.prepare(xid);
/*     */   }
/*     */ 
/*     */   public Xid[] recover(int flag) throws XAException {
/* 107 */     return MysqlXAConnection.recover(this.underlyingConnection, flag);
/*     */   }
/*     */ 
/*     */   public void rollback(Xid xid) throws XAException {
/* 111 */     switchToXid(xid);
/* 112 */     this.currentXAResource.rollback(xid);
/* 113 */     removeXAConnectionMapping(xid);
/*     */   }
/*     */ 
/*     */   public boolean setTransactionTimeout(int arg0) throws XAException
/*     */   {
/* 118 */     return false;
/*     */   }
/*     */ 
/*     */   public void start(Xid xid, int arg1) throws XAException {
/* 122 */     switchToXid(xid);
/*     */ 
/* 124 */     if (arg1 != 2097152) {
/* 125 */       this.currentXAResource.start(xid, arg1);
/*     */ 
/* 127 */       return;
/*     */     }
/*     */ 
/* 134 */     this.currentXAResource.start(xid, 134217728);
/*     */   }
/*     */ 
/*     */   public synchronized java.sql.Connection getConnection() throws SQLException {
/* 138 */     if (this.currentXAConnection == null) {
/* 139 */       return getConnection(false, true);
/*     */     }
/*     */ 
/* 142 */     return this.currentXAConnection.getConnection();
/*     */   }
/*     */ 
/*     */   public void close() throws SQLException {
/* 146 */     if (this.currentXAConnection == null) {
/* 147 */       super.close();
/*     */     } else {
/* 149 */       removeXAConnectionMapping(this.currentXid);
/* 150 */       this.currentXAConnection.close();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.jdbc2.optional.SuspendableXAConnection
 * JD-Core Version:    0.6.0
 */