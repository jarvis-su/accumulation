/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ReportInfo extends InfoData
/*    */ {
/*    */   private static final long serialVersionUID = -7231075398991999461L;
/*    */   private static final String REPORT_NAME = "REPORT_NAME";
/*    */   private static final String IS_AUTO = "IS_AUTO";
/*    */ 
/*    */   public ReportInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReportInfo(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public ReportInfo(String reportName, boolean isAuto, boolean isStart) {
/* 23 */     super(isStart);
/* 24 */     setData("REPORT_NAME", reportName);
/* 25 */     setData("IS_AUTO", new Boolean(isAuto));
/*    */   }
/*    */ 
/*    */   public String getReportName() {
/* 29 */     String reportName = "";
/* 30 */     if (getData("REPORT_NAME") != null) {
/* 31 */       reportName = (String)getData("REPORT_NAME");
/*    */     }
/* 33 */     return reportName;
/*    */   }
/*    */ 
/*    */   public boolean isAuto() {
/* 37 */     boolean retVal = false;
/* 38 */     if (getData("IS_AUTO") != null) {
/* 39 */       retVal = ((Boolean)getData("IS_AUTO")).booleanValue();
/*    */     }
/* 41 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return super.toString() + 
/* 46 */       "  ReportName: " + getReportName() + "\n" + 
/* 47 */       "  AutoStart: " + isAuto() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.ReportInfo
 * JD-Core Version:    0.6.0
 */