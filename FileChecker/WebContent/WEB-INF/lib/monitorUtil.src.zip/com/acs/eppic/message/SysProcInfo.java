/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class SysProcInfo extends InfoData
/*    */ {
/*    */   private static final long serialVersionUID = -3626815048785547205L;
/*    */   private static final String PROC_NAME = "PROC_NAME";
/*    */ 
/*    */   public SysProcInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SysProcInfo(HashMap map)
/*    */   {
/* 18 */     setData(map);
/*    */   }
/*    */ 
/*    */   public SysProcInfo(String procName, boolean isStart) {
/* 22 */     super(isStart);
/* 23 */     setData("PROC_NAME", procName);
/*    */   }
/*    */ 
/*    */   public String getProcName() {
/* 27 */     String procName = "";
/* 28 */     if (getData("PROC_NAME") != null) {
/* 29 */       procName = (String)getData("PROC_NAME");
/*    */     }
/* 31 */     return procName;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return super.toString() + 
/* 36 */       "  ProcessName: " + getProcName() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.SysProcInfo
 * JD-Core Version:    0.6.0
 */