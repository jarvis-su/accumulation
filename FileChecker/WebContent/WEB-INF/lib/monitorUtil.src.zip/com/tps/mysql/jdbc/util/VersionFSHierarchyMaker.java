/*     */ package com.mysql.jdbc.util;
/*     */ 
/*     */ import com.mysql.jdbc.NonRegisteringDriver;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ public class VersionFSHierarchyMaker
/*     */ {
/*     */   public static void main(String[] args)
/*     */     throws Exception
/*     */   {
/*  43 */     if (args.length < 3) {
/*  44 */       usage();
/*  45 */       System.exit(1);
/*     */     }
/*     */ 
/*  48 */     String jdbcUrl = null;
/*     */ 
/*  51 */     jdbcUrl = System.getProperty("com.mysql.jdbc.testsuite.url");
/*     */ 
/*  54 */     Connection conn = new NonRegisteringDriver().connect(jdbcUrl, null);
/*     */ 
/*  56 */     ResultSet rs = conn.createStatement().executeQuery("SELECT VERSION()");
/*  57 */     rs.next();
/*  58 */     String mysqlVersion = removeWhitespaceChars(rs.getString(1));
/*     */ 
/*  60 */     String jvmVersion = removeWhitespaceChars(System.getProperty("java.version"));
/*  61 */     String jvmVendor = removeWhitespaceChars(System.getProperty("java.vendor"));
/*  62 */     String osName = removeWhitespaceChars(System.getProperty("os.name"));
/*  63 */     String osArch = removeWhitespaceChars(System.getProperty("os.arch"));
/*  64 */     String osVersion = removeWhitespaceChars(System.getProperty("os.version"));
/*     */ 
/*  66 */     String jvmSubdirName = jvmVendor + "-" + jvmVersion;
/*  67 */     String osSubdirName = osName + "-" + osArch + "-" + osVersion;
/*     */ 
/*  69 */     File baseDir = new File(args[1]);
/*  70 */     File mysqlVersionDir = new File(baseDir, mysqlVersion);
/*  71 */     File osVersionDir = new File(mysqlVersionDir, osSubdirName);
/*  72 */     File jvmVersionDir = new File(osVersionDir, jvmSubdirName);
/*     */ 
/*  74 */     jvmVersionDir.mkdirs();
/*     */ 
/*  77 */     FileOutputStream pathOut = null;
/*     */     try
/*     */     {
/*  80 */       String propsOutputPath = args[2];
/*  81 */       pathOut = new FileOutputStream(propsOutputPath);
/*  82 */       String baseDirStr = baseDir.getAbsolutePath();
/*  83 */       String jvmVersionDirStr = jvmVersionDir.getAbsolutePath();
/*     */ 
/*  85 */       if (jvmVersionDirStr.startsWith(baseDirStr)) {
/*  86 */         jvmVersionDirStr = jvmVersionDirStr.substring(baseDirStr.length() + 1);
/*     */       }
/*     */ 
/*  89 */       pathOut.write(jvmVersionDirStr.getBytes());
/*     */     } finally {
/*  91 */       if (pathOut != null) {
/*  92 */         pathOut.flush();
/*  93 */         pathOut.close();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public static String removeWhitespaceChars(String input) {
/*  99 */     if (input == null) {
/* 100 */       return input;
/*     */     }
/*     */ 
/* 103 */     int strLen = input.length();
/*     */ 
/* 105 */     StringBuffer output = new StringBuffer(strLen);
/*     */ 
/* 107 */     for (int i = 0; i < strLen; i++) {
/* 108 */       char c = input.charAt(i);
/* 109 */       if ((!Character.isDigit(c)) && (!Character.isLetter(c))) {
/* 110 */         if (Character.isWhitespace(c))
/* 111 */           output.append("_");
/*     */         else
/* 113 */           output.append(".");
/*     */       }
/*     */       else {
/* 116 */         output.append(c);
/*     */       }
/*     */     }
/*     */ 
/* 120 */     return output.toString();
/*     */   }
/*     */ 
/*     */   private static void usage() {
/* 124 */     System.err.println("Creates a fs hierarchy representing MySQL version, OS version and JVM version.");
/* 125 */     System.err.println("Stores the full path as 'outputDirectory' property in file 'directoryPropPath'");
/* 126 */     System.err.println();
/* 127 */     System.err.println("Usage: java VersionFSHierarchyMaker unit|compliance baseDirectory directoryPropPath");
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.util.VersionFSHierarchyMaker
 * JD-Core Version:    0.6.0
 */