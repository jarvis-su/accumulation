/*     */ package ch.ethz.ssh2.crypto;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.cipher.AES;
/*     */ import ch.ethz.ssh2.crypto.cipher.BlockCipher;
/*     */ import ch.ethz.ssh2.crypto.cipher.CBCMode;
/*     */ import ch.ethz.ssh2.crypto.cipher.DES;
/*     */ import ch.ethz.ssh2.crypto.cipher.DESede;
/*     */ import ch.ethz.ssh2.crypto.digest.MD5;
/*     */ import ch.ethz.ssh2.signature.DSAPrivateKey;
/*     */ import ch.ethz.ssh2.signature.RSAPrivateKey;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class PEMDecoder
/*     */ {
/*     */   private static final int PEM_RSA_PRIVATE_KEY = 1;
/*     */   private static final int PEM_DSA_PRIVATE_KEY = 2;
/*     */ 
/*     */   private static final int hexToInt(char c)
/*     */   {
/*  31 */     if ((c >= 'a') && (c <= 'f'))
/*     */     {
/*  33 */       return c - 'a' + 10;
/*     */     }
/*     */ 
/*  36 */     if ((c >= 'A') && (c <= 'F'))
/*     */     {
/*  38 */       return c - 'A' + 10;
/*     */     }
/*     */ 
/*  41 */     if ((c >= '0') && (c <= '9'))
/*     */     {
/*  43 */       return c - '0';
/*     */     }
/*     */ 
/*  46 */     throw new IllegalArgumentException("Need hex char");
/*     */   }
/*     */ 
/*     */   private static byte[] hexToByteArray(String hex)
/*     */   {
/*  51 */     if (hex == null) {
/*  52 */       throw new IllegalArgumentException("null argument");
/*     */     }
/*  54 */     if (hex.length() % 2 != 0) {
/*  55 */       throw new IllegalArgumentException("Uneven string length in hex encoding.");
/*     */     }
/*  57 */     byte[] decoded = new byte[hex.length() / 2];
/*     */ 
/*  59 */     for (int i = 0; i < decoded.length; i++)
/*     */     {
/*  61 */       int hi = hexToInt(hex.charAt(i * 2));
/*  62 */       int lo = hexToInt(hex.charAt(i * 2 + 1));
/*     */ 
/*  64 */       decoded[i] = (byte)(hi * 16 + lo);
/*     */     }
/*     */ 
/*  67 */     return decoded;
/*     */   }
/*     */ 
/*     */   private static byte[] generateKeyFromPasswordSaltWithMD5(byte[] password, byte[] salt, int keyLen)
/*     */     throws IOException
/*     */   {
/*  73 */     if (salt.length < 8) {
/*  74 */       throw new IllegalArgumentException("Salt needs to be at least 8 bytes for key generation.");
/*     */     }
/*  76 */     MD5 md5 = new MD5();
/*     */ 
/*  78 */     byte[] key = new byte[keyLen];
/*  79 */     byte[] tmp = new byte[md5.getDigestLength()];
/*     */     while (true)
/*     */     {
/*  83 */       md5.update(password, 0, password.length);
/*  84 */       md5.update(salt, 0, 8);
/*     */ 
/*  87 */       int copy = keyLen < tmp.length ? keyLen : tmp.length;
/*     */ 
/*  89 */       md5.digest(tmp, 0);
/*     */ 
/*  91 */       System.arraycopy(tmp, 0, key, key.length - keyLen, copy);
/*     */ 
/*  93 */       keyLen -= copy;
/*     */ 
/*  95 */       if (keyLen == 0) {
/*  96 */         return key;
/*     */       }
/*  98 */       md5.update(tmp, 0, tmp.length);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static byte[] removePadding(byte[] buff, int blockSize)
/*     */     throws IOException
/*     */   {
/* 106 */     int rfc_1423_padding = buff[(buff.length - 1)] & 0xFF;
/*     */ 
/* 108 */     if ((rfc_1423_padding < 1) || (rfc_1423_padding > blockSize)) {
/* 109 */       throw new IOException("Decrypted PEM has wrong padding, did you specify the correct password?");
/*     */     }
/* 111 */     for (int i = 2; i <= rfc_1423_padding; i++)
/*     */     {
/* 113 */       if (buff[(buff.length - i)] != rfc_1423_padding) {
/* 114 */         throw new IOException("Decrypted PEM has wrong padding, did you specify the correct password?");
/*     */       }
/*     */     }
/* 117 */     byte[] tmp = new byte[buff.length - rfc_1423_padding];
/* 118 */     System.arraycopy(buff, 0, tmp, 0, buff.length - rfc_1423_padding);
/* 119 */     return tmp;
/*     */   }
/*     */ 
/*     */   private static final PEMStructure parsePEM(char[] pem) throws IOException
/*     */   {
/* 124 */     PEMStructure ps = new PEMStructure();
/*     */ 
/* 126 */     String line = null;
/*     */ 
/* 128 */     BufferedReader br = new BufferedReader(new CharArrayReader(pem));
/*     */ 
/* 130 */     String endLine = null;
/*     */     while (true)
/*     */     {
/* 134 */       line = br.readLine();
/*     */ 
/* 136 */       if (line == null) {
/* 137 */         throw new IOException("Invalid PEM structure, '-----BEGIN...' missing");
/*     */       }
/* 139 */       line = line.trim();
/*     */ 
/* 141 */       if (line.startsWith("-----BEGIN DSA PRIVATE KEY-----"))
/*     */       {
/* 143 */         endLine = "-----END DSA PRIVATE KEY-----";
/* 144 */         ps.pemType = 2;
/* 145 */         break;
/*     */       }
/*     */ 
/* 148 */       if (!line.startsWith("-----BEGIN RSA PRIVATE KEY-----"))
/*     */         continue;
/* 150 */       endLine = "-----END RSA PRIVATE KEY-----";
/* 151 */       ps.pemType = 1;
/* 152 */       break;
/*     */     }
/*     */ 
/*     */     while (true)
/*     */     {
/* 158 */       line = br.readLine();
/*     */ 
/* 160 */       if (line == null) {
/* 161 */         throw new IOException("Invalid PEM structure, " + endLine + " missing");
/*     */       }
/* 163 */       line = line.trim();
/*     */ 
/* 165 */       int sem_idx = line.indexOf(':');
/*     */ 
/* 167 */       if (sem_idx == -1) {
/*     */         break;
/*     */       }
/* 170 */       String name = line.substring(0, sem_idx + 1);
/* 171 */       String value = line.substring(sem_idx + 1);
/*     */ 
/* 173 */       String[] values = value.split(",");
/*     */ 
/* 175 */       for (int i = 0; i < values.length; i++) {
/* 176 */         values[i] = values[i].trim();
/*     */       }
/*     */ 
/* 181 */       if ("Proc-Type:".equals(name))
/*     */       {
/* 183 */         ps.procType = values;
/* 184 */         continue;
/*     */       }
/*     */ 
/* 187 */       if (!"DEK-Info:".equals(name))
/*     */         continue;
/* 189 */       ps.dekInfo = values;
/*     */     }
/*     */ 
/* 195 */     StringBuffer keyData = new StringBuffer();
/*     */     while (true)
/*     */     {
/* 199 */       if (line == null) {
/* 200 */         throw new IOException("Invalid PEM structure, " + endLine + " missing");
/*     */       }
/* 202 */       line = line.trim();
/*     */ 
/* 204 */       if (line.startsWith(endLine)) {
/*     */         break;
/*     */       }
/* 207 */       keyData.append(line);
/*     */ 
/* 209 */       line = br.readLine();
/*     */     }
/*     */ 
/* 212 */     char[] pem_chars = new char[keyData.length()];
/* 213 */     keyData.getChars(0, pem_chars.length, pem_chars, 0);
/*     */ 
/* 215 */     ps.data = Base64.decode(pem_chars);
/*     */ 
/* 217 */     if (ps.data.length == 0) {
/* 218 */       throw new IOException("Invalid PEM structure, no data available");
/*     */     }
/* 220 */     return ps;
/*     */   }
/*     */ 
/*     */   private static final void decryptPEM(PEMStructure ps, byte[] pw) throws IOException
/*     */   {
/* 225 */     if (ps.dekInfo == null) {
/* 226 */       throw new IOException("Broken PEM, no mode and salt given, but encryption enabled");
/*     */     }
/* 228 */     if (ps.dekInfo.length != 2) {
/* 229 */       throw new IOException("Broken PEM, DEK-Info is incomplete!");
/*     */     }
/* 231 */     String algo = ps.dekInfo[0];
/* 232 */     byte[] salt = hexToByteArray(ps.dekInfo[1]);
/*     */ 
/* 234 */     BlockCipher bc = null;
/*     */ 
/* 236 */     if (algo.equals("DES-EDE3-CBC"))
/*     */     {
/* 238 */       DESede des3 = new DESede();
/* 239 */       des3.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 24));
/* 240 */       bc = new CBCMode(des3, salt, false);
/*     */     }
/* 242 */     else if (algo.equals("DES-CBC"))
/*     */     {
/* 244 */       DES des = new DES();
/* 245 */       des.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 8));
/* 246 */       bc = new CBCMode(des, salt, false);
/*     */     }
/* 248 */     else if (algo.equals("AES-128-CBC"))
/*     */     {
/* 250 */       AES aes = new AES();
/* 251 */       aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 16));
/* 252 */       bc = new CBCMode(aes, salt, false);
/*     */     }
/* 254 */     else if (algo.equals("AES-192-CBC"))
/*     */     {
/* 256 */       AES aes = new AES();
/* 257 */       aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 24));
/* 258 */       bc = new CBCMode(aes, salt, false);
/*     */     }
/* 260 */     else if (algo.equals("AES-256-CBC"))
/*     */     {
/* 262 */       AES aes = new AES();
/* 263 */       aes.init(false, generateKeyFromPasswordSaltWithMD5(pw, salt, 32));
/* 264 */       bc = new CBCMode(aes, salt, false);
/*     */     }
/*     */     else
/*     */     {
/* 268 */       throw new IOException("Cannot decrypt PEM structure, unknown cipher " + algo);
/*     */     }
/*     */ 
/* 271 */     if (ps.data.length % bc.getBlockSize() != 0) {
/* 272 */       throw new IOException("Invalid PEM structure, size of encrypted block is not a multiple of " + 
/* 273 */         bc.getBlockSize());
/*     */     }
/*     */ 
/* 277 */     byte[] dz = new byte[ps.data.length];
/*     */ 
/* 279 */     for (int i = 0; i < ps.data.length / bc.getBlockSize(); i++)
/*     */     {
/* 281 */       bc.transformBlock(ps.data, i * bc.getBlockSize(), dz, i * bc.getBlockSize());
/*     */     }
/*     */ 
/* 286 */     dz = removePadding(dz, bc.getBlockSize());
/*     */ 
/* 288 */     ps.data = dz;
/* 289 */     ps.dekInfo = null;
/* 290 */     ps.procType = null;
/*     */   }
/*     */ 
/*     */   public static final boolean isPEMEncrypted(PEMStructure ps) throws IOException
/*     */   {
/* 295 */     if (ps.procType == null) {
/* 296 */       return false;
/*     */     }
/* 298 */     if (ps.procType.length != 2) {
/* 299 */       throw new IOException("Unknown Proc-Type field.");
/*     */     }
/* 301 */     if (!"4".equals(ps.procType[0])) {
/* 302 */       throw new IOException("Unknown Proc-Type field (" + ps.procType[0] + ")");
/*     */     }
/*     */ 
/* 305 */     return "ENCRYPTED".equals(ps.procType[1]);
/*     */   }
/*     */ 
/*     */   public static Object decode(char[] pem, String password)
/*     */     throws IOException
/*     */   {
/* 312 */     PEMStructure ps = parsePEM(pem);
/*     */ 
/* 314 */     if (isPEMEncrypted(ps))
/*     */     {
/* 316 */       if (password == null) {
/* 317 */         throw new IOException("PEM is encrypted, but no password was specified");
/*     */       }
/* 319 */       decryptPEM(ps, password.getBytes());
/*     */     }
/*     */ 
/* 322 */     if (ps.pemType == 2)
/*     */     {
/* 324 */       SimpleDERReader dr = new SimpleDERReader(ps.data);
/*     */ 
/* 326 */       byte[] seq = dr.readSequenceAsByteArray();
/*     */ 
/* 328 */       if (dr.available() != 0) {
/* 329 */         throw new IOException("Padding in DSA PRIVATE KEY DER stream.");
/*     */       }
/* 331 */       dr.resetInput(seq);
/*     */ 
/* 333 */       BigInteger version = dr.readInt();
/*     */ 
/* 335 */       if (version.compareTo(BigInteger.ZERO) != 0) {
/* 336 */         throw new IOException("Wrong version (" + version + ") in DSA PRIVATE KEY DER stream.");
/*     */       }
/* 338 */       BigInteger p = dr.readInt();
/* 339 */       BigInteger q = dr.readInt();
/* 340 */       BigInteger g = dr.readInt();
/* 341 */       BigInteger y = dr.readInt();
/* 342 */       BigInteger x = dr.readInt();
/*     */ 
/* 344 */       if (dr.available() != 0) {
/* 345 */         throw new IOException("Padding in DSA PRIVATE KEY DER stream.");
/*     */       }
/* 347 */       return new DSAPrivateKey(p, q, g, y, x);
/*     */     }
/*     */ 
/* 350 */     if (ps.pemType == 1)
/*     */     {
/* 352 */       SimpleDERReader dr = new SimpleDERReader(ps.data);
/*     */ 
/* 354 */       byte[] seq = dr.readSequenceAsByteArray();
/*     */ 
/* 356 */       if (dr.available() != 0) {
/* 357 */         throw new IOException("Padding in RSA PRIVATE KEY DER stream.");
/*     */       }
/* 359 */       dr.resetInput(seq);
/*     */ 
/* 361 */       BigInteger version = dr.readInt();
/*     */ 
/* 363 */       if ((version.compareTo(BigInteger.ZERO) != 0) && (version.compareTo(BigInteger.ONE) != 0)) {
/* 364 */         throw new IOException("Wrong version (" + version + ") in RSA PRIVATE KEY DER stream.");
/*     */       }
/* 366 */       BigInteger n = dr.readInt();
/* 367 */       BigInteger e = dr.readInt();
/* 368 */       BigInteger d = dr.readInt();
/*     */ 
/* 370 */       return new RSAPrivateKey(d, e, n);
/*     */     }
/*     */ 
/* 373 */     throw new IOException("PEM problem: it is of unknown type");
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.PEMDecoder
 * JD-Core Version:    0.6.0
 */