package ch.ethz.ssh2;

public abstract interface InteractiveCallback
{
  public abstract String[] replyToChallenge(String paramString1, String paramString2, int paramInt, String[] paramArrayOfString, boolean[] paramArrayOfBoolean)
    throws Exception;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.InteractiveCallback
 * JD-Core Version:    0.6.0
 */