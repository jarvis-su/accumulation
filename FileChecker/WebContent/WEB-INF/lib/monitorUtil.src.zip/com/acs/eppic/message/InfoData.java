/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class InfoData extends MessageData
/*    */ {
/*    */   private static final long serialVersionUID = -5672261978197541845L;
/*    */   private static final String IS_START = "IS_START";
/*    */ 
/*    */   public InfoData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public InfoData(boolean isStart)
/*    */   {
/* 18 */     setData("IS_START", new Boolean(isStart));
/*    */   }
/*    */ 
/*    */   public InfoData(HashMap map) {
/* 22 */     setData(map);
/*    */   }
/*    */ 
/*    */   public boolean isStart() {
/* 26 */     boolean retVal = false;
/* 27 */     if (getData("IS_START") != null) {
/* 28 */       retVal = ((Boolean)getData("IS_START")).booleanValue();
/*    */     }
/* 30 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 34 */     return super.toString() + 
/* 35 */       "  Msg Type: " + (isStart() ? "Start" : "Stop") + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.InfoData
 * JD-Core Version:    0.6.0
 */