/*     */ package ch.ethz.ssh2.util;
/*     */ 
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.StringWriter;
/*     */ import java.util.Collections;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ public class TimeoutService
/*     */ {
/*  24 */   private static final Logger log = Logger.getLogger(TimeoutService.class);
/*     */ 
/* 104 */   private static final LinkedList todolist = new LinkedList();
/*     */ 
/* 106 */   private static Thread timeoutThread = null;
/*     */ 
/*     */   public static final TimeoutToken addTimeoutHandler(long runTime, Runnable handler)
/*     */   {
/* 117 */     TimeoutToken token = new TimeoutToken(runTime, handler, null);
/*     */ 
/* 119 */     synchronized (todolist)
/*     */     {
/* 121 */       todolist.add(token);
/* 122 */       Collections.sort(todolist);
/*     */ 
/* 124 */       if (timeoutThread != null) {
/* 125 */         timeoutThread.interrupt();
/*     */       }
/*     */       else {
/* 128 */         timeoutThread = new TimeoutThread(null);
/* 129 */         timeoutThread.setDaemon(true);
/* 130 */         timeoutThread.start();
/*     */       }
/*     */     }
/*     */ 
/* 134 */     return token;
/*     */   }
/*     */ 
/*     */   public static final void cancelTimeoutHandler(TimeoutToken token)
/*     */   {
/* 139 */     synchronized (todolist)
/*     */     {
/* 141 */       todolist.remove(token);
/*     */ 
/* 143 */       if (timeoutThread != null)
/* 144 */         timeoutThread.interrupt();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class TimeoutToken
/*     */     implements Comparable
/*     */   {
/*     */     private long runTime;
/*     */     private Runnable handler;
/*     */ 
/*     */     private TimeoutToken(long runTime, Runnable handler)
/*     */     {
/*  33 */       this.runTime = runTime;
/*  34 */       this.handler = handler;
/*     */     }
/*     */ 
/*     */     public int compareTo(Object o)
/*     */     {
/*  39 */       TimeoutToken t = (TimeoutToken)o;
/*  40 */       if (this.runTime > t.runTime)
/*  41 */         return 1;
/*  42 */       if (this.runTime == t.runTime)
/*  43 */         return 0;
/*  44 */       return -1;
/*     */     }
/*     */ 
/*     */     TimeoutToken(long paramLong, Runnable paramRunnable, TimeoutToken paramTimeoutToken)
/*     */     {
/*  31 */       this(paramLong, paramRunnable);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TimeoutThread extends Thread
/*     */   {
/*     */     private TimeoutThread()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*  52 */       synchronized (TimeoutService.todolist)
/*     */       {
/*     */         while (true)
/*     */         {
/*  56 */           if (TimeoutService.todolist.size() == 0)
/*     */           {
/*  58 */             TimeoutService.timeoutThread = null;
/*  59 */             return;
/*     */           }
/*     */ 
/*  62 */           long now = System.currentTimeMillis();
/*     */ 
/*  64 */           TimeoutService.TimeoutToken tt = (TimeoutService.TimeoutToken)TimeoutService.todolist.getFirst();
/*     */ 
/*  66 */           if (tt.runTime > now)
/*     */           {
/*     */             try
/*     */             {
/*  72 */               TimeoutService.todolist.wait(tt.runTime - now);
/*     */             }
/*     */             catch (InterruptedException localInterruptedException)
/*     */             {
/*     */             }
/*     */ 
/*  83 */             continue;
/*     */           }
/*     */ 
/*  86 */           TimeoutService.todolist.removeFirst();
/*     */           try
/*     */           {
/*  90 */             tt.handler.run();
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*  94 */             StringWriter sw = new StringWriter();
/*  95 */             e.printStackTrace(new PrintWriter(sw));
/*  96 */             TimeoutService.log.log(20, "Exeception in Timeout handler:" + e.getMessage() + "(" + sw.toString() + ")");
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/*     */     TimeoutThread(TimeoutThread paramTimeoutThread)
/*     */     {
/*  48 */       this();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.util.TimeoutService
 * JD-Core Version:    0.6.0
 */