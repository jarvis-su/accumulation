/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.HeartbeatData;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import com.acs.eppic.message.RegistrationData;
/*     */ import com.acs.eppic.messageservice.web.MessageWebService;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.jmx.LoggerDynamicMBean;
/*     */ 
/*     */ public class MessageService
/*     */   implements MessageServiceMBean
/*     */ {
/*  33 */   private static MessageService soleInstance = null;
/*  34 */   protected static final Logger logger = Logger.getLogger("MessageService");
/*     */ 
/*  36 */   private String systemId = "MONITOR";
/*  37 */   private String systemPort = "8080";
/*     */   protected static final String CONFIG_SOURCE_FILENAME = "com_acs_eppic_messagingservice_properties";
/*  41 */   private boolean monitorMode = false;
/*     */   private String monitorHost;
/*     */   private String monitorPort;
/*     */   private String monitorUrl;
/*  49 */   private boolean serviceEnabled = false;
/*     */ 
/*  52 */   private int registration_timeout = 300;
/*  53 */   private int heartbeat_interval = 30;
/*  54 */   private int resend_interval = 30;
/*  55 */   private int maxSendingQueueSize = 25;
/*  56 */   private int maxAlertQueueSize = 0;
/*  57 */   private int maxMessageQueueSize = 0;
/*  58 */   private int messageNotificationQueueSize = 0;
/*     */   private int serverIndex;
/*  64 */   private boolean isStarted = false;
/*     */   private boolean connected;
/*     */   private Map handles;
/*     */   private Thread heartBeater;
/*     */   private IncomingQueue incomingQueue;
/*     */   private OutgoingQueue outgoingQueue;
/*     */ 
/*     */   public static MessageService getSoleInstance()
/*     */   {
/*  73 */     if (soleInstance == null)
/*     */     {
/*  75 */       synchronized (MessageService.class)
/*     */       {
/*  77 */         if (soleInstance == null)
/*     */         {
/*  79 */           soleInstance = new MessageService();
/*     */         }
/*     */       }
/*     */     }
/*  83 */     return soleInstance;
/*     */   }
/*     */ 
/*     */   public MessageService()
/*     */   {
/*  88 */     ArrayList list = MBeanServerFactory.findMBeanServer(null);
/*     */ 
/*  90 */     synchronized (list) {
/*  91 */       if (!list.isEmpty()) {
/*     */         try
/*     */         {
/*  94 */           ObjectName objectName = new ObjectName("log4j:name=" + logger.getClass().getName());
/*  95 */           ((MBeanServer)list.get(0)).registerMBean(new LoggerDynamicMBean(logger), objectName);
/*     */         } catch (Exception e) {
/*  97 */           logger.error("Error registering with MBeanServer", e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 102 */     this.serverIndex = 0;
/* 103 */     this.handles = new HashMap();
/*     */     try
/*     */     {
/* 106 */       ConfigFileReader pfr = new ConfigFileReader("com_acs_eppic_messagingservice_properties");
/* 107 */       this.monitorMode = (pfr.readConfigValueString("monitor.mode").compareToIgnoreCase("true") == 0);
/* 108 */       this.monitorHost = pfr.readConfigValueString("service.host");
/* 109 */       this.monitorPort = pfr.readConfigValueString("service.port");
/* 110 */       this.monitorUrl = pfr.readConfigValueString("service.urlpath");
/* 111 */       this.systemId = pfr.readConfigValueString("system.name");
/* 112 */       this.systemPort = pfr.readConfigValueString("system.port");
/* 113 */       this.registration_timeout = pfr.readConfigValueInteger("registration.timeout");
/* 114 */       this.heartbeat_interval = pfr.readConfigValueInteger("heartbeat.interval");
/* 115 */       this.resend_interval = pfr.readConfigValueInteger("resend.interval");
/* 116 */       this.serviceEnabled = (pfr.readConfigValueString("service.enabled").compareToIgnoreCase("true") == 0);
/* 117 */       this.maxSendingQueueSize = pfr.readConfigValueInteger("max.send.queueSize");
/* 118 */       this.maxAlertQueueSize = pfr.readConfigValueInteger("max.alert.queueSize");
/* 119 */       this.maxMessageQueueSize = pfr.readConfigValueInteger("max.message.queueSize");
/* 120 */       this.messageNotificationQueueSize = pfr.readConfigValueInteger("message.notify.queueSize");
/*     */     } catch (Exception e) {
/* 122 */       logger.error("ERROR Starting Messaging Service.", e);
/*     */     }
/*     */ 
/* 125 */     if ((this.monitorMode) || (this.serviceEnabled)) {
/* 126 */       this.outgoingQueue = new OutgoingQueue();
/* 127 */       this.incomingQueue = new IncomingQueue();
/* 128 */       if ((!this.monitorMode) && (this.heartbeat_interval > 0)) {
/* 129 */         this.heartBeater = new Thread(new HeartBeat(this.heartbeat_interval));
/* 130 */         this.heartBeater.start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getConfigName()
/*     */   {
/* 137 */     return "com.acs.eppic.messagservice.MessageService";
/*     */   }
/*     */ 
/*     */   public void setServerIndex(int index)
/*     */   {
/* 145 */     this.serverIndex = index;
/*     */   }
/*     */ 
/*     */   public int getServerIndex()
/*     */   {
/* 150 */     return this.serverIndex;
/*     */   }
/*     */ 
/*     */   public boolean isStarted()
/*     */   {
/* 155 */     return this.isStarted;
/*     */   }
/*     */ 
/*     */   public String getSystemId()
/*     */   {
/* 160 */     return this.systemId;
/*     */   }
/*     */ 
/*     */   public MessageServiceHandle findServiceHandle(String serviceId)
/*     */   {
/* 172 */     MessageService ms = getSoleInstance();
/* 173 */     MessageServiceHandle handle = null;
/* 174 */     if (ms.handles.get(serviceId) != null) {
/* 175 */       handle = (MessageServiceHandle)ms.handles.get(serviceId);
/*     */     }
/* 177 */     return handle;
/*     */   }
/*     */ 
/*     */   public static MessageServiceHandle getServiceHandle(MessageRecipient recipient, boolean createHandle)
/*     */   {
/* 191 */     MessageService ms = getSoleInstance();
/* 192 */     MessageServiceHandle handle = ms.findServiceHandle("MONITOR");
/* 193 */     if ((handle == null) && (createHandle)) {
/* 194 */       handle = ms.newServiceHandle("MONITOR", recipient);
/*     */     }
/* 196 */     return handle;
/*     */   }
/*     */ 
/*     */   public static MessageServiceHandle getServiceHandle(String serviceId, MessageRecipient recipient, boolean createHandle)
/*     */   {
/* 211 */     MessageService ms = getSoleInstance();
/* 212 */     MessageServiceHandle handle = null;
/*     */ 
/* 214 */     if (((handle = ms.findServiceHandle(serviceId)) == null) && (createHandle)) {
/* 215 */       handle = ms.newServiceHandle(serviceId, recipient);
/*     */     }
/* 217 */     return handle;
/*     */   }
/*     */ 
/*     */   protected MessageServiceHandle newServiceHandle(String serviceId, MessageRecipient recipient)
/*     */   {
/* 230 */     MessageServiceHandle handle = null;
/* 231 */     synchronized (this.handles) {
/* 232 */       handle = new MessageServiceHandle(getSystemId(), serviceId, getSystemPort(), recipient);
/* 233 */       this.handles.put(serviceId, handle);
/*     */     }
/* 235 */     return handle;
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message)
/*     */   {
/* 240 */     if (isServiceEnabled())
/* 241 */       this.outgoingQueue.enqueue(message);
/*     */   }
/*     */ 
/*     */   public String getOutgoingQueue()
/*     */   {
/* 246 */     return this.outgoingQueue.toString();
/*     */   }
/*     */ 
/*     */   public String getIncomingQueue() {
/* 250 */     return this.incomingQueue.toString();
/*     */   }
/*     */ 
/*     */   public void receive(Message message)
/*     */   {
/* 255 */     if (isServiceEnabled())
/* 256 */       this.incomingQueue.enqueue(message);
/*     */   }
/*     */ 
/*     */   public int getRegistration_timeout()
/*     */   {
/* 511 */     return this.registration_timeout;
/*     */   }
/*     */ 
/*     */   public boolean isServiceEnabled()
/*     */   {
/* 516 */     return this.serviceEnabled;
/*     */   }
/*     */ 
/*     */   public boolean isMonitorMode()
/*     */   {
/* 521 */     return this.monitorMode;
/*     */   }
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 526 */     return this.connected;
/*     */   }
/*     */ 
/*     */   protected void setConnected(boolean connected)
/*     */   {
/* 535 */     this.connected = connected;
/*     */   }
/*     */ 
/*     */   public String getSystemPort()
/*     */   {
/* 542 */     return this.systemPort;
/*     */   }
/*     */ 
/*     */   public int getResend_interval()
/*     */   {
/* 549 */     return this.resend_interval;
/*     */   }
/*     */ 
/*     */   private String createURL() {
/* 553 */     return createURL(this.monitorHost, this.monitorPort);
/*     */   }
/*     */ 
/*     */   private String createURL(String host, String port) {
/* 557 */     return "http://" + host.trim() + ":" + port.trim() + "/" + this.monitorUrl;
/*     */   }
/*     */ 
/*     */   public String getMonitorHost() {
/* 561 */     return this.monitorHost;
/*     */   }
/*     */   public String getMonitorPort() {
/* 564 */     return this.monitorPort;
/*     */   }
/*     */   public String getMonitorUrlPath() {
/* 567 */     return this.monitorUrl;
/*     */   }
/*     */ 
/*     */   public void setMonitorHost(String host) {
/* 571 */     this.monitorHost = host.trim();
/* 572 */     setConnected(false);
/*     */   }
/*     */   public void setMonitorPort(String port) {
/* 575 */     this.monitorPort = port.trim();
/* 576 */     setConnected(false);
/*     */   }
/*     */   public void setMonitorUrlPath(String path) {
/* 579 */     this.monitorUrl = path.trim();
/* 580 */     setConnected(false);
/*     */   }
/*     */ 
/*     */   public void receiveIncoming(Message message)
/*     */   {
/* 592 */     switch (message.getType().getTypeId()) {
/*     */     case 0:
/* 594 */       logger.info("SystemId: " + getSystemId() + " is connected to the monitor");
/* 595 */       setConnected(true);
/* 596 */       break;
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/* 602 */       logger.error("UNABLE TO PROCESS MESSAGES OF THIS TYPE.\n" + message);
/* 603 */       break;
/*     */     default:
/* 605 */       logger.error("INVALID MESSAGE TYPE.\n" + message);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class HeartBeat
/*     */     implements Runnable
/*     */   {
/*     */     private int internalInterval;
/*     */     private Message message;
/*     */     private Date timestamp;
/*     */     private HeartbeatData hbData;
/*     */ 
/*     */     HeartBeat(int interval)
/*     */     {
/* 624 */       this.internalInterval = interval;
/* 625 */       this.message = new Message(MessageService.this.getSystemId(), "HEARTBEAT", 3, MessageService.this.getSystemPort());
/* 626 */       this.hbData = new HeartbeatData(getInterval());
/* 627 */       this.message.setM_MessageData(this.hbData);
/*     */     }
/*     */ 
/*     */     public void setInterval(int interval) {
/* 631 */       this.internalInterval = interval;
/*     */     }
/*     */ 
/*     */     public int getInterval()
/*     */     {
/* 641 */       int interval = this.internalInterval;
/* 642 */       if (!MessageService.this.isConnected()) {
/* 643 */         interval = MessageService.this.getRegistration_timeout();
/*     */       }
/* 645 */       return interval;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 653 */       while (MessageService.this.isServiceEnabled()) {
/* 654 */         if (MessageService.this.isConnected()) {
/* 655 */           MessageService.logger.debug("HeartBeat.run(): Sending HeartBeat.");
/* 656 */           this.timestamp = new Date();
/* 657 */           this.message.setTimestamp(this.timestamp);
/* 658 */           this.hbData.setInterval(getInterval());
/* 659 */           MessageService.this.enqueue(this.message);
/*     */         } else {
/* 661 */           MessageService.logger.info("HeartBeat.run(): Not Connected. Waiting for " + MessageService.this.getRegistration_timeout() + " before attempting a reconnect of System:" + MessageService.this.getSystemId());
/*     */ 
/* 663 */           Message m = new Message(MessageService.this.getSystemId(), "HEARTBEAT", 5, MessageService.this.getSystemPort());
/* 664 */           m.setM_MessageData(new RegistrationData(MessageService.this.getRegistration_timeout()));
/* 665 */           MessageService.this.enqueue(m);
/*     */         }
/*     */         try {
/* 668 */           Thread.sleep(getInterval() * 1000);
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class IncomingQueue
/*     */   {
/*     */     private final QueueWorker[] threads;
/*     */     private final LinkedList alertQueue;
/*     */     private final LinkedList messageQueue;
/* 405 */     Object semObj = new Object();
/*     */ 
/*     */     public IncomingQueue() {
/* 408 */       this.alertQueue = new LinkedList();
/* 409 */       this.messageQueue = new LinkedList();
/* 410 */       this.threads = new QueueWorker[2];
/* 411 */       for (int i = 0; i < this.threads.length; i++) {
/* 412 */         this.threads[i] = new QueueWorker(null);
/* 413 */         this.threads[i].setName("INCOMING_QUEUE_" + i);
/* 414 */         this.threads[i].start();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void enqueue(Message message) {
/* 419 */       if (message.getType().getTypeId() == 1) {
/* 420 */         synchronized (this.alertQueue) {
/* 421 */           this.alertQueue.addLast(message);
/*     */         }
/*     */       }
/* 424 */       synchronized (this.messageQueue) {
/* 425 */         this.messageQueue.addLast(message);
/*     */       }
/*     */ 
/* 428 */       synchronized (this.semObj) {
/* 429 */         this.semObj.notifyAll();
/*     */       }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 504 */       return "CLASS: IncomingQueue\n";
/*     */     }
/*     */ 
/*     */     private class QueueWorker extends Thread
/*     */     {
/* 436 */       boolean alertQueueWait = false;
/* 437 */       boolean messageQueueWait = false;
/*     */ 
/*     */       private QueueWorker() {  } 
/* 439 */       public void run() { LinkedList messageList = new LinkedList();
/*     */ 
/* 442 */         while (MessageService.this.isServiceEnabled()) {
/* 443 */           messageList.clear();
/* 444 */           synchronized (MessageService.IncomingQueue.this.alertQueue) {
/* 445 */             if (MessageService.IncomingQueue.this.alertQueue.isEmpty()) {
/* 446 */               this.alertQueueWait = true;
/*     */             }
/*     */             else {
/* 449 */               this.alertQueueWait = false;
/*     */               do
/*     */               {
/* 452 */                 messageList.add(MessageService.IncomingQueue.this.alertQueue.removeFirst());
/*     */ 
/* 451 */                 if (messageList.size() >= MessageService.this.maxSendingQueueSize) break; 
/* 451 */               }while (!MessageService.IncomingQueue.this.alertQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 457 */           synchronized (MessageService.IncomingQueue.this.messageQueue) {
/* 458 */             if (MessageService.IncomingQueue.this.messageQueue.isEmpty()) {
/* 459 */               this.messageQueueWait = true;
/*     */             } else {
/* 461 */               this.messageQueueWait = false;
/*     */               do
/*     */               {
/* 464 */                 messageList.add(MessageService.IncomingQueue.this.messageQueue.removeFirst());
/*     */ 
/* 463 */                 if (messageList.size() >= MessageService.this.maxSendingQueueSize) break; 
/* 463 */               }while (!MessageService.IncomingQueue.this.messageQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 469 */           if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 470 */             synchronized (MessageService.IncomingQueue.this.semObj) {
/*     */               try {
/* 472 */                 MessageService.IncomingQueue.this.semObj.wait();
/*     */               }
/*     */               catch (InterruptedException localInterruptedException)
/*     */               {
/*     */               }
/*     */             }
/*     */           }
/* 479 */           int receivedMessages = 0;
/*     */ 
/* 481 */           while (!messageList.isEmpty()) {
/* 482 */             Message message = (Message)messageList.removeFirst();
/*     */             MessageServiceHandle msh;
/*     */             MessageServiceHandle msh;
/* 483 */             if (MessageService.this.isMonitorMode())
/* 484 */               msh = MessageService.this.findServiceHandle("MONITOR");
/*     */             else {
/* 486 */               msh = MessageService.this.findServiceHandle(message.getServiceId());
/*     */             }
/*     */ 
/* 489 */             if (msh != null)
/* 490 */               msh.receiveIncoming(message);
/*     */             else {
/* 492 */               MessageService.this.receiveIncoming(message);
/*     */             }
/* 494 */             receivedMessages++;
/*     */           }
/* 496 */           if (receivedMessages > 0)
/* 497 */             MessageService.logger.info(getName() + "\tReceived " + receivedMessages + " Messages.");
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class OutgoingQueue
/*     */   {
/*     */     private final QueueWorker[] threads;
/*     */     private final LinkedList alertQueue;
/*     */     private final LinkedList messageQueue;
/*     */     private MessageWebServiceServiceLocator mwsl;
/* 266 */     Object semObj = new Object();
/*     */ 
/*     */     public OutgoingQueue() {
/* 269 */       this.mwsl = new MessageWebServiceServiceLocator();
/* 270 */       this.alertQueue = new LinkedList();
/* 271 */       this.messageQueue = new LinkedList();
/* 272 */       this.threads = new QueueWorker[2];
/* 273 */       for (int i = 0; i < this.threads.length; i++) {
/* 274 */         this.threads[i] = new QueueWorker(null);
/* 275 */         this.threads[i].setName("OUTGOING_QUEUE_" + i);
/* 276 */         this.threads[i].start();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void enqueue(Message message) {
/* 281 */       boolean notify = false;
/* 282 */       if ((message.getServiceId() == "HEARTBEAT") || 
/* 283 */         (message.getType().getTypeId() == 1) || 
/* 284 */         (message.getType().getTypeId() == 0))
/*     */       {
/* 286 */         synchronized (this.alertQueue) {
/* 287 */           if (this.alertQueue.size() <= MessageService.this.maxAlertQueueSize) {
/* 288 */             this.alertQueue.addLast(message);
/* 289 */             notify = true;
/*     */           } else {
/* 291 */             notify = false;
/*     */           }
/*     */         }
/*     */       }
/* 295 */       synchronized (this.messageQueue) {
/* 296 */         int queueSize = this.messageQueue.size();
/* 297 */         if (queueSize <= MessageService.this.maxMessageQueueSize) {
/* 298 */           this.messageQueue.addLast(message);
/* 299 */           if (queueSize >= MessageService.this.messageNotificationQueueSize)
/* 300 */             notify = true;
/*     */           else {
/* 302 */             notify = false;
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 307 */       if (notify)
/* 308 */         synchronized (this.semObj) {
/* 309 */           this.semObj.notifyAll();
/*     */         }
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 388 */       return "CLASS: OutgoingQueue\n";
/*     */     }
/*     */ 
/*     */     private class QueueWorker extends Thread
/*     */     {
/* 319 */       boolean alertQueueWait = false;
/* 320 */       boolean messageQueueWait = false;
/*     */ 
/*     */       private QueueWorker() {  } 
/* 322 */       public void run() { List messageList = new LinkedList();
/*     */ 
/* 325 */         while (MessageService.this.isServiceEnabled()) {
/* 326 */           messageList.clear();
/* 327 */           synchronized (MessageService.OutgoingQueue.this.alertQueue) {
/* 328 */             if (MessageService.OutgoingQueue.this.alertQueue.isEmpty()) {
/* 329 */               this.alertQueueWait = true;
/*     */             }
/*     */             else {
/* 332 */               this.alertQueueWait = false;
/*     */               do
/*     */               {
/* 335 */                 messageList.add(MessageService.OutgoingQueue.this.alertQueue.removeFirst());
/*     */ 
/* 334 */                 if (messageList.size() >= MessageService.this.maxSendingQueueSize) break; 
/* 334 */               }while (!MessageService.OutgoingQueue.this.alertQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 339 */           synchronized (MessageService.OutgoingQueue.this.messageQueue) {
/* 340 */             if (MessageService.OutgoingQueue.this.messageQueue.isEmpty()) {
/* 341 */               this.messageQueueWait = true;
/*     */             }
/*     */             else {
/* 344 */               this.messageQueueWait = false;
/*     */               do
/*     */               {
/* 347 */                 messageList.add(MessageService.OutgoingQueue.this.messageQueue.removeFirst());
/*     */ 
/* 346 */                 if (messageList.size() >= MessageService.this.maxSendingQueueSize) break; 
/* 346 */               }while (!MessageService.OutgoingQueue.this.messageQueue.isEmpty());
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 352 */           if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 353 */             synchronized (MessageService.OutgoingQueue.this.semObj) {
/*     */               try {
/* 355 */                 MessageService.OutgoingQueue.this.semObj.wait();
/*     */               }
/*     */               catch (InterruptedException localInterruptedException)
/*     */               {
/*     */               }
/*     */             }
/*     */           }
/* 362 */           MessageWebService mws = null;
/* 363 */           int sentMessages = 0;
/*     */ 
/* 365 */           while (!messageList.isEmpty()) {
/* 366 */             Message message = (Message)messageList.remove(0);
/*     */             try {
/* 368 */               if (MessageService.this.isMonitorMode())
/* 369 */                 mws = MessageService.OutgoingQueue.this.mwsl.getMessageWebService(new URL(MessageService.this.createURL(message.getIP(), message.getPort())));
/* 370 */               else if (mws == null) {
/* 371 */                 mws = MessageService.OutgoingQueue.this.mwsl.getMessageWebService(new URL(MessageService.this.createURL()));
/*     */               }
/* 373 */               MessageService.logger.debug(getName() + "Sending Message(s)...\n" + message);
/* 374 */               mws.sendMessage(message);
/* 375 */               sentMessages++;
/*     */             } catch (Throwable e) {
/* 377 */               MessageService.logger.error("Send Message Failed" + message, e);
/* 378 */               MessageService.this.setConnected(false);
/* 379 */               mws = null;
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.MessageService
 * JD-Core Version:    0.6.0
 */