/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketIgnore
/*    */ {
/*    */   byte[] payload;
/*    */   byte[] body;
/*    */ 
/*    */   public void setBody(byte[] body)
/*    */   {
/* 20 */     this.body = body;
/* 21 */     this.payload = null;
/*    */   }
/*    */ 
/*    */   public PacketIgnore(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 26 */     this.payload = new byte[len];
/* 27 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 29 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 31 */     int packet_type = tr.readByte();
/*    */ 
/* 33 */     if (packet_type != 2)
/* 34 */       throw new IOException("This is not a SSH_MSG_IGNORE packet! (" + packet_type + ")");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 41 */     if (this.payload == null)
/*    */     {
/* 43 */       TypesWriter tw = new TypesWriter();
/* 44 */       tw.writeByte(2);
/* 45 */       tw.writeString(this.body, 0, this.body.length);
/* 46 */       this.payload = tw.getBytes();
/*    */     }
/* 48 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketIgnore
 * JD-Core Version:    0.6.0
 */