package ch.ethz.ssh2.crypto;

public class PEMStructure
{
  int pemType;
  String[] dekInfo;
  String[] procType;
  byte[] data;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.PEMStructure
 * JD-Core Version:    0.6.0
 */