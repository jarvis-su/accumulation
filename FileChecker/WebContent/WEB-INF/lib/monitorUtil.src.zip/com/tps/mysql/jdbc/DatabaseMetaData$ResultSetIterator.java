/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class DatabaseMetaData$ResultSetIterator extends DatabaseMetaData.IteratorWithCleanup
/*     */ {
/*     */   int colIndex;
/*     */   ResultSet resultSet;
/*     */   private final DatabaseMetaData this$0;
/*     */ 
/*     */   DatabaseMetaData$ResultSetIterator(DatabaseMetaData this$0, ResultSet rs, int index)
/*     */   {
/* 120 */     super(this$0); this.this$0 = this$0;
/* 121 */     this.resultSet = rs;
/* 122 */     this.colIndex = index;
/*     */   }
/*     */ 
/*     */   void close() throws SQLException {
/* 126 */     this.resultSet.close();
/*     */   }
/*     */ 
/*     */   boolean hasNext() throws SQLException {
/* 130 */     return this.resultSet.next();
/*     */   }
/*     */ 
/*     */   Object next() throws SQLException {
/* 134 */     return this.resultSet.getObject(this.colIndex);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.ResultSetIterator
 * JD-Core Version:    0.6.0
 */