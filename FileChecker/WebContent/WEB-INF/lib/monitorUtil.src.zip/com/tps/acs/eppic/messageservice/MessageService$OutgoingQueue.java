/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class MessageService$OutgoingQueue
/*     */ {
/*     */   private final MessageService.OutgoingQueue.QueueWorker[] threads;
/*     */   private final LinkedList alertQueue;
/*     */   private final LinkedList messageQueue;
/*     */   private MessageWebServiceServiceLocator mwsl;
/* 266 */   Object semObj = new Object();
/*     */ 
/*     */   public MessageService$OutgoingQueue(MessageService arg1) {
/* 269 */     this.mwsl = new MessageWebServiceServiceLocator();
/* 270 */     this.alertQueue = new LinkedList();
/* 271 */     this.messageQueue = new LinkedList();
/* 272 */     this.threads = new MessageService.OutgoingQueue.QueueWorker[2];
/* 273 */     for (int i = 0; i < this.threads.length; i++) {
/* 274 */       this.threads[i] = new MessageService.OutgoingQueue.QueueWorker(this, null);
/* 275 */       this.threads[i].setName("OUTGOING_QUEUE_" + i);
/* 276 */       this.threads[i].start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message) {
/* 281 */     boolean notify = false;
/* 282 */     if ((message.getServiceId() == "HEARTBEAT") || 
/* 283 */       (message.getType().getTypeId() == 1) || 
/* 284 */       (message.getType().getTypeId() == 0))
/*     */     {
/* 286 */       synchronized (this.alertQueue) {
/* 287 */         if (this.alertQueue.size() <= MessageService.access$3(this.this$0)) {
/* 288 */           this.alertQueue.addLast(message);
/* 289 */           notify = true;
/*     */         } else {
/* 291 */           notify = false;
/*     */         }
/*     */       }
/*     */     }
/* 295 */     synchronized (this.messageQueue) {
/* 296 */       int queueSize = this.messageQueue.size();
/* 297 */       if (queueSize <= MessageService.access$4(this.this$0)) {
/* 298 */         this.messageQueue.addLast(message);
/* 299 */         if (queueSize >= MessageService.access$5(this.this$0))
/* 300 */           notify = true;
/*     */         else {
/* 302 */           notify = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 307 */     if (notify)
/* 308 */       synchronized (this.semObj) {
/* 309 */         this.semObj.notifyAll();
/*     */       }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 388 */     return "CLASS: OutgoingQueue\n";
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService.OutgoingQueue
 * JD-Core Version:    0.6.0
 */