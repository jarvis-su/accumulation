/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ public class MySQLTimeoutException extends MySQLTransientException
/*    */ {
/*    */   public MySQLTimeoutException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 29 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLTimeoutException(String reason, String SQLState) {
/* 33 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLTimeoutException(String reason) {
/* 37 */     super(reason);
/*    */   }
/*    */ 
/*    */   public MySQLTimeoutException() {
/* 41 */     super("Statement cancelled due to timeout or client request");
/*    */   }
/*    */ 
/*    */   public int getErrorCode()
/*    */   {
/* 46 */     return super.getErrorCode();
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLTimeoutException
 * JD-Core Version:    0.6.0
 */