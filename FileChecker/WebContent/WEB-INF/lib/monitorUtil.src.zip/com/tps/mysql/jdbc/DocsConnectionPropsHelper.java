/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class DocsConnectionPropsHelper extends ConnectionProperties
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 18 */     System.out.println(new DocsConnectionPropsHelper().exposeAsXml());
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DocsConnectionPropsHelper
 * JD-Core Version:    0.6.0
 */