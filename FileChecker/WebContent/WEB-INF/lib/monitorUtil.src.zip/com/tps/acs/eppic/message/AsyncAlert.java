/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ 
/*    */ public class AsyncAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = 295850997119909043L;
/*    */   private static final String COMMIT_COUNT = "COMMIT_COUNT";
/*    */   private static final String ID_TABLE = "ID_TABLE";
/*    */   private static final String TLOG_ID = "TLOG_ID";
/*    */ 
/*    */   public AsyncAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AsyncAlert(HashMap map)
/*    */   {
/* 23 */     setData(map);
/*    */   }
/*    */ 
/*    */   public AsyncAlert(String code, String description, int commitCount, ArrayList idtable, int tlogId)
/*    */   {
/* 29 */     super(code, description);
/* 30 */     setData("COMMIT_COUNT", new Integer(commitCount));
/* 31 */     setData("ID_TABLE", idtable);
/* 32 */     setData("TLOG_ID", new Integer(tlogId));
/*    */   }
/*    */ 
/*    */   public int getCommitCount() {
/* 36 */     int retVal = -1;
/* 37 */     if (getData("COMMIT_COUNT") != null) {
/* 38 */       retVal = ((Integer)getData("COMMIT_COUNT")).intValue();
/*    */     }
/* 40 */     return retVal;
/*    */   }
/*    */ 
/*    */   public List getIdTable()
/*    */   {
/*    */     ArrayList list;
/*    */     ArrayList list;
/* 45 */     if (getData("ID_TABLE") != null)
/* 46 */       list = (ArrayList)getData("ID_TABLE");
/*    */     else {
/* 48 */       list = new ArrayList(0);
/*    */     }
/* 50 */     return list;
/*    */   }
/*    */ 
/*    */   public int getTlogId() {
/* 54 */     int retVal = -1;
/* 55 */     if (getData("TLOG_ID") != null) {
/* 56 */       retVal = ((Integer)getData("TLOG_ID")).intValue();
/*    */     }
/* 58 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 62 */     return super.toString() + 
/* 63 */       "  CC: " + getCommitCount() + "\n" + 
/* 64 */       "  TLOG ID: " + getTlogId() + "\n" + 
/* 65 */       "  IdTable: " + getIdTable() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.AsyncAlert
 * JD-Core Version:    0.6.0
 */