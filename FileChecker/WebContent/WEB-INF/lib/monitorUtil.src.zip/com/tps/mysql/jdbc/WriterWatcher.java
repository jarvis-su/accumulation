package com.mysql.jdbc;

abstract interface WriterWatcher
{
  public abstract void writerClosed(WatchableWriter paramWatchableWriter);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.WriterWatcher
 * JD-Core Version:    0.6.0
 */