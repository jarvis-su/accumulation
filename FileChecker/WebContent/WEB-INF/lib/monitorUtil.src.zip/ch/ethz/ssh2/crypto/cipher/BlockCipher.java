package ch.ethz.ssh2.crypto.cipher;

public abstract interface BlockCipher
{
  public abstract void init(boolean paramBoolean, byte[] paramArrayOfByte);

  public abstract int getBlockSize();

  public abstract void transformBlock(byte[] paramArrayOfByte1, int paramInt1, byte[] paramArrayOfByte2, int paramInt2);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.BlockCipher
 * JD-Core Version:    0.6.0
 */