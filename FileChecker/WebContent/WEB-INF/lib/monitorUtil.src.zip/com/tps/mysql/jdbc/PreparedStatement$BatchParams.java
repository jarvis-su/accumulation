/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ 
/*     */ class PreparedStatement$BatchParams
/*     */ {
/*     */   boolean[] isNull;
/*     */   boolean[] isStream;
/*     */   InputStream[] parameterStreams;
/*     */   byte[][] parameterStrings;
/*     */   int[] streamLengths;
/*     */   private final PreparedStatement this$0;
/*     */ 
/*     */   PreparedStatement$BatchParams(PreparedStatement this$0, byte[][] strings, InputStream[] streams, boolean[] isStreamFlags, int[] lengths, boolean[] isNullFlags)
/*     */   {
/*  95 */     this.this$0 = this$0;
/*     */ 
/*  84 */     this.isNull = null;
/*     */ 
/*  86 */     this.isStream = null;
/*     */ 
/*  88 */     this.parameterStreams = null;
/*     */ 
/*  90 */     this.parameterStrings = ((byte[][])null);
/*     */ 
/*  92 */     this.streamLengths = null;
/*     */ 
/*  99 */     this.parameterStrings = new byte[strings.length][];
/* 100 */     this.parameterStreams = new InputStream[streams.length];
/* 101 */     this.isStream = new boolean[isStreamFlags.length];
/* 102 */     this.streamLengths = new int[lengths.length];
/* 103 */     this.isNull = new boolean[isNullFlags.length];
/* 104 */     System.arraycopy(strings, 0, this.parameterStrings, 0, strings.length);
/*     */ 
/* 106 */     System.arraycopy(streams, 0, this.parameterStreams, 0, streams.length);
/*     */ 
/* 108 */     System.arraycopy(isStreamFlags, 0, this.isStream, 0, isStreamFlags.length);
/*     */ 
/* 110 */     System.arraycopy(lengths, 0, this.streamLengths, 0, lengths.length);
/* 111 */     System.arraycopy(isNullFlags, 0, this.isNull, 0, isNullFlags.length);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.PreparedStatement.BatchParams
 * JD-Core Version:    0.6.0
 */