/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import java.util.Hashtable;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.Name;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.spi.ObjectFactory;
/*     */ 
/*     */ public class MysqlDataSourceFactory
/*     */   implements ObjectFactory
/*     */ {
/*     */   protected static final String DATA_SOURCE_CLASS_NAME = "com.mysql.jdbc.jdbc2.optional.MysqlDataSource";
/*     */   protected static final String POOL_DATA_SOURCE_CLASS_NAME = "com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSource";
/*     */ 
/*     */   public Object getObjectInstance(Object refObj, Name nm, Context ctx, Hashtable env)
/*     */     throws Exception
/*     */   {
/*  70 */     Reference ref = (Reference)refObj;
/*  71 */     String className = ref.getClassName();
/*     */ 
/*  73 */     if ((className != null) && ((className.equals("com.mysql.jdbc.jdbc2.optional.MysqlDataSource")) || (className.equals("com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSource"))))
/*     */     {
/*  76 */       MysqlDataSource dataSource = null;
/*     */       try
/*     */       {
/*  79 */         dataSource = (MysqlDataSource)Class.forName(className).newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/*  82 */         throw new RuntimeException("Unable to create DataSource of class '" + className + "', reason: " + ex.toString());
/*     */       }
/*     */ 
/*  86 */       int portNumber = 3306;
/*     */ 
/*  88 */       String portNumberAsString = nullSafeRefAddrStringGet("port", ref);
/*     */ 
/*  90 */       if (portNumberAsString != null) {
/*  91 */         portNumber = Integer.parseInt(portNumberAsString);
/*     */       }
/*     */ 
/*  94 */       dataSource.setPort(portNumber);
/*     */ 
/*  96 */       String user = nullSafeRefAddrStringGet("user", ref);
/*     */ 
/*  98 */       if (user != null) {
/*  99 */         dataSource.setUser(user);
/*     */       }
/*     */ 
/* 102 */       String password = nullSafeRefAddrStringGet("password", ref);
/*     */ 
/* 104 */       if (password != null) {
/* 105 */         dataSource.setPassword(password);
/*     */       }
/*     */ 
/* 108 */       String serverName = nullSafeRefAddrStringGet("serverName", ref);
/*     */ 
/* 110 */       if (serverName != null) {
/* 111 */         dataSource.setServerName(serverName);
/*     */       }
/*     */ 
/* 114 */       String databaseName = nullSafeRefAddrStringGet("databaseName", ref);
/*     */ 
/* 116 */       if (databaseName != null) {
/* 117 */         dataSource.setDatabaseName(databaseName);
/*     */       }
/*     */ 
/* 120 */       String explicitUrlAsString = nullSafeRefAddrStringGet("explicitUrl", ref);
/*     */ 
/* 122 */       if ((explicitUrlAsString != null) && 
/* 123 */         (Boolean.valueOf(explicitUrlAsString).booleanValue())) {
/* 124 */         dataSource.setUrl(nullSafeRefAddrStringGet("url", ref));
/*     */       }
/*     */ 
/* 128 */       dataSource.setPropertiesViaRef(ref);
/*     */ 
/* 130 */       return dataSource;
/*     */     }
/*     */ 
/* 134 */     return null;
/*     */   }
/*     */ 
/*     */   private String nullSafeRefAddrStringGet(String referenceName, Reference ref) {
/* 138 */     RefAddr refAddr = ref.get(referenceName);
/*     */ 
/* 140 */     String asString = refAddr != null ? (String)refAddr.getContent() : null;
/*     */ 
/* 142 */     return asString;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.jdbc2.optional.MysqlDataSourceFactory
 * JD-Core Version:    0.6.0
 */