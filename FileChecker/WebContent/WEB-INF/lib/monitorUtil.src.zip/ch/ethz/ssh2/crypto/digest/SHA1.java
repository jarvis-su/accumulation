/*     */ package ch.ethz.ssh2.crypto.digest;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ 
/*     */ public final class SHA1
/*     */   implements Digest
/*     */ {
/*     */   private int H0;
/*     */   private int H1;
/*     */   private int H2;
/*     */   private int H3;
/*     */   private int H4;
/*  17 */   private final byte[] msg = new byte[64];
/*  18 */   private final int[] w = new int[80];
/*     */   private int currentPos;
/*     */   private long currentLen;
/*     */ 
/*     */   public SHA1()
/*     */   {
/*  24 */     reset();
/*     */   }
/*     */ 
/*     */   public final int getDigestLength()
/*     */   {
/*  29 */     return 20;
/*     */   }
/*     */ 
/*     */   public final void reset()
/*     */   {
/*  34 */     this.H0 = 1732584193;
/*  35 */     this.H1 = -271733879;
/*  36 */     this.H2 = -1732584194;
/*  37 */     this.H3 = 271733878;
/*  38 */     this.H4 = -1009589776;
/*     */ 
/*  40 */     this.currentPos = 0;
/*  41 */     this.currentLen = 0L;
/*     */   }
/*     */ 
/*     */   public final void update(byte[] b, int off, int len)
/*     */   {
/*  46 */     for (int i = off; i < off + len; i++)
/*  47 */       update(b[i]);
/*     */   }
/*     */ 
/*     */   public final void update(byte[] b)
/*     */   {
/*  52 */     for (int i = 0; i < b.length; i++)
/*  53 */       update(b[i]);
/*     */   }
/*     */ 
/*     */   public final void update(byte b)
/*     */   {
/*  59 */     this.msg[(this.currentPos++)] = b;
/*  60 */     this.currentLen += 8L;
/*  61 */     if (this.currentPos == 64)
/*     */     {
/*  63 */       perform();
/*  64 */       this.currentPos = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static final String toHexString(byte[] b)
/*     */   {
/*  70 */     String hexChar = "0123456789ABCDEF";
/*     */ 
/*  72 */     StringBuffer sb = new StringBuffer();
/*  73 */     for (int i = 0; i < b.length; i++)
/*     */     {
/*  75 */       sb.append("0123456789ABCDEF".charAt(b[i] >> 4 & 0xF));
/*  76 */       sb.append("0123456789ABCDEF".charAt(b[i] & 0xF));
/*     */     }
/*  78 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private final void putInt(byte[] b, int pos, int val)
/*     */   {
/*  83 */     b[pos] = (byte)(val >> 24);
/*  84 */     b[(pos + 1)] = (byte)(val >> 16);
/*  85 */     b[(pos + 2)] = (byte)(val >> 8);
/*  86 */     b[(pos + 3)] = (byte)val;
/*     */   }
/*     */ 
/*     */   public final void digest(byte[] out)
/*     */   {
/*  91 */     digest(out, 0);
/*     */   }
/*     */ 
/*     */   public final void digest(byte[] out, int off)
/*     */   {
/*  96 */     long l = this.currentLen;
/*     */ 
/*  98 */     update(-128);
/*     */ 
/* 101 */     while (this.currentPos != 56) {
/* 102 */       update(0);
/*     */     }
/* 104 */     update((byte)(int)(l >> 56));
/* 105 */     update((byte)(int)(l >> 48));
/* 106 */     update((byte)(int)(l >> 40));
/* 107 */     update((byte)(int)(l >> 32));
/*     */ 
/* 109 */     update((byte)(int)(l >> 24));
/* 110 */     update((byte)(int)(l >> 16));
/* 111 */     update((byte)(int)(l >> 8));
/* 112 */     update((byte)(int)l);
/*     */ 
/* 116 */     putInt(out, off, this.H0);
/* 117 */     putInt(out, off + 4, this.H1);
/* 118 */     putInt(out, off + 8, this.H2);
/* 119 */     putInt(out, off + 12, this.H3);
/* 120 */     putInt(out, off + 16, this.H4);
/*     */ 
/* 122 */     reset();
/*     */   }
/*     */ 
/*     */   private final void perform()
/*     */   {
/* 135 */     for (int i = 0; i < 16; i++) {
/* 136 */       this.w[i] = 
/* 137 */         ((this.msg[(i * 4)] & 0xFF) << 24 | (this.msg[(i * 4 + 1)] & 0xFF) << 16 | (this.msg[(i * 4 + 2)] & 0xFF) << 8 | 
/* 137 */         this.msg[(i * 4 + 3)] & 0xFF);
/*     */     }
/* 139 */     for (int t = 16; t < 80; t++)
/*     */     {
/* 141 */       int x = this.w[(t - 3)] ^ this.w[(t - 8)] ^ this.w[(t - 14)] ^ this.w[(t - 16)];
/* 142 */       this.w[t] = (x << 1 | x >>> 31);
/*     */     }
/*     */ 
/* 145 */     int A = this.H0;
/* 146 */     int B = this.H1;
/* 147 */     int C = this.H2;
/* 148 */     int D = this.H3;
/* 149 */     int E = this.H4;
/*     */ 
/* 153 */     for (int t = 0; t <= 19; t++)
/*     */     {
/* 155 */       int T = (A << 5 | A >>> 27) + (B & C | (B ^ 0xFFFFFFFF) & D) + E + this.w[t] + 1518500249;
/* 156 */       E = D;
/* 157 */       D = C;
/* 158 */       C = B << 30 | B >>> 2;
/* 159 */       B = A;
/* 160 */       A = T;
/*     */     }
/*     */ 
/* 164 */     for (int t = 20; t <= 39; t++)
/*     */     {
/* 166 */       int T = (A << 5 | A >>> 27) + (B ^ C ^ D) + E + this.w[t] + 1859775393;
/* 167 */       E = D;
/* 168 */       D = C;
/* 169 */       C = B << 30 | B >>> 2;
/* 170 */       B = A;
/* 171 */       A = T;
/*     */     }
/*     */ 
/* 175 */     for (int t = 40; t <= 59; t++)
/*     */     {
/* 177 */       int T = (A << 5 | A >>> 27) + (B & C | B & D | C & D) + E + this.w[t] + -1894007588;
/* 178 */       E = D;
/* 179 */       D = C;
/* 180 */       C = B << 30 | B >>> 2;
/* 181 */       B = A;
/* 182 */       A = T;
/*     */     }
/*     */ 
/* 186 */     for (int t = 60; t <= 79; t++)
/*     */     {
/* 188 */       int T = (A << 5 | A >>> 27) + (B ^ C ^ D) + E + this.w[t] + -899497514;
/* 189 */       E = D;
/* 190 */       D = C;
/* 191 */       C = B << 30 | B >>> 2;
/* 192 */       B = A;
/* 193 */       A = T;
/*     */     }
/*     */ 
/* 197 */     this.H0 += A;
/* 198 */     this.H1 += B;
/* 199 */     this.H2 += C;
/* 200 */     this.H3 += D;
/* 201 */     this.H4 += E;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 208 */     SHA1 sha = new SHA1();
/*     */ 
/* 210 */     byte[] dig1 = new byte[20];
/* 211 */     byte[] dig2 = new byte[20];
/* 212 */     byte[] dig3 = new byte[20];
/*     */ 
/* 223 */     sha.update("abc".getBytes());
/* 224 */     sha.digest(dig1);
/*     */ 
/* 226 */     sha.update("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq".getBytes());
/* 227 */     sha.digest(dig2);
/*     */ 
/* 229 */     for (int i = 0; i < 1000000; i++)
/* 230 */       sha.update(97);
/* 231 */     sha.digest(dig3);
/*     */ 
/* 233 */     String dig1_res = toHexString(dig1);
/* 234 */     String dig2_res = toHexString(dig2);
/* 235 */     String dig3_res = toHexString(dig3);
/*     */ 
/* 237 */     String dig1_ref = "A9993E364706816ABA3E25717850C26C9CD0D89D";
/* 238 */     String dig2_ref = "84983E441C3BD26EBAAE4AA1F95129E5E54670F1";
/* 239 */     String dig3_ref = "34AA973CD4C4DAA4F61EEB2BDBAD27316534016F";
/*     */ 
/* 241 */     if (dig1_res.equals(dig1_ref))
/* 242 */       System.out.println("SHA-1 Test 1 OK.");
/*     */     else {
/* 244 */       System.out.println("SHA-1 Test 1 FAILED.");
/*     */     }
/* 246 */     if (dig2_res.equals(dig2_ref))
/* 247 */       System.out.println("SHA-1 Test 2 OK.");
/*     */     else {
/* 249 */       System.out.println("SHA-1 Test 2 FAILED.");
/*     */     }
/* 251 */     if (dig3_res.equals(dig3_ref))
/* 252 */       System.out.println("SHA-1 Test 3 OK.");
/*     */     else
/* 254 */       System.out.println("SHA-1 Test 3 FAILED.");
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.SHA1
 * JD-Core Version:    0.6.0
 */