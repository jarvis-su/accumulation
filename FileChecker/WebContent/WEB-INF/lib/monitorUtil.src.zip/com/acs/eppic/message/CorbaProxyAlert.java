/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class CorbaProxyAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = -7688559133676611909L;
/*    */   private static final String METHODNAME = "METHODNAME";
/*    */   private static final String RESPONSETIME = "RESPONSETIME";
/*    */ 
/*    */   public CorbaProxyAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CorbaProxyAlert(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public CorbaProxyAlert(String code, String description, String methodName, long responseTime) {
/* 23 */     super(code, description);
/* 24 */     setData("METHODNAME", methodName);
/* 25 */     setData("RESPONSETIME", new Long(responseTime));
/*    */   }
/*    */ 
/*    */   public String getMethodName() {
/* 29 */     String methodName = "";
/* 30 */     if (getData("METHODNAME") != null) {
/* 31 */       methodName = (String)getData("METHODNAME");
/*    */     }
/* 33 */     return methodName;
/*    */   }
/*    */ 
/*    */   public long getResponseTime() {
/* 37 */     long retVal = -1L;
/* 38 */     if (getData("RESPONSETIME") != null) {
/* 39 */       retVal = ((Long)getData("RESPONSETIME")).intValue();
/*    */     }
/* 41 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return super.toString() + 
/* 46 */       "  Method Name: " + getMethodName() + "\n" + 
/* 47 */       "  Response Time: " + getResponseTime() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.CorbaProxyAlert
 * JD-Core Version:    0.6.0
 */