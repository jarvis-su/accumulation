/*     */ package ch.ethz.ssh2.transport;
/*     */ 
/*     */ import ch.ethz.ssh2.ConnectionInfo;
/*     */ import ch.ethz.ssh2.DHGexParameters;
/*     */ import ch.ethz.ssh2.ServerHostKeyVerifier;
/*     */ import ch.ethz.ssh2.crypto.CryptoWishList;
/*     */ import ch.ethz.ssh2.crypto.KeyMaterial;
/*     */ import ch.ethz.ssh2.crypto.cipher.BlockCipher;
/*     */ import ch.ethz.ssh2.crypto.cipher.BlockCipherFactory;
/*     */ import ch.ethz.ssh2.crypto.dh.DhExchange;
/*     */ import ch.ethz.ssh2.crypto.dh.DhGroupExchange;
/*     */ import ch.ethz.ssh2.crypto.digest.MAC;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import ch.ethz.ssh2.packets.PacketKexDHInit;
/*     */ import ch.ethz.ssh2.packets.PacketKexDHReply;
/*     */ import ch.ethz.ssh2.packets.PacketKexDhGexGroup;
/*     */ import ch.ethz.ssh2.packets.PacketKexDhGexInit;
/*     */ import ch.ethz.ssh2.packets.PacketKexDhGexReply;
/*     */ import ch.ethz.ssh2.packets.PacketKexDhGexRequest;
/*     */ import ch.ethz.ssh2.packets.PacketKexDhGexRequestOld;
/*     */ import ch.ethz.ssh2.packets.PacketKexInit;
/*     */ import ch.ethz.ssh2.packets.PacketNewKeys;
/*     */ import ch.ethz.ssh2.signature.DSAPublicKey;
/*     */ import ch.ethz.ssh2.signature.DSASHA1Verify;
/*     */ import ch.ethz.ssh2.signature.DSASignature;
/*     */ import ch.ethz.ssh2.signature.RSAPublicKey;
/*     */ import ch.ethz.ssh2.signature.RSASHA1Verify;
/*     */ import ch.ethz.ssh2.signature.RSASignature;
/*     */ import java.io.IOException;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class KexManager
/*     */ {
/*  43 */   private static final Logger log = Logger.getLogger(KexManager.class);
/*     */   KexState kxs;
/*  46 */   int kexCount = 0;
/*     */   KeyMaterial km;
/*     */   byte[] sessionId;
/*     */   ClientServerHello csh;
/*  51 */   final Object accessLock = new Object();
/*  52 */   ConnectionInfo lastConnInfo = null;
/*     */ 
/*  54 */   boolean connectionClosed = false;
/*     */ 
/*  56 */   boolean ignore_next_kex_packet = false;
/*     */   final TransportManager tm;
/*     */   CryptoWishList nextKEXcryptoWishList;
/*     */   DHGexParameters nextKEXdhgexParameters;
/*     */   ServerHostKeyVerifier verifier;
/*     */   final String hostname;
/*     */   final int port;
/*     */   final SecureRandom rnd;
/*     */ 
/*     */   public KexManager(TransportManager tm, ClientServerHello csh, CryptoWishList initialCwl, String hostname, int port, ServerHostKeyVerifier keyVerifier, SecureRandom rnd)
/*     */   {
/*  71 */     this.tm = tm;
/*  72 */     this.csh = csh;
/*  73 */     this.nextKEXcryptoWishList = initialCwl;
/*  74 */     this.nextKEXdhgexParameters = new DHGexParameters();
/*  75 */     this.hostname = hostname;
/*  76 */     this.port = port;
/*  77 */     this.verifier = keyVerifier;
/*  78 */     this.rnd = rnd;
/*     */   }
/*     */ 
/*     */   public ConnectionInfo getOrWaitForConnectionInfo(int minKexCount) throws IOException
/*     */   {
/*  83 */     synchronized (this.accessLock)
/*     */     {
/*     */       while (true)
/*     */       {
/*  87 */         if ((this.lastConnInfo != null) && (this.lastConnInfo.keyExchangeCounter >= minKexCount)) {
/*  88 */           return this.lastConnInfo;
/*     */         }
/*  90 */         if (this.connectionClosed) {
/*  91 */           throw ((IOException)new IOException("Key exchange was not finished, connection is closed.")
/*  92 */             .initCause(this.tm.getReasonClosedCause()));
/*     */         }
/*     */         try
/*     */         {
/*  96 */           this.accessLock.wait();
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private String getFirstMatch(String[] client, String[] server) throws NegotiateException
/*     */   {
/* 107 */     if ((client == null) || (server == null)) {
/* 108 */       throw new IllegalArgumentException();
/*     */     }
/* 110 */     if (client.length == 0) {
/* 111 */       return null;
/*     */     }
/* 113 */     for (int i = 0; i < client.length; i++)
/*     */     {
/* 115 */       for (int j = 0; j < server.length; j++)
/*     */       {
/* 117 */         if (client[i].equals(server[j]))
/* 118 */           return client[i];
/*     */       }
/*     */     }
/* 121 */     throw new NegotiateException();
/*     */   }
/*     */ 
/*     */   private boolean compareFirstOfNameList(String[] a, String[] b)
/*     */   {
/* 126 */     if ((a == null) || (b == null)) {
/* 127 */       throw new IllegalArgumentException();
/*     */     }
/* 129 */     if ((a.length == 0) && (b.length == 0)) {
/* 130 */       return true;
/*     */     }
/* 132 */     if ((a.length == 0) || (b.length == 0)) {
/* 133 */       return false;
/*     */     }
/* 135 */     return a[0].equals(b[0]);
/*     */   }
/*     */ 
/*     */   private boolean isGuessOK(KexParameters cpar, KexParameters spar)
/*     */   {
/* 140 */     if ((cpar == null) || (spar == null)) {
/* 141 */       throw new IllegalArgumentException();
/*     */     }
/* 143 */     if (!compareFirstOfNameList(cpar.kex_algorithms, spar.kex_algorithms))
/*     */     {
/* 145 */       return false;
/*     */     }
/*     */ 
/* 150 */     return compareFirstOfNameList(cpar.server_host_key_algorithms, spar.server_host_key_algorithms);
/*     */   }
/*     */ 
/*     */   private NegotiatedParameters mergeKexParameters(KexParameters client, KexParameters server)
/*     */   {
/* 164 */     NegotiatedParameters np = new NegotiatedParameters();
/*     */     try
/*     */     {
/* 168 */       np.kex_algo = getFirstMatch(client.kex_algorithms, server.kex_algorithms);
/*     */ 
/* 170 */       log.log(20, "kex_algo=" + np.kex_algo);
/*     */ 
/* 172 */       np.server_host_key_algo = 
/* 173 */         getFirstMatch(client.server_host_key_algorithms, 
/* 173 */         server.server_host_key_algorithms);
/*     */ 
/* 175 */       log.log(20, "server_host_key_algo=" + np.server_host_key_algo);
/*     */ 
/* 177 */       np.enc_algo_client_to_server = 
/* 178 */         getFirstMatch(client.encryption_algorithms_client_to_server, 
/* 178 */         server.encryption_algorithms_client_to_server);
/* 179 */       np.enc_algo_server_to_client = 
/* 180 */         getFirstMatch(client.encryption_algorithms_server_to_client, 
/* 180 */         server.encryption_algorithms_server_to_client);
/*     */ 
/* 182 */       log.log(20, "enc_algo_client_to_server=" + np.enc_algo_client_to_server);
/* 183 */       log.log(20, "enc_algo_server_to_client=" + np.enc_algo_server_to_client);
/*     */ 
/* 185 */       np.mac_algo_client_to_server = 
/* 186 */         getFirstMatch(client.mac_algorithms_client_to_server, 
/* 186 */         server.mac_algorithms_client_to_server);
/* 187 */       np.mac_algo_server_to_client = 
/* 188 */         getFirstMatch(client.mac_algorithms_server_to_client, 
/* 188 */         server.mac_algorithms_server_to_client);
/*     */ 
/* 190 */       log.log(20, "mac_algo_client_to_server=" + np.mac_algo_client_to_server);
/* 191 */       log.log(20, "mac_algo_server_to_client=" + np.mac_algo_server_to_client);
/*     */ 
/* 193 */       np.comp_algo_client_to_server = 
/* 194 */         getFirstMatch(client.compression_algorithms_client_to_server, 
/* 194 */         server.compression_algorithms_client_to_server);
/* 195 */       np.comp_algo_server_to_client = 
/* 196 */         getFirstMatch(client.compression_algorithms_server_to_client, 
/* 196 */         server.compression_algorithms_server_to_client);
/*     */ 
/* 198 */       log.log(20, "comp_algo_client_to_server=" + np.comp_algo_client_to_server);
/* 199 */       log.log(20, "comp_algo_server_to_client=" + np.comp_algo_server_to_client);
/*     */     }
/*     */     catch (NegotiateException e)
/*     */     {
/* 204 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 209 */       np.lang_client_to_server = 
/* 210 */         getFirstMatch(client.languages_client_to_server, 
/* 210 */         server.languages_client_to_server);
/*     */     }
/*     */     catch (NegotiateException e1)
/*     */     {
/* 214 */       np.lang_client_to_server = null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 219 */       np.lang_server_to_client = 
/* 220 */         getFirstMatch(client.languages_server_to_client, 
/* 220 */         server.languages_server_to_client);
/*     */     }
/*     */     catch (NegotiateException e2)
/*     */     {
/* 224 */       np.lang_server_to_client = null;
/*     */     }
/*     */ 
/* 227 */     if (isGuessOK(client, server)) {
/* 228 */       np.guessOK = true;
/*     */     }
/* 230 */     return np;
/*     */   }
/*     */ 
/*     */   public synchronized void initiateKEX(CryptoWishList cwl, DHGexParameters dhgex) throws IOException
/*     */   {
/* 235 */     this.nextKEXcryptoWishList = cwl;
/* 236 */     this.nextKEXdhgexParameters = dhgex;
/*     */ 
/* 238 */     if (this.kxs == null)
/*     */     {
/* 240 */       this.kxs = new KexState();
/*     */ 
/* 242 */       this.kxs.dhgexParameters = this.nextKEXdhgexParameters;
/* 243 */       PacketKexInit kp = new PacketKexInit(this.nextKEXcryptoWishList, this.rnd);
/* 244 */       this.kxs.localKEX = kp;
/* 245 */       this.tm.sendKexMessage(kp.getPayload());
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean establishKeyMaterial()
/*     */   {
/*     */     try
/*     */     {
/* 253 */       int mac_cs_key_len = MAC.getKeyLen(this.kxs.np.mac_algo_client_to_server);
/* 254 */       int enc_cs_key_len = BlockCipherFactory.getKeySize(this.kxs.np.enc_algo_client_to_server);
/* 255 */       int enc_cs_block_len = BlockCipherFactory.getBlockSize(this.kxs.np.enc_algo_client_to_server);
/*     */ 
/* 257 */       int mac_sc_key_len = MAC.getKeyLen(this.kxs.np.mac_algo_server_to_client);
/* 258 */       int enc_sc_key_len = BlockCipherFactory.getKeySize(this.kxs.np.enc_algo_server_to_client);
/* 259 */       int enc_sc_block_len = BlockCipherFactory.getBlockSize(this.kxs.np.enc_algo_server_to_client);
/*     */ 
/* 261 */       this.km = 
/* 262 */         KeyMaterial.create("SHA1", this.kxs.H, this.kxs.K, this.sessionId, enc_cs_key_len, enc_cs_block_len, mac_cs_key_len, 
/* 262 */         enc_sc_key_len, enc_sc_block_len, mac_sc_key_len);
/*     */     }
/*     */     catch (IllegalArgumentException e)
/*     */     {
/* 266 */       return false;
/*     */     }
/* 268 */     return true;
/*     */   }
/*     */ 
/*     */   private void finishKex() throws IOException
/*     */   {
/* 273 */     if (this.sessionId == null) {
/* 274 */       this.sessionId = this.kxs.H;
/*     */     }
/* 276 */     establishKeyMaterial();
/*     */ 
/* 280 */     PacketNewKeys ign = new PacketNewKeys();
/* 281 */     this.tm.sendKexMessage(ign.getPayload());
/*     */     try
/*     */     {
/* 288 */       BlockCipher cbc = BlockCipherFactory.createCipher(this.kxs.np.enc_algo_client_to_server, true, this.km.enc_key_client_to_server, 
/* 289 */         this.km.initial_iv_client_to_server);
/*     */ 
/* 291 */       mac = new MAC(this.kxs.np.mac_algo_client_to_server, this.km.integrity_key_client_to_server);
/*     */     }
/*     */     catch (IllegalArgumentException e1)
/*     */     {
/*     */       MAC mac;
/* 296 */       throw new IOException("Fatal error during MAC startup!");
/*     */     }
/*     */     MAC mac;
/*     */     BlockCipher cbc;
/* 299 */     this.tm.changeSendCipher(cbc, mac);
/* 300 */     this.tm.kexFinished();
/*     */   }
/*     */ 
/*     */   public static final String[] getDefaultServerHostkeyAlgorithmList()
/*     */   {
/* 305 */     return new String[] { "ssh-rsa", "ssh-dss" };
/*     */   }
/*     */ 
/*     */   public static final void checkServerHostkeyAlgorithmsList(String[] algos)
/*     */   {
/* 310 */     for (int i = 0; i < algos.length; i++)
/*     */     {
/* 312 */       if ((!"ssh-rsa".equals(algos[i])) && (!"ssh-dss".equals(algos[i])))
/* 313 */         throw new IllegalArgumentException("Unknown server host key algorithm '" + algos[i] + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   public static final String[] getDefaultKexAlgorithmList()
/*     */   {
/* 319 */     return new String[] { "diffie-hellman-group-exchange-sha1", "diffie-hellman-group14-sha1", 
/* 320 */       "diffie-hellman-group1-sha1" };
/*     */   }
/*     */ 
/*     */   public static final void checkKexAlgorithmList(String[] algos)
/*     */   {
/* 325 */     for (int i = 0; i < algos.length; i++)
/*     */     {
/* 327 */       if ("diffie-hellman-group-exchange-sha1".equals(algos[i])) {
/*     */         continue;
/*     */       }
/* 330 */       if ("diffie-hellman-group14-sha1".equals(algos[i])) {
/*     */         continue;
/*     */       }
/* 333 */       if ("diffie-hellman-group1-sha1".equals(algos[i])) {
/*     */         continue;
/*     */       }
/* 336 */       throw new IllegalArgumentException("Unknown kex algorithm '" + algos[i] + "'");
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean verifySignature(byte[] sig, byte[] hostkey) throws IOException
/*     */   {
/* 342 */     if (this.kxs.np.server_host_key_algo.equals("ssh-rsa"))
/*     */     {
/* 344 */       RSASignature rs = RSASHA1Verify.decodeSSHRSASignature(sig);
/* 345 */       RSAPublicKey rpk = RSASHA1Verify.decodeSSHRSAPublicKey(hostkey);
/*     */ 
/* 347 */       log.log(50, "Verifying ssh-rsa signature");
/*     */ 
/* 349 */       return RSASHA1Verify.verifySignature(this.kxs.H, rs, rpk);
/*     */     }
/*     */ 
/* 352 */     if (this.kxs.np.server_host_key_algo.equals("ssh-dss"))
/*     */     {
/* 354 */       DSASignature ds = DSASHA1Verify.decodeSSHDSASignature(sig);
/* 355 */       DSAPublicKey dpk = DSASHA1Verify.decodeSSHDSAPublicKey(hostkey);
/*     */ 
/* 357 */       log.log(50, "Verifying ssh-dss signature");
/*     */ 
/* 359 */       return DSASHA1Verify.verifySignature(this.kxs.H, ds, dpk);
/*     */     }
/*     */ 
/* 362 */     throw new IOException("Unknown server host key algorithm '" + this.kxs.np.server_host_key_algo + "'");
/*     */   }
/*     */ 
/*     */   public synchronized void handleMessage(byte[] msg, int msglen)
/*     */     throws IOException
/*     */   {
/* 369 */     if (msg == null)
/*     */     {
/* 371 */       synchronized (this.accessLock)
/*     */       {
/* 373 */         this.connectionClosed = true;
/* 374 */         this.accessLock.notifyAll();
/* 375 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 379 */     if ((this.kxs == null) && (msg[0] != 20)) {
/* 380 */       throw new IOException("Unexpected KEX message (type " + msg[0] + ")");
/*     */     }
/* 382 */     if (this.ignore_next_kex_packet)
/*     */     {
/* 384 */       this.ignore_next_kex_packet = false;
/* 385 */       return;
/*     */     }
/*     */ 
/* 388 */     if (msg[0] == 20)
/*     */     {
/* 390 */       if ((this.kxs != null) && (this.kxs.state != 0)) {
/* 391 */         throw new IOException("Unexpected SSH_MSG_KEXINIT message during on-going kex exchange!");
/*     */       }
/* 393 */       if (this.kxs == null)
/*     */       {
/* 399 */         this.kxs = new KexState();
/* 400 */         this.kxs.dhgexParameters = this.nextKEXdhgexParameters;
/* 401 */         PacketKexInit kip = new PacketKexInit(this.nextKEXcryptoWishList, this.rnd);
/* 402 */         this.kxs.localKEX = kip;
/* 403 */         this.tm.sendKexMessage(kip.getPayload());
/*     */       }
/*     */ 
/* 406 */       PacketKexInit kip = new PacketKexInit(msg, 0, msglen);
/* 407 */       this.kxs.remoteKEX = kip;
/*     */ 
/* 409 */       this.kxs.np = mergeKexParameters(this.kxs.localKEX.getKexParameters(), this.kxs.remoteKEX.getKexParameters());
/*     */ 
/* 411 */       if (this.kxs.np == null) {
/* 412 */         throw new IOException("Cannot negotiate, proposals do not match.");
/*     */       }
/* 414 */       if ((this.kxs.remoteKEX.isFirst_kex_packet_follows()) && (!this.kxs.np.guessOK))
/*     */       {
/* 420 */         this.ignore_next_kex_packet = true;
/*     */       }
/*     */ 
/* 423 */       if (this.kxs.np.kex_algo.equals("diffie-hellman-group-exchange-sha1"))
/*     */       {
/* 425 */         if (this.kxs.dhgexParameters.getMin_group_len() == 0)
/*     */         {
/* 427 */           PacketKexDhGexRequestOld dhgexreq = new PacketKexDhGexRequestOld(this.kxs.dhgexParameters);
/* 428 */           this.tm.sendKexMessage(dhgexreq.getPayload());
/*     */         }
/*     */         else
/*     */         {
/* 433 */           PacketKexDhGexRequest dhgexreq = new PacketKexDhGexRequest(this.kxs.dhgexParameters);
/* 434 */           this.tm.sendKexMessage(dhgexreq.getPayload());
/*     */         }
/* 436 */         this.kxs.state = 1;
/* 437 */         return;
/*     */       }
/*     */ 
/* 440 */       if ((this.kxs.np.kex_algo.equals("diffie-hellman-group1-sha1")) || 
/* 441 */         (this.kxs.np.kex_algo.equals("diffie-hellman-group14-sha1")))
/*     */       {
/* 443 */         this.kxs.dhx = new DhExchange();
/*     */ 
/* 445 */         if (this.kxs.np.kex_algo.equals("diffie-hellman-group1-sha1"))
/* 446 */           this.kxs.dhx.init(1, this.rnd);
/*     */         else {
/* 448 */           this.kxs.dhx.init(14, this.rnd);
/*     */         }
/* 450 */         PacketKexDHInit kp = new PacketKexDHInit(this.kxs.dhx.getE());
/* 451 */         this.tm.sendKexMessage(kp.getPayload());
/* 452 */         this.kxs.state = 1;
/* 453 */         return;
/*     */       }
/*     */ 
/* 456 */       throw new IllegalStateException("Unkown KEX method!");
/*     */     }
/*     */ 
/* 459 */     if (msg[0] == 21)
/*     */     {
/* 461 */       if (this.km == null) {
/* 462 */         throw new IOException("Peer sent SSH_MSG_NEWKEYS, but I have no key material ready!");
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 469 */         BlockCipher cbc = BlockCipherFactory.createCipher(this.kxs.np.enc_algo_server_to_client, false, 
/* 470 */           this.km.enc_key_server_to_client, this.km.initial_iv_server_to_client);
/*     */ 
/* 472 */         mac = new MAC(this.kxs.np.mac_algo_server_to_client, this.km.integrity_key_server_to_client);
/*     */       }
/*     */       catch (IllegalArgumentException e1)
/*     */       {
/*     */         MAC mac;
/* 477 */         throw new IOException("Fatal error during MAC startup!");
/*     */       }
/*     */       MAC mac;
/*     */       BlockCipher cbc;
/* 480 */       this.tm.changeRecvCipher(cbc, mac);
/*     */ 
/* 482 */       ConnectionInfo sci = new ConnectionInfo();
/*     */ 
/* 484 */       this.kexCount += 1;
/*     */ 
/* 486 */       sci.keyExchangeAlgorithm = this.kxs.np.kex_algo;
/* 487 */       sci.keyExchangeCounter = this.kexCount;
/* 488 */       sci.clientToServerCryptoAlgorithm = this.kxs.np.enc_algo_client_to_server;
/* 489 */       sci.serverToClientCryptoAlgorithm = this.kxs.np.enc_algo_server_to_client;
/* 490 */       sci.clientToServerMACAlgorithm = this.kxs.np.mac_algo_client_to_server;
/* 491 */       sci.serverToClientMACAlgorithm = this.kxs.np.mac_algo_server_to_client;
/* 492 */       sci.serverHostKeyAlgorithm = this.kxs.np.server_host_key_algo;
/* 493 */       sci.serverHostKey = this.kxs.hostkey;
/*     */ 
/* 495 */       synchronized (this.accessLock)
/*     */       {
/* 497 */         this.lastConnInfo = sci;
/* 498 */         this.accessLock.notifyAll();
/*     */       }
/*     */ 
/* 501 */       this.kxs = null;
/* 502 */       return;
/*     */     }
/*     */ 
/* 505 */     if ((this.kxs == null) || (this.kxs.state == 0)) {
/* 506 */       throw new IOException("Unexpected Kex submessage!");
/*     */     }
/* 508 */     if (this.kxs.np.kex_algo.equals("diffie-hellman-group-exchange-sha1"))
/*     */     {
/* 510 */       if (this.kxs.state == 1)
/*     */       {
/* 512 */         PacketKexDhGexGroup dhgexgrp = new PacketKexDhGexGroup(msg, 0, msglen);
/* 513 */         this.kxs.dhgx = new DhGroupExchange(dhgexgrp.getP(), dhgexgrp.getG());
/* 514 */         this.kxs.dhgx.init(this.rnd);
/* 515 */         PacketKexDhGexInit dhgexinit = new PacketKexDhGexInit(this.kxs.dhgx.getE());
/* 516 */         this.tm.sendKexMessage(dhgexinit.getPayload());
/* 517 */         this.kxs.state = 2;
/* 518 */         return;
/*     */       }
/*     */ 
/* 521 */       if (this.kxs.state == 2)
/*     */       {
/* 523 */         PacketKexDhGexReply dhgexrpl = new PacketKexDhGexReply(msg, 0, msglen);
/*     */ 
/* 525 */         this.kxs.hostkey = dhgexrpl.getHostKey();
/*     */ 
/* 527 */         if (this.verifier != null)
/*     */         {
/* 529 */           boolean vres = false;
/*     */           try
/*     */           {
/* 533 */             vres = this.verifier.verifyServerHostKey(this.hostname, this.port, this.kxs.np.server_host_key_algo, this.kxs.hostkey);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 537 */             throw ((IOException)new IOException(
/* 538 */               "The server hostkey was not accepted by the verifier callback.").initCause(e));
/*     */           }
/*     */ 
/* 541 */           if (!vres) {
/* 542 */             throw new IOException("The server hostkey was not accepted by the verifier callback");
/*     */           }
/*     */         }
/* 545 */         this.kxs.dhgx.setF(dhgexrpl.getF());
/*     */         try
/*     */         {
/* 549 */           this.kxs.H = this.kxs.dhgx
/* 551 */             .calculateH(this.csh.getClientString(), this.csh.getServerString(), 
/* 550 */             this.kxs.localKEX.getPayload(), this.kxs.remoteKEX.getPayload(), dhgexrpl.getHostKey(), 
/* 551 */             this.kxs.dhgexParameters);
/*     */         }
/*     */         catch (IllegalArgumentException e)
/*     */         {
/* 555 */           throw ((IOException)new IOException("KEX error.").initCause(e));
/*     */         }
/*     */ 
/* 558 */         boolean res = verifySignature(dhgexrpl.getSignature(), this.kxs.hostkey);
/*     */ 
/* 560 */         if (!res) {
/* 561 */           throw new IOException("Hostkey signature sent by remote is wrong!");
/*     */         }
/* 563 */         this.kxs.K = this.kxs.dhgx.getK();
/*     */ 
/* 565 */         finishKex();
/* 566 */         this.kxs.state = -1;
/* 567 */         return;
/*     */       }
/*     */ 
/* 570 */       throw new IllegalStateException("Illegal State in KEX Exchange!");
/*     */     }
/*     */ 
/* 573 */     if ((this.kxs.np.kex_algo.equals("diffie-hellman-group1-sha1")) || 
/* 574 */       (this.kxs.np.kex_algo.equals("diffie-hellman-group14-sha1")))
/*     */     {
/* 576 */       if (this.kxs.state == 1)
/*     */       {
/* 579 */         PacketKexDHReply dhr = new PacketKexDHReply(msg, 0, msglen);
/*     */ 
/* 581 */         this.kxs.hostkey = dhr.getHostKey();
/*     */ 
/* 583 */         if (this.verifier != null)
/*     */         {
/* 585 */           boolean vres = false;
/*     */           try
/*     */           {
/* 589 */             vres = this.verifier.verifyServerHostKey(this.hostname, this.port, this.kxs.np.server_host_key_algo, this.kxs.hostkey);
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/* 593 */             throw ((IOException)new IOException(
/* 594 */               "The server hostkey was not accepted by the verifier callback.").initCause(e));
/*     */           }
/*     */ 
/* 597 */           if (!vres) {
/* 598 */             throw new IOException("The server hostkey was not accepted by the verifier callback");
/*     */           }
/*     */         }
/* 601 */         this.kxs.dhx.setF(dhr.getF());
/*     */         try
/*     */         {
/* 605 */           this.kxs.H = this.kxs.dhx
/* 606 */             .calculateH(this.csh.getClientString(), this.csh.getServerString(), this.kxs.localKEX.getPayload(), 
/* 606 */             this.kxs.remoteKEX.getPayload(), dhr.getHostKey());
/*     */         }
/*     */         catch (IllegalArgumentException e)
/*     */         {
/* 610 */           throw ((IOException)new IOException("KEX error.").initCause(e));
/*     */         }
/*     */ 
/* 613 */         boolean res = verifySignature(dhr.getSignature(), this.kxs.hostkey);
/*     */ 
/* 615 */         if (!res) {
/* 616 */           throw new IOException("Hostkey signature sent by remote is wrong!");
/*     */         }
/* 618 */         this.kxs.K = this.kxs.dhx.getK();
/*     */ 
/* 620 */         finishKex();
/* 621 */         this.kxs.state = -1;
/* 622 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 626 */     throw new IllegalStateException("Unkown KEX method! (" + this.kxs.np.kex_algo + ")");
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.KexManager
 * JD-Core Version:    0.6.0
 */