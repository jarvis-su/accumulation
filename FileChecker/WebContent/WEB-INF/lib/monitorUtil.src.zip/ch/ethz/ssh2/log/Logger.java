/*    */ package ch.ethz.ssh2.log;
/*    */ 
/*    */ public class Logger
/*    */ {
/*    */   private static final boolean enabled = false;
/*    */   private static final int logLevel = 99;
/*    */   private String className;
/*    */ 
/*    */   public static final Logger getLogger(Class x)
/*    */   {
/* 23 */     return new Logger(x);
/*    */   }
/*    */ 
/*    */   public Logger(Class x)
/*    */   {
/* 28 */     this.className = x.getName();
/*    */   }
/*    */ 
/*    */   public final boolean isEnabled()
/*    */   {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */   public final void log(int level, String message)
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.log.Logger
 * JD-Core Version:    0.6.0
 */