package ch.ethz.ssh2;

public abstract interface ProxyData
{
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.ProxyData
 * JD-Core Version:    0.6.0
 */