package com.ibm.wsdl.extensions.schema;

import javax.wsdl.extensions.schema.SchemaImport;

public class SchemaImportImpl extends SchemaReferenceImpl
  implements SchemaImport
{
  public static final long serialVersionUID = 1L;
  private String namespace = null;

  public String getNamespaceURI()
  {
    return this.namespace;
  }

  public void setNamespaceURI(String paramString)
  {
    this.namespace = paramString;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.schema.SchemaImportImpl
 * JD-Core Version:    0.6.0
 */