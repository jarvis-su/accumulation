/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ import ch.ethz.ssh2.channel.Channel;
/*     */ import ch.ethz.ssh2.channel.ChannelManager;
/*     */ import ch.ethz.ssh2.channel.X11ServerData;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class Session
/*     */ {
/*     */   ChannelManager cm;
/*     */   Channel cn;
/*  27 */   boolean flag_pty_requested = false;
/*  28 */   boolean flag_x11_requested = false;
/*  29 */   boolean flag_execution_started = false;
/*  30 */   boolean flag_closed = false;
/*     */ 
/*  32 */   String x11FakeCookie = null;
/*     */   final SecureRandom rnd;
/*     */ 
/*     */   Session(ChannelManager cm, SecureRandom rnd)
/*     */     throws IOException
/*     */   {
/*  38 */     this.cm = cm;
/*  39 */     this.cn = cm.openSessionChannel();
/*  40 */     this.rnd = rnd;
/*     */   }
/*     */ 
/*     */   public void requestDumbPTY()
/*     */     throws IOException
/*     */   {
/*  51 */     requestPTY("dumb", 0, 0, 0, 0, null);
/*     */   }
/*     */ 
/*     */   public void requestPTY(String term)
/*     */     throws IOException
/*     */   {
/*  62 */     requestPTY(term, 0, 0, 0, 0, null);
/*     */   }
/*     */ 
/*     */   public void requestPTY(String term, int term_width_characters, int term_height_characters, int term_width_pixels, int term_height_pixels, byte[] terminal_modes)
/*     */     throws IOException
/*     */   {
/* 102 */     if (term == null) {
/* 103 */       throw new IllegalArgumentException("TERM cannot be null.");
/*     */     }
/* 105 */     if ((terminal_modes != null) && (terminal_modes.length > 0))
/*     */     {
/* 107 */       if (terminal_modes[(terminal_modes.length - 1)] != 0)
/* 108 */         throw new IOException("Illegal terminal modes description, does not end in zero byte");
/*     */     }
/*     */     else {
/* 111 */       terminal_modes = new byte[1];
/*     */     }
/* 113 */     synchronized (this)
/*     */     {
/* 116 */       if (this.flag_closed) {
/* 117 */         throw new IOException("This session is closed.");
/*     */       }
/* 119 */       if (this.flag_pty_requested) {
/* 120 */         throw new IOException("A PTY was already requested.");
/*     */       }
/* 122 */       if (this.flag_execution_started) {
/* 123 */         throw new IOException(
/* 124 */           "Cannot request PTY at this stage anymore, a remote execution has already started.");
/*     */       }
/* 126 */       this.flag_pty_requested = true;
/*     */     }
/*     */ 
/* 129 */     this.cm.requestPTY(this.cn, term, term_width_characters, term_height_characters, term_width_pixels, term_height_pixels, 
/* 130 */       terminal_modes);
/*     */   }
/*     */ 
/*     */   public void requestX11Forwarding(String hostname, int port, byte[] cookie, boolean singleConnection)
/*     */     throws IOException
/*     */   {
/* 152 */     if (hostname == null) {
/* 153 */       throw new IllegalArgumentException("hostname argument may not be null");
/*     */     }
/* 155 */     synchronized (this)
/*     */     {
/* 158 */       if (this.flag_closed) {
/* 159 */         throw new IOException("This session is closed.");
/*     */       }
/* 161 */       if (this.flag_x11_requested) {
/* 162 */         throw new IOException("X11 forwarding was already requested.");
/*     */       }
/* 164 */       if (this.flag_execution_started) {
/* 165 */         throw new IOException(
/* 166 */           "Cannot request X11 forwarding at this stage anymore, a remote execution has already started.");
/*     */       }
/* 168 */       this.flag_x11_requested = true;
/*     */     }
/*     */ 
/* 173 */     X11ServerData x11data = new X11ServerData();
/*     */ 
/* 175 */     x11data.hostname = hostname;
/* 176 */     x11data.port = port;
/* 177 */     x11data.x11_magic_cookie = cookie;
/*     */ 
/* 181 */     byte[] fakeCookie = new byte[16];
/*     */     while (true)
/*     */     {
/* 188 */       this.rnd.nextBytes(fakeCookie);
/*     */ 
/* 192 */       StringBuffer tmp = new StringBuffer(32);
/* 193 */       for (int i = 0; i < fakeCookie.length; i++)
/*     */       {
/* 195 */         String digit2 = Integer.toHexString(fakeCookie[i] & 0xFF);
/* 196 */         tmp.append("0" + digit2);
/*     */       }
/* 198 */       String hexEncodedFakeCookie = tmp.toString();
/*     */ 
/* 202 */       if (this.cm.checkX11Cookie(hexEncodedFakeCookie) == null)
/* 203 */         break;
/*     */     }
/*     */     String hexEncodedFakeCookie;
/* 208 */     this.cm.requestX11(this.cn, singleConnection, "MIT-MAGIC-COOKIE-1", hexEncodedFakeCookie, 0);
/*     */ 
/* 213 */     synchronized (this)
/*     */     {
/* 215 */       if (!this.flag_closed)
/*     */       {
/* 217 */         this.x11FakeCookie = hexEncodedFakeCookie;
/* 218 */         this.cm.registerX11Cookie(hexEncodedFakeCookie, x11data);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execCommand(String cmd)
/*     */     throws IOException
/*     */   {
/* 234 */     if (cmd == null) {
/* 235 */       throw new IllegalArgumentException("cmd argument may not be null");
/*     */     }
/* 237 */     synchronized (this)
/*     */     {
/* 240 */       if (this.flag_closed) {
/* 241 */         throw new IOException("This session is closed.");
/*     */       }
/* 243 */       if (this.flag_execution_started) {
/* 244 */         throw new IOException("A remote execution has already started.");
/*     */       }
/* 246 */       this.flag_execution_started = true;
/*     */     }
/*     */ 
/* 249 */     this.cm.requestExecCommand(this.cn, cmd);
/*     */   }
/*     */ 
/*     */   public void startShell()
/*     */     throws IOException
/*     */   {
/* 259 */     synchronized (this)
/*     */     {
/* 262 */       if (this.flag_closed) {
/* 263 */         throw new IOException("This session is closed.");
/*     */       }
/* 265 */       if (this.flag_execution_started) {
/* 266 */         throw new IOException("A remote execution has already started.");
/*     */       }
/* 268 */       this.flag_execution_started = true;
/*     */     }
/*     */ 
/* 271 */     this.cm.requestShell(this.cn);
/*     */   }
/*     */ 
/*     */   public void startSubSystem(String name)
/*     */     throws IOException
/*     */   {
/* 283 */     if (name == null) {
/* 284 */       throw new IllegalArgumentException("name argument may not be null");
/*     */     }
/* 286 */     synchronized (this)
/*     */     {
/* 289 */       if (this.flag_closed) {
/* 290 */         throw new IOException("This session is closed.");
/*     */       }
/* 292 */       if (this.flag_execution_started) {
/* 293 */         throw new IOException("A remote execution has already started.");
/*     */       }
/* 295 */       this.flag_execution_started = true;
/*     */     }
/*     */ 
/* 298 */     this.cm.requestSubSystem(this.cn, name);
/*     */   }
/*     */ 
/*     */   public InputStream getStdout()
/*     */   {
/* 303 */     return this.cn.getStdoutStream();
/*     */   }
/*     */ 
/*     */   public InputStream getStderr()
/*     */   {
/* 308 */     return this.cn.getStderrStream();
/*     */   }
/*     */ 
/*     */   public OutputStream getStdin()
/*     */   {
/* 313 */     return this.cn.getStdinStream();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public int waitUntilDataAvailable(long timeout)
/*     */     throws IOException
/*     */   {
/* 342 */     if (timeout < 0L) {
/* 343 */       throw new IllegalArgumentException("timeout must not be negative!");
/*     */     }
/* 345 */     int conditions = this.cm.waitForCondition(this.cn, timeout, 28);
/*     */ 
/* 348 */     if ((conditions & 0x1) != 0) {
/* 349 */       return -1;
/*     */     }
/* 351 */     if ((conditions & 0xC) != 0) {
/* 352 */       return 1;
/*     */     }
/*     */ 
/* 356 */     if ((conditions & 0x10) != 0) {
/* 357 */       return 0;
/*     */     }
/* 359 */     throw new IllegalStateException("Unexpected condition result (" + conditions + ")");
/*     */   }
/*     */ 
/*     */   public int waitForCondition(int condition_set, long timeout)
/*     */   {
/* 388 */     if (timeout < 0L) {
/* 389 */       throw new IllegalArgumentException("timeout must be non-negative!");
/*     */     }
/* 391 */     return this.cm.waitForCondition(this.cn, timeout, condition_set);
/*     */   }
/*     */ 
/*     */   public Integer getExitStatus()
/*     */   {
/* 405 */     return this.cn.getExitStatus();
/*     */   }
/*     */ 
/*     */   public String getExitSignal()
/*     */   {
/* 419 */     return this.cn.getExitSignal();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */   {
/* 434 */     synchronized (this)
/*     */     {
/* 436 */       if (this.flag_closed) {
/* 437 */         return;
/*     */       }
/* 439 */       this.flag_closed = true;
/*     */ 
/* 441 */       if (this.x11FakeCookie != null) {
/* 442 */         this.cm.unRegisterX11Cookie(this.x11FakeCookie, true);
/*     */       }
/*     */       try
/*     */       {
/* 446 */         this.cm.closeChannel(this.cn, "Closed due to user request", true);
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.Session
 * JD-Core Version:    0.6.0
 */