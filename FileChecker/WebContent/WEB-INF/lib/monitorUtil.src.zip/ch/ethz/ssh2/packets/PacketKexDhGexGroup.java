/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class PacketKexDhGexGroup
/*    */ {
/*    */   byte[] payload;
/*    */   BigInteger p;
/*    */   BigInteger g;
/*    */ 
/*    */   public PacketKexDhGexGroup(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 22 */     this.payload = new byte[len];
/* 23 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 25 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 27 */     int packet_type = tr.readByte();
/*    */ 
/* 29 */     if (packet_type != 31) {
/* 30 */       throw new IllegalArgumentException(
/* 31 */         "This is not a SSH_MSG_KEX_DH_GEX_GROUP! (" + packet_type + 
/* 32 */         ")");
/*    */     }
/* 34 */     this.p = tr.readMPINT();
/* 35 */     this.g = tr.readMPINT();
/*    */ 
/* 37 */     if (tr.remain() != 0)
/* 38 */       throw new IOException("PADDING IN SSH_MSG_KEX_DH_GEX_GROUP!");
/*    */   }
/*    */ 
/*    */   public BigInteger getG()
/*    */   {
/* 43 */     return this.g;
/*    */   }
/*    */ 
/*    */   public BigInteger getP()
/*    */   {
/* 48 */     return this.p;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDhGexGroup
 * JD-Core Version:    0.6.0
 */