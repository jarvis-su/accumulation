/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketDisconnect
/*    */ {
/*    */   byte[] payload;
/*    */   int reason;
/*    */   String desc;
/*    */   String lang;
/*    */ 
/*    */   public PacketDisconnect(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 20 */     this.payload = new byte[len];
/* 21 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 23 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 25 */     int packet_type = tr.readByte();
/*    */ 
/* 27 */     if (packet_type != 1) {
/* 28 */       throw new IOException("This is not a Disconnect Packet! (" + 
/* 29 */         packet_type + ")");
/*    */     }
/* 31 */     this.reason = tr.readUINT32();
/* 32 */     this.desc = tr.readString();
/* 33 */     this.lang = tr.readString();
/*    */   }
/*    */ 
/*    */   public PacketDisconnect(int reason, String desc, String lang)
/*    */   {
/* 38 */     this.reason = reason;
/* 39 */     this.desc = desc;
/* 40 */     this.lang = lang;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 45 */     if (this.payload == null)
/*    */     {
/* 47 */       TypesWriter tw = new TypesWriter();
/* 48 */       tw.writeByte(1);
/* 49 */       tw.writeUINT32(this.reason);
/* 50 */       tw.writeString(this.desc);
/* 51 */       tw.writeString(this.lang);
/* 52 */       this.payload = tw.getBytes();
/*    */     }
/* 54 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketDisconnect
 * JD-Core Version:    0.6.0
 */