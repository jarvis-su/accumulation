/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class DSAPrivateKey
/*    */ {
/*    */   private BigInteger p;
/*    */   private BigInteger q;
/*    */   private BigInteger g;
/*    */   private BigInteger x;
/*    */   private BigInteger y;
/*    */ 
/*    */   public DSAPrivateKey(BigInteger p, BigInteger q, BigInteger g, BigInteger y, BigInteger x)
/*    */   {
/* 22 */     this.p = p;
/* 23 */     this.q = q;
/* 24 */     this.g = g;
/* 25 */     this.y = y;
/* 26 */     this.x = x;
/*    */   }
/*    */ 
/*    */   public BigInteger getP()
/*    */   {
/* 31 */     return this.p;
/*    */   }
/*    */ 
/*    */   public BigInteger getQ()
/*    */   {
/* 36 */     return this.q;
/*    */   }
/*    */ 
/*    */   public BigInteger getG()
/*    */   {
/* 41 */     return this.g;
/*    */   }
/*    */ 
/*    */   public BigInteger getY()
/*    */   {
/* 46 */     return this.y;
/*    */   }
/*    */ 
/*    */   public BigInteger getX()
/*    */   {
/* 51 */     return this.x;
/*    */   }
/*    */ 
/*    */   public DSAPublicKey getPublicKey()
/*    */   {
/* 56 */     return new DSAPublicKey(this.p, this.q, this.g, this.y);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.DSAPrivateKey
 * JD-Core Version:    0.6.0
 */