/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public abstract class CopyOfDBVar
/*    */ {
/*  6 */   private String _initialVal = null;
/*  7 */   private Vector<String> _values = new Vector();
/*    */ 
/*  9 */   private CopyOfDBVar.Status _status = CopyOfDBVar.Status.NADA;
/*    */ 
/*    */   public CopyOfDBVar() {
/* 12 */     this(null);
/*    */   }
/*    */ 
/*    */   public CopyOfDBVar(String s) {
/* 16 */     setInitialValue(s);
/*    */   }
/*    */ 
/*    */   public final void setInitialValue(String val) {
/* 20 */     this._initialVal = val;
/*    */   }
/*    */ 
/*    */   public final String getInitialValue() {
/* 24 */     return this._initialVal;
/*    */   }
/*    */ 
/*    */   public final boolean isResolved() {
/* 28 */     return this._status == CopyOfDBVar.Status.RESOLVED;
/*    */   }
/*    */ 
/*    */   public final boolean isDirty() {
/* 32 */     return this._status == CopyOfDBVar.Status.DIRTY;
/*    */   }
/*    */ 
/*    */   public final Vector<String> getValues() {
/* 36 */     return this._values;
/*    */   }
/*    */ 
/*    */   protected final void addValue(String val) {
/* 40 */     this._values.add(val);
/*    */   }
/*    */ 
/*    */   protected final void deleteValue(String val) {
/* 44 */     this._values.remove(val);
/*    */   }
/*    */ 
/*    */   protected final void updateValue(int loc, String val) {
/* 48 */     this._values.set(loc, val);
/*    */   }
/*    */ 
/*    */   public final Vector<String> resolve(VarCache c) throws Exception {
/* 52 */     this._status = CopyOfDBVar.Status.DIRTY;
/* 53 */     Vector ret = resolveInternal(c);
/* 54 */     this._status = CopyOfDBVar.Status.RESOLVED;
/* 55 */     return ret;
/*    */   }
/*    */ 
/*    */   protected abstract Vector<String> resolveInternal(VarCache paramVarCache)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.CopyOfDBVar
 * JD-Core Version:    0.6.0
 */