/*     */ package com.acs.eppic.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ public class MessageType
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 6358106565708670692L;
/*     */   public static final int ACK = 0;
/*     */   public static final int ALERT = 1;
/*     */   public static final int DISCONNECT = 2;
/*     */   public static final int HEARTBEAT = 3;
/*     */   public static final int INFO = 4;
/*     */   public static final int REGISTRATION = 5;
/*     */   public static final int TEST = 6;
/*     */   private int typeId;
/*  79 */   private boolean __hashCodeCalc = false;
/*     */ 
/*  93 */   private static TypeDesc typeDesc = new TypeDesc(MessageType.class, true);
/*     */ 
/*     */   static {
/*  96 */     typeDesc.setXmlType(new QName("http://message.eppic.acs.com", "MessageType"));
/*  97 */     ElementDesc elemField = new ElementDesc();
/*  98 */     elemField.setFieldName("typeId");
/*  99 */     elemField.setXmlName(new QName("", "typeId"));
/* 100 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "int"));
/* 101 */     elemField.setNillable(false);
/* 102 */     typeDesc.addFieldDesc(elemField);
/*     */   }
/*     */ 
/*     */   public MessageType()
/*     */   {
/*  24 */     this.typeId = 3;
/*     */   }
/*     */ 
/*     */   public MessageType(int id) {
/*  28 */     setTypeId(id);
/*     */   }
/*     */ 
/*     */   public int getTypeId() {
/*  32 */     return this.typeId;
/*     */   }
/*     */ 
/*     */   public void setTypeId(int id) {
/*  36 */     switch (id) {
/*     */     case 0:
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/*     */     case 6:
/*  44 */       this.typeId = id;
/*  45 */       break;
/*     */     default:
/*  47 */       throw new IllegalArgumentException("Invalid id.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString() {
/*  52 */     switch (getTypeId()) {
/*     */     case 0:
/*  54 */       return "ACK";
/*     */     case 1:
/*  56 */       return "ALERT";
/*     */     case 2:
/*  58 */       return "DISCONNECT";
/*     */     case 3:
/*  60 */       return "HEARTBEAT";
/*     */     case 4:
/*  62 */       return "INFO";
/*     */     case 5:
/*  64 */       return "REGISTRATION";
/*     */     }
/*  66 */     return "";
/*     */   }
/*     */ 
/*     */   public synchronized boolean equals(Object obj)
/*     */   {
/*  71 */     if (!(obj instanceof MessageType)) return false;
/*     */ 
/*  73 */     return getTypeId() == ((MessageType)obj).getTypeId();
/*     */   }
/*     */ 
/*     */   public synchronized int hashCode()
/*     */   {
/*  81 */     if (this.__hashCodeCalc) {
/*  82 */       return 0;
/*     */     }
/*  84 */     this.__hashCodeCalc = true;
/*  85 */     int _hashCode = 1;
/*  86 */     _hashCode += getTypeId();
/*  87 */     this.__hashCodeCalc = false;
/*  88 */     return _hashCode;
/*     */   }
/*     */ 
/*     */   public static TypeDesc getTypeDesc()
/*     */   {
/* 109 */     return typeDesc;
/*     */   }
/*     */ 
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 119 */     return 
/* 120 */       new BeanSerializer(
/* 121 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ 
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 131 */     return 
/* 132 */       new BeanDeserializer(
/* 133 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.MessageType
 * JD-Core Version:    0.6.0
 */