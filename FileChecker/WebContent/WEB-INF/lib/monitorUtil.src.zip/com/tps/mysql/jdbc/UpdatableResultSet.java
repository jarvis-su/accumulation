/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.DatabaseMetaData;
/*      */ import java.sql.Date;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ 
/*      */ public class UpdatableResultSet extends ResultSet
/*      */ {
/*   45 */   private static final byte[] STREAM_DATA_MARKER = "** STREAM DATA **".getBytes();
/*      */   private SingleByteCharsetConverter charConverter;
/*      */   private String charEncoding;
/*      */   private byte[][] defaultColumnValue;
/*   56 */   private PreparedStatement deleter = null;
/*      */ 
/*   58 */   private String deleteSQL = null;
/*      */ 
/*   60 */   private boolean initializedCharConverter = false;
/*      */ 
/*   63 */   private PreparedStatement inserter = null;
/*      */ 
/*   65 */   private String insertSQL = null;
/*      */ 
/*   68 */   private boolean isUpdatable = false;
/*      */ 
/*   71 */   private List primaryKeyIndicies = null;
/*      */   private String qualifiedAndQuotedTableName;
/*   75 */   private String quotedIdChar = null;
/*      */   private PreparedStatement refresher;
/*   80 */   private String refreshSQL = null;
/*      */   private Object[] savedCurrentRow;
/*      */   private String tableOnlyName;
/*   88 */   private PreparedStatement updater = null;
/*      */ 
/*   91 */   private String updateSQL = null;
/*      */ 
/*      */   public UpdatableResultSet(long updateCount, long updateID, Connection conn, Statement creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  110 */     super(updateCount, updateID, conn, creatorStmt);
/*  111 */     checkUpdatability();
/*      */   }
/*      */ 
/*      */   public UpdatableResultSet(String catalog, Field[] fields, RowData tuples, Connection conn, Statement creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  133 */     super(catalog, fields, tuples, conn, creatorStmt);
/*  134 */     checkUpdatability();
/*      */   }
/*      */ 
/*      */   public synchronized boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  176 */     return super.absolute(row);
/*      */   }
/*      */ 
/*      */   public synchronized void afterLast()
/*      */     throws SQLException
/*      */   {
/*  192 */     super.afterLast();
/*      */   }
/*      */ 
/*      */   public synchronized void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  208 */     super.beforeFirst();
/*      */   }
/*      */ 
/*      */   public synchronized void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  222 */     checkClosed();
/*      */ 
/*  224 */     if (this.doingUpdates) {
/*  225 */       this.doingUpdates = false;
/*  226 */       this.updater.clearParameters();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  236 */     checkClosed();
/*      */ 
/*  238 */     if (!this.onInsertRow)
/*  239 */       super.checkRowPos();
/*      */   }
/*      */ 
/*      */   private void checkUpdatability()
/*      */     throws SQLException
/*      */   {
/*  250 */     String singleTableName = null;
/*  251 */     String catalogName = null;
/*      */ 
/*  253 */     int primaryKeyCount = 0;
/*      */ 
/*  255 */     if (this.fields.length > 0) {
/*  256 */       singleTableName = this.fields[0].getOriginalTableName();
/*  257 */       catalogName = this.fields[0].getDatabaseName();
/*      */ 
/*  259 */       if (singleTableName == null) {
/*  260 */         singleTableName = this.fields[0].getTableName();
/*  261 */         catalogName = this.catalog;
/*      */       }
/*      */ 
/*  264 */       if (this.fields[0].isPrimaryKey()) {
/*  265 */         primaryKeyCount++;
/*      */       }
/*      */ 
/*  271 */       for (int i = 1; i < this.fields.length; i++) {
/*  272 */         String otherTableName = this.fields[i].getOriginalTableName();
/*  273 */         String otherCatalogName = this.fields[i].getDatabaseName();
/*      */ 
/*  275 */         if (otherTableName == null) {
/*  276 */           otherTableName = this.fields[i].getTableName();
/*  277 */           otherCatalogName = this.catalog;
/*      */         }
/*      */ 
/*  280 */         if ((singleTableName == null) || (!otherTableName.equals(singleTableName)))
/*      */         {
/*  282 */           this.isUpdatable = false;
/*      */ 
/*  284 */           return;
/*      */         }
/*      */ 
/*  288 */         if ((catalogName == null) || (!otherCatalogName.equals(catalogName)))
/*      */         {
/*  290 */           this.isUpdatable = false;
/*      */ 
/*  292 */           return;
/*      */         }
/*      */ 
/*  295 */         if (this.fields[i].isPrimaryKey()) {
/*  296 */           primaryKeyCount++;
/*      */         }
/*      */       }
/*      */ 
/*  300 */       if ((singleTableName == null) || (singleTableName.length() == 0)) {
/*  301 */         this.isUpdatable = false;
/*      */ 
/*  303 */         return;
/*      */       }
/*      */     } else {
/*  306 */       this.isUpdatable = false;
/*      */ 
/*  308 */       return;
/*      */     }
/*      */ 
/*  314 */     if (primaryKeyCount == 0) {
/*  315 */       this.isUpdatable = false;
/*      */ 
/*  317 */       return;
/*      */     }
/*      */ 
/*  325 */     if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  326 */       this.catalog = this.fields[0].getDatabaseName();
/*      */ 
/*  328 */       if ((this.catalog == null) || (this.catalog.length() == 0)) {
/*  329 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  335 */     if (this.connection.getStrictUpdates()) {
/*  336 */       DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */ 
/*  338 */       java.sql.ResultSet rs = null;
/*  339 */       HashMap primaryKeyNames = new HashMap();
/*      */       try
/*      */       {
/*  342 */         rs = dbmd.getPrimaryKeys(catalogName, null, singleTableName);
/*      */ 
/*  344 */         while (rs.next()) {
/*  345 */           String keyName = rs.getString(4);
/*  346 */           keyName = keyName.toUpperCase();
/*  347 */           primaryKeyNames.put(keyName, keyName);
/*      */         }
/*      */       } finally {
/*  350 */         if (rs != null) {
/*      */           try {
/*  352 */             rs.close();
/*      */           } catch (Exception ex) {
/*  354 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */ 
/*  357 */           rs = null;
/*      */         }
/*      */       }
/*      */ 
/*  361 */       if (primaryKeyNames.size() == 0) {
/*  362 */         this.isUpdatable = false;
/*      */ 
/*  364 */         return;
/*      */       }
/*      */ 
/*  370 */       for (int i = 0; i < this.fields.length; i++) {
/*  371 */         if (this.fields[i].isPrimaryKey()) {
/*  372 */           String columnNameUC = this.fields[i].getName().toUpperCase();
/*      */ 
/*  375 */           if (primaryKeyNames.remove(columnNameUC) != null)
/*      */             continue;
/*  377 */           String originalName = this.fields[i].getOriginalName();
/*      */ 
/*  379 */           if ((originalName == null) || 
/*  380 */             (primaryKeyNames.remove(originalName.toUpperCase()) != null)) {
/*      */             continue;
/*      */           }
/*  383 */           this.isUpdatable = false;
/*      */ 
/*  385 */           return;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  392 */       this.isUpdatable = primaryKeyNames.isEmpty();
/*      */ 
/*  394 */       return;
/*      */     }
/*      */ 
/*  397 */     this.isUpdatable = true;
/*      */   }
/*      */ 
/*      */   public synchronized void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  413 */     checkClosed();
/*      */ 
/*  415 */     if (!this.isUpdatable) {
/*  416 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/*  419 */     if (this.onInsertRow)
/*  420 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"));
/*  421 */     if (this.rowData.size() == 0)
/*  422 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"));
/*  423 */     if (isBeforeFirst())
/*  424 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"));
/*  425 */     if (isAfterLast()) {
/*  426 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"));
/*      */     }
/*      */ 
/*  429 */     if (this.deleter == null) {
/*  430 */       if (this.deleteSQL == null) {
/*  431 */         generateStatements();
/*      */       }
/*      */ 
/*  434 */       this.deleter = this.connection.clientPrepareStatement(this.deleteSQL);
/*      */     }
/*      */ 
/*  438 */     this.deleter.clearParameters();
/*      */ 
/*  440 */     String characterEncoding = null;
/*      */ 
/*  442 */     if (this.connection.getUseUnicode()) {
/*  443 */       characterEncoding = this.connection.getEncoding();
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  450 */       int numKeys = this.primaryKeyIndicies.size();
/*      */ 
/*  452 */       if (numKeys == 1) {
/*  453 */         int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */ 
/*  455 */         String currentVal = characterEncoding == null ? new String((byte[])this.thisRow[index]) : new String((byte[])this.thisRow[index], characterEncoding);
/*      */ 
/*  458 */         this.deleter.setString(1, currentVal);
/*      */       } else {
/*  460 */         for (int i = 0; i < numKeys; i++) {
/*  461 */           int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */ 
/*  463 */           String currentVal = characterEncoding == null ? new String((byte[])this.thisRow[index]) : new String((byte[])this.thisRow[index], characterEncoding);
/*      */ 
/*  467 */           this.deleter.setString(i + 1, currentVal);
/*      */         }
/*      */       }
/*      */ 
/*  471 */       this.deleter.executeUpdate();
/*  472 */       this.rowData.removeRow(this.rowData.getCurrentRowNumber());
/*      */     } catch (UnsupportedEncodingException encodingEx) {
/*  474 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.39", new Object[] { this.charEncoding }), "S1009");
/*      */     }
/*      */   }
/*      */ 
/*      */   private synchronized void extractDefaultValues()
/*      */     throws SQLException
/*      */   {
/*  481 */     DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */ 
/*  483 */     java.sql.ResultSet columnsResultSet = null;
/*      */     try
/*      */     {
/*  486 */       columnsResultSet = dbmd.getColumns(this.catalog, null, this.tableOnlyName, "%");
/*      */ 
/*  489 */       HashMap columnNameToDefaultValueMap = new HashMap(this.fields.length);
/*      */ 
/*  492 */       while (columnsResultSet.next()) {
/*  493 */         String columnName = columnsResultSet.getString("COLUMN_NAME");
/*  494 */         byte[] defaultValue = columnsResultSet.getBytes("COLUMN_DEF");
/*      */ 
/*  496 */         columnNameToDefaultValueMap.put(columnName, defaultValue);
/*      */       }
/*      */ 
/*  499 */       int numFields = this.fields.length;
/*      */ 
/*  501 */       this.defaultColumnValue = new byte[numFields][];
/*      */ 
/*  503 */       for (int i = 0; i < numFields; i++) {
/*  504 */         String defValTableName = this.fields[i].getOriginalName();
/*      */ 
/*  506 */         if ((defValTableName == null) || (defValTableName.length() == 0))
/*      */         {
/*  508 */           defValTableName = this.fields[i].getName();
/*      */         }
/*      */ 
/*  511 */         if (defValTableName != null) {
/*  512 */           byte[] defaultVal = (byte[])columnNameToDefaultValueMap.get(defValTableName);
/*      */ 
/*  515 */           this.defaultColumnValue[i] = defaultVal;
/*      */         }
/*      */       }
/*      */     } finally {
/*  519 */       if (columnsResultSet != null) {
/*  520 */         columnsResultSet.close();
/*      */ 
/*  522 */         columnsResultSet = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized boolean first()
/*      */     throws SQLException
/*      */   {
/*  541 */     return super.first();
/*      */   }
/*      */ 
/*      */   protected synchronized void generateStatements()
/*      */     throws SQLException
/*      */   {
/*  554 */     if (!this.isUpdatable) {
/*  555 */       this.doingUpdates = false;
/*  556 */       this.onInsertRow = false;
/*      */ 
/*  558 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/*  561 */     String quotedId = getQuotedIdChar();
/*      */ 
/*  563 */     if (this.fields[0].getOriginalTableName() != null) {
/*  564 */       StringBuffer tableNameBuffer = new StringBuffer();
/*      */ 
/*  566 */       String databaseName = this.fields[0].getDatabaseName();
/*      */ 
/*  568 */       if ((databaseName != null) && (databaseName.length() > 0)) {
/*  569 */         tableNameBuffer.append(quotedId);
/*  570 */         tableNameBuffer.append(databaseName);
/*  571 */         tableNameBuffer.append(quotedId);
/*  572 */         tableNameBuffer.append('.');
/*      */       }
/*      */ 
/*  575 */       this.tableOnlyName = this.fields[0].getOriginalTableName();
/*      */ 
/*  577 */       tableNameBuffer.append(quotedId);
/*  578 */       tableNameBuffer.append(this.tableOnlyName);
/*  579 */       tableNameBuffer.append(quotedId);
/*      */ 
/*  581 */       this.qualifiedAndQuotedTableName = tableNameBuffer.toString();
/*      */     } else {
/*  583 */       StringBuffer tableNameBuffer = new StringBuffer();
/*      */ 
/*  585 */       this.tableOnlyName = this.fields[0].getTableName();
/*      */ 
/*  587 */       tableNameBuffer.append(quotedId);
/*  588 */       tableNameBuffer.append(this.tableOnlyName);
/*  589 */       tableNameBuffer.append(quotedId);
/*      */ 
/*  591 */       this.qualifiedAndQuotedTableName = tableNameBuffer.toString();
/*      */     }
/*      */ 
/*  594 */     this.primaryKeyIndicies = new ArrayList();
/*      */ 
/*  596 */     StringBuffer fieldValues = new StringBuffer();
/*  597 */     StringBuffer keyValues = new StringBuffer();
/*  598 */     StringBuffer columnNames = new StringBuffer();
/*  599 */     StringBuffer insertPlaceHolders = new StringBuffer();
/*  600 */     boolean firstTime = true;
/*  601 */     boolean keysFirstTime = true;
/*      */ 
/*  603 */     String equalsStr = this.connection.versionMeetsMinimum(3, 23, 0) ? "<=>" : "=";
/*      */ 
/*  606 */     for (int i = 0; i < this.fields.length; i++) {
/*  607 */       String originalColumnName = this.fields[i].getOriginalName();
/*  608 */       String columnName = null;
/*      */ 
/*  610 */       if ((this.connection.getIO().hasLongColumnInfo()) && (originalColumnName != null) && (originalColumnName.length() > 0))
/*      */       {
/*  613 */         columnName = originalColumnName;
/*      */       }
/*  615 */       else columnName = this.fields[i].getName();
/*      */ 
/*  618 */       if (this.fields[i].isPrimaryKey()) {
/*  619 */         this.primaryKeyIndicies.add(new Integer(i));
/*      */ 
/*  621 */         if (!keysFirstTime)
/*  622 */           keyValues.append(" AND ");
/*      */         else {
/*  624 */           keysFirstTime = false;
/*      */         }
/*      */ 
/*  627 */         keyValues.append(quotedId);
/*  628 */         keyValues.append(columnName);
/*  629 */         keyValues.append(quotedId);
/*  630 */         keyValues.append(equalsStr);
/*  631 */         keyValues.append("?");
/*      */       }
/*      */ 
/*  634 */       if (firstTime) {
/*  635 */         firstTime = false;
/*  636 */         fieldValues.append("SET ");
/*      */       } else {
/*  638 */         fieldValues.append(",");
/*  639 */         columnNames.append(",");
/*  640 */         insertPlaceHolders.append(",");
/*      */       }
/*      */ 
/*  643 */       insertPlaceHolders.append("?");
/*      */ 
/*  645 */       columnNames.append(quotedId);
/*  646 */       columnNames.append(columnName);
/*  647 */       columnNames.append(quotedId);
/*      */ 
/*  649 */       fieldValues.append(quotedId);
/*  650 */       fieldValues.append(columnName);
/*  651 */       fieldValues.append(quotedId);
/*  652 */       fieldValues.append("=?");
/*      */     }
/*      */ 
/*  655 */     this.updateSQL = ("UPDATE " + this.qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString());
/*      */ 
/*  658 */     this.insertSQL = ("INSERT INTO " + this.qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")");
/*      */ 
/*  661 */     this.refreshSQL = ("SELECT " + columnNames.toString() + " FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*      */ 
/*  664 */     this.deleteSQL = ("DELETE FROM " + this.qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
/*      */   }
/*      */ 
/*      */   private synchronized SingleByteCharsetConverter getCharConverter()
/*      */     throws SQLException
/*      */   {
/*  671 */     if (!this.initializedCharConverter) {
/*  672 */       this.initializedCharConverter = true;
/*      */ 
/*  674 */       if (this.connection.getUseUnicode()) {
/*  675 */         this.charEncoding = this.connection.getEncoding();
/*  676 */         this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  681 */     return this.charConverter;
/*      */   }
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/*  694 */     return this.isUpdatable ? 1008 : 1007;
/*      */   }
/*      */ 
/*      */   private synchronized String getQuotedIdChar() throws SQLException {
/*  698 */     if (this.quotedIdChar == null) {
/*  699 */       boolean useQuotedIdentifiers = this.connection.supportsQuotedIdentifiers();
/*      */ 
/*  702 */       if (useQuotedIdentifiers) {
/*  703 */         DatabaseMetaData dbmd = this.connection.getMetaData();
/*  704 */         this.quotedIdChar = dbmd.getIdentifierQuoteString();
/*      */       } else {
/*  706 */         this.quotedIdChar = "";
/*      */       }
/*      */     }
/*      */ 
/*  710 */     return this.quotedIdChar;
/*      */   }
/*      */ 
/*      */   public synchronized void insertRow()
/*      */     throws SQLException
/*      */   {
/*  723 */     checkClosed();
/*      */ 
/*  725 */     if (!this.onInsertRow) {
/*  726 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"));
/*      */     }
/*      */ 
/*  729 */     this.inserter.executeUpdate();
/*      */ 
/*  731 */     long autoIncrementId = this.inserter.getLastInsertID();
/*  732 */     int numFields = this.fields.length;
/*  733 */     byte[][] newRow = new byte[numFields][];
/*      */ 
/*  735 */     for (int i = 0; i < numFields; i++) {
/*  736 */       if (this.inserter.isNull(i))
/*  737 */         newRow[i] = null;
/*      */       else {
/*  739 */         newRow[i] = this.inserter.getBytesRepresentation(i);
/*      */       }
/*      */ 
/*  746 */       if ((this.fields[i].isAutoIncrement()) && (autoIncrementId > 0L)) {
/*  747 */         newRow[i] = String.valueOf(autoIncrementId).getBytes();
/*      */       }
/*      */     }
/*      */ 
/*  751 */     this.rowData.addRow(newRow);
/*  752 */     resetInserter();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/*  769 */     return super.isAfterLast();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/*  786 */     return super.isBeforeFirst();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isFirst()
/*      */     throws SQLException
/*      */   {
/*  802 */     return super.isFirst();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isLast()
/*      */     throws SQLException
/*      */   {
/*  821 */     return super.isLast();
/*      */   }
/*      */ 
/*      */   boolean isUpdatable() {
/*  825 */     return this.isUpdatable;
/*      */   }
/*      */ 
/*      */   public synchronized boolean last()
/*      */     throws SQLException
/*      */   {
/*  842 */     return super.last();
/*      */   }
/*      */ 
/*      */   public synchronized void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/*  856 */     checkClosed();
/*      */ 
/*  858 */     if (!this.isUpdatable) {
/*  859 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/*  862 */     if (this.onInsertRow) {
/*  863 */       this.onInsertRow = false;
/*  864 */       this.thisRow = this.savedCurrentRow;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/*  886 */     checkClosed();
/*      */ 
/*  888 */     if (!this.isUpdatable) {
/*  889 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/*  892 */     if (this.inserter == null) {
/*  893 */       if (this.insertSQL == null) {
/*  894 */         generateStatements();
/*      */       }
/*      */ 
/*  897 */       this.inserter = this.connection.clientPrepareStatement(this.insertSQL);
/*      */ 
/*  899 */       extractDefaultValues();
/*  900 */       resetInserter();
/*      */     } else {
/*  902 */       resetInserter();
/*      */     }
/*      */ 
/*  905 */     int numFields = this.fields.length;
/*      */ 
/*  907 */     this.onInsertRow = true;
/*  908 */     this.doingUpdates = false;
/*  909 */     this.savedCurrentRow = this.thisRow;
/*  910 */     this.thisRow = new byte[numFields][];
/*      */ 
/*  912 */     for (int i = 0; i < numFields; i++)
/*  913 */       if (this.defaultColumnValue[i] != null) {
/*  914 */         Field f = this.fields[i];
/*      */ 
/*  916 */         switch (f.getMysqlType())
/*      */         {
/*      */         case 7:
/*      */         case 10:
/*      */         case 11:
/*      */         case 12:
/*      */         case 14:
/*  923 */           if ((this.defaultColumnValue[i].length <= 7) || (this.defaultColumnValue[i][0] != 67) || (this.defaultColumnValue[i][1] != 85) || (this.defaultColumnValue[i][2] != 82) || (this.defaultColumnValue[i][3] != 82) || (this.defaultColumnValue[i][4] != 69) || (this.defaultColumnValue[i][5] != 78) || (this.defaultColumnValue[i][6] != 84) || (this.defaultColumnValue[i][7] != 95))
/*      */           {
/*      */             break;
/*      */           }
/*      */ 
/*  932 */           this.inserter.setBytesNoEscapeNoQuotes(i + 1, this.defaultColumnValue[i]);
/*      */ 
/*  935 */           break;
/*      */         case 8:
/*      */         case 9:
/*  938 */         case 13: } this.inserter.setBytes(i + 1, this.defaultColumnValue[i], false, false);
/*      */ 
/*  944 */         byte[] defaultValueCopy = new byte[this.defaultColumnValue[i].length];
/*  945 */         System.arraycopy(this.defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
/*      */ 
/*  947 */         this.thisRow[i] = defaultValueCopy;
/*      */       } else {
/*  949 */         this.inserter.setNull(i + 1, 0);
/*  950 */         this.thisRow[i] = null;
/*      */       }
/*      */   }
/*      */ 
/*      */   public synchronized boolean next()
/*      */     throws SQLException
/*      */   {
/*  975 */     return super.next();
/*      */   }
/*      */ 
/*      */   public synchronized boolean prev()
/*      */     throws SQLException
/*      */   {
/*  994 */     return super.prev();
/*      */   }
/*      */ 
/*      */   public synchronized boolean previous()
/*      */     throws SQLException
/*      */   {
/* 1016 */     return super.previous();
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 1029 */     if (this.isClosed) {
/* 1030 */       return;
/*      */     }
/*      */ 
/* 1033 */     SQLException sqlEx = null;
/*      */ 
/* 1035 */     if ((this.useUsageAdvisor) && 
/* 1036 */       (this.deleter == null) && (this.inserter == null) && (this.refresher == null) && (this.updater == null))
/*      */     {
/* 1038 */       this.eventSink = ProfileEventSink.getInstance(this.connection);
/*      */ 
/* 1040 */       String message = Messages.getString("UpdatableResultSet.34");
/*      */ 
/* 1042 */       this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1055 */       if (this.deleter != null)
/* 1056 */         this.deleter.close();
/*      */     }
/*      */     catch (SQLException ex) {
/* 1059 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1063 */       if (this.inserter != null)
/* 1064 */         this.inserter.close();
/*      */     }
/*      */     catch (SQLException ex) {
/* 1067 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1071 */       if (this.refresher != null)
/* 1072 */         this.refresher.close();
/*      */     }
/*      */     catch (SQLException ex) {
/* 1075 */       sqlEx = ex;
/*      */     }
/*      */     try
/*      */     {
/* 1079 */       if (this.updater != null)
/* 1080 */         this.updater.close();
/*      */     }
/*      */     catch (SQLException ex) {
/* 1083 */       sqlEx = ex;
/*      */     }
/*      */ 
/* 1086 */     super.realClose(calledExplicitly);
/*      */ 
/* 1088 */     if (sqlEx != null)
/* 1089 */       throw sqlEx;
/*      */   }
/*      */ 
/*      */   public synchronized void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 1114 */     checkClosed();
/*      */ 
/* 1116 */     if (!this.isUpdatable) {
/* 1117 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/* 1120 */     if (this.onInsertRow)
/* 1121 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"));
/* 1122 */     if (this.rowData.size() == 0)
/* 1123 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"));
/* 1124 */     if (isBeforeFirst())
/* 1125 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"));
/* 1126 */     if (isAfterLast()) {
/* 1127 */       throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"));
/*      */     }
/*      */ 
/* 1130 */     if (this.refresher == null) {
/* 1131 */       if (this.refreshSQL == null) {
/* 1132 */         generateStatements();
/*      */       }
/*      */ 
/* 1135 */       this.refresher = this.connection.clientPrepareStatement(this.refreshSQL);
/*      */     }
/*      */ 
/* 1139 */     this.refresher.clearParameters();
/*      */ 
/* 1141 */     int numKeys = this.primaryKeyIndicies.size();
/*      */ 
/* 1143 */     if (numKeys == 1) {
/* 1144 */       byte[] dataFrom = null;
/* 1145 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/*      */ 
/* 1147 */       if (!this.doingUpdates) {
/* 1148 */         dataFrom = (byte[])this.thisRow[index];
/*      */       } else {
/* 1150 */         dataFrom = this.updater.getBytesRepresentation(index);
/*      */ 
/* 1153 */         if ((this.updater.isNull(index)) || (dataFrom.length == 0))
/* 1154 */           dataFrom = (byte[])this.thisRow[index];
/*      */         else {
/* 1156 */           dataFrom = stripBinaryPrefix(dataFrom);
/*      */         }
/*      */       }
/*      */ 
/* 1160 */       this.refresher.setBytesNoEscape(1, dataFrom);
/*      */     } else {
/* 1162 */       for (int i = 0; i < numKeys; i++) {
/* 1163 */         byte[] dataFrom = null;
/* 1164 */         int index = ((Integer)this.primaryKeyIndicies.get(i)).intValue();
/*      */ 
/* 1167 */         if (!this.doingUpdates) {
/* 1168 */           dataFrom = (byte[])this.thisRow[index];
/*      */         } else {
/* 1170 */           dataFrom = this.updater.getBytesRepresentation(index);
/*      */ 
/* 1173 */           if ((this.updater.isNull(index)) || (dataFrom.length == 0))
/* 1174 */             dataFrom = (byte[])this.thisRow[index];
/*      */           else {
/* 1176 */             dataFrom = stripBinaryPrefix(dataFrom);
/*      */           }
/*      */         }
/*      */ 
/* 1180 */         this.refresher.setBytesNoEscape(i + 1, dataFrom);
/*      */       }
/*      */     }
/*      */ 
/* 1184 */     java.sql.ResultSet rs = null;
/*      */     try
/*      */     {
/* 1187 */       rs = this.refresher.executeQuery();
/*      */ 
/* 1189 */       int numCols = rs.getMetaData().getColumnCount();
/*      */ 
/* 1191 */       if (rs.next()) {
/* 1192 */         for (int i = 0; i < numCols; i++) {
/* 1193 */           byte[] val = rs.getBytes(i + 1);
/*      */ 
/* 1195 */           if ((val == null) || (rs.wasNull()))
/* 1196 */             this.thisRow[i] = null;
/*      */           else
/* 1198 */             this.thisRow[i] = rs.getBytes(i + 1);
/*      */         }
/*      */       }
/*      */       else {
/* 1202 */         throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000");
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1207 */       if (rs != null)
/*      */         try {
/* 1209 */           rs.close();
/*      */         }
/*      */         catch (SQLException ex)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 1244 */     return super.relative(rows);
/*      */   }
/*      */ 
/*      */   private void resetInserter() throws SQLException {
/* 1248 */     this.inserter.clearParameters();
/*      */ 
/* 1250 */     for (int i = 0; i < this.fields.length; i++)
/* 1251 */       this.inserter.setNull(i + 1, 0);
/*      */   }
/*      */ 
/*      */   public synchronized boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 1271 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public synchronized boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 1289 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public synchronized boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 1307 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   protected void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 1317 */     super.setResultSetConcurrency(concurrencyFlag);
/*      */   }
/*      */ 
/*      */   private byte[] stripBinaryPrefix(byte[] dataFrom)
/*      */   {
/* 1331 */     return StringUtils.stripEnclosure(dataFrom, "_binary'", "'");
/*      */   }
/*      */ 
/*      */   synchronized void syncUpdate()
/*      */     throws SQLException
/*      */   {
/* 1342 */     if (this.updater == null) {
/* 1343 */       if (this.updateSQL == null) {
/* 1344 */         generateStatements();
/*      */       }
/*      */ 
/* 1347 */       this.updater = this.connection.clientPrepareStatement(this.updateSQL);
/*      */     }
/*      */ 
/* 1351 */     int numFields = this.fields.length;
/* 1352 */     this.updater.clearParameters();
/*      */ 
/* 1354 */     for (int i = 0; i < numFields; i++) {
/* 1355 */       if (this.thisRow[i] != null) {
/* 1356 */         this.updater.setBytes(i + 1, (byte[])this.thisRow[i], this.fields[i].isBinary(), false);
/*      */       }
/*      */       else {
/* 1359 */         this.updater.setNull(i + 1, 0);
/*      */       }
/*      */     }
/*      */ 
/* 1363 */     int numKeys = this.primaryKeyIndicies.size();
/*      */ 
/* 1365 */     if (numKeys == 1) {
/* 1366 */       int index = ((Integer)this.primaryKeyIndicies.get(0)).intValue();
/* 1367 */       byte[] keyData = (byte[])this.thisRow[index];
/* 1368 */       this.updater.setBytes(numFields + 1, keyData, false, false);
/*      */     } else {
/* 1370 */       for (int i = 0; i < numKeys; i++) {
/* 1371 */         byte[] currentVal = (byte[])this.thisRow[((Integer)this.primaryKeyIndicies.get(i)).intValue()];
/*      */ 
/* 1374 */         if (currentVal != null) {
/* 1375 */           this.updater.setBytes(numFields + i + 1, currentVal, false, false);
/*      */         }
/*      */         else
/* 1378 */           this.updater.setNull(numFields + i + 1, 0);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1403 */     if (!this.onInsertRow) {
/* 1404 */       if (!this.doingUpdates) {
/* 1405 */         this.doingUpdates = true;
/* 1406 */         syncUpdate();
/*      */       }
/*      */ 
/* 1409 */       this.updater.setAsciiStream(columnIndex, x, length);
/*      */     } else {
/* 1411 */       this.inserter.setAsciiStream(columnIndex, x, length);
/* 1412 */       this.thisRow[(columnIndex - 1)] = STREAM_DATA_MARKER;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1435 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */   public synchronized void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1454 */     if (!this.onInsertRow) {
/* 1455 */       if (!this.doingUpdates) {
/* 1456 */         this.doingUpdates = true;
/* 1457 */         syncUpdate();
/*      */       }
/*      */ 
/* 1460 */       this.updater.setBigDecimal(columnIndex, x);
/*      */     } else {
/* 1462 */       this.inserter.setBigDecimal(columnIndex, x);
/*      */ 
/* 1464 */       if (x == null)
/* 1465 */         this.thisRow[(columnIndex - 1)] = null;
/*      */       else
/* 1467 */         this.thisRow[(columnIndex - 1)] = x.toString().getBytes();
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1488 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1510 */     if (!this.onInsertRow) {
/* 1511 */       if (!this.doingUpdates) {
/* 1512 */         this.doingUpdates = true;
/* 1513 */         syncUpdate();
/*      */       }
/*      */ 
/* 1516 */       this.updater.setBinaryStream(columnIndex, x, length);
/*      */     } else {
/* 1518 */       this.inserter.setBinaryStream(columnIndex, x, length);
/*      */ 
/* 1520 */       if (x == null)
/* 1521 */         this.thisRow[(columnIndex - 1)] = null;
/*      */       else
/* 1523 */         this.thisRow[(columnIndex - 1)] = STREAM_DATA_MARKER;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1547 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */   public synchronized void updateBlob(int columnIndex, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1555 */     if (!this.onInsertRow) {
/* 1556 */       if (!this.doingUpdates) {
/* 1557 */         this.doingUpdates = true;
/* 1558 */         syncUpdate();
/*      */       }
/*      */ 
/* 1561 */       this.updater.setBlob(columnIndex, blob);
/*      */     } else {
/* 1563 */       this.inserter.setBlob(columnIndex, blob);
/*      */ 
/* 1565 */       if (blob == null)
/* 1566 */         this.thisRow[(columnIndex - 1)] = null;
/*      */       else
/* 1568 */         this.thisRow[(columnIndex - 1)] = STREAM_DATA_MARKER;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateBlob(String columnName, Blob blob)
/*      */     throws SQLException
/*      */   {
/* 1578 */     updateBlob(findColumn(columnName), blob);
/*      */   }
/*      */ 
/*      */   public synchronized void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1597 */     if (!this.onInsertRow) {
/* 1598 */       if (!this.doingUpdates) {
/* 1599 */         this.doingUpdates = true;
/* 1600 */         syncUpdate();
/*      */       }
/*      */ 
/* 1603 */       this.updater.setBoolean(columnIndex, x);
/*      */     } else {
/* 1605 */       this.inserter.setBoolean(columnIndex, x);
/*      */ 
/* 1607 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1628 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1647 */     if (!this.onInsertRow) {
/* 1648 */       if (!this.doingUpdates) {
/* 1649 */         this.doingUpdates = true;
/* 1650 */         syncUpdate();
/*      */       }
/*      */ 
/* 1653 */       this.updater.setByte(columnIndex, x);
/*      */     } else {
/* 1655 */       this.inserter.setByte(columnIndex, x);
/*      */ 
/* 1657 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 1678 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1697 */     if (!this.onInsertRow) {
/* 1698 */       if (!this.doingUpdates) {
/* 1699 */         this.doingUpdates = true;
/* 1700 */         syncUpdate();
/*      */       }
/*      */ 
/* 1703 */       this.updater.setBytes(columnIndex, x);
/*      */     } else {
/* 1705 */       this.inserter.setBytes(columnIndex, x);
/*      */ 
/* 1707 */       this.thisRow[(columnIndex - 1)] = x;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1727 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 1749 */     if (!this.onInsertRow) {
/* 1750 */       if (!this.doingUpdates) {
/* 1751 */         this.doingUpdates = true;
/* 1752 */         syncUpdate();
/*      */       }
/*      */ 
/* 1755 */       this.updater.setCharacterStream(columnIndex, x, length);
/*      */     } else {
/* 1757 */       this.inserter.setCharacterStream(columnIndex, x, length);
/*      */ 
/* 1759 */       if (x == null)
/* 1760 */         this.thisRow[(columnIndex - 1)] = null;
/*      */       else
/* 1762 */         this.thisRow[(columnIndex - 1)] = STREAM_DATA_MARKER;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1786 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */ 
/*      */   public void updateClob(int columnIndex, Clob clob)
/*      */     throws SQLException
/*      */   {
/* 1794 */     if (clob == null)
/* 1795 */       updateNull(columnIndex);
/*      */     else
/* 1797 */       updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
/*      */   }
/*      */ 
/*      */   public synchronized void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 1818 */     if (!this.onInsertRow) {
/* 1819 */       if (!this.doingUpdates) {
/* 1820 */         this.doingUpdates = true;
/* 1821 */         syncUpdate();
/*      */       }
/*      */ 
/* 1824 */       this.updater.setDate(columnIndex, x);
/*      */     } else {
/* 1826 */       this.inserter.setDate(columnIndex, x);
/*      */ 
/* 1828 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 1849 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1868 */     if (!this.onInsertRow) {
/* 1869 */       if (!this.doingUpdates) {
/* 1870 */         this.doingUpdates = true;
/* 1871 */         syncUpdate();
/*      */       }
/*      */ 
/* 1874 */       this.updater.setDouble(columnIndex, x);
/*      */     } else {
/* 1876 */       this.inserter.setDouble(columnIndex, x);
/*      */ 
/* 1878 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 1899 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 1918 */     if (!this.onInsertRow) {
/* 1919 */       if (!this.doingUpdates) {
/* 1920 */         this.doingUpdates = true;
/* 1921 */         syncUpdate();
/*      */       }
/*      */ 
/* 1924 */       this.updater.setFloat(columnIndex, x);
/*      */     } else {
/* 1926 */       this.inserter.setFloat(columnIndex, x);
/*      */ 
/* 1928 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 1949 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 1968 */     if (!this.onInsertRow) {
/* 1969 */       if (!this.doingUpdates) {
/* 1970 */         this.doingUpdates = true;
/* 1971 */         syncUpdate();
/*      */       }
/*      */ 
/* 1974 */       this.updater.setInt(columnIndex, x);
/*      */     } else {
/* 1976 */       this.inserter.setInt(columnIndex, x);
/*      */ 
/* 1978 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 1999 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 2018 */     if (!this.onInsertRow) {
/* 2019 */       if (!this.doingUpdates) {
/* 2020 */         this.doingUpdates = true;
/* 2021 */         syncUpdate();
/*      */       }
/*      */ 
/* 2024 */       this.updater.setLong(columnIndex, x);
/*      */     } else {
/* 2026 */       this.inserter.setLong(columnIndex, x);
/*      */ 
/* 2028 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 2049 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2065 */     if (!this.onInsertRow) {
/* 2066 */       if (!this.doingUpdates) {
/* 2067 */         this.doingUpdates = true;
/* 2068 */         syncUpdate();
/*      */       }
/*      */ 
/* 2071 */       this.updater.setNull(columnIndex, 0);
/*      */     } else {
/* 2073 */       this.inserter.setNull(columnIndex, 0);
/*      */ 
/* 2075 */       this.thisRow[(columnIndex - 1)] = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2092 */     updateNull(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 2111 */     if (!this.onInsertRow) {
/* 2112 */       if (!this.doingUpdates) {
/* 2113 */         this.doingUpdates = true;
/* 2114 */         syncUpdate();
/*      */       }
/*      */ 
/* 2117 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2119 */       this.inserter.setObject(columnIndex, x);
/*      */ 
/* 2121 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2146 */     if (!this.onInsertRow) {
/* 2147 */       if (!this.doingUpdates) {
/* 2148 */         this.doingUpdates = true;
/* 2149 */         syncUpdate();
/*      */       }
/*      */ 
/* 2152 */       this.updater.setObject(columnIndex, x);
/*      */     } else {
/* 2154 */       this.inserter.setObject(columnIndex, x);
/*      */ 
/* 2156 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2177 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 2200 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateRow()
/*      */     throws SQLException
/*      */   {
/* 2214 */     if (!this.isUpdatable) {
/* 2215 */       throw new NotUpdatable();
/*      */     }
/*      */ 
/* 2218 */     if (this.doingUpdates) {
/* 2219 */       this.updater.executeUpdate();
/* 2220 */       refreshRow();
/* 2221 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/* 2227 */     syncUpdate();
/*      */   }
/*      */ 
/*      */   public synchronized void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 2246 */     if (!this.onInsertRow) {
/* 2247 */       if (!this.doingUpdates) {
/* 2248 */         this.doingUpdates = true;
/* 2249 */         syncUpdate();
/*      */       }
/*      */ 
/* 2252 */       this.updater.setShort(columnIndex, x);
/*      */     } else {
/* 2254 */       this.inserter.setShort(columnIndex, x);
/*      */ 
/* 2256 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 2277 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 2296 */     checkClosed();
/*      */ 
/* 2298 */     if (!this.onInsertRow) {
/* 2299 */       if (!this.doingUpdates) {
/* 2300 */         this.doingUpdates = true;
/* 2301 */         syncUpdate();
/*      */       }
/*      */ 
/* 2304 */       this.updater.setString(columnIndex, x);
/*      */     } else {
/* 2306 */       this.inserter.setString(columnIndex, x);
/*      */ 
/* 2308 */       if (x == null) {
/* 2309 */         this.thisRow[(columnIndex - 1)] = null;
/*      */       }
/* 2311 */       else if (getCharConverter() != null) {
/* 2312 */         this.thisRow[(columnIndex - 1)] = StringUtils.getBytes(x, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode());
/*      */       }
/*      */       else
/*      */       {
/* 2317 */         this.thisRow[(columnIndex - 1)] = x.getBytes();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 2339 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 2358 */     if (!this.onInsertRow) {
/* 2359 */       if (!this.doingUpdates) {
/* 2360 */         this.doingUpdates = true;
/* 2361 */         syncUpdate();
/*      */       }
/*      */ 
/* 2364 */       this.updater.setTime(columnIndex, x);
/*      */     } else {
/* 2366 */       this.inserter.setTime(columnIndex, x);
/*      */ 
/* 2368 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2389 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public synchronized void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2408 */     if (!this.onInsertRow) {
/* 2409 */       if (!this.doingUpdates) {
/* 2410 */         this.doingUpdates = true;
/* 2411 */         syncUpdate();
/*      */       }
/*      */ 
/* 2414 */       this.updater.setTimestamp(columnIndex, x);
/*      */     } else {
/* 2416 */       this.inserter.setTimestamp(columnIndex, x);
/*      */ 
/* 2418 */       this.thisRow[(columnIndex - 1)] = this.inserter.getBytesRepresentation(columnIndex - 1);
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2439 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.UpdatableResultSet
 * JD-Core Version:    0.6.0
 */