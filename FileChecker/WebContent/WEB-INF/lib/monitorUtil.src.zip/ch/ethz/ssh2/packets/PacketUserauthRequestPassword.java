/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthRequestPassword
/*    */ {
/*    */   byte[] payload;
/*    */   String userName;
/*    */   String serviceName;
/*    */   String password;
/*    */ 
/*    */   public PacketUserauthRequestPassword(String serviceName, String user, String pass)
/*    */   {
/* 21 */     this.serviceName = serviceName;
/* 22 */     this.userName = user;
/* 23 */     this.password = pass;
/*    */   }
/*    */ 
/*    */   public PacketUserauthRequestPassword(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 28 */     this.payload = new byte[len];
/* 29 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 31 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 33 */     int packet_type = tr.readByte();
/*    */ 
/* 35 */     if (packet_type != 50) {
/* 36 */       throw new IOException("This is not a SSH_MSG_USERAUTH_REQUEST! (" + packet_type + ")");
/*    */     }
/* 38 */     this.userName = tr.readString();
/* 39 */     this.serviceName = tr.readString();
/*    */ 
/* 41 */     String method = tr.readString();
/*    */ 
/* 43 */     if (!method.equals("password")) {
/* 44 */       throw new IOException("This is not a SSH_MSG_USERAUTH_REQUEST with type password!");
/*    */     }
/*    */ 
/* 48 */     if (tr.remain() != 0)
/* 49 */       throw new IOException("Padding in SSH_MSG_USERAUTH_REQUEST packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 54 */     if (this.payload == null)
/*    */     {
/* 56 */       TypesWriter tw = new TypesWriter();
/* 57 */       tw.writeByte(50);
/* 58 */       tw.writeString(this.userName);
/* 59 */       tw.writeString(this.serviceName);
/* 60 */       tw.writeString("password");
/* 61 */       tw.writeBoolean(false);
/* 62 */       tw.writeString(this.password);
/* 63 */       this.payload = tw.getBytes();
/*    */     }
/* 65 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthRequestPassword
 * JD-Core Version:    0.6.0
 */