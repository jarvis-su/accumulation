package com.ibm.wsdl.extensions.schema;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaImport;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SchemaImpl
  implements Schema
{
  protected QName elementType = null;
  protected Boolean required = null;
  protected Element element = null;
  public static final long serialVersionUID = 1L;
  private Map imports = new HashMap();
  private List includes = new Vector();
  private List redefines = new Vector();
  private String documentBaseURI = null;

  public Map getImports()
  {
    return this.imports;
  }

  public SchemaImport createImport()
  {
    return new SchemaImportImpl();
  }

  public void addImport(SchemaImport paramSchemaImport)
  {
    String str = paramSchemaImport.getNamespaceURI();
    Object localObject = (List)this.imports.get(str);
    if (localObject == null)
    {
      localObject = new Vector();
      this.imports.put(str, localObject);
    }
    ((List)localObject).add(paramSchemaImport);
  }

  public List getIncludes()
  {
    return this.includes;
  }

  public SchemaReference createInclude()
  {
    return new SchemaReferenceImpl();
  }

  public void addInclude(SchemaReference paramSchemaReference)
  {
    this.includes.add(paramSchemaReference);
  }

  public List getRedefines()
  {
    return this.redefines;
  }

  public SchemaReference createRedefine()
  {
    return new SchemaReferenceImpl();
  }

  public void addRedefine(SchemaReference paramSchemaReference)
  {
    this.redefines.add(paramSchemaReference);
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("SchemaExtensibilityElement (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.element != null)
      localStringBuffer.append("\nelement=" + this.element);
    return localStringBuffer.toString();
  }

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setElement(Element paramElement)
  {
    this.element = paramElement;
  }

  public Element getElement()
  {
    return this.element;
  }

  public void setDocumentBaseURI(String paramString)
  {
    this.documentBaseURI = paramString;
  }

  public String getDocumentBaseURI()
  {
    return this.documentBaseURI;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.schema.SchemaImpl
 * JD-Core Version:    0.6.0
 */