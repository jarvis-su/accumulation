/*     */ package com.acs.eppic.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Date;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ public class Message
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3058395228514311379L;
/*     */   private String systemId;
/*     */   private Date timestamp;
/*     */   private String serviceId;
/*     */   private String IP;
/*     */   private String port;
/*     */   private MessageType type;
/*     */   private MessageData m_MessageData;
/* 214 */   private Object __equalsCalc = null;
/*     */ 
/* 251 */   private boolean __hashCodeCalc = false;
/*     */ 
/* 285 */   private static TypeDesc typeDesc = new TypeDesc(Message.class, true);
/*     */ 
/*     */   static {
/* 288 */     typeDesc.setXmlType(new QName("http://message.eppic.acs.com", "Message"));
/* 289 */     ElementDesc elemField = new ElementDesc();
/* 290 */     elemField.setFieldName("systemId");
/* 291 */     elemField.setXmlName(new QName("", "systemId"));
/* 292 */     elemField.setXmlType(new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
/* 293 */     elemField.setNillable(true);
/* 294 */     typeDesc.addFieldDesc(elemField);
/* 295 */     elemField = new ElementDesc();
/* 296 */     elemField.setFieldName("timestamp");
/* 297 */     elemField.setXmlName(new QName("", "timestamp"));
/* 298 */     elemField.setXmlType(new QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
/* 299 */     elemField.setNillable(true);
/* 300 */     typeDesc.addFieldDesc(elemField);
/* 301 */     elemField = new ElementDesc();
/* 302 */     elemField.setFieldName("serviceId");
/* 303 */     elemField.setXmlName(new QName("", "serviceId"));
/* 304 */     elemField.setXmlType(new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
/* 305 */     elemField.setNillable(true);
/* 306 */     typeDesc.addFieldDesc(elemField);
/* 307 */     elemField = new ElementDesc();
/* 308 */     elemField.setFieldName("IP");
/* 309 */     elemField.setXmlName(new QName("", "IP"));
/* 310 */     elemField.setXmlType(new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
/* 311 */     elemField.setNillable(false);
/* 312 */     typeDesc.addFieldDesc(elemField);
/* 313 */     elemField = new ElementDesc();
/* 314 */     elemField.setFieldName("port");
/* 315 */     elemField.setXmlName(new QName("", "port"));
/* 316 */     elemField.setXmlType(new QName("http://schemas.xmlsoap.org/soap/encoding/", "string"));
/* 317 */     elemField.setNillable(true);
/* 318 */     typeDesc.addFieldDesc(elemField);
/* 319 */     elemField = new ElementDesc();
/* 320 */     elemField.setFieldName("type");
/* 321 */     elemField.setXmlName(new QName("", "type"));
/* 322 */     elemField.setXmlType(new QName("http://message.eppic.acs.com", "MessageType"));
/* 323 */     elemField.setNillable(true);
/* 324 */     typeDesc.addFieldDesc(elemField);
/* 325 */     elemField = new ElementDesc();
/* 326 */     elemField.setFieldName("m_MessageData");
/* 327 */     elemField.setXmlName(new QName("", "m_MessageData"));
/* 328 */     elemField.setXmlType(new QName("http://message.eppic.acs.com", "MessageData"));
/* 329 */     elemField.setNillable(true);
/* 330 */     typeDesc.addFieldDesc(elemField);
/*     */   }
/*     */ 
/*     */   public Message()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Message(String systemId, String serviceId, int mType, String port)
/*     */   {
/*  35 */     this.systemId = systemId;
/*  36 */     this.serviceId = serviceId;
/*  37 */     this.type = new MessageType(mType);
/*  38 */     this.timestamp = new Date();
/*  39 */     this.port = port;
/*     */     try {
/*  41 */       InetAddress i = InetAddress.getLocalHost();
/*  42 */       this.IP = i.getHostAddress();
/*     */     } catch (UnknownHostException e) {
/*  44 */       this.IP = "127.0.0.1";
/*     */     }
/*     */   }
/*     */ 
/*     */   public Message(String systemId, String serviceId, int mType, String IP, String port) {
/*  49 */     this.systemId = systemId;
/*  50 */     this.serviceId = serviceId;
/*  51 */     this.type = new MessageType(mType);
/*  52 */     this.timestamp = new Date();
/*  53 */     this.port = port;
/*  54 */     this.IP = IP;
/*     */   }
/*     */ 
/*     */   public Message(String systemId, String serviceId, Date timestamp, String IP, String port, MessageType type, MessageData m_MessageData)
/*     */   {
/*  65 */     this.systemId = systemId;
/*  66 */     this.timestamp = timestamp;
/*  67 */     this.serviceId = serviceId;
/*  68 */     this.IP = IP;
/*  69 */     this.port = port;
/*  70 */     this.type = type;
/*  71 */     this.m_MessageData = m_MessageData;
/*     */   }
/*     */ 
/*     */   public String getSystemId()
/*     */   {
/*  81 */     return this.systemId;
/*     */   }
/*     */ 
/*     */   public void setSystemId(String systemId)
/*     */   {
/*  91 */     this.systemId = systemId;
/*     */   }
/*     */ 
/*     */   public Date getTimestamp()
/*     */   {
/* 101 */     return this.timestamp;
/*     */   }
/*     */ 
/*     */   public void setTimestamp(Date timestamp)
/*     */   {
/* 111 */     this.timestamp = timestamp;
/*     */   }
/*     */ 
/*     */   public String getServiceId()
/*     */   {
/* 121 */     return this.serviceId;
/*     */   }
/*     */ 
/*     */   public void setServiceId(String serviceId)
/*     */   {
/* 131 */     this.serviceId = serviceId;
/*     */   }
/*     */ 
/*     */   public String getIP()
/*     */   {
/* 141 */     return this.IP;
/*     */   }
/*     */ 
/*     */   public void setIP(String IP)
/*     */   {
/* 151 */     this.IP = IP;
/*     */   }
/*     */ 
/*     */   public String getPort()
/*     */   {
/* 161 */     return this.port;
/*     */   }
/*     */ 
/*     */   public void setPort(String port)
/*     */   {
/* 171 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public MessageType getType()
/*     */   {
/* 181 */     return this.type;
/*     */   }
/*     */ 
/*     */   public void setType(MessageType type)
/*     */   {
/* 191 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public MessageData getM_MessageData()
/*     */   {
/* 201 */     return this.m_MessageData;
/*     */   }
/*     */ 
/*     */   public void setM_MessageData(MessageData m_MessageData)
/*     */   {
/* 211 */     this.m_MessageData = m_MessageData;
/*     */   }
/*     */ 
/*     */   public synchronized boolean equals(Object obj)
/*     */   {
/* 216 */     if (!(obj instanceof Message)) return false;
/* 217 */     Message other = (Message)obj;
/* 218 */     if (obj == null) return false;
/* 219 */     if (this == obj) return true;
/* 220 */     if (this.__equalsCalc != null) {
/* 221 */       return this.__equalsCalc == obj;
/*     */     }
/* 223 */     this.__equalsCalc = obj;
/*     */ 
/* 225 */     boolean _equals = 
/* 226 */       ((this.systemId == null) && (other.getSystemId() == null)) || (
/* 227 */       (this.systemId != null) && 
/* 228 */       (this.systemId.equals(other.getSystemId())) && (
/* 229 */       ((this.timestamp == null) && (other.getTimestamp() == null)) || (
/* 230 */       (this.timestamp != null) && 
/* 231 */       (this.timestamp.equals(other.getTimestamp())) && (
/* 232 */       ((this.serviceId == null) && (other.getServiceId() == null)) || (
/* 233 */       (this.serviceId != null) && 
/* 234 */       (this.serviceId.equals(other.getServiceId())) && (
/* 235 */       ((this.IP == null) && (other.getIP() == null)) || (
/* 236 */       (this.IP != null) && 
/* 237 */       (this.IP.equals(other.getIP())) && (
/* 238 */       ((this.port == null) && (other.getPort() == null)) || (
/* 239 */       (this.port != null) && 
/* 240 */       (this.port.equals(other.getPort())) && (
/* 241 */       ((this.type == null) && (other.getType() == null)) || (
/* 242 */       (this.type != null) && 
/* 243 */       (this.type.equals(other.getType())) && (
/* 244 */       ((this.m_MessageData == null) && (other.getM_MessageData() == null)) || (
/* 245 */       (this.m_MessageData != null) && 
/* 246 */       (this.m_MessageData.equals(other.getM_MessageData())))))))))))))));
/* 247 */     this.__equalsCalc = null;
/* 248 */     return _equals;
/*     */   }
/*     */ 
/*     */   public synchronized int hashCode()
/*     */   {
/* 253 */     if (this.__hashCodeCalc) {
/* 254 */       return 0;
/*     */     }
/* 256 */     this.__hashCodeCalc = true;
/* 257 */     int _hashCode = 1;
/* 258 */     if (getSystemId() != null) {
/* 259 */       _hashCode += getSystemId().hashCode();
/*     */     }
/* 261 */     if (getTimestamp() != null) {
/* 262 */       _hashCode += getTimestamp().hashCode();
/*     */     }
/* 264 */     if (getServiceId() != null) {
/* 265 */       _hashCode += getServiceId().hashCode();
/*     */     }
/* 267 */     if (getIP() != null) {
/* 268 */       _hashCode += getIP().hashCode();
/*     */     }
/* 270 */     if (getPort() != null) {
/* 271 */       _hashCode += getPort().hashCode();
/*     */     }
/* 273 */     if (getType() != null) {
/* 274 */       _hashCode += getType().hashCode();
/*     */     }
/* 276 */     if (getM_MessageData() != null) {
/* 277 */       _hashCode += getM_MessageData().hashCode();
/*     */     }
/* 279 */     this.__hashCodeCalc = false;
/* 280 */     return _hashCode;
/*     */   }
/*     */ 
/*     */   public static TypeDesc getTypeDesc()
/*     */   {
/* 337 */     return typeDesc;
/*     */   }
/*     */ 
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 347 */     return 
/* 348 */       new BeanSerializer(
/* 349 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ 
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 359 */     return 
/* 360 */       new BeanDeserializer(
/* 361 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 366 */     return "\nMessage:\n  SystemId: " + 
/* 367 */       getSystemId() + "\n" + 
/* 368 */       "  ServiceId: " + getServiceId() + "\n" + 
/* 369 */       "  IP: " + getIP() + "\n" + 
/* 370 */       "  Port: " + getPort() + "\n" + 
/* 371 */       "  Time: " + getTimestamp() + "\n" + 
/* 372 */       "  Type: " + getType() + "\n" + 
/* 373 */       "MessageData:\n" + (
/* 374 */       this.m_MessageData == null ? "NULL" : this.m_MessageData.toString());
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.Message
 * JD-Core Version:    0.6.0
 */