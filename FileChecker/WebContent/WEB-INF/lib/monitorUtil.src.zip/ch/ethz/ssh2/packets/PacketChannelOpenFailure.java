/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketChannelOpenFailure
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public int reasonCode;
/*    */   public String description;
/*    */   public String languageTag;
/*    */ 
/*    */   public PacketChannelOpenFailure(int recipientChannelID, int reasonCode, String description, String languageTag)
/*    */   {
/* 23 */     this.recipientChannelID = recipientChannelID;
/* 24 */     this.reasonCode = reasonCode;
/* 25 */     this.description = description;
/* 26 */     this.languageTag = languageTag;
/*    */   }
/*    */ 
/*    */   public PacketChannelOpenFailure(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 31 */     this.payload = new byte[len];
/* 32 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 34 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 36 */     int packet_type = tr.readByte();
/*    */ 
/* 38 */     if (packet_type != 92) {
/* 39 */       throw new IOException(
/* 40 */         "This is not a SSH_MSG_CHANNEL_OPEN_FAILURE! (" + 
/* 41 */         packet_type + ")");
/*    */     }
/* 43 */     this.recipientChannelID = tr.readUINT32();
/* 44 */     this.reasonCode = tr.readUINT32();
/* 45 */     this.description = tr.readString();
/* 46 */     this.languageTag = tr.readString();
/*    */ 
/* 48 */     if (tr.remain() != 0)
/* 49 */       throw new IOException("Padding in SSH_MSG_CHANNEL_OPEN_FAILURE packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 54 */     if (this.payload == null)
/*    */     {
/* 56 */       TypesWriter tw = new TypesWriter();
/* 57 */       tw.writeByte(92);
/* 58 */       tw.writeUINT32(this.recipientChannelID);
/* 59 */       tw.writeUINT32(this.reasonCode);
/* 60 */       tw.writeString(this.description);
/* 61 */       tw.writeString(this.languageTag);
/* 62 */       this.payload = tw.getBytes();
/*    */     }
/* 64 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketChannelOpenFailure
 * JD-Core Version:    0.6.0
 */