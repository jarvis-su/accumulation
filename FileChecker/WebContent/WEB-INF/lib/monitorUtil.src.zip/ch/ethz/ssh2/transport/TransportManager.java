/*     */ package ch.ethz.ssh2.transport;
/*     */ 
/*     */ import ch.ethz.ssh2.ConnectionInfo;
/*     */ import ch.ethz.ssh2.ConnectionMonitor;
/*     */ import ch.ethz.ssh2.DHGexParameters;
/*     */ import ch.ethz.ssh2.HTTPProxyData;
/*     */ import ch.ethz.ssh2.HTTPProxyException;
/*     */ import ch.ethz.ssh2.ProxyData;
/*     */ import ch.ethz.ssh2.ServerHostKeyVerifier;
/*     */ import ch.ethz.ssh2.crypto.Base64;
/*     */ import ch.ethz.ssh2.crypto.CryptoWishList;
/*     */ import ch.ethz.ssh2.crypto.cipher.BlockCipher;
/*     */ import ch.ethz.ssh2.crypto.digest.MAC;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import ch.ethz.ssh2.packets.PacketDisconnect;
/*     */ import ch.ethz.ssh2.packets.TypesReader;
/*     */ import ch.ethz.ssh2.util.Tokenizer;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.InetSocketAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class TransportManager
/*     */ {
/*  55 */   private static final Logger log = Logger.getLogger(TransportManager.class);
/*     */ 
/*  64 */   private final Vector asynchronousQueue = new Vector();
/*  65 */   private Thread asynchronousThread = null;
/*     */   String hostname;
/*     */   int port;
/* 126 */   final Socket sock = new Socket();
/*     */ 
/* 128 */   Object connectionSemaphore = new Object();
/*     */ 
/* 130 */   boolean flagKexOngoing = false;
/* 131 */   boolean connectionClosed = false;
/*     */ 
/* 133 */   Throwable reasonClosedCause = null;
/*     */   TransportConnection tc;
/*     */   KexManager km;
/* 138 */   Vector messageHandlers = new Vector();
/*     */   Thread receiveThread;
/* 142 */   Vector connectionMonitors = new Vector();
/* 143 */   boolean monitorsWereInformed = false;
/*     */ 
/*     */   private InetAddress createInetAddress(String host)
/*     */     throws UnknownHostException
/*     */   {
/* 159 */     InetAddress addr = parseIPv4Address(host);
/*     */ 
/* 161 */     if (addr != null) {
/* 162 */       return addr;
/*     */     }
/* 164 */     return InetAddress.getByName(host);
/*     */   }
/*     */ 
/*     */   private InetAddress parseIPv4Address(String host) throws UnknownHostException
/*     */   {
/* 169 */     if (host == null) {
/* 170 */       return null;
/*     */     }
/* 172 */     String[] quad = Tokenizer.parseTokens(host, '.');
/*     */ 
/* 174 */     if ((quad == null) || (quad.length != 4)) {
/* 175 */       return null;
/*     */     }
/* 177 */     byte[] addr = new byte[4];
/*     */ 
/* 179 */     for (int i = 0; i < 4; i++)
/*     */     {
/* 181 */       int part = 0;
/*     */ 
/* 183 */       if ((quad[i].length() == 0) || (quad[i].length() > 3)) {
/* 184 */         return null;
/*     */       }
/* 186 */       for (int k = 0; k < quad[i].length(); k++)
/*     */       {
/* 188 */         char c = quad[i].charAt(k);
/*     */ 
/* 191 */         if ((c < '0') || (c > '9')) {
/* 192 */           return null;
/*     */         }
/* 194 */         part = part * 10 + (c - '0');
/*     */       }
/*     */ 
/* 197 */       if (part > 255) {
/* 198 */         return null;
/*     */       }
/* 200 */       addr[i] = (byte)part;
/*     */     }
/*     */ 
/* 203 */     return InetAddress.getByAddress(host, addr);
/*     */   }
/*     */ 
/*     */   public TransportManager(String host, int port) throws IOException
/*     */   {
/* 208 */     this.hostname = host;
/* 209 */     this.port = port;
/*     */   }
/*     */ 
/*     */   public int getPacketOverheadEstimate()
/*     */   {
/* 214 */     return this.tc.getPacketOverheadEstimate();
/*     */   }
/*     */ 
/*     */   public void setTcpNoDelay(boolean state) throws IOException
/*     */   {
/* 219 */     this.sock.setTcpNoDelay(state);
/*     */   }
/*     */ 
/*     */   public void setSoTimeout(int timeout) throws IOException
/*     */   {
/* 224 */     this.sock.setSoTimeout(timeout);
/*     */   }
/*     */ 
/*     */   public ConnectionInfo getConnectionInfo(int kexNumber) throws IOException
/*     */   {
/* 229 */     return this.km.getOrWaitForConnectionInfo(kexNumber);
/*     */   }
/*     */ 
/*     */   public Throwable getReasonClosedCause()
/*     */   {
/* 234 */     synchronized (this.connectionSemaphore)
/*     */     {
/* 236 */       return this.reasonClosedCause;
/*     */     }
/*     */   }
/*     */ 
/*     */   public byte[] getSessionIdentifier()
/*     */   {
/* 242 */     return this.km.sessionId;
/*     */   }
/*     */ 
/*     */   public void close(Throwable cause, boolean useDisconnectPacket)
/*     */   {
/* 247 */     if (!useDisconnectPacket)
/*     */     {
/*     */       try
/*     */       {
/* 255 */         this.sock.close();
/*     */       }
/*     */       catch (IOException localIOException)
/*     */       {
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 267 */     synchronized (this.connectionSemaphore)
/*     */     {
/* 269 */       if (!this.connectionClosed)
/*     */       {
/* 271 */         if (useDisconnectPacket)
/*     */         {
/*     */           try
/*     */           {
/* 275 */             byte[] msg = new PacketDisconnect(11, cause.getMessage(), "")
/* 276 */               .getPayload();
/* 277 */             if (this.tc != null) {
/* 278 */               this.tc.sendMessage(msg);
/*     */             }
/*     */           }
/*     */           catch (IOException localIOException1)
/*     */           {
/*     */           }
/*     */           try
/*     */           {
/* 286 */             this.sock.close();
/*     */           }
/*     */           catch (IOException localIOException2)
/*     */           {
/*     */           }
/*     */         }
/*     */ 
/* 293 */         this.connectionClosed = true;
/* 294 */         this.reasonClosedCause = cause;
/*     */       }
/* 296 */       this.connectionSemaphore.notifyAll();
/*     */     }
/*     */ 
/* 301 */     Vector monitors = null;
/*     */ 
/* 303 */     synchronized (this)
/*     */     {
/* 310 */       if (!this.monitorsWereInformed)
/*     */       {
/* 312 */         this.monitorsWereInformed = true;
/* 313 */         monitors = (Vector)this.connectionMonitors.clone();
/*     */       }
/*     */     }
/*     */ 
/* 317 */     if (monitors != null)
/*     */     {
/* 319 */       for (int i = 0; i < monitors.size(); i++)
/*     */       {
/*     */         try
/*     */         {
/* 323 */           ConnectionMonitor cmon = (ConnectionMonitor)monitors.elementAt(i);
/* 324 */           cmon.connectionLost(this.reasonClosedCause);
/*     */         }
/*     */         catch (Exception localException)
/*     */         {
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void establishConnection(ProxyData proxyData, int connectTimeout)
/*     */     throws IOException
/*     */   {
/* 337 */     if (proxyData == null)
/*     */     {
/* 339 */       InetAddress addr = createInetAddress(this.hostname);
/* 340 */       this.sock.connect(new InetSocketAddress(addr, this.port), connectTimeout);
/* 341 */       this.sock.setSoTimeout(0);
/* 342 */       return;
/*     */     }
/*     */ 
/* 345 */     if ((proxyData instanceof HTTPProxyData))
/*     */     {
/* 347 */       HTTPProxyData pd = (HTTPProxyData)proxyData;
/*     */ 
/* 351 */       InetAddress addr = createInetAddress(pd.proxyHost);
/* 352 */       this.sock.connect(new InetSocketAddress(addr, pd.proxyPort), connectTimeout);
/* 353 */       this.sock.setSoTimeout(0);
/*     */ 
/* 357 */       StringBuffer sb = new StringBuffer();
/*     */ 
/* 359 */       sb.append("CONNECT ");
/* 360 */       sb.append(this.hostname);
/* 361 */       sb.append(':');
/* 362 */       sb.append(this.port);
/* 363 */       sb.append(" HTTP/1.0\r\n");
/*     */ 
/* 365 */       if ((pd.proxyUser != null) && (pd.proxyPass != null))
/*     */       {
/* 367 */         String credentials = pd.proxyUser + ":" + pd.proxyPass;
/* 368 */         char[] encoded = Base64.encode(credentials.getBytes());
/* 369 */         sb.append("Proxy-Authorization: Basic ");
/* 370 */         sb.append(encoded);
/* 371 */         sb.append("\r\n");
/*     */       }
/*     */ 
/* 374 */       if (pd.requestHeaderLines != null)
/*     */       {
/* 376 */         for (int i = 0; i < pd.requestHeaderLines.length; i++)
/*     */         {
/* 378 */           if (pd.requestHeaderLines[i] == null)
/*     */             continue;
/* 380 */           sb.append(pd.requestHeaderLines[i]);
/* 381 */           sb.append("\r\n");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 386 */       sb.append("\r\n");
/*     */ 
/* 388 */       OutputStream out = this.sock.getOutputStream();
/*     */ 
/* 390 */       out.write(sb.toString().getBytes());
/* 391 */       out.flush();
/*     */ 
/* 395 */       byte[] buffer = new byte[1024];
/* 396 */       InputStream in = this.sock.getInputStream();
/*     */ 
/* 398 */       int len = ClientServerHello.readLineRN(in, buffer);
/*     */ 
/* 400 */       String httpReponse = new String(buffer, 0, len);
/*     */ 
/* 402 */       if (!httpReponse.startsWith("HTTP/")) {
/* 403 */         throw new IOException("The proxy did not send back a valid HTTP response.");
/*     */       }
/*     */ 
/* 407 */       if ((httpReponse.length() < 14) || (httpReponse.charAt(8) != ' ') || (httpReponse.charAt(12) != ' ')) {
/* 408 */         throw new IOException("The proxy did not send back a valid HTTP response.");
/*     */       }
/* 410 */       int errorCode = 0;
/*     */       try
/*     */       {
/* 414 */         errorCode = Integer.parseInt(httpReponse.substring(9, 12));
/*     */       }
/*     */       catch (NumberFormatException ignore)
/*     */       {
/* 418 */         throw new IOException("The proxy did not send back a valid HTTP response.");
/*     */       }
/*     */ 
/* 421 */       if ((errorCode < 0) || (errorCode > 999)) {
/* 422 */         throw new IOException("The proxy did not send back a valid HTTP response.");
/*     */       }
/* 424 */       if (errorCode != 200)
/*     */       {
/* 426 */         throw new HTTPProxyException(httpReponse.substring(13), errorCode);
/*     */       }
/*     */ 
/*     */       while (true)
/*     */       {
/* 433 */         len = ClientServerHello.readLineRN(in, buffer);
/* 434 */         if (len == 0)
/* 435 */           break;
/*     */       }
/* 437 */       return;
/*     */     }
/*     */ 
/* 440 */     throw new IOException("Unsupported ProxyData");
/*     */   }
/*     */ 
/*     */   public void initialize(CryptoWishList cwl, ServerHostKeyVerifier verifier, DHGexParameters dhgex, int connectTimeout, SecureRandom rnd, ProxyData proxyData)
/*     */     throws IOException
/*     */   {
/* 448 */     establishConnection(proxyData, connectTimeout);
/*     */ 
/* 455 */     ClientServerHello csh = new ClientServerHello(this.sock.getInputStream(), this.sock.getOutputStream());
/*     */ 
/* 457 */     this.tc = new TransportConnection(this.sock.getInputStream(), this.sock.getOutputStream(), rnd);
/*     */ 
/* 459 */     this.km = new KexManager(this, csh, cwl, this.hostname, this.port, verifier, rnd);
/* 460 */     this.km.initiateKEX(cwl, dhgex);
/*     */ 
/* 462 */     this.receiveThread = new Thread(new Runnable()
/*     */     {
/*     */       public void run()
/*     */       {
/*     */         try
/*     */         {
/* 468 */           TransportManager.this.receiveLoop();
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 472 */           TransportManager.this.close(e, false);
/*     */ 
/* 474 */           if (TransportManager.log.isEnabled()) {
/* 475 */             TransportManager.log.log(10, "Receive thread: error in receiveLoop: " + e.getMessage());
/*     */           }
/*     */         }
/* 478 */         if (TransportManager.log.isEnabled()) {
/* 479 */           TransportManager.log.log(50, "Receive thread: back from receiveLoop");
/*     */         }
/*     */ 
/* 483 */         if (TransportManager.this.km != null)
/*     */         {
/*     */           try
/*     */           {
/* 487 */             TransportManager.this.km.handleMessage(null, 0);
/*     */           }
/*     */           catch (IOException localIOException1)
/*     */           {
/*     */           }
/*     */         }
/*     */ 
/* 494 */         for (int i = 0; i < TransportManager.this.messageHandlers.size(); i++)
/*     */         {
/* 496 */           TransportManager.HandlerEntry he = (TransportManager.HandlerEntry)TransportManager.this.messageHandlers.elementAt(i);
/*     */           try
/*     */           {
/* 499 */             he.mh.handleMessage(null, 0);
/*     */           }
/*     */           catch (Exception localException)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     });
/* 508 */     this.receiveThread.setDaemon(true);
/* 509 */     this.receiveThread.start();
/*     */   }
/*     */ 
/*     */   public void registerMessageHandler(MessageHandler mh, int low, int high)
/*     */   {
/* 514 */     HandlerEntry he = new HandlerEntry();
/* 515 */     he.mh = mh;
/* 516 */     he.low = low;
/* 517 */     he.high = high;
/*     */ 
/* 519 */     synchronized (this.messageHandlers)
/*     */     {
/* 521 */       this.messageHandlers.addElement(he);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeMessageHandler(MessageHandler mh, int low, int high)
/*     */   {
/* 527 */     synchronized (this.messageHandlers)
/*     */     {
/* 529 */       for (int i = 0; i < this.messageHandlers.size(); i++)
/*     */       {
/* 531 */         HandlerEntry he = (HandlerEntry)this.messageHandlers.elementAt(i);
/* 532 */         if ((he.mh != mh) || (he.low != low) || (he.high != high))
/*     */           continue;
/* 534 */         this.messageHandlers.removeElementAt(i);
/* 535 */         break;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendKexMessage(byte[] msg)
/*     */     throws IOException
/*     */   {
/* 543 */     synchronized (this.connectionSemaphore)
/*     */     {
/* 545 */       if (this.connectionClosed)
/*     */       {
/* 547 */         throw ((IOException)new IOException("Sorry, this connection is closed.").initCause(this.reasonClosedCause));
/*     */       }
/*     */ 
/* 550 */       this.flagKexOngoing = true;
/*     */       try
/*     */       {
/* 554 */         this.tc.sendMessage(msg);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 558 */         close(e, false);
/* 559 */         throw e;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void kexFinished() throws IOException
/*     */   {
/* 566 */     synchronized (this.connectionSemaphore)
/*     */     {
/* 568 */       this.flagKexOngoing = false;
/* 569 */       this.connectionSemaphore.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void forceKeyExchange(CryptoWishList cwl, DHGexParameters dhgex) throws IOException
/*     */   {
/* 575 */     this.km.initiateKEX(cwl, dhgex);
/*     */   }
/*     */ 
/*     */   public void changeRecvCipher(BlockCipher bc, MAC mac)
/*     */   {
/* 580 */     this.tc.changeRecvCipher(bc, mac);
/*     */   }
/*     */ 
/*     */   public void changeSendCipher(BlockCipher bc, MAC mac)
/*     */   {
/* 585 */     this.tc.changeSendCipher(bc, mac);
/*     */   }
/*     */ 
/*     */   public void sendAsynchronousMessage(byte[] msg) throws IOException
/*     */   {
/* 590 */     synchronized (this.asynchronousQueue)
/*     */     {
/* 592 */       this.asynchronousQueue.addElement(msg);
/*     */ 
/* 600 */       if (this.asynchronousQueue.size() > 100) {
/* 601 */         throw new IOException("Error: the peer is not consuming our asynchronous replies.");
/*     */       }
/*     */ 
/* 605 */       if (this.asynchronousThread == null)
/*     */       {
/* 607 */         this.asynchronousThread = new AsynchronousWorker();
/* 608 */         this.asynchronousThread.setDaemon(true);
/* 609 */         this.asynchronousThread.start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setConnectionMonitors(Vector monitors)
/*     */   {
/* 618 */     synchronized (this)
/*     */     {
/* 620 */       this.connectionMonitors = ((Vector)monitors.clone());
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendMessage(byte[] msg) throws IOException
/*     */   {
/* 626 */     if (Thread.currentThread() == this.receiveThread) {
/* 627 */       throw new IOException("Assertion error: sendMessage may never be invoked by the receiver thread!");
/*     */     }
/* 629 */     synchronized (this.connectionSemaphore)
/*     */     {
/*     */       while (true)
/*     */       {
/* 633 */         if (this.connectionClosed)
/*     */         {
/* 635 */           throw ((IOException)new IOException("Sorry, this connection is closed.")
/* 636 */             .initCause(this.reasonClosedCause));
/*     */         }
/*     */ 
/* 639 */         if (!this.flagKexOngoing) {
/*     */           break;
/*     */         }
/*     */         try
/*     */         {
/* 644 */           this.connectionSemaphore.wait();
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 653 */         this.tc.sendMessage(msg);
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/* 657 */         close(e, false);
/* 658 */         throw e;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void receiveLoop() throws IOException
/*     */   {
/* 665 */     byte[] msg = new byte[35000];
/*     */     while (true)
/*     */     {
/* 669 */       int msglen = this.tc.receiveMessage(msg, 0, msg.length);
/*     */ 
/* 671 */       int type = msg[0] & 0xFF;
/*     */ 
/* 673 */       if (type == 2) {
/*     */         continue;
/*     */       }
/* 676 */       if (type == 4)
/*     */       {
/* 678 */         if (!log.isEnabled())
/*     */           continue;
/* 680 */         TypesReader tr = new TypesReader(msg, 0, msglen);
/* 681 */         tr.readByte();
/* 682 */         tr.readBoolean();
/* 683 */         StringBuffer debugMessageBuffer = new StringBuffer();
/* 684 */         debugMessageBuffer.append(tr.readString("UTF-8"));
/*     */ 
/* 686 */         for (int i = 0; i < debugMessageBuffer.length(); i++)
/*     */         {
/* 688 */           char c = debugMessageBuffer.charAt(i);
/*     */ 
/* 690 */           if ((c >= ' ') && (c <= '~'))
/*     */             continue;
/* 692 */           debugMessageBuffer.setCharAt(i, 65533);
/*     */         }
/*     */ 
/* 695 */         log.log(50, "DEBUG Message from remote: '" + debugMessageBuffer.toString() + "'");
/*     */ 
/* 697 */         continue;
/*     */       }
/*     */ 
/* 700 */       if (type == 3)
/*     */       {
/* 702 */         throw new IOException("Peer sent UNIMPLEMENTED message, that should not happen.");
/*     */       }
/*     */ 
/* 705 */       if (type == 1)
/*     */       {
/* 707 */         TypesReader tr = new TypesReader(msg, 0, msglen);
/* 708 */         tr.readByte();
/* 709 */         int reason_code = tr.readUINT32();
/* 710 */         StringBuffer reasonBuffer = new StringBuffer();
/* 711 */         reasonBuffer.append(tr.readString("UTF-8"));
/*     */ 
/* 718 */         if (reasonBuffer.length() > 255)
/*     */         {
/* 720 */           reasonBuffer.setLength(255);
/* 721 */           reasonBuffer.setCharAt(254, '.');
/* 722 */           reasonBuffer.setCharAt(253, '.');
/* 723 */           reasonBuffer.setCharAt(252, '.');
/*     */         }
/*     */ 
/* 733 */         for (int i = 0; i < reasonBuffer.length(); i++)
/*     */         {
/* 735 */           char c = reasonBuffer.charAt(i);
/*     */ 
/* 737 */           if ((c >= ' ') && (c <= '~'))
/*     */             continue;
/* 739 */           reasonBuffer.setCharAt(i, 65533);
/*     */         }
/*     */ 
/* 742 */         throw new IOException("Peer sent DISCONNECT message (reason code " + reason_code + "): " + 
/* 743 */           reasonBuffer.toString());
/*     */       }
/*     */ 
/* 750 */       if ((type == 20) || (type == 21) || (
/* 751 */         (type >= 30) && (type <= 49)))
/*     */       {
/* 753 */         this.km.handleMessage(msg, msglen);
/* 754 */         continue;
/*     */       }
/*     */ 
/* 757 */       MessageHandler mh = null;
/*     */ 
/* 759 */       for (int i = 0; i < this.messageHandlers.size(); i++)
/*     */       {
/* 761 */         HandlerEntry he = (HandlerEntry)this.messageHandlers.elementAt(i);
/* 762 */         if ((he.low > type) || (type > he.high))
/*     */           continue;
/* 764 */         mh = he.mh;
/* 765 */         break;
/*     */       }
/*     */ 
/* 769 */       if (mh == null) {
/* 770 */         throw new IOException("Unexpected SSH message (type " + type + ")");
/*     */       }
/* 772 */       mh.handleMessage(msg, msglen);
/*     */     }
/*     */   }
/*     */ 
/*     */   class HandlerEntry
/*     */   {
/*     */     MessageHandler mh;
/*     */     int low;
/*     */     int high;
/*     */ 
/*     */     HandlerEntry()
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   class AsynchronousWorker extends Thread
/*     */   {
/*     */     AsynchronousWorker()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       while (true)
/*     */       {
/*  73 */         byte[] msg = (byte[])null;
/*     */ 
/*  75 */         synchronized (TransportManager.this.asynchronousQueue)
/*     */         {
/*  77 */           if (TransportManager.this.asynchronousQueue.size() == 0)
/*     */           {
/*     */             try
/*     */             {
/*  83 */               TransportManager.this.asynchronousQueue.wait(2000L);
/*     */             }
/*     */             catch (InterruptedException localInterruptedException)
/*     */             {
/*     */             }
/*     */ 
/*  90 */             if (TransportManager.this.asynchronousQueue.size() == 0)
/*     */             {
/*  92 */               TransportManager.this.asynchronousThread = null;
/*  93 */               return;
/*     */             }
/*     */           }
/*     */ 
/*  97 */           msg = (byte[])TransportManager.this.asynchronousQueue.remove(0);
/*     */         }
/*     */ 
/*     */         try
/*     */         {
/* 114 */           TransportManager.this.sendMessage(msg);
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/* 118 */           return;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.TransportManager
 * JD-Core Version:    0.6.0
 */