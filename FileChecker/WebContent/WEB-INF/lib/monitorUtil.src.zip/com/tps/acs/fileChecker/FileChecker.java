/*     */ package com.acs.fileChecker;
/*     */ 
/*     */ import com.acs.eppic.message.AlertData;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.messageservice.MessageSender;
/*     */ import com.acs.fileChecker.fileserver.FileCheckerMain3;
/*     */ import com.smj.dbvariable.VarCache;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.mail.EmailException;
/*     */ import org.apache.commons.mail.MultiPartEmail;
/*     */ 
/*     */ public class FileChecker
/*     */ {
/*     */   private Calendar _cal;
/*     */   private Calendar _today;
/*  43 */   private String _dbhost = null;
/*  44 */   private String _dbname = null;
/*  45 */   private String _dbuser = null;
/*  46 */   private String _dbpass = null;
/*  47 */   private String _username = null;
/*  48 */   private String _emailFrom = null;
/*  49 */   private String _emailHost = null;
/*  50 */   private String _emailReplyTo = null;
/*  51 */   private String _keyFile = null;
/*  52 */   private String _remoteCommand = "/usr/local/java14/bin/java -classpath /home/monitor/lib FileCheckerMain3 2>/tmp/blah";
/*     */   private int _numGroups;
/*  54 */   private Map<String, String> _states = new HashMap();
/*  55 */   private MessageSender _ms = null;
/*     */   private Connection _conn;
/*     */   private PreparedStatement _ps;
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*  61 */     if (argv.length >= 1) {
/*  62 */       String states = argv[0];
/*  63 */       String dateFor = argv[1];
/*  64 */       FileChecker x = new FileChecker(dateFor, "/config/filechecker.properties");
/*  65 */       String files = null;
/*     */       String instance;
/*  66 */       if (argv.length >= 3) {
/*  67 */         String alertType = argv[2];
/*  68 */         for (Iterator localIterator = x.commasToArray(states).iterator(); localIterator.hasNext(); ) { instance = (String)localIterator.next();
/*  69 */           files = x.getFilesForInstanceLocal(instance, true);
/*     */ 
/*  71 */           if (alertType.startsWith("-mailTo=")) {
/*  72 */             String emailList = alertType.substring(8);
/*  73 */             x.mailIt(emailList, files);
/*     */           }
/*  75 */           else if ((alertType.startsWith("-alert")) && 
/*  76 */             (!files.equals(""))) {
/*  77 */             x.sendAlert(instance.toUpperCase(), 
/*  78 */               "FileChecker Detected problems\n\n" + files);
/*     */           }
/*  80 */           if (!files.equals(""))
/*  81 */             System.out.println(files); }
/*     */       }
/*     */       else
/*     */       {
/*  85 */         for (String instance : x.commasToArray(states)) {
/*  86 */           files = x.getFilesForInstanceLocal(instance, false);
/*  87 */           if (!files.equals(""))
/*  88 */             System.out.println(files);
/*     */         }
/*     */       }
/*  91 */       x.cleanup();
/*     */     }
/*     */     else {
/*  94 */       System.out.println("Usage: FileChecker instance1,instance2 \n -mailTo=email1,email2...\n -alert (Sends alerts to EMMS)");
/*     */     }
/*     */   }
/*     */ 
/*     */   public FileChecker(String checkDate)
/*     */   {
/* 101 */     this._cal = strToCal(checkDate);
/* 102 */     this._ms = new MessageSender();
/*     */ 
/* 104 */     this._today = Calendar.getInstance();
/*     */   }
/*     */ 
/*     */   public FileChecker(String checkDate, String properties) {
/* 108 */     this(checkDate);
/*     */     try
/*     */     {
/* 111 */       Class.forName("org.sqlite.JDBC");
/* 112 */       this._conn = DriverManager.getConnection("jdbc:sqlite:fileChecker.db"); } catch (Exception e) {
/* 113 */       e.printStackTrace();
/* 114 */     }loadProperties(properties);
/*     */ 
/* 116 */     this._ps = prepare(checkDate);
/*     */   }
/*     */ 
/*     */   public void sendAlert(String id, String desc) {
/* 120 */     Message m = new Message(id, "FILECHECK", 
/* 121 */       1, "");
/* 122 */     m.setM_MessageData(new AlertData("_GENERIC_1", desc));
/* 123 */     this._ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public ArrayList<String> commasToArray(String s) {
/* 127 */     ArrayList ar = new ArrayList();
/* 128 */     StringTokenizer st = new StringTokenizer(s, ",");
/* 129 */     while (st.hasMoreTokens())
/* 130 */       ar.add(st.nextToken());
/* 131 */     return ar;
/*     */   }
/*     */ 
/*     */   public void mailIt(String emailList, String stuff) {
/* 135 */     ArrayList list = commasToArray(emailList);
/* 136 */     if ((stuff == null) || (stuff.equals("")) || 
/* 137 */       (this._emailFrom == null) || (this._emailHost == null))
/* 138 */       return;
/* 139 */     MultiPartEmail email = new MultiPartEmail();
/*     */     try {
/* 141 */       email.setFrom(this._emailFrom);
/* 142 */       email.addReplyTo(this._emailReplyTo);
/* 143 */       email.setSubject("[FileChecker] Problems detected at " + 
/* 144 */         String.format("%1$tD %1$tl:%1$tM %1$tp", new Object[] { Calendar.getInstance() }));
/* 145 */       email.setHostName(this._emailHost);
/* 146 */       for (String s : list) {
/* 147 */         email.addTo(s);
/*     */       }
/* 149 */       email.addPart(stuff, "text/plain");
/* 150 */       email.send(); } catch (EmailException e) {
/* 151 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void loadProperties(String filename) {
/* 156 */     Properties props = new Properties();
/*     */     try
/*     */     {
/* 160 */       props.load(FileChecker.class.getResourceAsStream(filename));
/* 161 */       this._username = props.getProperty("remote.username");
/* 162 */       this._keyFile = props.getProperty("keyfile");
/* 163 */       this._remoteCommand = props.getProperty("remote.command");
/* 164 */       this._dbhost = props.getProperty("database.host");
/* 165 */       this._dbname = props.getProperty("database.schema");
/* 166 */       this._dbuser = props.getProperty("database.user");
/* 167 */       this._dbpass = props.getProperty("database.pass");
/* 168 */       this._emailFrom = props.getProperty("email.from");
/* 169 */       this._emailHost = props.getProperty("email.host");
/* 170 */       this._emailReplyTo = props.getProperty("email.replyto");
/*     */ 
/* 172 */       this._numGroups = Integer.valueOf(props.getProperty("products.numgroups")).intValue();
/*     */ 
/* 174 */       for (int i = 0; i < this._numGroups; i++)
/*     */       {
/* 176 */         int numinstances = Integer.valueOf(props.getProperty("products." + i + ".numInstances")).intValue();
/* 177 */         for (int j = 0; j < numinstances; j++)
/*     */         {
/* 179 */           String name = props.getProperty("products." + i + "." + j + ".name");
/* 180 */           String instanceId = props.getProperty("products." + i + "." + j + ".instanceId");
/* 181 */           this._states.put(name.toUpperCase(), instanceId);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 186 */       VarCache.getInstance(this._conn);
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 190 */       System.out.println("Could not load properties " + filename);
/* 191 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<String> getStates() {
/* 196 */     return this._states.keySet();
/*     */   }
/*     */ 
/*     */   public void cleanup()
/*     */   {
/*     */     try {
/* 202 */       Thread.sleep(2000L);
/*     */     } catch (InterruptedException e) {
/* 204 */       e.printStackTrace();
/*     */     }
/* 206 */     this._ms.setServiceEnabled(false);
/* 207 */     this._ms = null;
/*     */     try {
/* 209 */       this._ps.close();
/*     */     } catch (SQLException localSQLException) {
/*     */     }
/* 212 */     this._conn = null;
/* 213 */     this._ps = null;
/*     */   }
/*     */ 
/*     */   public String checkFilesLocal(ReportList reports, boolean errOnly) {
/* 217 */     StringBuffer output = new StringBuffer();
/* 218 */     FileCheckerMain3 fcm = new FileCheckerMain3(false);
/*     */ 
/* 221 */     for (Report r : reports.getAll().values())
/*     */     {
/* 225 */       String line = r.toString();
/* 226 */       String base = fcm.baseName(line);
/* 227 */       String name = fcm.fileName(line);
/* 228 */       int expectedCount = r.getExpectedCount();
/* 229 */       String[] test = fcm.getFilesRegExp(new File(base), name);
/*     */ 
/* 231 */       if ((test != null) && (test.length != 0)) {
/* 232 */         for (int j = 0; j < test.length; j++) {
/* 233 */           String ch = fcm.check(base + test[j]);
/*     */ 
/* 235 */           if ((!errOnly) || ((errOnly) && (ch.contains("Error"))))
/* 236 */             output.append(base + test[j] + " " + ch + "\n");
/*     */         }
/*     */       }
/* 239 */       if ((test == null) || (expectedCount > test.length)) {
/* 240 */         int count = test == null ? 1 : expectedCount - test.length;
/* 241 */         output.append(base + name + String.format(
/* 242 */           "\tError missing %1$s file%2$s expected by %3$tH:%3$tM\n", new Object[] { 
/* 243 */           Integer.valueOf(count), 
/* 244 */           count == 1 ? "" : "s", 
/* 245 */           r.getStartCheck() }));
/*     */       }
/*     */     }
/* 248 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public int getMonth()
/*     */   {
/* 290 */     return this._cal.get(2) + 1;
/*     */   }
/*     */ 
/*     */   public int getDay() {
/* 294 */     return this._cal.get(5);
/*     */   }
/*     */ 
/*     */   public int getDayOfWeek() {
/* 298 */     return this._cal.get(7);
/*     */   }
/*     */ 
/*     */   public String getFilesForInstanceTest(String state, boolean errOnly) {
/* 302 */     String output = null;
/* 303 */     ReportList replist = new ReportList();
/*     */ 
/* 305 */     replist.add(new Report("YourFace"));
/*     */     try {
/* 307 */       output = checkFilesLocal(replist, errOnly);
/*     */     } catch (Exception e) {
/* 309 */       e.printStackTrace();
/* 310 */     }return output;
/*     */   }
/*     */ 
/*     */   public String getQuery(String date) {
/* 314 */     StringBuffer query = new StringBuffer("");
/* 315 */     query.append("select r.fileName, r.checkTime, r.checkStop from tblVariableReport r, tblReportFrequency rf ");
/* 316 */     query.append("where ( rf.month = 0 or rf.month = ? ) and ( rf.dayOfMonth = 0 or rf.dayOfMonth = ? ) ");
/* 317 */     query.append("and ( rf.dayOfWeek = 0 or rf.dayOfWeek = ? ) and r.instanceID = ? ");
/* 318 */     query.append("and r.frequencyID = rf.frequencyID and r.ignoreFlag = 0 ");
/*     */ 
/* 324 */     query.append("order by fileName, checkTime, checkStop ");
/* 325 */     return query.toString();
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepare(String date) {
/* 329 */     PreparedStatement pps = null;
/*     */     try {
/* 331 */       pps = this._conn.prepareStatement(getQuery(date)); } catch (Exception e) {
/* 332 */       e.printStackTrace();
/* 333 */     }return pps;
/*     */   }
/*     */ 
/*     */   public void setValues(PreparedStatement ps, int month, int day, int dow, String instanceID) throws SQLException {
/* 337 */     ps.setInt(1, month);
/* 338 */     ps.setInt(2, day);
/* 339 */     ps.setInt(3, dow);
/*     */ 
/* 341 */     ps.setInt(4, Integer.parseInt(instanceID));
/*     */   }
/*     */ 
/*     */   public String getFilesForInstanceLocal(String state, boolean errOnly) {
/* 345 */     String output = null;
/* 346 */     ReportList replist = new ReportList();
/*     */ 
/* 349 */     String instanceID = (String)this._states.get(state.toUpperCase());
/*     */ 
/* 351 */     if (instanceID == null) {
/* 352 */       return "Error Instance " + state + " does not exist";
/*     */     }
/*     */ 
/* 359 */     Properties runtimeEnv = new Properties();
/* 360 */     runtimeEnv.put("DATEFOR", this._cal);
/*     */     try {
/* 362 */       setValues(this._ps, getMonth(), getDay(), getDayOfWeek(), instanceID);
/* 363 */       ResultSet rs = this._ps.executeQuery();
/* 364 */       while (rs.next()) {
/*     */         try {
/* 366 */           for (String s : VarCache.resolve(rs.getString("fileName"), runtimeEnv))
/*     */           {
/* 369 */             Calendar start = setCalDate(this._cal, rs.getString("checkTime"));
/* 370 */             Calendar end = setCalDate(this._cal, rs.getString("checkStop"));
/* 371 */             replist.add(new Report(s, start, end));
/*     */           }
/*     */         }
/*     */         catch (Exception e) {
/* 375 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 378 */       System.err.println();
/*     */     }
/*     */     catch (SQLException sqle) {
/* 381 */       sqle.printStackTrace();
/*     */     }
/*     */ 
/* 384 */     output = checkFilesLocal(replist, errOnly);
/* 385 */     return output;
/*     */   }
/*     */ 
/*     */   private Calendar setCalDate(Calendar cal, String d)
/*     */   {
/* 390 */     Calendar dateCal = (Calendar)cal.clone();
/* 391 */     Calendar timeCal = (Calendar)dateCal.clone();
/* 392 */     DateFormat df = new SimpleDateFormat("HH:mm:ss");
/*     */     try {
/* 394 */       Date date = df.parse(d);
/*     */ 
/* 396 */       timeCal.setTimeInMillis(date.getTime()); } catch (ParseException localParseException) {
/*     */     }
/* 398 */     dateCal.set(11, timeCal.get(11));
/* 399 */     dateCal.set(12, timeCal.get(12));
/* 400 */     dateCal.set(13, timeCal.get(13));
/* 401 */     return dateCal;
/*     */   }
/*     */ 
/*     */   public Calendar strToCal(String d)
/*     */   {
/* 450 */     Calendar c = Calendar.getInstance();
/* 451 */     int yr = 0; int mo = 0; int dt = 0;
/* 452 */     if (validDate(d)) {
/* 453 */       mo = Integer.parseInt(d.substring(0, 2));
/* 454 */       dt = Integer.parseInt(d.substring(3, 5));
/* 455 */       yr = Integer.parseInt(d.substring(6, 10));
/* 456 */       c.set(yr, mo - 1, dt);
/* 457 */       return c;
/*     */     }
/* 459 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean validDate(String date)
/*     */   {
/* 464 */     return (date.equals("Never Checked")) || (Pattern.matches("[0-9]+/[0-9]+/2[0-9]+", date));
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.FileChecker
 * JD-Core Version:    0.6.0
 */