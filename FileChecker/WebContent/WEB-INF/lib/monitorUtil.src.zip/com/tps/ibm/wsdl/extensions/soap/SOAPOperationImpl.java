package com.ibm.wsdl.extensions.soap;

import javax.wsdl.extensions.soap.SOAPOperation;
import javax.xml.namespace.QName;

public class SOAPOperationImpl
  implements SOAPOperation
{
  protected QName elementType = SOAPConstants.Q_ELEM_SOAP_OPERATION;
  protected Boolean required = null;
  protected String soapActionURI = null;
  protected String style = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setSoapActionURI(String paramString)
  {
    this.soapActionURI = paramString;
  }

  public String getSoapActionURI()
  {
    return this.soapActionURI;
  }

  public void setStyle(String paramString)
  {
    this.style = paramString;
  }

  public String getStyle()
  {
    return this.style;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("SOAPOperation (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.soapActionURI != null)
      localStringBuffer.append("\nsoapActionURI=" + this.soapActionURI);
    if (this.style != null)
      localStringBuffer.append("\nstyle=" + this.style);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.soap.SOAPOperationImpl
 * JD-Core Version:    0.6.0
 */