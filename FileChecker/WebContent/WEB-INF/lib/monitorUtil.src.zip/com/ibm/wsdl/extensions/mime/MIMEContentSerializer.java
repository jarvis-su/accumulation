package com.ibm.wsdl.extensions.mime;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.mime.MIMEContent;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class MIMEContentSerializer
  implements ExtensionSerializer, ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    MIMEContent localMIMEContent = (MIMEContent)paramExtensibilityElement;
    if (localMIMEContent != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/mime/", "content", paramDefinition);
      if ((paramClass != null) && (MIMEPart.class.isAssignableFrom(paramClass)))
        paramPrintWriter.print("    ");
      paramPrintWriter.print("        <" + str);
      DOMUtils.printAttribute("part", localMIMEContent.getPart(), paramPrintWriter);
      DOMUtils.printAttribute("type", localMIMEContent.getType(), paramPrintWriter);
      Boolean localBoolean = localMIMEContent.getRequired();
      if (localBoolean != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("/>");
    }
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    MIMEContent localMIMEContent = (MIMEContent)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "part");
    String str2 = DOMUtils.getAttribute(paramElement, "type");
    String str3 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      localMIMEContent.setPart(str1);
    if (str2 != null)
      localMIMEContent.setType(str2);
    if (str3 != null)
      localMIMEContent.setRequired(new Boolean(str3));
    return localMIMEContent;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.mime.MIMEContentSerializer
 * JD-Core Version:    0.6.0
 */