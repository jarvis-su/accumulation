/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ import java.util.regex.Matcher;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ public class VarString extends DBVar
/*    */ {
/*    */   public VarString()
/*    */   {
/* 19 */     super(null);
/*    */   }
/*    */ 
/*    */   public VarString(String s) {
/* 23 */     super(s);
/*    */   }
/*    */ 
/*    */   protected Vector<String> resolveInternal(VarCache cache, Properties env) throws Exception {
/* 27 */     Pattern p = Pattern.compile("\\{.*?\\}");
/* 28 */     Matcher ma = p.matcher(getInitialValue());
/* 29 */     Vector ret = new Vector();
/* 30 */     Vector dirty = new Vector();
/* 31 */     ret.add(getInitialValue());
/* 32 */     while (ma.find()) {
/* 33 */       String var = ma.group();
/* 34 */       DBVar child = cache.getVar(var);
/* 35 */       if (child == null)
/* 36 */         throw new Exception("Unresolvable variable " + var);
/* 37 */       if (child.isDirty())
/* 38 */         throw new Exception("Illegal recursive variable " + var);
/* 39 */       Vector cvals = child.resolve(cache, env);
/* 40 */       int size = ret.size();
/* 41 */       for (int i = 0; i < size; i++) {
/* 42 */         String val = (String)ret.get(i);
/* 43 */         for (int j = 0; j < cvals.size(); j++) {
/* 44 */           dirty.add(val.replace(var, (CharSequence)cvals.get(j)));
/*    */         }
/*    */       }
/* 47 */       ret = dirty;
/* 48 */       dirty = new Vector();
/*    */     }
/* 50 */     return ret;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 54 */     VarCache cache = VarCache.getInstance();
/* 55 */     cache.putVar("{var2}", new VarString("shawn"));
/* 56 */     cache.putVar("{CAEBT_COUNTIES}", new VarList("01,02"));
/* 57 */     Vector v = VarCache.resolve("CA{CAEBT_COUNTIES}{var2}");
/* 58 */     for (String s : v)
/* 59 */       System.out.println(s);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.VarString
 * JD-Core Version:    0.6.0
 */