/*     */ package com.acs.fileChecker;
/*     */ 
/*     */ import com.mysql.jdbc.Driver;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Statement;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class DBConnector
/*     */ {
/*     */   private String hostname;
/*     */   private String dbSID;
/*     */   private String dbUser;
/*     */   private String dbPass;
/*     */   private String url;
/*  19 */   private Connection conn = null;
/*  20 */   private Statement strSQL = null;
/*     */ 
/*     */   public DBConnector(String props)
/*     */   {
/*  25 */     Properties prop = new Properties();
/*     */     try
/*     */     {
/*  28 */       prop.load(new FileInputStream(props));
/*  29 */       this.hostname = prop.getProperty("database.host");
/*  30 */       this.dbSID = prop.getProperty("database.schema");
/*  31 */       this.dbUser = prop.getProperty("database.user");
/*  32 */       this.dbPass = prop.getProperty("database.pass");
/*  33 */       this.url = "";
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/*  37 */       System.out.println("Could not load properties");
/*  38 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public DBConnector(String URL, String dbUser, String dbPass) {
/*  43 */     this.url = URL;
/*  44 */     this.dbUser = dbUser;
/*  45 */     this.dbPass = dbPass;
/*     */   }
/*     */ 
/*     */   public DBConnector(String hostname, String dbSID, String dbUser, String dbPass)
/*     */   {
/*  52 */     this.hostname = hostname;
/*  53 */     this.dbSID = dbSID;
/*  54 */     this.dbUser = dbUser;
/*  55 */     this.dbPass = dbPass;
/*  56 */     this.url = "";
/*     */   }
/*     */ 
/*     */   public String getHostname()
/*     */   {
/*  65 */     return this.hostname;
/*     */   }
/*     */ 
/*     */   public String getdbSID() {
/*  69 */     return this.dbSID;
/*     */   }
/*     */ 
/*     */   public String getUser() {
/*  73 */     return this.dbUser;
/*     */   }
/*     */ 
/*     */   public String getPass() {
/*  77 */     return this.dbPass;
/*     */   }
/*     */ 
/*     */   public boolean checkStatus()
/*     */   {
/*  83 */     return this.conn != null;
/*     */   }
/*     */ 
/*     */   public int connect()
/*     */   {
/*     */     try
/*     */     {
/*  94 */       if (this.url.length() == 0) {
/*  95 */         this.url = ("jdbc:mysql://" + this.hostname + "/" + this.dbSID);
/*  96 */         DriverManager.registerDriver(new Driver());
/*     */       }
/*  98 */       this.conn = DriverManager.getConnection(this.url, this.dbUser, this.dbPass);
/*     */ 
/* 100 */       this.conn.setAutoCommit(false);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 104 */       System.err.println("Cannot connect to Server : " + this.hostname + "\t SID : " + this.dbSID);
/* 105 */       System.err.println(e.getMessage());
/* 106 */       return 1;
/*     */     }
/* 108 */     return 0;
/*     */   }
/*     */ 
/*     */   public int disconnect()
/*     */   {
/* 113 */     if (this.conn != null) {
/*     */       try {
/* 115 */         this.conn.close();
/*     */       }
/*     */       catch (Exception localException) {
/*     */       }
/* 119 */       return 0;
/*     */     }
/* 121 */     return 1;
/*     */   }
/*     */ 
/*     */   public String execSingleResultQuery(String SQL)
/*     */   {
/* 129 */     ResultSet temp = execQuery(SQL);
/* 130 */     String out = null;
/*     */     try {
/* 132 */       out = temp.getString(0);
/*     */     } catch (Exception e) {
/* 134 */       e.printStackTrace();
/* 135 */     }return out;
/*     */   }
/*     */ 
/*     */   public ResultSet execQuery(String SQL)
/*     */   {
/* 140 */     ResultSet rs = null;
/*     */ 
/* 142 */     if (SQL.length() > 1) {
/*     */       try {
/* 144 */         this.strSQL = this.conn.createStatement();
/* 145 */         rs = this.strSQL.executeQuery(SQL);
/*     */       }
/*     */       catch (Exception e) {
/* 148 */         e.printStackTrace();
/* 149 */         return null;
/*     */       }
/*     */     }
/* 152 */     return rs;
/*     */   }
/*     */ 
/*     */   public int insertStatement(String SQL) {
/* 156 */     int results = 0;
/*     */     try {
/* 158 */       this.strSQL = this.conn.createStatement();
/* 159 */       results = this.strSQL.executeUpdate(SQL);
/*     */     } catch (Exception e) {
/* 161 */       e.printStackTrace();
/* 162 */       results = -1;
/*     */     }
/* 164 */     return results;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String SQL) {
/* 168 */     PreparedStatement ps = null;
/*     */     try {
/* 170 */       ps = this.conn.prepareStatement(SQL);
/*     */     } catch (Exception e) {
/* 172 */       e.printStackTrace();
/*     */     }
/* 174 */     return ps;
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */   {
/*     */     try
/*     */     {
/* 181 */       this.conn.commit();
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 185 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/* 190 */     DBConnector d = new DBConnector("192.168.179.39", "dbtoolsite", "sjohnson", "sjohnson1");
/* 191 */     d.connect();
/* 192 */     ResultSet rs = d.execQuery("select * from tblInstance");
/*     */     try
/*     */     {
/* 195 */       while (rs.next())
/*     */       {
/* 197 */         System.out.println(rs.getRow());
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 201 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.DBConnector
 * JD-Core Version:    0.6.0
 */