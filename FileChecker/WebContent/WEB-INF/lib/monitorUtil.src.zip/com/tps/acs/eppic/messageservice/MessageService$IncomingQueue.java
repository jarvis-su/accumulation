/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class MessageService$IncomingQueue
/*     */ {
/*     */   private final MessageService.IncomingQueue.QueueWorker[] threads;
/*     */   private final LinkedList alertQueue;
/*     */   private final LinkedList messageQueue;
/* 405 */   Object semObj = new Object();
/*     */ 
/*     */   public MessageService$IncomingQueue(MessageService arg1) {
/* 408 */     this.alertQueue = new LinkedList();
/* 409 */     this.messageQueue = new LinkedList();
/* 410 */     this.threads = new MessageService.IncomingQueue.QueueWorker[2];
/* 411 */     for (int i = 0; i < this.threads.length; i++) {
/* 412 */       this.threads[i] = new MessageService.IncomingQueue.QueueWorker(this, null);
/* 413 */       this.threads[i].setName("INCOMING_QUEUE_" + i);
/* 414 */       this.threads[i].start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message) {
/* 419 */     if (message.getType().getTypeId() == 1) {
/* 420 */       synchronized (this.alertQueue) {
/* 421 */         this.alertQueue.addLast(message);
/*     */       }
/*     */     }
/* 424 */     synchronized (this.messageQueue) {
/* 425 */       this.messageQueue.addLast(message);
/*     */     }
/*     */ 
/* 428 */     synchronized (this.semObj) {
/* 429 */       this.semObj.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 504 */     return "CLASS: IncomingQueue\n";
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService.IncomingQueue
 * JD-Core Version:    0.6.0
 */