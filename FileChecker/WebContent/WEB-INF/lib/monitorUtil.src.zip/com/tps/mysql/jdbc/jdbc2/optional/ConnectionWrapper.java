/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class ConnectionWrapper extends WrapperBase
/*     */   implements java.sql.Connection
/*     */ {
/*  58 */   private com.mysql.jdbc.Connection mc = null;
/*     */ 
/*  60 */   private MysqlPooledConnection mpc = null;
/*     */ 
/*  62 */   private String invalidHandleStr = "Logical handle no longer valid";
/*     */   private boolean closed;
/*     */   private boolean isForXa;
/*     */ 
/*     */   public ConnectionWrapper(MysqlPooledConnection mysqlPooledConnection, com.mysql.jdbc.Connection mysqlConnection, boolean forXa)
/*     */     throws SQLException
/*     */   {
/*  81 */     this.mpc = mysqlPooledConnection;
/*  82 */     this.mc = mysqlConnection;
/*  83 */     this.closed = false;
/*  84 */     this.pooledConnection = this.mpc;
/*  85 */     this.isForXa = forXa;
/*     */ 
/*  87 */     if (this.isForXa) {
/*  88 */       setInGlobalTx(false);
/*  89 */       setAutoCommit(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {
/* 100 */     checkClosed();
/*     */ 
/* 102 */     if ((autoCommit) && (isInGlobalTx())) {
/* 103 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 109 */       this.mc.setAutoCommit(autoCommit);
/*     */     } catch (SQLException sqlException) {
/* 111 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 122 */     checkClosed();
/*     */     try
/*     */     {
/* 125 */       return this.mc.getAutoCommit();
/*     */     } catch (SQLException sqlException) {
/* 127 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 130 */     return false;
/*     */   }
/*     */ 
/*     */   public void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {
/* 140 */     checkClosed();
/*     */     try
/*     */     {
/* 143 */       this.mc.setCatalog(catalog);
/*     */     } catch (SQLException sqlException) {
/* 145 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 159 */     checkClosed();
/*     */     try
/*     */     {
/* 162 */       return this.mc.getCatalog();
/*     */     } catch (SQLException sqlException) {
/* 164 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 177 */     return (this.closed) || (this.mc.isClosed());
/*     */   }
/*     */ 
/*     */   public boolean isMasterConnection() throws SQLException {
/* 181 */     return this.mc.isMasterConnection();
/*     */   }
/*     */ 
/*     */   public void setHoldability(int arg0)
/*     */     throws SQLException
/*     */   {
/* 188 */     checkClosed();
/*     */     try
/*     */     {
/* 191 */       this.mc.setHoldability(arg0);
/*     */     } catch (SQLException sqlException) {
/* 193 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getHoldability()
/*     */     throws SQLException
/*     */   {
/* 201 */     checkClosed();
/*     */     try
/*     */     {
/* 204 */       return this.mc.getHoldability();
/*     */     } catch (SQLException sqlException) {
/* 206 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 209 */     return 1;
/*     */   }
/*     */ 
/*     */   public long getIdleFor()
/*     */   {
/* 219 */     return this.mc.getIdleFor();
/*     */   }
/*     */ 
/*     */   public DatabaseMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 232 */     checkClosed();
/*     */     try
/*     */     {
/* 235 */       return this.mc.getMetaData();
/*     */     } catch (SQLException sqlException) {
/* 237 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 240 */     return null;
/*     */   }
/*     */ 
/*     */   public void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 250 */     checkClosed();
/*     */     try
/*     */     {
/* 253 */       this.mc.setReadOnly(readOnly);
/*     */     } catch (SQLException sqlException) {
/* 255 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 266 */     checkClosed();
/*     */     try
/*     */     {
/* 269 */       return this.mc.isReadOnly();
/*     */     } catch (SQLException sqlException) {
/* 271 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 274 */     return false;
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint()
/*     */     throws SQLException
/*     */   {
/* 281 */     checkClosed();
/*     */ 
/* 283 */     if (isInGlobalTx()) {
/* 284 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 290 */       return this.mc.setSavepoint();
/*     */     } catch (SQLException sqlException) {
/* 292 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 295 */     return null;
/*     */   }
/*     */ 
/*     */   public Savepoint setSavepoint(String arg0)
/*     */     throws SQLException
/*     */   {
/* 302 */     checkClosed();
/*     */ 
/* 304 */     if (isInGlobalTx()) {
/* 305 */       throw SQLError.createSQLException("Can't set autocommit to 'true' on an XAConnection", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 311 */       return this.mc.setSavepoint(arg0);
/*     */     } catch (SQLException sqlException) {
/* 313 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */   public void setTransactionIsolation(int level)
/*     */     throws SQLException
/*     */   {
/* 326 */     checkClosed();
/*     */     try
/*     */     {
/* 329 */       this.mc.setTransactionIsolation(level);
/*     */     } catch (SQLException sqlException) {
/* 331 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getTransactionIsolation()
/*     */     throws SQLException
/*     */   {
/* 342 */     checkClosed();
/*     */     try
/*     */     {
/* 345 */       return this.mc.getTransactionIsolation();
/*     */     } catch (SQLException sqlException) {
/* 347 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 350 */     return 4;
/*     */   }
/*     */ 
/*     */   public void setTypeMap(Map map)
/*     */     throws SQLException
/*     */   {
/* 361 */     checkClosed();
/*     */     try
/*     */     {
/* 364 */       this.mc.setTypeMap(map);
/*     */     } catch (SQLException sqlException) {
/* 366 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Map getTypeMap()
/*     */     throws SQLException
/*     */   {
/* 377 */     checkClosed();
/*     */     try
/*     */     {
/* 380 */       return this.mc.getTypeMap();
/*     */     } catch (SQLException sqlException) {
/* 382 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 385 */     return null;
/*     */   }
/*     */ 
/*     */   public SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 395 */     checkClosed();
/*     */     try
/*     */     {
/* 398 */       return this.mc.getWarnings();
/*     */     } catch (SQLException sqlException) {
/* 400 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 403 */     return null;
/*     */   }
/*     */ 
/*     */   public void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 414 */     checkClosed();
/*     */     try
/*     */     {
/* 417 */       this.mc.clearWarnings();
/*     */     } catch (SQLException sqlException) {
/* 419 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 434 */     close(true);
/*     */   }
/*     */ 
/*     */   public void commit()
/*     */     throws SQLException
/*     */   {
/* 445 */     checkClosed();
/*     */ 
/* 447 */     if (isInGlobalTx()) {
/* 448 */       throw SQLError.createSQLException("Can't call commit() on an XAConnection associated with a global transaction", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 455 */       this.mc.commit();
/*     */     } catch (SQLException sqlException) {
/* 457 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Statement createStatement()
/*     */     throws SQLException
/*     */   {
/* 468 */     checkClosed();
/*     */     try
/*     */     {
/* 471 */       return new StatementWrapper(this, this.mpc, this.mc.createStatement());
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 474 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 477 */     return null;
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 488 */     checkClosed();
/*     */     try
/*     */     {
/* 491 */       return new StatementWrapper(this, this.mpc, this.mc.createStatement(resultSetType, resultSetConcurrency));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 494 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 497 */     return null;
/*     */   }
/*     */ 
/*     */   public Statement createStatement(int arg0, int arg1, int arg2)
/*     */     throws SQLException
/*     */   {
/* 505 */     checkClosed();
/*     */     try
/*     */     {
/* 508 */       return new StatementWrapper(this, this.mpc, this.mc.createStatement(arg0, arg1, arg2));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 511 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 514 */     return null;
/*     */   }
/*     */ 
/*     */   public String nativeSQL(String sql)
/*     */     throws SQLException
/*     */   {
/* 524 */     checkClosed();
/*     */     try
/*     */     {
/* 527 */       return this.mc.nativeSQL(sql);
/*     */     } catch (SQLException sqlException) {
/* 529 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 532 */     return null;
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql)
/*     */     throws SQLException
/*     */   {
/* 543 */     checkClosed();
/*     */     try
/*     */     {
/* 546 */       return new CallableStatementWrapper(this, this.mpc, this.mc.prepareCall(sql));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 549 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 552 */     return null;
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 563 */     checkClosed();
/*     */     try
/*     */     {
/* 566 */       return new CallableStatementWrapper(this, this.mpc, this.mc.prepareCall(sql, resultSetType, resultSetConcurrency));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 569 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 572 */     return null;
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String arg0, int arg1, int arg2, int arg3)
/*     */     throws SQLException
/*     */   {
/* 580 */     checkClosed();
/*     */     try
/*     */     {
/* 583 */       return new CallableStatementWrapper(this, this.mpc, this.mc.prepareCall(arg0, arg1, arg2, arg3));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 586 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 589 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement clientPrepare(String sql) throws SQLException
/*     */   {
/* 594 */     checkClosed();
/*     */     try
/*     */     {
/* 597 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.clientPrepareStatement(sql));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 600 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 603 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement clientPrepare(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 609 */     checkClosed();
/*     */     try
/*     */     {
/* 612 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
/*     */     }
/*     */     catch (SQLException sqlException)
/*     */     {
/* 616 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 619 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/* 630 */     checkClosed();
/*     */     try
/*     */     {
/* 633 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(sql));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 636 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 639 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 650 */     checkClosed();
/*     */     try
/*     */     {
/* 653 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(sql, resultSetType, resultSetConcurrency));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 656 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 659 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String arg0, int arg1, int arg2, int arg3)
/*     */     throws SQLException
/*     */   {
/* 667 */     checkClosed();
/*     */     try
/*     */     {
/* 670 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(arg0, arg1, arg2, arg3));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 673 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 676 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String arg0, int arg1)
/*     */     throws SQLException
/*     */   {
/* 684 */     checkClosed();
/*     */     try
/*     */     {
/* 687 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(arg0, arg1));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 690 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 693 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String arg0, int[] arg1)
/*     */     throws SQLException
/*     */   {
/* 701 */     checkClosed();
/*     */     try
/*     */     {
/* 704 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(arg0, arg1));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 707 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 710 */     return null;
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String arg0, String[] arg1)
/*     */     throws SQLException
/*     */   {
/* 718 */     checkClosed();
/*     */     try
/*     */     {
/* 721 */       return new PreparedStatementWrapper(this, this.mpc, this.mc.prepareStatement(arg0, arg1));
/*     */     }
/*     */     catch (SQLException sqlException) {
/* 724 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */ 
/* 727 */     return null;
/*     */   }
/*     */ 
/*     */   public void releaseSavepoint(Savepoint arg0)
/*     */     throws SQLException
/*     */   {
/* 734 */     checkClosed();
/*     */     try
/*     */     {
/* 737 */       this.mc.releaseSavepoint(arg0);
/*     */     } catch (SQLException sqlException) {
/* 739 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void rollback()
/*     */     throws SQLException
/*     */   {
/* 750 */     checkClosed();
/*     */ 
/* 753 */     if (isInGlobalTx()) {
/* 754 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 760 */       this.mc.rollback();
/*     */     } catch (SQLException sqlException) {
/* 762 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void rollback(Savepoint arg0)
/*     */     throws SQLException
/*     */   {
/* 770 */     checkClosed();
/*     */ 
/* 772 */     if (isInGlobalTx()) {
/* 773 */       throw SQLError.createSQLException("Can't call rollback() on an XAConnection associated with a global transaction", "2D000", 1401);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 779 */       this.mc.rollback(arg0);
/*     */     } catch (SQLException sqlException) {
/* 781 */       checkAndFireConnectionError(sqlException);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSameResource(java.sql.Connection c) {
/* 786 */     if ((c instanceof ConnectionWrapper))
/* 787 */       return this.mc.isSameResource(((ConnectionWrapper)c).mc);
/* 788 */     if ((c instanceof com.mysql.jdbc.Connection)) {
/* 789 */       return this.mc.isSameResource((com.mysql.jdbc.Connection)c);
/*     */     }
/*     */ 
/* 792 */     return false;
/*     */   }
/*     */ 
/*     */   protected void close(boolean fireClosedEvent) throws SQLException {
/* 796 */     synchronized (this.mpc) {
/* 797 */       if (this.closed) {
/* 798 */         return;
/*     */       }
/*     */ 
/* 801 */       if ((!isInGlobalTx()) && (this.mc.getRollbackOnPooledClose()) && (!getAutoCommit()))
/*     */       {
/* 804 */         rollback();
/*     */       }
/*     */ 
/* 807 */       if (fireClosedEvent) {
/* 808 */         this.mpc.callListener(2, null);
/*     */       }
/*     */ 
/* 817 */       this.closed = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void checkClosed() throws SQLException {
/* 822 */     if (this.closed)
/* 823 */       throw SQLError.createSQLException(this.invalidHandleStr);
/*     */   }
/*     */ 
/*     */   protected boolean isInGlobalTx()
/*     */   {
/* 828 */     return this.mc.isInGlobalTx();
/*     */   }
/*     */ 
/*     */   protected void setInGlobalTx(boolean flag) {
/* 832 */     this.mc.setInGlobalTx(flag);
/*     */   }
/*     */ 
/*     */   public void ping() throws SQLException {
/* 836 */     if (this.mc != null)
/* 837 */       this.mc.ping();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.jdbc2.optional.ConnectionWrapper
 * JD-Core Version:    0.6.0
 */