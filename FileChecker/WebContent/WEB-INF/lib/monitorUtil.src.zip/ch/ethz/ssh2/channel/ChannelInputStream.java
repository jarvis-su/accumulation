/*    */ package ch.ethz.ssh2.channel;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public final class ChannelInputStream extends InputStream
/*    */ {
/*    */   Channel c;
/* 17 */   boolean isClosed = false;
/* 18 */   boolean isEOF = false;
/* 19 */   boolean extendedFlag = false;
/*    */ 
/*    */   ChannelInputStream(Channel c, boolean isExtended)
/*    */   {
/* 23 */     this.c = c;
/* 24 */     this.extendedFlag = isExtended;
/*    */   }
/*    */ 
/*    */   public int available() throws IOException
/*    */   {
/* 29 */     if (this.isEOF) {
/* 30 */       return 0;
/*    */     }
/* 32 */     int avail = this.c.cm.getAvailable(this.c, this.extendedFlag);
/*    */ 
/* 36 */     return avail > 0 ? avail : 0;
/*    */   }
/*    */ 
/*    */   public void close() throws IOException
/*    */   {
/* 41 */     this.isClosed = true;
/*    */   }
/*    */ 
/*    */   public int read(byte[] b, int off, int len) throws IOException
/*    */   {
/* 46 */     if (b == null) {
/* 47 */       throw new NullPointerException();
/*    */     }
/* 49 */     if ((off < 0) || (len < 0) || (off + len > b.length) || (off + len < 0) || (off > b.length)) {
/* 50 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 52 */     if (len == 0) {
/* 53 */       return 0;
/*    */     }
/* 55 */     if (this.isEOF) {
/* 56 */       return -1;
/*    */     }
/* 58 */     int ret = this.c.cm.getChannelData(this.c, this.extendedFlag, b, off, len);
/*    */ 
/* 60 */     if (ret == -1)
/*    */     {
/* 62 */       this.isEOF = true;
/*    */     }
/*    */ 
/* 65 */     return ret;
/*    */   }
/*    */ 
/*    */   public int read(byte[] b) throws IOException
/*    */   {
/* 70 */     return read(b, 0, b.length);
/*    */   }
/*    */ 
/*    */   public int read()
/*    */     throws IOException
/*    */   {
/* 77 */     byte[] b = new byte[1];
/*    */ 
/* 79 */     int ret = read(b, 0, 1);
/*    */ 
/* 81 */     if (ret != 1) {
/* 82 */       return -1;
/*    */     }
/* 84 */     return b[0] & 0xFF;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.ChannelInputStream
 * JD-Core Version:    0.6.0
 */