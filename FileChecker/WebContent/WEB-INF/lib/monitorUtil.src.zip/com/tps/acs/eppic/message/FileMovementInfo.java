/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.Date;
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class FileMovementInfo extends InfoData
/*    */ {
/*    */   private static final long serialVersionUID = -3626815048785547205L;
/*    */   private static final String FILENAME = "FILENAME";
/*    */   private static final String DEST_SERVER = "DEST_SERVER";
/*    */   private static final String SOURCE_SERVER = "SOURCE_SERVER";
/*    */   private static final String STATUS = "STATUS";
/*    */   private static final String TIME = "TIME";
/*    */   private static final String SIZE = "SIZE";
/*    */ 
/*    */   public FileMovementInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FileMovementInfo(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public FileMovementInfo(String filename, String destServer, String sourceServer, String status, Date time, boolean isStart, long size)
/*    */   {
/* 29 */     super(isStart);
/*    */ 
/* 31 */     setData("FILENAME", filename);
/* 32 */     setData("DEST_SERVER", destServer);
/* 33 */     setData("SOURCE_SERVER", sourceServer);
/* 34 */     setData("STATUS", status);
/* 35 */     setData("TIME", time);
/* 36 */     setData("SIZE", Long.valueOf(size));
/*    */   }
/*    */ 
/*    */   public String getFileName()
/*    */   {
/* 41 */     String fileName = "";
/* 42 */     if (getData("FILENAME") != null) {
/* 43 */       fileName = (String)getData("FILENAME");
/*    */     }
/* 45 */     return fileName;
/*    */   }
/*    */ 
/*    */   public String getDestServer() {
/* 49 */     String destServer = "";
/* 50 */     if (getData("DEST_SERVER") != null)
/* 51 */       destServer = (String)getData("DEST_SERVER");
/* 52 */     return destServer;
/*    */   }
/*    */ 
/*    */   public String getSourceServer() {
/* 56 */     String sourceServer = "";
/* 57 */     if (getData("SOURCE_SERVER") != null)
/* 58 */       sourceServer = (String)getData("SOURCE_SERVER");
/* 59 */     return sourceServer;
/*    */   }
/*    */ 
/*    */   public String getStatus() {
/* 63 */     String status = "";
/* 64 */     if (getData("STATUS") != null)
/* 65 */       status = (String)getData("STATUS");
/* 66 */     return status;
/*    */   }
/*    */ 
/*    */   public long getFileSize() {
/* 70 */     long size = 0L;
/* 71 */     if (getData("SIZE") != null)
/* 72 */       size = ((Long)getData("SIZE")).longValue();
/* 73 */     return size;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 77 */     return super.toString() + "  FI: " + getFileName() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.FileMovementInfo
 * JD-Core Version:    0.6.0
 */