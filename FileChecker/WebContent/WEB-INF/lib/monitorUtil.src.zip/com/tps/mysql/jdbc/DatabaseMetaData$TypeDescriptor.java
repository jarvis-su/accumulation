/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.Locale;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ class DatabaseMetaData$TypeDescriptor
/*     */ {
/*     */   int bufferLength;
/*     */   int charOctetLength;
/*     */   int columnSize;
/*     */   short dataType;
/*     */   int decimalDigits;
/*     */   String isNullable;
/*     */   int nullability;
/*     */   int numPrecRadix;
/*     */   String typeName;
/*     */   private final DatabaseMetaData this$0;
/*     */ 
/*     */   DatabaseMetaData$TypeDescriptor(DatabaseMetaData this$0, String typeInfo, String nullabilityInfo)
/*     */     throws SQLException
/*     */   {
/* 186 */     this.this$0 = this$0;
/*     */ 
/* 181 */     this.numPrecRadix = 10;
/*     */ 
/* 187 */     String mysqlType = "";
/* 188 */     String fullMysqlType = null;
/*     */ 
/* 190 */     if (typeInfo.indexOf("(") != -1)
/* 191 */       mysqlType = typeInfo.substring(0, typeInfo.indexOf("("));
/*     */     else {
/* 193 */       mysqlType = typeInfo;
/*     */     }
/*     */ 
/* 196 */     int indexOfUnsignedInMysqlType = StringUtils.indexOfIgnoreCase(mysqlType, "unsigned");
/*     */ 
/* 199 */     if (indexOfUnsignedInMysqlType != -1) {
/* 200 */       mysqlType = mysqlType.substring(0, indexOfUnsignedInMysqlType - 1);
/*     */     }
/*     */ 
/* 207 */     if (StringUtils.indexOfIgnoreCase(typeInfo, "unsigned") != -1)
/* 208 */       fullMysqlType = mysqlType + " unsigned";
/*     */     else {
/* 210 */       fullMysqlType = mysqlType;
/*     */     }
/*     */ 
/* 213 */     if (this$0.conn.getCapitalizeTypeNames()) {
/* 214 */       fullMysqlType = fullMysqlType.toUpperCase(Locale.ENGLISH);
/*     */     }
/*     */ 
/* 217 */     this.dataType = (short)MysqlDefs.mysqlToJavaType(mysqlType);
/*     */ 
/* 219 */     this.typeName = fullMysqlType;
/*     */ 
/* 222 */     if (typeInfo != null) {
/* 223 */       if (StringUtils.startsWithIgnoreCase(typeInfo, "enum")) {
/* 224 */         String temp = typeInfo.substring(typeInfo.indexOf("("), typeInfo.lastIndexOf(")"));
/*     */ 
/* 226 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*     */ 
/* 228 */         int maxLength = 0;
/*     */ 
/* 230 */         while (tokenizer.hasMoreTokens()) {
/* 231 */           maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*     */         }
/*     */ 
/* 235 */         this.columnSize = maxLength;
/* 236 */         this.decimalDigits = 0;
/* 237 */       } else if (StringUtils.startsWithIgnoreCase(typeInfo, "set")) {
/* 238 */         String temp = typeInfo.substring(typeInfo.indexOf("("), typeInfo.lastIndexOf(")"));
/*     */ 
/* 240 */         StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*     */ 
/* 242 */         int maxLength = 0;
/*     */ 
/* 244 */         while (tokenizer.hasMoreTokens()) {
/* 245 */           String setMember = tokenizer.nextToken().trim();
/*     */ 
/* 247 */           if ((setMember.startsWith("'")) && (setMember.endsWith("'")))
/* 248 */             maxLength += setMember.length() - 2;
/*     */           else {
/* 250 */             maxLength += setMember.length();
/*     */           }
/*     */         }
/*     */ 
/* 254 */         this.columnSize = maxLength;
/* 255 */         this.decimalDigits = 0;
/* 256 */       } else if (typeInfo.indexOf(",") != -1)
/*     */       {
/* 258 */         this.columnSize = Integer.parseInt(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")));
/*     */ 
/* 261 */         this.decimalDigits = Integer.parseInt(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")));
/*     */       }
/*     */       else
/*     */       {
/* 265 */         this.columnSize = 0;
/*     */ 
/* 268 */         if (typeInfo.indexOf("(") != -1) {
/* 269 */           int endParenIndex = typeInfo.indexOf(")");
/*     */ 
/* 271 */           if (endParenIndex == -1) {
/* 272 */             endParenIndex = typeInfo.length();
/*     */           }
/*     */ 
/* 275 */           this.columnSize = Integer.parseInt(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex));
/*     */ 
/* 279 */           if ((this$0.conn.getTinyInt1isBit()) && (this.columnSize == 1) && (StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint")))
/*     */           {
/* 283 */             if (this$0.conn.getTransformedBitIsBoolean()) {
/* 284 */               this.dataType = 16;
/* 285 */               this.typeName = "BOOLEAN";
/*     */             } else {
/* 287 */               this.dataType = -7;
/* 288 */               this.typeName = "BIT";
/*     */             }
/*     */           }
/* 291 */         } else if (typeInfo.equalsIgnoreCase("tinyint")) {
/* 292 */           this.columnSize = 1;
/* 293 */         } else if (typeInfo.equalsIgnoreCase("smallint")) {
/* 294 */           this.columnSize = 6;
/* 295 */         } else if (typeInfo.equalsIgnoreCase("mediumint")) {
/* 296 */           this.columnSize = 6;
/* 297 */         } else if (typeInfo.equalsIgnoreCase("int")) {
/* 298 */           this.columnSize = 11;
/* 299 */         } else if (typeInfo.equalsIgnoreCase("integer")) {
/* 300 */           this.columnSize = 11;
/* 301 */         } else if (typeInfo.equalsIgnoreCase("bigint")) {
/* 302 */           this.columnSize = 25;
/* 303 */         } else if (typeInfo.equalsIgnoreCase("int24")) {
/* 304 */           this.columnSize = 25;
/* 305 */         } else if (typeInfo.equalsIgnoreCase("real")) {
/* 306 */           this.columnSize = 12;
/* 307 */         } else if (typeInfo.equalsIgnoreCase("float")) {
/* 308 */           this.columnSize = 12;
/* 309 */         } else if (typeInfo.equalsIgnoreCase("decimal")) {
/* 310 */           this.columnSize = 12;
/* 311 */         } else if (typeInfo.equalsIgnoreCase("numeric")) {
/* 312 */           this.columnSize = 12;
/* 313 */         } else if (typeInfo.equalsIgnoreCase("double")) {
/* 314 */           this.columnSize = 22;
/* 315 */         } else if (typeInfo.equalsIgnoreCase("char")) {
/* 316 */           this.columnSize = 1;
/* 317 */         } else if (typeInfo.equalsIgnoreCase("varchar")) {
/* 318 */           this.columnSize = 255;
/* 319 */         } else if (typeInfo.equalsIgnoreCase("date")) {
/* 320 */           this.columnSize = 10;
/* 321 */         } else if (typeInfo.equalsIgnoreCase("time")) {
/* 322 */           this.columnSize = 8;
/* 323 */         } else if (typeInfo.equalsIgnoreCase("timestamp")) {
/* 324 */           this.columnSize = 19;
/* 325 */         } else if (typeInfo.equalsIgnoreCase("datetime")) {
/* 326 */           this.columnSize = 19;
/* 327 */         } else if (typeInfo.equalsIgnoreCase("tinyblob")) {
/* 328 */           this.columnSize = 255;
/* 329 */         } else if (typeInfo.equalsIgnoreCase("blob")) {
/* 330 */           this.columnSize = 65535;
/* 331 */         } else if (typeInfo.equalsIgnoreCase("mediumblob")) {
/* 332 */           this.columnSize = 16277215;
/* 333 */         } else if (typeInfo.equalsIgnoreCase("longblob")) {
/* 334 */           this.columnSize = 2147483647;
/* 335 */         } else if (typeInfo.equalsIgnoreCase("tinytext")) {
/* 336 */           this.columnSize = 255;
/* 337 */         } else if (typeInfo.equalsIgnoreCase("text")) {
/* 338 */           this.columnSize = 65535;
/* 339 */         } else if (typeInfo.equalsIgnoreCase("mediumtext")) {
/* 340 */           this.columnSize = 16277215;
/* 341 */         } else if (typeInfo.equalsIgnoreCase("longtext")) {
/* 342 */           this.columnSize = 2147483647;
/* 343 */         } else if (typeInfo.equalsIgnoreCase("enum")) {
/* 344 */           this.columnSize = 255;
/* 345 */         } else if (typeInfo.equalsIgnoreCase("set")) {
/* 346 */           this.columnSize = 255;
/*     */         }
/*     */ 
/* 349 */         this.decimalDigits = 0;
/*     */       }
/*     */     } else {
/* 352 */       this.decimalDigits = 0;
/* 353 */       this.columnSize = 0;
/*     */     }
/*     */ 
/* 357 */     this.bufferLength = MysqlIO.getMaxBuf();
/*     */ 
/* 360 */     this.numPrecRadix = 10;
/*     */ 
/* 363 */     if (nullabilityInfo != null) {
/* 364 */       if (nullabilityInfo.equals("YES")) {
/* 365 */         this.nullability = 1;
/* 366 */         this.isNullable = "YES";
/*     */       }
/*     */       else
/*     */       {
/* 370 */         this.nullability = 0;
/* 371 */         this.isNullable = "NO";
/*     */       }
/*     */     } else {
/* 374 */       this.nullability = 0;
/* 375 */       this.isNullable = "NO";
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.TypeDescriptor
 * JD-Core Version:    0.6.0
 */