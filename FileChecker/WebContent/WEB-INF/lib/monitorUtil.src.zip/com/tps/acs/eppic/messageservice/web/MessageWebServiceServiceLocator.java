/*     */ package com.acs.eppic.messageservice.web;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import java.rmi.Remote;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.rpc.ServiceException;
/*     */ import org.apache.axis.AxisFault;
/*     */ import org.apache.axis.EngineConfiguration;
/*     */ import org.apache.axis.client.Service;
/*     */ import org.apache.axis.client.Stub;
/*     */ 
/*     */ public class MessageWebServiceServiceLocator extends Service
/*     */   implements MessageWebServiceService
/*     */ {
/*     */   private static final long serialVersionUID = -905084036038849270L;
/*  30 */   private String MessageWebService_address = "http://localhost:8080/monitor/services/MessageWebService";
/*     */ 
/*  37 */   private String MessageWebServiceWSDDServiceName = "MessageWebService";
/*     */ 
/* 116 */   private HashSet ports = null;
/*     */ 
/*     */   public MessageWebServiceServiceLocator()
/*     */   {
/*     */   }
/*     */ 
/*     */   public MessageWebServiceServiceLocator(EngineConfiguration config)
/*     */   {
/*  22 */     super(config);
/*     */   }
/*     */ 
/*     */   public MessageWebServiceServiceLocator(String wsdlLoc, QName sName) throws ServiceException {
/*  26 */     super(wsdlLoc, sName);
/*     */   }
/*     */ 
/*     */   public String getMessageWebServiceAddress()
/*     */   {
/*  33 */     return this.MessageWebService_address;
/*     */   }
/*     */ 
/*     */   public String getMessageWebServiceWSDDServiceName()
/*     */   {
/*  40 */     return this.MessageWebServiceWSDDServiceName;
/*     */   }
/*     */ 
/*     */   public void setMessageWebServiceWSDDServiceName(String name) {
/*  44 */     this.MessageWebServiceWSDDServiceName = name;
/*     */   }
/*     */ 
/*     */   public MessageWebService getMessageWebService() throws ServiceException
/*     */   {
/*     */     try {
/*  50 */       endpoint = new URL(this.MessageWebService_address);
/*     */     }
/*     */     catch (MalformedURLException e)
/*     */     {
/*     */       URL endpoint;
/*  53 */       throw new ServiceException(e);
/*     */     }
/*     */     URL endpoint;
/*  55 */     return getMessageWebService(endpoint);
/*     */   }
/*     */ 
/*     */   public MessageWebService getMessageWebService(URL portAddress) throws ServiceException {
/*     */     try {
/*  60 */       MessageWebServiceSoapBindingStub _stub = new MessageWebServiceSoapBindingStub(portAddress, this);
/*  61 */       _stub.setPortName(getMessageWebServiceWSDDServiceName());
/*  62 */       return _stub;
/*     */     } catch (AxisFault e) {
/*     */     }
/*  65 */     return null;
/*     */   }
/*     */ 
/*     */   public void setMessageWebServiceEndpointAddress(String address)
/*     */   {
/*  70 */     this.MessageWebService_address = address;
/*     */   }
/*     */ 
/*     */   public Remote getPort(Class serviceEndpointInterface)
/*     */     throws ServiceException
/*     */   {
/*     */     try
/*     */     {
/*  80 */       if (MessageWebService.class.isAssignableFrom(serviceEndpointInterface)) {
/*  81 */         MessageWebServiceSoapBindingStub _stub = new MessageWebServiceSoapBindingStub(new URL(this.MessageWebService_address), this);
/*  82 */         _stub.setPortName(getMessageWebServiceWSDDServiceName());
/*  83 */         return _stub;
/*     */       }
/*     */     }
/*     */     catch (Throwable t) {
/*  87 */       throw new ServiceException(t);
/*     */     }
/*  89 */     throw new ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
/*     */   }
/*     */ 
/*     */   public Remote getPort(QName portName, Class serviceEndpointInterface)
/*     */     throws ServiceException
/*     */   {
/*  98 */     if (portName == null) {
/*  99 */       return getPort(serviceEndpointInterface);
/*     */     }
/* 101 */     String inputPortName = portName.getLocalPart();
/* 102 */     if ("MessageWebService".equals(inputPortName)) {
/* 103 */       return getMessageWebService();
/*     */     }
/*     */ 
/* 106 */     Remote _stub = getPort(serviceEndpointInterface);
/* 107 */     ((Stub)_stub).setPortName(portName);
/* 108 */     return _stub;
/*     */   }
/*     */ 
/*     */   public QName getServiceName()
/*     */   {
/* 113 */     return new QName("urn:MessageWebService", "MessageWebServiceService");
/*     */   }
/*     */ 
/*     */   public Iterator getPorts()
/*     */   {
/* 119 */     if (this.ports == null) {
/* 120 */       this.ports = new HashSet();
/* 121 */       this.ports.add(new QName("urn:MessageWebService", "MessageWebService"));
/*     */     }
/* 123 */     return this.ports.iterator();
/*     */   }
/*     */ 
/*     */   public void setEndpointAddress(String portName, String address)
/*     */     throws ServiceException
/*     */   {
/* 131 */     if ("MessageWebService".equals(portName)) {
/* 132 */       setMessageWebServiceEndpointAddress(address);
/*     */     }
/*     */     else
/*     */     {
/* 136 */       throw new ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setEndpointAddress(QName portName, String address)
/*     */     throws ServiceException
/*     */   {
/* 144 */     setEndpointAddress(portName.getLocalPart(), address);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.web.MessageWebServiceServiceLocator
 * JD-Core Version:    0.6.0
 */