/*     */ package com.mysql.jdbc.log;
/*     */ 
/*     */ import com.mysql.jdbc.Util;
/*     */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*     */ 
/*     */ public class LogUtils
/*     */ {
/*     */   public static final String CALLER_INFORMATION_NOT_AVAILABLE = "Caller information not available";
/*  32 */   private static final String LINE_SEPARATOR = System.getProperty("line.separator");
/*     */ 
/*  35 */   private static final int LINE_SEPARATOR_LENGTH = LINE_SEPARATOR.length();
/*     */ 
/*     */   public static Object expandProfilerEventIfNecessary(Object possibleProfilerEvent)
/*     */   {
/*  40 */     if ((possibleProfilerEvent instanceof ProfilerEvent)) {
/*  41 */       StringBuffer msgBuf = new StringBuffer();
/*     */ 
/*  43 */       ProfilerEvent evt = (ProfilerEvent)possibleProfilerEvent;
/*     */ 
/*  45 */       Throwable locationException = evt.getEventCreationPoint();
/*     */ 
/*  47 */       if (locationException == null) {
/*  48 */         locationException = new Throwable();
/*     */       }
/*     */ 
/*  51 */       msgBuf.append("Profiler Event: [");
/*     */ 
/*  53 */       boolean appendLocationInfo = false;
/*     */ 
/*  55 */       switch (evt.getEventType()) {
/*     */       case 4:
/*  57 */         msgBuf.append("EXECUTE");
/*     */ 
/*  59 */         break;
/*     */       case 5:
/*  62 */         msgBuf.append("FETCH");
/*     */ 
/*  64 */         break;
/*     */       case 1:
/*  67 */         msgBuf.append("CONSTRUCT");
/*     */ 
/*  69 */         break;
/*     */       case 2:
/*  72 */         msgBuf.append("PREPARE");
/*     */ 
/*  74 */         break;
/*     */       case 3:
/*  77 */         msgBuf.append("QUERY");
/*     */ 
/*  79 */         break;
/*     */       case 0:
/*  82 */         msgBuf.append("WARN");
/*  83 */         appendLocationInfo = true;
/*     */ 
/*  85 */         break;
/*     */       default:
/*  88 */         msgBuf.append("UNKNOWN");
/*     */       }
/*     */ 
/*  91 */       msgBuf.append("] ");
/*  92 */       msgBuf.append(findCallingClassAndMethod(locationException));
/*  93 */       msgBuf.append(" duration: ");
/*  94 */       msgBuf.append(evt.getEventDurationMillis());
/*  95 */       msgBuf.append(" ms, connection-id: ");
/*  96 */       msgBuf.append(evt.getConnectionId());
/*  97 */       msgBuf.append(", statement-id: ");
/*  98 */       msgBuf.append(evt.getStatementId());
/*  99 */       msgBuf.append(", resultset-id: ");
/* 100 */       msgBuf.append(evt.getResultSetId());
/*     */ 
/* 102 */       String evtMessage = evt.getMessage();
/*     */ 
/* 104 */       if (evtMessage != null) {
/* 105 */         msgBuf.append(", message: ");
/* 106 */         msgBuf.append(evtMessage);
/*     */       }
/*     */ 
/* 109 */       if (appendLocationInfo) {
/* 110 */         msgBuf.append("\n\nFull stack trace of location where event occurred:\n\n");
/*     */ 
/* 112 */         msgBuf.append(Util.stackTraceToString(locationException));
/* 113 */         msgBuf.append("\n");
/*     */       }
/*     */ 
/* 116 */       return msgBuf;
/*     */     }
/*     */ 
/* 119 */     return possibleProfilerEvent;
/*     */   }
/*     */ 
/*     */   public static String findCallingClassAndMethod(Throwable t)
/*     */   {
/* 124 */     String stackTraceAsString = Util.stackTraceToString(t);
/*     */ 
/* 126 */     String callingClassAndMethod = "Caller information not available";
/*     */ 
/* 128 */     int endInternalMethods = stackTraceAsString.lastIndexOf("com.mysql.jdbc");
/*     */ 
/* 131 */     if (endInternalMethods != -1) {
/* 132 */       int endOfLine = -1;
/* 133 */       int compliancePackage = stackTraceAsString.indexOf("com.mysql.jdbc.compliance", endInternalMethods);
/*     */ 
/* 136 */       if (compliancePackage != -1)
/* 137 */         endOfLine = compliancePackage - LINE_SEPARATOR_LENGTH;
/*     */       else {
/* 139 */         endOfLine = stackTraceAsString.indexOf(LINE_SEPARATOR, endInternalMethods);
/*     */       }
/*     */ 
/* 143 */       if (endOfLine != -1) {
/* 144 */         int nextEndOfLine = stackTraceAsString.indexOf(LINE_SEPARATOR, endOfLine + LINE_SEPARATOR_LENGTH);
/*     */ 
/* 147 */         if (nextEndOfLine != -1) {
/* 148 */           callingClassAndMethod = stackTraceAsString.substring(endOfLine + LINE_SEPARATOR_LENGTH, nextEndOfLine);
/*     */         }
/*     */         else {
/* 151 */           callingClassAndMethod = stackTraceAsString.substring(endOfLine + LINE_SEPARATOR_LENGTH);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 157 */     if ((!callingClassAndMethod.startsWith("\tat ")) && (!callingClassAndMethod.startsWith("at ")))
/*     */     {
/* 159 */       return "at " + callingClassAndMethod;
/*     */     }
/*     */ 
/* 162 */     return callingClassAndMethod;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.log.LogUtils
 * JD-Core Version:    0.6.0
 */