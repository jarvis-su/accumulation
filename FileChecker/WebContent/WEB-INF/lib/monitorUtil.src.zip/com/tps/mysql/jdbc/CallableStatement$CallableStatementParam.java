/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ class CallableStatement$CallableStatementParam
/*     */ {
/*     */   int desiredJdbcType;
/*     */   int index;
/*     */   int inOutModifier;
/*     */   boolean isIn;
/*     */   boolean isOut;
/*     */   int jdbcType;
/*     */   short nullability;
/*     */   String paramName;
/*     */   int precision;
/*     */   int scale;
/*     */   String typeName;
/*     */   private final CallableStatement this$0;
/*     */ 
/*     */   CallableStatement$CallableStatementParam(CallableStatement this$0, String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier)
/*     */   {
/*  86 */     this.this$0 = this$0;
/*  87 */     this.paramName = name;
/*  88 */     this.isIn = in;
/*  89 */     this.isOut = out;
/*  90 */     this.index = idx;
/*     */ 
/*  92 */     this.jdbcType = jdbcType;
/*  93 */     this.typeName = typeName;
/*  94 */     this.precision = precision;
/*  95 */     this.scale = scale;
/*  96 */     this.nullability = nullability;
/*  97 */     this.inOutModifier = inOutModifier;
/*     */   }
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 106 */     return super.clone();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CallableStatement.CallableStatementParam
 * JD-Core Version:    0.6.0
 */