package ch.ethz.ssh2.transport;

import java.io.IOException;

public abstract interface MessageHandler
{
  public abstract void handleMessage(byte[] paramArrayOfByte, int paramInt)
    throws IOException;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.MessageHandler
 * JD-Core Version:    0.6.0
 */