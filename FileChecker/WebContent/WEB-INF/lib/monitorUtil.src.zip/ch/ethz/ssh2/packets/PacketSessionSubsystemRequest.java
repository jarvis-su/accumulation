/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketSessionSubsystemRequest
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public boolean wantReply;
/*    */   public String subsystem;
/*    */ 
/*    */   public PacketSessionSubsystemRequest(int recipientChannelID, boolean wantReply, String subsystem)
/*    */   {
/* 20 */     this.recipientChannelID = recipientChannelID;
/* 21 */     this.wantReply = wantReply;
/* 22 */     this.subsystem = subsystem;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 27 */     if (this.payload == null)
/*    */     {
/* 29 */       TypesWriter tw = new TypesWriter();
/* 30 */       tw.writeByte(98);
/* 31 */       tw.writeUINT32(this.recipientChannelID);
/* 32 */       tw.writeString("subsystem");
/* 33 */       tw.writeBoolean(this.wantReply);
/* 34 */       tw.writeString(this.subsystem);
/* 35 */       this.payload = tw.getBytes();
/* 36 */       tw.getBytes(this.payload);
/*    */     }
/* 38 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketSessionSubsystemRequest
 * JD-Core Version:    0.6.0
 */