package com.ibm.wsdl.factory;

import com.ibm.wsdl.DefinitionImpl;
import com.ibm.wsdl.extensions.PopulatedExtensionRegistry;
import com.ibm.wsdl.xml.WSDLReaderImpl;
import com.ibm.wsdl.xml.WSDLWriterImpl;
import javax.wsdl.Definition;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;

public class WSDLFactoryImpl extends WSDLFactory
{
  public Definition newDefinition()
  {
    DefinitionImpl localDefinitionImpl = new DefinitionImpl();
    ExtensionRegistry localExtensionRegistry = newPopulatedExtensionRegistry();
    localDefinitionImpl.setExtensionRegistry(localExtensionRegistry);
    return localDefinitionImpl;
  }

  public WSDLReader newWSDLReader()
  {
    return new WSDLReaderImpl();
  }

  public WSDLWriter newWSDLWriter()
  {
    return new WSDLWriterImpl();
  }

  public ExtensionRegistry newPopulatedExtensionRegistry()
  {
    return new PopulatedExtensionRegistry();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.factory.WSDLFactoryImpl
 * JD-Core Version:    0.6.0
 */