/*     */ package ch.ethz.ssh2.signature;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.SimpleDERReader;
/*     */ import ch.ethz.ssh2.crypto.digest.SHA1;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import ch.ethz.ssh2.packets.TypesReader;
/*     */ import ch.ethz.ssh2.packets.TypesWriter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class RSASHA1Verify
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(RSASHA1Verify.class);
/*     */ 
/*     */   public static RSAPublicKey decodeSSHRSAPublicKey(byte[] key) throws IOException
/*     */   {
/*  25 */     TypesReader tr = new TypesReader(key);
/*     */ 
/*  27 */     String key_format = tr.readString();
/*     */ 
/*  29 */     if (!key_format.equals("ssh-rsa")) {
/*  30 */       throw new IllegalArgumentException("This is not a ssh-rsa public key");
/*     */     }
/*  32 */     BigInteger e = tr.readMPINT();
/*  33 */     BigInteger n = tr.readMPINT();
/*     */ 
/*  35 */     if (tr.remain() != 0) {
/*  36 */       throw new IOException("Padding in RSA public key!");
/*     */     }
/*  38 */     return new RSAPublicKey(e, n);
/*     */   }
/*     */ 
/*     */   public static byte[] encodeSSHRSAPublicKey(RSAPublicKey pk) throws IOException
/*     */   {
/*  43 */     TypesWriter tw = new TypesWriter();
/*     */ 
/*  45 */     tw.writeString("ssh-rsa");
/*  46 */     tw.writeMPInt(pk.getE());
/*  47 */     tw.writeMPInt(pk.getN());
/*     */ 
/*  49 */     return tw.getBytes();
/*     */   }
/*     */ 
/*     */   public static RSASignature decodeSSHRSASignature(byte[] sig) throws IOException
/*     */   {
/*  54 */     TypesReader tr = new TypesReader(sig);
/*     */ 
/*  56 */     String sig_format = tr.readString();
/*     */ 
/*  58 */     if (!sig_format.equals("ssh-rsa")) {
/*  59 */       throw new IOException("Peer sent wrong signature format");
/*     */     }
/*     */ 
/*  66 */     byte[] s = tr.readByteString();
/*     */ 
/*  68 */     if (s.length == 0) {
/*  69 */       throw new IOException("Error in RSA signature, S is empty.");
/*     */     }
/*  71 */     if (log.isEnabled())
/*     */     {
/*  73 */       log.log(80, "Decoding ssh-rsa signature string (length: " + s.length + ")");
/*     */     }
/*     */ 
/*  76 */     if (tr.remain() != 0) {
/*  77 */       throw new IOException("Padding in RSA signature!");
/*     */     }
/*  79 */     return new RSASignature(new BigInteger(1, s));
/*     */   }
/*     */ 
/*     */   public static byte[] encodeSSHRSASignature(RSASignature sig) throws IOException
/*     */   {
/*  84 */     TypesWriter tw = new TypesWriter();
/*     */ 
/*  86 */     tw.writeString("ssh-rsa");
/*     */ 
/*  93 */     byte[] s = sig.getS().toByteArray();
/*     */ 
/*  97 */     if ((s.length > 1) && (s[0] == 0))
/*  98 */       tw.writeString(s, 1, s.length - 1);
/*     */     else {
/* 100 */       tw.writeString(s, 0, s.length);
/*     */     }
/* 102 */     return tw.getBytes();
/*     */   }
/*     */ 
/*     */   public static RSASignature generateSignature(byte[] message, RSAPrivateKey pk) throws IOException
/*     */   {
/* 107 */     SHA1 md = new SHA1();
/* 108 */     md.update(message);
/* 109 */     byte[] sha_message = new byte[md.getDigestLength()];
/* 110 */     md.digest(sha_message);
/*     */ 
/* 112 */     byte[] der_header = { 48, 33, 48, 9, 6, 5, 43, 14, 3, 2, 26, 5, 
/* 113 */       0, 4, 20 };
/*     */ 
/* 115 */     int rsa_block_len = (pk.getN().bitLength() + 7) / 8;
/*     */ 
/* 117 */     int num_pad = rsa_block_len - (2 + der_header.length + sha_message.length) - 1;
/*     */ 
/* 119 */     if (num_pad < 8) {
/* 120 */       throw new IOException("Cannot sign with RSA, message too long");
/*     */     }
/* 122 */     byte[] sig = new byte[der_header.length + sha_message.length + 2 + num_pad];
/*     */ 
/* 124 */     sig[0] = 1;
/*     */ 
/* 126 */     for (int i = 0; i < num_pad; i++)
/*     */     {
/* 128 */       sig[(i + 1)] = -1;
/*     */     }
/*     */ 
/* 131 */     sig[(num_pad + 1)] = 0;
/*     */ 
/* 133 */     System.arraycopy(der_header, 0, sig, 2 + num_pad, der_header.length);
/* 134 */     System.arraycopy(sha_message, 0, sig, 2 + num_pad + der_header.length, sha_message.length);
/*     */ 
/* 136 */     BigInteger m = new BigInteger(1, sig);
/*     */ 
/* 138 */     BigInteger s = m.modPow(pk.getD(), pk.getN());
/*     */ 
/* 140 */     return new RSASignature(s);
/*     */   }
/*     */ 
/*     */   public static boolean verifySignature(byte[] message, RSASignature ds, RSAPublicKey dpk) throws IOException
/*     */   {
/* 145 */     SHA1 md = new SHA1();
/* 146 */     md.update(message);
/* 147 */     byte[] sha_message = new byte[md.getDigestLength()];
/* 148 */     md.digest(sha_message);
/*     */ 
/* 150 */     BigInteger n = dpk.getN();
/* 151 */     BigInteger e = dpk.getE();
/* 152 */     BigInteger s = ds.getS();
/*     */ 
/* 154 */     if (n.compareTo(s) <= 0)
/*     */     {
/* 156 */       log.log(20, "ssh-rsa signature: n.compareTo(s) <= 0");
/* 157 */       return false;
/*     */     }
/*     */ 
/* 160 */     int rsa_block_len = (n.bitLength() + 7) / 8;
/*     */ 
/* 164 */     if (rsa_block_len < 1)
/*     */     {
/* 166 */       log.log(20, "ssh-rsa signature: rsa_block_len < 1");
/* 167 */       return false;
/*     */     }
/*     */ 
/* 170 */     byte[] v = s.modPow(e, n).toByteArray();
/*     */ 
/* 172 */     int startpos = 0;
/*     */ 
/* 174 */     if ((v.length > 0) && (v[0] == 0)) {
/* 175 */       startpos++;
/*     */     }
/* 177 */     if (v.length - startpos != rsa_block_len - 1)
/*     */     {
/* 179 */       log.log(20, "ssh-rsa signature: (v.length - startpos) != (rsa_block_len - 1)");
/* 180 */       return false;
/*     */     }
/*     */ 
/* 183 */     if (v[startpos] != 1)
/*     */     {
/* 185 */       log.log(20, "ssh-rsa signature: v[startpos] != 0x01");
/* 186 */       return false;
/*     */     }
/*     */ 
/* 189 */     int pos = startpos + 1;
/*     */     while (true)
/*     */     {
/* 193 */       if (pos >= v.length)
/*     */       {
/* 195 */         log.log(20, "ssh-rsa signature: pos >= v.length");
/* 196 */         return false;
/*     */       }
/* 198 */       if (v[pos] == 0)
/*     */         break;
/* 200 */       if (v[pos] != -1)
/*     */       {
/* 202 */         log.log(20, "ssh-rsa signature: v[pos] != (byte) 0xff");
/* 203 */         return false;
/*     */       }
/* 205 */       pos++;
/*     */     }
/*     */ 
/* 208 */     int num_pad = pos - (startpos + 1);
/*     */ 
/* 210 */     if (num_pad < 8)
/*     */     {
/* 212 */       log.log(20, "ssh-rsa signature: num_pad < 8");
/* 213 */       return false;
/*     */     }
/*     */ 
/* 216 */     pos++;
/*     */ 
/* 218 */     if (pos >= v.length)
/*     */     {
/* 220 */       log.log(20, "ssh-rsa signature: pos >= v.length");
/* 221 */       return false;
/*     */     }
/*     */ 
/* 224 */     SimpleDERReader dr = new SimpleDERReader(v, pos, v.length - pos);
/*     */ 
/* 226 */     byte[] seq = dr.readSequenceAsByteArray();
/*     */ 
/* 228 */     if (dr.available() != 0)
/*     */     {
/* 230 */       log.log(20, "ssh-rsa signature: dr.available() != 0");
/* 231 */       return false;
/*     */     }
/*     */ 
/* 234 */     dr.resetInput(seq);
/*     */ 
/* 238 */     byte[] digestAlgorithm = dr.readSequenceAsByteArray();
/*     */ 
/* 242 */     if ((digestAlgorithm.length < 8) || (digestAlgorithm.length > 9))
/*     */     {
/* 244 */       log.log(20, "ssh-rsa signature: (digestAlgorithm.length < 8) || (digestAlgorithm.length > 9)");
/* 245 */       return false;
/*     */     }
/*     */ 
/* 248 */     byte[] digestAlgorithm_sha1 = { 6, 5, 43, 14, 3, 2, 26, 5 };
/*     */ 
/* 250 */     for (int i = 0; i < digestAlgorithm.length; i++)
/*     */     {
/* 252 */       if (digestAlgorithm[i] == digestAlgorithm_sha1[i])
/*     */         continue;
/* 254 */       log.log(20, "ssh-rsa signature: digestAlgorithm[i] != digestAlgorithm_sha1[i]");
/* 255 */       return false;
/*     */     }
/*     */ 
/* 259 */     byte[] digest = dr.readOctetString();
/*     */ 
/* 261 */     if (dr.available() != 0)
/*     */     {
/* 263 */       log.log(20, "ssh-rsa signature: dr.available() != 0 (II)");
/* 264 */       return false;
/*     */     }
/*     */ 
/* 267 */     if (digest.length != sha_message.length)
/*     */     {
/* 269 */       log.log(20, "ssh-rsa signature: digest.length != sha_message.length");
/* 270 */       return false;
/*     */     }
/*     */ 
/* 273 */     for (int i = 0; i < sha_message.length; i++)
/*     */     {
/* 275 */       if (sha_message[i] == digest[i])
/*     */         continue;
/* 277 */       log.log(20, "ssh-rsa signature: sha_message[i] != digest[i]");
/* 278 */       return false;
/*     */     }
/*     */ 
/* 282 */     return true;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.RSASHA1Verify
 * JD-Core Version:    0.6.0
 */