/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ 
/*     */ public class Field
/*     */ {
/*     */   private static final int AUTO_INCREMENT_FLAG = 512;
/*     */   private static final int NO_CHARSET_INFO = -1;
/*     */   private byte[] buffer;
/*  50 */   private int charsetIndex = 0;
/*     */ 
/*  52 */   private String charsetName = null;
/*     */   private int colDecimals;
/*     */   private short colFlag;
/*  58 */   private String collationName = null;
/*     */ 
/*  60 */   private Connection connection = null;
/*     */ 
/*  62 */   private String databaseName = null;
/*     */ 
/*  64 */   private int databaseNameLength = -1;
/*     */ 
/*  67 */   private int databaseNameStart = -1;
/*     */ 
/*  69 */   private int defaultValueLength = -1;
/*     */ 
/*  72 */   private int defaultValueStart = -1;
/*     */ 
/*  74 */   private String fullName = null;
/*     */ 
/*  76 */   private String fullOriginalName = null;
/*     */ 
/*  78 */   private boolean isImplicitTempTable = false;
/*     */   private long length;
/*  82 */   private int mysqlType = -1;
/*     */   private String name;
/*     */   private int nameLength;
/*     */   private int nameStart;
/*  90 */   private String originalColumnName = null;
/*     */ 
/*  92 */   private int originalColumnNameLength = -1;
/*     */ 
/*  95 */   private int originalColumnNameStart = -1;
/*     */ 
/*  97 */   private String originalTableName = null;
/*     */ 
/*  99 */   private int originalTableNameLength = -1;
/*     */ 
/* 102 */   private int originalTableNameStart = -1;
/*     */ 
/* 104 */   private int precisionAdjustFactor = 0;
/*     */ 
/* 106 */   private int sqlType = -1;
/*     */   private String tableName;
/*     */   private int tableNameLength;
/*     */   private int tableNameStart;
/* 114 */   private boolean useOldNameMetadata = false;
/*     */   private boolean isSingleBit;
/*     */ 
/*     */   Field(Connection conn, byte[] buffer, int databaseNameStart, int databaseNameLength, int tableNameStart, int tableNameLength, int originalTableNameStart, int originalTableNameLength, int nameStart, int nameLength, int originalColumnNameStart, int originalColumnNameLength, long length, int mysqlType, short colFlag, int colDecimals, int defaultValueStart, int defaultValueLength, int charsetIndex)
/*     */     throws SQLException
/*     */   {
/* 131 */     this.connection = conn;
/* 132 */     this.buffer = buffer;
/* 133 */     this.nameStart = nameStart;
/* 134 */     this.nameLength = nameLength;
/* 135 */     this.tableNameStart = tableNameStart;
/* 136 */     this.tableNameLength = tableNameLength;
/* 137 */     this.length = length;
/* 138 */     this.colFlag = colFlag;
/* 139 */     this.colDecimals = colDecimals;
/* 140 */     this.mysqlType = mysqlType;
/*     */ 
/* 143 */     this.databaseNameStart = databaseNameStart;
/* 144 */     this.databaseNameLength = databaseNameLength;
/*     */ 
/* 146 */     this.originalTableNameStart = originalTableNameStart;
/* 147 */     this.originalTableNameLength = originalTableNameLength;
/*     */ 
/* 149 */     this.originalColumnNameStart = originalColumnNameStart;
/* 150 */     this.originalColumnNameLength = originalColumnNameLength;
/*     */ 
/* 152 */     this.defaultValueStart = defaultValueStart;
/* 153 */     this.defaultValueLength = defaultValueLength;
/*     */ 
/* 157 */     this.charsetIndex = charsetIndex;
/*     */ 
/* 161 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */ 
/* 165 */     if (this.mysqlType == 252) {
/* 166 */       if ((this.charsetIndex == 63) || (!this.connection.versionMeetsMinimum(4, 1, 0)))
/*     */       {
/* 168 */         setBlobTypeBasedOnLength();
/* 169 */         this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */       }
/*     */       else {
/* 172 */         this.mysqlType = 253;
/* 173 */         this.sqlType = -1;
/*     */       }
/*     */     }
/*     */ 
/* 177 */     if ((this.sqlType == -6) && (this.length == 1L) && (this.connection.getTinyInt1isBit()))
/*     */     {
/* 180 */       if (conn.getTinyInt1isBit()) {
/* 181 */         if (conn.getTransformedBitIsBoolean())
/* 182 */           this.sqlType = 16;
/*     */         else {
/* 184 */           this.sqlType = -7;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 190 */     if ((!isNativeNumericType()) && (!isNativeDateTimeType())) {
/* 191 */       this.charsetName = this.connection.getCharsetNameForIndex(this.charsetIndex);
/*     */ 
/* 198 */       boolean isBinary = isBinary();
/*     */ 
/* 200 */       if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (this.mysqlType == 253) && (isBinary) && (this.charsetIndex == 63))
/*     */       {
/* 204 */         if (isOpaqueBinary()) {
/* 205 */           this.sqlType = -3;
/*     */         }
/*     */       }
/*     */ 
/* 209 */       if ((this.connection.versionMeetsMinimum(4, 1, 0)) && (this.mysqlType == 254) && (isBinary) && (this.charsetIndex == 63))
/*     */       {
/* 219 */         if (isOpaqueBinary()) {
/* 220 */           this.sqlType = -2;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 226 */       if (this.mysqlType == 16) {
/* 227 */         this.isSingleBit = (this.length == 0L);
/*     */ 
/* 229 */         if ((this.connection != null) && ((this.connection.versionMeetsMinimum(5, 0, 21)) || (this.connection.versionMeetsMinimum(5, 1, 10))) && (this.length == 1L))
/*     */         {
/* 231 */           this.isSingleBit = true;
/*     */         }
/*     */ 
/* 234 */         if (this.isSingleBit) {
/* 235 */           this.sqlType = -7;
/*     */         } else {
/* 237 */           this.sqlType = -3;
/* 238 */           this.colFlag = (short)(this.colFlag | 0x80);
/* 239 */           this.colFlag = (short)(this.colFlag | 0x10);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 246 */       if ((this.sqlType == -4) && (!isBinary))
/* 247 */         this.sqlType = -1;
/* 248 */       else if ((this.sqlType == -3) && (!isBinary)) {
/* 249 */         this.sqlType = 12;
/*     */       }
/*     */ 
/* 252 */       checkForImplicitTemporaryTable();
/*     */     } else {
/* 254 */       this.charsetName = "US-ASCII";
/*     */     }
/*     */ 
/* 260 */     if (!isUnsigned()) {
/* 261 */       switch (this.mysqlType) {
/*     */       case 0:
/*     */       case 246:
/* 264 */         this.precisionAdjustFactor = -1;
/*     */ 
/* 266 */         break;
/*     */       case 4:
/*     */       case 5:
/* 269 */         this.precisionAdjustFactor = 1;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 274 */       switch (this.mysqlType) {
/*     */       case 4:
/*     */       case 5:
/* 277 */         this.precisionAdjustFactor = 1;
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   Field(Connection conn, byte[] buffer, int nameStart, int nameLength, int tableNameStart, int tableNameLength, int length, int mysqlType, short colFlag, int colDecimals)
/*     */     throws SQLException
/*     */   {
/* 290 */     this(conn, buffer, -1, -1, tableNameStart, tableNameLength, -1, -1, nameStart, nameLength, -1, -1, length, mysqlType, colFlag, colDecimals, -1, -1, -1);
/*     */   }
/*     */ 
/*     */   Field(String tableName, String columnName, int jdbcType, int length)
/*     */   {
/* 299 */     this.tableName = tableName;
/* 300 */     this.name = columnName;
/* 301 */     this.length = length;
/* 302 */     this.sqlType = jdbcType;
/* 303 */     this.colFlag = 0;
/* 304 */     this.colDecimals = 0;
/*     */   }
/*     */ 
/*     */   private void checkForImplicitTemporaryTable()
/*     */   {
/* 311 */     this.isImplicitTempTable = ((this.tableNameLength > 5) && (this.buffer[this.tableNameStart] == 35) && (this.buffer[(this.tableNameStart + 1)] == 115) && (this.buffer[(this.tableNameStart + 2)] == 113) && (this.buffer[(this.tableNameStart + 3)] == 108) && (this.buffer[(this.tableNameStart + 4)] == 95));
/*     */   }
/*     */ 
/*     */   public String getCharacterSet()
/*     */     throws SQLException
/*     */   {
/* 325 */     return this.charsetName;
/*     */   }
/*     */ 
/*     */   public synchronized String getCollation() throws SQLException {
/* 329 */     if ((this.collationName == null) && 
/* 330 */       (this.connection != null) && 
/* 331 */       (this.connection.versionMeetsMinimum(4, 1, 0))) {
/* 332 */       DatabaseMetaData dbmd = this.connection.getMetaData();
/*     */ 
/* 335 */       String quotedIdStr = dbmd.getIdentifierQuoteString();
/*     */ 
/* 337 */       if (" ".equals(quotedIdStr)) {
/* 338 */         quotedIdStr = "";
/*     */       }
/*     */ 
/* 341 */       String csCatalogName = getDatabaseName();
/* 342 */       String csTableName = getOriginalTableName();
/* 343 */       String csColumnName = getOriginalName();
/*     */ 
/* 345 */       if ((csCatalogName != null) && (csCatalogName.length() != 0) && (csTableName != null) && (csTableName.length() != 0) && (csColumnName != null) && (csColumnName.length() != 0))
/*     */       {
/* 349 */         StringBuffer queryBuf = new StringBuffer(csCatalogName.length() + csTableName.length() + 28);
/*     */ 
/* 352 */         queryBuf.append("SHOW FULL COLUMNS FROM ");
/* 353 */         queryBuf.append(quotedIdStr);
/* 354 */         queryBuf.append(csCatalogName);
/* 355 */         queryBuf.append(quotedIdStr);
/* 356 */         queryBuf.append(".");
/* 357 */         queryBuf.append(quotedIdStr);
/* 358 */         queryBuf.append(csTableName);
/* 359 */         queryBuf.append(quotedIdStr);
/*     */ 
/* 361 */         Statement collationStmt = null;
/* 362 */         ResultSet collationRs = null;
/*     */         try
/*     */         {
/* 365 */           collationStmt = this.connection.createStatement();
/*     */ 
/* 367 */           collationRs = collationStmt.executeQuery(queryBuf.toString());
/*     */ 
/* 370 */           while (collationRs.next()) {
/* 371 */             if (!csColumnName.equals(collationRs.getString("Field")))
/*     */               continue;
/* 373 */             this.collationName = collationRs.getString("Collation");
/*     */           }
/*     */ 
/*     */         }
/*     */         finally
/*     */         {
/* 380 */           if (collationRs != null) {
/* 381 */             collationRs.close();
/* 382 */             collationRs = null;
/*     */           }
/*     */ 
/* 385 */           if (collationStmt != null) {
/* 386 */             collationStmt.close();
/* 387 */             collationStmt = null;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 398 */     return this.collationName;
/*     */   }
/*     */ 
/*     */   public String getColumnLabel() throws SQLException {
/* 402 */     return getName();
/*     */   }
/*     */ 
/*     */   public String getDatabaseName()
/*     */     throws SQLException
/*     */   {
/* 411 */     if ((this.databaseName == null) && (this.databaseNameStart != -1) && (this.databaseNameLength != -1))
/*     */     {
/* 413 */       this.databaseName = getStringFromBytes(this.databaseNameStart, this.databaseNameLength);
/*     */     }
/*     */ 
/* 417 */     return this.databaseName;
/*     */   }
/*     */ 
/*     */   int getDecimals() {
/* 421 */     return this.colDecimals;
/*     */   }
/*     */ 
/*     */   public String getFullName()
/*     */     throws SQLException
/*     */   {
/* 430 */     if (this.fullName == null) {
/* 431 */       StringBuffer fullNameBuf = new StringBuffer(getTableName().length() + 1 + getName().length());
/*     */ 
/* 433 */       fullNameBuf.append(this.tableName);
/*     */ 
/* 436 */       fullNameBuf.append('.');
/* 437 */       fullNameBuf.append(this.name);
/* 438 */       this.fullName = fullNameBuf.toString();
/* 439 */       fullNameBuf = null;
/*     */     }
/*     */ 
/* 442 */     return this.fullName;
/*     */   }
/*     */ 
/*     */   public String getFullOriginalName()
/*     */     throws SQLException
/*     */   {
/* 451 */     getOriginalName();
/*     */ 
/* 453 */     if (this.originalColumnName == null) {
/* 454 */       return null;
/*     */     }
/*     */ 
/* 457 */     if (this.fullName == null) {
/* 458 */       StringBuffer fullOriginalNameBuf = new StringBuffer(getOriginalTableName().length() + 1 + getOriginalName().length());
/*     */ 
/* 461 */       fullOriginalNameBuf.append(this.originalTableName);
/*     */ 
/* 464 */       fullOriginalNameBuf.append('.');
/* 465 */       fullOriginalNameBuf.append(this.originalColumnName);
/* 466 */       this.fullOriginalName = fullOriginalNameBuf.toString();
/* 467 */       fullOriginalNameBuf = null;
/*     */     }
/*     */ 
/* 470 */     return this.fullOriginalName;
/*     */   }
/*     */ 
/*     */   public long getLength()
/*     */   {
/* 479 */     return this.length;
/*     */   }
/*     */ 
/*     */   public int getMaxBytesPerCharacter() throws SQLException {
/* 483 */     return this.connection.getMaxBytesPerChar(getCharacterSet());
/*     */   }
/*     */ 
/*     */   public int getMysqlType()
/*     */   {
/* 492 */     return this.mysqlType;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */     throws SQLException
/*     */   {
/* 501 */     if (this.name == null) {
/* 502 */       this.name = getStringFromBytes(this.nameStart, this.nameLength);
/*     */     }
/*     */ 
/* 505 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String getNameNoAliases() throws SQLException {
/* 509 */     if (this.useOldNameMetadata) {
/* 510 */       return getName();
/*     */     }
/*     */ 
/* 513 */     if ((this.connection != null) && (this.connection.versionMeetsMinimum(4, 1, 0)))
/*     */     {
/* 515 */       return getOriginalName();
/*     */     }
/*     */ 
/* 518 */     return getName();
/*     */   }
/*     */ 
/*     */   public String getOriginalName()
/*     */     throws SQLException
/*     */   {
/* 527 */     if ((this.originalColumnName == null) && (this.originalColumnNameStart != -1) && (this.originalColumnNameLength != -1))
/*     */     {
/* 530 */       this.originalColumnName = getStringFromBytes(this.originalColumnNameStart, this.originalColumnNameLength);
/*     */     }
/*     */ 
/* 534 */     return this.originalColumnName;
/*     */   }
/*     */ 
/*     */   public String getOriginalTableName()
/*     */     throws SQLException
/*     */   {
/* 543 */     if ((this.originalTableName == null) && (this.originalTableNameStart != -1) && (this.originalTableNameLength != -1))
/*     */     {
/* 546 */       this.originalTableName = getStringFromBytes(this.originalTableNameStart, this.originalTableNameLength);
/*     */     }
/*     */ 
/* 550 */     return this.originalTableName;
/*     */   }
/*     */ 
/*     */   public int getPrecisionAdjustFactor()
/*     */   {
/* 562 */     return this.precisionAdjustFactor;
/*     */   }
/*     */ 
/*     */   public int getSQLType()
/*     */   {
/* 571 */     return this.sqlType;
/*     */   }
/*     */ 
/*     */   private String getStringFromBytes(int stringStart, int stringLength)
/*     */     throws SQLException
/*     */   {
/* 580 */     if ((stringStart == -1) || (stringLength == -1)) {
/* 581 */       return null;
/*     */     }
/*     */ 
/* 584 */     String stringVal = null;
/*     */ 
/* 586 */     if (this.connection != null) {
/* 587 */       if (this.connection.getUseUnicode()) {
/* 588 */         String encoding = this.connection.getCharacterSetMetadata();
/*     */ 
/* 590 */         if (encoding == null) {
/* 591 */           encoding = this.connection.getEncoding();
/*     */         }
/*     */ 
/* 594 */         if (encoding != null) {
/* 595 */           SingleByteCharsetConverter converter = null;
/*     */ 
/* 597 */           if (this.connection != null) {
/* 598 */             converter = this.connection.getCharsetConverter(encoding);
/*     */           }
/*     */ 
/* 602 */           if (converter != null) {
/* 603 */             stringVal = converter.toString(this.buffer, stringStart, stringLength);
/*     */           }
/*     */           else
/*     */           {
/* 607 */             byte[] stringBytes = new byte[stringLength];
/*     */ 
/* 609 */             int endIndex = stringStart + stringLength;
/* 610 */             int pos = 0;
/*     */ 
/* 612 */             for (int i = stringStart; i < endIndex; i++) {
/* 613 */               stringBytes[(pos++)] = this.buffer[i];
/*     */             }
/*     */             try
/*     */             {
/* 617 */               stringVal = new String(stringBytes, encoding);
/*     */             } catch (UnsupportedEncodingException ue) {
/* 619 */               throw new RuntimeException(Messages.getString("Field.12") + encoding + Messages.getString("Field.13"));
/*     */             }
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/* 626 */           stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 631 */         stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 636 */       stringVal = StringUtils.toAsciiString(this.buffer, stringStart, stringLength);
/*     */     }
/*     */ 
/* 640 */     return stringVal;
/*     */   }
/*     */ 
/*     */   public String getTable()
/*     */     throws SQLException
/*     */   {
/* 649 */     return getTableName();
/*     */   }
/*     */ 
/*     */   public String getTableName()
/*     */     throws SQLException
/*     */   {
/* 658 */     if (this.tableName == null) {
/* 659 */       this.tableName = getStringFromBytes(this.tableNameStart, this.tableNameLength);
/*     */     }
/*     */ 
/* 663 */     return this.tableName;
/*     */   }
/*     */ 
/*     */   public String getTableNameNoAliases() throws SQLException {
/* 667 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 668 */       return getOriginalTableName();
/*     */     }
/*     */ 
/* 671 */     return getTableName();
/*     */   }
/*     */ 
/*     */   public boolean isAutoIncrement()
/*     */   {
/* 680 */     return (this.colFlag & 0x200) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isBinary()
/*     */   {
/* 689 */     return (this.colFlag & 0x80) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isBlob()
/*     */   {
/* 698 */     return (this.colFlag & 0x10) > 0;
/*     */   }
/*     */ 
/*     */   private boolean isImplicitTemporaryTable()
/*     */   {
/* 707 */     return this.isImplicitTempTable;
/*     */   }
/*     */ 
/*     */   public boolean isMultipleKey()
/*     */   {
/* 716 */     return (this.colFlag & 0x8) > 0;
/*     */   }
/*     */ 
/*     */   boolean isNotNull() {
/* 720 */     return (this.colFlag & 0x1) > 0;
/*     */   }
/*     */ 
/*     */   boolean isOpaqueBinary()
/*     */     throws SQLException
/*     */   {
/* 730 */     if ((this.charsetIndex == 63) && (isBinary()) && ((getMysqlType() == 254) || (getMysqlType() == 253)))
/*     */     {
/* 734 */       if (this.originalTableNameLength == 0) {
/* 735 */         return false;
/*     */       }
/*     */ 
/* 741 */       return !isImplicitTemporaryTable();
/*     */     }
/*     */ 
/* 744 */     return (this.connection.versionMeetsMinimum(4, 1, 0)) && ("binary".equalsIgnoreCase(getCharacterSet()));
/*     */   }
/*     */ 
/*     */   public boolean isPrimaryKey()
/*     */   {
/* 755 */     return (this.colFlag & 0x2) > 0;
/*     */   }
/*     */ 
/*     */   boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 765 */     if (this.connection.versionMeetsMinimum(4, 1, 0)) {
/* 766 */       String orgColumnName = getOriginalName();
/* 767 */       String orgTableName = getOriginalTableName();
/*     */ 
/* 769 */       return (orgColumnName == null) || (orgColumnName.length() <= 0) || (orgTableName == null) || (orgTableName.length() <= 0);
/*     */     }
/*     */ 
/* 773 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isUniqueKey()
/*     */   {
/* 782 */     return (this.colFlag & 0x4) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isUnsigned()
/*     */   {
/* 791 */     return (this.colFlag & 0x20) > 0;
/*     */   }
/*     */ 
/*     */   public boolean isZeroFill()
/*     */   {
/* 800 */     return (this.colFlag & 0x40) > 0;
/*     */   }
/*     */ 
/*     */   private void setBlobTypeBasedOnLength()
/*     */   {
/* 809 */     if (this.length == 255L)
/* 810 */       this.mysqlType = 249;
/* 811 */     else if (this.length == 65535L)
/* 812 */       this.mysqlType = 252;
/* 813 */     else if (this.length == 16777215L)
/* 814 */       this.mysqlType = 250;
/* 815 */     else if (this.length == 4294967295L)
/* 816 */       this.mysqlType = 251;
/*     */   }
/*     */ 
/*     */   private boolean isNativeNumericType()
/*     */   {
/* 821 */     return ((this.mysqlType >= 1) && (this.mysqlType <= 5)) || (this.mysqlType == 8) || (this.mysqlType == 13);
/*     */   }
/*     */ 
/*     */   private boolean isNativeDateTimeType()
/*     */   {
/* 828 */     return (this.mysqlType == 10) || (this.mysqlType == 14) || (this.mysqlType == 12) || (this.mysqlType == 11) || (this.mysqlType == 7);
/*     */   }
/*     */ 
/*     */   public void setConnection(Connection conn)
/*     */   {
/* 842 */     this.connection = conn;
/*     */ 
/* 844 */     this.charsetName = this.connection.getEncoding();
/*     */   }
/*     */ 
/*     */   void setMysqlType(int type) {
/* 848 */     this.mysqlType = type;
/* 849 */     this.sqlType = MysqlDefs.mysqlToJavaType(this.mysqlType);
/*     */   }
/*     */ 
/*     */   protected void setUseOldNameMetadata(boolean useOldNameMetadata) {
/* 853 */     this.useOldNameMetadata = useOldNameMetadata;
/*     */   }
/*     */ 
/*     */   public String toString() {
/*     */     try {
/* 858 */       StringBuffer asString = new StringBuffer();
/* 859 */       asString.append(super.toString());
/*     */ 
/* 861 */       asString.append("\n  catalog: ");
/* 862 */       asString.append(getDatabaseName());
/* 863 */       asString.append("\n  table name: ");
/* 864 */       asString.append(getTableName());
/* 865 */       asString.append("\n  original table name: ");
/* 866 */       asString.append(getOriginalTableName());
/* 867 */       asString.append("\n  column name: ");
/* 868 */       asString.append(getName());
/* 869 */       asString.append("\n  original column name: ");
/* 870 */       asString.append(getOriginalName());
/* 871 */       asString.append("\n  MySQL data type: ");
/* 872 */       asString.append(getMysqlType());
/*     */ 
/* 874 */       if (this.buffer != null) {
/* 875 */         asString.append("\n\nData as received from server:\n\n");
/* 876 */         asString.append(StringUtils.dumpAsHex(this.buffer, this.buffer.length));
/*     */       }
/*     */ 
/* 880 */       return asString.toString(); } catch (Throwable t) {
/*     */     }
/* 882 */     return super.toString();
/*     */   }
/*     */ 
/*     */   protected boolean isSingleBit()
/*     */   {
/* 887 */     return this.isSingleBit;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Field
 * JD-Core Version:    0.6.0
 */