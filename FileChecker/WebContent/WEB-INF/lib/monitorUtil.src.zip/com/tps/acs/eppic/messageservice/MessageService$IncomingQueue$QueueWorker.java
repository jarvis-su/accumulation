/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import java.util.LinkedList;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ class MessageService$IncomingQueue$QueueWorker extends Thread
/*     */ {
/* 436 */   boolean alertQueueWait = false;
/* 437 */   boolean messageQueueWait = false;
/*     */ 
/*     */   private MessageService$IncomingQueue$QueueWorker(MessageService.IncomingQueue paramIncomingQueue) {  } 
/* 439 */   public void run() { LinkedList messageList = new LinkedList();
/*     */ 
/* 442 */     while (MessageService.IncomingQueue.access$2(this.this$1).isServiceEnabled()) {
/* 443 */       messageList.clear();
/* 444 */       synchronized (MessageService.IncomingQueue.access$0(this.this$1)) {
/* 445 */         if (MessageService.IncomingQueue.access$0(this.this$1).isEmpty()) {
/* 446 */           this.alertQueueWait = true;
/*     */         }
/*     */         else {
/* 449 */           this.alertQueueWait = false;
/*     */           do
/*     */           {
/* 452 */             messageList.add(MessageService.IncomingQueue.access$0(this.this$1).removeFirst());
/*     */ 
/* 451 */             if (messageList.size() >= MessageService.access$0(MessageService.IncomingQueue.access$2(this.this$1))) break; 
/* 451 */           }while (!MessageService.IncomingQueue.access$0(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 457 */       synchronized (MessageService.IncomingQueue.access$1(this.this$1)) {
/* 458 */         if (MessageService.IncomingQueue.access$1(this.this$1).isEmpty()) {
/* 459 */           this.messageQueueWait = true;
/*     */         } else {
/* 461 */           this.messageQueueWait = false;
/*     */           do
/*     */           {
/* 464 */             messageList.add(MessageService.IncomingQueue.access$1(this.this$1).removeFirst());
/*     */ 
/* 463 */             if (messageList.size() >= MessageService.access$0(MessageService.IncomingQueue.access$2(this.this$1))) break; 
/* 463 */           }while (!MessageService.IncomingQueue.access$1(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 469 */       if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 470 */         synchronized (this.this$1.semObj) {
/*     */           try {
/* 472 */             this.this$1.semObj.wait();
/*     */           }
/*     */           catch (InterruptedException localInterruptedException)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 479 */       int receivedMessages = 0;
/*     */ 
/* 481 */       while (!messageList.isEmpty()) {
/* 482 */         Message message = (Message)messageList.removeFirst();
/*     */         MessageServiceHandle msh;
/*     */         MessageServiceHandle msh;
/* 483 */         if (MessageService.IncomingQueue.access$2(this.this$1).isMonitorMode())
/* 484 */           msh = MessageService.IncomingQueue.access$2(this.this$1).findServiceHandle("MONITOR");
/*     */         else {
/* 486 */           msh = MessageService.IncomingQueue.access$2(this.this$1).findServiceHandle(message.getServiceId());
/*     */         }
/*     */ 
/* 489 */         if (msh != null)
/* 490 */           msh.receiveIncoming(message);
/*     */         else {
/* 492 */           MessageService.IncomingQueue.access$2(this.this$1).receiveIncoming(message);
/*     */         }
/* 494 */         receivedMessages++;
/*     */       }
/* 496 */       if (receivedMessages > 0)
/* 497 */         MessageService.logger.info(getName() + "\tReceived " + receivedMessages + " Messages.");
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService.IncomingQueue.QueueWorker
 * JD-Core Version:    0.6.0
 */