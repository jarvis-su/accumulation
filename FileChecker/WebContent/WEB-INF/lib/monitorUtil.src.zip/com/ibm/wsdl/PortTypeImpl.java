package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import javax.wsdl.Input;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.PortType;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class PortTypeImpl
  implements PortType
{
  protected QName name = null;
  protected List operations = new Vector();
  protected Element docEl = null;
  protected Map extensionAttributes = new HashMap();
  protected List nativeAttributeNames = Arrays.asList(Constants.PORT_TYPE_ATTR_NAMES);
  protected boolean isUndefined = true;
  public static final long serialVersionUID = 1L;

  public void setQName(QName paramQName)
  {
    this.name = paramQName;
  }

  public QName getQName()
  {
    return this.name;
  }

  public void addOperation(Operation paramOperation)
  {
    this.operations.add(paramOperation);
  }

  public Operation getOperation(String paramString1, String paramString2, String paramString3)
  {
    int i = 0;
    Object localObject1 = null;
    Iterator localIterator = this.operations.iterator();
    while (localIterator.hasNext())
    {
      Operation localOperation = (Operation)localIterator.next();
      String str1 = localOperation.getName();
      if ((paramString1 != null) && (str1 != null))
      {
        if (!paramString1.equals(str1))
          localOperation = null;
      }
      else if ((paramString1 != null) || (str1 != null))
        localOperation = null;
      OperationType localOperationType;
      String str2;
      boolean bool;
      Object localObject2;
      String str3;
      if ((localOperation != null) && (paramString2 != null))
      {
        localOperationType = localOperation.getStyle();
        str2 = str1;
        if (localOperationType == OperationType.REQUEST_RESPONSE)
          str2 = str1 + "Request";
        else if (localOperationType == OperationType.SOLICIT_RESPONSE)
          str2 = str1 + "Solicit";
        bool = paramString2.equals(str2);
        localObject2 = localOperation.getInput();
        if (localObject2 != null)
        {
          str3 = ((Input)localObject2).getName();
          if (str3 == null)
          {
            if (!bool)
              localOperation = null;
          }
          else if (!str3.equals(paramString2))
            localOperation = null;
        }
        else
        {
          localOperation = null;
        }
      }
      if ((localOperation != null) && (paramString3 != null))
      {
        localOperationType = localOperation.getStyle();
        str2 = str1;
        if ((localOperationType == OperationType.REQUEST_RESPONSE) || (localOperationType == OperationType.SOLICIT_RESPONSE))
          str2 = str1 + "Response";
        bool = paramString3.equals(str2);
        localObject2 = localOperation.getOutput();
        if (localObject2 != null)
        {
          str3 = ((Output)localObject2).getName();
          if (str3 == null)
          {
            if (!bool)
              localOperation = null;
          }
          else if (!str3.equals(paramString3))
            localOperation = null;
        }
        else
        {
          localOperation = null;
        }
      }
      if (localOperation == null)
        continue;
      if (i != 0)
        throw new IllegalArgumentException("Duplicate operation with name=" + paramString1 + (paramString2 != null ? ", inputName=" + paramString2 : "") + (paramString3 != null ? ", outputName=" + paramString3 : "") + ", found in portType '" + getQName() + "'.");
      i = 1;
      localObject1 = localOperation;
    }
    return (Operation)localObject1;
  }

  public List getOperations()
  {
    return this.operations;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void setUndefined(boolean paramBoolean)
  {
    this.isUndefined = paramBoolean;
  }

  public boolean isUndefined()
  {
    return this.isUndefined;
  }

  public void setExtensionAttribute(QName paramQName, Object paramObject)
  {
    if (paramObject != null)
      this.extensionAttributes.put(paramQName, paramObject);
    else
      this.extensionAttributes.remove(paramQName);
  }

  public Object getExtensionAttribute(QName paramQName)
  {
    return this.extensionAttributes.get(paramQName);
  }

  public Map getExtensionAttributes()
  {
    return this.extensionAttributes;
  }

  public List getNativeAttributeNames()
  {
    return this.nativeAttributeNames;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("PortType: name=" + this.name);
    if (this.operations != null)
    {
      localIterator = this.operations.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    Iterator localIterator = this.extensionAttributes.keySet().iterator();
    while (localIterator.hasNext())
    {
      QName localQName = (QName)localIterator.next();
      localStringBuffer.append("\nextension attribute: " + localQName + "=" + this.extensionAttributes.get(localQName));
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.PortTypeImpl
 * JD-Core Version:    0.6.0
 */