/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthRequestPublicKey
/*    */ {
/*    */   byte[] payload;
/*    */   String userName;
/*    */   String serviceName;
/*    */   String password;
/*    */   String pkAlgoName;
/*    */   byte[] pk;
/*    */   byte[] sig;
/*    */ 
/*    */   public PacketUserauthRequestPublicKey(String serviceName, String user, String pkAlgorithmName, byte[] pk, byte[] sig)
/*    */   {
/* 25 */     this.serviceName = serviceName;
/* 26 */     this.userName = user;
/* 27 */     this.pkAlgoName = pkAlgorithmName;
/* 28 */     this.pk = pk;
/* 29 */     this.sig = sig;
/*    */   }
/*    */ 
/*    */   public PacketUserauthRequestPublicKey(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 34 */     this.payload = new byte[len];
/* 35 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 37 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 39 */     int packet_type = tr.readByte();
/*    */ 
/* 41 */     if (packet_type != 50) {
/* 42 */       throw new IOException("This is not a SSH_MSG_USERAUTH_REQUEST! (" + 
/* 43 */         packet_type + ")");
/*    */     }
/* 45 */     throw new IOException("Not implemented!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 50 */     if (this.payload == null)
/*    */     {
/* 52 */       TypesWriter tw = new TypesWriter();
/* 53 */       tw.writeByte(50);
/* 54 */       tw.writeString(this.userName);
/* 55 */       tw.writeString(this.serviceName);
/* 56 */       tw.writeString("publickey");
/* 57 */       tw.writeBoolean(true);
/* 58 */       tw.writeString(this.pkAlgoName);
/* 59 */       tw.writeString(this.pk, 0, this.pk.length);
/* 60 */       tw.writeString(this.sig, 0, this.sig.length);
/* 61 */       this.payload = tw.getBytes();
/*    */     }
/* 63 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthRequestPublicKey
 * JD-Core Version:    0.6.0
 */