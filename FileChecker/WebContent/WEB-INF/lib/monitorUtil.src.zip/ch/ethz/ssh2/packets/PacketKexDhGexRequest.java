/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import ch.ethz.ssh2.DHGexParameters;
/*    */ 
/*    */ public class PacketKexDhGexRequest
/*    */ {
/*    */   byte[] payload;
/*    */   int min;
/*    */   int n;
/*    */   int max;
/*    */ 
/*    */   public PacketKexDhGexRequest(DHGexParameters para)
/*    */   {
/* 21 */     this.min = para.getMin_group_len();
/* 22 */     this.n = para.getPref_group_len();
/* 23 */     this.max = para.getMax_group_len();
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 28 */     if (this.payload == null)
/*    */     {
/* 30 */       TypesWriter tw = new TypesWriter();
/* 31 */       tw.writeByte(34);
/* 32 */       tw.writeUINT32(this.min);
/* 33 */       tw.writeUINT32(this.n);
/* 34 */       tw.writeUINT32(this.max);
/* 35 */       this.payload = tw.getBytes();
/*    */     }
/* 37 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDhGexRequest
 * JD-Core Version:    0.6.0
 */