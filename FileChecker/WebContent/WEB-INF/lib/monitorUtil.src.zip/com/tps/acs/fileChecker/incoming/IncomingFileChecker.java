/*     */ package com.acs.fileChecker.incoming;
/*     */ 
/*     */ import com.acs.fileChecker.DBConnector;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.Time;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Hashtable;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.regex.Pattern;
/*     */ import sun.misc.BASE64Encoder;
/*     */ 
/*     */ public class IncomingFileChecker
/*     */ {
/*  20 */   private BufferedReader input = null;
/*     */   private Calendar cal2;
/*     */   protected ResultSet rs;
/*  23 */   private Hashtable _ht = new Hashtable();
/*     */ 
/*  25 */   private final String _host = "192.168.179.39";
/*     */   private String _dateString;
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*  35 */     IncomingFileChecker x = new IncomingFileChecker();
/*  36 */     Date d = new Date();
/*  37 */     Date d2 = new Date();
/*     */ 
/*  39 */     for (int i = 0; i < argv.length; i++)
/*     */     {
/*  41 */       String output = x.getFilesForInstance(argv[i]);
/*  42 */       if ((output != null) && (!output.equals(""))) {
/*  43 */         System.out.println(output);
/*  44 */         Jmail jm = new Jmail();
/*  45 */         jm.sendMail("Incoming file-Checker detected problems", output);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public IncomingFileChecker() {
/*  51 */     this.cal2 = Calendar.getInstance();
/*  52 */     StringBuffer tmp = new StringBuffer(formatNumber(getMonth(), "00"));
/*  53 */     tmp.append("/");
/*  54 */     tmp.append(formatNumber(getDay(), "00"));
/*  55 */     tmp.append("/");
/*  56 */     tmp.append(formatNumber(this.cal2.get(1), "0000"));
/*  57 */     this._dateString = tmp.toString();
/*     */   }
/*     */ 
/*     */   public String getIncomingFilesTable(String instance, String user) {
/*  61 */     StringBuffer out = new StringBuffer();
/*  62 */     StringBuffer buf = new StringBuffer();
/*  63 */     DBConnector d = new DBConnector("192.168.179.39", "dbtoolsite", "root", "eppicce");
/*  64 */     buf.append("select tf.desc, ti.ignore from tblIncoming ti, tblReportFrequency tf where ti.instanceID = ");
/*  65 */     buf.append(instance);
/*  66 */     buf.append(" and tf.frequencyID = ti.frequencyID order by tf.frequencyID asc");
/*  67 */     d.connect();
/*  68 */     this.rs = d.execQuery(buf.toString());
/*     */ 
/*  70 */     out.append("<table width=\"500\" cellspacing=\"0\" cellpadding=\"0\" border=\"1\" ");
/*  71 */     out.append("style=\"margin: 0px\">\r\n<tr><td width=85%>Day</td><td width=15%>Check</td></tr>");
/*     */     try {
/*  73 */       while (this.rs.next()) {
/*  74 */         out.append("<tr><td width=85%>");
/*  75 */         out.append(this.rs.getString("desc"));
/*  76 */         out.append("</td><td width=15%><a href=test><img src=");
/*  77 */         out.append(this.rs.getBoolean("ignore") ? "check" : "x");
/*  78 */         out.append(".jpg></a></td></tr>");
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/*  82 */       e.printStackTrace();
/*     */     }
/*  84 */     d.disconnect();
/*  85 */     out.append("</table>");
/*  86 */     return out.toString();
/*     */   }
/*     */ 
/*     */   public String checkFiles(String host, String files)
/*     */   {
/*  95 */     StringBuffer output = new StringBuffer();
/*  96 */     String line = null;
/*  97 */     System.out.println(host + ":" + files);
/*     */     try {
/*  99 */       Process p = Runtime.getRuntime().exec("/home/ce-tools/incoming-fileCheckerTest.sh " + host + " " + files);
/* 100 */       this.input = new BufferedReader(new InputStreamReader(p.getInputStream()));
/* 101 */       while ((line = this.input.readLine()) != null)
/*     */       {
/* 103 */         StringTokenizer st = new StringTokenizer(line, " ");
/* 104 */         if (st.countTokens() == 2) {
/* 105 */           String tok = st.nextToken();
/* 106 */           int shouldBe = Integer.parseInt((String)this._ht.get(tok));
/* 107 */           int actual = Integer.parseInt(st.nextToken());
/*     */ 
/* 109 */           if (shouldBe > actual) {
/* 110 */             output.append(this._dateString);
/* 111 */             output.append(" ");
/* 112 */             output.append(formatNumber(this.cal2.get(11), "00"));
/* 113 */             output.append(":");
/* 114 */             output.append(formatNumber(this.cal2.get(12), "00"));
/* 115 */             output.append(" Should be ");
/* 116 */             output.append(shouldBe);
/* 117 */             output.append(" ");
/* 118 */             output.append(tok);
/* 119 */             output.append(" files on ");
/* 120 */             output.append(host);
/* 121 */             output.append(" Missing ");
/* 122 */             output.append(shouldBe - actual);
/* 123 */             output.append(" files\n");
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 129 */       this.input.close();
/*     */     }
/*     */     catch (Exception err) {
/* 132 */       err.printStackTrace();
/*     */     }
/* 134 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public int getMonth() {
/* 138 */     return this.cal2.get(2) + 1;
/*     */   }
/*     */ 
/*     */   public int getDay() {
/* 142 */     return this.cal2.get(5);
/*     */   }
/*     */ 
/*     */   public int getDayOfWeek() {
/* 146 */     return this.cal2.get(7);
/*     */   }
/*     */ 
/*     */   public int getYear() {
/* 150 */     return this.cal2.get(1);
/*     */   }
/*     */ 
/*     */   public String getFilesForInstance(String user) {
/* 154 */     String output = null;
/* 155 */     StringBuffer query = new StringBuffer("");
/* 156 */     StringBuffer tmp = new StringBuffer("");
/*     */ 
/* 158 */     DBConnector d = new DBConnector("192.168.179.39", "dbtoolsite", "root", "eppicce");
/*     */ 
/* 160 */     query.append("select f.folder, f.fileName, f.receiveBy, f.processBy, sum(f.numFiles) numFiles from tblIncoming f, tblReportFrequency rf, tblInstance ti where ( rf.month = 0 or rf.month = ");
/* 161 */     query.append(getMonth());
/* 162 */     query.append(" ) and ( rf.dayOfMonth = 0 or rf.dayOfMonth = ");
/* 163 */     query.append(getDay());
/* 164 */     query.append(" ) and ( rf.dayOfWeek = 0 or rf.dayOfWeek = ");
/* 165 */     query.append(getDayOfWeek());
/* 166 */     query.append(" ) and ti.AppUserName = '");
/* 167 */     query.append(new String(new BASE64Encoder().encode(user.getBytes())));
/* 168 */     query.append("' and f.instanceID = ti.instanceID ");
/*     */ 
/* 179 */     query.append(" and f.frequencyID = rf.frequencyID and f.ignoreFlag = 0 ");
/*     */ 
/* 182 */     query.append(" and f.processBy <= CURTIME() ");
/* 183 */     query.append("group by f.folder, f.fileName, f.receiveBy, f.processBy");
/*     */ 
/* 187 */     d.connect();
/* 188 */     this.rs = d.execQuery(query.toString());
/* 189 */     int numFiles = 0;
/*     */     try {
/* 191 */       while (this.rs.next()) {
/* 192 */         StringBuffer tmp2 = new StringBuffer();
/* 193 */         String fo = this.rs.getString("folder");
/* 194 */         Date receiveBy = new Date();
/* 195 */         Time tm = this.rs.getTime("receiveBy");
/* 196 */         receiveBy.setHours(tm.getHours());
/* 197 */         receiveBy.setMinutes(tm.getMinutes());
/*     */ 
/* 199 */         tm = this.rs.getTime("processBy");
/* 200 */         Date processBy = new Date();
/* 201 */         processBy.setHours(tm.getHours());
/* 202 */         processBy.setMinutes(tm.getMinutes());
/*     */ 
/* 204 */         String fi = replaceDate(this.rs.getString("fileName"), receiveBy, processBy);
/* 205 */         numFiles = this.rs.getInt("numFiles");
/* 206 */         tmp2.append("\"");
/* 207 */         if (fo != null) {
/* 208 */           tmp2.append(fo);
/* 209 */           tmp2.append(fi);
/*     */         }
/*     */         else {
/* 212 */           tmp2.append("/home/");
/* 213 */           tmp2.append(user);
/* 214 */           tmp2.append("/extfile/processed/");
/* 215 */           tmp2.append(fi);
/* 216 */           tmp2.append("\" \"/home/");
/* 217 */           tmp2.append(user);
/* 218 */           tmp2.append("/extfile/error/");
/* 219 */           tmp2.append(fi);
/* 220 */           tmp2.append("\" \"/home/");
/* 221 */           tmp2.append(user);
/* 222 */           tmp2.append("/extfile/");
/* 223 */           tmp2.append(fi);
/* 224 */           tmp2.append("\" ");
/*     */         }
/* 226 */         this._ht.put(fi, String.valueOf(numFiles));
/* 227 */         tmp.append(" ");
/* 228 */         tmp.append(tmp2);
/*     */       }
/*     */     }
/*     */     catch (Exception e) {
/* 232 */       e.printStackTrace();
/*     */     }
/* 234 */     d.disconnect();
/* 235 */     d.connect();
/*     */ 
/* 237 */     this.rs = d.execQuery("select ts.hostname from tblServer ts, tblInstance ti where ti.AppUserName = '" + new String(new BASE64Encoder().encode(user.getBytes())) + "' and ts.serverID = ti.fileServerID");
/*     */     try {
/* 239 */       this.rs.first();
/* 240 */       output = checkFiles(this.rs.getString("hostname"), tmp.toString());
/*     */     }
/*     */     catch (Exception e) {
/* 243 */       e.printStackTrace();
/* 244 */     }d.disconnect();
/* 245 */     return output;
/*     */   }
/*     */ 
/*     */   public Calendar strToCal(String d)
/*     */   {
/* 253 */     int yr = 0; int mo = 0; int dt = 0;
/* 254 */     if (validDate(d)) {
/* 255 */       mo = Integer.parseInt(d.substring(0, 2));
/* 256 */       dt = Integer.parseInt(d.substring(3, 5));
/* 257 */       yr = Integer.parseInt(d.substring(6, 10));
/* 258 */       Calendar c = Calendar.getInstance();
/* 259 */       c.set(yr, mo - 1, dt);
/* 260 */       return c;
/*     */     }
/* 262 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean validDate(String date)
/*     */   {
/* 267 */     return (date.equals("Never Checked")) || (Pattern.matches("[0-9]+/[0-9]+/2[0-9]+", date));
/*     */   }
/*     */ 
/*     */   public String replaceDate(String source, Date d1, Date d2)
/*     */   {
/* 272 */     char first = '{';
/* 273 */     char last = '}';
/* 274 */     int cur = 0;
/* 275 */     StringBuffer sb = new StringBuffer();
/* 276 */     int found = source.indexOf(first, cur);
/* 277 */     int found2 = source.indexOf(last, found);
/* 278 */     if ((found == -1) || (found2 == -1) || (d1 == null) || (d2 == null))
/* 279 */       return null;
/* 280 */     sb.append(source.substring(0, found + 1));
/* 281 */     String tmp = source.substring(found + 1, found2);
/* 282 */     SimpleDateFormat sdf = new SimpleDateFormat(tmp);
/*     */ 
/* 286 */     if (d2.before(d1))
/*     */     {
/* 288 */       int day = d1.getDate();
/* 289 */       d1.setDate(day - 1);
/*     */     }
/* 291 */     sb.append(tmp);
/* 292 */     sb.append('-');
/* 293 */     sb.append(sdf.format(d1));
/* 294 */     sb.append('-');
/* 295 */     sb.append(sdf.format(d2));
/* 296 */     sb.append(source.substring(found2, source.length()));
/* 297 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected static String formatNumber(int i, String pattern)
/*     */   {
/* 302 */     String strI = Integer.toString(i);
/* 303 */     StringBuffer sb = new StringBuffer();
/* 304 */     for (int cnt = 0; cnt < pattern.length() - strI.length(); cnt++)
/*     */     {
/* 306 */       sb.append(pattern.substring(cnt, cnt + 1));
/*     */     }
/* 308 */     sb.append(strI);
/* 309 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.incoming.IncomingFileChecker
 * JD-Core Version:    0.6.0
 */