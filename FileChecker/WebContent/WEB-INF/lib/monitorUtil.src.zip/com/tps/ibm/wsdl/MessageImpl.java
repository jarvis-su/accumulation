package com.ibm.wsdl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Message;
import javax.wsdl.Part;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class MessageImpl
  implements Message
{
  protected Map parts = new HashMap();
  protected List additionOrderOfParts = new Vector();
  protected QName name = null;
  protected Element docEl = null;
  protected List extElements = new Vector();
  protected boolean isUndefined = true;
  public static final long serialVersionUID = 1L;

  public void setQName(QName paramQName)
  {
    this.name = paramQName;
  }

  public QName getQName()
  {
    return this.name;
  }

  public void addPart(Part paramPart)
  {
    String str = paramPart.getName();
    this.parts.put(str, paramPart);
    this.additionOrderOfParts.add(str);
  }

  public Part getPart(String paramString)
  {
    return (Part)this.parts.get(paramString);
  }

  public Map getParts()
  {
    return this.parts;
  }

  public List getOrderedParts(List paramList)
  {
    Vector localVector = new Vector();
    if (paramList == null)
      paramList = this.additionOrderOfParts;
    Iterator localIterator = paramList.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      Part localPart = getPart(str);
      if (localPart == null)
        continue;
      localVector.add(localPart);
    }
    return localVector;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public void setUndefined(boolean paramBoolean)
  {
    this.isUndefined = paramBoolean;
  }

  public boolean isUndefined()
  {
    return this.isUndefined;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Message: name=" + this.name);
    if (this.parts != null)
    {
      Iterator localIterator = this.parts.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.MessageImpl
 * JD-Core Version:    0.6.0
 */