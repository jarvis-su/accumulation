/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import com.acs.fileChecker.DBConnector;
/*    */ import java.io.PrintStream;
/*    */ import java.sql.Connection;
/*    */ import java.sql.ResultSet;
/*    */ import java.sql.Statement;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class VarCache
/*    */ {
/* 15 */   private static final VarCache _instance = new VarCache();
/*    */   private Map<String, DBVar> _cache;
/*    */ 
/*    */   protected VarCache()
/*    */   {
/* 19 */     this._cache = new HashMap();
/*    */   }
/*    */ 
/*    */   public static VarCache getInstance() {
/* 23 */     return _instance;
/*    */   }
/*    */ 
/*    */   public static VarCache getInstance(Connection conn) {
/* 27 */     VarCache inst = getInstance();
/* 28 */     inst.loadSQLiteVars(conn);
/* 29 */     return inst;
/*    */   }
/*    */ 
/*    */   public static VarCache getInstance(String host, String db, String user, String pass)
/*    */   {
/* 37 */     VarCache inst = getInstance();
/* 38 */     inst.loadVars(host, db, user, pass);
/* 39 */     return inst;
/*    */   }
/*    */ 
/*    */   public static Vector<String> resolve(String s) throws Exception {
/* 43 */     return resolve(s, new Properties());
/*    */   }
/*    */ 
/*    */   public static Vector<String> resolve(String s, Properties env) throws Exception {
/* 47 */     VarString vs = new VarString(s);
/* 48 */     System.err.println("Resolving " + s);
/* 49 */     return vs.resolve(getInstance(), env);
/*    */   }
/*    */ 
/*    */   public DBVar getVar(String s) {
/* 53 */     return (DBVar)this._cache.get(s);
/*    */   }
/*    */ 
/*    */   public void putVar(String s, DBVar v) {
/* 57 */     this._cache.put(s, v);
/*    */   }
/*    */ 
/*    */   private void loadSQLiteVars(Connection conn) {
/*    */     try {
/* 62 */       Statement st = conn.createStatement();
/* 63 */       ResultSet rs = st.executeQuery("select name, value, type from tblVariable tv, tblVariableType tvt where tvt.varTypeId = tv.varTypeId");
/* 64 */       while (rs.next()) {
/* 65 */         String name = rs.getString(1);
/* 66 */         String val = rs.getString(2);
/* 67 */         String type = "com.smj.dbvariable." + rs.getString(3);
/*    */         Class c1;
/* 70 */         if ((type == null) || ((c1 = Class.forName(type)) == null)) {
/* 71 */           System.err.println("Variable type not found " + type);
/*    */         }
/*    */         else
/*    */         {
/*    */           Class c1;
/* 75 */           DBVar dbvar = (DBVar)c1.newInstance();
/* 76 */           dbvar.setInitialValue(val);
/* 77 */           putVar(name, dbvar);
/*    */         }
/*    */       }
/*    */     } catch (Exception e) {
/* 80 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ 
/*    */   private void loadVars(String host, String db, String user, String pass) {
/* 84 */     DBConnector d = new DBConnector(host, db, user, pass);
/* 85 */     d.connect();
/* 86 */     ResultSet rs = d.execQuery("select name, value, type from tblVariable tv, tblVariableType tvt where tvt.varTypeId = tv.varTypeId");
/*    */     try {
/* 88 */       while (rs.next()) {
/* 89 */         String name = rs.getString(1);
/* 90 */         String val = rs.getString(2);
/* 91 */         String type = "com.smj.dbvariable." + rs.getString(3);
/*    */         Class c1;
/* 94 */         if ((type == null) || ((c1 = Class.forName(type)) == null)) {
/* 95 */           System.err.println("Variable type not found " + type);
/*    */         }
/*    */         else
/*    */         {
/*    */           Class c1;
/* 99 */           DBVar dbvar = (DBVar)c1.newInstance();
/* 100 */           dbvar.setInitialValue(val);
/* 101 */           putVar(name, dbvar);
/*    */         }
/*    */       }
/* 104 */       d.disconnect(); } catch (Exception e) {
/* 105 */       e.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.VarCache
 * JD-Core Version:    0.6.0
 */