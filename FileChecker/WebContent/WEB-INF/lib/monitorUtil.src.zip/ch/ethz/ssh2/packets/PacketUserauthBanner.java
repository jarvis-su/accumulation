/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthBanner
/*    */ {
/*    */   byte[] payload;
/*    */   String message;
/*    */   String language;
/*    */ 
/*    */   public PacketUserauthBanner(String message, String language)
/*    */   {
/* 20 */     this.message = message;
/* 21 */     this.language = language;
/*    */   }
/*    */ 
/*    */   public String getBanner()
/*    */   {
/* 26 */     return this.message;
/*    */   }
/*    */ 
/*    */   public PacketUserauthBanner(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 31 */     this.payload = new byte[len];
/* 32 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 34 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 36 */     int packet_type = tr.readByte();
/*    */ 
/* 38 */     if (packet_type != 53) {
/* 39 */       throw new IOException("This is not a SSH_MSG_USERAUTH_BANNER! (" + packet_type + ")");
/*    */     }
/* 41 */     this.message = tr.readString("UTF-8");
/* 42 */     this.language = tr.readString();
/*    */ 
/* 44 */     if (tr.remain() != 0)
/* 45 */       throw new IOException("Padding in SSH_MSG_USERAUTH_REQUEST packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 50 */     if (this.payload == null)
/*    */     {
/* 52 */       TypesWriter tw = new TypesWriter();
/* 53 */       tw.writeByte(53);
/* 54 */       tw.writeString(this.message);
/* 55 */       tw.writeString(this.language);
/* 56 */       this.payload = tw.getBytes();
/*    */     }
/* 58 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthBanner
 * JD-Core Version:    0.6.0
 */