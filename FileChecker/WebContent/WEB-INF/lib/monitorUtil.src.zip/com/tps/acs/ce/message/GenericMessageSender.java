/*    */ package com.acs.ce.message;
/*    */ 
/*    */ import com.acs.eppic.message.AlertData;
/*    */ import com.acs.eppic.message.Message;
/*    */ import com.acs.eppic.messageservice.MessageSender;
/*    */ import java.io.PrintStream;
/*    */ 
/*    */ public class GenericMessageSender
/*    */ {
/*    */   public static void usage(int argSize)
/*    */   {
/* 11 */     System.out.println("Usage:\nOPTION 1\nMessageSender [systemId] [message]\n");
/*    */ 
/* 13 */     System.out.println("Example:\nOPTION 1\nMessageSender CAEBT Hello\n");
/*    */   }
/*    */ 
/*    */   public static void sendMessage(String system, String msg)
/*    */   {
/* 18 */     MessageSender ms = new MessageSender();
/* 19 */     ms.setServiceEnabled(true);
/* 20 */     Message m = new Message(system, "_GENERIC_1", 1, "");
/* 21 */     m.setM_MessageData(new AlertData("_GENERIC_1", msg));
/* 22 */     ms.enqueue(m);
/*    */     try {
/* 24 */       Thread.sleep(1000L);
/*    */     } catch (InterruptedException e) {
/* 26 */       e.printStackTrace();
/*    */     }
/* 28 */     ms.setServiceEnabled(false);
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 32 */     if (args.length != 2) {
/* 33 */       usage(args.length);
/*    */     }
/*    */     else {
/* 36 */       String systemId = args[0];
/* 37 */       String msg = args[1];
/* 38 */       sendMessage(systemId, msg);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.ce.message.GenericMessageSender
 * JD-Core Version:    0.6.0
 */