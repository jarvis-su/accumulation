/*     */ package com.smj.dbvariable;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.Calendar;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Properties;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class VarTime extends DBVar
/*     */ {
/*     */   private Properties _runtimeEnv;
/*     */ 
/*     */   protected Vector<String> resolveInternal(VarCache c, Properties env)
/*     */     throws Exception
/*     */   {
/*  29 */     this._runtimeEnv = env;
/*  30 */     Vector today = new Vector();
/*  31 */     Vector yest = new Vector();
/*  32 */     Vector v = new Vector();
/*  33 */     StringTokenizer st = new StringTokenizer(getInitialValue(), ",");
/*  34 */     int cal_hour = getCalendar().get(11);
/*  35 */     int cal_minute = getCalendar().get(12);
/*     */ 
/*  37 */     while (st.hasMoreTokens()) {
/*  38 */       VarString vs = new VarString(st.nextToken());
/*  39 */       for (String s : vs.resolve(c, env)) {
/*  40 */         boolean add = false;
/*  41 */         if (s.length() >= 2) {
/*  42 */           int hour = Integer.parseInt(s.substring(0, 2));
/*     */ 
/*  44 */           if ((hour < 24) && (cal_hour >= hour)) {
/*  45 */             if (s.length() >= 4) {
/*  46 */               int minute = Integer.parseInt(s.substring(2, 4));
/*     */ 
/*  48 */               if (minute < 60)
/*  49 */                 if ((cal_hour == hour) && (cal_minute >= minute))
/*  50 */                   today.add(s);
/*  51 */                 else if (cal_hour > hour)
/*  52 */                   today.add(s);
/*     */                 else
/*  54 */                   yest.add(s);
/*     */             }
/*     */             else {
/*  57 */               today.add(s);
/*     */             }
/*     */           }
/*  60 */           else yest.add(s);
/*     */         }
/*     */       }
/*     */     }
/*  64 */     boolean first = true;
/*  65 */     Enumeration e = yest.elements();
/*  66 */     StringBuffer sb = new StringBuffer("(");
/*  67 */     while (e.hasMoreElements()) {
/*  68 */       if (first)
/*  69 */         sb.append("{-yyyyMMdd}(");
/*  70 */       if (!first)
/*  71 */         sb.append("|");
/*  72 */       sb.append(e.nextElement());
/*  73 */       first = false;
/*     */     }
/*  75 */     if (!yest.isEmpty())
/*  76 */       sb.append(")");
/*  77 */     e = today.elements();
/*  78 */     first = true;
/*  79 */     while (e.hasMoreElements()) {
/*  80 */       if (first) {
/*  81 */         sb.append("|");
/*  82 */         sb.append(VarCache.resolve("{yyyyMMdd}", env));
/*  83 */         sb.append("(");
/*     */       }
/*  85 */       if (!first)
/*  86 */         sb.append("|");
/*  87 */       sb.append(e.nextElement());
/*  88 */       first = false;
/*     */     }
/*  90 */     if (!today.isEmpty())
/*  91 */       sb.append(")");
/*  92 */     v.add(")");
/*  93 */     return v;
/*     */   }
/*     */ 
/*     */   public Calendar getCalendar() {
/*  97 */     Calendar c1 = (Calendar)this._runtimeEnv.get("DATEFOR");
/*     */     Calendar c;
/*     */     Calendar c;
/*  99 */     if (c1 == null)
/* 100 */       c = Calendar.getInstance();
/*     */     else
/* 102 */       c = (Calendar)c1.clone();
/* 103 */     return c;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) throws Exception {
/* 107 */     VarTime v = new VarTime();
/* 108 */     VarDate d = new VarDate();
/* 109 */     d.setInitialValue("yyyyMMdd");
/* 110 */     v.setInitialValue("01,02,03,04,05,1625,17,18,19,20");
/* 111 */     VarCache.getInstance().putVar("{TODAY}", v);
/* 112 */     VarCache.getInstance().putVar("{yyyyMMdd}", d);
/* 113 */     VarCache.getInstance().putVar("{-yyyyMMdd}", d);
/* 114 */     System.out.print(VarCache.resolve("{TODAY}"));
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.smj.dbvariable.VarTime
 * JD-Core Version:    0.6.0
 */