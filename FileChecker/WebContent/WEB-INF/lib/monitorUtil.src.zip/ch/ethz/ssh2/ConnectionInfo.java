/*    */ package ch.ethz.ssh2;
/*    */ 
/*    */ public class ConnectionInfo
/*    */ {
/*    */   public String keyExchangeAlgorithm;
/*    */   public String clientToServerCryptoAlgorithm;
/*    */   public String serverToClientCryptoAlgorithm;
/*    */   public String clientToServerMACAlgorithm;
/*    */   public String serverToClientMACAlgorithm;
/*    */   public String serverHostKeyAlgorithm;
/*    */   public byte[] serverHostKey;
/* 52 */   public int keyExchangeCounter = 0;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.ConnectionInfo
 * JD-Core Version:    0.6.0
 */