/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.ParameterMetaData;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class CallableStatement$CallableStatementParamInfoJDBC3 extends CallableStatement.CallableStatementParamInfo
/*     */   implements ParameterMetaData
/*     */ {
/*     */   private final CallableStatement this$0;
/*     */ 
/*     */   CallableStatement$CallableStatementParamInfoJDBC3(CallableStatement this$0, ResultSet paramTypesRs)
/*     */     throws SQLException
/*     */   {
/* 343 */     super(this$0, paramTypesRs);
/*     */ 
/* 342 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   public CallableStatement$CallableStatementParamInfoJDBC3(CallableStatement this$0, CallableStatement.CallableStatementParamInfo paramInfo)
/*     */   {
/* 347 */     super(this$0, paramInfo);
/*     */ 
/* 346 */     this.this$0 = this$0;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CallableStatement.CallableStatementParamInfoJDBC3
 * JD-Core Version:    0.6.0
 */