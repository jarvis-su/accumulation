/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ public class StreamGobbler extends InputStream
/*     */ {
/*     */   private InputStream is;
/*     */   private GobblerThread t;
/* 108 */   private Object synchronizer = new Object();
/*     */ 
/* 110 */   private boolean isEOF = false;
/* 111 */   private boolean isClosed = false;
/* 112 */   private IOException exception = null;
/*     */ 
/* 114 */   private byte[] buffer = new byte[2048];
/* 115 */   private int read_pos = 0;
/* 116 */   private int write_pos = 0;
/*     */ 
/*     */   public StreamGobbler(InputStream is)
/*     */   {
/* 120 */     this.is = is;
/* 121 */     this.t = new GobblerThread();
/* 122 */     this.t.setDaemon(true);
/* 123 */     this.t.start();
/*     */   }
/*     */ 
/*     */   public int read() throws IOException
/*     */   {
/* 128 */     synchronized (this.synchronizer)
/*     */     {
/* 130 */       if (this.isClosed) {
/* 131 */         throw new IOException("This StreamGobbler is closed.");
/*     */       }
/* 133 */       while (this.read_pos == this.write_pos)
/*     */       {
/* 135 */         if (this.exception != null) {
/* 136 */           throw this.exception;
/*     */         }
/* 138 */         if (this.isEOF) {
/* 139 */           return -1;
/*     */         }
/*     */         try
/*     */         {
/* 143 */           this.synchronizer.wait();
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/* 150 */       int b = this.buffer[(this.read_pos++)] & 0xFF;
/*     */ 
/* 152 */       return b;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int available() throws IOException
/*     */   {
/* 158 */     synchronized (this.synchronizer)
/*     */     {
/* 160 */       if (this.isClosed) {
/* 161 */         throw new IOException("This StreamGobbler is closed.");
/*     */       }
/* 163 */       return this.write_pos - this.read_pos;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int read(byte[] b) throws IOException
/*     */   {
/* 169 */     return read(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void close() throws IOException
/*     */   {
/* 174 */     synchronized (this.synchronizer)
/*     */     {
/* 176 */       if (this.isClosed)
/* 177 */         return;
/* 178 */       this.isClosed = true;
/* 179 */       this.isEOF = true;
/* 180 */       this.synchronizer.notifyAll();
/* 181 */       this.is.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len) throws IOException
/*     */   {
/* 187 */     if (b == null) {
/* 188 */       throw new NullPointerException();
/*     */     }
/* 190 */     if ((off < 0) || (len < 0) || (off + len > b.length) || (off + len < 0) || (off > b.length)) {
/* 191 */       throw new IndexOutOfBoundsException();
/*     */     }
/* 193 */     if (len == 0) {
/* 194 */       return 0;
/*     */     }
/* 196 */     synchronized (this.synchronizer)
/*     */     {
/* 198 */       if (this.isClosed) {
/* 199 */         throw new IOException("This StreamGobbler is closed.");
/*     */       }
/* 201 */       while (this.read_pos == this.write_pos)
/*     */       {
/* 203 */         if (this.exception != null) {
/* 204 */           throw this.exception;
/*     */         }
/* 206 */         if (this.isEOF) {
/* 207 */           return -1;
/*     */         }
/*     */         try
/*     */         {
/* 211 */           this.synchronizer.wait();
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/* 218 */       int avail = this.write_pos - this.read_pos;
/*     */ 
/* 220 */       avail = avail > len ? len : avail;
/*     */ 
/* 222 */       System.arraycopy(this.buffer, this.read_pos, b, off, avail);
/*     */ 
/* 224 */       this.read_pos += avail;
/*     */ 
/* 226 */       return avail;
/*     */     }
/*     */   }
/*     */ 
/*     */   class GobblerThread extends Thread
/*     */   {
/*     */     GobblerThread()
/*     */     {
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*  41 */       byte[] buff = new byte[8192];
/*     */       while (true)
/*     */       {
/*     */         try
/*     */         {
/*  47 */           int avail = StreamGobbler.this.is.read(buff);
/*     */ 
/*  49 */           synchronized (StreamGobbler.this.synchronizer)
/*     */           {
/*  51 */             if (avail > 0)
/*     */               continue;
/*  53 */             StreamGobbler.this.isEOF = true;
/*  54 */             StreamGobbler.this.synchronizer.notifyAll();
/*  55 */             break;
/*     */ 
/*  58 */             int space_available = StreamGobbler.this.buffer.length - StreamGobbler.this.write_pos;
/*     */ 
/*  60 */             if (space_available >= avail)
/*     */             {
/*     */               continue;
/*     */             }
/*  64 */             int unread_size = StreamGobbler.this.write_pos - StreamGobbler.this.read_pos;
/*  65 */             int need_space = unread_size + avail;
/*     */ 
/*  67 */             byte[] new_buffer = StreamGobbler.this.buffer;
/*     */ 
/*  69 */             if (need_space <= StreamGobbler.this.buffer.length)
/*     */               continue;
/*  71 */             int inc = need_space / 3;
/*  72 */             inc = inc < 256 ? 256 : inc;
/*  73 */             inc = inc > 8192 ? 8192 : inc;
/*  74 */             new_buffer = new byte[need_space + inc];
/*     */ 
/*  77 */             if (unread_size > 0) {
/*  78 */               System.arraycopy(StreamGobbler.this.buffer, StreamGobbler.this.read_pos, new_buffer, 0, unread_size);
/*     */             }
/*  80 */             StreamGobbler.this.buffer = new_buffer;
/*     */ 
/*  82 */             StreamGobbler.this.read_pos = 0;
/*  83 */             StreamGobbler.this.write_pos = unread_size;
/*     */ 
/*  86 */             System.arraycopy(buff, 0, StreamGobbler.this.buffer, StreamGobbler.this.write_pos, avail);
/*  87 */             StreamGobbler.this.write_pos += avail;
/*     */ 
/*  89 */             StreamGobbler.this.synchronizer.notifyAll();
/*     */           }
/*  49 */           continue;
/*     */         }
/*     */         catch (IOException e)
/*     */         {
/*  94 */           synchronized (StreamGobbler.this.synchronizer)
/*     */           {
/*  96 */             StreamGobbler.this.exception = e;
/*  97 */             StreamGobbler.this.synchronizer.notifyAll();
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.StreamGobbler
 * JD-Core Version:    0.6.0
 */