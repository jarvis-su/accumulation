/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketOpenSessionChannel
/*    */ {
/*    */   byte[] payload;
/*    */   int channelID;
/*    */   int initialWindowSize;
/*    */   int maxPacketSize;
/*    */ 
/*    */   public PacketOpenSessionChannel(int channelID, int initialWindowSize, int maxPacketSize)
/*    */   {
/* 22 */     this.channelID = channelID;
/* 23 */     this.initialWindowSize = initialWindowSize;
/* 24 */     this.maxPacketSize = maxPacketSize;
/*    */   }
/*    */ 
/*    */   public PacketOpenSessionChannel(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 29 */     this.payload = new byte[len];
/* 30 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 32 */     TypesReader tr = new TypesReader(payload);
/*    */ 
/* 34 */     int packet_type = tr.readByte();
/*    */ 
/* 36 */     if (packet_type != 90) {
/* 37 */       throw new IOException("This is not a SSH_MSG_CHANNEL_OPEN! (" + 
/* 38 */         packet_type + ")");
/*    */     }
/* 40 */     this.channelID = tr.readUINT32();
/* 41 */     this.initialWindowSize = tr.readUINT32();
/* 42 */     this.maxPacketSize = tr.readUINT32();
/*    */ 
/* 44 */     if (tr.remain() != 0)
/* 45 */       throw new IOException("Padding in SSH_MSG_CHANNEL_OPEN packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 50 */     if (this.payload == null)
/*    */     {
/* 52 */       TypesWriter tw = new TypesWriter();
/* 53 */       tw.writeByte(90);
/* 54 */       tw.writeString("session");
/* 55 */       tw.writeUINT32(this.channelID);
/* 56 */       tw.writeUINT32(this.initialWindowSize);
/* 57 */       tw.writeUINT32(this.maxPacketSize);
/* 58 */       this.payload = tw.getBytes();
/*    */     }
/* 60 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketOpenSessionChannel
 * JD-Core Version:    0.6.0
 */