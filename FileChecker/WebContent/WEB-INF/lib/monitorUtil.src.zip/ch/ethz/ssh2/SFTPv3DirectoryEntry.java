package ch.ethz.ssh2;

public class SFTPv3DirectoryEntry
{
  public String filename;
  public String longEntry;
  public SFTPv3FileAttributes attributes;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SFTPv3DirectoryEntry
 * JD-Core Version:    0.6.0
 */