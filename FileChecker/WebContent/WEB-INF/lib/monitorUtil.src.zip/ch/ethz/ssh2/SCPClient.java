/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.BufferedOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class SCPClient
/*     */ {
/*     */   Connection conn;
/*     */ 
/*     */   public SCPClient(Connection conn)
/*     */   {
/*  37 */     if (conn == null)
/*  38 */       throw new IllegalArgumentException("Cannot accept null argument!");
/*  39 */     this.conn = conn;
/*     */   }
/*     */ 
/*     */   private void readResponse(InputStream is) throws IOException
/*     */   {
/*  44 */     int c = is.read();
/*     */ 
/*  46 */     if (c == 0) {
/*  47 */       return;
/*     */     }
/*  49 */     if (c == -1) {
/*  50 */       throw new IOException("Remote scp terminated unexpectedly.");
/*     */     }
/*  52 */     if ((c != 1) && (c != 2)) {
/*  53 */       throw new IOException("Remote scp sent illegal error code.");
/*     */     }
/*  55 */     if (c == 2) {
/*  56 */       throw new IOException("Remote scp terminated with error.");
/*     */     }
/*  58 */     String err = receiveLine(is);
/*  59 */     throw new IOException("Remote scp terminated with error (" + err + ").");
/*     */   }
/*     */ 
/*     */   private String receiveLine(InputStream is) throws IOException
/*     */   {
/*  64 */     StringBuffer sb = new StringBuffer(30);
/*     */     while (true)
/*     */     {
/*  70 */       if (sb.length() > 8192) {
/*  71 */         throw new IOException("Remote scp sent a too long line");
/*     */       }
/*  73 */       int c = is.read();
/*     */ 
/*  75 */       if (c < 0) {
/*  76 */         throw new IOException("Remote scp terminated unexpectedly.");
/*     */       }
/*  78 */       if (c == 10) {
/*     */         break;
/*     */       }
/*  81 */       sb.append((char)c);
/*     */     }
/*     */ 
/*  84 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private LenNamePair parseCLine(String line)
/*     */     throws IOException
/*     */   {
/*  93 */     if (line.length() < 8) {
/*  94 */       throw new IOException("Malformed C line sent by remote SCP binary, line too short.");
/*     */     }
/*  96 */     if ((line.charAt(4) != ' ') || (line.charAt(5) == ' ')) {
/*  97 */       throw new IOException("Malformed C line sent by remote SCP binary.");
/*     */     }
/*  99 */     int length_name_sep = line.indexOf(' ', 5);
/*     */ 
/* 101 */     if (length_name_sep == -1) {
/* 102 */       throw new IOException("Malformed C line sent by remote SCP binary.");
/*     */     }
/* 104 */     String length_substring = line.substring(5, length_name_sep);
/* 105 */     String name_substring = line.substring(length_name_sep + 1);
/*     */ 
/* 107 */     if ((length_substring.length() <= 0) || (name_substring.length() <= 0)) {
/* 108 */       throw new IOException("Malformed C line sent by remote SCP binary.");
/*     */     }
/* 110 */     if (6 + length_substring.length() + name_substring.length() != line.length()) {
/* 111 */       throw new IOException("Malformed C line sent by remote SCP binary.");
/*     */     }
/*     */     try
/*     */     {
/* 115 */       len = Long.parseLong(length_substring);
/*     */     }
/*     */     catch (NumberFormatException e)
/*     */     {
/*     */       long len;
/* 119 */       throw new IOException("Malformed C line sent by remote SCP binary, cannot parse file length.");
/*     */     }
/*     */     long len;
/* 122 */     if (len < 0L) {
/* 123 */       throw new IOException("Malformed C line sent by remote SCP binary, illegal file length.");
/*     */     }
/* 125 */     LenNamePair lnp = new LenNamePair();
/* 126 */     lnp.length = len;
/* 127 */     lnp.filename = name_substring;
/*     */ 
/* 129 */     return lnp;
/*     */   }
/*     */ 
/*     */   private void sendBytes(Session sess, byte[] data, String fileName, String mode) throws IOException
/*     */   {
/* 134 */     OutputStream os = sess.getStdin();
/* 135 */     InputStream is = new BufferedInputStream(sess.getStdout(), 512);
/*     */ 
/* 137 */     readResponse(is);
/*     */ 
/* 139 */     String cline = "C" + mode + " " + data.length + " " + fileName + "\n";
/*     */ 
/* 141 */     os.write(cline.getBytes());
/* 142 */     os.flush();
/*     */ 
/* 144 */     readResponse(is);
/*     */ 
/* 146 */     os.write(data, 0, data.length);
/* 147 */     os.write(0);
/* 148 */     os.flush();
/*     */ 
/* 150 */     readResponse(is);
/*     */ 
/* 152 */     os.write("E\n".getBytes());
/* 153 */     os.flush();
/*     */   }
/*     */ 
/*     */   private void sendFiles(Session sess, String[] files, String[] remoteFiles, String mode) throws IOException
/*     */   {
/* 158 */     byte[] buffer = new byte[8192];
/*     */ 
/* 160 */     OutputStream os = new BufferedOutputStream(sess.getStdin(), 40000);
/* 161 */     InputStream is = new BufferedInputStream(sess.getStdout(), 512);
/*     */ 
/* 163 */     readResponse(is);
/*     */ 
/* 165 */     for (int i = 0; i < files.length; i++)
/*     */     {
/* 167 */       File f = new File(files[i]);
/* 168 */       long remain = f.length();
/*     */       String remoteName;
/*     */       String remoteName;
/* 172 */       if ((remoteFiles != null) && (remoteFiles.length > i) && (remoteFiles[i] != null))
/* 173 */         remoteName = remoteFiles[i];
/*     */       else {
/* 175 */         remoteName = f.getName();
/*     */       }
/* 177 */       String cline = "C" + mode + " " + remain + " " + remoteName + "\n";
/*     */ 
/* 179 */       os.write(cline.getBytes());
/* 180 */       os.flush();
/*     */ 
/* 182 */       readResponse(is);
/*     */ 
/* 184 */       FileInputStream fis = null;
/*     */       try
/*     */       {
/* 188 */         fis = new FileInputStream(f);
/*     */ 
/* 190 */         while (remain > 0L)
/*     */         {
/*     */           int trans;
/*     */           int trans;
/* 193 */           if (remain > buffer.length)
/* 194 */             trans = buffer.length;
/*     */           else {
/* 196 */             trans = (int)remain;
/*     */           }
/* 198 */           if (fis.read(buffer, 0, trans) != trans) {
/* 199 */             throw new IOException("Cannot read enough from local file " + files[i]);
/*     */           }
/* 201 */           os.write(buffer, 0, trans);
/*     */ 
/* 203 */           remain -= trans;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 208 */         if (fis != null) {
/* 209 */           fis.close();
/*     */         }
/*     */       }
/* 212 */       os.write(0);
/* 213 */       os.flush();
/*     */ 
/* 215 */       readResponse(is);
/*     */     }
/*     */ 
/* 218 */     os.write("E\n".getBytes());
/* 219 */     os.flush();
/*     */   }
/*     */ 
/*     */   private void receiveFiles(Session sess, OutputStream[] targets) throws IOException
/*     */   {
/* 224 */     byte[] buffer = new byte[8192];
/*     */ 
/* 226 */     OutputStream os = new BufferedOutputStream(sess.getStdin(), 512);
/* 227 */     InputStream is = new BufferedInputStream(sess.getStdout(), 40000);
/*     */ 
/* 229 */     os.write(0);
/* 230 */     os.flush();
/*     */ 
/* 232 */     for (int i = 0; i < targets.length; i++)
/*     */     {
/* 234 */       LenNamePair lnp = null;
/*     */       while (true)
/*     */       {
/* 238 */         int c = is.read();
/* 239 */         if (c < 0) {
/* 240 */           throw new IOException("Remote scp terminated unexpectedly.");
/*     */         }
/* 242 */         String line = receiveLine(is);
/*     */ 
/* 244 */         if (c == 84)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 251 */         if ((c == 1) || (c == 2)) {
/* 252 */           throw new IOException("Remote SCP error: " + line);
/*     */         }
/* 254 */         if (c == 67)
/*     */         {
/* 256 */           lnp = parseCLine(line);
/* 257 */           break;
/*     */         }
/*     */ 
/* 260 */         throw new IOException("Remote SCP error: " + (char)c + line);
/*     */       }
/*     */ 
/* 263 */       os.write(0);
/* 264 */       os.flush();
/*     */ 
/* 266 */       long remain = lnp.length;
/*     */ 
/* 268 */       while (remain > 0L)
/*     */       {
/*     */         int trans;
/*     */         int trans;
/* 271 */         if (remain > buffer.length)
/* 272 */           trans = buffer.length;
/*     */         else {
/* 274 */           trans = (int)remain;
/*     */         }
/* 276 */         int this_time_received = is.read(buffer, 0, trans);
/*     */ 
/* 278 */         if (this_time_received < 0)
/*     */         {
/* 280 */           throw new IOException("Remote scp terminated connection unexpectedly");
/*     */         }
/*     */ 
/* 283 */         targets[i].write(buffer, 0, this_time_received);
/*     */ 
/* 285 */         remain -= this_time_received;
/*     */       }
/*     */ 
/* 288 */       readResponse(is);
/*     */ 
/* 290 */       os.write(0);
/* 291 */       os.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   private void receiveFiles(Session sess, String[] files, String target) throws IOException
/*     */   {
/* 297 */     byte[] buffer = new byte[8192];
/*     */ 
/* 299 */     OutputStream os = new BufferedOutputStream(sess.getStdin(), 512);
/* 300 */     InputStream is = new BufferedInputStream(sess.getStdout(), 40000);
/*     */ 
/* 302 */     os.write(0);
/* 303 */     os.flush();
/*     */ 
/* 305 */     for (int i = 0; i < files.length; i++)
/*     */     {
/* 307 */       LenNamePair lnp = null;
/*     */       while (true)
/*     */       {
/* 311 */         int c = is.read();
/* 312 */         if (c < 0) {
/* 313 */           throw new IOException("Remote scp terminated unexpectedly.");
/*     */         }
/* 315 */         String line = receiveLine(is);
/*     */ 
/* 317 */         if (c == 84)
/*     */         {
/*     */           continue;
/*     */         }
/*     */ 
/* 324 */         if ((c == 1) || (c == 2)) {
/* 325 */           throw new IOException("Remote SCP error: " + line);
/*     */         }
/* 327 */         if (c == 67)
/*     */         {
/* 329 */           lnp = parseCLine(line);
/* 330 */           break;
/*     */         }
/*     */ 
/* 333 */         throw new IOException("Remote SCP error: " + (char)c + line);
/*     */       }
/*     */ 
/* 336 */       os.write(0);
/* 337 */       os.flush();
/*     */ 
/* 339 */       File f = new File(target + File.separatorChar + lnp.filename);
/* 340 */       FileOutputStream fop = null;
/*     */       try
/*     */       {
/* 344 */         fop = new FileOutputStream(f);
/*     */ 
/* 346 */         long remain = lnp.length;
/*     */ 
/* 348 */         while (remain > 0L)
/*     */         {
/*     */           int trans;
/*     */           int trans;
/* 351 */           if (remain > buffer.length)
/* 352 */             trans = buffer.length;
/*     */           else {
/* 354 */             trans = (int)remain;
/*     */           }
/* 356 */           int this_time_received = is.read(buffer, 0, trans);
/*     */ 
/* 358 */           if (this_time_received < 0)
/*     */           {
/* 360 */             throw new IOException("Remote scp terminated connection unexpectedly");
/*     */           }
/*     */ 
/* 363 */           fop.write(buffer, 0, this_time_received);
/*     */ 
/* 365 */           remain -= this_time_received;
/*     */         }
/*     */       }
/*     */       finally
/*     */       {
/* 370 */         if (fop != null) {
/* 371 */           fop.close();
/*     */         }
/*     */       }
/* 374 */       readResponse(is);
/*     */ 
/* 376 */       os.write(0);
/* 377 */       os.flush();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void put(String localFile, String remoteTargetDirectory)
/*     */     throws IOException
/*     */   {
/* 394 */     put(new String[] { localFile }, remoteTargetDirectory, "0600");
/*     */   }
/*     */ 
/*     */   public void put(String[] localFiles, String remoteTargetDirectory)
/*     */     throws IOException
/*     */   {
/* 411 */     put(localFiles, remoteTargetDirectory, "0600");
/*     */   }
/*     */ 
/*     */   public void put(String localFile, String remoteTargetDirectory, String mode)
/*     */     throws IOException
/*     */   {
/* 428 */     put(new String[] { localFile }, remoteTargetDirectory, mode);
/*     */   }
/*     */ 
/*     */   public void put(String localFile, String remoteFileName, String remoteTargetDirectory, String mode)
/*     */     throws IOException
/*     */   {
/* 448 */     put(new String[] { localFile }, new String[] { remoteFileName }, remoteTargetDirectory, mode);
/*     */   }
/*     */ 
/*     */   public void put(byte[] data, String remoteFileName, String remoteTargetDirectory)
/*     */     throws IOException
/*     */   {
/* 466 */     put(data, remoteFileName, remoteTargetDirectory, "0600");
/*     */   }
/*     */ 
/*     */   public void put(byte[] data, String remoteFileName, String remoteTargetDirectory, String mode)
/*     */     throws IOException
/*     */   {
/* 485 */     Session sess = null;
/*     */ 
/* 487 */     if ((remoteFileName == null) || (remoteTargetDirectory == null) || (mode == null)) {
/* 488 */       throw new IllegalArgumentException("Null argument.");
/*     */     }
/* 490 */     if (mode.length() != 4) {
/* 491 */       throw new IllegalArgumentException("Invalid mode.");
/*     */     }
/* 493 */     for (int i = 0; i < mode.length(); i++) {
/* 494 */       if (!Character.isDigit(mode.charAt(i)))
/* 495 */         throw new IllegalArgumentException("Invalid mode.");
/*     */     }
/* 497 */     remoteTargetDirectory = remoteTargetDirectory.trim();
/* 498 */     remoteTargetDirectory = remoteTargetDirectory.length() > 0 ? remoteTargetDirectory : ".";
/*     */ 
/* 500 */     String cmd = "scp -t -d " + remoteTargetDirectory;
/*     */     try
/*     */     {
/* 504 */       sess = this.conn.openSession();
/* 505 */       sess.execCommand(cmd);
/* 506 */       sendBytes(sess, data, remoteFileName, mode);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 510 */       throw ((IOException)new IOException("Error during SCP transfer.").initCause(e));
/*     */     }
/*     */     finally
/*     */     {
/* 514 */       if (sess != null)
/* 515 */         sess.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void put(String[] localFiles, String remoteTargetDirectory, String mode)
/*     */     throws IOException
/*     */   {
/* 533 */     put(localFiles, null, remoteTargetDirectory, mode);
/*     */   }
/*     */ 
/*     */   public void put(String[] localFiles, String[] remoteFiles, String remoteTargetDirectory, String mode)
/*     */     throws IOException
/*     */   {
/* 539 */     Session sess = null;
/*     */ 
/* 543 */     if ((localFiles == null) || (remoteTargetDirectory == null) || (mode == null)) {
/* 544 */       throw new IllegalArgumentException("Null argument.");
/*     */     }
/* 546 */     if (mode.length() != 4) {
/* 547 */       throw new IllegalArgumentException("Invalid mode.");
/*     */     }
/* 549 */     for (int i = 0; i < mode.length(); i++) {
/* 550 */       if (!Character.isDigit(mode.charAt(i)))
/* 551 */         throw new IllegalArgumentException("Invalid mode.");
/*     */     }
/* 553 */     if (localFiles.length == 0) {
/* 554 */       return;
/*     */     }
/* 556 */     remoteTargetDirectory = remoteTargetDirectory.trim();
/* 557 */     remoteTargetDirectory = remoteTargetDirectory.length() > 0 ? remoteTargetDirectory : ".";
/*     */ 
/* 559 */     String cmd = "scp -t -d " + remoteTargetDirectory;
/*     */ 
/* 561 */     for (int i = 0; i < localFiles.length; i++)
/*     */     {
/* 563 */       if (localFiles[i] == null) {
/* 564 */         throw new IllegalArgumentException("Cannot accept null filename.");
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 569 */       sess = this.conn.openSession();
/* 570 */       sess.execCommand(cmd);
/* 571 */       sendFiles(sess, localFiles, remoteFiles, mode);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 575 */       throw ((IOException)new IOException("Error during SCP transfer.").initCause(e));
/*     */     }
/*     */     finally
/*     */     {
/* 579 */       if (sess != null)
/* 580 */         sess.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void get(String remoteFile, String localTargetDirectory)
/*     */     throws IOException
/*     */   {
/* 596 */     get(new String[] { remoteFile }, localTargetDirectory);
/*     */   }
/*     */ 
/*     */   public void get(String remoteFile, OutputStream target)
/*     */     throws IOException
/*     */   {
/* 612 */     get(new String[] { remoteFile }, new OutputStream[] { target });
/*     */   }
/*     */ 
/*     */   private void get(String[] remoteFiles, OutputStream[] targets) throws IOException
/*     */   {
/* 617 */     Session sess = null;
/*     */ 
/* 619 */     if ((remoteFiles == null) || (targets == null)) {
/* 620 */       throw new IllegalArgumentException("Null argument.");
/*     */     }
/* 622 */     if (remoteFiles.length != targets.length) {
/* 623 */       throw new IllegalArgumentException("Length of arguments does not match.");
/*     */     }
/* 625 */     if (remoteFiles.length == 0) {
/* 626 */       return;
/*     */     }
/* 628 */     String cmd = "scp -f";
/*     */ 
/* 630 */     for (int i = 0; i < remoteFiles.length; i++)
/*     */     {
/* 632 */       if (remoteFiles[i] == null) {
/* 633 */         throw new IllegalArgumentException("Cannot accept null filename.");
/*     */       }
/* 635 */       tmp = remoteFiles[i].trim();
/*     */ 
/* 637 */       if (tmp.length() == 0) {
/* 638 */         throw new IllegalArgumentException("Cannot accept empty filename.");
/*     */       }
/* 640 */       cmd = cmd + " " + tmp;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 645 */       sess = this.conn.openSession();
/* 646 */       sess.execCommand(cmd);
/* 647 */       receiveFiles(sess, targets);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 651 */       throw ((IOException)new IOException("Error during SCP transfer.").initCause(e));
/*     */     }
/*     */     finally
/*     */     {
/* 655 */       if (sess != null)
/* 656 */         sess.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void get(String[] remoteFiles, String localTargetDirectory)
/*     */     throws IOException
/*     */   {
/* 672 */     Session sess = null;
/*     */ 
/* 674 */     if ((remoteFiles == null) || (localTargetDirectory == null)) {
/* 675 */       throw new IllegalArgumentException("Null argument.");
/*     */     }
/* 677 */     if (remoteFiles.length == 0) {
/* 678 */       return;
/*     */     }
/* 680 */     String cmd = "scp -f";
/*     */ 
/* 682 */     for (int i = 0; i < remoteFiles.length; i++)
/*     */     {
/* 684 */       if (remoteFiles[i] == null) {
/* 685 */         throw new IllegalArgumentException("Cannot accept null filename.");
/*     */       }
/* 687 */       tmp = remoteFiles[i].trim();
/*     */ 
/* 689 */       if (tmp.length() == 0) {
/* 690 */         throw new IllegalArgumentException("Cannot accept empty filename.");
/*     */       }
/* 692 */       cmd = cmd + " " + tmp;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 697 */       sess = this.conn.openSession();
/* 698 */       sess.execCommand(cmd);
/* 699 */       receiveFiles(sess, remoteFiles, localTargetDirectory);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 703 */       throw ((IOException)new IOException("Error during SCP transfer.").initCause(e));
/*     */     }
/*     */     finally
/*     */     {
/* 707 */       if (sess != null)
/* 708 */         sess.close();
/*     */     }
/*     */   }
/*     */ 
/*     */   class LenNamePair
/*     */   {
/*     */     long length;
/*     */     String filename;
/*     */ 
/*     */     LenNamePair()
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SCPClient
 * JD-Core Version:    0.6.0
 */