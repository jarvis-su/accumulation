/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.LogFactory;
/*      */ import com.mysql.jdbc.log.NullLogger;
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.io.IOException;
/*      */ import java.io.PrintStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.Method;
/*      */ import java.sql.Blob;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Savepoint;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.Map.Entry;
/*      */ import java.util.Properties;
/*      */ import java.util.Set;
/*      */ import java.util.Stack;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class Connection extends ConnectionProperties
/*      */   implements java.sql.Connection
/*      */ {
/* 1026 */   private static final Object CHARSET_CONVERTER_NOT_AVAILABLE_MARKER = new Object();
/*      */   public static Map charsetMap;
/*      */   protected static final String DEFAULT_LOGGER_CLASS = "com.mysql.jdbc.log.StandardLogger";
/*      */   private static final int HISTOGRAM_BUCKETS = 20;
/*      */   private static final String LOGGER_INSTANCE_NAME = "MySQL";
/* 1046 */   private static Map mapTransIsolationNameToValue = null;
/*      */ 
/* 1049 */   private static final Log NULL_LOGGER = new NullLogger("MySQL");
/*      */   private static Map roundRobinStatsMap;
/* 1053 */   private static final Map serverCollationByUrl = new HashMap();
/*      */ 
/* 1055 */   private static final Map serverConfigByUrl = new HashMap();
/*      */   private static Timer cancelTimer;
/* 1167 */   private boolean autoCommit = true;
/*      */   private Map cachedPreparedStatementParams;
/* 1175 */   private String characterSetMetadata = null;
/*      */ 
/* 1181 */   private String characterSetResultsOnServer = null;
/*      */ 
/* 1188 */   private Map charsetConverterMap = new HashMap(CharsetMapping.getNumberOfCharsetsConfigured());
/*      */   private Map charsetToNumBytesMap;
/* 1198 */   private long connectionCreationTimeMillis = 0L;
/*      */   private long connectionId;
/* 1204 */   private String database = null;
/*      */ 
/* 1207 */   private DatabaseMetaData dbmd = null;
/*      */   private TimeZone defaultTimeZone;
/*      */   private ProfileEventSink eventSink;
/* 1214 */   private boolean executingFailoverReconnect = false;
/*      */ 
/* 1217 */   private boolean failedOver = false;
/*      */   private Throwable forceClosedReason;
/*      */   private Throwable forcedClosedLocation;
/* 1226 */   private boolean hasIsolationLevels = false;
/*      */ 
/* 1229 */   private boolean hasQuotedIdentifiers = false;
/*      */ 
/* 1232 */   private String host = null;
/*      */ 
/* 1235 */   private List hostList = null;
/*      */ 
/* 1238 */   private int hostListSize = 0;
/*      */ 
/* 1244 */   private String[] indexToCharsetMapping = CharsetMapping.INDEX_TO_CHARSET;
/*      */ 
/* 1247 */   private MysqlIO io = null;
/*      */ 
/* 1249 */   private boolean isClientTzUTC = false;
/*      */ 
/* 1252 */   private boolean isClosed = true;
/*      */ 
/* 1255 */   private boolean isInGlobalTx = false;
/*      */ 
/* 1258 */   private boolean isRunningOnJDK13 = false;
/*      */ 
/* 1261 */   private int isolationLevel = 2;
/*      */ 
/* 1263 */   private boolean isServerTzUTC = false;
/*      */ 
/* 1266 */   private long lastQueryFinishedTime = 0L;
/*      */ 
/* 1269 */   private Log log = NULL_LOGGER;
/*      */ 
/* 1275 */   private long longestQueryTimeMs = 0L;
/*      */ 
/* 1278 */   private boolean lowerCaseTableNames = false;
/*      */ 
/* 1281 */   private long masterFailTimeMillis = 0L;
/*      */ 
/* 1287 */   private int maxAllowedPacket = 65536;
/*      */ 
/* 1289 */   private long maximumNumberTablesAccessed = 0L;
/*      */ 
/* 1292 */   private boolean maxRowsChanged = false;
/*      */   private long metricsLastReportedMs;
/* 1297 */   private long minimumNumberTablesAccessed = 9223372036854775807L;
/*      */ 
/* 1300 */   private final Object mutex = new Object();
/*      */ 
/* 1303 */   private String myURL = null;
/*      */ 
/* 1306 */   private boolean needsPing = false;
/*      */ 
/* 1308 */   private int netBufferLength = 16384;
/*      */ 
/* 1310 */   private boolean noBackslashEscapes = false;
/*      */ 
/* 1312 */   private long numberOfPreparedExecutes = 0L;
/*      */ 
/* 1314 */   private long numberOfPrepares = 0L;
/*      */ 
/* 1316 */   private long numberOfQueriesIssued = 0L;
/*      */ 
/* 1318 */   private long numberOfResultSetsCreated = 0L;
/*      */   private long[] numTablesMetricsHistBreakpoints;
/*      */   private int[] numTablesMetricsHistCounts;
/* 1324 */   private long[] oldHistBreakpoints = null;
/*      */ 
/* 1326 */   private int[] oldHistCounts = null;
/*      */   private Map openStatements;
/*      */   private LRUCache parsedCallableStatementCache;
/* 1333 */   private boolean parserKnowsUnicode = false;
/*      */ 
/* 1336 */   private String password = null;
/*      */   private long[] perfMetricsHistBreakpoints;
/*      */   private int[] perfMetricsHistCounts;
/*      */   private Throwable pointOfOrigin;
/* 1346 */   private int port = 3306;
/*      */ 
/* 1352 */   private boolean preferSlaveDuringFailover = false;
/*      */ 
/* 1355 */   private Properties props = null;
/*      */ 
/* 1358 */   private long queriesIssuedFailedOver = 0L;
/*      */ 
/* 1361 */   private boolean readInfoMsg = false;
/*      */ 
/* 1364 */   private boolean readOnly = false;
/*      */ 
/* 1367 */   private TimeZone serverTimezoneTZ = null;
/*      */ 
/* 1370 */   private Map serverVariables = null;
/*      */ 
/* 1372 */   private long shortestQueryTimeMs = 9223372036854775807L;
/*      */   private Map statementsUsingMaxRows;
/* 1377 */   private double totalQueryTimeMs = 0.0D;
/*      */ 
/* 1380 */   private boolean transactionsSupported = false;
/*      */   private Map typeMap;
/* 1389 */   private boolean useAnsiQuotes = false;
/*      */ 
/* 1392 */   private String user = null;
/*      */ 
/* 1398 */   private boolean useServerPreparedStmts = false;
/*      */   private LRUCache serverSideStatementCheckCache;
/*      */   private LRUCache serverSideStatementCache;
/*      */   private Calendar sessionCalendar;
/*      */   private Calendar utcCalendar;
/*      */   private String origHostToConnectTo;
/*      */   private int origPortToConnectTo;
/*      */   private String origDatabaseToConnectTo;
/* 1414 */   private String errorMessageEncoding = "Cp1252";
/*      */   private boolean usePlatformCharsetConverters;
/* 5727 */   private boolean hasTriedMasterFlag = false;
/*      */ 
/*      */   protected static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend)
/*      */   {
/* 1075 */     String origMessage = sqlEx.getMessage();
/* 1076 */     String sqlState = sqlEx.getSQLState();
/* 1077 */     int vendorErrorCode = sqlEx.getErrorCode();
/*      */ 
/* 1079 */     StringBuffer messageBuf = new StringBuffer(origMessage.length() + messageToAppend.length());
/*      */ 
/* 1081 */     messageBuf.append(origMessage);
/* 1082 */     messageBuf.append(messageToAppend);
/*      */ 
/* 1084 */     SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(messageBuf.toString(), sqlState, vendorErrorCode);
/*      */     try
/*      */     {
/* 1094 */       Method getStackTraceMethod = null;
/* 1095 */       Method setStackTraceMethod = null;
/* 1096 */       Object theStackTraceAsObject = null;
/*      */ 
/* 1098 */       Class stackTraceElementClass = Class.forName("java.lang.StackTraceElement");
/*      */ 
/* 1100 */       Class stackTraceElementArrayClass = Array.newInstance(stackTraceElementClass, new int[] { 0 }).getClass();
/*      */ 
/* 1103 */       getStackTraceMethod = Throwable.class.getMethod("getStackTrace", new Class[0]);
/*      */ 
/* 1106 */       setStackTraceMethod = class$java$lang$Throwable.getMethod("setStackTrace", new Class[] { stackTraceElementArrayClass });
/*      */ 
/* 1109 */       if ((getStackTraceMethod != null) && (setStackTraceMethod != null)) {
/* 1110 */         theStackTraceAsObject = getStackTraceMethod.invoke(sqlEx, new Object[0]);
/*      */ 
/* 1112 */         setStackTraceMethod.invoke(sqlExceptionWithNewMessage, new Object[] { theStackTraceAsObject });
/*      */       }
/*      */     }
/*      */     catch (NoClassDefFoundError noClassDefFound)
/*      */     {
/*      */     }
/*      */     catch (NoSuchMethodException noSuchMethodEx)
/*      */     {
/*      */     }
/*      */     catch (Throwable catchAll) {
/*      */     }
/* 1123 */     return sqlExceptionWithNewMessage;
/*      */   }
/*      */ 
/*      */   protected static Timer getCancelTimer() {
/* 1127 */     return cancelTimer;
/*      */   }
/*      */ 
/*      */   private static synchronized int getNextRoundRobinHostIndex(String url, List hostList)
/*      */   {
/* 1132 */     if (roundRobinStatsMap == null) {
/* 1133 */       roundRobinStatsMap = new HashMap();
/*      */     }
/*      */ 
/* 1136 */     int[] index = (int[])roundRobinStatsMap.get(url);
/*      */ 
/* 1138 */     if (index == null) {
/* 1139 */       index = new int[1];
/* 1140 */       index[0] = -1;
/*      */ 
/* 1142 */       roundRobinStatsMap.put(url, index);
/*      */     }
/*      */ 
/* 1145 */     index[0] += 1;
/*      */ 
/* 1147 */     if (index[0] >= hostList.size()) {
/* 1148 */       index[0] = 0;
/*      */     }
/*      */ 
/* 1151 */     return index[0];
/*      */   }
/*      */ 
/*      */   private static boolean nullSafeCompare(String s1, String s2) {
/* 1155 */     if ((s1 == null) && (s2 == null)) {
/* 1156 */       return true;
/*      */     }
/*      */ 
/* 1159 */     if ((s1 == null) && (s2 != null)) {
/* 1160 */       return false;
/*      */     }
/*      */ 
/* 1163 */     return s1.equals(s2);
/*      */   }
/*      */ 
/*      */   Connection(String hostToConnectTo, int portToConnectTo, Properties info, String databaseToConnectTo, String url)
/*      */     throws SQLException
/*      */   {
/* 1440 */     this.charsetToNumBytesMap = new HashMap();
/* 1441 */     cancelTimer = new Timer(true);
/* 1442 */     this.connectionCreationTimeMillis = System.currentTimeMillis();
/* 1443 */     this.pointOfOrigin = new Throwable();
/*      */ 
/* 1449 */     this.origHostToConnectTo = hostToConnectTo;
/* 1450 */     this.origPortToConnectTo = portToConnectTo;
/* 1451 */     this.origDatabaseToConnectTo = databaseToConnectTo;
/*      */     try
/*      */     {
/* 1454 */       class$java$sql$Blob.getMethod("truncate", new Class[] { Long.TYPE });
/*      */ 
/* 1456 */       this.isRunningOnJDK13 = false;
/*      */     } catch (NoSuchMethodException nsme) {
/* 1458 */       this.isRunningOnJDK13 = true;
/*      */     }
/*      */ 
/* 1461 */     this.sessionCalendar = new GregorianCalendar();
/* 1462 */     this.utcCalendar = new GregorianCalendar();
/* 1463 */     this.utcCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
/*      */ 
/* 1475 */     this.log = LogFactory.getLogger(getLogger(), "MySQL");
/*      */ 
/* 1479 */     this.defaultTimeZone = TimeZone.getDefault();
/* 1480 */     if ("GMT".equalsIgnoreCase(this.defaultTimeZone.getID()))
/* 1481 */       this.isClientTzUTC = true;
/*      */     else {
/* 1483 */       this.isClientTzUTC = false;
/*      */     }
/*      */ 
/* 1486 */     this.openStatements = new HashMap();
/* 1487 */     this.serverVariables = new HashMap();
/* 1488 */     this.hostList = new ArrayList();
/*      */ 
/* 1490 */     if (hostToConnectTo == null) {
/* 1491 */       this.host = "localhost";
/* 1492 */       this.hostList.add(this.host);
/* 1493 */     } else if (hostToConnectTo.indexOf(",") != -1)
/*      */     {
/* 1495 */       StringTokenizer hostTokenizer = new StringTokenizer(hostToConnectTo, ",", false);
/*      */ 
/* 1498 */       while (hostTokenizer.hasMoreTokens())
/* 1499 */         this.hostList.add(hostTokenizer.nextToken().trim());
/*      */     }
/*      */     else {
/* 1502 */       this.host = hostToConnectTo;
/* 1503 */       this.hostList.add(this.host);
/*      */     }
/*      */ 
/* 1506 */     this.hostListSize = this.hostList.size();
/* 1507 */     this.port = portToConnectTo;
/*      */ 
/* 1509 */     if (databaseToConnectTo == null) {
/* 1510 */       databaseToConnectTo = "";
/*      */     }
/*      */ 
/* 1513 */     this.database = databaseToConnectTo;
/* 1514 */     this.myURL = url;
/* 1515 */     this.user = info.getProperty("user");
/* 1516 */     this.password = info.getProperty("password");
/*      */ 
/* 1519 */     if ((this.user == null) || (this.user.equals(""))) {
/* 1520 */       this.user = "";
/*      */     }
/*      */ 
/* 1523 */     if (this.password == null) {
/* 1524 */       this.password = "";
/*      */     }
/*      */ 
/* 1527 */     this.props = info;
/* 1528 */     initializeDriverProperties(info);
/*      */     try
/*      */     {
/* 1531 */       createNewIO(false);
/* 1532 */       this.connectionId = this.io.getThreadId();
/* 1533 */       this.dbmd = new DatabaseMetaData(this, this.database);
/*      */     } catch (SQLException ex) {
/* 1535 */       cleanup(ex);
/*      */ 
/* 1538 */       throw ex;
/*      */     } catch (Exception ex) {
/* 1540 */       cleanup(ex);
/*      */ 
/* 1542 */       StringBuffer mesg = new StringBuffer();
/*      */ 
/* 1544 */       if (getParanoid()) {
/* 1545 */         mesg.append("Cannot connect to MySQL server on ");
/* 1546 */         mesg.append(this.host);
/* 1547 */         mesg.append(":");
/* 1548 */         mesg.append(this.port);
/* 1549 */         mesg.append(".\n\n");
/* 1550 */         mesg.append("Make sure that there is a MySQL server ");
/* 1551 */         mesg.append("running on the machine/port you are trying ");
/* 1552 */         mesg.append("to connect to and that the machine this software is running on ");
/*      */ 
/* 1555 */         mesg.append("is able to connect to this host/port (i.e. not firewalled). ");
/*      */ 
/* 1557 */         mesg.append("Also make sure that the server has not been started with the --skip-networking ");
/*      */ 
/* 1560 */         mesg.append("flag.\n\n");
/*      */       } else {
/* 1562 */         mesg.append("Unable to connect to database.");
/*      */       }
/*      */ 
/* 1565 */       mesg.append("Underlying exception: \n\n");
/* 1566 */       mesg.append(ex.getClass().getName());
/*      */ 
/* 1568 */       if (!getParanoid()) {
/* 1569 */         mesg.append(Util.stackTraceToString(ex));
/*      */       }
/*      */ 
/* 1572 */       throw SQLError.createSQLException(mesg.toString(), "08S01");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound)
/*      */   {
/* 1580 */     if (histogramCounts == null) {
/* 1581 */       createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
/*      */     }
/*      */ 
/* 1585 */     for (int i = 0; i < 20; i++)
/* 1586 */       if (histogramBreakpoints[i] >= value) {
/* 1587 */         histogramCounts[i] += numberOfTimes;
/*      */ 
/* 1589 */         break;
/*      */       }
/*      */   }
/*      */ 
/*      */   private void addToPerformanceHistogram(long value, int numberOfTimes)
/*      */   {
/* 1595 */     checkAndCreatePerformanceHistogram();
/*      */ 
/* 1597 */     addToHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, value, numberOfTimes, this.shortestQueryTimeMs == 9223372036854775807L ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */ 
/*      */   private void addToTablesAccessedHistogram(long value, int numberOfTimes)
/*      */   {
/* 1604 */     checkAndCreateTablesAccessedHistogram();
/*      */ 
/* 1606 */     addToHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, value, numberOfTimes, this.minimumNumberTablesAccessed == 9223372036854775807L ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */ 
/*      */   private void buildCollationMapping()
/*      */     throws SQLException
/*      */   {
/* 1621 */     if (versionMeetsMinimum(4, 1, 0))
/*      */     {
/* 1623 */       TreeMap sortedCollationMap = null;
/*      */ 
/* 1625 */       if (getCacheServerConfiguration()) {
/* 1626 */         synchronized (serverConfigByUrl) {
/* 1627 */           sortedCollationMap = (TreeMap)serverCollationByUrl.get(getURL());
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1632 */       Statement stmt = null;
/* 1633 */       ResultSet results = null;
/*      */       try
/*      */       {
/* 1636 */         if (sortedCollationMap == null) {
/* 1637 */           sortedCollationMap = new TreeMap();
/*      */ 
/* 1639 */           stmt = (Statement)createStatement();
/*      */ 
/* 1641 */           if (stmt.getMaxRows() != 0) {
/* 1642 */             stmt.setMaxRows(0);
/*      */           }
/*      */ 
/* 1645 */           results = (ResultSet)stmt.executeQuery("SHOW COLLATION");
/*      */ 
/* 1648 */           while (results.next()) {
/* 1649 */             String charsetName = results.getString(2);
/* 1650 */             Integer charsetIndex = new Integer(results.getInt(3));
/*      */ 
/* 1652 */             sortedCollationMap.put(charsetIndex, charsetName);
/*      */           }
/*      */ 
/* 1655 */           if (getCacheServerConfiguration()) {
/* 1656 */             synchronized (serverConfigByUrl) {
/* 1657 */               serverCollationByUrl.put(getURL(), sortedCollationMap);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1665 */         int highestIndex = ((Integer)sortedCollationMap.lastKey()).intValue();
/*      */ 
/* 1668 */         if (CharsetMapping.INDEX_TO_CHARSET.length > highestIndex) {
/* 1669 */           highestIndex = CharsetMapping.INDEX_TO_CHARSET.length;
/*      */         }
/*      */ 
/* 1672 */         this.indexToCharsetMapping = new String[highestIndex + 1];
/*      */ 
/* 1674 */         for (int i = 0; i < CharsetMapping.INDEX_TO_CHARSET.length; i++) {
/* 1675 */           this.indexToCharsetMapping[i] = CharsetMapping.INDEX_TO_CHARSET[i];
/*      */         }
/*      */ 
/* 1678 */         Iterator indexIter = sortedCollationMap.entrySet().iterator();
/* 1679 */         while (indexIter.hasNext()) {
/* 1680 */           Map.Entry indexEntry = (Map.Entry)indexIter.next();
/*      */ 
/* 1682 */           String mysqlCharsetName = (String)indexEntry.getValue();
/*      */ 
/* 1684 */           this.indexToCharsetMapping[((Integer)indexEntry.getKey()).intValue()] = CharsetMapping.getJavaEncodingForMysqlEncoding(mysqlCharsetName, this);
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (SQLException e)
/*      */       {
/* 1690 */         throw e;
/*      */       } finally {
/* 1692 */         if (results != null) {
/*      */           try {
/* 1694 */             results.close();
/*      */           }
/*      */           catch (SQLException sqlE)
/*      */           {
/*      */           }
/*      */         }
/* 1700 */         if (stmt != null)
/*      */           try {
/* 1702 */             stmt.close();
/*      */           }
/*      */           catch (SQLException sqlE)
/*      */           {
/*      */           }
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 1711 */       this.indexToCharsetMapping = CharsetMapping.INDEX_TO_CHARSET;
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean canHandleAsServerPreparedStatement(String sql) throws SQLException
/*      */   {
/* 1717 */     if ((sql == null) || (sql.length() == 0)) {
/* 1718 */       return true;
/*      */     }
/*      */ 
/* 1721 */     if (getCachePreparedStatements()) {
/* 1722 */       synchronized (this.serverSideStatementCheckCache) {
/* 1723 */         Boolean flag = (Boolean)this.serverSideStatementCheckCache.get(sql);
/*      */ 
/* 1725 */         if (flag != null) {
/* 1726 */           return flag.booleanValue();
/*      */         }
/*      */ 
/* 1729 */         boolean canHandle = canHandleAsServerPreparedStatementNoCache(sql);
/*      */ 
/* 1731 */         if (sql.length() < getPreparedStatementCacheSqlLimit()) {
/* 1732 */           this.serverSideStatementCheckCache.put(sql, canHandle ? Boolean.TRUE : Boolean.FALSE);
/*      */         }
/*      */ 
/* 1736 */         return canHandle;
/*      */       }
/*      */     }
/*      */ 
/* 1740 */     return canHandleAsServerPreparedStatementNoCache(sql);
/*      */   }
/*      */ 
/*      */   private boolean canHandleAsServerPreparedStatementNoCache(String sql)
/*      */     throws SQLException
/*      */   {
/* 1747 */     if (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "CALL")) {
/* 1748 */       return false;
/*      */     }
/*      */ 
/* 1751 */     boolean canHandleAsStatement = true;
/*      */ 
/* 1753 */     if ((!versionMeetsMinimum(5, 0, 7)) && ((StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "SELECT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndNonAlphaNumeric(sql, "REPLACE"))))
/*      */     {
/* 1771 */       int currentPos = 0;
/* 1772 */       int statementLength = sql.length();
/* 1773 */       int lastPosToLook = statementLength - 7;
/* 1774 */       boolean allowBackslashEscapes = !this.noBackslashEscapes;
/* 1775 */       char quoteChar = this.useAnsiQuotes ? '"' : '\'';
/* 1776 */       boolean foundLimitWithPlaceholder = false;
/*      */ 
/* 1778 */       while (currentPos < lastPosToLook) {
/* 1779 */         int limitStart = StringUtils.indexOfIgnoreCaseRespectQuotes(currentPos, sql, "LIMIT ", quoteChar, allowBackslashEscapes);
/*      */ 
/* 1783 */         if (limitStart == -1)
/*      */         {
/*      */           break;
/*      */         }
/* 1787 */         currentPos = limitStart + 7;
/*      */ 
/* 1789 */         while (currentPos < statementLength) {
/* 1790 */           char c = sql.charAt(currentPos);
/*      */ 
/* 1797 */           if ((!Character.isDigit(c)) && (!Character.isWhitespace(c)) && (c != ',') && (c != '?'))
/*      */           {
/*      */             break;
/*      */           }
/*      */ 
/* 1802 */           if (c == '?') {
/* 1803 */             foundLimitWithPlaceholder = true;
/* 1804 */             break;
/*      */           }
/*      */ 
/* 1807 */           currentPos++;
/*      */         }
/*      */       }
/*      */ 
/* 1811 */       canHandleAsStatement = !foundLimitWithPlaceholder;
/* 1812 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE TABLE")) {
/* 1813 */       canHandleAsStatement = false;
/* 1814 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "DO")) {
/* 1815 */       canHandleAsStatement = false;
/* 1816 */     } else if (StringUtils.startsWithIgnoreCaseAndWs(sql, "SET")) {
/* 1817 */       canHandleAsStatement = false;
/*      */     }
/*      */ 
/* 1822 */     return canHandleAsStatement;
/*      */   }
/*      */ 
/*      */   public void changeUser(String userName, String newPassword)
/*      */     throws SQLException
/*      */   {
/* 1840 */     if ((userName == null) || (userName.equals(""))) {
/* 1841 */       userName = "";
/*      */     }
/*      */ 
/* 1844 */     if (newPassword == null) {
/* 1845 */       newPassword = "";
/*      */     }
/*      */ 
/* 1848 */     this.io.changeUser(userName, newPassword, this.database);
/* 1849 */     this.user = userName;
/* 1850 */     this.password = newPassword;
/*      */ 
/* 1852 */     if (versionMeetsMinimum(4, 1, 0)) {
/* 1853 */       configureClientCharacterSet();
/*      */     }
/*      */ 
/* 1856 */     setupServerForTruncationChecks();
/*      */   }
/*      */ 
/*      */   private void checkAndCreatePerformanceHistogram() {
/* 1860 */     if (this.perfMetricsHistCounts == null) {
/* 1861 */       this.perfMetricsHistCounts = new int[20];
/*      */     }
/*      */ 
/* 1864 */     if (this.perfMetricsHistBreakpoints == null)
/* 1865 */       this.perfMetricsHistBreakpoints = new long[20];
/*      */   }
/*      */ 
/*      */   private void checkAndCreateTablesAccessedHistogram()
/*      */   {
/* 1870 */     if (this.numTablesMetricsHistCounts == null) {
/* 1871 */       this.numTablesMetricsHistCounts = new int[20];
/*      */     }
/*      */ 
/* 1874 */     if (this.numTablesMetricsHistBreakpoints == null)
/* 1875 */       this.numTablesMetricsHistBreakpoints = new long[20];
/*      */   }
/*      */ 
/*      */   private void checkClosed() throws SQLException
/*      */   {
/* 1880 */     if (this.isClosed) {
/* 1881 */       StringBuffer messageBuf = new StringBuffer("No operations allowed after connection closed.");
/*      */ 
/* 1884 */       if ((this.forcedClosedLocation != null) || (this.forceClosedReason != null)) {
/* 1885 */         messageBuf.append("Connection was implicitly closed ");
/*      */       }
/*      */ 
/* 1889 */       if (this.forcedClosedLocation != null) {
/* 1890 */         messageBuf.append("\n\n");
/* 1891 */         messageBuf.append(" at (stack trace):\n");
/*      */ 
/* 1893 */         messageBuf.append(Util.stackTraceToString(this.forcedClosedLocation));
/*      */       }
/*      */ 
/* 1897 */       if (this.forceClosedReason != null) {
/* 1898 */         if (this.forcedClosedLocation != null)
/* 1899 */           messageBuf.append("\n\nDue ");
/*      */         else {
/* 1901 */           messageBuf.append("due ");
/*      */         }
/*      */ 
/* 1904 */         messageBuf.append("to underlying exception/error:\n");
/* 1905 */         messageBuf.append(Util.stackTraceToString(this.forceClosedReason));
/*      */       }
/*      */ 
/* 1909 */       throw SQLError.createSQLException(messageBuf.toString(), "08003");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkServerEncoding()
/*      */     throws SQLException
/*      */   {
/* 1922 */     if ((getUseUnicode()) && (getEncoding() != null))
/*      */     {
/* 1924 */       return;
/*      */     }
/*      */ 
/* 1927 */     String serverEncoding = (String)this.serverVariables.get("character_set");
/*      */ 
/* 1930 */     if (serverEncoding == null)
/*      */     {
/* 1932 */       serverEncoding = (String)this.serverVariables.get("character_set_server");
/*      */     }
/*      */ 
/* 1936 */     String mappedServerEncoding = null;
/*      */ 
/* 1938 */     if (serverEncoding != null) {
/* 1939 */       mappedServerEncoding = CharsetMapping.getJavaEncodingForMysqlEncoding(serverEncoding.toUpperCase(Locale.ENGLISH), this);
/*      */     }
/*      */ 
/* 1947 */     if ((!getUseUnicode()) && (mappedServerEncoding != null)) {
/* 1948 */       SingleByteCharsetConverter converter = getCharsetConverter(mappedServerEncoding);
/*      */ 
/* 1950 */       if (converter != null) {
/* 1951 */         setUseUnicode(true);
/* 1952 */         setEncoding(mappedServerEncoding);
/*      */ 
/* 1954 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1962 */     if (serverEncoding != null) {
/* 1963 */       if (mappedServerEncoding == null)
/*      */       {
/* 1966 */         if (Character.isLowerCase(serverEncoding.charAt(0))) {
/* 1967 */           char[] ach = serverEncoding.toCharArray();
/* 1968 */           ach[0] = Character.toUpperCase(serverEncoding.charAt(0));
/* 1969 */           setEncoding(new String(ach));
/*      */         }
/*      */       }
/*      */ 
/* 1973 */       if (mappedServerEncoding == null) {
/* 1974 */         throw SQLError.createSQLException("Unknown character encoding on server '" + serverEncoding + "', use 'characterEncoding=' property " + " to provide correct mapping", "01S00");
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1986 */         "abc".getBytes(mappedServerEncoding);
/* 1987 */         setEncoding(mappedServerEncoding);
/* 1988 */         setUseUnicode(true);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 1990 */         throw SQLError.createSQLException("The driver can not map the character encoding '" + getEncoding() + "' that your server is using " + "to a character encoding your JVM understands. You " + "can specify this mapping manually by adding \"useUnicode=true\" " + "as well as \"characterEncoding=[an_encoding_your_jvm_understands]\" " + "to your JDBC URL.", "0S100");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void checkTransactionIsolationLevel()
/*      */     throws SQLException
/*      */   {
/* 2010 */     String txIsolationName = null;
/*      */ 
/* 2012 */     if (versionMeetsMinimum(4, 0, 3))
/* 2013 */       txIsolationName = "tx_isolation";
/*      */     else {
/* 2015 */       txIsolationName = "transaction_isolation";
/*      */     }
/*      */ 
/* 2018 */     String s = (String)this.serverVariables.get(txIsolationName);
/*      */ 
/* 2020 */     if (s != null) {
/* 2021 */       Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */ 
/* 2023 */       if (intTI != null)
/* 2024 */         this.isolationLevel = intTI.intValue();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void cleanup(Throwable whyCleanedUp)
/*      */   {
/*      */     try
/*      */     {
/* 2039 */       if ((this.io != null) && (!isClosed()))
/* 2040 */         realClose(false, false, false, whyCleanedUp);
/* 2041 */       else if (this.io != null) {
/* 2042 */         this.io.forceClose();
/*      */       }
/*      */     }
/*      */     catch (SQLException sqlEx)
/*      */     {
/*      */     }
/*      */ 
/* 2049 */     this.isClosed = true;
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*      */   }
/*      */ 
/*      */   public PreparedStatement clientPrepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 2074 */     return clientPrepareStatement(sql, 1005, 1007);
/*      */   }
/*      */ 
/*      */   public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 2094 */     return clientPrepareStatement(sql, resultSetType, resultSetConcurrency, true);
/*      */   }
/*      */ 
/*      */   protected PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, boolean processEscapeCodesIfNeeded)
/*      */     throws SQLException
/*      */   {
/* 2100 */     checkClosed();
/*      */ 
/* 2102 */     String nativeSql = (processEscapeCodesIfNeeded) && (getProcessEscapeCodesForPrepStmts()) ? nativeSQL(sql) : sql;
/*      */ 
/* 2104 */     PreparedStatement pStmt = null;
/*      */ 
/* 2106 */     if (getCachePreparedStatements()) {
/* 2107 */       synchronized (this.cachedPreparedStatementParams) {
/* 2108 */         PreparedStatement.ParseInfo pStmtInfo = (PreparedStatement.ParseInfo)this.cachedPreparedStatementParams.get(nativeSql);
/*      */ 
/* 2111 */         if (pStmtInfo == null) {
/* 2112 */           pStmt = new PreparedStatement(this, nativeSql, this.database);
/*      */ 
/* 2115 */           PreparedStatement.ParseInfo parseInfo = pStmt.getParseInfo();
/*      */ 
/* 2117 */           if (parseInfo.statementLength < getPreparedStatementCacheSqlLimit()) {
/* 2118 */             if (this.cachedPreparedStatementParams.size() >= getPreparedStatementCacheSize()) {
/* 2119 */               Iterator oldestIter = this.cachedPreparedStatementParams.keySet().iterator();
/*      */ 
/* 2121 */               long lruTime = 9223372036854775807L;
/* 2122 */               String oldestSql = null;
/*      */ 
/* 2124 */               while (oldestIter.hasNext()) {
/* 2125 */                 String sqlKey = (String)oldestIter.next();
/* 2126 */                 PreparedStatement.ParseInfo lruInfo = (PreparedStatement.ParseInfo)this.cachedPreparedStatementParams.get(sqlKey);
/*      */ 
/* 2129 */                 if (lruInfo.lastUsed < lruTime) {
/* 2130 */                   lruTime = lruInfo.lastUsed;
/* 2131 */                   oldestSql = sqlKey;
/*      */                 }
/*      */               }
/*      */ 
/* 2135 */               if (oldestSql != null) {
/* 2136 */                 this.cachedPreparedStatementParams.remove(oldestSql);
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2141 */             this.cachedPreparedStatementParams.put(nativeSql, pStmt.getParseInfo());
/*      */           }
/*      */         }
/*      */         else {
/* 2145 */           pStmtInfo.lastUsed = System.currentTimeMillis();
/* 2146 */           pStmt = new PreparedStatement(this, nativeSql, this.database, pStmtInfo);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2151 */     pStmt = new PreparedStatement(this, nativeSql, this.database);
/*      */ 
/* 2155 */     pStmt.setResultSetType(resultSetType);
/* 2156 */     pStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */ 
/* 2158 */     return pStmt;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/* 2172 */     realClose(true, true, false, null);
/*      */   }
/*      */ 
/*      */   private void closeAllOpenStatements()
/*      */     throws SQLException
/*      */   {
/* 2182 */     SQLException postponedException = null;
/*      */ 
/* 2184 */     if (this.openStatements != null) {
/* 2185 */       List currentlyOpenStatements = new ArrayList();
/*      */ 
/* 2189 */       Iterator iter = this.openStatements.keySet().iterator();
/* 2190 */       while (iter.hasNext()) {
/* 2191 */         currentlyOpenStatements.add(iter.next());
/*      */       }
/*      */ 
/* 2194 */       int numStmts = currentlyOpenStatements.size();
/*      */ 
/* 2196 */       for (int i = 0; i < numStmts; i++) {
/* 2197 */         Statement stmt = (Statement)currentlyOpenStatements.get(i);
/*      */         try
/*      */         {
/* 2200 */           stmt.realClose(false, true);
/*      */         } catch (SQLException sqlEx) {
/* 2202 */           postponedException = sqlEx;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2207 */       if (postponedException != null)
/* 2208 */         throw postponedException;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void closeStatement(java.sql.Statement stmt)
/*      */   {
/* 2214 */     if (stmt != null) {
/*      */       try {
/* 2216 */         stmt.close();
/*      */       }
/*      */       catch (SQLException sqlEx)
/*      */       {
/*      */       }
/* 2221 */       stmt = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void commit()
/*      */     throws SQLException
/*      */   {
/* 2242 */     synchronized (getMutex()) {
/* 2243 */       checkClosed();
/*      */       try
/*      */       {
/* 2247 */         if ((this.autoCommit) && (!getRelaxAutoCommit()))
/* 2248 */           throw SQLError.createSQLException("Can't call commit when autocommit=true");
/* 2249 */         if (this.transactionsSupported) {
/* 2250 */           execSQL(null, "commit", -1, null, 1003, 1007, false, this.database, true, false);
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (SQLException sqlException)
/*      */       {
/* 2257 */         if ("08S01".equals(sqlException.getSQLState()))
/*      */         {
/* 2259 */           throw SQLError.createSQLException("Communications link failure during commit(). Transaction resolution unknown.", "08007");
/*      */         }
/*      */ 
/* 2264 */         throw sqlException;
/*      */       } finally {
/* 2266 */         this.needsPing = getReconnectAtTxEnd();
/*      */       }
/*      */ 
/* 2269 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void configureCharsetProperties()
/*      */     throws SQLException
/*      */   {
/* 2280 */     if (getEncoding() != null)
/*      */     {
/*      */       try
/*      */       {
/* 2284 */         String testString = "abc";
/* 2285 */         testString.getBytes(getEncoding());
/*      */       }
/*      */       catch (UnsupportedEncodingException UE) {
/* 2288 */         String oldEncoding = getEncoding();
/*      */ 
/* 2290 */         setEncoding(CharsetMapping.getJavaEncodingForMysqlEncoding(oldEncoding, this));
/*      */ 
/* 2293 */         if (getEncoding() == null) {
/* 2294 */           throw SQLError.createSQLException("Java does not support the MySQL character encoding  encoding '" + oldEncoding + "'.", "01S00");
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/* 2301 */           String testString = "abc";
/* 2302 */           testString.getBytes(getEncoding());
/*      */         } catch (UnsupportedEncodingException encodingEx) {
/* 2304 */           throw SQLError.createSQLException("Unsupported character encoding '" + getEncoding() + "'.", "01S00");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean configureClientCharacterSet()
/*      */     throws SQLException
/*      */   {
/* 2326 */     String realJavaEncoding = getEncoding();
/* 2327 */     boolean characterSetAlreadyConfigured = false;
/*      */     try
/*      */     {
/* 2330 */       if (versionMeetsMinimum(4, 1, 0)) {
/* 2331 */         characterSetAlreadyConfigured = true;
/*      */ 
/* 2333 */         setUseUnicode(true);
/*      */ 
/* 2335 */         configureCharsetProperties();
/* 2336 */         realJavaEncoding = getEncoding();
/*      */         try
/*      */         {
/* 2341 */           String serverEncodingToSet = CharsetMapping.INDEX_TO_CHARSET[this.io.serverCharsetIndex];
/*      */ 
/* 2344 */           if ((serverEncodingToSet == null) || (serverEncodingToSet.length() == 0)) {
/* 2345 */             throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000");
/*      */           }
/*      */ 
/* 2352 */           if ((versionMeetsMinimum(4, 1, 0)) && ("ISO8859_1".equalsIgnoreCase(serverEncodingToSet)))
/*      */           {
/* 2354 */             serverEncodingToSet = "Cp1252";
/*      */           }
/*      */ 
/* 2357 */           setEncoding(serverEncodingToSet);
/*      */         } catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 2359 */           if (realJavaEncoding != null)
/*      */           {
/* 2361 */             setEncoding(realJavaEncoding);
/*      */           }
/* 2363 */           else throw SQLError.createSQLException("Unknown initial character set index '" + this.io.serverCharsetIndex + "' received from server. Initial client character set can be forced via the 'characterEncoding' property.", "S1000");
/*      */ 
/*      */         }
/*      */ 
/* 2371 */         if (getEncoding() == null)
/*      */         {
/* 2373 */           setEncoding("ISO8859_1");
/*      */         }
/*      */ 
/* 2380 */         if (getUseUnicode()) {
/* 2381 */           if (realJavaEncoding != null)
/*      */           {
/* 2387 */             if ((realJavaEncoding.equalsIgnoreCase("UTF-8")) || (realJavaEncoding.equalsIgnoreCase("UTF8")))
/*      */             {
/* 2391 */               if (!getUseOldUTF8Behavior()) {
/* 2392 */                 execSQL(null, "SET NAMES utf8", -1, null, 1003, 1007, false, this.database, true, false);
/*      */               }
/*      */ 
/* 2398 */               setEncoding(realJavaEncoding);
/*      */             } else {
/* 2400 */               String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), this);
/*      */ 
/* 2415 */               if (mysqlEncodingName != null) {
/* 2416 */                 execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, true, false);
/*      */               }
/*      */ 
/* 2426 */               setEncoding(realJavaEncoding);
/*      */             }
/* 2428 */           } else if (getEncoding() != null)
/*      */           {
/* 2432 */             String mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(getEncoding().toUpperCase(Locale.ENGLISH), this);
/*      */ 
/* 2436 */             execSQL(null, "SET NAMES " + mysqlEncodingName, -1, null, 1003, 1007, false, this.database, true, false);
/*      */ 
/* 2441 */             realJavaEncoding = getEncoding();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2452 */         if (getCharacterSetResults() == null) {
/* 2453 */           execSQL(null, "SET character_set_results = NULL", -1, null, 1003, 1007, false, this.database, true, false);
/*      */         }
/*      */         else
/*      */         {
/* 2459 */           String charsetResults = getCharacterSetResults();
/* 2460 */           String mysqlEncodingName = null;
/*      */ 
/* 2462 */           if (("UTF-8".equalsIgnoreCase(charsetResults)) || ("UTF8".equalsIgnoreCase(charsetResults)))
/*      */           {
/* 2464 */             mysqlEncodingName = "utf8";
/*      */           }
/* 2466 */           else mysqlEncodingName = CharsetMapping.getMysqlEncodingForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), this);
/*      */ 
/* 2471 */           StringBuffer setBuf = new StringBuffer("SET character_set_results = ".length() + mysqlEncodingName.length());
/*      */ 
/* 2474 */           setBuf.append("SET character_set_results = ").append(mysqlEncodingName);
/*      */ 
/* 2477 */           execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, true, false);
/*      */         }
/*      */ 
/* 2483 */         if (getConnectionCollation() != null) {
/* 2484 */           StringBuffer setBuf = new StringBuffer("SET collation_connection = ".length() + getConnectionCollation().length());
/*      */ 
/* 2487 */           setBuf.append("SET collation_connection = ").append(getConnectionCollation());
/*      */ 
/* 2490 */           execSQL(null, setBuf.toString(), -1, null, 1003, 1007, false, this.database, true, false);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2497 */         realJavaEncoding = getEncoding();
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 2505 */       setEncoding(realJavaEncoding);
/*      */     }
/*      */ 
/* 2508 */     return characterSetAlreadyConfigured;
/*      */   }
/*      */ 
/*      */   private void configureTimezone()
/*      */     throws SQLException
/*      */   {
/* 2519 */     String configuredTimeZoneOnServer = (String)this.serverVariables.get("timezone");
/*      */ 
/* 2522 */     if (configuredTimeZoneOnServer == null) {
/* 2523 */       configuredTimeZoneOnServer = (String)this.serverVariables.get("time_zone");
/*      */ 
/* 2526 */       if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
/* 2527 */         configuredTimeZoneOnServer = (String)this.serverVariables.get("system_time_zone");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2532 */     if ((getUseTimezone()) && (configuredTimeZoneOnServer != null))
/*      */     {
/* 2534 */       String canoncicalTimezone = getServerTimezone();
/*      */ 
/* 2536 */       if ((canoncicalTimezone == null) || (canoncicalTimezone.length() == 0))
/*      */       {
/* 2538 */         String serverTimezoneStr = configuredTimeZoneOnServer;
/*      */         try
/*      */         {
/* 2541 */           canoncicalTimezone = TimeUtil.getCanoncialTimezone(serverTimezoneStr);
/*      */ 
/* 2544 */           if (canoncicalTimezone == null) {
/* 2545 */             throw SQLError.createSQLException("Can't map timezone '" + serverTimezoneStr + "' to " + " canonical timezone.", "S1009");
/*      */           }
/*      */ 
/*      */         }
/*      */         catch (IllegalArgumentException iae)
/*      */         {
/* 2551 */           throw SQLError.createSQLException(iae.getMessage(), "S1000");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2556 */       this.serverTimezoneTZ = TimeZone.getTimeZone(canoncicalTimezone);
/*      */ 
/* 2563 */       if ((!canoncicalTimezone.equalsIgnoreCase("GMT")) && (this.serverTimezoneTZ.getID().equals("GMT")))
/*      */       {
/* 2565 */         throw SQLError.createSQLException("No timezone mapping entry for '" + canoncicalTimezone + "'", "S1009");
/*      */       }
/*      */ 
/* 2570 */       if ("GMT".equalsIgnoreCase(this.serverTimezoneTZ.getID()))
/* 2571 */         this.isServerTzUTC = true;
/*      */       else
/* 2573 */         this.isServerTzUTC = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound)
/*      */   {
/* 2581 */     double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
/*      */ 
/* 2583 */     if (bucketSize < 1.0D) {
/* 2584 */       bucketSize = 1.0D;
/*      */     }
/*      */ 
/* 2587 */     for (int i = 0; i < 20; i++) {
/* 2588 */       breakpoints[i] = lowerBound;
/* 2589 */       lowerBound = ()(lowerBound + bucketSize);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected MysqlIO createNewIO(boolean isForReconnect)
/*      */     throws SQLException
/*      */   {
/* 2606 */     MysqlIO newIo = null;
/*      */ 
/* 2608 */     Properties mergedProps = new Properties();
/*      */ 
/* 2610 */     mergedProps = exposeAsProperties(this.props);
/*      */ 
/* 2612 */     long queriesIssuedFailedOverCopy = this.queriesIssuedFailedOver;
/* 2613 */     this.queriesIssuedFailedOver = 0L;
/*      */     try
/*      */     {
/* 2616 */       if ((!getHighAvailability()) && (!this.failedOver)) {
/* 2617 */         boolean connectionGood = false;
/* 2618 */         Exception connectionNotEstablishedBecause = null;
/*      */ 
/* 2620 */         int hostIndex = 0;
/*      */ 
/* 2628 */         if (getRoundRobinLoadBalance()) {
/* 2629 */           hostIndex = getNextRoundRobinHostIndex(getURL(), this.hostList);
/*      */         }
/*      */ 
/* 2633 */         for (; hostIndex < this.hostListSize; hostIndex++)
/*      */         {
/* 2635 */           if (hostIndex == 0) {
/* 2636 */             this.hasTriedMasterFlag = true;
/*      */           }
/*      */           try
/*      */           {
/* 2640 */             String newHostPortPair = (String)this.hostList.get(hostIndex);
/*      */ 
/* 2643 */             int newPort = 3306;
/*      */ 
/* 2645 */             String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(newHostPortPair);
/*      */ 
/* 2647 */             String newHost = hostPortPair[0];
/*      */ 
/* 2649 */             if ((newHost == null) || (newHost.trim().length() == 0)) {
/* 2650 */               newHost = "localhost";
/*      */             }
/*      */ 
/* 2653 */             if (hostPortPair[1] != null) {
/*      */               try {
/* 2655 */                 newPort = Integer.parseInt(hostPortPair[1]);
/*      */               }
/*      */               catch (NumberFormatException nfe) {
/* 2658 */                 throw SQLError.createSQLException("Illegal connection port value '" + hostPortPair[1] + "'", "01S00");
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2666 */             this.io = new MysqlIO(newHost, newPort, mergedProps, getSocketFactoryClassName(), this, getSocketTimeout());
/*      */ 
/* 2670 */             this.io.doHandshake(this.user, this.password, this.database);
/*      */ 
/* 2672 */             this.isClosed = false;
/*      */ 
/* 2675 */             boolean oldAutoCommit = getAutoCommit();
/* 2676 */             int oldIsolationLevel = this.isolationLevel;
/* 2677 */             boolean oldReadOnly = isReadOnly();
/* 2678 */             String oldCatalog = getCatalog();
/*      */ 
/* 2683 */             initializePropsFromServer();
/*      */ 
/* 2685 */             if (isForReconnect)
/*      */             {
/* 2687 */               setAutoCommit(oldAutoCommit);
/*      */ 
/* 2689 */               if (this.hasIsolationLevels) {
/* 2690 */                 setTransactionIsolation(oldIsolationLevel);
/*      */               }
/*      */ 
/* 2693 */               setCatalog(oldCatalog);
/*      */             }
/*      */ 
/* 2696 */             if (hostIndex != 0) {
/* 2697 */               setFailedOverState();
/* 2698 */               queriesIssuedFailedOverCopy = 0L;
/*      */             } else {
/* 2700 */               this.failedOver = false;
/* 2701 */               queriesIssuedFailedOverCopy = 0L;
/*      */ 
/* 2703 */               if (this.hostListSize > 1)
/* 2704 */                 setReadOnly(false);
/*      */               else {
/* 2706 */                 setReadOnly(oldReadOnly);
/*      */               }
/*      */             }
/*      */ 
/* 2710 */             connectionGood = true;
/*      */           }
/*      */           catch (Exception EEE)
/*      */           {
/* 2714 */             if (this.io != null) {
/* 2715 */               this.io.forceClose();
/*      */             }
/*      */ 
/* 2718 */             connectionNotEstablishedBecause = EEE;
/*      */ 
/* 2720 */             connectionGood = false;
/*      */ 
/* 2722 */             if ((EEE instanceof SQLException)) {
/* 2723 */               SQLException sqlEx = (SQLException)EEE;
/*      */ 
/* 2725 */               String sqlState = sqlEx.getSQLState();
/*      */ 
/* 2729 */               if ((sqlState == null) || (!sqlState.equals("08S01")))
/*      */               {
/* 2732 */                 throw sqlEx;
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 2737 */             if (getRoundRobinLoadBalance()) {
/* 2738 */               hostIndex = getNextRoundRobinHostIndex(getURL(), this.hostList) - 1;
/*      */             }
/* 2740 */             else if (this.hostListSize - 1 == hostIndex) {
/* 2741 */               throw new CommunicationsException(this, this.io != null ? this.io.getLastPacketSentTimeMs() : 0L, EEE);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2749 */         if (!connectionGood)
/*      */         {
/* 2751 */           throw SQLError.createSQLException("Could not create connection to database server due to underlying exception: '" + connectionNotEstablishedBecause + "'." + (getParanoid() ? "" : Util.stackTraceToString(connectionNotEstablishedBecause)), "08001");
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 2761 */         double timeout = getInitialTimeout();
/* 2762 */         boolean connectionGood = false;
/*      */ 
/* 2764 */         Exception connectionException = null;
/*      */ 
/* 2766 */         int hostIndex = 0;
/*      */ 
/* 2768 */         if (getRoundRobinLoadBalance()) {
/* 2769 */           hostIndex = getNextRoundRobinHostIndex(getURL(), this.hostList);
/*      */         }
/*      */ 
/* 2773 */         for (; (hostIndex < this.hostListSize) && (!connectionGood); hostIndex++) {
/* 2774 */           if (hostIndex == 0) {
/* 2775 */             this.hasTriedMasterFlag = true;
/*      */           }
/*      */ 
/* 2778 */           if ((this.preferSlaveDuringFailover) && (hostIndex == 0)) {
/* 2779 */             hostIndex++;
/*      */           }
/*      */ 
/* 2782 */           int attemptCount = 0;
/*      */           while (true) if ((attemptCount < getMaxReconnects()) && (!connectionGood)) {
/*      */               try {
/* 2785 */                 if (this.io != null) {
/* 2786 */                   this.io.forceClose();
/*      */                 }
/*      */ 
/* 2789 */                 String newHostPortPair = (String)this.hostList.get(hostIndex);
/*      */ 
/* 2792 */                 int newPort = 3306;
/*      */ 
/* 2794 */                 String[] hostPortPair = NonRegisteringDriver.parseHostPortPair(newHostPortPair);
/*      */ 
/* 2796 */                 String newHost = hostPortPair[0];
/*      */ 
/* 2798 */                 if ((newHost == null) || (newHost.trim().length() == 0)) {
/* 2799 */                   newHost = "localhost";
/*      */                 }
/*      */ 
/* 2802 */                 if (hostPortPair[1] != null) {
/*      */                   try {
/* 2804 */                     newPort = Integer.parseInt(hostPortPair[1]);
/*      */                   }
/*      */                   catch (NumberFormatException nfe) {
/* 2807 */                     throw SQLError.createSQLException("Illegal connection port value '" + hostPortPair[1] + "'", "01S00");
/*      */                   }
/*      */ 
/*      */                 }
/*      */ 
/* 2815 */                 this.io = new MysqlIO(newHost, newPort, mergedProps, getSocketFactoryClassName(), this, getSocketTimeout());
/*      */ 
/* 2818 */                 this.io.doHandshake(this.user, this.password, this.database);
/*      */ 
/* 2821 */                 pingInternal(false);
/* 2822 */                 this.isClosed = false;
/*      */ 
/* 2825 */                 boolean oldAutoCommit = getAutoCommit();
/* 2826 */                 int oldIsolationLevel = this.isolationLevel;
/* 2827 */                 boolean oldReadOnly = isReadOnly();
/* 2828 */                 String oldCatalog = getCatalog();
/*      */ 
/* 2833 */                 initializePropsFromServer();
/*      */ 
/* 2835 */                 if (isForReconnect)
/*      */                 {
/* 2837 */                   setAutoCommit(oldAutoCommit);
/*      */ 
/* 2839 */                   if (this.hasIsolationLevels) {
/* 2840 */                     setTransactionIsolation(oldIsolationLevel);
/*      */                   }
/*      */ 
/* 2843 */                   setCatalog(oldCatalog);
/*      */                 }
/*      */ 
/* 2846 */                 connectionGood = true;
/*      */ 
/* 2848 */                 if (hostIndex != 0) {
/* 2849 */                   setFailedOverState();
/* 2850 */                   queriesIssuedFailedOverCopy = 0L;
/*      */                 } else {
/* 2852 */                   this.failedOver = false;
/* 2853 */                   queriesIssuedFailedOverCopy = 0L;
/*      */ 
/* 2855 */                   if (this.hostListSize > 1)
/* 2856 */                     setReadOnly(false);
/*      */                   else {
/* 2858 */                     setReadOnly(oldReadOnly);
/*      */                   }
/*      */                 }
/*      */               }
/*      */               catch (Exception IE)
/*      */               {
/* 2864 */                 connectionException = EEE;
/* 2865 */                 connectionGood = false;
/*      */ 
/* 2868 */                 if (getRoundRobinLoadBalance()) {
/* 2869 */                   hostIndex = getNextRoundRobinHostIndex(getURL(), this.hostList) - 1;
/*      */                 }
/*      */ 
/* 2874 */                 if (!connectionGood)
/*      */                 {
/* 2878 */                   if (attemptCount > 0)
/*      */                     try {
/* 2880 */                       Thread.sleep(()timeout * 1000L);
/*      */                     }
/*      */                     catch (InterruptedException IE)
/*      */                     {
/*      */                     }
/* 2783 */                   attemptCount++; continue;
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */ 
/*      */         }
/*      */ 
/* 2888 */         if (!connectionGood)
/*      */         {
/* 2890 */           throw SQLError.createSQLException("Server connection failure during transaction. Due to underlying exception: '" + connectionException + "'." + (getParanoid() ? "" : Util.stackTraceToString(connectionException)) + "\nAttempted reconnect " + getMaxReconnects() + " times. Giving up.", "08001");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2903 */       if ((getParanoid()) && (!getHighAvailability()) && (this.hostListSize <= 1))
/*      */       {
/* 2905 */         this.password = null;
/* 2906 */         this.user = null;
/*      */       }
/*      */ 
/* 2909 */       if (isForReconnect)
/*      */       {
/* 2913 */         statementIter = this.openStatements.values().iterator();
/*      */ 
/* 2925 */         Stack serverPreparedStatements = null;
/*      */ 
/* 2927 */         while (statementIter.hasNext()) {
/* 2928 */           Object statementObj = statementIter.next();
/*      */ 
/* 2930 */           if ((statementObj instanceof ServerPreparedStatement)) {
/* 2931 */             if (serverPreparedStatements == null) {
/* 2932 */               serverPreparedStatements = new Stack();
/*      */             }
/*      */ 
/* 2935 */             serverPreparedStatements.add(statementObj);
/*      */           }
/*      */         }
/*      */ 
/* 2939 */         if (serverPreparedStatements != null) {
/* 2940 */           while (!serverPreparedStatements.isEmpty()) {
/* 2941 */             ((ServerPreparedStatement)serverPreparedStatements.pop()).rePrepare();
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2947 */       Iterator statementIter = newIo;
/*      */       return statementIter; } finally { this.queriesIssuedFailedOver = queriesIssuedFailedOverCopy; } throw localObject1;
/*      */   }
/*      */ 
/*      */   private void createPreparedStatementCaches()
/*      */   {
/* 2954 */     int cacheSize = getPreparedStatementCacheSize();
/*      */ 
/* 2956 */     this.cachedPreparedStatementParams = new HashMap(cacheSize);
/*      */ 
/* 2958 */     this.serverSideStatementCheckCache = new LRUCache(cacheSize);
/*      */ 
/* 2960 */     this.serverSideStatementCache = new Connection.1(this, cacheSize);
/*      */   }
/*      */ 
/*      */   public java.sql.Statement createStatement()
/*      */     throws SQLException
/*      */   {
/* 2996 */     return createStatement(1003, 1007);
/*      */   }
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 3014 */     checkClosed();
/*      */ 
/* 3016 */     Statement stmt = new Statement(this, this.database);
/* 3017 */     stmt.setResultSetType(resultSetType);
/* 3018 */     stmt.setResultSetConcurrency(resultSetConcurrency);
/*      */ 
/* 3020 */     return stmt;
/*      */   }
/*      */ 
/*      */   public java.sql.Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 3029 */     if ((getPedantic()) && 
/* 3030 */       (resultSetHoldability != 1)) {
/* 3031 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
/*      */     }
/*      */ 
/* 3037 */     return createStatement(resultSetType, resultSetConcurrency);
/*      */   }
/*      */ 
/*      */   protected void dumpTestcaseQuery(String query) {
/* 3041 */     System.err.println(query);
/*      */   }
/*      */ 
/*      */   protected Connection duplicate() throws SQLException {
/* 3045 */     return new Connection(this.origHostToConnectTo, this.origPortToConnectTo, this.props, this.origDatabaseToConnectTo, this.myURL);
/*      */   }
/*      */ 
/*      */   ResultSet execSQL(Statement callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean unpackFields)
/*      */     throws SQLException
/*      */   {
/* 3099 */     return execSQL(callingStatement, sql, maxRows, packet, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields, false);
/*      */   }
/*      */ 
/*      */   ResultSet execSQL(Statement callingStatement, String sql, int maxRows, Buffer packet, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean unpackFields, boolean isBatch)
/*      */     throws SQLException
/*      */   {
/* 3114 */     synchronized (this.mutex) {
/* 3115 */       long queryStartTime = 0L;
/*      */ 
/* 3117 */       int endOfQueryPacketPosition = 0;
/*      */ 
/* 3119 */       if (packet != null) {
/* 3120 */         endOfQueryPacketPosition = packet.getPosition();
/*      */       }
/*      */ 
/* 3123 */       if (getGatherPerformanceMetrics()) {
/* 3124 */         queryStartTime = System.currentTimeMillis();
/*      */       }
/*      */ 
/* 3127 */       this.lastQueryFinishedTime = 0L;
/*      */ 
/* 3129 */       if ((this.failedOver) && (this.autoCommit) && (!isBatch) && 
/* 3130 */         (shouldFallBack()) && (!this.executingFailoverReconnect)) {
/*      */         try {
/* 3132 */           this.executingFailoverReconnect = true;
/*      */ 
/* 3134 */           createNewIO(true);
/*      */ 
/* 3136 */           String connectedHost = this.io.getHost();
/*      */ 
/* 3138 */           if ((connectedHost != null) && (this.hostList.get(0).equals(connectedHost)))
/*      */           {
/* 3140 */             this.failedOver = false;
/* 3141 */             this.queriesIssuedFailedOver = 0L;
/* 3142 */             setReadOnly(false);
/*      */           }
/*      */         } finally {
/* 3145 */           this.executingFailoverReconnect = false;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3150 */       if (((getHighAvailability()) || (this.failedOver)) && ((this.autoCommit) || (getAutoReconnectForPools())) && (this.needsPing) && (!isBatch))
/*      */       {
/*      */         try
/*      */         {
/* 3154 */           pingInternal(false);
/*      */ 
/* 3156 */           this.needsPing = false;
/*      */         } catch (Exception Ex) {
/* 3158 */           createNewIO(true);
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 3163 */         if (packet == null) {
/* 3164 */           encoding = null;
/*      */ 
/* 3166 */           if (getUseUnicode()) {
/* 3167 */             encoding = getEncoding();
/*      */           }
/*      */ 
/* 3170 */           ResultSet localResultSet = this.io.sqlQueryDirect(callingStatement, sql, encoding, null, maxRows, this, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields); jsr 324; return localResultSet;
/*      */         }
/*      */ 
/* 3176 */         String encoding = this.io.sqlQueryDirect(callingStatement, null, null, packet, maxRows, this, resultSetType, resultSetConcurrency, streamResults, catalog, unpackFields); jsr 289; return encoding;
/*      */       }
/*      */       catch (SQLException sqlE)
/*      */       {
/* 3183 */         if (getDumpQueriesOnException()) {
/* 3184 */           String extractedSql = extractSqlFromPacket(sql, packet, endOfQueryPacketPosition);
/*      */ 
/* 3186 */           StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */ 
/* 3188 */           messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");
/*      */ 
/* 3190 */           messageBuf.append(extractedSql);
/*      */ 
/* 3192 */           sqlE = appendMessageToException(sqlE, messageBuf.toString());
/*      */         }
/*      */ 
/* 3195 */         if ((getHighAvailability()) || (this.failedOver)) {
/* 3196 */           this.needsPing = true;
/*      */         } else {
/* 3198 */           String sqlState = sqlE.getSQLState();
/*      */ 
/* 3200 */           if ((sqlState != null) && (sqlState.equals("08S01")))
/*      */           {
/* 3203 */             cleanup(sqlE);
/*      */           }
/*      */         }
/*      */ 
/* 3207 */         throw sqlE;
/*      */       } catch (Exception ex) {
/* 3209 */         if ((getHighAvailability()) || (this.failedOver))
/* 3210 */           this.needsPing = true;
/* 3211 */         else if ((ex instanceof IOException)) {
/* 3212 */           cleanup(ex);
/*      */         }
/*      */ 
/* 3215 */         String exceptionType = ex.getClass().getName();
/* 3216 */         String exceptionMessage = ex.getMessage();
/*      */ 
/* 3218 */         if (!getParanoid()) {
/* 3219 */           exceptionMessage = exceptionMessage + "\n\nNested Stack Trace:\n";
/* 3220 */           exceptionMessage = exceptionMessage + Util.stackTraceToString(ex);
/*      */         }
/*      */ 
/* 3223 */         throw new SQLException("Error during query: Unexpected Exception: " + exceptionType + " message given: " + exceptionMessage, "S1000");
/*      */       }
/*      */       finally
/*      */       {
/* 3229 */         jsr 6; } localObject3 = returnAddress; if (getMaintainTimeStats()) {
/* 3230 */         this.lastQueryFinishedTime = System.currentTimeMillis();
/*      */       }
/*      */ 
/* 3233 */       if (this.failedOver) {
/* 3234 */         this.queriesIssuedFailedOver += 1L;
/*      */       }
/*      */ 
/* 3237 */       if (getGatherPerformanceMetrics()) {
/* 3238 */         long queryTime = System.currentTimeMillis() - queryStartTime;
/*      */ 
/* 3241 */         registerQueryExecutionTime(queryTime); } ret;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected String extractSqlFromPacket(String possibleSqlQuery, Buffer queryPacket, int endOfQueryPacketPosition)
/*      */     throws SQLException
/*      */   {
/* 3251 */     String extractedSql = null;
/*      */ 
/* 3253 */     if (possibleSqlQuery != null) {
/* 3254 */       if (possibleSqlQuery.length() > getMaxQuerySizeToLog()) {
/* 3255 */         StringBuffer truncatedQueryBuf = new StringBuffer(possibleSqlQuery.substring(0, getMaxQuerySizeToLog()));
/*      */ 
/* 3257 */         truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
/* 3258 */         extractedSql = truncatedQueryBuf.toString();
/*      */       } else {
/* 3260 */         extractedSql = possibleSqlQuery;
/*      */       }
/*      */     }
/*      */ 
/* 3264 */     if (extractedSql == null)
/*      */     {
/* 3268 */       int extractPosition = endOfQueryPacketPosition;
/*      */ 
/* 3270 */       boolean truncated = false;
/*      */ 
/* 3272 */       if (endOfQueryPacketPosition > getMaxQuerySizeToLog()) {
/* 3273 */         extractPosition = getMaxQuerySizeToLog();
/* 3274 */         truncated = true;
/*      */       }
/*      */ 
/* 3277 */       extractedSql = new String(queryPacket.getByteBuffer(), 5, extractPosition - 5);
/*      */ 
/* 3280 */       if (truncated) {
/* 3281 */         extractedSql = extractedSql + Messages.getString("MysqlIO.25");
/*      */       }
/*      */     }
/*      */ 
/* 3285 */     return extractedSql;
/*      */   }
/*      */ 
/*      */   protected void finalize()
/*      */     throws Throwable
/*      */   {
/* 3296 */     cleanup(null);
/*      */   }
/*      */ 
/*      */   protected StringBuffer generateConnectionCommentBlock(StringBuffer buf) {
/* 3300 */     buf.append("/* conn id ");
/* 3301 */     buf.append(getId());
/* 3302 */     buf.append(" */ ");
/*      */ 
/* 3304 */     return buf;
/*      */   }
/*      */ 
/*      */   public int getActiveStatementCount()
/*      */   {
/* 3310 */     if (this.openStatements != null) {
/* 3311 */       synchronized (this.openStatements) {
/* 3312 */         return this.openStatements.size();
/*      */       }
/*      */     }
/*      */ 
/* 3316 */     return 0;
/*      */   }
/*      */ 
/*      */   public boolean getAutoCommit()
/*      */     throws SQLException
/*      */   {
/* 3328 */     return this.autoCommit;
/*      */   }
/*      */ 
/*      */   protected Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 3336 */     if (getDynamicCalendars()) {
/* 3337 */       return Calendar.getInstance();
/*      */     }
/*      */ 
/* 3340 */     return getSessionLockedCalendar();
/*      */   }
/*      */ 
/*      */   public String getCatalog()
/*      */     throws SQLException
/*      */   {
/* 3355 */     return this.database;
/*      */   }
/*      */ 
/*      */   protected String getCharacterSetMetadata()
/*      */   {
/* 3362 */     return this.characterSetMetadata;
/*      */   }
/*      */ 
/*      */   SingleByteCharsetConverter getCharsetConverter(String javaEncodingName)
/*      */     throws SQLException
/*      */   {
/* 3375 */     if (javaEncodingName == null) {
/* 3376 */       return null;
/*      */     }
/*      */ 
/* 3379 */     if (this.usePlatformCharsetConverters) {
/* 3380 */       return null;
/*      */     }
/*      */ 
/* 3384 */     SingleByteCharsetConverter converter = null;
/*      */ 
/* 3386 */     synchronized (this.charsetConverterMap) {
/* 3387 */       Object asObject = this.charsetConverterMap.get(javaEncodingName);
/*      */ 
/* 3390 */       if (asObject == CHARSET_CONVERTER_NOT_AVAILABLE_MARKER) {
/* 3391 */         return null;
/*      */       }
/*      */ 
/* 3394 */       converter = (SingleByteCharsetConverter)asObject;
/*      */ 
/* 3396 */       if (converter == null) {
/*      */         try {
/* 3398 */           converter = SingleByteCharsetConverter.getInstance(javaEncodingName, this);
/*      */ 
/* 3401 */           if (converter == null) {
/* 3402 */             this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */           }
/*      */           else
/* 3405 */             this.charsetConverterMap.put(javaEncodingName, converter);
/*      */         }
/*      */         catch (UnsupportedEncodingException unsupEncEx) {
/* 3408 */           this.charsetConverterMap.put(javaEncodingName, CHARSET_CONVERTER_NOT_AVAILABLE_MARKER);
/*      */ 
/* 3411 */           converter = null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3416 */     return converter;
/*      */   }
/*      */ 
/*      */   protected String getCharsetNameForIndex(int charsetIndex)
/*      */     throws SQLException
/*      */   {
/* 3431 */     String charsetName = null;
/*      */ 
/* 3433 */     if (getUseOldUTF8Behavior()) {
/* 3434 */       return getEncoding();
/*      */     }
/*      */ 
/* 3437 */     if (charsetIndex != -1) {
/*      */       try {
/* 3439 */         charsetName = this.indexToCharsetMapping[charsetIndex];
/*      */ 
/* 3441 */         if ("sjis".equalsIgnoreCase(charsetName))
/*      */         {
/* 3443 */           if (CharsetMapping.isAliasForSjis(getEncoding()))
/* 3444 */             charsetName = getEncoding();
/*      */         }
/*      */       }
/*      */       catch (ArrayIndexOutOfBoundsException outOfBoundsEx) {
/* 3448 */         throw SQLError.createSQLException("Unknown character set index for field '" + charsetIndex + "' received from server.", "S1000");
/*      */       }
/*      */ 
/* 3455 */       if (charsetName == null)
/* 3456 */         charsetName = getEncoding();
/*      */     }
/*      */     else {
/* 3459 */       charsetName = getEncoding();
/*      */     }
/*      */ 
/* 3462 */     return charsetName;
/*      */   }
/*      */ 
/*      */   protected TimeZone getDefaultTimeZone()
/*      */   {
/* 3471 */     return this.defaultTimeZone;
/*      */   }
/*      */ 
/*      */   public int getHoldability()
/*      */     throws SQLException
/*      */   {
/* 3478 */     return 2;
/*      */   }
/*      */ 
/*      */   long getId() {
/* 3482 */     return this.connectionId;
/*      */   }
/*      */ 
/*      */   public long getIdleFor()
/*      */   {
/* 3494 */     if (this.lastQueryFinishedTime == 0L) {
/* 3495 */       return 0L;
/*      */     }
/*      */ 
/* 3498 */     long now = System.currentTimeMillis();
/* 3499 */     long idleTime = now - this.lastQueryFinishedTime;
/*      */ 
/* 3501 */     return idleTime;
/*      */   }
/*      */ 
/*      */   protected MysqlIO getIO()
/*      */     throws SQLException
/*      */   {
/* 3512 */     if ((this.io == null) || (this.isClosed)) {
/* 3513 */       throw SQLError.createSQLException("Operation not allowed on closed connection", "08003");
/*      */     }
/*      */ 
/* 3518 */     return this.io;
/*      */   }
/*      */ 
/*      */   public Log getLog()
/*      */     throws SQLException
/*      */   {
/* 3530 */     return this.log;
/*      */   }
/*      */ 
/*      */   int getMaxAllowedPacket()
/*      */   {
/* 3539 */     return this.maxAllowedPacket;
/*      */   }
/*      */ 
/*      */   protected int getMaxBytesPerChar(String javaCharsetName)
/*      */     throws SQLException
/*      */   {
/* 3545 */     String charset = CharsetMapping.getMysqlEncodingForJavaEncoding(javaCharsetName, this);
/*      */ 
/* 3548 */     if (versionMeetsMinimum(4, 1, 0)) {
/* 3549 */       synchronized (this.charsetToNumBytesMap) {
/* 3550 */         if (this.charsetToNumBytesMap.isEmpty())
/*      */         {
/* 3552 */           java.sql.Statement stmt = null;
/* 3553 */           java.sql.ResultSet rs = null;
/*      */           try
/*      */           {
/* 3556 */             stmt = getMetadataSafeStatement();
/*      */ 
/* 3558 */             rs = stmt.executeQuery("SHOW CHARACTER SET");
/*      */ 
/* 3560 */             while (rs.next()) {
/* 3561 */               this.charsetToNumBytesMap.put(rs.getString("Charset"), new Integer(rs.getInt("Maxlen")));
/*      */             }
/*      */ 
/* 3565 */             rs.close();
/* 3566 */             rs = null;
/*      */ 
/* 3568 */             stmt.close();
/*      */ 
/* 3570 */             stmt = null;
/*      */           } finally {
/* 3572 */             if (rs != null) {
/* 3573 */               rs.close();
/* 3574 */               rs = null;
/*      */             }
/*      */ 
/* 3577 */             if (stmt != null) {
/* 3578 */               stmt.close();
/* 3579 */               stmt = null;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 3585 */       Integer mbPerChar = (Integer)this.charsetToNumBytesMap.get(charset);
/*      */ 
/* 3588 */       if (mbPerChar != null) {
/* 3589 */         return mbPerChar.intValue();
/*      */       }
/*      */ 
/* 3592 */       return 1;
/*      */     }
/*      */ 
/* 3595 */     return 1;
/*      */   }
/*      */ 
/*      */   public java.sql.DatabaseMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 3609 */     checkClosed();
/*      */ 
/* 3611 */     if ((getUseInformationSchema()) && (versionMeetsMinimum(5, 0, 7)))
/*      */     {
/* 3613 */       return new DatabaseMetaDataUsingInfoSchema(this, this.database);
/*      */     }
/*      */ 
/* 3616 */     return new DatabaseMetaData(this, this.database);
/*      */   }
/*      */ 
/*      */   protected java.sql.Statement getMetadataSafeStatement() throws SQLException {
/* 3620 */     java.sql.Statement stmt = createStatement();
/*      */ 
/* 3622 */     if (stmt.getMaxRows() != 0) {
/* 3623 */       stmt.setMaxRows(0);
/*      */     }
/*      */ 
/* 3626 */     stmt.setEscapeProcessing(false);
/*      */ 
/* 3628 */     return stmt;
/*      */   }
/*      */ 
/*      */   Object getMutex()
/*      */     throws SQLException
/*      */   {
/* 3639 */     if (this.io == null) {
/* 3640 */       throw SQLError.createSQLException("Connection.close() has already been called. Invalid operation in this state.", "08003");
/*      */     }
/*      */ 
/* 3645 */     reportMetricsIfNeeded();
/*      */ 
/* 3647 */     return this.mutex;
/*      */   }
/*      */ 
/*      */   int getNetBufferLength()
/*      */   {
/* 3656 */     return this.netBufferLength;
/*      */   }
/*      */ 
/*      */   protected String getServerCharacterEncoding()
/*      */   {
/* 3665 */     return (String)this.serverVariables.get("character_set");
/*      */   }
/*      */ 
/*      */   int getServerMajorVersion() {
/* 3669 */     return this.io.getServerMajorVersion();
/*      */   }
/*      */ 
/*      */   int getServerMinorVersion() {
/* 3673 */     return this.io.getServerMinorVersion();
/*      */   }
/*      */ 
/*      */   int getServerSubMinorVersion() {
/* 3677 */     return this.io.getServerSubMinorVersion();
/*      */   }
/*      */ 
/*      */   public TimeZone getServerTimezoneTZ()
/*      */   {
/* 3686 */     return this.serverTimezoneTZ;
/*      */   }
/*      */ 
/*      */   String getServerVariable(String variableName) {
/* 3690 */     if (this.serverVariables != null) {
/* 3691 */       return (String)this.serverVariables.get(variableName);
/*      */     }
/*      */ 
/* 3694 */     return null;
/*      */   }
/*      */ 
/*      */   String getServerVersion() {
/* 3698 */     return this.io.getServerVersion();
/*      */   }
/*      */ 
/*      */   protected Calendar getSessionLockedCalendar()
/*      */   {
/* 3703 */     return this.sessionCalendar;
/*      */   }
/*      */ 
/*      */   public int getTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 3716 */     if ((this.hasIsolationLevels) && (!getUseLocalSessionState())) {
/* 3717 */       java.sql.Statement stmt = null;
/* 3718 */       java.sql.ResultSet rs = null;
/*      */       try
/*      */       {
/* 3721 */         stmt = getMetadataSafeStatement();
/*      */ 
/* 3723 */         String query = null;
/*      */ 
/* 3725 */         if (versionMeetsMinimum(4, 0, 3))
/* 3726 */           query = "SHOW VARIABLES LIKE 'tx_isolation'";
/*      */         else {
/* 3728 */           query = "SHOW VARIABLES LIKE 'transaction_isolation'";
/*      */         }
/*      */ 
/* 3731 */         rs = stmt.executeQuery(query);
/*      */ 
/* 3733 */         if (rs.next()) {
/* 3734 */           String s = rs.getString(2);
/*      */           int i;
/* 3736 */           if (s != null) {
/* 3737 */             Integer intTI = (Integer)mapTransIsolationNameToValue.get(s);
/*      */ 
/* 3740 */             if (intTI != null) {
/* 3741 */               i = intTI.intValue(); jsr 58;
/*      */             }
/*      */           }
/*      */ 
/* 3745 */           throw SQLError.createSQLException("Could not map transaction isolation '" + s + " to a valid JDBC level.", "S1000");
/*      */         }
/*      */ 
/* 3751 */         throw SQLError.createSQLException("Could not retrieve transaction isolation level from server", "S1000");
/*      */       }
/*      */       finally
/*      */       {
/* 3756 */         if (rs != null) {
/*      */           try {
/* 3758 */             rs.close();
/*      */           }
/*      */           catch (Exception ex)
/*      */           {
/*      */           }
/*      */ 
/* 3764 */           rs = null;
/*      */         }
/*      */ 
/* 3767 */         if (stmt != null) {
/*      */           try {
/* 3769 */             stmt.close();
/*      */           }
/*      */           catch (Exception ex)
/*      */           {
/*      */           }
/*      */ 
/* 3775 */           stmt = null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3780 */     synchronized (this) {
/* 3781 */       return this.isolationLevel;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized Map getTypeMap()
/*      */     throws SQLException
/*      */   {
/* 3794 */     if (this.typeMap == null) {
/* 3795 */       this.typeMap = new HashMap();
/*      */     }
/*      */ 
/* 3798 */     return this.typeMap;
/*      */   }
/*      */ 
/*      */   String getURL() {
/* 3802 */     return this.myURL;
/*      */   }
/*      */ 
/*      */   String getUser() {
/* 3806 */     return this.user;
/*      */   }
/*      */ 
/*      */   protected Calendar getUtcCalendar() {
/* 3810 */     return this.utcCalendar;
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 3823 */     return null;
/*      */   }
/*      */ 
/*      */   public boolean hasSameProperties(Connection c) {
/* 3827 */     return this.props.equals(c.props);
/*      */   }
/*      */ 
/*      */   protected void incrementNumberOfPreparedExecutes() {
/* 3831 */     if (getGatherPerformanceMetrics()) {
/* 3832 */       this.numberOfPreparedExecutes += 1L;
/*      */ 
/* 3837 */       this.numberOfQueriesIssued += 1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void incrementNumberOfPrepares() {
/* 3842 */     if (getGatherPerformanceMetrics())
/* 3843 */       this.numberOfPrepares += 1L;
/*      */   }
/*      */ 
/*      */   protected void incrementNumberOfResultSetsCreated()
/*      */   {
/* 3848 */     if (getGatherPerformanceMetrics())
/* 3849 */       this.numberOfResultSetsCreated += 1L;
/*      */   }
/*      */ 
/*      */   private void initializeDriverProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 3864 */     initializeProperties(info);
/*      */ 
/* 3866 */     this.usePlatformCharsetConverters = getUseJvmCharsetConverters();
/*      */ 
/* 3868 */     this.log = LogFactory.getLogger(getLogger(), "MySQL");
/*      */ 
/* 3870 */     if ((getProfileSql()) || (getUseUsageAdvisor())) {
/* 3871 */       this.eventSink = ProfileEventSink.getInstance(this);
/*      */     }
/*      */ 
/* 3874 */     if (getCachePreparedStatements()) {
/* 3875 */       createPreparedStatementCaches();
/*      */     }
/*      */ 
/* 3878 */     if ((getNoDatetimeStringSync()) && (getUseTimezone())) {
/* 3879 */       throw SQLError.createSQLException("Can't enable noDatetimeSync and useTimezone configuration properties at the same time", "01S00");
/*      */     }
/*      */ 
/* 3885 */     if (getCacheCallableStatements())
/* 3886 */       this.parsedCallableStatementCache = new LRUCache(getCallableStatementCacheSize());
/*      */   }
/*      */ 
/*      */   private void initializePropsFromServer()
/*      */     throws SQLException
/*      */   {
/* 3901 */     setSessionVariables();
/*      */ 
/* 3907 */     if (!versionMeetsMinimum(4, 1, 0)) {
/* 3908 */       setTransformedBitIsBoolean(false);
/*      */     }
/*      */ 
/* 3913 */     boolean clientCharsetIsConfigured = configureClientCharacterSet();
/*      */ 
/* 3915 */     this.parserKnowsUnicode = versionMeetsMinimum(4, 1, 0);
/*      */ 
/* 3920 */     if ((getUseServerPreparedStmts()) && (versionMeetsMinimum(4, 1, 0))) {
/* 3921 */       this.useServerPreparedStmts = true;
/*      */ 
/* 3923 */       if ((versionMeetsMinimum(5, 0, 0)) && (!versionMeetsMinimum(5, 0, 3))) {
/* 3924 */         this.useServerPreparedStmts = false;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3930 */     this.serverVariables.clear();
/*      */ 
/* 3935 */     if (versionMeetsMinimum(3, 21, 22)) {
/* 3936 */       loadServerVariables();
/*      */ 
/* 3938 */       buildCollationMapping();
/*      */ 
/* 3940 */       LicenseConfiguration.checkLicenseType(this.serverVariables);
/*      */ 
/* 3942 */       String lowerCaseTables = (String)this.serverVariables.get("lower_case_table_names");
/*      */ 
/* 3945 */       this.lowerCaseTableNames = (("on".equalsIgnoreCase(lowerCaseTables)) || ("1".equalsIgnoreCase(lowerCaseTables)) || ("2".equalsIgnoreCase(lowerCaseTables)));
/*      */ 
/* 3949 */       configureTimezone();
/*      */ 
/* 3951 */       if (this.serverVariables.containsKey("max_allowed_packet")) {
/* 3952 */         this.maxAllowedPacket = Integer.parseInt((String)this.serverVariables.get("max_allowed_packet"));
/*      */ 
/* 3956 */         int preferredBlobSendChunkSize = getBlobSendChunkSize();
/*      */ 
/* 3958 */         int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, this.maxAllowedPacket) - 8192 - 11;
/*      */ 
/* 3963 */         setBlobSendChunkSize(String.valueOf(allowedBlobSendChunkSize));
/*      */       }
/*      */ 
/* 3966 */       if (this.serverVariables.containsKey("net_buffer_length")) {
/* 3967 */         this.netBufferLength = Integer.parseInt((String)this.serverVariables.get("net_buffer_length"));
/*      */       }
/*      */ 
/* 3972 */       checkTransactionIsolationLevel();
/*      */ 
/* 3980 */       if (!clientCharsetIsConfigured) {
/* 3981 */         checkServerEncoding();
/*      */       }
/*      */ 
/* 3984 */       this.io.checkForCharsetMismatch();
/*      */ 
/* 3986 */       if (this.serverVariables.containsKey("sql_mode")) {
/* 3987 */         int sqlMode = 0;
/*      */ 
/* 3989 */         String sqlModeAsString = (String)this.serverVariables.get("sql_mode");
/*      */         try
/*      */         {
/* 3992 */           sqlMode = Integer.parseInt(sqlModeAsString);
/*      */         }
/*      */         catch (NumberFormatException nfe)
/*      */         {
/* 3996 */           sqlMode = 0;
/*      */ 
/* 3998 */           if (sqlModeAsString != null) {
/* 3999 */             if (sqlModeAsString.indexOf("ANSI_QUOTES") != -1) {
/* 4000 */               sqlMode |= 4;
/*      */             }
/*      */ 
/* 4003 */             if (sqlModeAsString.indexOf("NO_BACKSLASH_ESCAPES") != -1) {
/* 4004 */               this.noBackslashEscapes = true;
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/* 4009 */         if ((sqlMode & 0x4) > 0)
/* 4010 */           this.useAnsiQuotes = true;
/*      */         else {
/* 4012 */           this.useAnsiQuotes = false;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 4017 */     this.errorMessageEncoding = CharsetMapping.getCharacterEncodingForErrorMessages(this);
/*      */ 
/* 4020 */     boolean overrideDefaultAutocommit = false;
/*      */ 
/* 4022 */     String initConnectValue = (String)this.serverVariables.get("init_connect");
/*      */ 
/* 4025 */     if ((versionMeetsMinimum(4, 1, 2)) && (initConnectValue != null) && (initConnectValue.length() > 0))
/*      */     {
/* 4028 */       java.sql.ResultSet rs = null;
/* 4029 */       java.sql.Statement stmt = null;
/*      */       try
/*      */       {
/* 4032 */         stmt = getMetadataSafeStatement();
/*      */ 
/* 4034 */         rs = stmt.executeQuery("SELECT @@session.autocommit");
/*      */ 
/* 4036 */         if (rs.next()) {
/* 4037 */           this.autoCommit = rs.getBoolean(1);
/* 4038 */           if (this.autoCommit != true)
/* 4039 */             overrideDefaultAutocommit = true;
/*      */         }
/*      */       }
/*      */       finally
/*      */       {
/* 4044 */         if (rs != null) {
/*      */           try {
/* 4046 */             rs.close();
/*      */           }
/*      */           catch (SQLException sqlEx)
/*      */           {
/*      */           }
/*      */         }
/* 4052 */         if (stmt != null) {
/*      */           try {
/* 4054 */             stmt.close();
/*      */           }
/*      */           catch (SQLException sqlEx)
/*      */           {
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/* 4062 */     if (versionMeetsMinimum(3, 23, 15)) {
/* 4063 */       this.transactionsSupported = true;
/*      */ 
/* 4065 */       if (!overrideDefaultAutocommit) {
/* 4066 */         setAutoCommit(true);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 4071 */       this.transactionsSupported = false;
/*      */     }
/*      */ 
/* 4075 */     if (versionMeetsMinimum(3, 23, 36))
/* 4076 */       this.hasIsolationLevels = true;
/*      */     else {
/* 4078 */       this.hasIsolationLevels = false;
/*      */     }
/*      */ 
/* 4081 */     this.hasQuotedIdentifiers = versionMeetsMinimum(3, 23, 6);
/*      */ 
/* 4083 */     this.io.resetMaxBuf();
/*      */ 
/* 4090 */     if (this.io.versionMeetsMinimum(4, 1, 0)) {
/* 4091 */       String characterSetResultsOnServerMysql = (String)this.serverVariables.get("character_set_results");
/*      */ 
/* 4094 */       if ((characterSetResultsOnServerMysql == null) || (StringUtils.startsWithIgnoreCaseAndWs(characterSetResultsOnServerMysql, "NULL")))
/*      */       {
/* 4097 */         String defaultMetadataCharsetMysql = (String)this.serverVariables.get("character_set_system");
/*      */ 
/* 4099 */         String defaultMetadataCharset = null;
/*      */ 
/* 4101 */         if (defaultMetadataCharsetMysql != null) {
/* 4102 */           defaultMetadataCharset = CharsetMapping.getJavaEncodingForMysqlEncoding(defaultMetadataCharsetMysql, this);
/*      */         }
/*      */         else
/*      */         {
/* 4106 */           defaultMetadataCharset = "UTF-8";
/*      */         }
/*      */ 
/* 4109 */         this.characterSetMetadata = defaultMetadataCharset;
/*      */       } else {
/* 4111 */         this.characterSetResultsOnServer = CharsetMapping.getJavaEncodingForMysqlEncoding(characterSetResultsOnServerMysql, this);
/*      */ 
/* 4114 */         this.characterSetMetadata = this.characterSetResultsOnServer;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4122 */     if ((versionMeetsMinimum(4, 1, 0)) && (!versionMeetsMinimum(4, 1, 10)) && (getAllowMultiQueries()))
/*      */     {
/* 4125 */       if (("ON".equalsIgnoreCase((String)this.serverVariables.get("query_cache_type"))) && (!"0".equalsIgnoreCase((String)this.serverVariables.get("query_cache_size"))))
/*      */       {
/* 4129 */         setAllowMultiQueries(false);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4137 */     setupServerForTruncationChecks();
/*      */   }
/*      */ 
/*      */   private void setupServerForTruncationChecks() throws SQLException {
/* 4141 */     if ((getJdbcCompliantTruncation()) && 
/* 4142 */       (versionMeetsMinimum(5, 0, 2)))
/*      */     {
/* 4144 */       String currentSqlMode = (String)this.serverVariables.get("sql_mode");
/*      */ 
/* 4147 */       boolean strictTransTablesIsSet = StringUtils.indexOfIgnoreCase(currentSqlMode, "STRICT_TRANS_TABLES") != -1;
/*      */ 
/* 4149 */       if ((currentSqlMode == null) || (currentSqlMode.length() == 0) || (!strictTransTablesIsSet))
/*      */       {
/* 4151 */         StringBuffer commandBuf = new StringBuffer("SET sql_mode='");
/*      */ 
/* 4153 */         if ((currentSqlMode != null) && (currentSqlMode.length() > 0)) {
/* 4154 */           commandBuf.append(currentSqlMode);
/* 4155 */           commandBuf.append(",");
/*      */         }
/*      */ 
/* 4158 */         commandBuf.append("STRICT_TRANS_TABLES'");
/*      */ 
/* 4160 */         execSQL(null, commandBuf.toString(), -1, null, 1003, 1007, false, this.database, true, false);
/*      */ 
/* 4165 */         setJdbcCompliantTruncation(false);
/* 4166 */       } else if (strictTransTablesIsSet)
/*      */       {
/* 4168 */         setJdbcCompliantTruncation(false);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected boolean isClientTzUTC()
/*      */   {
/* 4176 */     return this.isClientTzUTC;
/*      */   }
/*      */ 
/*      */   public boolean isClosed()
/*      */   {
/* 4185 */     return this.isClosed;
/*      */   }
/*      */ 
/*      */   protected boolean isCursorFetchEnabled() throws SQLException {
/* 4189 */     return (versionMeetsMinimum(5, 0, 2)) && (getUseCursorFetch());
/*      */   }
/*      */ 
/*      */   public boolean isInGlobalTx() {
/* 4193 */     return this.isInGlobalTx;
/*      */   }
/*      */ 
/*      */   public synchronized boolean isMasterConnection()
/*      */   {
/* 4204 */     return !this.failedOver;
/*      */   }
/*      */ 
/*      */   public boolean isNoBackslashEscapesSet()
/*      */   {
/* 4214 */     return this.noBackslashEscapes;
/*      */   }
/*      */ 
/*      */   boolean isReadInfoMsgEnabled() {
/* 4218 */     return this.readInfoMsg;
/*      */   }
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 4231 */     return this.readOnly;
/*      */   }
/*      */ 
/*      */   protected boolean isRunningOnJDK13() {
/* 4235 */     return this.isRunningOnJDK13;
/*      */   }
/*      */ 
/*      */   public synchronized boolean isSameResource(Connection otherConnection) {
/* 4239 */     if (otherConnection == null) {
/* 4240 */       return false;
/*      */     }
/*      */ 
/* 4243 */     boolean directCompare = true;
/*      */ 
/* 4245 */     String otherHost = otherConnection.origHostToConnectTo;
/* 4246 */     String otherOrigDatabase = otherConnection.origDatabaseToConnectTo;
/* 4247 */     String otherCurrentCatalog = otherConnection.database;
/*      */ 
/* 4249 */     if (!nullSafeCompare(otherHost, this.origHostToConnectTo))
/* 4250 */       directCompare = false;
/* 4251 */     else if ((((otherHost != null ? 1 : 0) & (otherHost.indexOf(",") == -1 ? 1 : 0)) != 0) && (otherHost.indexOf(":") == -1))
/*      */     {
/* 4254 */       directCompare = otherConnection.origPortToConnectTo == this.origPortToConnectTo;
/*      */     }
/*      */ 
/* 4258 */     if (directCompare) {
/* 4259 */       if (!nullSafeCompare(otherOrigDatabase, this.origDatabaseToConnectTo)) { directCompare = false;
/* 4260 */         directCompare = false;
/* 4261 */       } else if (!nullSafeCompare(otherCurrentCatalog, this.database)) {
/* 4262 */         directCompare = false;
/*      */       }
/*      */     }
/*      */ 
/* 4266 */     if (directCompare) {
/* 4267 */       return true;
/*      */     }
/*      */ 
/* 4271 */     String otherResourceId = otherConnection.getResourceId();
/* 4272 */     String myResourceId = getResourceId();
/*      */ 
/* 4274 */     if ((otherResourceId != null) || (myResourceId != null)) {
/* 4275 */       directCompare = nullSafeCompare(otherResourceId, myResourceId);
/*      */ 
/* 4277 */       if (directCompare) {
/* 4278 */         return true;
/*      */       }
/*      */     }
/*      */ 
/* 4282 */     return false;
/*      */   }
/*      */ 
/*      */   protected boolean isServerTzUTC() {
/* 4286 */     return this.isServerTzUTC;
/*      */   }
/*      */ 
/*      */   private void loadServerVariables()
/*      */     throws SQLException
/*      */   {
/* 4298 */     if (getCacheServerConfiguration()) {
/* 4299 */       synchronized (serverConfigByUrl) {
/* 4300 */         Map cachedVariableMap = (Map)serverConfigByUrl.get(getURL());
/*      */ 
/* 4302 */         if (cachedVariableMap != null) {
/* 4303 */           this.serverVariables = cachedVariableMap;
/*      */ 
/* 4305 */           return;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 4310 */     Statement stmt = null;
/* 4311 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 4314 */       stmt = (Statement)createStatement();
/* 4315 */       stmt.setEscapeProcessing(false);
/*      */ 
/* 4317 */       results = (ResultSet)stmt.executeQuery("SHOW VARIABLES");
/*      */ 
/* 4320 */       while (results.next()) {
/* 4321 */         this.serverVariables.put(results.getString(1), results.getString(2));
/*      */       }
/*      */ 
/* 4325 */       if (getCacheServerConfiguration())
/* 4326 */         synchronized (serverConfigByUrl) {
/* 4327 */           serverConfigByUrl.put(getURL(), this.serverVariables);
/*      */         }
/*      */     }
/*      */     catch (SQLException e) {
/* 4331 */       throw e;
/*      */     } finally {
/* 4333 */       if (results != null) {
/*      */         try {
/* 4335 */           results.close();
/*      */         }
/*      */         catch (SQLException sqlE)
/*      */         {
/*      */         }
/*      */       }
/* 4341 */       if (stmt != null)
/*      */         try {
/* 4343 */           stmt.close();
/*      */         }
/*      */         catch (SQLException sqlE)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean lowerCaseTableNames()
/*      */   {
/* 4357 */     return this.lowerCaseTableNames;
/*      */   }
/*      */ 
/*      */   void maxRowsChanged(Statement stmt)
/*      */   {
/* 4367 */     synchronized (this.mutex) {
/* 4368 */       if (this.statementsUsingMaxRows == null) {
/* 4369 */         this.statementsUsingMaxRows = new HashMap();
/*      */       }
/*      */ 
/* 4372 */       this.statementsUsingMaxRows.put(stmt, stmt);
/*      */ 
/* 4374 */       this.maxRowsChanged = true;
/*      */     }
/*      */   }
/*      */ 
/*      */   public String nativeSQL(String sql)
/*      */     throws SQLException
/*      */   {
/* 4391 */     if (sql == null) {
/* 4392 */       return null;
/*      */     }
/*      */ 
/* 4395 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), this);
/*      */ 
/* 4399 */     if ((escapedSqlResult instanceof String)) {
/* 4400 */       return (String)escapedSqlResult;
/*      */     }
/*      */ 
/* 4403 */     return ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */   }
/*      */ 
/*      */   private CallableStatement parseCallableStatement(String sql) throws SQLException
/*      */   {
/* 4408 */     Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, serverSupportsConvertFn(), this);
/*      */ 
/* 4411 */     boolean isFunctionCall = false;
/* 4412 */     String parsedSql = null;
/*      */ 
/* 4414 */     if ((escapedSqlResult instanceof EscapeProcessorResult)) {
/* 4415 */       parsedSql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/* 4416 */       isFunctionCall = ((EscapeProcessorResult)escapedSqlResult).callingStoredFunction;
/*      */     } else {
/* 4418 */       parsedSql = (String)escapedSqlResult;
/* 4419 */       isFunctionCall = false;
/*      */     }
/*      */ 
/* 4422 */     return new CallableStatement(this, parsedSql, this.database, isFunctionCall);
/*      */   }
/*      */ 
/*      */   public boolean parserKnowsUnicode()
/*      */   {
/* 4432 */     return this.parserKnowsUnicode;
/*      */   }
/*      */ 
/*      */   public void ping()
/*      */     throws SQLException
/*      */   {
/* 4442 */     pingInternal(true);
/*      */   }
/*      */ 
/*      */   private void pingInternal(boolean checkForClosedConnection) throws SQLException
/*      */   {
/* 4447 */     if (checkForClosedConnection) {
/* 4448 */       checkClosed();
/*      */     }
/*      */ 
/* 4452 */     this.io.sendCommand(14, null, null, false, null);
/*      */   }
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql)
/*      */     throws SQLException
/*      */   {
/* 4466 */     if (getUseUltraDevWorkAround()) {
/* 4467 */       return new Connection.UltraDevWorkAround(this, prepareStatement(sql));
/*      */     }
/*      */ 
/* 4470 */     return prepareCall(sql, 1003, 1007);
/*      */   }
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4491 */     if (versionMeetsMinimum(5, 0, 0)) {
/* 4492 */       CallableStatement cStmt = null;
/*      */ 
/* 4494 */       if (!getCacheCallableStatements())
/*      */       {
/* 4496 */         cStmt = parseCallableStatement(sql);
/*      */       }
/* 4498 */       else synchronized (this.parsedCallableStatementCache) {
/* 4499 */           Connection.CompoundCacheKey key = new Connection.CompoundCacheKey(this, getCatalog(), sql);
/*      */ 
/* 4501 */           CallableStatement.CallableStatementParamInfo cachedParamInfo = (CallableStatement.CallableStatementParamInfo)this.parsedCallableStatementCache.get(key);
/*      */ 
/* 4504 */           if (cachedParamInfo != null) {
/* 4505 */             cStmt = new CallableStatement(this, cachedParamInfo);
/*      */           } else {
/* 4507 */             cStmt = parseCallableStatement(sql);
/*      */ 
/* 4509 */             cachedParamInfo = cStmt.paramInfo;
/*      */ 
/* 4511 */             this.parsedCallableStatementCache.put(key, cachedParamInfo);
/*      */           }
/*      */         }
/*      */ 
/*      */ 
/* 4516 */       cStmt.setResultSetType(resultSetType);
/* 4517 */       cStmt.setResultSetConcurrency(resultSetConcurrency);
/*      */ 
/* 4519 */       return cStmt;
/*      */     }
/*      */ 
/* 4522 */     throw SQLError.createSQLException("Callable statements not supported.", "S1C00");
/*      */   }
/*      */ 
/*      */   public java.sql.CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4532 */     if ((getPedantic()) && 
/* 4533 */       (resultSetHoldability != 1)) {
/* 4534 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
/*      */     }
/*      */ 
/* 4540 */     CallableStatement cStmt = (CallableStatement)prepareCall(sql, resultSetType, resultSetConcurrency);
/*      */ 
/* 4543 */     return cStmt;
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 4573 */     return prepareStatement(sql, 1003, 1007);
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int autoGenKeyIndex)
/*      */     throws SQLException
/*      */   {
/* 4582 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */ 
/* 4584 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys(autoGenKeyIndex == 1);
/*      */ 
/* 4587 */     return pStmt;
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 4607 */     checkClosed();
/*      */ 
/* 4613 */     PreparedStatement pStmt = null;
/*      */ 
/* 4615 */     boolean canServerPrepare = true;
/*      */ 
/* 4617 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */ 
/* 4619 */     if (getEmulateUnsupportedPstmts()) {
/* 4620 */       canServerPrepare = canHandleAsServerPreparedStatement(nativeSql);
/*      */     }
/*      */ 
/* 4623 */     if ((this.useServerPreparedStmts) && (canServerPrepare)) {
/* 4624 */       if (getCachePreparedStatements()) {
/* 4625 */         synchronized (this.serverSideStatementCache) {
/* 4626 */           pStmt = (ServerPreparedStatement)this.serverSideStatementCache.remove(sql);
/*      */ 
/* 4628 */           if (pStmt != null) {
/* 4629 */             ((ServerPreparedStatement)pStmt).setClosed(false);
/* 4630 */             pStmt.clearParameters();
/*      */           }
/*      */ 
/* 4633 */           if (pStmt == null)
/*      */             try {
/* 4635 */               pStmt = new ServerPreparedStatement(this, nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */ 
/* 4637 */               if (sql.length() < getPreparedStatementCacheSqlLimit())
/* 4638 */                 ((ServerPreparedStatement)pStmt).isCached = true;
/*      */             }
/*      */             catch (SQLException sqlEx)
/*      */             {
/* 4642 */               if (getEmulateUnsupportedPstmts()) {
/* 4643 */                 pStmt = clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */ 
/* 4645 */                 if (sql.length() < getPreparedStatementCacheSqlLimit())
/* 4646 */                   this.serverSideStatementCheckCache.put(sql, Boolean.FALSE);
/*      */               }
/*      */               else {
/* 4649 */                 throw sqlEx;
/*      */               }
/*      */             }
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 4656 */         pStmt = new ServerPreparedStatement(this, nativeSql, this.database, resultSetType, resultSetConcurrency);
/*      */       }
/*      */       catch (SQLException sqlEx)
/*      */       {
/* 4660 */         if (getEmulateUnsupportedPstmts())
/* 4661 */           pStmt = clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */         else
/* 4663 */           throw sqlEx;
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 4668 */       pStmt = clientPrepareStatement(nativeSql, resultSetType, resultSetConcurrency, false);
/*      */     }
/*      */ 
/* 4671 */     return pStmt;
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*      */     throws SQLException
/*      */   {
/* 4680 */     if ((getPedantic()) && 
/* 4681 */       (resultSetHoldability != 1)) {
/* 4682 */       throw SQLError.createSQLException("HOLD_CUSRORS_OVER_COMMIT is only supported holdability level", "S1009");
/*      */     }
/*      */ 
/* 4688 */     return prepareStatement(sql, resultSetType, resultSetConcurrency);
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, int[] autoGenKeyIndexes)
/*      */     throws SQLException
/*      */   {
/* 4696 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */ 
/* 4698 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyIndexes != null) && (autoGenKeyIndexes.length > 0));
/*      */ 
/* 4702 */     return pStmt;
/*      */   }
/*      */ 
/*      */   public java.sql.PreparedStatement prepareStatement(String sql, String[] autoGenKeyColNames)
/*      */     throws SQLException
/*      */   {
/* 4710 */     java.sql.PreparedStatement pStmt = prepareStatement(sql);
/*      */ 
/* 4712 */     ((PreparedStatement)pStmt).setRetrieveGeneratedKeys((autoGenKeyColNames != null) && (autoGenKeyColNames.length > 0));
/*      */ 
/* 4716 */     return pStmt;
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason)
/*      */     throws SQLException
/*      */   {
/* 4731 */     SQLException sqlEx = null;
/*      */ 
/* 4733 */     if (isClosed()) {
/* 4734 */       return;
/*      */     }
/*      */ 
/* 4737 */     this.forceClosedReason = reason;
/*      */     try
/*      */     {
/* 4740 */       if (!skipLocalTeardown) {
/* 4741 */         if ((!getAutoCommit()) && (issueRollback)) {
/*      */           try {
/* 4743 */             rollback();
/*      */           } catch (SQLException ex) {
/* 4745 */             sqlEx = ex;
/*      */           }
/*      */         }
/*      */ 
/* 4749 */         reportMetrics();
/*      */ 
/* 4751 */         if (getUseUsageAdvisor()) {
/* 4752 */           if (!calledExplicitly) {
/* 4753 */             String message = "Connection implicitly closed by Driver. You should call Connection.close() from your code to free resources more efficiently and avoid resource leaks.";
/*      */ 
/* 4755 */             this.eventSink.consumeEvent(new ProfilerEvent(0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */           }
/*      */ 
/* 4762 */           long connectionLifeTime = System.currentTimeMillis() - this.connectionCreationTimeMillis;
/*      */ 
/* 4765 */           if (connectionLifeTime < 500L) {
/* 4766 */             String message = "Connection lifetime of < .5 seconds. You might be un-necessarily creating short-lived connections and should investigate connection pooling to be more efficient.";
/*      */ 
/* 4768 */             this.eventSink.consumeEvent(new ProfilerEvent(0, "", getCatalog(), getId(), -1, -1, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/* 4777 */           closeAllOpenStatements();
/*      */         } catch (SQLException ex) {
/* 4779 */           sqlEx = ex;
/*      */         }
/*      */ 
/* 4782 */         if (this.io != null)
/*      */           try {
/* 4784 */             this.io.quit();
/*      */           }
/*      */           catch (Exception e)
/*      */           {
/*      */           }
/*      */       }
/*      */       else {
/* 4791 */         this.io.forceClose();
/*      */       }
/*      */     } finally {
/* 4794 */       this.openStatements = null;
/* 4795 */       this.io = null;
/* 4796 */       ProfileEventSink.removeInstance(this);
/* 4797 */       this.isClosed = true;
/*      */     }
/*      */ 
/* 4800 */     if (sqlEx != null)
/* 4801 */       throw sqlEx;
/*      */   }
/*      */ 
/*      */   protected void recachePreparedStatement(ServerPreparedStatement pstmt)
/*      */   {
/* 4807 */     synchronized (this.serverSideStatementCache) {
/* 4808 */       this.serverSideStatementCache.put(pstmt.originalSql, pstmt);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void registerQueryExecutionTime(long queryTimeMs)
/*      */   {
/* 4818 */     if (queryTimeMs > this.longestQueryTimeMs) {
/* 4819 */       this.longestQueryTimeMs = queryTimeMs;
/*      */ 
/* 4821 */       repartitionPerformanceHistogram();
/*      */     }
/*      */ 
/* 4824 */     addToPerformanceHistogram(queryTimeMs, 1);
/*      */ 
/* 4826 */     if (queryTimeMs < this.shortestQueryTimeMs) {
/* 4827 */       this.shortestQueryTimeMs = (queryTimeMs == 0L ? 1L : queryTimeMs);
/*      */     }
/*      */ 
/* 4830 */     this.numberOfQueriesIssued += 1L;
/*      */ 
/* 4832 */     this.totalQueryTimeMs += queryTimeMs;
/*      */   }
/*      */ 
/*      */   void registerStatement(Statement stmt)
/*      */   {
/* 4842 */     synchronized (this.openStatements) {
/* 4843 */       this.openStatements.put(stmt, stmt);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void releaseSavepoint(Savepoint arg0)
/*      */     throws SQLException
/*      */   {
/*      */   }
/*      */ 
/*      */   private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound)
/*      */   {
/* 4857 */     if (this.oldHistCounts == null) {
/* 4858 */       this.oldHistCounts = new int[histCounts.length];
/* 4859 */       this.oldHistBreakpoints = new long[histBreakpoints.length];
/*      */     }
/*      */ 
/* 4862 */     for (int i = 0; i < histCounts.length; i++) {
/* 4863 */       this.oldHistCounts[i] = histCounts[i];
/*      */     }
/*      */ 
/* 4866 */     for (int i = 0; i < this.oldHistBreakpoints.length; i++) {
/* 4867 */       this.oldHistBreakpoints[i] = histBreakpoints[i];
/*      */     }
/*      */ 
/* 4870 */     createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
/*      */ 
/* 4873 */     for (int i = 0; i < 20; i++)
/* 4874 */       addToHistogram(histCounts, histBreakpoints, this.oldHistBreakpoints[i], this.oldHistCounts[i], currentLowerBound, currentUpperBound);
/*      */   }
/*      */ 
/*      */   private void repartitionPerformanceHistogram()
/*      */   {
/* 4880 */     checkAndCreatePerformanceHistogram();
/*      */ 
/* 4882 */     repartitionHistogram(this.perfMetricsHistCounts, this.perfMetricsHistBreakpoints, this.shortestQueryTimeMs == 9223372036854775807L ? 0L : this.shortestQueryTimeMs, this.longestQueryTimeMs);
/*      */   }
/*      */ 
/*      */   private void repartitionTablesAccessedHistogram()
/*      */   {
/* 4889 */     checkAndCreateTablesAccessedHistogram();
/*      */ 
/* 4891 */     repartitionHistogram(this.numTablesMetricsHistCounts, this.numTablesMetricsHistBreakpoints, this.minimumNumberTablesAccessed == 9223372036854775807L ? 0L : this.minimumNumberTablesAccessed, this.maximumNumberTablesAccessed);
/*      */   }
/*      */ 
/*      */   private void reportMetrics()
/*      */   {
/* 4899 */     if (getGatherPerformanceMetrics()) {
/* 4900 */       StringBuffer logMessage = new StringBuffer(256);
/*      */ 
/* 4902 */       logMessage.append("** Performance Metrics Report **\n");
/* 4903 */       logMessage.append("\nLongest reported query: " + this.longestQueryTimeMs + " ms");
/*      */ 
/* 4905 */       logMessage.append("\nShortest reported query: " + this.shortestQueryTimeMs + " ms");
/*      */ 
/* 4907 */       logMessage.append("\nAverage query execution time: " + this.totalQueryTimeMs / this.numberOfQueriesIssued + " ms");
/*      */ 
/* 4911 */       logMessage.append("\nNumber of statements executed: " + this.numberOfQueriesIssued);
/*      */ 
/* 4913 */       logMessage.append("\nNumber of result sets created: " + this.numberOfResultSetsCreated);
/*      */ 
/* 4915 */       logMessage.append("\nNumber of statements prepared: " + this.numberOfPrepares);
/*      */ 
/* 4917 */       logMessage.append("\nNumber of prepared statement executions: " + this.numberOfPreparedExecutes);
/*      */ 
/* 4920 */       if (this.perfMetricsHistBreakpoints != null) {
/* 4921 */         logMessage.append("\n\n\tTiming Histogram:\n");
/* 4922 */         int maxNumPoints = 20;
/* 4923 */         int highestCount = -2147483648;
/*      */ 
/* 4925 */         for (int i = 0; i < 20; i++) {
/* 4926 */           if (this.perfMetricsHistCounts[i] > highestCount) {
/* 4927 */             highestCount = this.perfMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */ 
/* 4931 */         if (highestCount == 0) {
/* 4932 */           highestCount = 1;
/*      */         }
/*      */ 
/* 4935 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4937 */           if (i == 0) {
/* 4938 */             logMessage.append("\n\tless than " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           }
/*      */           else
/*      */           {
/* 4942 */             logMessage.append("\n\tbetween " + this.perfMetricsHistBreakpoints[i] + " and " + this.perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + this.perfMetricsHistCounts[i]);
/*      */           }
/*      */ 
/* 4948 */           logMessage.append("\t");
/*      */ 
/* 4950 */           int numPointsToGraph = (int)(maxNumPoints * (this.perfMetricsHistCounts[i] / highestCount));
/*      */ 
/* 4952 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 4953 */             logMessage.append("*");
/*      */           }
/*      */ 
/* 4956 */           if (this.longestQueryTimeMs < this.perfMetricsHistCounts[(i + 1)])
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/* 4961 */         if (this.perfMetricsHistBreakpoints[18] < this.longestQueryTimeMs) {
/* 4962 */           logMessage.append("\n\tbetween ");
/* 4963 */           logMessage.append(this.perfMetricsHistBreakpoints[18]);
/*      */ 
/* 4965 */           logMessage.append(" and ");
/* 4966 */           logMessage.append(this.perfMetricsHistBreakpoints[19]);
/*      */ 
/* 4968 */           logMessage.append(" ms: \t");
/* 4969 */           logMessage.append(this.perfMetricsHistCounts[19]);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4974 */       if (this.numTablesMetricsHistBreakpoints != null) {
/* 4975 */         logMessage.append("\n\n\tTable Join Histogram:\n");
/* 4976 */         int maxNumPoints = 20;
/* 4977 */         int highestCount = -2147483648;
/*      */ 
/* 4979 */         for (int i = 0; i < 20; i++) {
/* 4980 */           if (this.numTablesMetricsHistCounts[i] > highestCount) {
/* 4981 */             highestCount = this.numTablesMetricsHistCounts[i];
/*      */           }
/*      */         }
/*      */ 
/* 4985 */         if (highestCount == 0) {
/* 4986 */           highestCount = 1;
/*      */         }
/*      */ 
/* 4989 */         for (int i = 0; i < 19; i++)
/*      */         {
/* 4991 */           if (i == 0) {
/* 4992 */             logMessage.append("\n\t" + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables or less: \t\t" + this.numTablesMetricsHistCounts[i]);
/*      */           }
/*      */           else
/*      */           {
/* 4997 */             logMessage.append("\n\tbetween " + this.numTablesMetricsHistBreakpoints[i] + " and " + this.numTablesMetricsHistBreakpoints[(i + 1)] + " tables: \t" + this.numTablesMetricsHistCounts[i]);
/*      */           }
/*      */ 
/* 5005 */           logMessage.append("\t");
/*      */ 
/* 5007 */           int numPointsToGraph = (int)(maxNumPoints * (this.numTablesMetricsHistCounts[i] / highestCount));
/*      */ 
/* 5009 */           for (int j = 0; j < numPointsToGraph; j++) {
/* 5010 */             logMessage.append("*");
/*      */           }
/*      */ 
/* 5013 */           if (this.maximumNumberTablesAccessed < this.numTablesMetricsHistBreakpoints[(i + 1)])
/*      */           {
/*      */             break;
/*      */           }
/*      */         }
/* 5018 */         if (this.numTablesMetricsHistBreakpoints[18] < this.maximumNumberTablesAccessed) {
/* 5019 */           logMessage.append("\n\tbetween ");
/* 5020 */           logMessage.append(this.numTablesMetricsHistBreakpoints[18]);
/*      */ 
/* 5022 */           logMessage.append(" and ");
/* 5023 */           logMessage.append(this.numTablesMetricsHistBreakpoints[19]);
/*      */ 
/* 5025 */           logMessage.append(" tables: ");
/* 5026 */           logMessage.append(this.numTablesMetricsHistCounts[19]);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5031 */       this.log.logInfo(logMessage);
/*      */ 
/* 5033 */       this.metricsLastReportedMs = System.currentTimeMillis();
/*      */     }
/*      */   }
/*      */ 
/*      */   private void reportMetricsIfNeeded()
/*      */   {
/* 5042 */     if ((getGatherPerformanceMetrics()) && 
/* 5043 */       (System.currentTimeMillis() - this.metricsLastReportedMs > getReportMetricsIntervalMillis()))
/* 5044 */       reportMetrics();
/*      */   }
/*      */ 
/*      */   protected void reportNumberOfTablesAccessed(int numTablesAccessed)
/*      */   {
/* 5050 */     if (numTablesAccessed < this.minimumNumberTablesAccessed) {
/* 5051 */       this.minimumNumberTablesAccessed = numTablesAccessed;
/*      */     }
/*      */ 
/* 5054 */     if (numTablesAccessed > this.maximumNumberTablesAccessed) {
/* 5055 */       this.maximumNumberTablesAccessed = numTablesAccessed;
/*      */ 
/* 5057 */       repartitionTablesAccessedHistogram();
/*      */     }
/*      */ 
/* 5060 */     addToTablesAccessedHistogram(numTablesAccessed, 1);
/*      */   }
/*      */ 
/*      */   public void resetServerState()
/*      */     throws SQLException
/*      */   {
/* 5072 */     if (!getParanoid()) if ((this.io != null & versionMeetsMinimum(4, 0, 6)))
/*      */       {
/* 5074 */         changeUser(this.user, this.password);
/*      */       }
/*      */   }
/*      */ 
/*      */   public void rollback()
/*      */     throws SQLException
/*      */   {
/* 5088 */     synchronized (getMutex()) {
/* 5089 */       checkClosed();
/*      */       try
/*      */       {
/* 5093 */         if ((this.autoCommit) && (!getRelaxAutoCommit())) {
/* 5094 */           throw SQLError.createSQLException("Can't call rollback when autocommit=true", "08003");
/*      */         }
/*      */ 
/* 5097 */         if (this.transactionsSupported)
/*      */           try {
/* 5099 */             rollbackNoChecks();
/*      */           }
/*      */           catch (SQLException sqlEx) {
/* 5102 */             if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() != 1196))
/*      */             {
/* 5104 */               throw sqlEx;
/*      */             }
/*      */           }
/*      */       }
/*      */       catch (SQLException sqlException) {
/* 5109 */         if ("08S01".equals(sqlException.getSQLState()))
/*      */         {
/* 5111 */           throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007");
/*      */         }
/*      */ 
/* 5116 */         throw sqlException;
/*      */       } finally {
/* 5118 */         this.needsPing = getReconnectAtTxEnd();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void rollback(Savepoint savepoint)
/*      */     throws SQLException
/*      */   {
/* 5128 */     if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 5129 */       synchronized (getMutex()) {
/* 5130 */         checkClosed();
/*      */         try
/*      */         {
/* 5133 */           StringBuffer rollbackQuery = new StringBuffer("ROLLBACK TO SAVEPOINT ");
/*      */ 
/* 5135 */           rollbackQuery.append('`');
/* 5136 */           rollbackQuery.append(savepoint.getSavepointName());
/* 5137 */           rollbackQuery.append('`');
/*      */ 
/* 5139 */           java.sql.Statement stmt = null;
/*      */           try
/*      */           {
/* 5142 */             stmt = createStatement();
/*      */ 
/* 5144 */             stmt.executeUpdate(rollbackQuery.toString());
/*      */           } catch (SQLException sqlEx) {
/* 5146 */             int errno = sqlEx.getErrorCode();
/*      */ 
/* 5148 */             if (errno == 1181) {
/* 5149 */               String msg = sqlEx.getMessage();
/*      */ 
/* 5151 */               if (msg != null) {
/* 5152 */                 int indexOfError153 = msg.indexOf("153");
/*      */ 
/* 5154 */                 if (indexOfError153 != -1) {
/* 5155 */                   throw SQLError.createSQLException("Savepoint '" + savepoint.getSavepointName() + "' does not exist", "S1009", errno);
/*      */                 }
/*      */ 
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/* 5165 */             if ((getIgnoreNonTxTables()) && (sqlEx.getErrorCode() != 1196))
/*      */             {
/* 5167 */               throw sqlEx;
/*      */             }
/*      */ 
/* 5170 */             if ("08S01".equals(sqlEx.getSQLState()))
/*      */             {
/* 5172 */               throw SQLError.createSQLException("Communications link failure during rollback(). Transaction resolution unknown.", "08007");
/*      */             }
/*      */ 
/* 5177 */             throw sqlEx;
/*      */           } finally {
/* 5179 */             closeStatement(stmt);
/*      */           }
/*      */         } finally {
/* 5182 */           this.needsPing = getReconnectAtTxEnd();
/*      */         }
/*      */       }
/*      */     }
/* 5186 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   private void rollbackNoChecks() throws SQLException
/*      */   {
/* 5191 */     execSQL(null, "rollback", -1, null, 1003, 1007, false, this.database, true, false);
/*      */   }
/*      */ 
/*      */   public ServerPreparedStatement serverPrepare(String sql)
/*      */     throws SQLException
/*      */   {
/* 5209 */     String nativeSql = getProcessEscapeCodesForPrepStmts() ? nativeSQL(sql) : sql;
/*      */ 
/* 5211 */     return new ServerPreparedStatement(this, nativeSql, getCatalog(), 1005, 1007);
/*      */   }
/*      */ 
/*      */   protected boolean serverSupportsConvertFn()
/*      */     throws SQLException
/*      */   {
/* 5217 */     return versionMeetsMinimum(4, 0, 2);
/*      */   }
/*      */ 
/*      */   public void setAutoCommit(boolean autoCommitFlag)
/*      */     throws SQLException
/*      */   {
/* 5243 */     synchronized (getMutex()) {
/* 5244 */       checkClosed();
/*      */ 
/* 5246 */       if (getAutoReconnectForPools()) {
/* 5247 */         setHighAvailability(true);
/*      */       }
/*      */       try
/*      */       {
/* 5251 */         if (this.transactionsSupported)
/*      */         {
/* 5253 */           boolean needsSetOnServer = true;
/*      */ 
/* 5255 */           if ((getUseLocalSessionState()) && (this.autoCommit == autoCommitFlag))
/*      */           {
/* 5257 */             needsSetOnServer = false;
/* 5258 */           } else if (!getHighAvailability()) {
/* 5259 */             needsSetOnServer = getIO().isSetNeededForAutoCommitMode(autoCommitFlag);
/*      */           }
/*      */ 
/* 5270 */           this.autoCommit = autoCommitFlag;
/*      */ 
/* 5272 */           if (needsSetOnServer) {
/* 5273 */             execSQL(null, autoCommitFlag ? "SET autocommit=1" : "SET autocommit=0", -1, null, 1003, 1007, false, this.database, true, false);
/*      */           }
/*      */ 
/*      */         }
/*      */         else
/*      */         {
/* 5281 */           if ((!autoCommitFlag) && (!getRelaxAutoCommit())) {
/* 5282 */             throw SQLError.createSQLException("MySQL Versions Older than 3.23.15 do not support transactions", "08003");
/*      */           }
/*      */ 
/* 5287 */           this.autoCommit = autoCommitFlag;
/*      */         }
/*      */       } finally {
/* 5290 */         if (getAutoReconnectForPools()) {
/* 5291 */           setHighAvailability(false);
/*      */         }
/*      */       }
/*      */ 
/* 5295 */       return;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setCatalog(String catalog)
/*      */     throws SQLException
/*      */   {
/* 5313 */     synchronized (getMutex()) {
/* 5314 */       checkClosed();
/*      */ 
/* 5316 */       if (catalog == null) {
/* 5317 */         throw SQLError.createSQLException("Catalog can not be null", "S1009");
/*      */       }
/*      */ 
/* 5321 */       if (getUseLocalSessionState()) {
/* 5322 */         if (this.lowerCaseTableNames) {
/* 5323 */           if (this.database.equalsIgnoreCase(catalog)) {
/* 5324 */             return;
/*      */           }
/*      */         }
/* 5327 */         else if (this.database.equals(catalog)) {
/* 5328 */           return;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5333 */       String quotedId = this.dbmd.getIdentifierQuoteString();
/*      */ 
/* 5335 */       if ((quotedId == null) || (quotedId.equals(" "))) {
/* 5336 */         quotedId = "";
/*      */       }
/*      */ 
/* 5339 */       StringBuffer query = new StringBuffer("USE ");
/* 5340 */       query.append(quotedId);
/* 5341 */       query.append(catalog);
/* 5342 */       query.append(quotedId);
/*      */ 
/* 5344 */       execSQL(null, query.toString(), -1, null, 1003, 1007, false, this.database, true, false);
/*      */ 
/* 5349 */       this.database = catalog;
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setFailedOver(boolean flag)
/*      */   {
/* 5358 */     this.failedOver = flag;
/*      */   }
/*      */ 
/*      */   private void setFailedOverState()
/*      */     throws SQLException
/*      */   {
/* 5368 */     if (getFailOverReadOnly()) {
/* 5369 */       setReadOnly(true);
/*      */     }
/*      */ 
/* 5372 */     this.queriesIssuedFailedOver = 0L;
/* 5373 */     this.failedOver = true;
/* 5374 */     this.masterFailTimeMillis = System.currentTimeMillis();
/*      */   }
/*      */ 
/*      */   public void setHoldability(int arg0)
/*      */     throws SQLException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setInGlobalTx(boolean flag)
/*      */   {
/* 5385 */     this.isInGlobalTx = flag;
/*      */   }
/*      */ 
/*      */   public void setPreferSlaveDuringFailover(boolean flag)
/*      */   {
/* 5394 */     this.preferSlaveDuringFailover = flag;
/*      */   }
/*      */ 
/*      */   void setReadInfoMsgEnabled(boolean flag) {
/* 5398 */     this.readInfoMsg = flag;
/*      */   }
/*      */ 
/*      */   public void setReadOnly(boolean readOnlyFlag)
/*      */     throws SQLException
/*      */   {
/* 5412 */     checkClosed();
/* 5413 */     this.readOnly = readOnlyFlag;
/*      */   }
/*      */ 
/*      */   public Savepoint setSavepoint()
/*      */     throws SQLException
/*      */   {
/* 5420 */     MysqlSavepoint savepoint = new MysqlSavepoint();
/*      */ 
/* 5422 */     setSavepoint(savepoint);
/*      */ 
/* 5424 */     return savepoint;
/*      */   }
/*      */ 
/*      */   private void setSavepoint(MysqlSavepoint savepoint) throws SQLException
/*      */   {
/* 5429 */     if ((versionMeetsMinimum(4, 0, 14)) || (versionMeetsMinimum(4, 1, 1))) {
/* 5430 */       synchronized (getMutex()) {
/* 5431 */         checkClosed();
/*      */ 
/* 5433 */         StringBuffer savePointQuery = new StringBuffer("SAVEPOINT ");
/* 5434 */         savePointQuery.append('`');
/* 5435 */         savePointQuery.append(savepoint.getSavepointName());
/* 5436 */         savePointQuery.append('`');
/*      */ 
/* 5438 */         java.sql.Statement stmt = null;
/*      */         try
/*      */         {
/* 5441 */           stmt = createStatement();
/*      */ 
/* 5443 */           stmt.executeUpdate(savePointQuery.toString());
/*      */         } finally {
/* 5445 */           closeStatement(stmt);
/*      */         }
/*      */       }
/*      */     }
/* 5449 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public synchronized Savepoint setSavepoint(String name)
/*      */     throws SQLException
/*      */   {
/* 5457 */     MysqlSavepoint savepoint = new MysqlSavepoint(name);
/*      */ 
/* 5459 */     setSavepoint(savepoint);
/*      */ 
/* 5461 */     return savepoint;
/*      */   }
/*      */ 
/*      */   private void setSessionVariables()
/*      */     throws SQLException
/*      */   {
/* 5468 */     if ((versionMeetsMinimum(4, 0, 0)) && (getSessionVariables() != null)) {
/* 5469 */       List variablesToSet = StringUtils.split(getSessionVariables(), ",", "\"'", "\"'", false);
/*      */ 
/* 5472 */       int numVariablesToSet = variablesToSet.size();
/*      */ 
/* 5474 */       java.sql.Statement stmt = null;
/*      */       try
/*      */       {
/* 5477 */         stmt = getMetadataSafeStatement();
/*      */ 
/* 5479 */         for (int i = 0; i < numVariablesToSet; i++) {
/* 5480 */           String variableValuePair = (String)variablesToSet.get(i);
/*      */ 
/* 5482 */           if (variableValuePair.startsWith("@"))
/* 5483 */             stmt.executeUpdate("SET " + variableValuePair);
/*      */           else
/* 5485 */             stmt.executeUpdate("SET SESSION " + variableValuePair);
/*      */         }
/*      */       }
/*      */       finally {
/* 5489 */         if (stmt != null)
/* 5490 */           stmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setTransactionIsolation(int level)
/*      */     throws SQLException
/*      */   {
/* 5520 */     checkClosed();
/*      */ 
/* 5522 */     if (this.hasIsolationLevels) {
/* 5523 */       String sql = null;
/*      */ 
/* 5525 */       boolean shouldSendSet = false;
/*      */ 
/* 5527 */       if (getAlwaysSendSetIsolation()) {
/* 5528 */         shouldSendSet = true;
/*      */       }
/* 5530 */       else if (level != this.isolationLevel) {
/* 5531 */         shouldSendSet = true;
/*      */       }
/*      */ 
/* 5535 */       if (getUseLocalSessionState()) {
/* 5536 */         shouldSendSet = this.isolationLevel != level;
/*      */       }
/*      */ 
/* 5539 */       if (shouldSendSet) {
/* 5540 */         switch (level) {
/*      */         case 0:
/* 5542 */           throw SQLError.createSQLException("Transaction isolation level NONE not supported by MySQL");
/*      */         case 2:
/* 5546 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED";
/*      */ 
/* 5548 */           break;
/*      */         case 1:
/* 5551 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL READ UNCOMMITTED";
/*      */ 
/* 5553 */           break;
/*      */         case 4:
/* 5556 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ";
/*      */ 
/* 5558 */           break;
/*      */         case 8:
/* 5561 */           sql = "SET SESSION TRANSACTION ISOLATION LEVEL SERIALIZABLE";
/*      */ 
/* 5563 */           break;
/*      */         case 3:
/*      */         case 5:
/*      */         case 6:
/*      */         case 7:
/*      */         default:
/* 5566 */           throw SQLError.createSQLException("Unsupported transaction isolation level '" + level + "'", "S1C00");
/*      */         }
/*      */ 
/* 5571 */         execSQL(null, sql, -1, null, 1003, 1007, false, this.database, true, false);
/*      */ 
/* 5576 */         this.isolationLevel = level;
/*      */       }
/*      */     } else {
/* 5579 */       throw SQLError.createSQLException("Transaction Isolation Levels are not supported on MySQL versions older than 3.23.36.", "S1C00");
/*      */     }
/*      */   }
/*      */ 
/*      */   public synchronized void setTypeMap(Map map)
/*      */     throws SQLException
/*      */   {
/* 5595 */     this.typeMap = map;
/*      */   }
/*      */ 
/*      */   private boolean shouldFallBack()
/*      */   {
/* 5606 */     long secondsSinceFailedOver = (System.currentTimeMillis() - this.masterFailTimeMillis) / 1000L;
/*      */ 
/* 5609 */     boolean tryFallback = (secondsSinceFailedOver >= getSecondsBeforeRetryMaster()) || (this.queriesIssuedFailedOver >= getQueriesBeforeRetryMaster());
/*      */ 
/* 5611 */     return tryFallback;
/*      */   }
/*      */ 
/*      */   public void shutdownServer()
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5622 */       this.io.sendCommand(8, null, null, false, null);
/*      */     } catch (Exception ex) {
/* 5624 */       throw SQLError.createSQLException("Unhandled exception '" + ex.toString() + "'", "S1000");
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean supportsIsolationLevel()
/*      */   {
/* 5635 */     return this.hasIsolationLevels;
/*      */   }
/*      */ 
/*      */   public boolean supportsQuotedIdentifiers()
/*      */   {
/* 5644 */     return this.hasQuotedIdentifiers;
/*      */   }
/*      */ 
/*      */   public boolean supportsTransactions()
/*      */   {
/* 5653 */     return this.transactionsSupported;
/*      */   }
/*      */ 
/*      */   void unregisterStatement(Statement stmt)
/*      */   {
/* 5663 */     if (this.openStatements != null)
/* 5664 */       synchronized (this.openStatements) {
/* 5665 */         this.openStatements.remove(stmt);
/*      */       }
/*      */   }
/*      */ 
/*      */   void unsetMaxRows(Statement stmt)
/*      */     throws SQLException
/*      */   {
/* 5681 */     synchronized (this.mutex) {
/* 5682 */       if (this.statementsUsingMaxRows != null) {
/* 5683 */         Object found = this.statementsUsingMaxRows.remove(stmt);
/*      */ 
/* 5685 */         if ((found != null) && (this.statementsUsingMaxRows.size() == 0))
/*      */         {
/* 5687 */           execSQL(null, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.database, true, false);
/*      */ 
/* 5692 */           this.maxRowsChanged = false;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean useAnsiQuotedIdentifiers() {
/* 5699 */     return this.useAnsiQuotes;
/*      */   }
/*      */ 
/*      */   boolean useMaxRows()
/*      */   {
/* 5708 */     synchronized (this.mutex) {
/* 5709 */       return this.maxRowsChanged;
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean versionMeetsMinimum(int major, int minor, int subminor) throws SQLException
/*      */   {
/* 5715 */     checkClosed();
/*      */ 
/* 5717 */     return this.io.versionMeetsMinimum(major, minor, subminor);
/*      */   }
/*      */ 
/*      */   protected String getErrorMessageEncoding() {
/* 5721 */     return this.errorMessageEncoding;
/*      */   }
/*      */ 
/*      */   public void clearHasTriedMaster()
/*      */   {
/* 5730 */     this.hasTriedMasterFlag = false;
/*      */   }
/*      */ 
/*      */   public boolean hasTriedMaster() {
/* 5734 */     return this.hasTriedMasterFlag;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/* 1060 */     mapTransIsolationNameToValue = new HashMap(8);
/* 1061 */     mapTransIsolationNameToValue.put("READ-UNCOMMITED", new Integer(1));
/*      */ 
/* 1063 */     mapTransIsolationNameToValue.put("READ-UNCOMMITTED", new Integer(1));
/*      */ 
/* 1065 */     mapTransIsolationNameToValue.put("READ-COMMITTED", new Integer(2));
/*      */ 
/* 1067 */     mapTransIsolationNameToValue.put("REPEATABLE-READ", new Integer(4));
/*      */ 
/* 1069 */     mapTransIsolationNameToValue.put("SERIALIZABLE", new Integer(8));
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Connection
 * JD-Core Version:    0.6.0
 */