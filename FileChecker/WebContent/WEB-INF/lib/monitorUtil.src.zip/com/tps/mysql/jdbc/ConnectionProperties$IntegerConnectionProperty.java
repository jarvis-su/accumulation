/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class ConnectionProperties$IntegerConnectionProperty extends ConnectionProperties.ConnectionProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = -8147538210820248187L;
/*     */   int multiplier;
/*     */   private final ConnectionProperties this$0;
/*     */ 
/*     */   ConnectionProperties$IntegerConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 329 */     super(this$0, propertyNameToSet, new Integer(defaultValueToSet), null, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */ 
/* 328 */     this.this$0 = this$0;
/*     */ 
/* 323 */     this.multiplier = 1;
/*     */   }
/*     */ 
/*     */   ConnectionProperties$IntegerConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, int defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 347 */     this(this$0, propertyNameToSet, defaultValueToSet, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */   }
/*     */ 
/*     */   String[] getAllowableValues()
/*     */   {
/* 355 */     return null;
/*     */   }
/*     */ 
/*     */   int getLowerBound()
/*     */   {
/* 362 */     return this.lowerBound;
/*     */   }
/*     */ 
/*     */   int getUpperBound()
/*     */   {
/* 369 */     return this.upperBound;
/*     */   }
/*     */ 
/*     */   int getValueAsInt() {
/* 373 */     return ((Integer)this.valueAsObject).intValue();
/*     */   }
/*     */ 
/*     */   boolean hasValueConstraints()
/*     */   {
/* 380 */     return false;
/*     */   }
/*     */ 
/*     */   void initializeFrom(String extractedValue)
/*     */     throws SQLException
/*     */   {
/* 387 */     if (extractedValue != null) {
/*     */       try
/*     */       {
/* 390 */         int intValue = Double.valueOf(extractedValue).intValue();
/*     */ 
/* 401 */         this.valueAsObject = new Integer(intValue * this.multiplier);
/*     */       } catch (NumberFormatException nfe) {
/* 403 */         throw SQLError.createSQLException("The connection property '" + getPropertyName() + "' only accepts integer values. The value '" + extractedValue + "' can not be converted to an integer.", "S1009");
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 411 */       this.valueAsObject = this.defaultValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean isRangeBased()
/*     */   {
/* 419 */     return getUpperBound() != getLowerBound();
/*     */   }
/*     */ 
/*     */   void setValue(int valueFlag) {
/* 423 */     this.valueAsObject = new Integer(valueFlag);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.IntegerConnectionProperty
 * JD-Core Version:    0.6.0
 */