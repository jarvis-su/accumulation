package com.acs.eppic.messageservice.web;

import java.net.URL;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;

public abstract interface MessageWebServiceService extends Service
{
  public abstract String getMessageWebServiceAddress();

  public abstract MessageWebService getMessageWebService()
    throws ServiceException;

  public abstract MessageWebService getMessageWebService(URL paramURL)
    throws ServiceException;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.web.MessageWebServiceService
 * JD-Core Version:    0.6.0
 */