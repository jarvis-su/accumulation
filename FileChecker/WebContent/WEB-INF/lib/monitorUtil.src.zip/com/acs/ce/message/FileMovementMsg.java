/*    */ package com.acs.ce.message;
/*    */ 
/*    */ import com.acs.eppic.message.FileMovementInfo;
/*    */ import com.acs.eppic.message.Message;
/*    */ import com.acs.eppic.messageservice.MessageSender;
/*    */ import java.io.File;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Date;
/*    */ import java.util.Random;
/*    */ 
/*    */ public class FileMovementMsg
/*    */ {
/*    */   public static void usage(int argSize)
/*    */   {
/* 14 */     System.out.println("Usage:\nFileMovementMsg [systemId] fileName destServer sourceServer status\n");
/*    */   }
/*    */ 
/*    */   public static void enableService(MessageSender ms)
/*    */   {
/* 19 */     ms.setServiceEnabled(true);
/*    */   }
/*    */ 
/*    */   public static void disableService(MessageSender ms)
/*    */   {
/*    */     try {
/* 25 */       Thread.sleep(1000L);
/*    */     } catch (InterruptedException e) {
/* 27 */       e.printStackTrace();
/*    */     }
/* 29 */     ms.setServiceEnabled(false);
/*    */   }
/*    */ 
/*    */   public static void sendMessage(MessageSender ms, String system, String fileName, String destServer, String sourceServer, String status, Date time, long size) {
/* 33 */     boolean isStart = false;
/* 34 */     if (status.equalsIgnoreCase("start"))
/* 35 */       isStart = true;
/* 36 */     Message m = new Message(system, "FILEMOVEMENT", 4, "");
/* 37 */     m.setM_MessageData(new FileMovementInfo(fileName, destServer, sourceServer, status, time, isStart, size));
/* 38 */     ms.enqueue(m);
/*    */   }
/*    */ 
/*    */   public static void sendMessage(String system, String fileName, String destServer, String sourceServer, String status, Date time, long size) {
/* 42 */     MessageSender ms = new MessageSender();
/* 43 */     enableService(ms);
/* 44 */     sendMessage(ms, system, fileName, destServer, sourceServer, status, time, size);
/* 45 */     disableService(ms);
/*    */   }
/*    */ 
/*    */   public static long getFileSize(File f) {
/* 49 */     if (!f.exists())
/* 50 */       return -1L;
/* 51 */     return f.length();
/*    */   }
/*    */ 
/*    */   public static void test(MessageSender ms, String system, File file, String destServer, String sourceServer, String status, Date time, long size) {
/* 55 */     Random r = new Random();
/*    */ 
/* 57 */     for (int i = 0; i < 1000; i++) {
/* 58 */       System.out.println("Sending " + i);
/* 59 */       sendMessage(ms, "CAEBT", file.getName() + i, 
/* 60 */         "caftp@192.168.179.98:sarsftp/outgoing", 
/* 61 */         "192.168.179.220", 
/* 62 */         "START", 
/* 63 */         new Date(System.currentTimeMillis()), 
/* 64 */         103600L);
/*    */ 
/* 67 */       long l = r.nextInt(5000);
/* 68 */       System.out.println("    Pretending to send " + l);
/*    */       try { Thread.sleep(l); } catch (InterruptedException localInterruptedException) {
/*    */       }
/* 71 */       sendMessage(ms, "CAEBT", file.getName() + i, 
/* 72 */         "caftp@192.168.179.98:sarsftp/outgoing", 
/* 73 */         "192.168.179.220", 
/* 74 */         "TRANSFERRED", 
/* 75 */         new Date(System.currentTimeMillis()), 
/* 76 */         103600L);
/* 77 */       l = r.nextInt(5000);
/* 78 */       System.out.println("    Waiting " + l);
/*    */       try { Thread.sleep(l); } catch (InterruptedException localInterruptedException1) {
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 84 */     if (args.length != 5) {
/* 85 */       usage(args.length);
/*    */     }
/*    */     else
/*    */     {
/* 89 */       String systemId = args[0];
/* 90 */       String fileName = args[1];
/* 91 */       String destServer = args[2];
/* 92 */       String sourceServer = args[3];
/* 93 */       String status = args[4];
/*    */ 
/* 103 */       File file = new File(fileName);
/* 104 */       long size = getFileSize(file);
/*    */ 
/* 106 */       MessageSender ms = new MessageSender();
/*    */ 
/* 108 */       enableService(ms);
/*    */ 
/* 110 */       sendMessage(ms, systemId, file.getName(), destServer, sourceServer, status, new Date(System.currentTimeMillis()), size);
/*    */ 
/* 113 */       disableService(ms);
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.ce.message.FileMovementMsg
 * JD-Core Version:    0.6.0
 */