/*    */ package ch.ethz.ssh2;
/*    */ 
/*    */ import ch.ethz.ssh2.sftp.ErrorCodes;
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class SFTPException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 578654644222421811L;
/*    */   private final String sftpErrorMessage;
/*    */   private final int sftpErrorCode;
/*    */ 
/*    */   private static String constructMessage(String s, int errorCode)
/*    */   {
/* 25 */     String[] detail = ErrorCodes.getDescription(errorCode);
/*    */ 
/* 27 */     if (detail == null) {
/* 28 */       return s + " (UNKNOW SFTP ERROR CODE)";
/*    */     }
/* 30 */     return s + " (" + detail[0] + ": " + detail[1] + ")";
/*    */   }
/*    */ 
/*    */   SFTPException(String msg, int errorCode)
/*    */   {
/* 35 */     super(constructMessage(msg, errorCode));
/* 36 */     this.sftpErrorMessage = msg;
/* 37 */     this.sftpErrorCode = errorCode;
/*    */   }
/*    */ 
/*    */   public String getServerErrorMessage()
/*    */   {
/* 48 */     return this.sftpErrorMessage;
/*    */   }
/*    */ 
/*    */   public int getServerErrorCode()
/*    */   {
/* 58 */     return this.sftpErrorCode;
/*    */   }
/*    */ 
/*    */   public String getServerErrorCodeSymbol()
/*    */   {
/* 68 */     String[] detail = ErrorCodes.getDescription(this.sftpErrorCode);
/*    */ 
/* 70 */     if (detail == null) {
/* 71 */       return "UNKNOW SFTP ERROR CODE " + this.sftpErrorCode;
/*    */     }
/* 73 */     return detail[0];
/*    */   }
/*    */ 
/*    */   public String getServerErrorCodeVerbose()
/*    */   {
/* 83 */     String[] detail = ErrorCodes.getDescription(this.sftpErrorCode);
/*    */ 
/* 85 */     if (detail == null) {
/* 86 */       return "The error code " + this.sftpErrorCode + " is unknown.";
/*    */     }
/* 88 */     return detail[1];
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SFTPException
 * JD-Core Version:    0.6.0
 */