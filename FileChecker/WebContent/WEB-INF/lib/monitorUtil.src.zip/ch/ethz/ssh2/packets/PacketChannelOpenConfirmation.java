/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketChannelOpenConfirmation
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public int senderChannelID;
/*    */   public int initialWindowSize;
/*    */   public int maxPacketSize;
/*    */ 
/*    */   public PacketChannelOpenConfirmation(int recipientChannelID, int senderChannelID, int initialWindowSize, int maxPacketSize)
/*    */   {
/* 23 */     this.recipientChannelID = recipientChannelID;
/* 24 */     this.senderChannelID = senderChannelID;
/* 25 */     this.initialWindowSize = initialWindowSize;
/* 26 */     this.maxPacketSize = maxPacketSize;
/*    */   }
/*    */ 
/*    */   public PacketChannelOpenConfirmation(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 31 */     this.payload = new byte[len];
/* 32 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 34 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 36 */     int packet_type = tr.readByte();
/*    */ 
/* 38 */     if (packet_type != 91) {
/* 39 */       throw new IOException(
/* 40 */         "This is not a SSH_MSG_CHANNEL_OPEN_CONFIRMATION! (" + 
/* 41 */         packet_type + ")");
/*    */     }
/* 43 */     this.recipientChannelID = tr.readUINT32();
/* 44 */     this.senderChannelID = tr.readUINT32();
/* 45 */     this.initialWindowSize = tr.readUINT32();
/* 46 */     this.maxPacketSize = tr.readUINT32();
/*    */ 
/* 48 */     if (tr.remain() != 0)
/* 49 */       throw new IOException("Padding in SSH_MSG_CHANNEL_OPEN_CONFIRMATION packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 54 */     if (this.payload == null)
/*    */     {
/* 56 */       TypesWriter tw = new TypesWriter();
/* 57 */       tw.writeByte(91);
/* 58 */       tw.writeUINT32(this.recipientChannelID);
/* 59 */       tw.writeUINT32(this.senderChannelID);
/* 60 */       tw.writeUINT32(this.initialWindowSize);
/* 61 */       tw.writeUINT32(this.maxPacketSize);
/* 62 */       this.payload = tw.getBytes();
/*    */     }
/* 64 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketChannelOpenConfirmation
 * JD-Core Version:    0.6.0
 */