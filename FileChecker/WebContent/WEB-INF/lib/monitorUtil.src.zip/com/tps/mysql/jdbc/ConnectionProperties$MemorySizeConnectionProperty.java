/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class ConnectionProperties$MemorySizeConnectionProperty extends ConnectionProperties.IntegerConnectionProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 7351065128998572656L;
/*     */   private final ConnectionProperties this$0;
/*     */ 
/*     */   ConnectionProperties$MemorySizeConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, int defaultValueToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 435 */     super(this$0, propertyNameToSet, defaultValueToSet, lowerBoundToSet, upperBoundToSet, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */ 
/* 434 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   void initializeFrom(String extractedValue)
/*     */     throws SQLException
/*     */   {
/* 442 */     if (extractedValue != null) {
/* 443 */       if ((extractedValue.endsWith("k")) || (extractedValue.endsWith("K")) || (extractedValue.endsWith("kb")) || (extractedValue.endsWith("Kb")) || (extractedValue.endsWith("kB")))
/*     */       {
/* 448 */         this.multiplier = 1024;
/* 449 */         int indexOfK = StringUtils.indexOfIgnoreCase(extractedValue, "k");
/*     */ 
/* 451 */         extractedValue = extractedValue.substring(0, indexOfK);
/* 452 */       } else if ((extractedValue.endsWith("m")) || (extractedValue.endsWith("M")) || (extractedValue.endsWith("G")) || (extractedValue.endsWith("mb")) || (extractedValue.endsWith("Mb")) || (extractedValue.endsWith("mB")))
/*     */       {
/* 458 */         this.multiplier = 1048576;
/* 459 */         int indexOfM = StringUtils.indexOfIgnoreCase(extractedValue, "m");
/*     */ 
/* 461 */         extractedValue = extractedValue.substring(0, indexOfM);
/* 462 */       } else if ((extractedValue.endsWith("g")) || (extractedValue.endsWith("G")) || (extractedValue.endsWith("gb")) || (extractedValue.endsWith("Gb")) || (extractedValue.endsWith("gB")))
/*     */       {
/* 467 */         this.multiplier = 1073741824;
/* 468 */         int indexOfG = StringUtils.indexOfIgnoreCase(extractedValue, "g");
/*     */ 
/* 470 */         extractedValue = extractedValue.substring(0, indexOfG);
/*     */       }
/*     */     }
/*     */ 
/* 474 */     super.initializeFrom(extractedValue);
/*     */   }
/*     */ 
/*     */   void setValue(String value) throws SQLException {
/* 478 */     initializeFrom(value);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.MemorySizeConnectionProperty
 * JD-Core Version:    0.6.0
 */