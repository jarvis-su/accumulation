/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.io.CharArrayWriter;
/*    */ 
/*    */ class WatchableWriter extends CharArrayWriter
/*    */ {
/*    */   private WriterWatcher watcher;
/*    */ 
/*    */   public void close()
/*    */   {
/* 47 */     super.close();
/*    */ 
/* 50 */     if (this.watcher != null)
/* 51 */       this.watcher.writerClosed(this);
/*    */   }
/*    */ 
/*    */   public void setWatcher(WriterWatcher watcher)
/*    */   {
/* 62 */     this.watcher = watcher;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.WatchableWriter
 * JD-Core Version:    0.6.0
 */