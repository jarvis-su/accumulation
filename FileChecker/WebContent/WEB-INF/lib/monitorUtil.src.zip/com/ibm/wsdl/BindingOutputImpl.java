package com.ibm.wsdl;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.BindingOutput;
import javax.wsdl.extensions.ExtensibilityElement;
import org.w3c.dom.Element;

public class BindingOutputImpl
  implements BindingOutput
{
  protected String name = null;
  protected Element docEl = null;
  protected List extElements = new Vector();
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("BindingOutput: name=" + this.name);
    if (this.extElements != null)
    {
      Iterator localIterator = this.extElements.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.BindingOutputImpl
 * JD-Core Version:    0.6.0
 */