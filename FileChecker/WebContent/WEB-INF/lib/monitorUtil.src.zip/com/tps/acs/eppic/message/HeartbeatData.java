/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class HeartbeatData extends MessageData
/*    */ {
/*    */   private static final long serialVersionUID = 9120576765029843955L;
/*    */   public static final String INTERVAL = "INTERVAL";
/*    */ 
/*    */   public HeartbeatData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public HeartbeatData(HashMap map)
/*    */   {
/* 18 */     setData(map);
/*    */   }
/*    */ 
/*    */   public HeartbeatData(int interval) {
/* 22 */     setInterval(interval);
/*    */   }
/*    */ 
/*    */   public void setInterval(int interval) {
/* 26 */     super.setData("INTERVAL", new Integer(interval));
/*    */   }
/*    */ 
/*    */   public int getInterval() {
/* 30 */     int retVal = -1;
/* 31 */     if (getData("INTERVAL") != null) {
/* 32 */       retVal = ((Integer)getData("INTERVAL")).intValue();
/*    */     }
/* 34 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 38 */     return "  Interval: " + getInterval() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.HeartbeatData
 * JD-Core Version:    0.6.0
 */