/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ 
/*      */ public class CallableStatement extends PreparedStatement
/*      */   implements java.sql.CallableStatement
/*      */ {
/*      */   private static final int NOT_OUTPUT_PARAMETER_INDICATOR = -2147483648;
/*      */   private static final String PARAMETER_NAMESPACE_PREFIX = "@com_mysql_jdbc_outparam_";
/*  376 */   private boolean callingStoredFunction = false;
/*      */   private ResultSet functionReturnValueResults;
/*  380 */   private boolean hasOutputParams = false;
/*      */   private ResultSet outputParameterResults;
/*  386 */   private boolean outputParamWasNull = false;
/*      */   private int[] parameterIndexToRsIndex;
/*      */   protected CallableStatement.CallableStatementParamInfo paramInfo;
/*      */   private CallableStatement.CallableStatementParam returnValueParam;
/*      */   private int[] placeholderToParameterIndexMap;
/*      */ 
/*      */   private static String mangleParameterName(String origParameterName)
/*      */   {
/*  356 */     if (origParameterName == null) {
/*  357 */       return null;
/*      */     }
/*      */ 
/*  360 */     int offset = 0;
/*      */ 
/*  362 */     if ((origParameterName.length() > 0) && (origParameterName.charAt(0) == '@'))
/*      */     {
/*  364 */       offset = 1;
/*      */     }
/*      */ 
/*  367 */     StringBuffer paramNameBuf = new StringBuffer("@com_mysql_jdbc_outparam_".length() + origParameterName.length());
/*      */ 
/*  370 */     paramNameBuf.append("@com_mysql_jdbc_outparam_");
/*  371 */     paramNameBuf.append(origParameterName.substring(offset));
/*      */ 
/*  373 */     return paramNameBuf.toString();
/*      */   }
/*      */ 
/*      */   public CallableStatement(Connection conn, CallableStatement.CallableStatementParamInfo paramInfo)
/*      */     throws SQLException
/*      */   {
/*  407 */     super(conn, paramInfo.nativeSql, paramInfo.catalogInUse);
/*      */ 
/*  409 */     this.paramInfo = paramInfo;
/*  410 */     this.callingStoredFunction = this.paramInfo.isFunctionCall;
/*      */ 
/*  412 */     if (this.callingStoredFunction)
/*  413 */       this.parameterCount += 1;
/*      */   }
/*      */ 
/*      */   public CallableStatement(Connection conn, String catalog)
/*      */     throws SQLException
/*      */   {
/*  430 */     super(conn, catalog, null);
/*      */ 
/*  432 */     determineParameterTypes();
/*  433 */     generateParameterMap();
/*      */ 
/*  435 */     if (this.callingStoredFunction)
/*  436 */       this.parameterCount += 1;
/*      */   }
/*      */ 
/*      */   private void generateParameterMap()
/*      */     throws SQLException
/*      */   {
/*  448 */     int parameterCountFromMetaData = this.paramInfo.getParameterCount();
/*      */ 
/*  452 */     if (this.callingStoredFunction) {
/*  453 */       parameterCountFromMetaData--;
/*      */     }
/*      */ 
/*  456 */     if ((this.paramInfo != null) && (this.parameterCount != parameterCountFromMetaData))
/*      */     {
/*  458 */       this.placeholderToParameterIndexMap = new int[this.parameterCount];
/*      */ 
/*  460 */       int startPos = this.callingStoredFunction ? StringUtils.indexOfIgnoreCase(this.originalSql, "SELECT") : StringUtils.indexOfIgnoreCase(this.originalSql, "CALL");
/*      */ 
/*  463 */       if (startPos != -1) {
/*  464 */         int parenOpenPos = this.originalSql.indexOf('(', startPos + 4);
/*      */ 
/*  466 */         if (parenOpenPos != -1) {
/*  467 */           int parenClosePos = StringUtils.indexOfIgnoreCaseRespectQuotes(parenOpenPos, this.originalSql, ")", '\'', true);
/*      */ 
/*  470 */           if (parenClosePos != -1) {
/*  471 */             List parsedParameters = StringUtils.split(this.originalSql.substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
/*      */ 
/*  473 */             int numParsedParameters = parsedParameters.size();
/*      */ 
/*  477 */             if (numParsedParameters != this.parameterCount);
/*  481 */             int placeholderCount = 0;
/*      */ 
/*  483 */             for (int i = 0; i < numParsedParameters; i++)
/*  484 */               if (((String)parsedParameters.get(i)).equals("?"))
/*  485 */                 this.placeholderToParameterIndexMap[(placeholderCount++)] = i;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public CallableStatement(Connection conn, String sql, String catalog, boolean isFunctionCall)
/*      */     throws SQLException
/*      */   {
/*  509 */     super(conn, sql, catalog);
/*      */ 
/*  511 */     this.callingStoredFunction = isFunctionCall;
/*      */ 
/*  513 */     determineParameterTypes();
/*  514 */     generateParameterMap();
/*      */ 
/*  516 */     if (this.callingStoredFunction)
/*  517 */       this.parameterCount += 1;
/*      */   }
/*      */ 
/*      */   public void addBatch()
/*      */     throws SQLException
/*      */   {
/*  527 */     setOutParams();
/*      */ 
/*  529 */     super.addBatch();
/*      */   }
/*      */ 
/*      */   private CallableStatement.CallableStatementParam checkIsOutputParam(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*  535 */     if (this.callingStoredFunction) {
/*  536 */       if (paramIndex == 1)
/*      */       {
/*  538 */         if (this.returnValueParam == null) {
/*  539 */           this.returnValueParam = new CallableStatement.CallableStatementParam(this, "", 0, false, true, 12, "VARCHAR", 0, 0, 2, 5);
/*      */         }
/*      */ 
/*  545 */         return this.returnValueParam;
/*      */       }
/*      */ 
/*  549 */       paramIndex--;
/*      */     }
/*      */ 
/*  552 */     checkParameterIndexBounds(paramIndex);
/*      */ 
/*  554 */     int localParamIndex = paramIndex - 1;
/*      */ 
/*  556 */     if (this.placeholderToParameterIndexMap != null) {
/*  557 */       localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */     }
/*      */ 
/*  560 */     CallableStatement.CallableStatementParam paramDescriptor = this.paramInfo.getParameter(localParamIndex);
/*      */ 
/*  563 */     if (!paramDescriptor.isOut) {
/*  564 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.9") + paramIndex + Messages.getString("CallableStatement.10"), "S1009");
/*      */     }
/*      */ 
/*  570 */     this.hasOutputParams = true;
/*      */ 
/*  572 */     return paramDescriptor;
/*      */   }
/*      */ 
/*      */   private void checkParameterIndexBounds(int paramIndex)
/*      */     throws SQLException
/*      */   {
/*  583 */     this.paramInfo.checkBounds(paramIndex);
/*      */   }
/*      */ 
/*      */   private void checkStreamability()
/*      */     throws SQLException
/*      */   {
/*  595 */     if ((this.hasOutputParams) && (createStreamingResultSet()))
/*  596 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00");
/*      */   }
/*      */ 
/*      */   public synchronized void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  602 */     super.clearParameters();
/*      */     try
/*      */     {
/*  605 */       if (this.outputParameterResults != null)
/*  606 */         this.outputParameterResults.close();
/*      */     }
/*      */     finally {
/*  609 */       this.outputParameterResults = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void fakeParameterTypes()
/*      */     throws SQLException
/*      */   {
/*  620 */     Field[] fields = new Field[13];
/*      */ 
/*  622 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/*  623 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/*  624 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/*  625 */     fields[3] = new Field("", "COLUMN_NAME", 1, 0);
/*  626 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 0);
/*  627 */     fields[5] = new Field("", "DATA_TYPE", 5, 0);
/*  628 */     fields[6] = new Field("", "TYPE_NAME", 1, 0);
/*  629 */     fields[7] = new Field("", "PRECISION", 4, 0);
/*  630 */     fields[8] = new Field("", "LENGTH", 4, 0);
/*  631 */     fields[9] = new Field("", "SCALE", 5, 0);
/*  632 */     fields[10] = new Field("", "RADIX", 5, 0);
/*  633 */     fields[11] = new Field("", "NULLABLE", 5, 0);
/*  634 */     fields[12] = new Field("", "REMARKS", 1, 0);
/*      */ 
/*  636 */     String procName = extractProcedureName();
/*      */ 
/*  638 */     byte[] procNameAsBytes = null;
/*      */     try
/*      */     {
/*  641 */       procNameAsBytes = procName.getBytes("UTF-8");
/*      */     } catch (UnsupportedEncodingException ueEx) {
/*  643 */       procNameAsBytes = StringUtils.s2b(procName, this.connection);
/*      */     }
/*      */ 
/*  646 */     ArrayList resultRows = new ArrayList();
/*      */ 
/*  648 */     for (int i = 0; i < this.parameterCount; i++) {
/*  649 */       byte[][] row = new byte[13][];
/*  650 */       row[0] = null;
/*  651 */       row[1] = null;
/*  652 */       row[2] = procNameAsBytes;
/*  653 */       row[3] = StringUtils.s2b(String.valueOf(i), this.connection);
/*      */ 
/*  655 */       row[4] = StringUtils.s2b(String.valueOf(2), this.connection);
/*      */ 
/*  659 */       row[5] = StringUtils.s2b(String.valueOf(12), this.connection);
/*      */ 
/*  661 */       row[6] = StringUtils.s2b("VARCHAR", this.connection);
/*  662 */       row[7] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  663 */       row[8] = StringUtils.s2b(Integer.toString(65535), this.connection);
/*  664 */       row[9] = StringUtils.s2b(Integer.toString(0), this.connection);
/*  665 */       row[10] = StringUtils.s2b(Integer.toString(10), this.connection);
/*      */ 
/*  667 */       row[11] = StringUtils.s2b(Integer.toString(2), this.connection);
/*      */ 
/*  671 */       row[12] = null;
/*      */ 
/*  673 */       resultRows.add(row);
/*      */     }
/*      */ 
/*  676 */     java.sql.ResultSet paramTypesRs = DatabaseMetaData.buildResultSet(fields, resultRows, this.connection);
/*      */ 
/*  679 */     convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */   }
/*      */ 
/*      */   private void determineParameterTypes() throws SQLException {
/*  683 */     if (this.connection.getNoAccessToProcedureBodies()) {
/*  684 */       fakeParameterTypes();
/*      */ 
/*  686 */       return;
/*      */     }
/*      */ 
/*  689 */     java.sql.ResultSet paramTypesRs = null;
/*      */     try
/*      */     {
/*  692 */       String procName = extractProcedureName();
/*      */ 
/*  694 */       java.sql.DatabaseMetaData dbmd = this.connection.getMetaData();
/*      */ 
/*  696 */       boolean useCatalog = false;
/*      */ 
/*  698 */       if (procName.indexOf(".") == -1) {
/*  699 */         useCatalog = true;
/*      */       }
/*      */ 
/*  702 */       paramTypesRs = dbmd.getProcedureColumns((this.connection.versionMeetsMinimum(5, 0, 2) & useCatalog) ? this.currentCatalog : null, null, procName, "%");
/*      */ 
/*  707 */       convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
/*      */     } finally {
/*  709 */       SQLException sqlExRethrow = null;
/*      */ 
/*  711 */       if (paramTypesRs != null) {
/*      */         try {
/*  713 */           paramTypesRs.close();
/*      */         } catch (SQLException sqlEx) {
/*  715 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */ 
/*  718 */         paramTypesRs = null;
/*      */       }
/*      */ 
/*  721 */       if (sqlExRethrow != null)
/*  722 */         throw sqlExRethrow;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void convertGetProcedureColumnsToInternalDescriptors(java.sql.ResultSet paramTypesRs) throws SQLException
/*      */   {
/*  728 */     if (!this.connection.isRunningOnJDK13()) {
/*  729 */       this.paramInfo = new CallableStatement.CallableStatementParamInfoJDBC3(this, paramTypesRs);
/*      */     }
/*      */     else
/*  732 */       this.paramInfo = new CallableStatement.CallableStatementParamInfo(this, paramTypesRs);
/*      */   }
/*      */ 
/*      */   public boolean execute()
/*      */     throws SQLException
/*      */   {
/*  742 */     boolean returnVal = false;
/*      */ 
/*  744 */     checkClosed();
/*      */ 
/*  746 */     checkStreamability();
/*      */ 
/*  748 */     synchronized (this.connection.getMutex()) {
/*  749 */       setInOutParamsOnServer();
/*  750 */       setOutParams();
/*      */ 
/*  752 */       returnVal = super.execute();
/*      */ 
/*  754 */       if (this.callingStoredFunction) {
/*  755 */         this.functionReturnValueResults = this.results;
/*  756 */         this.functionReturnValueResults.next();
/*  757 */         this.results = null;
/*      */       }
/*      */ 
/*  760 */       retrieveOutParams();
/*      */     }
/*      */ 
/*  763 */     if (!this.callingStoredFunction) {
/*  764 */       return returnVal;
/*      */     }
/*      */ 
/*  768 */     return false;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet executeQuery()
/*      */     throws SQLException
/*      */   {
/*  777 */     checkClosed();
/*      */ 
/*  779 */     checkStreamability();
/*      */ 
/*  781 */     java.sql.ResultSet execResults = null;
/*      */ 
/*  783 */     synchronized (this.connection.getMutex()) {
/*  784 */       setInOutParamsOnServer();
/*  785 */       setOutParams();
/*      */ 
/*  787 */       execResults = super.executeQuery();
/*      */ 
/*  789 */       retrieveOutParams();
/*      */     }
/*      */ 
/*  792 */     return execResults;
/*      */   }
/*      */ 
/*      */   public int executeUpdate()
/*      */     throws SQLException
/*      */   {
/*  801 */     int returnVal = -1;
/*      */ 
/*  803 */     checkClosed();
/*      */ 
/*  805 */     checkStreamability();
/*      */ 
/*  807 */     if (this.callingStoredFunction) {
/*  808 */       execute();
/*      */ 
/*  810 */       return -1;
/*      */     }
/*      */ 
/*  813 */     synchronized (this.connection.getMutex()) {
/*  814 */       setInOutParamsOnServer();
/*  815 */       setOutParams();
/*      */ 
/*  817 */       returnVal = super.executeUpdate();
/*      */ 
/*  819 */       retrieveOutParams();
/*      */     }
/*      */ 
/*  822 */     return returnVal;
/*      */   }
/*      */ 
/*      */   private String extractProcedureName() throws SQLException
/*      */   {
/*  827 */     int endCallIndex = StringUtils.indexOfIgnoreCase(this.originalSql, "CALL ");
/*      */ 
/*  829 */     int offset = 5;
/*      */ 
/*  831 */     if (endCallIndex == -1) {
/*  832 */       endCallIndex = StringUtils.indexOfIgnoreCase(this.originalSql, "SELECT ");
/*      */ 
/*  834 */       offset = 7;
/*      */     }
/*      */ 
/*  837 */     if (endCallIndex != -1) {
/*  838 */       StringBuffer nameBuf = new StringBuffer();
/*      */ 
/*  840 */       String trimmedStatement = this.originalSql.substring(endCallIndex + offset).trim();
/*      */ 
/*  843 */       int statementLength = trimmedStatement.length();
/*      */ 
/*  845 */       for (int i = 0; i < statementLength; i++) {
/*  846 */         char c = trimmedStatement.charAt(i);
/*      */ 
/*  848 */         if ((Character.isWhitespace(c)) || (c == '(') || (c == '?')) {
/*      */           break;
/*      */         }
/*  851 */         nameBuf.append(c);
/*      */       }
/*      */ 
/*  855 */       return nameBuf.toString();
/*      */     }
/*  857 */     throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000");
/*      */   }
/*      */ 
/*      */   private String fixParameterName(String paramNameIn)
/*      */     throws SQLException
/*      */   {
/*  874 */     if ((paramNameIn == null) || (paramNameIn.length() == 0)) {
/*  875 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.0") + paramNameIn == null ? Messages.getString("CallableStatement.15") : Messages.getString("CallableStatement.16"), "S1009");
/*      */     }
/*      */ 
/*  880 */     if (this.connection.getNoAccessToProcedureBodies()) {
/*  881 */       throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009");
/*      */     }
/*      */ 
/*  885 */     return mangleParameterName(paramNameIn);
/*      */   }
/*      */ 
/*      */   public synchronized Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/*  900 */     ResultSet rs = getOutputParameters(i);
/*      */ 
/*  902 */     Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
/*      */ 
/*  904 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  906 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Array getArray(String parameterName)
/*      */     throws SQLException
/*      */   {
/*  914 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/*  917 */     Array retValue = rs.getArray(fixParameterName(parameterName));
/*      */ 
/*  919 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  921 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized BigDecimal getBigDecimal(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*  929 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/*  931 */     BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/*  934 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  936 */     return retValue;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public synchronized BigDecimal getBigDecimal(int parameterIndex, int scale)
/*      */     throws SQLException
/*      */   {
/*  957 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/*  959 */     BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
/*      */ 
/*  962 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  964 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized BigDecimal getBigDecimal(String parameterName)
/*      */     throws SQLException
/*      */   {
/*  972 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/*  975 */     BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
/*      */ 
/*  977 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  979 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Blob getBlob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*  986 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/*  988 */     Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/*  991 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/*  993 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Blob getBlob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1000 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1003 */     Blob retValue = rs.getBlob(fixParameterName(parameterName));
/*      */ 
/* 1005 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1007 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getBoolean(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1015 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1017 */     boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1020 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1022 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized boolean getBoolean(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1030 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1033 */     boolean retValue = rs.getBoolean(fixParameterName(parameterName));
/*      */ 
/* 1035 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1037 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized byte getByte(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1044 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1046 */     byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1049 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1051 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized byte getByte(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1058 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1061 */     byte retValue = rs.getByte(fixParameterName(parameterName));
/*      */ 
/* 1063 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1065 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1072 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1074 */     byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1077 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1079 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized byte[] getBytes(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1087 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1090 */     byte[] retValue = rs.getBytes(fixParameterName(parameterName));
/*      */ 
/* 1092 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1094 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Clob getClob(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1101 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1103 */     Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1106 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1108 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Clob getClob(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1115 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1118 */     Clob retValue = rs.getClob(fixParameterName(parameterName));
/*      */ 
/* 1120 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1122 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Date getDate(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1129 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1131 */     Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1134 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1136 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Date getDate(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1144 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1146 */     Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */ 
/* 1149 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1151 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Date getDate(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1158 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1161 */     Date retValue = rs.getDate(fixParameterName(parameterName));
/*      */ 
/* 1163 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1165 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Date getDate(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1174 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1177 */     Date retValue = rs.getDate(fixParameterName(parameterName), cal);
/*      */ 
/* 1179 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1181 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized double getDouble(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1189 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1191 */     double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1194 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1196 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized double getDouble(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1204 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1207 */     double retValue = rs.getDouble(fixParameterName(parameterName));
/*      */ 
/* 1209 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1211 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized float getFloat(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1218 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1220 */     float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1223 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1225 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized float getFloat(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1233 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1236 */     float retValue = rs.getFloat(fixParameterName(parameterName));
/*      */ 
/* 1238 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1240 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized int getInt(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1247 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1249 */     int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1252 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1254 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized int getInt(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1261 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1264 */     int retValue = rs.getInt(fixParameterName(parameterName));
/*      */ 
/* 1266 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1268 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized long getLong(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1275 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1277 */     long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1280 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1282 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized long getLong(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1289 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1292 */     long retValue = rs.getLong(fixParameterName(parameterName));
/*      */ 
/* 1294 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1296 */     return retValue;
/*      */   }
/*      */ 
/*      */   private int getNamedParamIndex(String paramName, boolean forOut) throws SQLException
/*      */   {
/* 1301 */     if (this.connection.getNoAccessToProcedureBodies()) {
/* 1302 */       throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009");
/*      */     }
/*      */ 
/* 1306 */     if ((paramName == null) || (paramName.length() == 0)) {
/* 1307 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009");
/*      */     }
/*      */ 
/* 1311 */     CallableStatement.CallableStatementParam namedParamInfo = this.paramInfo.getParameter(paramName);
/*      */ 
/* 1314 */     if (this.paramInfo == null) {
/* 1315 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.3") + paramName + Messages.getString("CallableStatement.4"), "S1009");
/*      */     }
/*      */ 
/* 1320 */     if ((forOut) && (!namedParamInfo.isOut)) {
/* 1321 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.5") + paramName + Messages.getString("CallableStatement.6"), "S1009");
/*      */     }
/*      */ 
/* 1328 */     if (this.placeholderToParameterIndexMap == null) {
/* 1329 */       return namedParamInfo.index + 1;
/*      */     }
/*      */ 
/* 1332 */     for (int i = 0; i < this.placeholderToParameterIndexMap.length; i++) {
/* 1333 */       if (this.placeholderToParameterIndexMap[i] == namedParamInfo.index) {
/* 1334 */         return i + 1;
/*      */       }
/*      */     }
/*      */ 
/* 1338 */     throw SQLError.createSQLException("Can't find local placeholder mapping for parameter named \"" + paramName + "\".", "S1009");
/*      */   }
/*      */ 
/*      */   public synchronized Object getObject(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1347 */     CallableStatement.CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/*      */ 
/* 1349 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1351 */     Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), paramDescriptor.desiredJdbcType);
/*      */ 
/* 1355 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1357 */     return retVal;
/*      */   }
/*      */ 
/*      */   public synchronized Object getObject(int parameterIndex, Map map)
/*      */     throws SQLException
/*      */   {
/* 1365 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1367 */     Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
/*      */ 
/* 1370 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1372 */     return retVal;
/*      */   }
/*      */ 
/*      */   public synchronized Object getObject(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1380 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1383 */     Object retValue = rs.getObject(fixParameterName(parameterName));
/*      */ 
/* 1385 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1387 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Object getObject(String parameterName, Map map)
/*      */     throws SQLException
/*      */   {
/* 1396 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1399 */     Object retValue = rs.getObject(fixParameterName(parameterName), map);
/*      */ 
/* 1401 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1403 */     return retValue;
/*      */   }
/*      */ 
/*      */   private ResultSet getOutputParameters(int paramIndex)
/*      */     throws SQLException
/*      */   {
/* 1417 */     this.outputParamWasNull = false;
/*      */ 
/* 1419 */     if ((paramIndex == 1) && (this.callingStoredFunction) && (this.returnValueParam != null))
/*      */     {
/* 1421 */       return this.functionReturnValueResults;
/*      */     }
/*      */ 
/* 1424 */     if (this.outputParameterResults == null) {
/* 1425 */       if (this.paramInfo.numberOfParameters() == 0) {
/* 1426 */         throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009");
/*      */       }
/*      */ 
/* 1430 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000");
/*      */     }
/*      */ 
/* 1434 */     return this.outputParameterResults;
/*      */   }
/*      */ 
/*      */   public synchronized ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/* 1440 */     if (this.placeholderToParameterIndexMap == null) {
/* 1441 */       return (CallableStatement.CallableStatementParamInfoJDBC3)this.paramInfo;
/*      */     }
/* 1443 */     return new CallableStatement.CallableStatementParamInfoJDBC3(this, this.paramInfo);
/*      */   }
/*      */ 
/*      */   public synchronized Ref getRef(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1451 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1453 */     Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1456 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1458 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Ref getRef(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1465 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1468 */     Ref retValue = rs.getRef(fixParameterName(parameterName));
/*      */ 
/* 1470 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1472 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized short getShort(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1479 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1481 */     short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1484 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1486 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized short getShort(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1494 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1497 */     short retValue = rs.getShort(fixParameterName(parameterName));
/*      */ 
/* 1499 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1501 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized String getString(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1509 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1511 */     String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1514 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1516 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized String getString(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1524 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1527 */     String retValue = rs.getString(fixParameterName(parameterName));
/*      */ 
/* 1529 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1531 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Time getTime(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1538 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1540 */     Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1543 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1545 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Time getTime(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1553 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1555 */     Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */ 
/* 1558 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1560 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Time getTime(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1567 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1570 */     Time retValue = rs.getTime(fixParameterName(parameterName));
/*      */ 
/* 1572 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1574 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Time getTime(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1583 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1586 */     Time retValue = rs.getTime(fixParameterName(parameterName), cal);
/*      */ 
/* 1588 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1590 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1598 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1600 */     Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1603 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1605 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(int parameterIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1613 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1615 */     Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
/*      */ 
/* 1618 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1620 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1628 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1631 */     Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
/*      */ 
/* 1633 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1635 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized Timestamp getTimestamp(String parameterName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1644 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1647 */     Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
/*      */ 
/* 1650 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1652 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized URL getURL(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/* 1659 */     ResultSet rs = getOutputParameters(parameterIndex);
/*      */ 
/* 1661 */     URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
/*      */ 
/* 1664 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1666 */     return retValue;
/*      */   }
/*      */ 
/*      */   public synchronized URL getURL(String parameterName)
/*      */     throws SQLException
/*      */   {
/* 1673 */     ResultSet rs = getOutputParameters(0);
/*      */ 
/* 1676 */     URL retValue = rs.getURL(fixParameterName(parameterName));
/*      */ 
/* 1678 */     this.outputParamWasNull = rs.wasNull();
/*      */ 
/* 1680 */     return retValue;
/*      */   }
/*      */ 
/*      */   private int mapOutputParameterIndexToRsIndex(int paramIndex)
/*      */     throws SQLException
/*      */   {
/* 1686 */     if ((this.returnValueParam != null) && (paramIndex == 1)) {
/* 1687 */       return 1;
/*      */     }
/*      */ 
/* 1690 */     checkParameterIndexBounds(paramIndex);
/*      */ 
/* 1692 */     int localParamIndex = paramIndex - 1;
/*      */ 
/* 1694 */     if (this.placeholderToParameterIndexMap != null) {
/* 1695 */       localParamIndex = this.placeholderToParameterIndexMap[localParamIndex];
/*      */     }
/*      */ 
/* 1698 */     int rsIndex = this.parameterIndexToRsIndex[localParamIndex];
/*      */ 
/* 1700 */     if (rsIndex == -2147483648) {
/* 1701 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.21") + paramIndex + Messages.getString("CallableStatement.22"), "S1009");
/*      */     }
/*      */ 
/* 1707 */     return rsIndex + 1;
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1715 */     CallableStatement.CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
/* 1716 */     paramDescriptor.desiredJdbcType = sqlType;
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1724 */     registerOutParameter(parameterIndex, sqlType);
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1733 */     checkIsOutputParam(parameterIndex);
/*      */   }
/*      */ 
/*      */   public synchronized void registerOutParameter(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1742 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, int scale)
/*      */     throws SQLException
/*      */   {
/* 1751 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1760 */     registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName);
/*      */   }
/*      */ 
/*      */   private void retrieveOutParams()
/*      */     throws SQLException
/*      */   {
/* 1771 */     int numParameters = this.paramInfo.numberOfParameters();
/*      */ 
/* 1773 */     this.parameterIndexToRsIndex = new int[numParameters];
/*      */ 
/* 1775 */     for (int i = 0; i < numParameters; i++) {
/* 1776 */       this.parameterIndexToRsIndex[i] = -2147483648;
/*      */     }
/*      */ 
/* 1779 */     int localParamIndex = 0;
/*      */ 
/* 1781 */     if (numParameters > 0) {
/* 1782 */       StringBuffer outParameterQuery = new StringBuffer("SELECT ");
/*      */ 
/* 1784 */       boolean firstParam = true;
/* 1785 */       boolean hadOutputParams = false;
/*      */ 
/* 1787 */       Iterator paramIter = this.paramInfo.iterator();
/* 1788 */       while (paramIter.hasNext()) {
/* 1789 */         CallableStatement.CallableStatementParam retrParamInfo = (CallableStatement.CallableStatementParam)paramIter.next();
/*      */ 
/* 1792 */         if (retrParamInfo.isOut) {
/* 1793 */           hadOutputParams = true;
/*      */ 
/* 1795 */           this.parameterIndexToRsIndex[retrParamInfo.index] = (localParamIndex++);
/*      */ 
/* 1797 */           String outParameterName = mangleParameterName(retrParamInfo.paramName);
/*      */ 
/* 1799 */           if (!firstParam)
/* 1800 */             outParameterQuery.append(",");
/*      */           else {
/* 1802 */             firstParam = false;
/*      */           }
/*      */ 
/* 1805 */           if (!outParameterName.startsWith("@")) {
/* 1806 */             outParameterQuery.append('@');
/*      */           }
/*      */ 
/* 1809 */           outParameterQuery.append(outParameterName);
/*      */         }
/*      */       }
/*      */ 
/* 1813 */       if (hadOutputParams)
/*      */       {
/* 1816 */         Statement outParameterStmt = null;
/* 1817 */         java.sql.ResultSet outParamRs = null;
/*      */         try
/*      */         {
/* 1820 */           outParameterStmt = this.connection.createStatement();
/* 1821 */           outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
/*      */ 
/* 1823 */           this.outputParameterResults = ((ResultSet)outParamRs).copy();
/*      */ 
/* 1826 */           if (!this.outputParameterResults.next()) {
/* 1827 */             this.outputParameterResults.close();
/* 1828 */             this.outputParameterResults = null;
/*      */           }
/*      */         } finally {
/* 1831 */           if (outParameterStmt != null)
/* 1832 */             outParameterStmt.close();
/*      */         }
/*      */       }
/*      */       else {
/* 1836 */         this.outputParameterResults = null;
/*      */       }
/*      */     } else {
/* 1839 */       this.outputParameterResults = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1849 */     setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(String parameterName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1858 */     setBigDecimal(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(String parameterName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1867 */     setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
/*      */   }
/*      */ 
/*      */   public void setBoolean(String parameterName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1874 */     setBoolean(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setByte(String parameterName, byte x)
/*      */     throws SQLException
/*      */   {
/* 1881 */     setByte(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setBytes(String parameterName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1888 */     setBytes(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(String parameterName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1897 */     setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
/*      */   }
/*      */ 
/*      */   public void setDate(String parameterName, Date x)
/*      */     throws SQLException
/*      */   {
/* 1905 */     setDate(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setDate(String parameterName, Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1914 */     setDate(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */   public void setDouble(String parameterName, double x)
/*      */     throws SQLException
/*      */   {
/* 1921 */     setDouble(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setFloat(String parameterName, float x)
/*      */     throws SQLException
/*      */   {
/* 1928 */     setFloat(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   private void setInOutParamsOnServer()
/*      */     throws SQLException
/*      */   {
/* 1935 */     if (this.paramInfo.numParameters > 0) {
/* 1936 */       int parameterIndex = 0;
/*      */ 
/* 1938 */       Iterator paramIter = this.paramInfo.iterator();
/* 1939 */       while (paramIter.hasNext())
/*      */       {
/* 1941 */         CallableStatement.CallableStatementParam inParamInfo = (CallableStatement.CallableStatementParam)paramIter.next();
/*      */ 
/* 1944 */         if ((inParamInfo.isOut) && (inParamInfo.isIn)) {
/* 1945 */           String inOutParameterName = mangleParameterName(inParamInfo.paramName);
/* 1946 */           StringBuffer queryBuf = new StringBuffer(4 + inOutParameterName.length() + 1 + 1);
/*      */ 
/* 1948 */           queryBuf.append("SET ");
/* 1949 */           queryBuf.append(inOutParameterName);
/* 1950 */           queryBuf.append("=?");
/*      */ 
/* 1952 */           PreparedStatement setPstmt = null;
/*      */           try
/*      */           {
/* 1955 */             setPstmt = this.connection.clientPrepareStatement(queryBuf.toString());
/*      */ 
/* 1958 */             byte[] parameterAsBytes = getBytesRepresentation(inParamInfo.index);
/*      */ 
/* 1961 */             if (parameterAsBytes != null) {
/* 1962 */               if ((parameterAsBytes.length > 8) && (parameterAsBytes[0] == 95) && (parameterAsBytes[1] == 98) && (parameterAsBytes[2] == 105) && (parameterAsBytes[3] == 110) && (parameterAsBytes[4] == 97) && (parameterAsBytes[5] == 114) && (parameterAsBytes[6] == 121) && (parameterAsBytes[7] == 39))
/*      */               {
/* 1971 */                 setPstmt.setBytesNoEscapeNoQuotes(1, parameterAsBytes);
/*      */               }
/*      */               else
/* 1974 */                 setPstmt.setBytes(1, parameterAsBytes);
/*      */             }
/*      */             else {
/* 1977 */               setPstmt.setNull(1, 0);
/*      */             }
/*      */ 
/* 1980 */             setPstmt.executeUpdate();
/*      */           } finally {
/* 1982 */             if (setPstmt != null) {
/* 1983 */               setPstmt.close();
/*      */             }
/*      */           }
/*      */         }
/*      */ 
/* 1988 */         parameterIndex++;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setInt(String parameterName, int x)
/*      */     throws SQLException
/*      */   {
/* 1997 */     setInt(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setLong(String parameterName, long x)
/*      */     throws SQLException
/*      */   {
/* 2004 */     setLong(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 2011 */     setNull(getNamedParamIndex(parameterName, false), sqlType);
/*      */   }
/*      */ 
/*      */   public void setNull(String parameterName, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 2020 */     setNull(getNamedParamIndex(parameterName, false), sqlType, typeName);
/*      */   }
/*      */ 
/*      */   public void setObject(String parameterName, Object x)
/*      */     throws SQLException
/*      */   {
/* 2028 */     setObject(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType)
/*      */     throws SQLException
/*      */   {
/* 2037 */     setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
/*      */   }
/*      */ 
/*      */   public void setObject(String parameterName, Object x, int targetSqlType, int scale)
/*      */     throws SQLException
/*      */   {
/*      */   }
/*      */ 
/*      */   private void setOutParams()
/*      */     throws SQLException
/*      */   {
/* 2049 */     if (this.paramInfo.numParameters > 0) {
/* 2050 */       Iterator paramIter = this.paramInfo.iterator();
/* 2051 */       while (paramIter.hasNext()) {
/* 2052 */         CallableStatement.CallableStatementParam outParamInfo = (CallableStatement.CallableStatementParam)paramIter.next();
/*      */ 
/* 2055 */         if ((!this.callingStoredFunction) && (outParamInfo.isOut)) {
/* 2056 */           String outParameterName = mangleParameterName(outParamInfo.paramName);
/*      */           int outParamIndex;
/*      */           int outParamIndex;
/* 2060 */           if (this.placeholderToParameterIndexMap == null)
/* 2061 */             outParamIndex = outParamInfo.index + 1;
/*      */           else {
/* 2063 */             outParamIndex = this.placeholderToParameterIndexMap[(outParamInfo.index - 1)];
/*      */           }
/*      */ 
/* 2066 */           setBytesNoEscapeNoQuotes(outParamIndex, StringUtils.getBytes(outParameterName, this.charConverter, this.charEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode()));
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setShort(String parameterName, short x)
/*      */     throws SQLException
/*      */   {
/* 2081 */     setShort(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setString(String parameterName, String x)
/*      */     throws SQLException
/*      */   {
/* 2089 */     setString(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setTime(String parameterName, Time x)
/*      */     throws SQLException
/*      */   {
/* 2096 */     setTime(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setTime(String parameterName, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2105 */     setTime(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 2114 */     setTimestamp(getNamedParamIndex(parameterName, false), x);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 2123 */     setTimestamp(getNamedParamIndex(parameterName, false), x, cal);
/*      */   }
/*      */ 
/*      */   public void setURL(String parameterName, URL val)
/*      */     throws SQLException
/*      */   {
/* 2130 */     setURL(getNamedParamIndex(parameterName, false), val);
/*      */   }
/*      */ 
/*      */   public synchronized boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 2137 */     return this.outputParamWasNull;
/*      */   }
/*      */ 
/*      */   public int[] executeBatch() throws SQLException {
/* 2141 */     if (this.hasOutputParams) {
/* 2142 */       throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009");
/*      */     }
/*      */ 
/* 2146 */     return super.executeBatch();
/*      */   }
/*      */ 
/*      */   protected int getParameterIndexOffset() {
/* 2150 */     if (this.callingStoredFunction) {
/* 2151 */       return -1;
/*      */     }
/*      */ 
/* 2154 */     return super.getParameterIndexOffset();
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CallableStatement
 * JD-Core Version:    0.6.0
 */