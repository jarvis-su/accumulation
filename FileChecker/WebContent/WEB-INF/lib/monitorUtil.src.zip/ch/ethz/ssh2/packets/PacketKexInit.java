/*     */ package ch.ethz.ssh2.packets;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.CryptoWishList;
/*     */ import ch.ethz.ssh2.transport.KexParameters;
/*     */ import java.io.IOException;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class PacketKexInit
/*     */ {
/*     */   byte[] payload;
/*  20 */   KexParameters kp = new KexParameters();
/*     */ 
/*     */   public PacketKexInit(CryptoWishList cwl, SecureRandom rnd)
/*     */   {
/*  24 */     this.kp.cookie = new byte[16];
/*  25 */     rnd.nextBytes(this.kp.cookie);
/*     */ 
/*  27 */     this.kp.kex_algorithms = cwl.kexAlgorithms;
/*  28 */     this.kp.server_host_key_algorithms = cwl.serverHostKeyAlgorithms;
/*  29 */     this.kp.encryption_algorithms_client_to_server = cwl.c2s_enc_algos;
/*  30 */     this.kp.encryption_algorithms_server_to_client = cwl.s2c_enc_algos;
/*  31 */     this.kp.mac_algorithms_client_to_server = cwl.c2s_mac_algos;
/*  32 */     this.kp.mac_algorithms_server_to_client = cwl.s2c_mac_algos;
/*  33 */     this.kp.compression_algorithms_client_to_server = new String[] { "none" };
/*  34 */     this.kp.compression_algorithms_server_to_client = new String[] { "none" };
/*  35 */     this.kp.languages_client_to_server = new String[0];
/*  36 */     this.kp.languages_server_to_client = new String[0];
/*  37 */     this.kp.first_kex_packet_follows = false;
/*  38 */     this.kp.reserved_field1 = 0;
/*     */   }
/*     */ 
/*     */   public PacketKexInit(byte[] payload, int off, int len) throws IOException
/*     */   {
/*  43 */     this.payload = new byte[len];
/*  44 */     System.arraycopy(payload, off, this.payload, 0, len);
/*     */ 
/*  46 */     TypesReader tr = new TypesReader(payload, off, len);
/*     */ 
/*  48 */     int packet_type = tr.readByte();
/*     */ 
/*  50 */     if (packet_type != 20) {
/*  51 */       throw new IOException("This is not a KexInitPacket! (" + packet_type + ")");
/*     */     }
/*  53 */     this.kp.cookie = tr.readBytes(16);
/*  54 */     this.kp.kex_algorithms = tr.readNameList();
/*  55 */     this.kp.server_host_key_algorithms = tr.readNameList();
/*  56 */     this.kp.encryption_algorithms_client_to_server = tr.readNameList();
/*  57 */     this.kp.encryption_algorithms_server_to_client = tr.readNameList();
/*  58 */     this.kp.mac_algorithms_client_to_server = tr.readNameList();
/*  59 */     this.kp.mac_algorithms_server_to_client = tr.readNameList();
/*  60 */     this.kp.compression_algorithms_client_to_server = tr.readNameList();
/*  61 */     this.kp.compression_algorithms_server_to_client = tr.readNameList();
/*  62 */     this.kp.languages_client_to_server = tr.readNameList();
/*  63 */     this.kp.languages_server_to_client = tr.readNameList();
/*  64 */     this.kp.first_kex_packet_follows = tr.readBoolean();
/*  65 */     this.kp.reserved_field1 = tr.readUINT32();
/*     */ 
/*  67 */     if (tr.remain() != 0)
/*  68 */       throw new IOException("Padding in KexInitPacket!");
/*     */   }
/*     */ 
/*     */   public byte[] getPayload()
/*     */   {
/*  73 */     if (this.payload == null)
/*     */     {
/*  75 */       TypesWriter tw = new TypesWriter();
/*  76 */       tw.writeByte(20);
/*  77 */       tw.writeBytes(this.kp.cookie, 0, 16);
/*  78 */       tw.writeNameList(this.kp.kex_algorithms);
/*  79 */       tw.writeNameList(this.kp.server_host_key_algorithms);
/*  80 */       tw.writeNameList(this.kp.encryption_algorithms_client_to_server);
/*  81 */       tw.writeNameList(this.kp.encryption_algorithms_server_to_client);
/*  82 */       tw.writeNameList(this.kp.mac_algorithms_client_to_server);
/*  83 */       tw.writeNameList(this.kp.mac_algorithms_server_to_client);
/*  84 */       tw.writeNameList(this.kp.compression_algorithms_client_to_server);
/*  85 */       tw.writeNameList(this.kp.compression_algorithms_server_to_client);
/*  86 */       tw.writeNameList(this.kp.languages_client_to_server);
/*  87 */       tw.writeNameList(this.kp.languages_server_to_client);
/*  88 */       tw.writeBoolean(this.kp.first_kex_packet_follows);
/*  89 */       tw.writeUINT32(this.kp.reserved_field1);
/*  90 */       this.payload = tw.getBytes();
/*     */     }
/*  92 */     return this.payload;
/*     */   }
/*     */ 
/*     */   public KexParameters getKexParameters()
/*     */   {
/*  97 */     return this.kp;
/*     */   }
/*     */ 
/*     */   public String[] getCompression_algorithms_client_to_server()
/*     */   {
/* 102 */     return this.kp.compression_algorithms_client_to_server;
/*     */   }
/*     */ 
/*     */   public String[] getCompression_algorithms_server_to_client()
/*     */   {
/* 107 */     return this.kp.compression_algorithms_server_to_client;
/*     */   }
/*     */ 
/*     */   public byte[] getCookie()
/*     */   {
/* 112 */     return this.kp.cookie;
/*     */   }
/*     */ 
/*     */   public String[] getEncryption_algorithms_client_to_server()
/*     */   {
/* 117 */     return this.kp.encryption_algorithms_client_to_server;
/*     */   }
/*     */ 
/*     */   public String[] getEncryption_algorithms_server_to_client()
/*     */   {
/* 122 */     return this.kp.encryption_algorithms_server_to_client;
/*     */   }
/*     */ 
/*     */   public boolean isFirst_kex_packet_follows()
/*     */   {
/* 127 */     return this.kp.first_kex_packet_follows;
/*     */   }
/*     */ 
/*     */   public String[] getKex_algorithms()
/*     */   {
/* 132 */     return this.kp.kex_algorithms;
/*     */   }
/*     */ 
/*     */   public String[] getLanguages_client_to_server()
/*     */   {
/* 137 */     return this.kp.languages_client_to_server;
/*     */   }
/*     */ 
/*     */   public String[] getLanguages_server_to_client()
/*     */   {
/* 142 */     return this.kp.languages_server_to_client;
/*     */   }
/*     */ 
/*     */   public String[] getMac_algorithms_client_to_server()
/*     */   {
/* 147 */     return this.kp.mac_algorithms_client_to_server;
/*     */   }
/*     */ 
/*     */   public String[] getMac_algorithms_server_to_client()
/*     */   {
/* 152 */     return this.kp.mac_algorithms_server_to_client;
/*     */   }
/*     */ 
/*     */   public int getReserved_field1()
/*     */   {
/* 157 */     return this.kp.reserved_field1;
/*     */   }
/*     */ 
/*     */   public String[] getServer_host_key_algorithms()
/*     */   {
/* 162 */     return this.kp.server_host_key_algorithms;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexInit
 * JD-Core Version:    0.6.0
 */