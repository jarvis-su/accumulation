/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class CursorRowProvider
/*     */   implements RowData
/*     */ {
/*     */   private static final int BEFORE_START_OF_ROWS = -1;
/*     */   private List fetchedRows;
/*  49 */   private int currentPositionInEntireResult = -1;
/*     */ 
/*  55 */   private int currentPositionInFetchedRows = -1;
/*     */   private ResultSet owner;
/*  65 */   private boolean lastRowFetched = false;
/*     */   private Field[] fields;
/*     */   private MysqlIO mysql;
/*     */   private long statementIdOnServer;
/*     */   private ServerPreparedStatement prepStmt;
/*     */   private static final int SERVER_STATUS_LAST_ROW_SENT = 128;
/*  98 */   private boolean firstFetchCompleted = false;
/*     */ 
/*     */   public CursorRowProvider(MysqlIO ioChannel, ServerPreparedStatement creatingStatement, Field[] metadata)
/*     */   {
/* 112 */     this.currentPositionInEntireResult = -1;
/* 113 */     this.fields = metadata;
/* 114 */     this.mysql = ioChannel;
/* 115 */     this.statementIdOnServer = creatingStatement.getServerStatementId();
/* 116 */     this.prepStmt = creatingStatement;
/*     */   }
/*     */ 
/*     */   public boolean isAfterLast()
/*     */   {
/* 125 */     return (this.lastRowFetched) && (this.currentPositionInFetchedRows > this.fetchedRows.size());
/*     */   }
/*     */ 
/*     */   public Object[] getAt(int ind)
/*     */     throws SQLException
/*     */   {
/* 139 */     notSupported();
/*     */ 
/* 141 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean isBeforeFirst()
/*     */     throws SQLException
/*     */   {
/* 152 */     return this.currentPositionInEntireResult < 0;
/*     */   }
/*     */ 
/*     */   public void setCurrentRow(int rowNumber)
/*     */     throws SQLException
/*     */   {
/* 164 */     notSupported();
/*     */   }
/*     */ 
/*     */   public int getCurrentRowNumber()
/*     */     throws SQLException
/*     */   {
/* 175 */     return this.currentPositionInEntireResult + 1;
/*     */   }
/*     */ 
/*     */   public boolean isDynamic()
/*     */   {
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */     throws SQLException
/*     */   {
/* 198 */     return (isBeforeFirst()) && (isAfterLast());
/*     */   }
/*     */ 
/*     */   public boolean isFirst()
/*     */     throws SQLException
/*     */   {
/* 209 */     return this.currentPositionInEntireResult == 0;
/*     */   }
/*     */ 
/*     */   public boolean isLast()
/*     */     throws SQLException
/*     */   {
/* 220 */     return (this.lastRowFetched) && (this.currentPositionInFetchedRows == this.fetchedRows.size() - 1);
/*     */   }
/*     */ 
/*     */   public void addRow(byte[][] row)
/*     */     throws SQLException
/*     */   {
/* 234 */     notSupported();
/*     */   }
/*     */ 
/*     */   public void afterLast()
/*     */     throws SQLException
/*     */   {
/* 244 */     notSupported();
/*     */   }
/*     */ 
/*     */   public void beforeFirst()
/*     */     throws SQLException
/*     */   {
/* 254 */     notSupported();
/*     */   }
/*     */ 
/*     */   public void beforeLast()
/*     */     throws SQLException
/*     */   {
/* 264 */     notSupported();
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws SQLException
/*     */   {
/* 275 */     this.fields = null;
/* 276 */     this.owner = null;
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */     throws SQLException
/*     */   {
/* 288 */     if ((this.fetchedRows != null) && (this.fetchedRows.size() == 0)) {
/* 289 */       return false;
/*     */     }
/*     */ 
/* 292 */     if (this.currentPositionInEntireResult != -1)
/*     */     {
/* 295 */       if (this.currentPositionInFetchedRows < this.fetchedRows.size() - 1)
/* 296 */         return true;
/* 297 */       if ((this.currentPositionInFetchedRows == this.fetchedRows.size()) && (this.lastRowFetched))
/*     */       {
/* 300 */         return false;
/*     */       }
/*     */ 
/* 303 */       fetchMoreRows();
/*     */ 
/* 305 */       return this.fetchedRows.size() > 0;
/*     */     }
/*     */ 
/* 311 */     fetchMoreRows();
/*     */ 
/* 313 */     return this.fetchedRows.size() > 0;
/*     */   }
/*     */ 
/*     */   public void moveRowRelative(int rows)
/*     */     throws SQLException
/*     */   {
/* 325 */     notSupported();
/*     */   }
/*     */ 
/*     */   public Object[] next()
/*     */     throws SQLException
/*     */   {
/* 337 */     this.currentPositionInEntireResult += 1;
/* 338 */     this.currentPositionInFetchedRows += 1;
/*     */ 
/* 341 */     if ((this.fetchedRows != null) && (this.fetchedRows.size() == 0)) {
/* 342 */       return null;
/*     */     }
/*     */ 
/* 345 */     if (this.currentPositionInFetchedRows > this.fetchedRows.size() - 1) {
/* 346 */       fetchMoreRows();
/* 347 */       this.currentPositionInFetchedRows = 0;
/*     */     }
/*     */ 
/* 350 */     Object[] row = (Object[])this.fetchedRows.get(this.currentPositionInFetchedRows);
/*     */ 
/* 353 */     return row;
/*     */   }
/*     */ 
/*     */   private void fetchMoreRows()
/*     */     throws SQLException
/*     */   {
/* 360 */     if (this.lastRowFetched) {
/* 361 */       this.fetchedRows = new ArrayList(0);
/* 362 */       return;
/*     */     }
/*     */ 
/* 365 */     synchronized (this.owner.connection.getMutex()) {
/* 366 */       if (!this.firstFetchCompleted) {
/* 367 */         this.firstFetchCompleted = true;
/*     */       }
/*     */ 
/* 370 */       int numRowsToFetch = this.owner.getFetchSize();
/*     */ 
/* 372 */       if (numRowsToFetch == 0) {
/* 373 */         numRowsToFetch = this.prepStmt.getFetchSize();
/*     */       }
/*     */ 
/* 376 */       if (numRowsToFetch == -2147483648)
/*     */       {
/* 380 */         numRowsToFetch = 1;
/*     */       }
/*     */ 
/* 383 */       this.fetchedRows = this.mysql.fetchRowsViaCursor(this.fetchedRows, this.statementIdOnServer, this.fields, numRowsToFetch);
/*     */ 
/* 385 */       this.currentPositionInFetchedRows = -1;
/*     */ 
/* 387 */       if ((this.mysql.getServerStatus() & 0x80) != 0)
/* 388 */         this.lastRowFetched = true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeRow(int ind)
/*     */     throws SQLException
/*     */   {
/* 402 */     notSupported();
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 411 */     return -1;
/*     */   }
/*     */ 
/*     */   private void nextRecord() throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   private void notSupported() throws SQLException {
/* 419 */     throw new OperationNotSupportedException();
/*     */   }
/*     */ 
/*     */   public void setOwner(ResultSet rs)
/*     */   {
/* 428 */     this.owner = rs;
/*     */   }
/*     */ 
/*     */   public ResultSet getOwner()
/*     */   {
/* 437 */     return this.owner;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CursorRowProvider
 * JD-Core Version:    0.6.0
 */