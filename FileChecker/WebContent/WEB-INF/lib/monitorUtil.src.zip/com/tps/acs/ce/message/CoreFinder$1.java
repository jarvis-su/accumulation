/*    */ package com.acs.ce.message;
/*    */ 
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ import java.util.regex.Pattern;
/*    */ 
/*    */ final class CoreFinder$1
/*    */   implements FilenameFilter
/*    */ {
/*    */   public boolean accept(File dir, String name)
/*    */   {
/* 71 */     return Pattern.matches(this.val$regexp, name);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.ce.message.CoreFinder.1
 * JD-Core Version:    0.6.0
 */