/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class FesRegistration extends RegistrationData
/*    */ {
/*    */   private static final long serialVersionUID = 1138560264562647042L;
/*    */   private static final String IP = "IP";
/*    */   private static final String PORT = "PORT";
/*    */ 
/*    */   public FesRegistration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public FesRegistration(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public FesRegistration(String ip, int port) {
/* 23 */     setData("IP", ip);
/* 24 */     setData("PORT", new Integer(port));
/*    */   }
/*    */ 
/*    */   public String getIP() {
/* 28 */     String ip = "";
/* 29 */     if (getData("IP") != null) {
/* 30 */       ip = (String)getData("IP");
/*    */     }
/* 32 */     return ip;
/*    */   }
/*    */ 
/*    */   public int getPort() {
/* 36 */     int retVal = -1;
/* 37 */     if (getData("PORT") != null) {
/* 38 */       retVal = ((Integer)getData("PORT")).intValue();
/*    */     }
/* 40 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 44 */     return super.toString() + 
/* 45 */       "  IP: " + getIP() + "\n" + 
/* 46 */       "  Port: " + getPort() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.FesRegistration
 * JD-Core Version:    0.6.0
 */