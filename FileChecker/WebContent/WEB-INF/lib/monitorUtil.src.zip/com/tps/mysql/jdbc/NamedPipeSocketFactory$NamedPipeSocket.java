/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.io.RandomAccessFile;
/*    */ import java.net.Socket;
/*    */ 
/*    */ class NamedPipeSocketFactory$NamedPipeSocket extends Socket
/*    */ {
/*    */   private boolean isClosed;
/*    */   private RandomAccessFile namedPipeFile;
/*    */   private final NamedPipeSocketFactory this$0;
/*    */ 
/*    */   NamedPipeSocketFactory$NamedPipeSocket(NamedPipeSocketFactory this$0, String filePath)
/*    */     throws IOException
/*    */   {
/* 51 */     this.this$0 = this$0;
/*    */ 
/* 47 */     this.isClosed = false;
/*    */ 
/* 52 */     if ((filePath == null) || (filePath.length() == 0)) {
/* 53 */       throw new IOException(Messages.getString("NamedPipeSocketFactory.4"));
/*    */     }
/*    */ 
/* 57 */     this.namedPipeFile = new RandomAccessFile(filePath, "rw");
/*    */   }
/*    */ 
/*    */   public synchronized void close()
/*    */     throws IOException
/*    */   {
/* 64 */     this.namedPipeFile.close();
/* 65 */     this.isClosed = true;
/*    */   }
/*    */ 
/*    */   public InputStream getInputStream()
/*    */     throws IOException
/*    */   {
/* 72 */     return new NamedPipeSocketFactory.RandomAccessFileInputStream(this.this$0, this.namedPipeFile);
/*    */   }
/*    */ 
/*    */   public OutputStream getOutputStream()
/*    */     throws IOException
/*    */   {
/* 79 */     return new NamedPipeSocketFactory.RandomAccessFileOutputStream(this.this$0, this.namedPipeFile);
/*    */   }
/*    */ 
/*    */   public boolean isClosed()
/*    */   {
/* 86 */     return this.isClosed;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.NamedPipeSocketFactory.NamedPipeSocket
 * JD-Core Version:    0.6.0
 */