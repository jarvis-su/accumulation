package com.ibm.wsdl.extensions.soap;

import java.util.List;
import javax.wsdl.extensions.soap.SOAPFault;
import javax.xml.namespace.QName;

public class SOAPFaultImpl
  implements SOAPFault
{
  protected QName elementType = SOAPConstants.Q_ELEM_SOAP_FAULT;
  protected Boolean required = null;
  protected String name = null;
  protected String use = null;
  protected List encodingStyles = null;
  protected String namespaceURI = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setUse(String paramString)
  {
    this.use = paramString;
  }

  public String getUse()
  {
    return this.use;
  }

  public void setEncodingStyles(List paramList)
  {
    this.encodingStyles = paramList;
  }

  public List getEncodingStyles()
  {
    return this.encodingStyles;
  }

  public void setNamespaceURI(String paramString)
  {
    this.namespaceURI = paramString;
  }

  public String getNamespaceURI()
  {
    return this.namespaceURI;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("SOAPFault (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.name != null)
      localStringBuffer.append("\nname=" + this.name);
    if (this.use != null)
      localStringBuffer.append("\nuse=" + this.use);
    if (this.encodingStyles != null)
      localStringBuffer.append("\nencodingStyles=" + this.encodingStyles);
    if (this.namespaceURI != null)
      localStringBuffer.append("\nnamespaceURI=" + this.namespaceURI);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.soap.SOAPFaultImpl
 * JD-Core Version:    0.6.0
 */