/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ class NamedPipeSocketFactory$RandomAccessFileOutputStream extends OutputStream
/*     */ {
/*     */   RandomAccessFile raFile;
/*     */   private final NamedPipeSocketFactory this$0;
/*     */ 
/*     */   NamedPipeSocketFactory$RandomAccessFileOutputStream(NamedPipeSocketFactory this$0, RandomAccessFile file)
/*     */   {
/* 142 */     this.this$0 = this$0;
/* 143 */     this.raFile = file;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 150 */     this.raFile.close();
/*     */   }
/*     */ 
/*     */   public void write(byte[] b)
/*     */     throws IOException
/*     */   {
/* 157 */     this.raFile.write(b);
/*     */   }
/*     */ 
/*     */   public void write(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 164 */     this.raFile.write(b, off, len);
/*     */   }
/*     */ 
/*     */   public void write(int b)
/*     */     throws IOException
/*     */   {
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.NamedPipeSocketFactory.RandomAccessFileOutputStream
 * JD-Core Version:    0.6.0
 */