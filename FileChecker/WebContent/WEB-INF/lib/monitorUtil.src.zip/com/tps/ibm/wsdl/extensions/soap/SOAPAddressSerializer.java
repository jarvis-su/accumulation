package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.soap.SOAPAddress;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPAddressSerializer
  implements ExtensionSerializer, ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPAddress localSOAPAddress = (SOAPAddress)paramExtensibilityElement;
    if (localSOAPAddress != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "address", paramDefinition);
      paramPrintWriter.print("      <" + str);
      DOMUtils.printAttribute("location", localSOAPAddress.getLocationURI(), paramPrintWriter);
      Boolean localBoolean = localSOAPAddress.getRequired();
      if (localBoolean != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("/>");
    }
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPAddress localSOAPAddress = (SOAPAddress)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "location");
    String str2 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      localSOAPAddress.setLocationURI(str1);
    if (str2 != null)
      localSOAPAddress.setRequired(new Boolean(str2));
    return localSOAPAddress;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.soap.SOAPAddressSerializer
 * JD-Core Version:    0.6.0
 */