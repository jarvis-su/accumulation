/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ public class DatabaseMetaData$SingleStringIterator extends DatabaseMetaData.IteratorWithCleanup
/*     */ {
/*     */   boolean onFirst;
/*     */   String value;
/*     */   private final DatabaseMetaData this$0;
/*     */ 
/*     */   DatabaseMetaData$SingleStringIterator(DatabaseMetaData this$0, String s)
/*     */   {
/* 143 */     super(this$0); this.this$0 = this$0;
/*     */ 
/* 139 */     this.onFirst = true;
/*     */ 
/* 144 */     this.value = s;
/*     */   }
/*     */ 
/*     */   void close() throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   boolean hasNext() throws SQLException
/*     */   {
/* 153 */     return this.onFirst;
/*     */   }
/*     */ 
/*     */   Object next() throws SQLException {
/* 157 */     this.onFirst = false;
/* 158 */     return this.value;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.SingleStringIterator
 * JD-Core Version:    0.6.0
 */