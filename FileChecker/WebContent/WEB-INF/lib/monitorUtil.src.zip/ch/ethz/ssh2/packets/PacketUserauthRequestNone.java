/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthRequestNone
/*    */ {
/*    */   byte[] payload;
/*    */   String userName;
/*    */   String serviceName;
/*    */ 
/*    */   public PacketUserauthRequestNone(String serviceName, String user)
/*    */   {
/* 20 */     this.serviceName = serviceName;
/* 21 */     this.userName = user;
/*    */   }
/*    */ 
/*    */   public PacketUserauthRequestNone(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 26 */     this.payload = new byte[len];
/* 27 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 29 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 31 */     int packet_type = tr.readByte();
/*    */ 
/* 33 */     if (packet_type != 50) {
/* 34 */       throw new IOException("This is not a SSH_MSG_USERAUTH_REQUEST! (" + packet_type + ")");
/*    */     }
/* 36 */     this.userName = tr.readString();
/* 37 */     this.serviceName = tr.readString();
/*    */ 
/* 39 */     String method = tr.readString();
/*    */ 
/* 41 */     if (!method.equals("none")) {
/* 42 */       throw new IOException("This is not a SSH_MSG_USERAUTH_REQUEST with type none!");
/*    */     }
/* 44 */     if (tr.remain() != 0)
/* 45 */       throw new IOException("Padding in SSH_MSG_USERAUTH_REQUEST packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 50 */     if (this.payload == null)
/*    */     {
/* 52 */       TypesWriter tw = new TypesWriter();
/* 53 */       tw.writeByte(50);
/* 54 */       tw.writeString(this.userName);
/* 55 */       tw.writeString(this.serviceName);
/* 56 */       tw.writeString("none");
/* 57 */       this.payload = tw.getBytes();
/*    */     }
/* 59 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthRequestNone
 * JD-Core Version:    0.6.0
 */