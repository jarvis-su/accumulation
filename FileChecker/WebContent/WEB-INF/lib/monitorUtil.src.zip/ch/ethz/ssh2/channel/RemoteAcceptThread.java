/*    */ package ch.ethz.ssh2.channel;
/*    */ 
/*    */ import ch.ethz.ssh2.log.Logger;
/*    */ import java.io.IOException;
/*    */ import java.net.Socket;
/*    */ 
/*    */ public class RemoteAcceptThread extends Thread
/*    */ {
/* 17 */   private static final Logger log = Logger.getLogger(RemoteAcceptThread.class);
/*    */   Channel c;
/*    */   String remoteConnectedAddress;
/*    */   int remoteConnectedPort;
/*    */   String remoteOriginatorAddress;
/*    */   int remoteOriginatorPort;
/*    */   String targetAddress;
/*    */   int targetPort;
/*    */   Socket s;
/*    */ 
/*    */   public RemoteAcceptThread(Channel c, String remoteConnectedAddress, int remoteConnectedPort, String remoteOriginatorAddress, int remoteOriginatorPort, String targetAddress, int targetPort)
/*    */   {
/* 33 */     this.c = c;
/* 34 */     this.remoteConnectedAddress = remoteConnectedAddress;
/* 35 */     this.remoteConnectedPort = remoteConnectedPort;
/* 36 */     this.remoteOriginatorAddress = remoteOriginatorAddress;
/* 37 */     this.remoteOriginatorPort = remoteOriginatorPort;
/* 38 */     this.targetAddress = targetAddress;
/* 39 */     this.targetPort = targetPort;
/*    */ 
/* 41 */     if (log.isEnabled())
/* 42 */       log.log(20, "RemoteAcceptThread: " + remoteConnectedAddress + "/" + remoteConnectedPort + ", R: " + 
/* 43 */         remoteOriginatorAddress + "/" + remoteOriginatorPort);
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 50 */       this.c.cm.sendOpenConfirmation(this.c);
/*    */ 
/* 52 */       this.s = new Socket(this.targetAddress, this.targetPort);
/*    */ 
/* 54 */       StreamForwarder r2l = new StreamForwarder(this.c, null, null, this.c.getStdoutStream(), this.s.getOutputStream(), 
/* 55 */         "RemoteToLocal");
/* 56 */       StreamForwarder l2r = new StreamForwarder(this.c, null, null, this.s.getInputStream(), this.c.getStdinStream(), 
/* 57 */         "LocalToRemote");
/*    */ 
/* 61 */       r2l.setDaemon(true);
/* 62 */       r2l.start();
/* 63 */       l2r.run();
/*    */ 
/* 65 */       while (r2l.isAlive())
/*    */       {
/*    */         try
/*    */         {
/* 69 */           r2l.join();
/*    */         }
/*    */         catch (InterruptedException localInterruptedException)
/*    */         {
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 78 */       this.c.cm.closeChannel(this.c, "EOF on both streams reached.", true);
/* 79 */       this.s.close();
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 83 */       log.log(50, "IOException in proxy code: " + e.getMessage());
/*    */       try
/*    */       {
/* 87 */         this.c.cm.closeChannel(this.c, "IOException in proxy code (" + e.getMessage() + ")", true);
/*    */       }
/*    */       catch (IOException localIOException1)
/*    */       {
/*    */       }
/*    */       try
/*    */       {
/* 94 */         if (this.s != null)
/* 95 */           this.s.close();
/*    */       }
/*    */       catch (IOException localIOException2)
/*    */       {
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.RemoteAcceptThread
 * JD-Core Version:    0.6.0
 */