/*     */ package com.acs.fileChecker;
/*     */ 
/*     */ import com.acs.eppic.message.AlertData;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.messageservice.MessageSender;
/*     */ import com.acs.fileChecker.fileserver.FileCheckerMain3;
/*     */ import com.smj.dbvariable.VarCache;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.Vector;
/*     */ import java.util.regex.Pattern;
/*     */ import org.apache.commons.mail.EmailException;
/*     */ import org.apache.commons.mail.MultiPartEmail;
/*     */ 
/*     */ public class FileChecker
/*     */ {
/*     */   private Calendar _cal;
/*     */   private Calendar _today;
/*     */   private String _dbhost;
/*     */   private String _dbname;
/*     */   private String _dbuser;
/*     */   private String _dbpass;
/*     */   private String _username;
/*     */   private String _emailFrom;
/*     */   private String _emailHost;
/*     */   private String _emailReplyTo;
/*     */   private String _keyFile;
/*     */   private String _remoteCommand;
/*     */   private int _numGroups;
/*     */   private Map _states;
/*     */   private MessageSender _ms;
/*     */   private Connection _conn;
/*     */   private PreparedStatement _ps;
/*     */   private String _checkDate;
/*     */ 
/*     */   public static void main(String[] argv)
/*     */   {
/*  46 */     FileChecker x = null;
/*  47 */     if (argv.length <= 2)
/*     */     {
/*  49 */       if (argv[0].equals("-unignoreAll"))
/*     */       {
/*  51 */         x = new FileChecker("/config/filechecker.properties");
/*  52 */         x.unignoreAll();
/*     */       }
/*  54 */       else if (argv[0].equals("-ignore"))
/*     */       {
/*  56 */         x = new FileChecker("/config/filechecker.properties");
/*  57 */         String state = argv[1];
/*  58 */         x.ignoreAFile(state);
/*     */       }
/*  60 */       else if (argv[0].equals("-listAllFor"))
/*     */       {
/*  62 */         x = new FileChecker("/config/filechecker.properties");
/*  63 */         String state = argv[1];
/*  64 */         System.out.println(x.getAllFor(state));
/*     */       }
/*     */       else {
/*  67 */         String states = argv[0];
/*  68 */         String dateFor = argv[1];
/*  69 */         String files = null;
/*  70 */         x = new FileChecker(dateFor, "/config/filechecker.properties");
/*  71 */         for (Iterator iterator = x.commasToArray(states).iterator(); iterator.hasNext(); )
/*     */         {
/*  73 */           String instance = (String)iterator.next();
/*  74 */           ReportList replist = x.getFilesForInstanceLocal(instance, false);
/*  75 */           if (replist == null)
/*     */             continue;
/*  77 */           files = x.checkFilesLocal(replist, false, true);
/*  78 */           if ((files != null) && (!files.equals(""))) {
/*  79 */             System.out.println(files);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*  84 */       x.cleanup();
/*     */     }
/*  86 */     else if (argv.length >= 3)
/*     */     {
/*  88 */       String states = argv[0];
/*  89 */       String dateFor = argv[1];
/*  90 */       x = new FileChecker(dateFor, "/config/filechecker.properties");
/*  91 */       String files = null;
/*  92 */       String alertType = argv[2];
/*  93 */       for (Iterator iterator1 = x.commasToArray(states).iterator(); iterator1.hasNext(); )
/*     */       {
/*  95 */         String instance = (String)iterator1.next();
/*  96 */         ReportList replist = x.getFilesForInstanceLocal(instance, true);
/*  97 */         files = x.checkFilesLocal(replist, true, false);
/*  98 */         if (alertType.startsWith("-mailTo="))
/*     */         {
/* 100 */           String emailList = alertType.substring(8);
/*     */ 
/* 102 */           x.mailIt(instance.toUpperCase(), emailList, files);
/*     */         }
/* 104 */         else if ((alertType.startsWith("-alert")) && (!files.equals(""))) {
/* 105 */           x.sendAlert(instance.toUpperCase(), "FileChecker Detected problems\n\n" + files);
/* 106 */         }if (!files.equals("")) {
/* 107 */           System.out.println(files);
/*     */         }
/*     */       }
/* 110 */       x.cleanup();
/*     */     }
/*     */     else {
/* 113 */       System.out.println("Usage: FileChecker instance1,instance2 \n -mailTo=email1,email2...\n -alert (Sends alerts to EMMS)");
/*     */     }
/*     */   }
/*     */ 
/*     */   public FileChecker(String properties)
/*     */   {
/* 119 */     this._dbhost = null;
/* 120 */     this._dbname = null;
/* 121 */     this._dbuser = null;
/* 122 */     this._dbpass = null;
/* 123 */     this._username = null;
/* 124 */     this._emailFrom = null;
/* 125 */     this._emailHost = null;
/* 126 */     this._emailReplyTo = null;
/* 127 */     this._keyFile = null;
/* 128 */     this._remoteCommand = "/usr/local/java14/bin/java -classpath /home/monitor/lib FileCheckerMain3 2>/tmp/blah";
/* 129 */     this._states = new HashMap();
/* 130 */     this._ms = null;
/* 131 */     this._cal = Calendar.getInstance();
/* 132 */     this._ms = new MessageSender();
/* 133 */     this._today = Calendar.getInstance();
/* 134 */     this._checkDate = (getMonth() + "/" + getDay() + "/" + getYear());
/*     */     try
/*     */     {
/* 137 */       Class.forName("org.sqlite.JDBC");
/* 138 */       this._conn = DriverManager.getConnection("jdbc:sqlite:fileChecker.db");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 142 */       e.printStackTrace();
/*     */     }
/* 144 */     loadProperties(properties);
/* 145 */     this._ps = prepare(this._checkDate);
/*     */   }
/*     */ 
/*     */   public FileChecker(String checkDate, String properties)
/*     */   {
/* 150 */     this._dbhost = null;
/* 151 */     this._dbname = null;
/* 152 */     this._dbuser = null;
/* 153 */     this._dbpass = null;
/* 154 */     this._username = null;
/* 155 */     this._emailFrom = null;
/* 156 */     this._emailHost = null;
/* 157 */     this._emailReplyTo = null;
/* 158 */     this._keyFile = null;
/* 159 */     this._remoteCommand = "/usr/local/java14/bin/java -classpath /home/monitor/lib FileCheckerMain3 2>/tmp/blah";
/* 160 */     this._states = new HashMap();
/* 161 */     this._ms = null;
/* 162 */     this._cal = strToCal(checkDate);
/* 163 */     this._ms = new MessageSender();
/* 164 */     this._today = Calendar.getInstance();
/* 165 */     this._checkDate = checkDate;
/*     */     try
/*     */     {
/* 168 */       Class.forName("org.sqlite.JDBC");
/* 169 */       this._conn = DriverManager.getConnection("jdbc:sqlite:fileChecker.db");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 173 */       e.printStackTrace();
/*     */     }
/* 175 */     loadProperties(properties);
/* 176 */     this._ps = prepare(checkDate);
/*     */   }
/*     */ 
/*     */   public void sendAlert(String id, String desc)
/*     */   {
/* 181 */     Message m = new Message(id, "FILECHECK", 1, "");
/*     */ 
/* 183 */     m.setM_MessageData(new AlertData("_GENERIC_1", "FileChecker Detected problems\n\n\"http://acsint414:8080/FileChecker/FileChecker?state=" + id + "&checknow=true&dateFor=" + this._checkDate + "\""));
/*     */ 
/* 185 */     this._ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public ArrayList commasToArray(String s)
/*     */   {
/* 190 */     ArrayList ar = new ArrayList();
/* 191 */     for (StringTokenizer st = new StringTokenizer(s, ","); st.hasMoreTokens(); ar.add(st.nextToken()));
/* 192 */     return ar;
/*     */   }
/*     */ 
/*     */   public void mailIt(String id, String emailList, String stuff)
/*     */   {
/* 197 */     ArrayList list = commasToArray(emailList);
/* 198 */     if ((stuff == null) || (stuff.equals("")) || (this._emailFrom == null) || (this._emailHost == null))
/* 199 */       return;
/* 200 */     MultiPartEmail email = new MultiPartEmail();
/*     */     try
/*     */     {
/* 203 */       email.setFrom(this._emailFrom);
/* 204 */       email.addReplyTo(this._emailReplyTo);
/*     */ 
/* 208 */       email.setSubject(id + " - FILECHECK has had an error");
/* 209 */       email.setHostName(this._emailHost);
/*     */       String s;
/* 211 */       for (Iterator iterator = list.iterator(); iterator.hasNext(); email.addTo(s)) {
/* 212 */         s = (String)iterator.next();
/*     */       }
/*     */ 
/* 215 */       String emailtext = "LAECC - FILECHECK {DESCRIPTION=FileChecker Detected problems\n\n\"http://acsint414:8080/FileChecker/FileChecker?state=" + id + "&checknow=true&dateFor=" + this._checkDate + "\",CODE=_GENERIC_1}";
/* 216 */       email.addPart(emailtext, "text/plain");
/* 217 */       email.send();
/*     */     }
/*     */     catch (EmailException e)
/*     */     {
/* 221 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void loadProperties(String filename)
/*     */   {
/* 227 */     Properties props = new Properties();
/*     */     try
/*     */     {
/* 232 */       InputStream is = getClass().getResourceAsStream(filename);
/* 233 */       props.load(is);
/* 234 */       is.close();
/* 235 */       this._username = props.getProperty("remote.username");
/* 236 */       this._keyFile = props.getProperty("keyfile");
/* 237 */       this._remoteCommand = props.getProperty("remote.command");
/* 238 */       this._dbhost = props.getProperty("database.host");
/* 239 */       this._dbname = props.getProperty("database.schema");
/* 240 */       this._dbuser = props.getProperty("database.user");
/* 241 */       this._dbpass = props.getProperty("database.pass");
/* 242 */       this._emailFrom = props.getProperty("email.from");
/* 243 */       this._emailHost = props.getProperty("email.host");
/* 244 */       this._emailReplyTo = props.getProperty("email.replyto");
/* 245 */       this._numGroups = Integer.valueOf(props.getProperty("products.numgroups")).intValue();
/* 246 */       for (int i = 0; i < this._numGroups; i++)
/*     */       {
/* 248 */         int numinstances = Integer.valueOf(props.getProperty("products." + i + ".numInstances")).intValue();
/* 249 */         for (int j = 0; j < numinstances; j++)
/*     */         {
/* 251 */           String name = props.getProperty("products." + i + "." + j + ".name");
/* 252 */           String instanceId = props.getProperty("products." + i + "." + j + ".instanceId");
/* 253 */           this._states.put(name.toUpperCase(), instanceId);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 258 */       VarCache.getInstance(this._conn);
/*     */     }
/*     */     catch (IOException ioe)
/*     */     {
/* 262 */       System.out.println("Could not load properties " + filename);
/* 263 */       return;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set getStates()
/*     */   {
/* 269 */     return this._states.keySet();
/*     */   }
/*     */ 
/*     */   public void cleanup()
/*     */   {
/*     */     try
/*     */     {
/* 276 */       Thread.sleep(2000L);
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 280 */       e.printStackTrace();
/*     */     }
/* 282 */     this._ms.setServiceEnabled(false);
/* 283 */     this._ms = null;
/*     */     try
/*     */     {
/* 286 */       this._ps.close();
/*     */     } catch (SQLException localSQLException) {
/*     */     }
/* 289 */     this._conn = null;
/* 290 */     this._ps = null;
/*     */   }
/*     */ 
/*     */   public String getQueryForAllDates()
/*     */   {
/* 295 */     StringBuffer query = new StringBuffer("");
/* 296 */     query.append("select reportID, fileName, desc, checkTime, ignoreFlag from ( ");
/* 297 */     query.append("select r.reportID, r.fileName, rf.desc, r.checkTime, r.ignoreFlag from tblVariableReport r, tblReportFrequency rf ");
/* 298 */     query.append("where r.frequencyID = rf.frequencyID ");
/* 299 */     query.append("and r.instanceID = ? ");
/* 300 */     query.append("union all select r2.reportID, r2.fileName, cal.month || '/' || cal.dayOfMonth || '/' || cal.year as desc, r2.checkTime, r2.ignoreFlag ");
/* 301 */     query.append("from tblVariableReport r2, tblCalendar cal ");
/* 302 */     query.append("where r2.reportID = cal.reportID ");
/* 303 */     query.append("and r2.instanceID = ?) order by fileName, desc, checkTime ");
/* 304 */     return query.toString();
/*     */   }
/*     */ 
/*     */   public String getAllFor(String state)
/*     */   {
/* 311 */     String instanceID = (String)this._states.get(state.toUpperCase());
/* 312 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 314 */     if (instanceID == null)
/* 315 */       return null;
/*     */     try
/*     */     {
/* 318 */       PreparedStatement ps = this._conn.prepareStatement(getQueryForAllDates());
/* 319 */       ps.setString(1, instanceID);
/* 320 */       ps.setString(2, instanceID);
/* 321 */       for (ResultSet rs = ps.executeQuery(); rs.next(); )
/*     */       {
/* 323 */         String fileName = rs.getString("fileName");
/* 324 */         String reportID = rs.getString("reportID");
/* 325 */         String desc = rs.getString("desc");
/* 326 */         String checkTime = rs.getString("checkTime");
/* 327 */         String ignoreFlag = rs.getString("ignoreFlag");
/*     */         try
/*     */         {
/* 330 */           sb.append(String.format("%s,%s,%s,%s,%s\r\n", new Object[] { 
/* 331 */             reportID, fileName, desc, checkTime, ignoreFlag }));
/*     */         }
/*     */         catch (Exception localException) {
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (Exception localException1) {
/*     */     }
/* 339 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public String checkFilesLocal(ReportList reports, boolean errOnly, boolean showExpected)
/*     */   {
/* 344 */     StringBuffer output = new StringBuffer();
/* 345 */     FileCheckerMain3 fcm = new FileCheckerMain3(false);
/* 346 */     if (reports == null)
/* 347 */       return null;
/* 348 */     Collection coll = reports.getAll().values();
/* 349 */     for (Iterator iterator = reports.getAll().values().iterator(); iterator.hasNext(); )
/*     */     {
/* 351 */       Report r = (Report)iterator.next();
/* 352 */       String line = r.toString();
/* 353 */       String base = fcm.baseName(line);
/* 354 */       String name = fcm.fileName(line);
/* 355 */       int expectedCount = r.getExpectedCount();
/*     */ 
/* 357 */       String startCheck = r.getReadableStartCheck();
/*     */ 
/* 359 */       if ((!r.shouldBeChecked()) && (!showExpected))
/*     */         continue;
/*     */       String[] test;
/*     */       String[] test;
/* 367 */       if (new File(line).exists())
/* 368 */         test = new String[] { name };
/*     */       else {
/* 370 */         test = fcm.getFilesRegExp(new File(base), name);
/*     */       }
/* 372 */       boolean missing = test == null;
/*     */ 
/* 375 */       if ((test != null) && (test.length != 0))
/*     */       {
/* 377 */         for (int j = 0; j < test.length; j++)
/*     */         {
/* 379 */           String ch = fcm.check(base + test[j]);
/* 380 */           if ((!errOnly) || ((errOnly) && (ch.contains("Error")))) {
/* 381 */             output.append(base + test[j] + "\t" + startCheck + "\t" + ch + "\n");
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/* 386 */       else if ((!r.shouldBeChecked()) && (showExpected))
/*     */       {
/* 388 */         output.append(base + name + "\t" + startCheck + "\t\t\t\n");
/* 389 */         continue;
/*     */       }
/*     */ 
/* 393 */       if (((missing) || (expectedCount > test.length)) && (r.canIgnoreMissing()))
/*     */       {
/* 395 */         if (!errOnly)
/* 396 */           output.append(r + "\tN/A\tN/A\t\n");
/*     */       }
/*     */       else {
/* 399 */         if ((!missing) && (expectedCount <= test.length))
/*     */           continue;
/* 401 */         int count = test != null ? expectedCount - test.length : expectedCount;
/* 402 */         output.append(base + name + "\t" + startCheck + String.format("\t\t\tError missing %1$s of %2$s file%3$s expected by %4$tH:%4$tM\n", new Object[] { 
/* 403 */           Integer.valueOf(count), Integer.valueOf(expectedCount), expectedCount != 1 ? "s" : "", r.getStartCheck() })
/* 404 */           .toString());
/*     */       }
/*     */     }
/* 407 */     return output.toString();
/*     */   }
/*     */ 
/*     */   public int getMonth()
/*     */   {
/* 412 */     return this._cal.get(2) + 1;
/*     */   }
/*     */ 
/*     */   public int getDay()
/*     */   {
/* 417 */     return this._cal.get(5);
/*     */   }
/*     */ 
/*     */   public int getDayOfWeek()
/*     */   {
/* 422 */     return this._cal.get(7);
/*     */   }
/*     */ 
/*     */   public int getYear()
/*     */   {
/* 427 */     return this._cal.get(1);
/*     */   }
/*     */ 
/*     */   public String getFilesForInstanceTest(String state, boolean errOnly)
/*     */   {
/* 432 */     String output = null;
/* 433 */     ReportList replist = new ReportList();
/* 434 */     replist.add(new Report(0, "YourFace"));
/*     */     try
/*     */     {
/* 437 */       output = checkFilesLocal(replist, errOnly, false);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 441 */       e.printStackTrace();
/*     */     }
/* 443 */     return output;
/*     */   }
/*     */ 
/*     */   public String getQuery(String date)
/*     */   {
/* 464 */     StringBuffer query = new StringBuffer("");
/* 465 */     query.append("select reportID, fileName, checkTime, checkStop, ignoreMissing from (");
/* 466 */     query.append("select r.reportID, r.fileName, r.checkTime, r.checkStop, r.ignoreMissing from tblVariableReport r, tblReportFrequency rf ");
/* 467 */     query.append("where ( rf.month = 0 or rf.month = ? ) and ( rf.dayOfMonth = 0 or rf.dayOfMonth = ? ) ");
/* 468 */     query.append("and ( rf.dayOfWeek = 0 or rf.dayOfWeek = ? ) and r.instanceID = ? ");
/* 469 */     query.append("and r.frequencyID = rf.frequencyID and r.ignoreFlag = 0 and r.disabled = 0 ");
/* 470 */     query.append("union all select r2.reportID, r2.fileName, r2.checkTime, r2.checkStop, r2.ignoreMissing ");
/* 471 */     query.append("from tblVariableReport r2, tblCalendar cal ");
/* 472 */     query.append("where cal.year = ? and cal.month = ? ");
/* 473 */     query.append("and cal.dayOfMonth = ? and r2.reportID = cal.reportID ");
/* 474 */     query.append("and r2.instanceID = ? and r2.ignoreFlag = 0 and r2.disabled = 0) order by fileName, checkTime, checkStop ");
/* 475 */     return query.toString();
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepare(String date)
/*     */   {
/* 480 */     PreparedStatement pps = null;
/*     */     try
/*     */     {
/* 483 */       pps = this._conn.prepareStatement(getQuery(date));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 487 */       e.printStackTrace();
/*     */     }
/* 489 */     return pps;
/*     */   }
/*     */ 
/*     */   public void setValues(PreparedStatement ps, int year, int month, int day, int dow, String instanceID)
/*     */     throws SQLException
/*     */   {
/* 495 */     ps.setInt(1, month);
/* 496 */     ps.setInt(2, day);
/* 497 */     ps.setInt(3, dow);
/* 498 */     ps.setInt(4, Integer.parseInt(instanceID));
/* 499 */     ps.setInt(5, year);
/* 500 */     ps.setInt(6, month);
/* 501 */     ps.setInt(7, day);
/* 502 */     ps.setInt(8, Integer.parseInt(instanceID));
/*     */   }
/*     */ 
/*     */   public ReportList getFilesForInstanceLocal(String state, boolean errOnly)
/*     */   {
/* 507 */     String output = null;
/* 508 */     ReportList replist = new ReportList();
/* 509 */     String instanceID = (String)this._states.get(state.toUpperCase());
/* 510 */     if (instanceID == null)
/* 511 */       return null;
/* 512 */     Properties runtimeEnv = new Properties();
/* 513 */     runtimeEnv.put("DATEFOR", this._cal);
/*     */     try
/*     */     {
/* 516 */       setValues(this._ps, getYear(), getMonth(), getDay(), getDayOfWeek(), instanceID);
/* 517 */       for (ResultSet rs = this._ps.executeQuery(); rs.next(); ) {
/*     */         try
/*     */         {
/*     */           String s;
/*     */           Calendar start;
/*     */           Calendar end;
/*     */           int reportID;
/*     */           int ignoreMissing;
/* 525 */           for (Iterator iterator = VarCache.resolve(rs.getString("fileName"), runtimeEnv).iterator(); iterator.hasNext(); replist.add(new Report(reportID, s, start, end, ignoreMissing == 1)))
/*     */           {
/* 527 */             s = (String)iterator.next();
/* 528 */             start = setCalDate(this._cal, rs.getString("checkTime"));
/* 529 */             end = setCalDate(this._cal, rs.getString("checkStop"));
/* 530 */             reportID = rs.getInt("reportID");
/* 531 */             ignoreMissing = rs.getInt("ignoreMissing");
/*     */           }
/*     */ 
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 537 */           e.printStackTrace();
/*     */         }
/*     */       }
/* 540 */       System.err.println();
/*     */     }
/*     */     catch (SQLException sqle)
/*     */     {
/* 544 */       sqle.printStackTrace();
/*     */     }
/* 546 */     return replist;
/*     */   }
/*     */ 
/*     */   public void ignoreAFile(String state)
/*     */   {
/* 551 */     String instanceID = (String)this._states.get(state.toUpperCase());
/* 552 */     ReportList replist = new ReportList();
/*     */     try
/*     */     {
/* 555 */       setValues(this._ps, getYear(), getMonth(), getDay(), getDayOfWeek(), instanceID);
/*     */       Calendar start;
/*     */       Calendar end;
/*     */       int reportID;
/* 559 */       for (ResultSet rs = this._ps.executeQuery(); rs.next(); replist.add(new Report(reportID, rs.getString("fileName"), start, end, false)))
/*     */       {
/* 561 */         start = setCalDate(this._cal, rs.getString("checkTime"));
/* 562 */         end = setCalDate(this._cal, rs.getString("checkStop"));
/* 563 */         reportID = rs.getInt("reportID");
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 569 */       e.printStackTrace();
/*     */     }
/* 571 */     BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));
/* 572 */     ReportList ignores = new ReportList();
/* 573 */     boolean ignoreAll = false;
/*     */     try
/*     */     {
/* 576 */       int numgrps = replist.getAll().size();
/* 577 */       System.out.println("Ignore all " + numgrps + " filetypes for this instance? [y|n]:");
/* 578 */       String ans = scan.readLine();
/* 579 */       if (ans.matches("[yY](es)?"))
/* 580 */         ignoreAll = true;
/* 581 */       for (Iterator iterator = replist.getAll().values().iterator(); iterator.hasNext(); )
/*     */       {
/* 583 */         Report r = (Report)iterator.next();
/* 584 */         if (ignoreAll)
/*     */         {
/* 586 */           ignores.add(r);
/*     */         }
/*     */         else {
/* 589 */           System.out.println(r.getFileName());
/* 590 */           System.out.print("Ignore this filetype? [y|n]:");
/* 591 */           ans = scan.readLine();
/* 592 */           if (!ans.matches("[yY](es)?"))
/*     */             continue;
/* 594 */           ignores.add(r);
/* 595 */           System.out.println("OK!");
/*     */         }
/*     */       }
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/*     */     }
/* 602 */     System.out.println("Return " + executeIgnores(ignores));
/*     */   }
/*     */ 
/*     */   private int unignoreAll()
/*     */   {
/* 607 */     Statement st = null;
/*     */     try
/*     */     {
/* 611 */       st = this._conn.createStatement();
/* 612 */       int i = st.executeUpdate("update tblVariableReport set ignoreFlag = 0 where ignoreFlag = 1");
/* 613 */       return i;
/*     */     } catch (SQLException localSQLException) {
/*     */     }
/* 616 */     return -1;
/*     */   }
/*     */ 
/*     */   private int executeIgnores(ReportList ignores)
/*     */   {
/* 623 */     Statement st = null;
/* 624 */     String sql = String.format("update tblVariableReport set ignoreFlag = 1 where reportID in (%s)", new Object[] { 
/* 625 */       ignores });
/*     */ 
/* 627 */     System.out.println(sql);
/*     */     try
/*     */     {
/* 631 */       st = this._conn.createStatement();
/* 632 */       int i = st.executeUpdate(sql);
/* 633 */       return i;
/*     */     } catch (SQLException localSQLException) {
/*     */     }
/* 636 */     return -1;
/*     */   }
/*     */ 
/*     */   private Calendar setCalDate(Calendar cal, String d)
/*     */   {
/* 641 */     Calendar dateCal = (Calendar)cal.clone();
/* 642 */     Calendar timeCal = (Calendar)dateCal.clone();
/* 643 */     DateFormat df = new SimpleDateFormat("HH:mm:ss");
/*     */     try
/*     */     {
/* 646 */       Date date = df.parse(d);
/* 647 */       timeCal.setTimeInMillis(date.getTime());
/*     */     } catch (ParseException localParseException) {
/*     */     }
/* 650 */     dateCal.set(11, timeCal.get(11));
/* 651 */     dateCal.set(12, timeCal.get(12));
/* 652 */     dateCal.set(13, timeCal.get(13));
/* 653 */     return dateCal;
/*     */   }
/*     */ 
/*     */   public Calendar strToCal(String d)
/*     */   {
/* 658 */     Calendar c = Calendar.getInstance();
/* 659 */     int yr = 0;
/* 660 */     int mo = 0;
/* 661 */     int dt = 0;
/* 662 */     if (validDate(d))
/*     */     {
/* 664 */       mo = Integer.parseInt(d.substring(0, 2));
/* 665 */       dt = Integer.parseInt(d.substring(3, 5));
/* 666 */       yr = Integer.parseInt(d.substring(6, 10));
/* 667 */       c.set(yr, mo - 1, dt);
/* 668 */       return c;
/*     */     }
/*     */ 
/* 671 */     return null;
/*     */   }
/*     */ 
/*     */   public boolean validDate(String date)
/*     */   {
/* 677 */     return (date.equals("Never Checked")) || (Pattern.matches("[0-9]+/[0-9]+/2[0-9]+", date));
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.FileChecker
 * JD-Core Version:    0.6.0
 */