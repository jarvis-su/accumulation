/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ class OperationNotSupportedException extends SQLException
/*    */ {
/*    */   OperationNotSupportedException()
/*    */   {
/* 13 */     super(Messages.getString("RowDataDynamic.10"), "S1009");
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.OperationNotSupportedException
 * JD-Core Version:    0.6.0
 */