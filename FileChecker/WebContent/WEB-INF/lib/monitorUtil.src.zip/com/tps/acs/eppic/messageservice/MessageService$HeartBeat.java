/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.HeartbeatData;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.RegistrationData;
/*     */ import java.util.Date;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ class MessageService$HeartBeat
/*     */   implements Runnable
/*     */ {
/*     */   private int internalInterval;
/*     */   private Message message;
/*     */   private Date timestamp;
/*     */   private HeartbeatData hbData;
/*     */ 
/*     */   MessageService$HeartBeat(MessageService paramMessageService, int interval)
/*     */   {
/* 624 */     this.internalInterval = interval;
/* 625 */     this.message = new Message(paramMessageService.getSystemId(), "HEARTBEAT", 3, paramMessageService.getSystemPort());
/* 626 */     this.hbData = new HeartbeatData(getInterval());
/* 627 */     this.message.setM_MessageData(this.hbData);
/*     */   }
/*     */ 
/*     */   public void setInterval(int interval) {
/* 631 */     this.internalInterval = interval;
/*     */   }
/*     */ 
/*     */   public int getInterval()
/*     */   {
/* 641 */     int interval = this.internalInterval;
/* 642 */     if (!this.this$0.isConnected()) {
/* 643 */       interval = this.this$0.getRegistration_timeout();
/*     */     }
/* 645 */     return interval;
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/* 653 */     while (this.this$0.isServiceEnabled()) {
/* 654 */       if (this.this$0.isConnected()) {
/* 655 */         MessageService.logger.debug("HeartBeat.run(): Sending HeartBeat.");
/* 656 */         this.timestamp = new Date();
/* 657 */         this.message.setTimestamp(this.timestamp);
/* 658 */         this.hbData.setInterval(getInterval());
/* 659 */         this.this$0.enqueue(this.message);
/*     */       } else {
/* 661 */         MessageService.logger.info("HeartBeat.run(): Not Connected. Waiting for " + this.this$0.getRegistration_timeout() + " before attempting a reconnect of System:" + this.this$0.getSystemId());
/*     */ 
/* 663 */         Message m = new Message(this.this$0.getSystemId(), "HEARTBEAT", 5, this.this$0.getSystemPort());
/* 664 */         m.setM_MessageData(new RegistrationData(this.this$0.getRegistration_timeout()));
/* 665 */         this.this$0.enqueue(m);
/*     */       }
/*     */       try {
/* 668 */         Thread.sleep(getInterval() * 1000);
/*     */       }
/*     */       catch (InterruptedException localInterruptedException)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService.HeartBeat
 * JD-Core Version:    0.6.0
 */