/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ public class AssertionFailedException extends RuntimeException
/*    */ {
/*    */   public static void shouldNotHappen(Exception ex)
/*    */     throws AssertionFailedException
/*    */   {
/* 49 */     throw new AssertionFailedException(ex);
/*    */   }
/*    */ 
/*    */   public AssertionFailedException(Exception ex)
/*    */   {
/* 63 */     super(Messages.getString("AssertionFailedException.0") + ex.toString() + Messages.getString("AssertionFailedException.1"));
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.AssertionFailedException
 * JD-Core Version:    0.6.0
 */