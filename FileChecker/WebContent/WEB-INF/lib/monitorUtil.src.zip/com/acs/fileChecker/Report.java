/*     */ package com.acs.fileChecker;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ 
/*     */ public class Report
/*     */   implements Comparable
/*     */ {
/*     */   private String _fileName;
/*     */   private int _reportID;
/*     */   private int _expectedCount;
/*     */   private Calendar _startCheck;
/*     */   private Calendar _endCheck;
/*     */   private boolean _ignoreMissing;
/*     */ 
/*     */   public Report(int reportID, String file, Calendar start, Calendar end, boolean ignoreMissing)
/*     */   {
/*  12 */     this._startCheck = Calendar.getInstance();
/*  13 */     this._endCheck = Calendar.getInstance();
/*  14 */     this._reportID = reportID;
/*  15 */     if (start != null)
/*     */     {
/*  17 */       this._startCheck = start;
/*     */     }
/*     */     else {
/*  20 */       this._startCheck.set(11, 0);
/*  21 */       this._startCheck.set(12, 0);
/*  22 */       this._startCheck.set(13, 0);
/*     */     }
/*  24 */     if (end != null)
/*     */     {
/*  26 */       this._endCheck = end;
/*     */     }
/*     */     else {
/*  29 */       this._endCheck.set(11, 23);
/*  30 */       this._endCheck.set(12, 59);
/*  31 */       this._endCheck.set(13, 59);
/*     */     }
/*  33 */     this._fileName = file;
/*  34 */     this._expectedCount = 1;
/*  35 */     this._ignoreMissing = ignoreMissing;
/*     */   }
/*     */ 
/*     */   public boolean canIgnoreMissing() {
/*  39 */     return this._ignoreMissing;
/*     */   }
/*     */ 
/*     */   public int compareTo(Object o1)
/*     */   {
/*  44 */     return this._fileName.compareTo(((Report)o1).getFileName());
/*     */   }
/*     */ 
/*     */   public Calendar getStartCheck()
/*     */   {
/*  49 */     return this._startCheck;
/*     */   }
/*     */ 
/*     */   public String getReadableStartCheck()
/*     */   {
/*  54 */     SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
/*  55 */     return sdf.format(this._startCheck.getTime());
/*     */   }
/*     */ 
/*     */   public Calendar getEndCheck()
/*     */   {
/*  60 */     return this._endCheck;
/*     */   }
/*     */ 
/*     */   public void setStartCheck(Calendar c)
/*     */   {
/*  65 */     this._startCheck = ((Calendar)c.clone());
/*     */   }
/*     */ 
/*     */   public void setEndCheck(Calendar c)
/*     */   {
/*  70 */     this._endCheck = ((Calendar)c.clone());
/*     */   }
/*     */ 
/*     */   public Report(int reportID, String file)
/*     */   {
/*  75 */     this(reportID, file, null, null, false);
/*     */   }
/*     */ 
/*     */   public String getFileName()
/*     */   {
/*  80 */     return this._fileName;
/*     */   }
/*     */ 
/*     */   public void setFileName(String name)
/*     */   {
/*  85 */     this._fileName = name;
/*     */   }
/*     */ 
/*     */   public int getExpectedCount()
/*     */   {
/*  90 */     return this._expectedCount;
/*     */   }
/*     */ 
/*     */   public void incExpectedCount()
/*     */   {
/*  95 */     this._expectedCount += 1;
/*     */   }
/*     */ 
/*     */   public int getID()
/*     */   {
/* 100 */     return this._reportID;
/*     */   }
/*     */ 
/*     */   public static Calendar normalizeDate(Calendar c)
/*     */   {
/* 105 */     c.set(0, 0, 1);
/* 106 */     return c;
/*     */   }
/*     */ 
/*     */   public boolean shouldBeChecked()
/*     */   {
/* 111 */     Calendar now = Calendar.getInstance();
/* 112 */     Calendar start = this._startCheck;
/* 113 */     Calendar end = this._endCheck;
/* 114 */     if ((now.before(this._startCheck)) && (this._endCheck.before(this._startCheck)) && (now.before(this._endCheck)))
/* 115 */       return true;
/* 116 */     return now.after(this._startCheck);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 121 */     return this._fileName;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/* 126 */     Calendar start = Calendar.getInstance();
/* 127 */     Calendar end = (Calendar)start.clone();
/* 128 */     start.set(11, 11);
/* 129 */     end.set(11, 3);
/* 130 */     Report r = new Report(0, "blah", start, end, false);
/* 131 */     r.shouldBeChecked();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.Report
 * JD-Core Version:    0.6.0
 */