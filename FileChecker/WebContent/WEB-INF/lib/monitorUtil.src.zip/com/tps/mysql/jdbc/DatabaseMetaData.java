/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ public class DatabaseMetaData
/*      */   implements java.sql.DatabaseMetaData
/*      */ {
/*      */   private static final int DEFERRABILITY = 13;
/*      */   private static final int DELETE_RULE = 10;
/*      */   private static final int FK_NAME = 11;
/*      */   private static final int FKCOLUMN_NAME = 7;
/*      */   private static final int FKTABLE_CAT = 4;
/*      */   private static final int FKTABLE_NAME = 6;
/*      */   private static final int FKTABLE_SCHEM = 5;
/*      */   private static final int KEY_SEQ = 8;
/*      */   private static final int PK_NAME = 12;
/*      */   private static final int PKCOLUMN_NAME = 3;
/*      */   private static final int PKTABLE_CAT = 0;
/*      */   private static final int PKTABLE_NAME = 2;
/*      */   private static final int PKTABLE_SCHEM = 1;
/*      */   private static final String SUPPORTS_FK = "SUPPORTS_FK";
/*  413 */   private static final byte[] TABLE_AS_BYTES = "TABLE".getBytes();
/*      */   private static final int UPDATE_RULE = 9;
/*  417 */   private static final byte[] VIEW_AS_BYTES = "VIEW".getBytes();
/*      */   protected Connection conn;
/*  423 */   protected String database = null;
/*      */ 
/*  426 */   protected String quotedId = null;
/*      */ 
/*      */   public DatabaseMetaData(Connection connToSet, String databaseToSet)
/*      */   {
/*  437 */     this.conn = connToSet;
/*  438 */     this.database = databaseToSet;
/*      */     try
/*      */     {
/*  441 */       this.quotedId = (this.conn.supportsQuotedIdentifiers() ? getIdentifierQuoteString() : "");
/*      */     }
/*      */     catch (SQLException sqlEx)
/*      */     {
/*  447 */       AssertionFailedException.shouldNotHappen(sqlEx);
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean allProceduresAreCallable()
/*      */     throws SQLException
/*      */   {
/*  460 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean allTablesAreSelectable()
/*      */     throws SQLException
/*      */   {
/*  471 */     return false;
/*      */   }
/*      */ 
/*      */   private java.sql.ResultSet buildResultSet(Field[] fields, ArrayList rows) throws SQLException
/*      */   {
/*  476 */     return buildResultSet(fields, rows, this.conn);
/*      */   }
/*      */ 
/*      */   static java.sql.ResultSet buildResultSet(Field[] fields, ArrayList rows, Connection c) throws SQLException
/*      */   {
/*  481 */     int fieldsLength = fields.length;
/*      */ 
/*  483 */     for (int i = 0; i < fieldsLength; i++) {
/*  484 */       fields[i].setConnection(c);
/*  485 */       fields[i].setUseOldNameMetadata(true);
/*      */     }
/*      */ 
/*  488 */     return new ResultSet(c.getCatalog(), fields, new RowDataStatic(rows), c, null);
/*      */   }
/*      */ 
/*      */   private void convertToJdbcFunctionList(String catalog, java.sql.ResultSet proceduresRs, boolean needsClientFiltering, String db, Map procedureRowsOrderedByName, int nameIndex)
/*      */     throws SQLException
/*      */   {
/*  495 */     while (proceduresRs.next()) {
/*  496 */       boolean shouldAdd = true;
/*      */ 
/*  498 */       if (needsClientFiltering) {
/*  499 */         shouldAdd = false;
/*      */ 
/*  501 */         String procDb = proceduresRs.getString(1);
/*      */ 
/*  503 */         if ((db == null) && (procDb == null))
/*  504 */           shouldAdd = true;
/*  505 */         else if ((db != null & db.equals(procDb))) {
/*  506 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */ 
/*  510 */       if (shouldAdd) {
/*  511 */         String functionName = proceduresRs.getString(nameIndex);
/*  512 */         byte[][] rowData = new byte[8][];
/*  513 */         rowData[0] = (catalog == null ? null : s2b(catalog));
/*  514 */         rowData[1] = null;
/*  515 */         rowData[2] = s2b(functionName);
/*  516 */         rowData[3] = null;
/*  517 */         rowData[4] = null;
/*  518 */         rowData[5] = null;
/*  519 */         rowData[6] = null;
/*  520 */         rowData[7] = s2b(Integer.toString(2));
/*      */ 
/*  522 */         procedureRowsOrderedByName.put(functionName, rowData);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void convertToJdbcProcedureList(boolean fromSelect, String catalog, java.sql.ResultSet proceduresRs, boolean needsClientFiltering, String db, Map procedureRowsOrderedByName, int nameIndex)
/*      */     throws SQLException
/*      */   {
/*  530 */     while (proceduresRs.next()) {
/*  531 */       boolean shouldAdd = true;
/*      */ 
/*  533 */       if (needsClientFiltering) {
/*  534 */         shouldAdd = false;
/*      */ 
/*  536 */         String procDb = proceduresRs.getString(1);
/*      */ 
/*  538 */         if ((db == null) && (procDb == null))
/*  539 */           shouldAdd = true;
/*  540 */         else if ((db != null & db.equals(procDb))) {
/*  541 */           shouldAdd = true;
/*      */         }
/*      */       }
/*      */ 
/*  545 */       if (shouldAdd) {
/*  546 */         String procedureName = proceduresRs.getString(nameIndex);
/*  547 */         byte[][] rowData = new byte[8][];
/*  548 */         rowData[0] = (catalog == null ? null : s2b(catalog));
/*  549 */         rowData[1] = null;
/*  550 */         rowData[2] = s2b(procedureName);
/*  551 */         rowData[3] = null;
/*  552 */         rowData[4] = null;
/*  553 */         rowData[5] = null;
/*  554 */         rowData[6] = null;
/*      */ 
/*  556 */         boolean isFunction = fromSelect ? "FUNCTION".equalsIgnoreCase(proceduresRs.getString("type")) : false;
/*      */ 
/*  559 */         rowData[7] = s2b(isFunction ? Integer.toString(2) : Integer.toString(0));
/*      */ 
/*  563 */         procedureRowsOrderedByName.put(procedureName, rowData);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private byte[][] convertTypeDescriptorToProcedureRow(byte[] procNameAsBytes, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, DatabaseMetaData.TypeDescriptor typeDesc)
/*      */     throws SQLException
/*      */   {
/*  572 */     byte[][] row = new byte[14][];
/*  573 */     row[0] = null;
/*  574 */     row[1] = null;
/*  575 */     row[2] = procNameAsBytes;
/*  576 */     row[3] = s2b(paramName);
/*      */ 
/*  578 */     if ((isInParam) && (isOutParam))
/*  579 */       row[4] = s2b(String.valueOf(2));
/*  580 */     else if (isInParam)
/*  581 */       row[4] = s2b(String.valueOf(1));
/*  582 */     else if (isOutParam)
/*  583 */       row[4] = s2b(String.valueOf(4));
/*  584 */     else if (isReturnParam)
/*  585 */       row[4] = s2b(String.valueOf(5));
/*      */     else {
/*  587 */       row[4] = s2b(String.valueOf(0));
/*      */     }
/*  589 */     row[5] = s2b(Short.toString(typeDesc.dataType));
/*  590 */     row[6] = s2b(typeDesc.typeName);
/*  591 */     row[7] = s2b(Integer.toString(typeDesc.columnSize));
/*  592 */     row[8] = s2b(Integer.toString(typeDesc.bufferLength));
/*  593 */     row[9] = s2b(Integer.toString(typeDesc.decimalDigits));
/*  594 */     row[10] = s2b(Integer.toString(typeDesc.numPrecRadix));
/*      */ 
/*  596 */     switch (typeDesc.nullability) {
/*      */     case 0:
/*  598 */       row[11] = s2b(Integer.toString(0));
/*      */ 
/*  600 */       break;
/*      */     case 1:
/*  603 */       row[11] = s2b(Integer.toString(1));
/*      */ 
/*  605 */       break;
/*      */     case 2:
/*  608 */       row[11] = s2b(Integer.toString(2));
/*      */ 
/*  610 */       break;
/*      */     default:
/*  613 */       throw SQLError.createSQLException("Internal error while parsing callable statement metadata (unknown nullability value fount)", "S1000");
/*      */     }
/*      */ 
/*  617 */     row[12] = null;
/*  618 */     return row;
/*      */   }
/*      */ 
/*      */   public boolean dataDefinitionCausesTransactionCommit()
/*      */     throws SQLException
/*      */   {
/*  630 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean dataDefinitionIgnoredInTransactions()
/*      */     throws SQLException
/*      */   {
/*  641 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean deletesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/*  656 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean doesMaxRowSizeIncludeBlobs()
/*      */     throws SQLException
/*      */   {
/*  669 */     return true;
/*      */   }
/*      */ 
/*      */   public List extractForeignKeyForTable(ArrayList rows, java.sql.ResultSet rs, String catalog)
/*      */     throws SQLException
/*      */   {
/*  687 */     byte[][] row = new byte[3][];
/*  688 */     row[0] = rs.getBytes(1);
/*  689 */     row[1] = s2b("SUPPORTS_FK");
/*      */ 
/*  691 */     String createTableString = rs.getString(2);
/*  692 */     StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
/*      */ 
/*  694 */     StringBuffer commentBuf = new StringBuffer("comment; ");
/*  695 */     boolean firstTime = true;
/*      */ 
/*  697 */     String quoteChar = getIdentifierQuoteString();
/*      */ 
/*  699 */     if (quoteChar == null) {
/*  700 */       quoteChar = "`";
/*      */     }
/*      */ 
/*  703 */     while (lineTokenizer.hasMoreTokens()) {
/*  704 */       String line = lineTokenizer.nextToken().trim();
/*      */ 
/*  706 */       String constraintName = null;
/*      */ 
/*  708 */       if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT")) {
/*  709 */         boolean usingBackTicks = true;
/*  710 */         int beginPos = line.indexOf(quoteChar);
/*      */ 
/*  712 */         if (beginPos == -1) {
/*  713 */           beginPos = line.indexOf("\"");
/*  714 */           usingBackTicks = false;
/*      */         }
/*      */ 
/*  717 */         if (beginPos != -1) {
/*  718 */           int endPos = -1;
/*      */ 
/*  720 */           if (usingBackTicks)
/*  721 */             endPos = line.indexOf(quoteChar, beginPos + 1);
/*      */           else {
/*  723 */             endPos = line.indexOf("\"", beginPos + 1);
/*      */           }
/*      */ 
/*  726 */           if (endPos != -1) {
/*  727 */             constraintName = line.substring(beginPos + 1, endPos);
/*  728 */             line = line.substring(endPos + 1, line.length()).trim();
/*      */           }
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  734 */       if (line.startsWith("FOREIGN KEY")) {
/*  735 */         if (line.endsWith(",")) {
/*  736 */           line = line.substring(0, line.length() - 1);
/*      */         }
/*      */ 
/*  739 */         char quote = this.quotedId.charAt(0);
/*      */ 
/*  741 */         int indexOfFK = line.indexOf("FOREIGN KEY");
/*      */ 
/*  743 */         String localColumnName = null;
/*  744 */         String referencedCatalogName = this.quotedId + catalog + this.quotedId;
/*  745 */         String referencedTableName = null;
/*  746 */         String referencedColumnName = null;
/*      */ 
/*  749 */         if (indexOfFK != -1) {
/*  750 */           int afterFk = indexOfFK + "FOREIGN KEY".length();
/*      */ 
/*  752 */           int indexOfRef = StringUtils.indexOfIgnoreCaseRespectQuotes(afterFk, line, "REFERENCES", quote, true);
/*      */ 
/*  754 */           if (indexOfRef != -1)
/*      */           {
/*  756 */             int indexOfParenOpen = line.indexOf('(', afterFk);
/*  757 */             int indexOfParenClose = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfParenOpen, line, ")", quote, true);
/*      */ 
/*  759 */             if ((indexOfParenOpen != -1) && (indexOfParenClose == -1));
/*  763 */             localColumnName = line.substring(indexOfParenOpen + 1, indexOfParenClose);
/*      */ 
/*  765 */             int afterRef = indexOfRef + "REFERENCES".length();
/*      */ 
/*  767 */             int referencedColumnBegin = StringUtils.indexOfIgnoreCaseRespectQuotes(afterRef, line, "(", quote, true);
/*      */ 
/*  769 */             if (referencedColumnBegin != -1) {
/*  770 */               referencedTableName = line.substring(afterRef, referencedColumnBegin);
/*      */ 
/*  772 */               int referencedColumnEnd = StringUtils.indexOfIgnoreCaseRespectQuotes(referencedColumnBegin + 1, line, ")", quote, true);
/*      */ 
/*  774 */               if (referencedColumnEnd != -1) {
/*  775 */                 referencedColumnName = line.substring(referencedColumnBegin + 1, referencedColumnEnd);
/*      */               }
/*      */ 
/*  778 */               int indexOfCatalogSep = StringUtils.indexOfIgnoreCaseRespectQuotes(0, referencedTableName, ".", quote, true);
/*      */ 
/*  780 */               if (indexOfCatalogSep != -1) {
/*  781 */                 referencedCatalogName = referencedTableName.substring(0, indexOfCatalogSep);
/*  782 */                 referencedTableName = referencedTableName.substring(indexOfCatalogSep + 1);
/*      */               }
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  789 */         if (!firstTime)
/*  790 */           commentBuf.append("; ");
/*      */         else {
/*  792 */           firstTime = false;
/*      */         }
/*      */ 
/*  795 */         if (constraintName != null)
/*  796 */           commentBuf.append(constraintName);
/*      */         else {
/*  798 */           commentBuf.append("not_available");
/*      */         }
/*      */ 
/*  801 */         commentBuf.append("(");
/*  802 */         commentBuf.append(localColumnName);
/*  803 */         commentBuf.append(") REFER ");
/*  804 */         commentBuf.append(referencedCatalogName);
/*  805 */         commentBuf.append("/");
/*  806 */         commentBuf.append(referencedTableName);
/*  807 */         commentBuf.append("(");
/*  808 */         commentBuf.append(referencedColumnName);
/*  809 */         commentBuf.append(")");
/*      */ 
/*  811 */         int lastParenIndex = line.lastIndexOf(")");
/*      */ 
/*  813 */         if (lastParenIndex != line.length() - 1) {
/*  814 */           String cascadeOptions = cascadeOptions = line.substring(lastParenIndex + 1);
/*      */ 
/*  816 */           commentBuf.append(" ");
/*  817 */           commentBuf.append(cascadeOptions);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  822 */     row[2] = s2b(commentBuf.toString());
/*  823 */     rows.add(row);
/*      */ 
/*  825 */     return rows;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet extractForeignKeyFromCreateTable(String catalog, String tableName)
/*      */     throws SQLException
/*      */   {
/*  846 */     ArrayList tableList = new ArrayList();
/*  847 */     java.sql.ResultSet rs = null;
/*  848 */     Statement stmt = null;
/*      */ 
/*  850 */     if (tableName != null)
/*  851 */       tableList.add(tableName);
/*      */     else {
/*      */       try {
/*  854 */         rs = getTables(catalog, "", "%", new String[] { "TABLE" });
/*      */ 
/*  856 */         while (rs.next())
/*  857 */           tableList.add(rs.getString("TABLE_NAME"));
/*      */       }
/*      */       finally {
/*  860 */         if (rs != null) {
/*  861 */           rs.close();
/*      */         }
/*      */ 
/*  864 */         rs = null;
/*      */       }
/*      */     }
/*      */ 
/*  868 */     ArrayList rows = new ArrayList();
/*  869 */     Field[] fields = new Field[3];
/*  870 */     fields[0] = new Field("", "Name", 1, 2147483647);
/*  871 */     fields[1] = new Field("", "Type", 1, 255);
/*  872 */     fields[2] = new Field("", "Comment", 1, 2147483647);
/*      */ 
/*  874 */     int numTables = tableList.size();
/*  875 */     stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/*  877 */     String quoteChar = getIdentifierQuoteString();
/*      */ 
/*  879 */     if (quoteChar == null) {
/*  880 */       quoteChar = "`";
/*      */     }
/*      */     try
/*      */     {
/*  884 */       for (int i = 0; i < numTables; i++) {
/*  885 */         String tableToExtract = (String)tableList.get(i);
/*      */ 
/*  887 */         String query = "SHOW CREATE TABLE " + quoteChar + catalog + quoteChar + "." + quoteChar + tableToExtract + quoteChar;
/*      */ 
/*  891 */         rs = stmt.executeQuery(query);
/*      */ 
/*  893 */         while (rs.next())
/*  894 */           extractForeignKeyForTable(rows, rs, catalog);
/*      */       }
/*      */     }
/*      */     finally {
/*  898 */       if (rs != null) {
/*  899 */         rs.close();
/*      */       }
/*      */ 
/*  902 */       rs = null;
/*      */ 
/*  904 */       if (stmt != null) {
/*  905 */         stmt.close();
/*      */       }
/*      */ 
/*  908 */       stmt = null;
/*      */     }
/*      */ 
/*  911 */     return buildResultSet(fields, rows);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3)
/*      */     throws SQLException
/*      */   {
/*  919 */     Field[] fields = new Field[21];
/*  920 */     fields[0] = new Field("", "TYPE_CAT", 1, 32);
/*  921 */     fields[1] = new Field("", "TYPE_SCHEM", 1, 32);
/*  922 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/*  923 */     fields[3] = new Field("", "ATTR_NAME", 1, 32);
/*  924 */     fields[4] = new Field("", "DATA_TYPE", 5, 32);
/*  925 */     fields[5] = new Field("", "ATTR_TYPE_NAME", 1, 32);
/*  926 */     fields[6] = new Field("", "ATTR_SIZE", 4, 32);
/*  927 */     fields[7] = new Field("", "DECIMAL_DIGITS", 4, 32);
/*  928 */     fields[8] = new Field("", "NUM_PREC_RADIX", 4, 32);
/*  929 */     fields[9] = new Field("", "NULLABLE ", 4, 32);
/*  930 */     fields[10] = new Field("", "REMARKS", 1, 32);
/*  931 */     fields[11] = new Field("", "ATTR_DEF", 1, 32);
/*  932 */     fields[12] = new Field("", "SQL_DATA_TYPE", 4, 32);
/*  933 */     fields[13] = new Field("", "SQL_DATETIME_SUB", 4, 32);
/*  934 */     fields[14] = new Field("", "CHAR_OCTET_LENGTH", 4, 32);
/*  935 */     fields[15] = new Field("", "ORDINAL_POSITION", 4, 32);
/*  936 */     fields[16] = new Field("", "IS_NULLABLE", 1, 32);
/*  937 */     fields[17] = new Field("", "SCOPE_CATALOG", 1, 32);
/*  938 */     fields[18] = new Field("", "SCOPE_SCHEMA", 1, 32);
/*  939 */     fields[19] = new Field("", "SCOPE_TABLE", 1, 32);
/*  940 */     fields[20] = new Field("", "SOURCE_DATA_TYPE", 5, 32);
/*      */ 
/*  942 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getBestRowIdentifier(String catalog, String schema, String table, int scope, boolean nullable)
/*      */     throws SQLException
/*      */   {
/*  993 */     if (table == null) {
/*  994 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/*  998 */     Field[] fields = new Field[8];
/*  999 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 1000 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 1001 */     fields[2] = new Field("", "DATA_TYPE", 5, 32);
/* 1002 */     fields[3] = new Field("", "TYPE_NAME", 1, 32);
/* 1003 */     fields[4] = new Field("", "COLUMN_SIZE", 4, 10);
/* 1004 */     fields[5] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 1005 */     fields[6] = new Field("", "DECIMAL_DIGITS", 4, 10);
/* 1006 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */ 
/* 1008 */     ArrayList rows = new ArrayList();
/* 1009 */     Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     try
/*      */     {
/* 1013 */       new DatabaseMetaData.1(this, getCatalogIterator(catalog), table, stmt, rows).doForAll();
/*      */     }
/*      */     finally
/*      */     {
/* 1121 */       if (stmt != null) {
/* 1122 */         stmt.close();
/*      */       }
/*      */     }
/*      */ 
/* 1126 */     java.sql.ResultSet results = buildResultSet(fields, rows);
/*      */ 
/* 1128 */     return results;
/*      */   }
/*      */ 
/*      */   private void getCallStmtParameterTypes(String catalog, String procName, String parameterNamePattern, List resultRows)
/*      */     throws SQLException
/*      */   {
/* 1166 */     Statement paramRetrievalStmt = null;
/* 1167 */     java.sql.ResultSet paramRetrievalRs = null;
/*      */ 
/* 1169 */     if (parameterNamePattern == null) {
/* 1170 */       if (this.conn.getNullNamePatternMatchesAll())
/* 1171 */         parameterNamePattern = "%";
/*      */       else {
/* 1173 */         throw SQLError.createSQLException("Parameter/Column name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1179 */     byte[] procNameAsBytes = null;
/*      */     try
/*      */     {
/* 1182 */       procNameAsBytes = procName.getBytes("UTF-8");
/*      */     } catch (UnsupportedEncodingException ueEx) {
/* 1184 */       procNameAsBytes = s2b(procName);
/*      */     }
/*      */ 
/* 1189 */     String quoteChar = getIdentifierQuoteString();
/*      */ 
/* 1191 */     String storageDefnDelims = "(" + quoteChar;
/* 1192 */     String storageDefnClosures = ")" + quoteChar;
/*      */ 
/* 1195 */     String parameterDef = null;
/*      */     try
/*      */     {
/* 1198 */       paramRetrievalStmt = this.conn.getMetadataSafeStatement();
/*      */ 
/* 1200 */       if ((this.conn.lowerCaseTableNames()) && (catalog != null) && (catalog.length() != 0))
/*      */       {
/* 1206 */         String oldCatalog = this.conn.getCatalog();
/* 1207 */         java.sql.ResultSet rs = null;
/*      */         try
/*      */         {
/* 1210 */           this.conn.setCatalog(catalog);
/* 1211 */           rs = paramRetrievalStmt.executeQuery("SELECT DATABASE()");
/* 1212 */           rs.next();
/*      */ 
/* 1214 */           catalog = rs.getString(1);
/*      */         }
/*      */         finally
/*      */         {
/* 1218 */           this.conn.setCatalog(oldCatalog);
/*      */ 
/* 1220 */           if (rs != null) {
/* 1221 */             rs.close();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1226 */       if (paramRetrievalStmt.getMaxRows() != 0) {
/* 1227 */         paramRetrievalStmt.setMaxRows(0);
/*      */       }
/*      */ 
/* 1230 */       int dotIndex = -1;
/*      */ 
/* 1232 */       if (!" ".equals(quoteChar)) {
/* 1233 */         dotIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procName, ".", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */       }
/*      */       else
/*      */       {
/* 1237 */         dotIndex = procName.indexOf(".");
/*      */       }
/*      */ 
/* 1240 */       String dbName = null;
/*      */ 
/* 1242 */       if ((dotIndex != -1) && (dotIndex + 1 < procName.length())) {
/* 1243 */         dbName = procName.substring(0, dotIndex);
/* 1244 */         procName = procName.substring(dotIndex + 1);
/*      */       } else {
/* 1246 */         dbName = catalog;
/*      */       }
/*      */ 
/* 1249 */       StringBuffer procNameBuf = new StringBuffer();
/*      */ 
/* 1251 */       if (dbName != null) {
/* 1252 */         if ((!" ".equals(quoteChar)) && (!dbName.startsWith(quoteChar))) {
/* 1253 */           procNameBuf.append(quoteChar);
/*      */         }
/*      */ 
/* 1256 */         procNameBuf.append(dbName);
/*      */ 
/* 1258 */         if ((!" ".equals(quoteChar)) && (!dbName.startsWith(quoteChar))) {
/* 1259 */           procNameBuf.append(quoteChar);
/*      */         }
/*      */ 
/* 1262 */         procNameBuf.append(".");
/*      */       }
/*      */ 
/* 1265 */       boolean procNameIsNotQuoted = !procName.startsWith(quoteChar);
/*      */ 
/* 1267 */       if ((!" ".equals(quoteChar)) && (procNameIsNotQuoted)) {
/* 1268 */         procNameBuf.append(quoteChar);
/*      */       }
/*      */ 
/* 1271 */       procNameBuf.append(procName);
/*      */ 
/* 1273 */       if ((!" ".equals(quoteChar)) && (procNameIsNotQuoted)) {
/* 1274 */         procNameBuf.append(quoteChar);
/*      */       }
/*      */ 
/* 1277 */       boolean parsingFunction = false;
/*      */       try
/*      */       {
/* 1280 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE PROCEDURE " + procNameBuf.toString());
/*      */ 
/* 1283 */         parsingFunction = false;
/*      */       } catch (SQLException sqlEx) {
/* 1285 */         paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE FUNCTION " + procNameBuf.toString());
/*      */ 
/* 1288 */         parsingFunction = true;
/*      */       }
/*      */ 
/* 1291 */       if (paramRetrievalRs.next()) {
/* 1292 */         String procedureDef = parsingFunction ? paramRetrievalRs.getString("Create Function") : paramRetrievalRs.getString("Create Procedure");
/*      */ 
/* 1296 */         int openParenIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, "(", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */ 
/* 1301 */         String beforeBegin = null;
/*      */ 
/* 1304 */         int beginIndex = 0;
/*      */ 
/* 1306 */         if (!parsingFunction) {
/* 1307 */           beginIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, "\nbegin", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */         }
/*      */         else
/*      */         {
/* 1313 */           int returnsIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, " RETURNS ", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */ 
/* 1318 */           beginIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(returnsIndex, procedureDef, "\nbegin", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */ 
/* 1323 */           if (beginIndex == -1) {
/* 1324 */             beginIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, "\n", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */           }
/*      */ 
/* 1333 */           if (beginIndex == -1) {
/* 1334 */             throw SQLError.createSQLException("Driver requires declaration of procedure to either contain a '\\nbegin' or '\\n' to follow argument declaration, or SELECT privilege on mysql.proc to parse column types.", "S1000");
/*      */           }
/*      */ 
/* 1339 */           String returnsDefn = procedureDef.substring(returnsIndex + "RETURNS ".length(), beginIndex);
/*      */ 
/* 1341 */           DatabaseMetaData.TypeDescriptor returnDescriptor = new DatabaseMetaData.TypeDescriptor(this, returnsDefn, null);
/*      */ 
/* 1344 */           resultRows.add(convertTypeDescriptorToProcedureRow(procNameAsBytes, "", false, false, true, returnDescriptor));
/*      */ 
/* 1348 */           beginIndex = returnsIndex;
/*      */         }
/*      */ 
/* 1354 */         if (beginIndex != -1) {
/* 1355 */           beforeBegin = procedureDef.substring(0, beginIndex);
/*      */         } else {
/* 1357 */           beginIndex = StringUtils.indexOfIgnoreCaseRespectQuotes(0, procedureDef, "\n", quoteChar.charAt(0), !this.conn.isNoBackslashEscapesSet());
/*      */ 
/* 1361 */           if (beginIndex != -1)
/* 1362 */             beforeBegin = procedureDef.substring(0, beginIndex);
/*      */           else {
/* 1364 */             throw SQLError.createSQLException("Driver requires declaration of procedure to either contain a '\\nbegin' or '\\n' to follow argument declaration, or SELECT privilege on mysql.proc to parse column types.", "S1000");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1371 */         int endParenIndex = beforeBegin.lastIndexOf(')');
/*      */ 
/* 1373 */         if ((openParenIndex == -1) || (endParenIndex == -1))
/*      */         {
/* 1375 */           throw SQLError.createSQLException("Internal error when parsing callable statement metadata", "S1000");
/*      */         }
/*      */ 
/* 1380 */         parameterDef = procedureDef.substring(openParenIndex + 1, endParenIndex);
/*      */       }
/*      */     }
/*      */     finally {
/* 1384 */       SQLException sqlExRethrow = null;
/*      */ 
/* 1386 */       if (paramRetrievalRs != null) {
/*      */         try {
/* 1388 */           paramRetrievalRs.close();
/*      */         } catch (SQLException sqlEx) {
/* 1390 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */ 
/* 1393 */         paramRetrievalRs = null;
/*      */       }
/*      */ 
/* 1396 */       if (paramRetrievalStmt != null) {
/*      */         try {
/* 1398 */           paramRetrievalStmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1400 */           sqlExRethrow = sqlEx;
/*      */         }
/*      */ 
/* 1403 */         paramRetrievalStmt = null;
/*      */       }
/*      */ 
/* 1406 */       if (sqlExRethrow != null) {
/* 1407 */         throw sqlExRethrow;
/*      */       }
/*      */     }
/*      */ 
/* 1411 */     if (parameterDef != null) {
/* 1412 */       List parseList = StringUtils.split(parameterDef, ",", storageDefnDelims, storageDefnClosures, true);
/*      */ 
/* 1415 */       int parseListLen = parseList.size();
/*      */ 
/* 1417 */       for (int i = 0; i < parseListLen; i++) {
/* 1418 */         String declaration = (String)parseList.get(i);
/*      */ 
/* 1420 */         if (declaration.trim().length() == 0)
/*      */         {
/*      */           break;
/*      */         }
/* 1424 */         StringTokenizer declarationTok = new StringTokenizer(declaration, " \t");
/*      */ 
/* 1427 */         String paramName = null;
/* 1428 */         boolean isOutParam = false;
/* 1429 */         boolean isInParam = false;
/*      */ 
/* 1431 */         if (declarationTok.hasMoreTokens()) {
/* 1432 */           String possibleParamName = declarationTok.nextToken();
/*      */ 
/* 1434 */           if (possibleParamName.equalsIgnoreCase("OUT")) {
/* 1435 */             isOutParam = true;
/*      */ 
/* 1437 */             if (declarationTok.hasMoreTokens())
/* 1438 */               paramName = declarationTok.nextToken();
/*      */             else {
/* 1440 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000");
/*      */             }
/*      */ 
/*      */           }
/* 1444 */           else if (possibleParamName.equalsIgnoreCase("INOUT")) {
/* 1445 */             isOutParam = true;
/* 1446 */             isInParam = true;
/*      */ 
/* 1448 */             if (declarationTok.hasMoreTokens())
/* 1449 */               paramName = declarationTok.nextToken();
/*      */             else {
/* 1451 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000");
/*      */             }
/*      */ 
/*      */           }
/* 1455 */           else if (possibleParamName.equalsIgnoreCase("IN")) {
/* 1456 */             isOutParam = false;
/* 1457 */             isInParam = true;
/*      */ 
/* 1459 */             if (declarationTok.hasMoreTokens())
/* 1460 */               paramName = declarationTok.nextToken();
/*      */             else {
/* 1462 */               throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter name)", "S1000");
/*      */             }
/*      */           }
/*      */           else
/*      */           {
/* 1467 */             isOutParam = false;
/* 1468 */             isInParam = true;
/*      */ 
/* 1470 */             paramName = possibleParamName;
/*      */           }
/*      */ 
/* 1473 */           DatabaseMetaData.TypeDescriptor typeDesc = null;
/*      */ 
/* 1475 */           if (declarationTok.hasMoreTokens()) {
/* 1476 */             StringBuffer typeInfoBuf = new StringBuffer(declarationTok.nextToken());
/*      */ 
/* 1479 */             while (declarationTok.hasMoreTokens()) {
/* 1480 */               typeInfoBuf.append(" ");
/* 1481 */               typeInfoBuf.append(declarationTok.nextToken());
/*      */             }
/*      */ 
/* 1484 */             String typeInfo = typeInfoBuf.toString();
/*      */ 
/* 1486 */             typeDesc = new DatabaseMetaData.TypeDescriptor(this, typeInfo, null);
/*      */           } else {
/* 1488 */             throw SQLError.createSQLException("Internal error when parsing callable statement metadata (missing parameter type)", "S1000");
/*      */           }
/*      */ 
/* 1493 */           int wildCompareRes = StringUtils.wildCompare(paramName, parameterNamePattern);
/*      */ 
/* 1496 */           if (wildCompareRes != -1) {
/* 1497 */             byte[][] row = convertTypeDescriptorToProcedureRow(procNameAsBytes, paramName, isOutParam, isInParam, false, typeDesc);
/*      */ 
/* 1501 */             resultRows.add(row);
/*      */           }
/*      */         } else {
/* 1504 */           throw SQLError.createSQLException("Internal error when parsing callable statement metadata (unknown output from 'SHOW CREATE PROCEDURE')", "S1000");
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int getCascadeDeleteOption(String cascadeOptions)
/*      */   {
/* 1525 */     int onDeletePos = cascadeOptions.indexOf("ON DELETE");
/*      */ 
/* 1527 */     if (onDeletePos != -1) {
/* 1528 */       String deleteOptions = cascadeOptions.substring(onDeletePos, cascadeOptions.length());
/*      */ 
/* 1531 */       if (deleteOptions.startsWith("ON DELETE CASCADE"))
/* 1532 */         return 0;
/* 1533 */       if (deleteOptions.startsWith("ON DELETE SET NULL"))
/* 1534 */         return 2;
/* 1535 */       if (deleteOptions.startsWith("ON DELETE RESTRICT"))
/* 1536 */         return 1;
/* 1537 */       if (deleteOptions.startsWith("ON DELETE NO ACTION")) {
/* 1538 */         return 3;
/*      */       }
/*      */     }
/*      */ 
/* 1542 */     return 3;
/*      */   }
/*      */ 
/*      */   private int getCascadeUpdateOption(String cascadeOptions)
/*      */   {
/* 1554 */     int onUpdatePos = cascadeOptions.indexOf("ON UPDATE");
/*      */ 
/* 1556 */     if (onUpdatePos != -1) {
/* 1557 */       String updateOptions = cascadeOptions.substring(onUpdatePos, cascadeOptions.length());
/*      */ 
/* 1560 */       if (updateOptions.startsWith("ON UPDATE CASCADE"))
/* 1561 */         return 0;
/* 1562 */       if (updateOptions.startsWith("ON UPDATE SET NULL"))
/* 1563 */         return 2;
/* 1564 */       if (updateOptions.startsWith("ON UPDATE RESTRICT"))
/* 1565 */         return 1;
/* 1566 */       if (updateOptions.startsWith("ON UPDATE NO ACTION")) {
/* 1567 */         return 3;
/*      */       }
/*      */     }
/*      */ 
/* 1571 */     return 3;
/*      */   }
/*      */ 
/*      */   protected DatabaseMetaData.IteratorWithCleanup getCatalogIterator(String catalogSpec)
/*      */     throws SQLException
/*      */   {
/*      */     DatabaseMetaData.IteratorWithCleanup allCatalogsIter;
/*      */     DatabaseMetaData.IteratorWithCleanup allCatalogsIter;
/* 1577 */     if (catalogSpec != null)
/*      */     {
/*      */       DatabaseMetaData.IteratorWithCleanup allCatalogsIter;
/* 1578 */       if (!catalogSpec.equals("")) {
/* 1579 */         allCatalogsIter = new DatabaseMetaData.SingleStringIterator(this, catalogSpec);
/*      */       }
/*      */       else
/* 1582 */         allCatalogsIter = new DatabaseMetaData.SingleStringIterator(this, this.database);
/*      */     }
/*      */     else
/*      */     {
/*      */       DatabaseMetaData.IteratorWithCleanup allCatalogsIter;
/* 1584 */       if (this.conn.getNullCatalogMeansCurrent())
/* 1585 */         allCatalogsIter = new DatabaseMetaData.SingleStringIterator(this, this.database);
/*      */       else {
/* 1587 */         allCatalogsIter = new DatabaseMetaData.ResultSetIterator(this, getCatalogs(), 1);
/*      */       }
/*      */     }
/* 1590 */     return allCatalogsIter;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getCatalogs()
/*      */     throws SQLException
/*      */   {
/* 1609 */     java.sql.ResultSet results = null;
/* 1610 */     Statement stmt = null;
/*      */     try
/*      */     {
/* 1613 */       stmt = this.conn.createStatement();
/* 1614 */       stmt.setEscapeProcessing(false);
/* 1615 */       results = stmt.executeQuery("SHOW DATABASES");
/*      */ 
/* 1617 */       ResultSetMetaData resultsMD = results.getMetaData();
/* 1618 */       Field[] fields = new Field[1];
/* 1619 */       fields[0] = new Field("", "TABLE_CAT", 12, resultsMD.getColumnDisplaySize(1));
/*      */ 
/* 1622 */       ArrayList tuples = new ArrayList();
/*      */ 
/* 1624 */       while (results.next()) {
/* 1625 */         rowVal = new byte[1][];
/* 1626 */         rowVal[0] = results.getBytes(1);
/* 1627 */         tuples.add(rowVal);
/*      */       }
/*      */ 
/* 1630 */       rowVal = buildResultSet(fields, tuples);
/*      */     }
/*      */     finally
/*      */     {
/*      */       byte[][] rowVal;
/* 1632 */       if (results != null) {
/*      */         try {
/* 1634 */           results.close();
/*      */         } catch (SQLException sqlEx) {
/* 1636 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */ 
/* 1639 */         results = null;
/*      */       }
/*      */ 
/* 1642 */       if (stmt != null) {
/*      */         try {
/* 1644 */           stmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 1646 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */ 
/* 1649 */         stmt = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String getCatalogSeparator()
/*      */     throws SQLException
/*      */   {
/* 1662 */     return ".";
/*      */   }
/*      */ 
/*      */   public String getCatalogTerm()
/*      */     throws SQLException
/*      */   {
/* 1679 */     return "database";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1720 */     Field[] fields = new Field[8];
/* 1721 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 1722 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 1723 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 1724 */     fields[3] = new Field("", "COLUMN_NAME", 1, 64);
/* 1725 */     fields[4] = new Field("", "GRANTOR", 1, 77);
/* 1726 */     fields[5] = new Field("", "GRANTEE", 1, 77);
/* 1727 */     fields[6] = new Field("", "PRIVILEGE", 1, 64);
/* 1728 */     fields[7] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */ 
/* 1730 */     StringBuffer grantQuery = new StringBuffer("SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv from mysql.columns_priv c, mysql.tables_priv t where c.host = t.host and c.db = t.db and c.table_name = t.table_name ");
/*      */ 
/* 1737 */     if ((catalog != null) && (catalog.length() != 0)) {
/* 1738 */       grantQuery.append(" AND c.db='");
/* 1739 */       grantQuery.append(catalog);
/* 1740 */       grantQuery.append("' ");
/*      */     }
/*      */ 
/* 1744 */     grantQuery.append(" AND c.table_name ='");
/* 1745 */     grantQuery.append(table);
/* 1746 */     grantQuery.append("' AND c.column_name like '");
/* 1747 */     grantQuery.append(columnNamePattern);
/* 1748 */     grantQuery.append("'");
/*      */ 
/* 1750 */     Statement stmt = null;
/* 1751 */     java.sql.ResultSet results = null;
/* 1752 */     ArrayList grantRows = new ArrayList();
/*      */     try
/*      */     {
/* 1755 */       stmt = this.conn.createStatement();
/* 1756 */       stmt.setEscapeProcessing(false);
/* 1757 */       results = stmt.executeQuery(grantQuery.toString());
/*      */ 
/* 1759 */       while (results.next()) {
/* 1760 */         String host = results.getString(1);
/* 1761 */         String db = results.getString(2);
/* 1762 */         String grantor = results.getString(3);
/* 1763 */         String user = results.getString(4);
/*      */ 
/* 1765 */         if ((user == null) || (user.length() == 0)) {
/* 1766 */           user = "%";
/*      */         }
/*      */ 
/* 1769 */         StringBuffer fullUser = new StringBuffer(user);
/*      */ 
/* 1771 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 1772 */           fullUser.append("@");
/* 1773 */           fullUser.append(host);
/*      */         }
/*      */ 
/* 1776 */         String columnName = results.getString(6);
/* 1777 */         String allPrivileges = results.getString(7);
/*      */ 
/* 1779 */         if (allPrivileges != null) {
/* 1780 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */ 
/* 1782 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */ 
/* 1784 */           while (st.hasMoreTokens()) {
/* 1785 */             String privilege = st.nextToken().trim();
/* 1786 */             byte[][] tuple = new byte[8][];
/* 1787 */             tuple[0] = s2b(db);
/* 1788 */             tuple[1] = null;
/* 1789 */             tuple[2] = s2b(table);
/* 1790 */             tuple[3] = s2b(columnName);
/*      */ 
/* 1792 */             if (grantor != null)
/* 1793 */               tuple[4] = s2b(grantor);
/*      */             else {
/* 1795 */               tuple[4] = null;
/*      */             }
/*      */ 
/* 1798 */             tuple[5] = s2b(fullUser.toString());
/* 1799 */             tuple[6] = s2b(privilege);
/* 1800 */             tuple[7] = null;
/* 1801 */             grantRows.add(tuple);
/*      */           }
/*      */         }
/*      */       }
/*      */     } finally {
/* 1806 */       if (results != null) {
/*      */         try {
/* 1808 */           results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 1813 */         results = null;
/*      */       }
/*      */ 
/* 1816 */       if (stmt != null) {
/*      */         try {
/* 1818 */           stmt.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 1823 */         stmt = null;
/*      */       }
/*      */     }
/*      */ 
/* 1827 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 1891 */     if (columnNamePattern == null) {
/* 1892 */       if (this.conn.getNullNamePatternMatchesAll())
/* 1893 */         columnNamePattern = "%";
/*      */       else {
/* 1895 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1901 */     String colPattern = columnNamePattern;
/*      */ 
/* 1903 */     Field[] fields = new Field[18];
/* 1904 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 1905 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 1906 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 1907 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 1908 */     fields[4] = new Field("", "DATA_TYPE", 5, 5);
/* 1909 */     fields[5] = new Field("", "TYPE_NAME", 1, 16);
/* 1910 */     fields[6] = new Field("", "COLUMN_SIZE", 4, Integer.toString(2147483647).length());
/*      */ 
/* 1912 */     fields[7] = new Field("", "BUFFER_LENGTH", 4, 10);
/* 1913 */     fields[8] = new Field("", "DECIMAL_DIGITS", 4, 10);
/* 1914 */     fields[9] = new Field("", "NUM_PREC_RADIX", 4, 10);
/* 1915 */     fields[10] = new Field("", "NULLABLE", 4, 10);
/* 1916 */     fields[11] = new Field("", "REMARKS", 1, 0);
/* 1917 */     fields[12] = new Field("", "COLUMN_DEF", 1, 0);
/* 1918 */     fields[13] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 1919 */     fields[14] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 1920 */     fields[15] = new Field("", "CHAR_OCTET_LENGTH", 4, Integer.toString(2147483647).length());
/*      */ 
/* 1922 */     fields[16] = new Field("", "ORDINAL_POSITION", 4, 10);
/* 1923 */     fields[17] = new Field("", "IS_NULLABLE", 1, 3);
/*      */ 
/* 1925 */     ArrayList rows = new ArrayList();
/* 1926 */     Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     try
/*      */     {
/* 1930 */       new DatabaseMetaData.2(this, getCatalogIterator(catalog), tableNamePattern, catalog, schemaPattern, colPattern, stmt, rows).doForAll();
/*      */     }
/*      */     finally
/*      */     {
/* 2154 */       if (stmt != null) {
/* 2155 */         stmt.close();
/*      */       }
/*      */     }
/*      */ 
/* 2159 */     java.sql.ResultSet results = buildResultSet(fields, rows);
/*      */ 
/* 2161 */     return results;
/*      */   }
/*      */ 
/*      */   public java.sql.Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 2172 */     return this.conn;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getCrossReference(String primaryCatalog, String primarySchema, String primaryTable, String foreignCatalog, String foreignSchema, String foreignTable)
/*      */     throws SQLException
/*      */   {
/* 2246 */     if (primaryTable == null) {
/* 2247 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/* 2251 */     Field[] fields = new Field[14];
/* 2252 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2253 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2254 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2255 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2256 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2257 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2258 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2259 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2260 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2261 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2262 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2263 */     fields[11] = new Field("", "FK_NAME", 1, 0);
/* 2264 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2265 */     fields[13] = new Field("", "DEFERRABILITY", 4, 2);
/*      */ 
/* 2267 */     ArrayList tuples = new ArrayList();
/*      */ 
/* 2269 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2271 */       Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       try
/*      */       {
/* 2275 */         new DatabaseMetaData.3(this, getCatalogIterator(foreignCatalog), stmt, foreignTable, primaryTable, foreignCatalog, foreignSchema, primaryCatalog, primarySchema, tuples).doForAll();
/*      */       }
/*      */       finally
/*      */       {
/* 2417 */         if (stmt != null) {
/* 2418 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2423 */     java.sql.ResultSet results = buildResultSet(fields, tuples);
/*      */ 
/* 2425 */     return results;
/*      */   }
/*      */ 
/*      */   public int getDatabaseMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 2432 */     return this.conn.getServerMajorVersion();
/*      */   }
/*      */ 
/*      */   public int getDatabaseMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 2439 */     return this.conn.getServerMinorVersion();
/*      */   }
/*      */ 
/*      */   public String getDatabaseProductName()
/*      */     throws SQLException
/*      */   {
/* 2450 */     return "MySQL";
/*      */   }
/*      */ 
/*      */   public String getDatabaseProductVersion()
/*      */     throws SQLException
/*      */   {
/* 2461 */     return this.conn.getServerVersion();
/*      */   }
/*      */ 
/*      */   public int getDefaultTransactionIsolation()
/*      */     throws SQLException
/*      */   {
/* 2474 */     if (this.conn.supportsIsolationLevel()) {
/* 2475 */       return 2;
/*      */     }
/*      */ 
/* 2478 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getDriverMajorVersion()
/*      */   {
/* 2487 */     return NonRegisteringDriver.getMajorVersionInternal();
/*      */   }
/*      */ 
/*      */   public int getDriverMinorVersion()
/*      */   {
/* 2496 */     return NonRegisteringDriver.getMinorVersionInternal();
/*      */   }
/*      */ 
/*      */   public String getDriverName()
/*      */     throws SQLException
/*      */   {
/* 2507 */     return "MySQL-AB JDBC Driver";
/*      */   }
/*      */ 
/*      */   public String getDriverVersion()
/*      */     throws SQLException
/*      */   {
/* 2518 */     return "mysql-connector-java-5.0.4 ( $Date: 2006-10-19 17:47:48 +0200 (Thu, 19 Oct 2006) $, $Revision: 5908 $ )";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getExportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 2582 */     if (table == null) {
/* 2583 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/* 2587 */     Field[] fields = new Field[14];
/* 2588 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2589 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2590 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2591 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2592 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2593 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2594 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2595 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2596 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2597 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2598 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2599 */     fields[11] = new Field("", "FK_NAME", 1, 255);
/* 2600 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2601 */     fields[13] = new Field("", "DEFERRABILITY", 4, 2);
/*      */ 
/* 2603 */     ArrayList rows = new ArrayList();
/*      */ 
/* 2605 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2607 */       Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       try
/*      */       {
/* 2611 */         new DatabaseMetaData.4(this, getCatalogIterator(catalog), stmt, table, rows).doForAll();
/*      */       }
/*      */       finally
/*      */       {
/* 2694 */         if (stmt != null) {
/* 2695 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2700 */     java.sql.ResultSet results = buildResultSet(fields, rows);
/*      */ 
/* 2702 */     return results;
/*      */   }
/*      */ 
/*      */   private void getExportKeyResults(String catalog, String exportingTable, String keysComment, List tuples, String fkTableName)
/*      */     throws SQLException
/*      */   {
/* 2726 */     getResultsImpl(catalog, exportingTable, keysComment, tuples, fkTableName, true);
/*      */   }
/*      */ 
/*      */   public String getExtraNameCharacters()
/*      */     throws SQLException
/*      */   {
/* 2739 */     return "#@";
/*      */   }
/*      */ 
/*      */   private int[] getForeignKeyActions(String commentString)
/*      */   {
/* 2752 */     int[] actions = { 3, 3 };
/*      */ 
/* 2756 */     int lastParenIndex = commentString.lastIndexOf(")");
/*      */ 
/* 2758 */     if (lastParenIndex != commentString.length() - 1) {
/* 2759 */       String cascadeOptions = commentString.substring(lastParenIndex + 1).trim().toUpperCase(Locale.ENGLISH);
/*      */ 
/* 2762 */       actions[0] = getCascadeDeleteOption(cascadeOptions);
/* 2763 */       actions[1] = getCascadeUpdateOption(cascadeOptions);
/*      */     }
/*      */ 
/* 2766 */     return actions;
/*      */   }
/*      */ 
/*      */   public String getIdentifierQuoteString()
/*      */     throws SQLException
/*      */   {
/* 2779 */     if (this.conn.supportsQuotedIdentifiers()) {
/* 2780 */       if (!this.conn.useAnsiQuotedIdentifiers()) {
/* 2781 */         return "`";
/*      */       }
/*      */ 
/* 2784 */       return "\"";
/*      */     }
/*      */ 
/* 2787 */     return " ";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getImportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 2851 */     if (table == null) {
/* 2852 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/* 2856 */     Field[] fields = new Field[14];
/* 2857 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/* 2858 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/* 2859 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/* 2860 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/* 2861 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/* 2862 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/* 2863 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/* 2864 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/* 2865 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/* 2866 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/* 2867 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/* 2868 */     fields[11] = new Field("", "FK_NAME", 1, 255);
/* 2869 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/* 2870 */     fields[13] = new Field("", "DEFERRABILITY", 4, 2);
/*      */ 
/* 2872 */     ArrayList rows = new ArrayList();
/*      */ 
/* 2874 */     if (this.conn.versionMeetsMinimum(3, 23, 0))
/*      */     {
/* 2876 */       Statement stmt = this.conn.getMetadataSafeStatement();
/*      */       try
/*      */       {
/* 2880 */         new DatabaseMetaData.5(this, getCatalogIterator(catalog), table, stmt, rows).doForAll();
/*      */       }
/*      */       finally
/*      */       {
/* 2959 */         if (stmt != null) {
/* 2960 */           stmt.close();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 2965 */     java.sql.ResultSet results = buildResultSet(fields, rows);
/*      */ 
/* 2967 */     return results;
/*      */   }
/*      */ 
/*      */   private void getImportKeyResults(String catalog, String importingTable, String keysComment, List tuples)
/*      */     throws SQLException
/*      */   {
/* 2989 */     getResultsImpl(catalog, importingTable, keysComment, tuples, null, false);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate)
/*      */     throws SQLException
/*      */   {
/* 3060 */     Field[] fields = new Field[13];
/* 3061 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3062 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3063 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3064 */     fields[3] = new Field("", "NON_UNIQUE", 1, 4);
/* 3065 */     fields[4] = new Field("", "INDEX_QUALIFIER", 1, 1);
/* 3066 */     fields[5] = new Field("", "INDEX_NAME", 1, 32);
/* 3067 */     fields[6] = new Field("", "TYPE", 1, 32);
/* 3068 */     fields[7] = new Field("", "ORDINAL_POSITION", 5, 5);
/* 3069 */     fields[8] = new Field("", "COLUMN_NAME", 1, 32);
/* 3070 */     fields[9] = new Field("", "ASC_OR_DESC", 1, 1);
/* 3071 */     fields[10] = new Field("", "CARDINALITY", 4, 10);
/* 3072 */     fields[11] = new Field("", "PAGES", 4, 10);
/* 3073 */     fields[12] = new Field("", "FILTER_CONDITION", 1, 32);
/*      */ 
/* 3075 */     ArrayList rows = new ArrayList();
/* 3076 */     Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     try
/*      */     {
/* 3080 */       new DatabaseMetaData.6(this, getCatalogIterator(catalog), table, stmt, unique, rows).doForAll();
/*      */ 
/* 3160 */       java.sql.ResultSet indexInfo = buildResultSet(fields, rows);
/*      */ 
/* 3162 */       java.sql.ResultSet localResultSet1 = indexInfo;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/* 3164 */       if (stmt != null)
/* 3165 */         stmt.close(); 
/* 3165 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public int getJDBCMajorVersion()
/*      */     throws SQLException
/*      */   {
/* 3174 */     return 3;
/*      */   }
/*      */ 
/*      */   public int getJDBCMinorVersion()
/*      */     throws SQLException
/*      */   {
/* 3181 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxBinaryLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3192 */     return 16777208;
/*      */   }
/*      */ 
/*      */   public int getMaxCatalogNameLength()
/*      */     throws SQLException
/*      */   {
/* 3203 */     return 32;
/*      */   }
/*      */ 
/*      */   public int getMaxCharLiteralLength()
/*      */     throws SQLException
/*      */   {
/* 3214 */     return 16777208;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnNameLength()
/*      */     throws SQLException
/*      */   {
/* 3225 */     return 64;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInGroupBy()
/*      */     throws SQLException
/*      */   {
/* 3236 */     return 64;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInIndex()
/*      */     throws SQLException
/*      */   {
/* 3247 */     return 16;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 3258 */     return 64;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInSelect()
/*      */     throws SQLException
/*      */   {
/* 3269 */     return 256;
/*      */   }
/*      */ 
/*      */   public int getMaxColumnsInTable()
/*      */     throws SQLException
/*      */   {
/* 3280 */     return 512;
/*      */   }
/*      */ 
/*      */   public int getMaxConnections()
/*      */     throws SQLException
/*      */   {
/* 3291 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxCursorNameLength()
/*      */     throws SQLException
/*      */   {
/* 3302 */     return 64;
/*      */   }
/*      */ 
/*      */   public int getMaxIndexLength()
/*      */     throws SQLException
/*      */   {
/* 3313 */     return 256;
/*      */   }
/*      */ 
/*      */   public int getMaxProcedureNameLength()
/*      */     throws SQLException
/*      */   {
/* 3324 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxRowSize()
/*      */     throws SQLException
/*      */   {
/* 3335 */     return 2147483639;
/*      */   }
/*      */ 
/*      */   public int getMaxSchemaNameLength()
/*      */     throws SQLException
/*      */   {
/* 3346 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxStatementLength()
/*      */     throws SQLException
/*      */   {
/* 3357 */     return MysqlIO.getMaxBuf() - 4;
/*      */   }
/*      */ 
/*      */   public int getMaxStatements()
/*      */     throws SQLException
/*      */   {
/* 3368 */     return 0;
/*      */   }
/*      */ 
/*      */   public int getMaxTableNameLength()
/*      */     throws SQLException
/*      */   {
/* 3379 */     return 64;
/*      */   }
/*      */ 
/*      */   public int getMaxTablesInSelect()
/*      */     throws SQLException
/*      */   {
/* 3390 */     return 256;
/*      */   }
/*      */ 
/*      */   public int getMaxUserNameLength()
/*      */     throws SQLException
/*      */   {
/* 3401 */     return 16;
/*      */   }
/*      */ 
/*      */   public String getNumericFunctions()
/*      */     throws SQLException
/*      */   {
/* 3412 */     return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getPrimaryKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 3444 */     Field[] fields = new Field[6];
/* 3445 */     fields[0] = new Field("", "TABLE_CAT", 1, 255);
/* 3446 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 0);
/* 3447 */     fields[2] = new Field("", "TABLE_NAME", 1, 255);
/* 3448 */     fields[3] = new Field("", "COLUMN_NAME", 1, 32);
/* 3449 */     fields[4] = new Field("", "KEY_SEQ", 5, 5);
/* 3450 */     fields[5] = new Field("", "PK_NAME", 1, 32);
/*      */ 
/* 3452 */     if (table == null) {
/* 3453 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/* 3457 */     ArrayList rows = new ArrayList();
/* 3458 */     Statement stmt = this.conn.getMetadataSafeStatement();
/*      */     try
/*      */     {
/* 3462 */       new DatabaseMetaData.7(this, getCatalogIterator(catalog), table, stmt, rows).doForAll();
/*      */     }
/*      */     finally
/*      */     {
/* 3526 */       if (stmt != null) {
/* 3527 */         stmt.close();
/*      */       }
/*      */     }
/*      */ 
/* 3531 */     java.sql.ResultSet results = buildResultSet(fields, rows);
/*      */ 
/* 3533 */     return results;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/* 3606 */     Field[] fields = new Field[13];
/*      */ 
/* 3608 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/* 3609 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/* 3610 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/* 3611 */     fields[3] = new Field("", "COLUMN_NAME", 1, 0);
/* 3612 */     fields[4] = new Field("", "COLUMN_TYPE", 1, 0);
/* 3613 */     fields[5] = new Field("", "DATA_TYPE", 5, 0);
/* 3614 */     fields[6] = new Field("", "TYPE_NAME", 1, 0);
/* 3615 */     fields[7] = new Field("", "PRECISION", 4, 0);
/* 3616 */     fields[8] = new Field("", "LENGTH", 4, 0);
/* 3617 */     fields[9] = new Field("", "SCALE", 5, 0);
/* 3618 */     fields[10] = new Field("", "RADIX", 5, 0);
/* 3619 */     fields[11] = new Field("", "NULLABLE", 5, 0);
/* 3620 */     fields[12] = new Field("", "REMARKS", 1, 0);
/*      */ 
/* 3622 */     List proceduresToExtractList = new ArrayList();
/*      */ 
/* 3624 */     if (supportsStoredProcedures()) {
/* 3625 */       if ((procedureNamePattern.indexOf("%") == -1) && (procedureNamePattern.indexOf("?") == -1))
/*      */       {
/* 3627 */         proceduresToExtractList.add(procedureNamePattern);
/*      */       }
/*      */       else {
/* 3630 */         java.sql.ResultSet procedureNameRs = null;
/*      */         try
/*      */         {
/* 3634 */           procedureNameRs = getProcedures(catalog, schemaPattern, procedureNamePattern);
/*      */ 
/* 3637 */           while (procedureNameRs.next()) {
/* 3638 */             proceduresToExtractList.add(procedureNameRs.getString(3));
/*      */           }
/*      */ 
/* 3646 */           Collections.sort(proceduresToExtractList);
/*      */         } finally {
/* 3648 */           SQLException rethrowSqlEx = null;
/*      */ 
/* 3650 */           if (procedureNameRs != null) {
/*      */             try {
/* 3652 */               procedureNameRs.close();
/*      */             } catch (SQLException sqlEx) {
/* 3654 */               rethrowSqlEx = sqlEx;
/*      */             }
/*      */           }
/*      */ 
/* 3658 */           if (rethrowSqlEx != null) {
/* 3659 */             throw rethrowSqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 3665 */     ArrayList resultRows = new ArrayList();
/*      */ 
/* 3667 */     for (Iterator iter = proceduresToExtractList.iterator(); iter.hasNext(); ) {
/* 3668 */       String procName = (String)iter.next();
/*      */ 
/* 3670 */       getCallStmtParameterTypes(catalog, procName, columnNamePattern, resultRows);
/*      */     }
/*      */ 
/* 3674 */     return buildResultSet(fields, resultRows);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
/*      */     throws SQLException
/*      */   {
/* 3720 */     return getProceduresAndOrFunctions(catalog, schemaPattern, procedureNamePattern, true, true);
/*      */   }
/*      */ 
/*      */   protected java.sql.ResultSet getProceduresAndOrFunctions(String catalog, String schemaPattern, String procedureNamePattern, boolean returnProcedures, boolean returnFunctions)
/*      */     throws SQLException
/*      */   {
/* 3730 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0))
/*      */     {
/* 3732 */       if (this.conn.getNullNamePatternMatchesAll())
/* 3733 */         procedureNamePattern = "%";
/*      */       else {
/* 3735 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3741 */     Field[] fields = new Field[8];
/* 3742 */     fields[0] = new Field("", "PROCEDURE_CAT", 1, 0);
/* 3743 */     fields[1] = new Field("", "PROCEDURE_SCHEM", 1, 0);
/* 3744 */     fields[2] = new Field("", "PROCEDURE_NAME", 1, 0);
/* 3745 */     fields[3] = new Field("", "reserved1", 1, 0);
/* 3746 */     fields[4] = new Field("", "reserved2", 1, 0);
/* 3747 */     fields[5] = new Field("", "reserved3", 1, 0);
/* 3748 */     fields[6] = new Field("", "REMARKS", 1, 0);
/* 3749 */     fields[7] = new Field("", "PROCEDURE_TYPE", 5, 0);
/*      */ 
/* 3751 */     ArrayList procedureRows = new ArrayList();
/*      */ 
/* 3753 */     if (supportsStoredProcedures()) {
/* 3754 */       String procNamePattern = procedureNamePattern;
/*      */ 
/* 3756 */       Map procedureRowsOrderedByName = new TreeMap();
/*      */ 
/* 3758 */       new DatabaseMetaData.8(this, getCatalogIterator(catalog), procNamePattern, returnProcedures, procedureRowsOrderedByName, returnFunctions, procedureRows).doForAll();
/*      */     }
/*      */ 
/* 3889 */     return buildResultSet(fields, procedureRows);
/*      */   }
/*      */ 
/*      */   public String getProcedureTerm()
/*      */     throws SQLException
/*      */   {
/* 3900 */     return "PROCEDURE";
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 3907 */     return 1;
/*      */   }
/*      */ 
/*      */   private void getResultsImpl(String catalog, String table, String keysComment, List tuples, String fkTableName, boolean isExport)
/*      */     throws SQLException
/*      */   {
/* 3914 */     DatabaseMetaData.LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keysComment);
/*      */ 
/* 3916 */     if ((isExport) && (!parsedInfo.referencedTable.equals(table))) {
/* 3917 */       return;
/*      */     }
/*      */ 
/* 3920 */     if (parsedInfo.localColumnsList.size() != parsedInfo.referencedColumnsList.size())
/*      */     {
/* 3922 */       throw SQLError.createSQLException("Error parsing foreign keys definition,number of local and referenced columns is not the same.", "S1000");
/*      */     }
/*      */ 
/* 3928 */     Iterator localColumnNames = parsedInfo.localColumnsList.iterator();
/* 3929 */     Iterator referColumnNames = parsedInfo.referencedColumnsList.iterator();
/*      */ 
/* 3931 */     int keySeqIndex = 1;
/*      */ 
/* 3933 */     while (localColumnNames.hasNext()) {
/* 3934 */       byte[][] tuple = new byte[14][];
/* 3935 */       String lColumnName = removeQuotedId(localColumnNames.next().toString());
/*      */ 
/* 3937 */       String rColumnName = removeQuotedId(referColumnNames.next().toString());
/*      */ 
/* 3939 */       tuple[4] = (catalog == null ? new byte[0] : s2b(catalog));
/*      */ 
/* 3941 */       tuple[5] = null;
/* 3942 */       tuple[6] = s2b(isExport ? fkTableName : table);
/* 3943 */       tuple[7] = s2b(lColumnName);
/* 3944 */       tuple[0] = s2b(parsedInfo.referencedCatalog);
/* 3945 */       tuple[1] = null;
/* 3946 */       tuple[2] = s2b(isExport ? table : parsedInfo.referencedTable);
/*      */ 
/* 3948 */       tuple[3] = s2b(rColumnName);
/* 3949 */       tuple[8] = s2b(Integer.toString(keySeqIndex++));
/*      */ 
/* 3951 */       int[] actions = getForeignKeyActions(keysComment);
/*      */ 
/* 3953 */       tuple[9] = s2b(Integer.toString(actions[1]));
/* 3954 */       tuple[10] = s2b(Integer.toString(actions[0]));
/* 3955 */       tuple[11] = s2b(parsedInfo.constraintName);
/* 3956 */       tuple[12] = null;
/* 3957 */       tuple[13] = s2b(Integer.toString(7));
/*      */ 
/* 3959 */       tuples.add(tuple);
/*      */     }
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getSchemas()
/*      */     throws SQLException
/*      */   {
/* 3979 */     Field[] fields = new Field[1];
/* 3980 */     fields[0] = new Field("", "TABLE_SCHEM", 1, 0);
/*      */ 
/* 3982 */     ArrayList tuples = new ArrayList();
/* 3983 */     java.sql.ResultSet results = buildResultSet(fields, tuples);
/*      */ 
/* 3985 */     return results;
/*      */   }
/*      */ 
/*      */   public String getSchemaTerm()
/*      */     throws SQLException
/*      */   {
/* 3996 */     return "";
/*      */   }
/*      */ 
/*      */   public String getSearchStringEscape()
/*      */     throws SQLException
/*      */   {
/* 4014 */     return "\\";
/*      */   }
/*      */ 
/*      */   public String getSQLKeywords()
/*      */     throws SQLException
/*      */   {
/* 4026 */     return "AUTO_INCREMENT,BINARY,BLOB,ENUM,INFILE,LOAD,MEDIUMINT,OPTION,OUTFILE,REPLACE,SET,TEXT,UNSIGNED,ZEROFILL";
/*      */   }
/*      */ 
/*      */   public int getSQLStateType()
/*      */     throws SQLException
/*      */   {
/* 4048 */     if (this.conn.versionMeetsMinimum(4, 1, 0)) {
/* 4049 */       return 2;
/*      */     }
/*      */ 
/* 4052 */     if (this.conn.getUseSqlStateCodes()) {
/* 4053 */       return 2;
/*      */     }
/*      */ 
/* 4056 */     return 1;
/*      */   }
/*      */ 
/*      */   public String getStringFunctions()
/*      */     throws SQLException
/*      */   {
/* 4067 */     return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getSuperTables(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4081 */     Field[] fields = new Field[4];
/* 4082 */     fields[0] = new Field("", "TABLE_CAT", 1, 32);
/* 4083 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 32);
/* 4084 */     fields[2] = new Field("", "TABLE_NAME", 1, 32);
/* 4085 */     fields[3] = new Field("", "SUPERTABLE_NAME", 1, 32);
/*      */ 
/* 4087 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getSuperTypes(String arg0, String arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/* 4095 */     Field[] fields = new Field[6];
/* 4096 */     fields[0] = new Field("", "TABLE_CAT", 1, 32);
/* 4097 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 32);
/* 4098 */     fields[2] = new Field("", "TYPE_NAME", 1, 32);
/* 4099 */     fields[3] = new Field("", "SUPERTYPE_CAT", 1, 32);
/* 4100 */     fields[4] = new Field("", "SUPERTYPE_SCHEM", 1, 32);
/* 4101 */     fields[5] = new Field("", "SUPERTYPE_NAME", 1, 32);
/*      */ 
/* 4103 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */ 
/*      */   public String getSystemFunctions()
/*      */     throws SQLException
/*      */   {
/* 4114 */     return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
/*      */   }
/*      */ 
/*      */   private String getTableNameWithCase(String table) {
/* 4118 */     String tableNameWithCase = this.conn.lowerCaseTableNames() ? table.toLowerCase() : table;
/*      */ 
/* 4121 */     return tableNameWithCase;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern)
/*      */     throws SQLException
/*      */   {
/* 4161 */     if (tableNamePattern == null) {
/* 4162 */       if (this.conn.getNullNamePatternMatchesAll())
/* 4163 */         tableNamePattern = "%";
/*      */       else {
/* 4165 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4171 */     Field[] fields = new Field[7];
/* 4172 */     fields[0] = new Field("", "TABLE_CAT", 1, 64);
/* 4173 */     fields[1] = new Field("", "TABLE_SCHEM", 1, 1);
/* 4174 */     fields[2] = new Field("", "TABLE_NAME", 1, 64);
/* 4175 */     fields[3] = new Field("", "GRANTOR", 1, 77);
/* 4176 */     fields[4] = new Field("", "GRANTEE", 1, 77);
/* 4177 */     fields[5] = new Field("", "PRIVILEGE", 1, 64);
/* 4178 */     fields[6] = new Field("", "IS_GRANTABLE", 1, 3);
/*      */ 
/* 4180 */     StringBuffer grantQuery = new StringBuffer("SELECT host,db,table_name,grantor,user,table_priv from mysql.tables_priv ");
/*      */ 
/* 4182 */     grantQuery.append(" WHERE ");
/*      */ 
/* 4184 */     if ((catalog != null) && (catalog.length() != 0)) {
/* 4185 */       grantQuery.append(" db='");
/* 4186 */       grantQuery.append(catalog);
/* 4187 */       grantQuery.append("' AND ");
/*      */     }
/*      */ 
/* 4190 */     grantQuery.append("table_name like '");
/* 4191 */     grantQuery.append(tableNamePattern);
/* 4192 */     grantQuery.append("'");
/*      */ 
/* 4194 */     java.sql.ResultSet results = null;
/* 4195 */     ArrayList grantRows = new ArrayList();
/* 4196 */     Statement stmt = null;
/*      */     try
/*      */     {
/* 4199 */       stmt = this.conn.createStatement();
/* 4200 */       stmt.setEscapeProcessing(false);
/*      */ 
/* 4202 */       results = stmt.executeQuery(grantQuery.toString());
/*      */ 
/* 4204 */       while (results.next()) {
/* 4205 */         String host = results.getString(1);
/* 4206 */         String db = results.getString(2);
/* 4207 */         String table = results.getString(3);
/* 4208 */         String grantor = results.getString(4);
/* 4209 */         String user = results.getString(5);
/*      */ 
/* 4211 */         if ((user == null) || (user.length() == 0)) {
/* 4212 */           user = "%";
/*      */         }
/*      */ 
/* 4215 */         StringBuffer fullUser = new StringBuffer(user);
/*      */ 
/* 4217 */         if ((host != null) && (this.conn.getUseHostsInPrivileges())) {
/* 4218 */           fullUser.append("@");
/* 4219 */           fullUser.append(host);
/*      */         }
/*      */ 
/* 4222 */         String allPrivileges = results.getString(6);
/*      */ 
/* 4224 */         if (allPrivileges != null) {
/* 4225 */           allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
/*      */ 
/* 4227 */           StringTokenizer st = new StringTokenizer(allPrivileges, ",");
/*      */ 
/* 4229 */           while (st.hasMoreTokens()) {
/* 4230 */             String privilege = st.nextToken().trim();
/*      */ 
/* 4233 */             java.sql.ResultSet columnResults = null;
/*      */             try
/*      */             {
/* 4236 */               columnResults = getColumns(catalog, schemaPattern, table, "%");
/*      */ 
/* 4239 */               while (columnResults.next()) {
/* 4240 */                 byte[][] tuple = new byte[8][];
/* 4241 */                 tuple[0] = s2b(db);
/* 4242 */                 tuple[1] = null;
/* 4243 */                 tuple[2] = s2b(table);
/*      */ 
/* 4245 */                 if (grantor != null)
/* 4246 */                   tuple[3] = s2b(grantor);
/*      */                 else {
/* 4248 */                   tuple[3] = null;
/*      */                 }
/*      */ 
/* 4251 */                 tuple[4] = s2b(fullUser.toString());
/* 4252 */                 tuple[5] = s2b(privilege);
/* 4253 */                 tuple[6] = null;
/* 4254 */                 grantRows.add(tuple);
/*      */               }
/*      */             } finally {
/* 4257 */               if (columnResults != null)
/*      */                 try {
/* 4259 */                   columnResults.close();
/*      */                 }
/*      */                 catch (Exception ex) {
/*      */                 }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/* 4269 */       if (results != null) {
/*      */         try {
/* 4271 */           results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 4276 */         results = null;
/*      */       }
/*      */ 
/* 4279 */       if (stmt != null) {
/*      */         try {
/* 4281 */           stmt.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 4286 */         stmt = null;
/*      */       }
/*      */     }
/*      */ 
/* 4290 */     return buildResultSet(fields, grantRows);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types)
/*      */     throws SQLException
/*      */   {
/* 4332 */     if (tableNamePattern == null) {
/* 4333 */       if (this.conn.getNullNamePatternMatchesAll())
/* 4334 */         tableNamePattern = "%";
/*      */       else {
/* 4336 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 4342 */     Field[] fields = new Field[5];
/* 4343 */     fields[0] = new Field("", "TABLE_CAT", 12, 255);
/* 4344 */     fields[1] = new Field("", "TABLE_SCHEM", 12, 0);
/* 4345 */     fields[2] = new Field("", "TABLE_NAME", 12, 255);
/* 4346 */     fields[3] = new Field("", "TABLE_TYPE", 12, 5);
/* 4347 */     fields[4] = new Field("", "REMARKS", 12, 0);
/*      */ 
/* 4349 */     ArrayList tuples = new ArrayList();
/*      */ 
/* 4351 */     Statement stmt = this.conn.getMetadataSafeStatement();
/*      */ 
/* 4353 */     String tableNamePat = tableNamePattern;
/*      */     try
/*      */     {
/* 4357 */       new DatabaseMetaData.9(this, getCatalogIterator(catalog), stmt, tableNamePat, types, tuples).doForAll();
/*      */     }
/*      */     finally
/*      */     {
/* 4540 */       if (stmt != null) {
/* 4541 */         stmt.close();
/*      */       }
/*      */     }
/*      */ 
/* 4545 */     java.sql.ResultSet tables = buildResultSet(fields, tuples);
/*      */ 
/* 4547 */     return tables;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getTableTypes()
/*      */     throws SQLException
/*      */   {
/* 4568 */     ArrayList tuples = new ArrayList();
/* 4569 */     Field[] fields = new Field[1];
/* 4570 */     fields[0] = new Field("", "TABLE_TYPE", 12, 5);
/*      */ 
/* 4572 */     byte[][] tableTypeRow = new byte[1][];
/* 4573 */     tableTypeRow[0] = TABLE_AS_BYTES;
/* 4574 */     tuples.add(tableTypeRow);
/*      */ 
/* 4576 */     if (this.conn.versionMeetsMinimum(5, 0, 1)) {
/* 4577 */       byte[][] viewTypeRow = new byte[1][];
/* 4578 */       viewTypeRow[0] = VIEW_AS_BYTES;
/* 4579 */       tuples.add(viewTypeRow);
/*      */     }
/*      */ 
/* 4582 */     byte[][] tempTypeRow = new byte[1][];
/* 4583 */     tempTypeRow[0] = s2b("LOCAL TEMPORARY");
/* 4584 */     tuples.add(tempTypeRow);
/*      */ 
/* 4586 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */   public String getTimeDateFunctions()
/*      */     throws SQLException
/*      */   {
/* 4597 */     return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getTypeInfo()
/*      */     throws SQLException
/*      */   {
/* 4706 */     Field[] fields = new Field[18];
/* 4707 */     fields[0] = new Field("", "TYPE_NAME", 1, 32);
/* 4708 */     fields[1] = new Field("", "DATA_TYPE", 5, 5);
/* 4709 */     fields[2] = new Field("", "PRECISION", 4, 10);
/* 4710 */     fields[3] = new Field("", "LITERAL_PREFIX", 1, 4);
/* 4711 */     fields[4] = new Field("", "LITERAL_SUFFIX", 1, 4);
/* 4712 */     fields[5] = new Field("", "CREATE_PARAMS", 1, 32);
/* 4713 */     fields[6] = new Field("", "NULLABLE", 5, 5);
/* 4714 */     fields[7] = new Field("", "CASE_SENSITIVE", 1, 3);
/* 4715 */     fields[8] = new Field("", "SEARCHABLE", 5, 3);
/* 4716 */     fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", 1, 3);
/* 4717 */     fields[10] = new Field("", "FIXED_PREC_SCALE", 1, 3);
/* 4718 */     fields[11] = new Field("", "AUTO_INCREMENT", 1, 3);
/* 4719 */     fields[12] = new Field("", "LOCAL_TYPE_NAME", 1, 32);
/* 4720 */     fields[13] = new Field("", "MINIMUM_SCALE", 5, 5);
/* 4721 */     fields[14] = new Field("", "MAXIMUM_SCALE", 5, 5);
/* 4722 */     fields[15] = new Field("", "SQL_DATA_TYPE", 4, 10);
/* 4723 */     fields[16] = new Field("", "SQL_DATETIME_SUB", 4, 10);
/* 4724 */     fields[17] = new Field("", "NUM_PREC_RADIX", 4, 10);
/*      */ 
/* 4726 */     byte[][] rowVal = (byte[][])null;
/* 4727 */     ArrayList tuples = new ArrayList();
/*      */ 
/* 4736 */     rowVal = new byte[18][];
/* 4737 */     rowVal[0] = s2b("BIT");
/* 4738 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */ 
/* 4741 */     rowVal[2] = s2b("1");
/* 4742 */     rowVal[3] = s2b("");
/* 4743 */     rowVal[4] = s2b("");
/* 4744 */     rowVal[5] = s2b("");
/* 4745 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4749 */     rowVal[7] = s2b("true");
/* 4750 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4754 */     rowVal[9] = s2b("false");
/* 4755 */     rowVal[10] = s2b("false");
/* 4756 */     rowVal[11] = s2b("false");
/* 4757 */     rowVal[12] = s2b("BIT");
/* 4758 */     rowVal[13] = s2b("0");
/* 4759 */     rowVal[14] = s2b("0");
/* 4760 */     rowVal[15] = s2b("0");
/* 4761 */     rowVal[16] = s2b("0");
/* 4762 */     rowVal[17] = s2b("10");
/* 4763 */     tuples.add(rowVal);
/*      */ 
/* 4768 */     rowVal = new byte[18][];
/* 4769 */     rowVal[0] = s2b("BOOL");
/* 4770 */     rowVal[1] = Integer.toString(-7).getBytes();
/*      */ 
/* 4773 */     rowVal[2] = s2b("1");
/* 4774 */     rowVal[3] = s2b("");
/* 4775 */     rowVal[4] = s2b("");
/* 4776 */     rowVal[5] = s2b("");
/* 4777 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4781 */     rowVal[7] = s2b("true");
/* 4782 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4786 */     rowVal[9] = s2b("false");
/* 4787 */     rowVal[10] = s2b("false");
/* 4788 */     rowVal[11] = s2b("false");
/* 4789 */     rowVal[12] = s2b("BOOL");
/* 4790 */     rowVal[13] = s2b("0");
/* 4791 */     rowVal[14] = s2b("0");
/* 4792 */     rowVal[15] = s2b("0");
/* 4793 */     rowVal[16] = s2b("0");
/* 4794 */     rowVal[17] = s2b("10");
/* 4795 */     tuples.add(rowVal);
/*      */ 
/* 4800 */     rowVal = new byte[18][];
/* 4801 */     rowVal[0] = s2b("TINYINT");
/* 4802 */     rowVal[1] = Integer.toString(-6).getBytes();
/*      */ 
/* 4805 */     rowVal[2] = s2b("3");
/* 4806 */     rowVal[3] = s2b("");
/* 4807 */     rowVal[4] = s2b("");
/* 4808 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 4809 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4813 */     rowVal[7] = s2b("false");
/* 4814 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4818 */     rowVal[9] = s2b("true");
/* 4819 */     rowVal[10] = s2b("false");
/* 4820 */     rowVal[11] = s2b("true");
/* 4821 */     rowVal[12] = s2b("TINYINT");
/* 4822 */     rowVal[13] = s2b("0");
/* 4823 */     rowVal[14] = s2b("0");
/* 4824 */     rowVal[15] = s2b("0");
/* 4825 */     rowVal[16] = s2b("0");
/* 4826 */     rowVal[17] = s2b("10");
/* 4827 */     tuples.add(rowVal);
/*      */ 
/* 4832 */     rowVal = new byte[18][];
/* 4833 */     rowVal[0] = s2b("BIGINT");
/* 4834 */     rowVal[1] = Integer.toString(-5).getBytes();
/*      */ 
/* 4837 */     rowVal[2] = s2b("19");
/* 4838 */     rowVal[3] = s2b("");
/* 4839 */     rowVal[4] = s2b("");
/* 4840 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 4841 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4845 */     rowVal[7] = s2b("false");
/* 4846 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4850 */     rowVal[9] = s2b("true");
/* 4851 */     rowVal[10] = s2b("false");
/* 4852 */     rowVal[11] = s2b("true");
/* 4853 */     rowVal[12] = s2b("BIGINT");
/* 4854 */     rowVal[13] = s2b("0");
/* 4855 */     rowVal[14] = s2b("0");
/* 4856 */     rowVal[15] = s2b("0");
/* 4857 */     rowVal[16] = s2b("0");
/* 4858 */     rowVal[17] = s2b("10");
/* 4859 */     tuples.add(rowVal);
/*      */ 
/* 4864 */     rowVal = new byte[18][];
/* 4865 */     rowVal[0] = s2b("LONG VARBINARY");
/* 4866 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/* 4869 */     rowVal[2] = s2b("16777215");
/* 4870 */     rowVal[3] = s2b("'");
/* 4871 */     rowVal[4] = s2b("'");
/* 4872 */     rowVal[5] = s2b("");
/* 4873 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4877 */     rowVal[7] = s2b("true");
/* 4878 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4882 */     rowVal[9] = s2b("false");
/* 4883 */     rowVal[10] = s2b("false");
/* 4884 */     rowVal[11] = s2b("false");
/* 4885 */     rowVal[12] = s2b("LONG VARBINARY");
/* 4886 */     rowVal[13] = s2b("0");
/* 4887 */     rowVal[14] = s2b("0");
/* 4888 */     rowVal[15] = s2b("0");
/* 4889 */     rowVal[16] = s2b("0");
/* 4890 */     rowVal[17] = s2b("10");
/* 4891 */     tuples.add(rowVal);
/*      */ 
/* 4896 */     rowVal = new byte[18][];
/* 4897 */     rowVal[0] = s2b("MEDIUMBLOB");
/* 4898 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/* 4901 */     rowVal[2] = s2b("16777215");
/* 4902 */     rowVal[3] = s2b("'");
/* 4903 */     rowVal[4] = s2b("'");
/* 4904 */     rowVal[5] = s2b("");
/* 4905 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4909 */     rowVal[7] = s2b("true");
/* 4910 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4914 */     rowVal[9] = s2b("false");
/* 4915 */     rowVal[10] = s2b("false");
/* 4916 */     rowVal[11] = s2b("false");
/* 4917 */     rowVal[12] = s2b("MEDIUMBLOB");
/* 4918 */     rowVal[13] = s2b("0");
/* 4919 */     rowVal[14] = s2b("0");
/* 4920 */     rowVal[15] = s2b("0");
/* 4921 */     rowVal[16] = s2b("0");
/* 4922 */     rowVal[17] = s2b("10");
/* 4923 */     tuples.add(rowVal);
/*      */ 
/* 4928 */     rowVal = new byte[18][];
/* 4929 */     rowVal[0] = s2b("LONGBLOB");
/* 4930 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/* 4933 */     rowVal[2] = Integer.toString(2147483647).getBytes();
/*      */ 
/* 4936 */     rowVal[3] = s2b("'");
/* 4937 */     rowVal[4] = s2b("'");
/* 4938 */     rowVal[5] = s2b("");
/* 4939 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4943 */     rowVal[7] = s2b("true");
/* 4944 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4948 */     rowVal[9] = s2b("false");
/* 4949 */     rowVal[10] = s2b("false");
/* 4950 */     rowVal[11] = s2b("false");
/* 4951 */     rowVal[12] = s2b("LONGBLOB");
/* 4952 */     rowVal[13] = s2b("0");
/* 4953 */     rowVal[14] = s2b("0");
/* 4954 */     rowVal[15] = s2b("0");
/* 4955 */     rowVal[16] = s2b("0");
/* 4956 */     rowVal[17] = s2b("10");
/* 4957 */     tuples.add(rowVal);
/*      */ 
/* 4962 */     rowVal = new byte[18][];
/* 4963 */     rowVal[0] = s2b("BLOB");
/* 4964 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/* 4967 */     rowVal[2] = s2b("65535");
/* 4968 */     rowVal[3] = s2b("'");
/* 4969 */     rowVal[4] = s2b("'");
/* 4970 */     rowVal[5] = s2b("");
/* 4971 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 4975 */     rowVal[7] = s2b("true");
/* 4976 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 4980 */     rowVal[9] = s2b("false");
/* 4981 */     rowVal[10] = s2b("false");
/* 4982 */     rowVal[11] = s2b("false");
/* 4983 */     rowVal[12] = s2b("BLOB");
/* 4984 */     rowVal[13] = s2b("0");
/* 4985 */     rowVal[14] = s2b("0");
/* 4986 */     rowVal[15] = s2b("0");
/* 4987 */     rowVal[16] = s2b("0");
/* 4988 */     rowVal[17] = s2b("10");
/* 4989 */     tuples.add(rowVal);
/*      */ 
/* 4994 */     rowVal = new byte[18][];
/* 4995 */     rowVal[0] = s2b("TINYBLOB");
/* 4996 */     rowVal[1] = Integer.toString(-4).getBytes();
/*      */ 
/* 4999 */     rowVal[2] = s2b("255");
/* 5000 */     rowVal[3] = s2b("'");
/* 5001 */     rowVal[4] = s2b("'");
/* 5002 */     rowVal[5] = s2b("");
/* 5003 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5007 */     rowVal[7] = s2b("true");
/* 5008 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5012 */     rowVal[9] = s2b("false");
/* 5013 */     rowVal[10] = s2b("false");
/* 5014 */     rowVal[11] = s2b("false");
/* 5015 */     rowVal[12] = s2b("TINYBLOB");
/* 5016 */     rowVal[13] = s2b("0");
/* 5017 */     rowVal[14] = s2b("0");
/* 5018 */     rowVal[15] = s2b("0");
/* 5019 */     rowVal[16] = s2b("0");
/* 5020 */     rowVal[17] = s2b("10");
/* 5021 */     tuples.add(rowVal);
/*      */ 
/* 5027 */     rowVal = new byte[18][];
/* 5028 */     rowVal[0] = s2b("VARBINARY");
/* 5029 */     rowVal[1] = Integer.toString(-3).getBytes();
/*      */ 
/* 5032 */     rowVal[2] = s2b("255");
/* 5033 */     rowVal[3] = s2b("'");
/* 5034 */     rowVal[4] = s2b("'");
/* 5035 */     rowVal[5] = s2b("(M)");
/* 5036 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5040 */     rowVal[7] = s2b("true");
/* 5041 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5045 */     rowVal[9] = s2b("false");
/* 5046 */     rowVal[10] = s2b("false");
/* 5047 */     rowVal[11] = s2b("false");
/* 5048 */     rowVal[12] = s2b("VARBINARY");
/* 5049 */     rowVal[13] = s2b("0");
/* 5050 */     rowVal[14] = s2b("0");
/* 5051 */     rowVal[15] = s2b("0");
/* 5052 */     rowVal[16] = s2b("0");
/* 5053 */     rowVal[17] = s2b("10");
/* 5054 */     tuples.add(rowVal);
/*      */ 
/* 5060 */     rowVal = new byte[18][];
/* 5061 */     rowVal[0] = s2b("BINARY");
/* 5062 */     rowVal[1] = Integer.toString(-2).getBytes();
/*      */ 
/* 5065 */     rowVal[2] = s2b("255");
/* 5066 */     rowVal[3] = s2b("'");
/* 5067 */     rowVal[4] = s2b("'");
/* 5068 */     rowVal[5] = s2b("(M)");
/* 5069 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5073 */     rowVal[7] = s2b("true");
/* 5074 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5078 */     rowVal[9] = s2b("false");
/* 5079 */     rowVal[10] = s2b("false");
/* 5080 */     rowVal[11] = s2b("false");
/* 5081 */     rowVal[12] = s2b("BINARY");
/* 5082 */     rowVal[13] = s2b("0");
/* 5083 */     rowVal[14] = s2b("0");
/* 5084 */     rowVal[15] = s2b("0");
/* 5085 */     rowVal[16] = s2b("0");
/* 5086 */     rowVal[17] = s2b("10");
/* 5087 */     tuples.add(rowVal);
/*      */ 
/* 5092 */     rowVal = new byte[18][];
/* 5093 */     rowVal[0] = s2b("LONG VARCHAR");
/* 5094 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/* 5097 */     rowVal[2] = s2b("16777215");
/* 5098 */     rowVal[3] = s2b("'");
/* 5099 */     rowVal[4] = s2b("'");
/* 5100 */     rowVal[5] = s2b("");
/* 5101 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5105 */     rowVal[7] = s2b("false");
/* 5106 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5110 */     rowVal[9] = s2b("false");
/* 5111 */     rowVal[10] = s2b("false");
/* 5112 */     rowVal[11] = s2b("false");
/* 5113 */     rowVal[12] = s2b("LONG VARCHAR");
/* 5114 */     rowVal[13] = s2b("0");
/* 5115 */     rowVal[14] = s2b("0");
/* 5116 */     rowVal[15] = s2b("0");
/* 5117 */     rowVal[16] = s2b("0");
/* 5118 */     rowVal[17] = s2b("10");
/* 5119 */     tuples.add(rowVal);
/*      */ 
/* 5124 */     rowVal = new byte[18][];
/* 5125 */     rowVal[0] = s2b("MEDIUMTEXT");
/* 5126 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/* 5129 */     rowVal[2] = s2b("16777215");
/* 5130 */     rowVal[3] = s2b("'");
/* 5131 */     rowVal[4] = s2b("'");
/* 5132 */     rowVal[5] = s2b("");
/* 5133 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5137 */     rowVal[7] = s2b("false");
/* 5138 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5142 */     rowVal[9] = s2b("false");
/* 5143 */     rowVal[10] = s2b("false");
/* 5144 */     rowVal[11] = s2b("false");
/* 5145 */     rowVal[12] = s2b("MEDIUMTEXT");
/* 5146 */     rowVal[13] = s2b("0");
/* 5147 */     rowVal[14] = s2b("0");
/* 5148 */     rowVal[15] = s2b("0");
/* 5149 */     rowVal[16] = s2b("0");
/* 5150 */     rowVal[17] = s2b("10");
/* 5151 */     tuples.add(rowVal);
/*      */ 
/* 5156 */     rowVal = new byte[18][];
/* 5157 */     rowVal[0] = s2b("LONGTEXT");
/* 5158 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/* 5161 */     rowVal[2] = Integer.toString(2147483647).getBytes();
/*      */ 
/* 5164 */     rowVal[3] = s2b("'");
/* 5165 */     rowVal[4] = s2b("'");
/* 5166 */     rowVal[5] = s2b("");
/* 5167 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5171 */     rowVal[7] = s2b("false");
/* 5172 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5176 */     rowVal[9] = s2b("false");
/* 5177 */     rowVal[10] = s2b("false");
/* 5178 */     rowVal[11] = s2b("false");
/* 5179 */     rowVal[12] = s2b("LONGTEXT");
/* 5180 */     rowVal[13] = s2b("0");
/* 5181 */     rowVal[14] = s2b("0");
/* 5182 */     rowVal[15] = s2b("0");
/* 5183 */     rowVal[16] = s2b("0");
/* 5184 */     rowVal[17] = s2b("10");
/* 5185 */     tuples.add(rowVal);
/*      */ 
/* 5190 */     rowVal = new byte[18][];
/* 5191 */     rowVal[0] = s2b("TEXT");
/* 5192 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/* 5195 */     rowVal[2] = s2b("65535");
/* 5196 */     rowVal[3] = s2b("'");
/* 5197 */     rowVal[4] = s2b("'");
/* 5198 */     rowVal[5] = s2b("");
/* 5199 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5203 */     rowVal[7] = s2b("false");
/* 5204 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5208 */     rowVal[9] = s2b("false");
/* 5209 */     rowVal[10] = s2b("false");
/* 5210 */     rowVal[11] = s2b("false");
/* 5211 */     rowVal[12] = s2b("TEXT");
/* 5212 */     rowVal[13] = s2b("0");
/* 5213 */     rowVal[14] = s2b("0");
/* 5214 */     rowVal[15] = s2b("0");
/* 5215 */     rowVal[16] = s2b("0");
/* 5216 */     rowVal[17] = s2b("10");
/* 5217 */     tuples.add(rowVal);
/*      */ 
/* 5222 */     rowVal = new byte[18][];
/* 5223 */     rowVal[0] = s2b("TINYTEXT");
/* 5224 */     rowVal[1] = Integer.toString(-1).getBytes();
/*      */ 
/* 5227 */     rowVal[2] = s2b("255");
/* 5228 */     rowVal[3] = s2b("'");
/* 5229 */     rowVal[4] = s2b("'");
/* 5230 */     rowVal[5] = s2b("");
/* 5231 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5235 */     rowVal[7] = s2b("false");
/* 5236 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5240 */     rowVal[9] = s2b("false");
/* 5241 */     rowVal[10] = s2b("false");
/* 5242 */     rowVal[11] = s2b("false");
/* 5243 */     rowVal[12] = s2b("TINYTEXT");
/* 5244 */     rowVal[13] = s2b("0");
/* 5245 */     rowVal[14] = s2b("0");
/* 5246 */     rowVal[15] = s2b("0");
/* 5247 */     rowVal[16] = s2b("0");
/* 5248 */     rowVal[17] = s2b("10");
/* 5249 */     tuples.add(rowVal);
/*      */ 
/* 5254 */     rowVal = new byte[18][];
/* 5255 */     rowVal[0] = s2b("CHAR");
/* 5256 */     rowVal[1] = Integer.toString(1).getBytes();
/*      */ 
/* 5259 */     rowVal[2] = s2b("255");
/* 5260 */     rowVal[3] = s2b("'");
/* 5261 */     rowVal[4] = s2b("'");
/* 5262 */     rowVal[5] = s2b("(M)");
/* 5263 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5267 */     rowVal[7] = s2b("false");
/* 5268 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5272 */     rowVal[9] = s2b("false");
/* 5273 */     rowVal[10] = s2b("false");
/* 5274 */     rowVal[11] = s2b("false");
/* 5275 */     rowVal[12] = s2b("CHAR");
/* 5276 */     rowVal[13] = s2b("0");
/* 5277 */     rowVal[14] = s2b("0");
/* 5278 */     rowVal[15] = s2b("0");
/* 5279 */     rowVal[16] = s2b("0");
/* 5280 */     rowVal[17] = s2b("10");
/* 5281 */     tuples.add(rowVal);
/*      */ 
/* 5287 */     rowVal = new byte[18][];
/* 5288 */     rowVal[0] = s2b("NUMERIC");
/* 5289 */     rowVal[1] = Integer.toString(2).getBytes();
/*      */ 
/* 5292 */     rowVal[2] = s2b("17");
/* 5293 */     rowVal[3] = s2b("");
/* 5294 */     rowVal[4] = s2b("");
/* 5295 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5296 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5300 */     rowVal[7] = s2b("false");
/* 5301 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5305 */     rowVal[9] = s2b("false");
/* 5306 */     rowVal[10] = s2b("false");
/* 5307 */     rowVal[11] = s2b("true");
/* 5308 */     rowVal[12] = s2b("NUMERIC");
/* 5309 */     rowVal[13] = s2b("-308");
/* 5310 */     rowVal[14] = s2b("308");
/* 5311 */     rowVal[15] = s2b("0");
/* 5312 */     rowVal[16] = s2b("0");
/* 5313 */     rowVal[17] = s2b("10");
/* 5314 */     tuples.add(rowVal);
/*      */ 
/* 5319 */     rowVal = new byte[18][];
/* 5320 */     rowVal[0] = s2b("DECIMAL");
/* 5321 */     rowVal[1] = Integer.toString(3).getBytes();
/*      */ 
/* 5324 */     rowVal[2] = s2b("17");
/* 5325 */     rowVal[3] = s2b("");
/* 5326 */     rowVal[4] = s2b("");
/* 5327 */     rowVal[5] = s2b("[(M[,D])] [ZEROFILL]");
/* 5328 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5332 */     rowVal[7] = s2b("false");
/* 5333 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5337 */     rowVal[9] = s2b("false");
/* 5338 */     rowVal[10] = s2b("false");
/* 5339 */     rowVal[11] = s2b("true");
/* 5340 */     rowVal[12] = s2b("DECIMAL");
/* 5341 */     rowVal[13] = s2b("-308");
/* 5342 */     rowVal[14] = s2b("308");
/* 5343 */     rowVal[15] = s2b("0");
/* 5344 */     rowVal[16] = s2b("0");
/* 5345 */     rowVal[17] = s2b("10");
/* 5346 */     tuples.add(rowVal);
/*      */ 
/* 5351 */     rowVal = new byte[18][];
/* 5352 */     rowVal[0] = s2b("INTEGER");
/* 5353 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/* 5356 */     rowVal[2] = s2b("10");
/* 5357 */     rowVal[3] = s2b("");
/* 5358 */     rowVal[4] = s2b("");
/* 5359 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5360 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5364 */     rowVal[7] = s2b("false");
/* 5365 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5369 */     rowVal[9] = s2b("true");
/* 5370 */     rowVal[10] = s2b("false");
/* 5371 */     rowVal[11] = s2b("true");
/* 5372 */     rowVal[12] = s2b("INTEGER");
/* 5373 */     rowVal[13] = s2b("0");
/* 5374 */     rowVal[14] = s2b("0");
/* 5375 */     rowVal[15] = s2b("0");
/* 5376 */     rowVal[16] = s2b("0");
/* 5377 */     rowVal[17] = s2b("10");
/* 5378 */     tuples.add(rowVal);
/*      */ 
/* 5383 */     rowVal = new byte[18][];
/* 5384 */     rowVal[0] = s2b("INT");
/* 5385 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/* 5388 */     rowVal[2] = s2b("10");
/* 5389 */     rowVal[3] = s2b("");
/* 5390 */     rowVal[4] = s2b("");
/* 5391 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5392 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5396 */     rowVal[7] = s2b("false");
/* 5397 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5401 */     rowVal[9] = s2b("true");
/* 5402 */     rowVal[10] = s2b("false");
/* 5403 */     rowVal[11] = s2b("true");
/* 5404 */     rowVal[12] = s2b("INT");
/* 5405 */     rowVal[13] = s2b("0");
/* 5406 */     rowVal[14] = s2b("0");
/* 5407 */     rowVal[15] = s2b("0");
/* 5408 */     rowVal[16] = s2b("0");
/* 5409 */     rowVal[17] = s2b("10");
/* 5410 */     tuples.add(rowVal);
/*      */ 
/* 5415 */     rowVal = new byte[18][];
/* 5416 */     rowVal[0] = s2b("MEDIUMINT");
/* 5417 */     rowVal[1] = Integer.toString(4).getBytes();
/*      */ 
/* 5420 */     rowVal[2] = s2b("7");
/* 5421 */     rowVal[3] = s2b("");
/* 5422 */     rowVal[4] = s2b("");
/* 5423 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5424 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5428 */     rowVal[7] = s2b("false");
/* 5429 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5433 */     rowVal[9] = s2b("true");
/* 5434 */     rowVal[10] = s2b("false");
/* 5435 */     rowVal[11] = s2b("true");
/* 5436 */     rowVal[12] = s2b("MEDIUMINT");
/* 5437 */     rowVal[13] = s2b("0");
/* 5438 */     rowVal[14] = s2b("0");
/* 5439 */     rowVal[15] = s2b("0");
/* 5440 */     rowVal[16] = s2b("0");
/* 5441 */     rowVal[17] = s2b("10");
/* 5442 */     tuples.add(rowVal);
/*      */ 
/* 5447 */     rowVal = new byte[18][];
/* 5448 */     rowVal[0] = s2b("SMALLINT");
/* 5449 */     rowVal[1] = Integer.toString(5).getBytes();
/*      */ 
/* 5452 */     rowVal[2] = s2b("5");
/* 5453 */     rowVal[3] = s2b("");
/* 5454 */     rowVal[4] = s2b("");
/* 5455 */     rowVal[5] = s2b("[(M)] [UNSIGNED] [ZEROFILL]");
/* 5456 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5460 */     rowVal[7] = s2b("false");
/* 5461 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5465 */     rowVal[9] = s2b("true");
/* 5466 */     rowVal[10] = s2b("false");
/* 5467 */     rowVal[11] = s2b("true");
/* 5468 */     rowVal[12] = s2b("SMALLINT");
/* 5469 */     rowVal[13] = s2b("0");
/* 5470 */     rowVal[14] = s2b("0");
/* 5471 */     rowVal[15] = s2b("0");
/* 5472 */     rowVal[16] = s2b("0");
/* 5473 */     rowVal[17] = s2b("10");
/* 5474 */     tuples.add(rowVal);
/*      */ 
/* 5480 */     rowVal = new byte[18][];
/* 5481 */     rowVal[0] = s2b("FLOAT");
/* 5482 */     rowVal[1] = Integer.toString(7).getBytes();
/*      */ 
/* 5485 */     rowVal[2] = s2b("10");
/* 5486 */     rowVal[3] = s2b("");
/* 5487 */     rowVal[4] = s2b("");
/* 5488 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5489 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5493 */     rowVal[7] = s2b("false");
/* 5494 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5498 */     rowVal[9] = s2b("false");
/* 5499 */     rowVal[10] = s2b("false");
/* 5500 */     rowVal[11] = s2b("true");
/* 5501 */     rowVal[12] = s2b("FLOAT");
/* 5502 */     rowVal[13] = s2b("-38");
/* 5503 */     rowVal[14] = s2b("38");
/* 5504 */     rowVal[15] = s2b("0");
/* 5505 */     rowVal[16] = s2b("0");
/* 5506 */     rowVal[17] = s2b("10");
/* 5507 */     tuples.add(rowVal);
/*      */ 
/* 5512 */     rowVal = new byte[18][];
/* 5513 */     rowVal[0] = s2b("DOUBLE");
/* 5514 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/* 5517 */     rowVal[2] = s2b("17");
/* 5518 */     rowVal[3] = s2b("");
/* 5519 */     rowVal[4] = s2b("");
/* 5520 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5521 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5525 */     rowVal[7] = s2b("false");
/* 5526 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5530 */     rowVal[9] = s2b("false");
/* 5531 */     rowVal[10] = s2b("false");
/* 5532 */     rowVal[11] = s2b("true");
/* 5533 */     rowVal[12] = s2b("DOUBLE");
/* 5534 */     rowVal[13] = s2b("-308");
/* 5535 */     rowVal[14] = s2b("308");
/* 5536 */     rowVal[15] = s2b("0");
/* 5537 */     rowVal[16] = s2b("0");
/* 5538 */     rowVal[17] = s2b("10");
/* 5539 */     tuples.add(rowVal);
/*      */ 
/* 5544 */     rowVal = new byte[18][];
/* 5545 */     rowVal[0] = s2b("DOUBLE PRECISION");
/* 5546 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/* 5549 */     rowVal[2] = s2b("17");
/* 5550 */     rowVal[3] = s2b("");
/* 5551 */     rowVal[4] = s2b("");
/* 5552 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5553 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5557 */     rowVal[7] = s2b("false");
/* 5558 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5562 */     rowVal[9] = s2b("false");
/* 5563 */     rowVal[10] = s2b("false");
/* 5564 */     rowVal[11] = s2b("true");
/* 5565 */     rowVal[12] = s2b("DOUBLE PRECISION");
/* 5566 */     rowVal[13] = s2b("-308");
/* 5567 */     rowVal[14] = s2b("308");
/* 5568 */     rowVal[15] = s2b("0");
/* 5569 */     rowVal[16] = s2b("0");
/* 5570 */     rowVal[17] = s2b("10");
/* 5571 */     tuples.add(rowVal);
/*      */ 
/* 5576 */     rowVal = new byte[18][];
/* 5577 */     rowVal[0] = s2b("REAL");
/* 5578 */     rowVal[1] = Integer.toString(8).getBytes();
/*      */ 
/* 5581 */     rowVal[2] = s2b("17");
/* 5582 */     rowVal[3] = s2b("");
/* 5583 */     rowVal[4] = s2b("");
/* 5584 */     rowVal[5] = s2b("[(M,D)] [ZEROFILL]");
/* 5585 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5589 */     rowVal[7] = s2b("false");
/* 5590 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5594 */     rowVal[9] = s2b("false");
/* 5595 */     rowVal[10] = s2b("false");
/* 5596 */     rowVal[11] = s2b("true");
/* 5597 */     rowVal[12] = s2b("REAL");
/* 5598 */     rowVal[13] = s2b("-308");
/* 5599 */     rowVal[14] = s2b("308");
/* 5600 */     rowVal[15] = s2b("0");
/* 5601 */     rowVal[16] = s2b("0");
/* 5602 */     rowVal[17] = s2b("10");
/* 5603 */     tuples.add(rowVal);
/*      */ 
/* 5608 */     rowVal = new byte[18][];
/* 5609 */     rowVal[0] = s2b("VARCHAR");
/* 5610 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/* 5613 */     rowVal[2] = s2b("255");
/* 5614 */     rowVal[3] = s2b("'");
/* 5615 */     rowVal[4] = s2b("'");
/* 5616 */     rowVal[5] = s2b("(M)");
/* 5617 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5621 */     rowVal[7] = s2b("false");
/* 5622 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5626 */     rowVal[9] = s2b("false");
/* 5627 */     rowVal[10] = s2b("false");
/* 5628 */     rowVal[11] = s2b("false");
/* 5629 */     rowVal[12] = s2b("VARCHAR");
/* 5630 */     rowVal[13] = s2b("0");
/* 5631 */     rowVal[14] = s2b("0");
/* 5632 */     rowVal[15] = s2b("0");
/* 5633 */     rowVal[16] = s2b("0");
/* 5634 */     rowVal[17] = s2b("10");
/* 5635 */     tuples.add(rowVal);
/*      */ 
/* 5640 */     rowVal = new byte[18][];
/* 5641 */     rowVal[0] = s2b("ENUM");
/* 5642 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/* 5645 */     rowVal[2] = s2b("65535");
/* 5646 */     rowVal[3] = s2b("'");
/* 5647 */     rowVal[4] = s2b("'");
/* 5648 */     rowVal[5] = s2b("");
/* 5649 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5653 */     rowVal[7] = s2b("false");
/* 5654 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5658 */     rowVal[9] = s2b("false");
/* 5659 */     rowVal[10] = s2b("false");
/* 5660 */     rowVal[11] = s2b("false");
/* 5661 */     rowVal[12] = s2b("ENUM");
/* 5662 */     rowVal[13] = s2b("0");
/* 5663 */     rowVal[14] = s2b("0");
/* 5664 */     rowVal[15] = s2b("0");
/* 5665 */     rowVal[16] = s2b("0");
/* 5666 */     rowVal[17] = s2b("10");
/* 5667 */     tuples.add(rowVal);
/*      */ 
/* 5672 */     rowVal = new byte[18][];
/* 5673 */     rowVal[0] = s2b("SET");
/* 5674 */     rowVal[1] = Integer.toString(12).getBytes();
/*      */ 
/* 5677 */     rowVal[2] = s2b("64");
/* 5678 */     rowVal[3] = s2b("'");
/* 5679 */     rowVal[4] = s2b("'");
/* 5680 */     rowVal[5] = s2b("");
/* 5681 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5685 */     rowVal[7] = s2b("false");
/* 5686 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5690 */     rowVal[9] = s2b("false");
/* 5691 */     rowVal[10] = s2b("false");
/* 5692 */     rowVal[11] = s2b("false");
/* 5693 */     rowVal[12] = s2b("SET");
/* 5694 */     rowVal[13] = s2b("0");
/* 5695 */     rowVal[14] = s2b("0");
/* 5696 */     rowVal[15] = s2b("0");
/* 5697 */     rowVal[16] = s2b("0");
/* 5698 */     rowVal[17] = s2b("10");
/* 5699 */     tuples.add(rowVal);
/*      */ 
/* 5704 */     rowVal = new byte[18][];
/* 5705 */     rowVal[0] = s2b("DATE");
/* 5706 */     rowVal[1] = Integer.toString(91).getBytes();
/*      */ 
/* 5709 */     rowVal[2] = s2b("0");
/* 5710 */     rowVal[3] = s2b("'");
/* 5711 */     rowVal[4] = s2b("'");
/* 5712 */     rowVal[5] = s2b("");
/* 5713 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5717 */     rowVal[7] = s2b("false");
/* 5718 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5722 */     rowVal[9] = s2b("false");
/* 5723 */     rowVal[10] = s2b("false");
/* 5724 */     rowVal[11] = s2b("false");
/* 5725 */     rowVal[12] = s2b("DATE");
/* 5726 */     rowVal[13] = s2b("0");
/* 5727 */     rowVal[14] = s2b("0");
/* 5728 */     rowVal[15] = s2b("0");
/* 5729 */     rowVal[16] = s2b("0");
/* 5730 */     rowVal[17] = s2b("10");
/* 5731 */     tuples.add(rowVal);
/*      */ 
/* 5736 */     rowVal = new byte[18][];
/* 5737 */     rowVal[0] = s2b("TIME");
/* 5738 */     rowVal[1] = Integer.toString(92).getBytes();
/*      */ 
/* 5741 */     rowVal[2] = s2b("0");
/* 5742 */     rowVal[3] = s2b("'");
/* 5743 */     rowVal[4] = s2b("'");
/* 5744 */     rowVal[5] = s2b("");
/* 5745 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5749 */     rowVal[7] = s2b("false");
/* 5750 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5754 */     rowVal[9] = s2b("false");
/* 5755 */     rowVal[10] = s2b("false");
/* 5756 */     rowVal[11] = s2b("false");
/* 5757 */     rowVal[12] = s2b("TIME");
/* 5758 */     rowVal[13] = s2b("0");
/* 5759 */     rowVal[14] = s2b("0");
/* 5760 */     rowVal[15] = s2b("0");
/* 5761 */     rowVal[16] = s2b("0");
/* 5762 */     rowVal[17] = s2b("10");
/* 5763 */     tuples.add(rowVal);
/*      */ 
/* 5768 */     rowVal = new byte[18][];
/* 5769 */     rowVal[0] = s2b("DATETIME");
/* 5770 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */ 
/* 5773 */     rowVal[2] = s2b("0");
/* 5774 */     rowVal[3] = s2b("'");
/* 5775 */     rowVal[4] = s2b("'");
/* 5776 */     rowVal[5] = s2b("");
/* 5777 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5781 */     rowVal[7] = s2b("false");
/* 5782 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5786 */     rowVal[9] = s2b("false");
/* 5787 */     rowVal[10] = s2b("false");
/* 5788 */     rowVal[11] = s2b("false");
/* 5789 */     rowVal[12] = s2b("DATETIME");
/* 5790 */     rowVal[13] = s2b("0");
/* 5791 */     rowVal[14] = s2b("0");
/* 5792 */     rowVal[15] = s2b("0");
/* 5793 */     rowVal[16] = s2b("0");
/* 5794 */     rowVal[17] = s2b("10");
/* 5795 */     tuples.add(rowVal);
/*      */ 
/* 5800 */     rowVal = new byte[18][];
/* 5801 */     rowVal[0] = s2b("TIMESTAMP");
/* 5802 */     rowVal[1] = Integer.toString(93).getBytes();
/*      */ 
/* 5805 */     rowVal[2] = s2b("0");
/* 5806 */     rowVal[3] = s2b("'");
/* 5807 */     rowVal[4] = s2b("'");
/* 5808 */     rowVal[5] = s2b("[(M)]");
/* 5809 */     rowVal[6] = Integer.toString(1).getBytes();
/*      */ 
/* 5813 */     rowVal[7] = s2b("false");
/* 5814 */     rowVal[8] = Integer.toString(3).getBytes();
/*      */ 
/* 5818 */     rowVal[9] = s2b("false");
/* 5819 */     rowVal[10] = s2b("false");
/* 5820 */     rowVal[11] = s2b("false");
/* 5821 */     rowVal[12] = s2b("TIMESTAMP");
/* 5822 */     rowVal[13] = s2b("0");
/* 5823 */     rowVal[14] = s2b("0");
/* 5824 */     rowVal[15] = s2b("0");
/* 5825 */     rowVal[16] = s2b("0");
/* 5826 */     rowVal[17] = s2b("10");
/* 5827 */     tuples.add(rowVal);
/*      */ 
/* 5829 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types)
/*      */     throws SQLException
/*      */   {
/* 5875 */     Field[] fields = new Field[6];
/* 5876 */     fields[0] = new Field("", "TYPE_CAT", 12, 32);
/* 5877 */     fields[1] = new Field("", "TYPE_SCHEM", 12, 32);
/* 5878 */     fields[2] = new Field("", "TYPE_NAME", 12, 32);
/* 5879 */     fields[3] = new Field("", "CLASS_NAME", 12, 32);
/* 5880 */     fields[4] = new Field("", "DATA_TYPE", 12, 32);
/* 5881 */     fields[5] = new Field("", "REMARKS", 12, 32);
/*      */ 
/* 5883 */     ArrayList tuples = new ArrayList();
/*      */ 
/* 5885 */     return buildResultSet(fields, tuples);
/*      */   }
/*      */ 
/*      */   public String getURL()
/*      */     throws SQLException
/*      */   {
/* 5896 */     return this.conn.getURL();
/*      */   }
/*      */ 
/*      */   public String getUserName()
/*      */     throws SQLException
/*      */   {
/* 5907 */     if (this.conn.getUseHostsInPrivileges()) {
/* 5908 */       Statement stmt = null;
/* 5909 */       java.sql.ResultSet rs = null;
/*      */       try
/*      */       {
/* 5912 */         stmt = this.conn.createStatement();
/* 5913 */         stmt.setEscapeProcessing(false);
/*      */ 
/* 5915 */         rs = stmt.executeQuery("SELECT USER()");
/* 5916 */         rs.next();
/*      */ 
/* 5918 */         str = rs.getString(1);
/*      */       }
/*      */       finally
/*      */       {
/*      */         String str;
/* 5920 */         if (rs != null) {
/*      */           try {
/* 5922 */             rs.close();
/*      */           } catch (Exception ex) {
/* 5924 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */ 
/* 5927 */           rs = null;
/*      */         }
/*      */ 
/* 5930 */         if (stmt != null) {
/*      */           try {
/* 5932 */             stmt.close();
/*      */           } catch (Exception ex) {
/* 5934 */             AssertionFailedException.shouldNotHappen(ex);
/*      */           }
/*      */ 
/* 5937 */           stmt = null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 5942 */     return this.conn.getUser();
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getVersionColumns(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/* 5981 */     Field[] fields = new Field[8];
/* 5982 */     fields[0] = new Field("", "SCOPE", 5, 5);
/* 5983 */     fields[1] = new Field("", "COLUMN_NAME", 1, 32);
/* 5984 */     fields[2] = new Field("", "DATA_TYPE", 5, 5);
/* 5985 */     fields[3] = new Field("", "TYPE_NAME", 1, 16);
/* 5986 */     fields[4] = new Field("", "COLUMN_SIZE", 1, 16);
/* 5987 */     fields[5] = new Field("", "BUFFER_LENGTH", 1, 16);
/* 5988 */     fields[6] = new Field("", "DECIMAL_DIGITS", 1, 16);
/* 5989 */     fields[7] = new Field("", "PSEUDO_COLUMN", 5, 5);
/*      */ 
/* 5991 */     return buildResultSet(fields, new ArrayList());
/*      */   }
/*      */ 
/*      */   public boolean insertsAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 6007 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isCatalogAtStart()
/*      */     throws SQLException
/*      */   {
/* 6019 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean isReadOnly()
/*      */     throws SQLException
/*      */   {
/* 6030 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean locatorsUpdateCopy()
/*      */     throws SQLException
/*      */   {
/* 6037 */     return !this.conn.getEmulateLocators();
/*      */   }
/*      */ 
/*      */   public boolean nullPlusNonNullIsNull()
/*      */     throws SQLException
/*      */   {
/* 6049 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedAtEnd()
/*      */     throws SQLException
/*      */   {
/* 6060 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedAtStart()
/*      */     throws SQLException
/*      */   {
/* 6071 */     return (this.conn.versionMeetsMinimum(4, 0, 2)) && (!this.conn.versionMeetsMinimum(4, 0, 11));
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedHigh()
/*      */     throws SQLException
/*      */   {
/* 6083 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean nullsAreSortedLow()
/*      */     throws SQLException
/*      */   {
/* 6094 */     return !nullsAreSortedHigh();
/*      */   }
/*      */ 
/*      */   public boolean othersDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6107 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean othersInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6120 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean othersUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6133 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ownDeletesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6146 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ownInsertsAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6159 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean ownUpdatesAreVisible(int type)
/*      */     throws SQLException
/*      */   {
/* 6172 */     return false;
/*      */   }
/*      */ 
/*      */   private DatabaseMetaData.LocalAndReferencedColumns parseTableStatusIntoLocalAndReferencedColumns(String keysComment)
/*      */     throws SQLException
/*      */   {
/* 6193 */     String columnsDelimitter = ",";
/*      */ 
/* 6195 */     char quoteChar = this.quotedId.length() == 0 ? '\000' : this.quotedId.charAt(0);
/*      */ 
/* 6198 */     int indexOfOpenParenLocalColumns = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysComment, "(", quoteChar, true);
/*      */ 
/* 6202 */     if (indexOfOpenParenLocalColumns == -1) {
/* 6203 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of local columns list.", "S1000");
/*      */     }
/*      */ 
/* 6208 */     String constraintName = removeQuotedId(keysComment.substring(0, indexOfOpenParenLocalColumns).trim());
/*      */ 
/* 6210 */     keysComment = keysComment.substring(indexOfOpenParenLocalColumns, keysComment.length());
/*      */ 
/* 6213 */     String keysCommentTrimmed = keysComment.trim();
/*      */ 
/* 6215 */     int indexOfCloseParenLocalColumns = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysCommentTrimmed, ")", quoteChar, true);
/*      */ 
/* 6219 */     if (indexOfCloseParenLocalColumns == -1) {
/* 6220 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of local columns list.", "S1000");
/*      */     }
/*      */ 
/* 6225 */     String localColumnNamesString = keysCommentTrimmed.substring(1, indexOfCloseParenLocalColumns);
/*      */ 
/* 6228 */     int indexOfRefer = StringUtils.indexOfIgnoreCaseRespectQuotes(0, keysCommentTrimmed, "REFER ", this.quotedId.charAt(0), true);
/*      */ 
/* 6231 */     if (indexOfRefer == -1) {
/* 6232 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced tables list.", "S1000");
/*      */     }
/*      */ 
/* 6237 */     int indexOfOpenParenReferCol = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfRefer, keysCommentTrimmed, "(", quoteChar, false);
/*      */ 
/* 6241 */     if (indexOfOpenParenReferCol == -1) {
/* 6242 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find start of referenced columns list.", "S1000");
/*      */     }
/*      */ 
/* 6247 */     String referCatalogTableString = keysCommentTrimmed.substring(indexOfRefer + "REFER ".length(), indexOfOpenParenReferCol);
/*      */ 
/* 6250 */     int indexOfSlash = StringUtils.indexOfIgnoreCaseRespectQuotes(0, referCatalogTableString, "/", this.quotedId.charAt(0), false);
/*      */ 
/* 6253 */     if (indexOfSlash == -1) {
/* 6254 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find name of referenced catalog.", "S1000");
/*      */     }
/*      */ 
/* 6259 */     String referCatalog = removeQuotedId(referCatalogTableString.substring(0, indexOfSlash));
/*      */ 
/* 6261 */     String referTable = removeQuotedId(referCatalogTableString.substring(indexOfSlash + 1).trim());
/*      */ 
/* 6264 */     int indexOfCloseParenRefer = StringUtils.indexOfIgnoreCaseRespectQuotes(indexOfOpenParenReferCol, keysCommentTrimmed, ")", quoteChar, true);
/*      */ 
/* 6268 */     if (indexOfCloseParenRefer == -1) {
/* 6269 */       throw SQLError.createSQLException("Error parsing foreign keys definition, couldn't find end of referenced columns list.", "S1000");
/*      */     }
/*      */ 
/* 6274 */     String referColumnNamesString = keysCommentTrimmed.substring(indexOfOpenParenReferCol + 1, indexOfCloseParenRefer);
/*      */ 
/* 6277 */     List referColumnsList = StringUtils.split(referColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */ 
/* 6279 */     List localColumnsList = StringUtils.split(localColumnNamesString, columnsDelimitter, this.quotedId, this.quotedId, false);
/*      */ 
/* 6282 */     return new DatabaseMetaData.LocalAndReferencedColumns(this, localColumnsList, referColumnsList, constraintName, referCatalog, referTable);
/*      */   }
/*      */ 
/*      */   private String removeQuotedId(String s)
/*      */   {
/* 6287 */     if (s == null) {
/* 6288 */       return null;
/*      */     }
/*      */ 
/* 6291 */     if (this.quotedId.equals("")) {
/* 6292 */       return s;
/*      */     }
/*      */ 
/* 6295 */     s = s.trim();
/*      */ 
/* 6297 */     int frontOffset = 0;
/* 6298 */     int backOffset = s.length();
/* 6299 */     int quoteLength = this.quotedId.length();
/*      */ 
/* 6301 */     if (s.startsWith(this.quotedId)) {
/* 6302 */       frontOffset = quoteLength;
/*      */     }
/*      */ 
/* 6305 */     if (s.endsWith(this.quotedId)) {
/* 6306 */       backOffset -= quoteLength;
/*      */     }
/*      */ 
/* 6309 */     return s.substring(frontOffset, backOffset);
/*      */   }
/*      */ 
/*      */   private byte[] s2b(String s)
/*      */     throws SQLException
/*      */   {
/* 6321 */     return StringUtils.s2b(s, this.conn);
/*      */   }
/*      */ 
/*      */   public boolean storesLowerCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6334 */     return this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean storesLowerCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6346 */     return this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean storesMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6358 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean storesMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6370 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean storesUpperCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6382 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean storesUpperCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6394 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsAlterTableWithAddColumn()
/*      */     throws SQLException
/*      */   {
/* 6405 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsAlterTableWithDropColumn()
/*      */     throws SQLException
/*      */   {
/* 6416 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92EntryLevelSQL()
/*      */     throws SQLException
/*      */   {
/* 6428 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92FullSQL()
/*      */     throws SQLException
/*      */   {
/* 6439 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsANSI92IntermediateSQL()
/*      */     throws SQLException
/*      */   {
/* 6450 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsBatchUpdates()
/*      */     throws SQLException
/*      */   {
/* 6462 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 6474 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6486 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6498 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 6510 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsCatalogsInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 6522 */     return this.conn.versionMeetsMinimum(3, 22, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsColumnAliasing()
/*      */     throws SQLException
/*      */   {
/* 6538 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsConvert()
/*      */     throws SQLException
/*      */   {
/* 6549 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsConvert(int fromType, int toType)
/*      */     throws SQLException
/*      */   {
/* 6566 */     switch (fromType)
/*      */     {
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/*      */     case -1:
/*      */     case 1:
/*      */     case 12:
/* 6577 */       switch (toType) {
/*      */       case -6:
/*      */       case -5:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 12:
/*      */       case 91:
/*      */       case 92:
/*      */       case 93:
/*      */       case 1111:
/* 6597 */         return true;
/*      */       }
/*      */ 
/* 6600 */       return false;
/*      */     case -7:
/* 6607 */       return false;
/*      */     case -6:
/*      */     case -5:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/* 6623 */       switch (toType) {
/*      */       case -6:
/*      */       case -5:
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 12:
/* 6639 */         return true;
/*      */       case 0:
/*      */       case 9:
/*      */       case 10:
/* 6642 */       case 11: } return false;
/*      */     case 0:
/* 6647 */       return false;
/*      */     case 1111:
/* 6655 */       switch (toType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 6662 */         return true;
/*      */       case 0:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/* 6665 */       case 11: } return false;
/*      */     case 91:
/* 6671 */       switch (toType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 6678 */         return true;
/*      */       case 0:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/* 6681 */       case 11: } return false;
/*      */     case 92:
/* 6687 */       switch (toType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/* 6694 */         return true;
/*      */       case 0:
/*      */       case 2:
/*      */       case 3:
/*      */       case 4:
/*      */       case 5:
/*      */       case 6:
/*      */       case 7:
/*      */       case 8:
/*      */       case 9:
/*      */       case 10:
/* 6697 */       case 11: } return false;
/*      */     case 93:
/* 6706 */       switch (toType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case -1:
/*      */       case 1:
/*      */       case 12:
/*      */       case 91:
/*      */       case 92:
/* 6715 */         return true;
/*      */       }
/*      */ 
/* 6718 */       return false;
/*      */     }
/*      */ 
/* 6723 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsCoreSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 6735 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsCorrelatedSubqueries()
/*      */     throws SQLException
/*      */   {
/* 6747 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsDataDefinitionAndDataManipulationTransactions()
/*      */     throws SQLException
/*      */   {
/* 6760 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsDataManipulationTransactionsOnly()
/*      */     throws SQLException
/*      */   {
/* 6772 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsDifferentTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 6785 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsExpressionsInOrderBy()
/*      */     throws SQLException
/*      */   {
/* 6796 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsExtendedSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 6807 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsFullOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 6818 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsGetGeneratedKeys()
/*      */   {
/* 6827 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupBy()
/*      */     throws SQLException
/*      */   {
/* 6838 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupByBeyondSelect()
/*      */     throws SQLException
/*      */   {
/* 6850 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsGroupByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 6861 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsIntegrityEnhancementFacility()
/*      */     throws SQLException
/*      */   {
/* 6873 */     return this.conn.getOverrideSupportsIntegrityEnhancementFacility();
/*      */   }
/*      */ 
/*      */   public boolean supportsLikeEscapeClause()
/*      */     throws SQLException
/*      */   {
/* 6888 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsLimitedOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 6900 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMinimumSQLGrammar()
/*      */     throws SQLException
/*      */   {
/* 6912 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMixedCaseIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6923 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean supportsMixedCaseQuotedIdentifiers()
/*      */     throws SQLException
/*      */   {
/* 6935 */     return !this.conn.lowerCaseTableNames();
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleOpenResults()
/*      */     throws SQLException
/*      */   {
/* 6942 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleResultSets()
/*      */     throws SQLException
/*      */   {
/* 6953 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsMultipleTransactions()
/*      */     throws SQLException
/*      */   {
/* 6965 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsNamedParameters()
/*      */     throws SQLException
/*      */   {
/* 6972 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsNonNullableColumns()
/*      */     throws SQLException
/*      */   {
/* 6984 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 6996 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenCursorsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7008 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossCommit()
/*      */     throws SQLException
/*      */   {
/* 7020 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOpenStatementsAcrossRollback()
/*      */     throws SQLException
/*      */   {
/* 7032 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOrderByUnrelated()
/*      */     throws SQLException
/*      */   {
/* 7043 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsOuterJoins()
/*      */     throws SQLException
/*      */   {
/* 7054 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsPositionedDelete()
/*      */     throws SQLException
/*      */   {
/* 7065 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsPositionedUpdate()
/*      */     throws SQLException
/*      */   {
/* 7076 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetConcurrency(int type, int concurrency)
/*      */     throws SQLException
/*      */   {
/* 7094 */     switch (type) {
/*      */     case 1004:
/* 7096 */       if ((concurrency == 1007) || (concurrency == 1008))
/*      */       {
/* 7098 */         return true;
/*      */       }
/* 7100 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009");
/*      */     case 1003:
/* 7105 */       if ((concurrency == 1007) || (concurrency == 1008))
/*      */       {
/* 7107 */         return true;
/*      */       }
/* 7109 */       throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009");
/*      */     case 1005:
/* 7114 */       return false;
/*      */     }
/* 7116 */     throw SQLError.createSQLException("Illegal arguments to supportsResultSetConcurrency()", "S1009");
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetHoldability(int holdability)
/*      */     throws SQLException
/*      */   {
/* 7128 */     return holdability == 1;
/*      */   }
/*      */ 
/*      */   public boolean supportsResultSetType(int type)
/*      */     throws SQLException
/*      */   {
/* 7142 */     return type == 1004;
/*      */   }
/*      */ 
/*      */   public boolean supportsSavepoints()
/*      */     throws SQLException
/*      */   {
/* 7150 */     return (this.conn.versionMeetsMinimum(4, 0, 14)) || (this.conn.versionMeetsMinimum(4, 1, 1));
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInDataManipulation()
/*      */     throws SQLException
/*      */   {
/* 7162 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInIndexDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7173 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInPrivilegeDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7184 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInProcedureCalls()
/*      */     throws SQLException
/*      */   {
/* 7195 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsSchemasInTableDefinitions()
/*      */     throws SQLException
/*      */   {
/* 7206 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsSelectForUpdate()
/*      */     throws SQLException
/*      */   {
/* 7217 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsStatementPooling()
/*      */     throws SQLException
/*      */   {
/* 7224 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsStoredProcedures()
/*      */     throws SQLException
/*      */   {
/* 7236 */     return this.conn.versionMeetsMinimum(5, 0, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInComparisons()
/*      */     throws SQLException
/*      */   {
/* 7248 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInExists()
/*      */     throws SQLException
/*      */   {
/* 7260 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInIns()
/*      */     throws SQLException
/*      */   {
/* 7272 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsSubqueriesInQuantifieds()
/*      */     throws SQLException
/*      */   {
/* 7284 */     return this.conn.versionMeetsMinimum(4, 1, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsTableCorrelationNames()
/*      */     throws SQLException
/*      */   {
/* 7296 */     return true;
/*      */   }
/*      */ 
/*      */   public boolean supportsTransactionIsolationLevel(int level)
/*      */     throws SQLException
/*      */   {
/* 7311 */     if (this.conn.supportsIsolationLevel()) {
/* 7312 */       switch (level) {
/*      */       case 1:
/*      */       case 2:
/*      */       case 4:
/*      */       case 8:
/* 7317 */         return true;
/*      */       case 3:
/*      */       case 5:
/*      */       case 6:
/* 7320 */       case 7: } return false;
/*      */     }
/*      */ 
/* 7324 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean supportsTransactions()
/*      */     throws SQLException
/*      */   {
/* 7336 */     return this.conn.supportsTransactions();
/*      */   }
/*      */ 
/*      */   public boolean supportsUnion()
/*      */     throws SQLException
/*      */   {
/* 7347 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */   public boolean supportsUnionAll()
/*      */     throws SQLException
/*      */   {
/* 7358 */     return this.conn.versionMeetsMinimum(4, 0, 0);
/*      */   }
/*      */ 
/*      */   public boolean updatesAreDetected(int type)
/*      */     throws SQLException
/*      */   {
/* 7372 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean usesLocalFilePerTable()
/*      */     throws SQLException
/*      */   {
/* 7383 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean usesLocalFiles()
/*      */     throws SQLException
/*      */   {
/* 7394 */     return false;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData
 * JD-Core Version:    0.6.0
 */