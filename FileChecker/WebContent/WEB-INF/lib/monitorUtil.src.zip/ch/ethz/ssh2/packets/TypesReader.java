/*     */ package ch.ethz.ssh2.packets;
/*     */ 
/*     */ import ch.ethz.ssh2.util.Tokenizer;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class TypesReader
/*     */ {
/*     */   byte[] arr;
/*  18 */   int pos = 0;
/*  19 */   int max = 0;
/*     */ 
/*     */   public TypesReader(byte[] arr)
/*     */   {
/*  23 */     this.arr = arr;
/*  24 */     this.pos = 0;
/*  25 */     this.max = arr.length;
/*     */   }
/*     */ 
/*     */   public TypesReader(byte[] arr, int off)
/*     */   {
/*  30 */     this.arr = arr;
/*  31 */     this.pos = off;
/*  32 */     this.max = arr.length;
/*     */ 
/*  34 */     if ((this.pos < 0) || (this.pos > arr.length))
/*  35 */       throw new IllegalArgumentException("Illegal offset.");
/*     */   }
/*     */ 
/*     */   public TypesReader(byte[] arr, int off, int len)
/*     */   {
/*  40 */     this.arr = arr;
/*  41 */     this.pos = off;
/*  42 */     this.max = (off + len);
/*     */ 
/*  44 */     if ((this.pos < 0) || (this.pos > arr.length)) {
/*  45 */       throw new IllegalArgumentException("Illegal offset.");
/*     */     }
/*  47 */     if ((this.max < 0) || (this.max > arr.length))
/*  48 */       throw new IllegalArgumentException("Illegal length.");
/*     */   }
/*     */ 
/*     */   public int readByte() throws IOException
/*     */   {
/*  53 */     if (this.pos >= this.max) {
/*  54 */       throw new IOException("Packet too short.");
/*     */     }
/*  56 */     return this.arr[(this.pos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public byte[] readBytes(int len) throws IOException
/*     */   {
/*  61 */     if (this.pos + len > this.max) {
/*  62 */       throw new IOException("Packet too short.");
/*     */     }
/*  64 */     byte[] res = new byte[len];
/*     */ 
/*  66 */     System.arraycopy(this.arr, this.pos, res, 0, len);
/*  67 */     this.pos += len;
/*     */ 
/*  69 */     return res;
/*     */   }
/*     */ 
/*     */   public void readBytes(byte[] dst, int off, int len) throws IOException
/*     */   {
/*  74 */     if (this.pos + len > this.max) {
/*  75 */       throw new IOException("Packet too short.");
/*     */     }
/*  77 */     System.arraycopy(this.arr, this.pos, dst, off, len);
/*  78 */     this.pos += len;
/*     */   }
/*     */ 
/*     */   public boolean readBoolean() throws IOException
/*     */   {
/*  83 */     if (this.pos >= this.max) {
/*  84 */       throw new IOException("Packet too short.");
/*     */     }
/*  86 */     return this.arr[(this.pos++)] != 0;
/*     */   }
/*     */ 
/*     */   public int readUINT32() throws IOException
/*     */   {
/*  91 */     if (this.pos + 4 > this.max) {
/*  92 */       throw new IOException("Packet too short.");
/*     */     }
/*  94 */     return (this.arr[(this.pos++)] & 0xFF) << 24 | (this.arr[(this.pos++)] & 0xFF) << 16 | (this.arr[(this.pos++)] & 0xFF) << 8 | 
/*  95 */       this.arr[(this.pos++)] & 0xFF;
/*     */   }
/*     */ 
/*     */   public long readUINT64() throws IOException
/*     */   {
/* 100 */     if (this.pos + 8 > this.max) {
/* 101 */       throw new IOException("Packet too short.");
/*     */     }
/* 103 */     long high = (this.arr[(this.pos++)] & 0xFF) << 24 | (this.arr[(this.pos++)] & 0xFF) << 16 | (this.arr[(this.pos++)] & 0xFF) << 8 | 
/* 104 */       this.arr[(this.pos++)] & 0xFF;
/*     */ 
/* 106 */     long low = (this.arr[(this.pos++)] & 0xFF) << 24 | (this.arr[(this.pos++)] & 0xFF) << 16 | (this.arr[(this.pos++)] & 0xFF) << 8 | 
/* 107 */       this.arr[(this.pos++)] & 0xFF;
/*     */ 
/* 109 */     return high << 32 | low & 0xFFFFFFFF;
/*     */   }
/*     */ 
/*     */   public BigInteger readMPINT()
/*     */     throws IOException
/*     */   {
/* 116 */     byte[] raw = readByteString();
/*     */     BigInteger b;
/*     */     BigInteger b;
/* 118 */     if (raw.length == 0)
/* 119 */       b = BigInteger.ZERO;
/*     */     else {
/* 121 */       b = new BigInteger(raw);
/*     */     }
/* 123 */     return b;
/*     */   }
/*     */ 
/*     */   public byte[] readByteString() throws IOException
/*     */   {
/* 128 */     int len = readUINT32();
/*     */ 
/* 130 */     if (len + this.pos > this.max) {
/* 131 */       throw new IOException("Malformed SSH byte string.");
/*     */     }
/* 133 */     byte[] res = new byte[len];
/* 134 */     System.arraycopy(this.arr, this.pos, res, 0, len);
/* 135 */     this.pos += len;
/* 136 */     return res;
/*     */   }
/*     */ 
/*     */   public String readString(String charsetName) throws IOException
/*     */   {
/* 141 */     int len = readUINT32();
/*     */ 
/* 143 */     if (len + this.pos > this.max) {
/* 144 */       throw new IOException("Malformed SSH string.");
/*     */     }
/* 146 */     String res = charsetName == null ? new String(this.arr, this.pos, len) : new String(this.arr, this.pos, len, charsetName);
/* 147 */     this.pos += len;
/*     */ 
/* 149 */     return res;
/*     */   }
/*     */ 
/*     */   public String readString() throws IOException
/*     */   {
/* 154 */     int len = readUINT32();
/*     */ 
/* 156 */     if (len + this.pos > this.max) {
/* 157 */       throw new IOException("Malformed SSH string.");
/*     */     }
/* 159 */     String res = new String(this.arr, this.pos, len);
/* 160 */     this.pos += len;
/*     */ 
/* 162 */     return res;
/*     */   }
/*     */ 
/*     */   public String[] readNameList() throws IOException
/*     */   {
/* 167 */     return Tokenizer.parseTokens(readString(), ',');
/*     */   }
/*     */ 
/*     */   public int remain()
/*     */   {
/* 172 */     return this.max - this.pos;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.TypesReader
 * JD-Core Version:    0.6.0
 */