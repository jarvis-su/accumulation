package com.ibm.wsdl.extensions.mime;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;

public class MIMEPartImpl
  implements MIMEPart
{
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_PART;
  protected Boolean required = null;
  protected List extElements = new Vector();
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("MIMEPart (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.extElements != null)
    {
      Iterator localIterator = this.extElements.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.mime.MIMEPartImpl
 * JD-Core Version:    0.6.0
 */