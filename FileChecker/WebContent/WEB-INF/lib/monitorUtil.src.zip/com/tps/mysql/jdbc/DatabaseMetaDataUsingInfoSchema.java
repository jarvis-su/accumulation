/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.SQLException;
/*      */ 
/*      */ public class DatabaseMetaDataUsingInfoSchema extends DatabaseMetaData
/*      */ {
/*      */   public DatabaseMetaDataUsingInfoSchema(Connection connToSet, String databaseToSet)
/*      */   {
/*   40 */     super(connToSet, databaseToSet);
/*      */   }
/*      */ 
/*      */   private java.sql.ResultSet executeMetadataQuery(PreparedStatement pStmt) throws SQLException
/*      */   {
/*   45 */     java.sql.ResultSet rs = pStmt.executeQuery();
/*   46 */     ((ResultSet)rs).setOwningStatement(null);
/*      */ 
/*   48 */     return rs;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/*   89 */     if (columnNamePattern == null) {
/*   90 */       if (this.conn.getNullNamePatternMatchesAll())
/*   91 */         columnNamePattern = "%";
/*      */       else {
/*   93 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*   99 */     if (catalog == null) {
/*  100 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  101 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  105 */       catalog = this.database;
/*      */     }
/*      */ 
/*  108 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME,COLUMN_NAME, NULL AS GRANTOR, GRANTEE, PRIVILEGE_TYPE AS PRIVILEGE, IS_GRANTABLE FROM INFORMATION_SCHEMA.COLUMN_PRIVILEGES WHERE TABLE_SCHEMA = ? AND TABLE_NAME =? AND COLUMN_NAME LIKE ? ORDER BY COLUMN_NAME, PRIVILEGE_TYPE";
/*      */ 
/*  115 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  118 */       pStmt = prepareMetaDataSafeStatement(sql);
/*  119 */       pStmt.setString(1, catalog);
/*  120 */       pStmt.setString(2, table);
/*  121 */       pStmt.setString(3, columnNamePattern);
/*      */ 
/*  123 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*  124 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 64), new Field("", "TABLE_SCHEM", 1, 1), new Field("", "TABLE_NAME", 1, 64), new Field("", "COLUMN_NAME", 1, 64), new Field("", "GRANTOR", 1, 77), new Field("", "GRANTEE", 1, 77), new Field("", "PRIVILEGE", 1, 64), new Field("", "IS_GRANTABLE", 1, 3) });
/*      */ 
/*  134 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  136 */       if (pStmt != null)
/*  137 */         pStmt.close(); 
/*  137 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getColumns(String catalog, String schemaPattern, String tableName, String columnNamePattern)
/*      */     throws SQLException
/*      */   {
/*  188 */     if (columnNamePattern == null) {
/*  189 */       if (this.conn.getNullNamePatternMatchesAll())
/*  190 */         columnNamePattern = "%";
/*      */       else {
/*  192 */         throw SQLError.createSQLException("Column name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  198 */     if (catalog == null) {
/*  199 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  200 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  204 */       catalog = this.database;
/*      */     }
/*      */ 
/*  207 */     StringBuffer sqlBuf = new StringBuffer("SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,TABLE_NAME,COLUMN_NAME,");
/*      */ 
/*  210 */     MysqlDefs.appendJdbcTypeMappingQuery(sqlBuf, "DATA_TYPE");
/*      */ 
/*  212 */     sqlBuf.append(" AS DATA_TYPE, ");
/*      */ 
/*  214 */     if (this.conn.getCapitalizeTypeNames())
/*  215 */       sqlBuf.append("UPPER(CASE WHEN LOCATE('unsigned', COLUMN_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END) AS TYPE_NAME,");
/*      */     else {
/*  217 */       sqlBuf.append("CASE WHEN LOCATE('unsigned', COLUMN_TYPE) != 0 AND LOCATE('unsigned', DATA_TYPE) = 0 THEN CONCAT(DATA_TYPE, ' unsigned') ELSE DATA_TYPE END AS TYPE_NAME,");
/*      */     }
/*      */ 
/*  220 */     sqlBuf.append("CASE WHEN CHARACTER_MAXIMUM_LENGTH IS NULL THEN NUMERIC_PRECISION ELSE CASE WHEN CHARACTER_MAXIMUM_LENGTH > 2147483647 THEN 2147483647 ELSE CHARACTER_MAXIMUM_LENGTH END END AS COLUMN_SIZE,  NULL AS BUFFER_LENGTH,NUMERIC_SCALE AS DECIMAL_DIGITS,10 AS NUM_PREC_RADIX,NULL AS NULLABLE,COLUMN_COMMENT AS REMARKS,COLUMN_DEFAULT AS COLUMN_DEF,NULL AS SQL_DATA_TYPE,NULL AS SQL_DATETIME_SUB,CHARACTER_OCTET_LENGTH AS CHAR_OCTET_LENGTH,ORDINAL_POSITION,IS_NULLABLE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ? AND COLUMN_NAME LIKE ? ORDER BY TABLE_SCHEMA, TABLE_NAME, ORDINAL_POSITION");
/*      */ 
/*  239 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  242 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*  243 */       pStmt.setString(1, catalog);
/*  244 */       pStmt.setString(2, tableName);
/*  245 */       pStmt.setString(3, columnNamePattern);
/*      */ 
/*  247 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*      */ 
/*  249 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 255), new Field("", "TABLE_SCHEM", 1, 0), new Field("", "TABLE_NAME", 1, 255), new Field("", "COLUMN_NAME", 1, 32), new Field("", "DATA_TYPE", 5, 5), new Field("", "TYPE_NAME", 1, 16), new Field("", "COLUMN_SIZE", 4, Integer.toString(2147483647).length()), new Field("", "BUFFER_LENGTH", 4, 10), new Field("", "DECIMAL_DIGITS", 4, 10), new Field("", "NUM_PREC_RADIX", 4, 10), new Field("", "NULLABLE", 4, 10), new Field("", "REMARKS", 1, 0), new Field("", "COLUMN_DEF", 1, 0), new Field("", "SQL_DATA_TYPE", 4, 10), new Field("", "SQL_DATETIME_SUB", 4, 10), new Field("", "CHAR_OCTET_LENGTH", 4, Integer.toString(2147483647).length()), new Field("", "ORDINAL_POSITION", 4, 10), new Field("", "IS_NULLABLE", 1, 3) });
/*      */ 
/*  271 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  273 */       if (pStmt != null)
/*  274 */         pStmt.close(); 
/*  274 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getCrossReference(String primaryCatalog, String primarySchema, String primaryTable, String foreignCatalog, String foreignSchema, String foreignTable)
/*      */     throws SQLException
/*      */   {
/*  349 */     if (primaryTable == null) {
/*  350 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/*  354 */     if (primaryCatalog == null) {
/*  355 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  356 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  360 */       primaryCatalog = this.database;
/*      */     }
/*      */ 
/*  363 */     if (foreignCatalog == null) {
/*  364 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  365 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  369 */       foreignCatalog = this.database;
/*      */     }
/*      */ 
/*  372 */     Field[] fields = new Field[14];
/*  373 */     fields[0] = new Field("", "PKTABLE_CAT", 1, 255);
/*  374 */     fields[1] = new Field("", "PKTABLE_SCHEM", 1, 0);
/*  375 */     fields[2] = new Field("", "PKTABLE_NAME", 1, 255);
/*  376 */     fields[3] = new Field("", "PKCOLUMN_NAME", 1, 32);
/*  377 */     fields[4] = new Field("", "FKTABLE_CAT", 1, 255);
/*  378 */     fields[5] = new Field("", "FKTABLE_SCHEM", 1, 0);
/*  379 */     fields[6] = new Field("", "FKTABLE_NAME", 1, 255);
/*  380 */     fields[7] = new Field("", "FKCOLUMN_NAME", 1, 32);
/*  381 */     fields[8] = new Field("", "KEY_SEQ", 5, 2);
/*  382 */     fields[9] = new Field("", "UPDATE_RULE", 5, 2);
/*  383 */     fields[10] = new Field("", "DELETE_RULE", 5, 2);
/*  384 */     fields[11] = new Field("", "FK_NAME", 1, 0);
/*  385 */     fields[12] = new Field("", "PK_NAME", 1, 0);
/*  386 */     fields[13] = new Field("", "DEFERRABILITY", 4, 2);
/*      */ 
/*  388 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT,NULL AS PKTABLE_SCHEM,A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME,A.TABLE_SCHEMA AS FKTABLE_CAT,NULL AS FKTABLE_SCHEM,A.TABLE_NAME AS FKTABLE_NAME, A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ,1 AS UPDATE_RULE,1 AS DELETE_RULE,A.CONSTRAINT_NAME AS FK_NAME,NULL AS PK_NAME,7 AS DEFERRABILITY FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A,INFORMATION_SCHEMA.TABLE_CONSTRAINTS B WHERE A.TABLE_SCHEMA=B.TABLE_SCHEMA AND A.TABLE_NAME=B.TABLE_NAME AND A.CONSTRAINT_NAME=B.CONSTRAINT_NAME AND B.CONSTRAINT_TYPE IS NOT NULL AND A.REFERENCED_TABLE_SCHEMA=? AND A.REFERENCED_TABLE_NAME=? AND A.TABLE_SCHEMA=? AND A.TABLE_NAME=? ORDER BY A.TABLE_SCHEMA, A.TABLE_NAME, A.ORDINAL_POSITION";
/*      */ 
/*  417 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  420 */       pStmt = prepareMetaDataSafeStatement(sql);
/*  421 */       pStmt.setString(1, primaryCatalog);
/*  422 */       pStmt.setString(2, primaryTable);
/*  423 */       pStmt.setString(3, foreignCatalog);
/*  424 */       pStmt.setString(4, foreignTable);
/*      */ 
/*  426 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*  427 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "PKTABLE_CAT", 1, 255), new Field("", "PKTABLE_SCHEM", 1, 0), new Field("", "PKTABLE_NAME", 1, 255), new Field("", "PKCOLUMN_NAME", 1, 32), new Field("", "FKTABLE_CAT", 1, 255), new Field("", "FKTABLE_SCHEM", 1, 0), new Field("", "FKTABLE_NAME", 1, 255), new Field("", "FKCOLUMN_NAME", 1, 32), new Field("", "KEY_SEQ", 5, 2), new Field("", "UPDATE_RULE", 5, 2), new Field("", "DELETE_RULE", 5, 2), new Field("", "FK_NAME", 1, 0), new Field("", "PK_NAME", 1, 0), new Field("", "DEFERRABILITY", 4, 2) });
/*      */ 
/*  443 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  445 */       if (pStmt != null)
/*  446 */         pStmt.close(); 
/*  446 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getExportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  514 */     if (table == null) {
/*  515 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/*  519 */     if (catalog == null) {
/*  520 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  521 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  525 */       catalog = this.database;
/*      */     }
/*      */ 
/*  528 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT,NULL AS PKTABLE_SCHEM,A.REFERENCED_TABLE_NAME AS PKTABLE_NAME, A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME, A.TABLE_SCHEMA AS FKTABLE_CAT,NULL AS FKTABLE_SCHEM,A.TABLE_NAME AS FKTABLE_NAME,A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ,1 AS UPDATE_RULE,1 AS DELETE_RULE,A.CONSTRAINT_NAME AS FK_NAME,NULL AS PK_NAME,7 AS DEFERRABILITY FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A,INFORMATION_SCHEMA.TABLE_CONSTRAINTS B WHERE A.TABLE_SCHEMA=B.TABLE_SCHEMA AND A.TABLE_NAME=B.TABLE_NAME AND A.CONSTRAINT_NAME=B.CONSTRAINT_NAME AND B.CONSTRAINT_TYPE IS NOT NULL AND A.REFERENCED_TABLE_SCHEMA=? AND A.REFERENCED_TABLE_NAME=? ORDER BY A.TABLE_SCHEMA, A.TABLE_NAME, A.ORDINAL_POSITION";
/*      */ 
/*  556 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  559 */       pStmt = prepareMetaDataSafeStatement(sql);
/*  560 */       pStmt.setString(1, catalog);
/*  561 */       pStmt.setString(2, table);
/*      */ 
/*  563 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*      */ 
/*  565 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "PKTABLE_CAT", 1, 255), new Field("", "PKTABLE_SCHEM", 1, 0), new Field("", "PKTABLE_NAME", 1, 255), new Field("", "PKCOLUMN_NAME", 1, 32), new Field("", "FKTABLE_CAT", 1, 255), new Field("", "FKTABLE_SCHEM", 1, 0), new Field("", "FKTABLE_NAME", 1, 255), new Field("", "FKCOLUMN_NAME", 1, 32), new Field("", "KEY_SEQ", 5, 2), new Field("", "UPDATE_RULE", 5, 2), new Field("", "DELETE_RULE", 5, 2), new Field("", "FK_NAME", 1, 255), new Field("", "PK_NAME", 1, 0), new Field("", "DEFERRABILITY", 4, 2) });
/*      */ 
/*  581 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  583 */       if (pStmt != null)
/*  584 */         pStmt.close(); 
/*  584 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getImportedKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  677 */     if (table == null) {
/*  678 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/*  682 */     if (catalog == null) {
/*  683 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  684 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  688 */       catalog = this.database;
/*      */     }
/*      */ 
/*  691 */     String sql = "SELECT A.REFERENCED_TABLE_SCHEMA AS PKTABLE_CAT,NULL AS PKTABLE_SCHEM,A.REFERENCED_TABLE_NAME AS PKTABLE_NAME,A.REFERENCED_COLUMN_NAME AS PKCOLUMN_NAME,A.TABLE_SCHEMA AS FKTABLE_CAT,NULL AS FKTABLE_SCHEM,A.TABLE_NAME AS FKTABLE_NAME, A.COLUMN_NAME AS FKCOLUMN_NAME, A.ORDINAL_POSITION AS KEY_SEQ,1 AS UPDATE_RULE,1 AS DELETE_RULE,A.CONSTRAINT_NAME AS FK_NAME,NULL AS PK_NAME, 7 AS DEFERRABILITY FROM INFORMATION_SCHEMA.KEY_COLUMN_USAGE A, INFORMATION_SCHEMA.TABLE_CONSTRAINTS B WHERE A.TABLE_SCHEMA=? AND A.CONSTRAINT_NAME=B.CONSTRAINT_NAME AND A.TABLE_NAME=? AND B.TABLE_NAME=? AND A.REFERENCED_TABLE_SCHEMA IS NOT NULL  ORDER BY A.REFERENCED_TABLE_SCHEMA, A.REFERENCED_TABLE_NAME, A.ORDINAL_POSITION";
/*      */ 
/*  719 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  722 */       pStmt = prepareMetaDataSafeStatement(sql);
/*  723 */       pStmt.setString(1, catalog);
/*  724 */       pStmt.setString(2, table);
/*  725 */       pStmt.setString(3, table);
/*      */ 
/*  727 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*      */ 
/*  729 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "PKTABLE_CAT", 1, 255), new Field("", "PKTABLE_SCHEM", 1, 0), new Field("", "PKTABLE_NAME", 1, 255), new Field("", "PKCOLUMN_NAME", 1, 32), new Field("", "FKTABLE_CAT", 1, 255), new Field("", "FKTABLE_SCHEM", 1, 0), new Field("", "FKTABLE_NAME", 1, 255), new Field("", "FKCOLUMN_NAME", 1, 32), new Field("", "KEY_SEQ", 5, 2), new Field("", "UPDATE_RULE", 5, 2), new Field("", "DELETE_RULE", 5, 2), new Field("", "FK_NAME", 1, 255), new Field("", "PK_NAME", 1, 0), new Field("", "DEFERRABILITY", 4, 2) });
/*      */ 
/*  745 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  747 */       if (pStmt != null)
/*  748 */         pStmt.close(); 
/*  748 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate)
/*      */     throws SQLException
/*      */   {
/*  813 */     StringBuffer sqlBuf = new StringBuffer("SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM,TABLE_NAME,NON_UNIQUE,TABLE_SCHEMA AS INDEX_QUALIFIER,INDEX_NAME,3 AS TYPE,SEQ_IN_INDEX AS ORDINAL_POSITION,COLUMN_NAME,COLLATION AS ASC_OR_DESC,CARDINALITY,NULL AS PAGES,NULL AS FILTER_CONDITION FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ?");
/*      */ 
/*  824 */     if (unique) {
/*  825 */       sqlBuf.append(" AND NON_UNIQUE=0 ");
/*      */     }
/*      */ 
/*  828 */     sqlBuf.append("ORDER BY NON_UNIQUE, INDEX_NAME, SEQ_IN_INDEX");
/*      */ 
/*  830 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  833 */       pStmt = prepareMetaDataSafeStatement(sqlBuf.toString());
/*      */ 
/*  835 */       pStmt.setString(1, catalog);
/*  836 */       pStmt.setString(2, table);
/*      */ 
/*  838 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*      */ 
/*  840 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 255), new Field("", "TABLE_SCHEM", 1, 0), new Field("", "TABLE_NAME", 1, 255), new Field("", "NON_UNIQUE", 1, 4), new Field("", "INDEX_QUALIFIER", 1, 1), new Field("", "INDEX_NAME", 1, 32), new Field("", "TYPE", 1, 32), new Field("", "ORDINAL_POSITION", 5, 5), new Field("", "COLUMN_NAME", 1, 32), new Field("", "ASC_OR_DESC", 1, 1), new Field("", "CARDINALITY", 4, 10), new Field("", "PAGES", 4, 10), new Field("", "FILTER_CONDITION", 1, 32) });
/*      */ 
/*  855 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  857 */       if (pStmt != null)
/*  858 */         pStmt.close(); 
/*  858 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getPrimaryKeys(String catalog, String schema, String table)
/*      */     throws SQLException
/*      */   {
/*  891 */     if (catalog == null) {
/*  892 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  893 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/*  897 */       catalog = this.database;
/*      */     }
/*      */ 
/*  900 */     if (table == null) {
/*  901 */       throw SQLError.createSQLException("Table not specified.", "S1009");
/*      */     }
/*      */ 
/*  905 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, COLUMN_NAME, SEQ_IN_INDEX AS KEY_SEQ, 'PRIMARY' AS PK_NAME FROM INFORMATION_SCHEMA.STATISTICS WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ? AND INDEX_NAME='PRIMARY' ORDER BY TABLE_SCHEMA, TABLE_NAME, INDEX_NAME, SEQ_IN_INDEX";
/*      */ 
/*  910 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/*  913 */       pStmt = prepareMetaDataSafeStatement(sql);
/*      */ 
/*  915 */       pStmt.setString(1, catalog);
/*  916 */       pStmt.setString(2, table);
/*      */ 
/*  918 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*  919 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 1, 255), new Field("", "TABLE_SCHEM", 1, 0), new Field("", "TABLE_NAME", 1, 255), new Field("", "COLUMN_NAME", 1, 32), new Field("", "KEY_SEQ", 5, 5), new Field("", "PK_NAME", 1, 32) });
/*      */ 
/*  927 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/*  929 */       if (pStmt != null)
/*  930 */         pStmt.close(); 
/*  930 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
/*      */     throws SQLException
/*      */   {
/*  978 */     if ((procedureNamePattern == null) || (procedureNamePattern.length() == 0))
/*      */     {
/*  980 */       if (this.conn.getNullNamePatternMatchesAll())
/*  981 */         procedureNamePattern = "%";
/*      */       else {
/*  983 */         throw SQLError.createSQLException("Procedure name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  989 */     String db = null;
/*      */ 
/*  991 */     if (catalog == null) {
/*  992 */       db = this.database;
/*  993 */     } else if (catalog.length() > 0) {
/*  994 */       db = catalog;
/*      */     } else {
/*  996 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/*  997 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/* 1001 */       catalog = null;
/* 1002 */       db = null;
/*      */     }
/*      */ 
/* 1005 */     String sql = "SELECT ROUTINE_SCHEMA AS PROCEDURE_CAT, NULL AS PROCEDURE_SCHEM, ROUTINE_NAME AS PROCEDURE_NAME, NULL AS RESERVED_1, NULL AS RESERVED_2, NULL AS RESERVED_3, ROUTINE_COMMENT AS REMARKS, CASE WHEN ROUTINE_TYPE = 'PROCEDURE' THEN 1 WHEN ROUTINE_TYPE='FUNCTION' THEN 2 ELSE 0 END AS PROCEDURE_TYPE FROM INFORMATION_SCHEMA.ROUTINES WHERE ROUTINE_SCHEMA LIKE ? AND ROUTINE_NAME LIKE ? ORDER BY ROUTINE_SCHEMA, ROUTINE_NAME";
/*      */ 
/* 1018 */     PreparedStatement pStmt = null;
/*      */     try
/*      */     {
/* 1021 */       pStmt = prepareMetaDataSafeStatement(sql);
/* 1022 */       pStmt.setString(1, db);
/* 1023 */       pStmt.setString(2, procedureNamePattern);
/*      */ 
/* 1025 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/* 1026 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "PROCEDURE_CAT", 1, 0), new Field("", "PROCEDURE_SCHEM", 1, 0), new Field("", "PROCEDURE_NAME", 1, 0), new Field("", "reserved1", 1, 0), new Field("", "reserved2", 1, 0), new Field("", "reserved3", 1, 0), new Field("", "REMARKS", 1, 0), new Field("", "PROCEDURE_TYPE", 5, 0) });
/*      */ 
/* 1036 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/* 1038 */       if (pStmt != null)
/* 1039 */         pStmt.close(); 
/* 1039 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types)
/*      */     throws SQLException
/*      */   {
/* 1082 */     if (catalog == null) {
/* 1083 */       if (!this.conn.getNullCatalogMeansCurrent()) {
/* 1084 */         throw SQLError.createSQLException("'catalog' parameter can not be null", "S1009");
/*      */       }
/*      */ 
/* 1088 */       catalog = this.database;
/*      */     }
/*      */ 
/* 1091 */     if (tableNamePattern == null) {
/* 1092 */       if (this.conn.getNullNamePatternMatchesAll())
/* 1093 */         tableNamePattern = "%";
/*      */       else {
/* 1095 */         throw SQLError.createSQLException("Table name pattern can not be NULL or empty.", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1101 */     PreparedStatement pStmt = null;
/*      */ 
/* 1103 */     String sql = "SELECT TABLE_SCHEMA AS TABLE_CAT, NULL AS TABLE_SCHEM, TABLE_NAME, CASE WHEN TABLE_TYPE='BASE TABLE' THEN 'TABLE' WHEN TABLE_TYPE='TEMPORARY' THEN 'LOCAL_TEMPORARY' ELSE TABLE_TYPE END AS TABLE_TYPE, TABLE_COMMENT AS REMARKS FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA LIKE ? AND TABLE_NAME LIKE ? AND TABLE_TYPE IN (?,?,?) ORDER BY TABLE_TYPE, TABLE_SCHEMA, TABLE_NAME";
/*      */     try
/*      */     {
/* 1111 */       pStmt = prepareMetaDataSafeStatement(sql);
/* 1112 */       pStmt.setString(1, catalog);
/* 1113 */       pStmt.setString(2, tableNamePattern);
/*      */ 
/* 1117 */       if ((types == null) || (types.length == 0)) {
/* 1118 */         pStmt.setString(3, "BASE TABLE");
/* 1119 */         pStmt.setString(4, "VIEW");
/* 1120 */         pStmt.setString(5, "TEMPORARY");
/*      */       } else {
/* 1122 */         pStmt.setNull(3, 12);
/* 1123 */         pStmt.setNull(4, 12);
/* 1124 */         pStmt.setNull(5, 12);
/*      */ 
/* 1126 */         for (int i = 0; i < types.length; i++) {
/* 1127 */           if ("TABLE".equalsIgnoreCase(types[i])) {
/* 1128 */             pStmt.setString(3, "BASE TABLE");
/*      */           }
/*      */ 
/* 1131 */           if ("VIEW".equalsIgnoreCase(types[i])) {
/* 1132 */             pStmt.setString(4, "VIEW");
/*      */           }
/*      */ 
/* 1135 */           if ("LOCAL TEMPORARY".equalsIgnoreCase(types[i])) {
/* 1136 */             pStmt.setString(5, "TEMPORARY");
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 1141 */       java.sql.ResultSet rs = executeMetadataQuery(pStmt);
/*      */ 
/* 1143 */       ((ResultSet)rs).redefineFieldsForDBMD(new Field[] { new Field("", "TABLE_CAT", 12, catalog == null ? 0 : catalog.length()), new Field("", "TABLE_SCHEM", 12, 0), new Field("", "TABLE_NAME", 12, 255), new Field("", "TABLE_TYPE", 12, 5), new Field("", "REMARKS", 12, 0) });
/*      */ 
/* 1151 */       java.sql.ResultSet localResultSet1 = rs;
/*      */       return localResultSet1;
/*      */     }
/*      */     finally
/*      */     {
/* 1153 */       if (pStmt != null)
/* 1154 */         pStmt.close(); 
/* 1154 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   private PreparedStatement prepareMetaDataSafeStatement(String sql)
/*      */     throws SQLException
/*      */   {
/* 1163 */     PreparedStatement pStmt = this.conn.clientPrepareStatement(sql);
/*      */ 
/* 1165 */     if (pStmt.getMaxRows() != 0) {
/* 1166 */       pStmt.setMaxRows(0);
/*      */     }
/*      */ 
/* 1169 */     pStmt.setHoldResultsOpenOverClose(true);
/*      */ 
/* 1171 */     return pStmt;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaDataUsingInfoSchema
 * JD-Core Version:    0.6.0
 */