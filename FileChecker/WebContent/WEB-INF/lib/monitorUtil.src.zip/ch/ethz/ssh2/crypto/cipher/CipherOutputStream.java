/*     */ package ch.ethz.ssh2.crypto.cipher;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class CipherOutputStream
/*     */ {
/*     */   BlockCipher currentCipher;
/*     */   OutputStream bo;
/*     */   byte[] buffer;
/*     */   byte[] enc;
/*     */   int blockSize;
/*     */   int pos;
/*  27 */   final int BUFF_SIZE = 2048;
/*  28 */   byte[] out_buffer = new byte[2048];
/*  29 */   int out_buffer_pos = 0;
/*     */ 
/*     */   public CipherOutputStream(BlockCipher tc, OutputStream bo)
/*     */   {
/*  33 */     this.bo = bo;
/*  34 */     changeCipher(tc);
/*     */   }
/*     */ 
/*     */   private void internal_write(byte[] src, int off, int len) throws IOException
/*     */   {
/*  39 */     while (len > 0)
/*     */     {
/*  41 */       int space = 2048 - this.out_buffer_pos;
/*  42 */       int copy = len > space ? space : len;
/*     */ 
/*  44 */       System.arraycopy(src, off, this.out_buffer, this.out_buffer_pos, copy);
/*     */ 
/*  46 */       off += copy;
/*  47 */       this.out_buffer_pos += copy;
/*  48 */       len -= copy;
/*     */ 
/*  50 */       if (this.out_buffer_pos < 2048)
/*     */         continue;
/*  52 */       this.bo.write(this.out_buffer, 0, 2048);
/*  53 */       this.out_buffer_pos = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   private void internal_write(int b)
/*     */     throws IOException
/*     */   {
/*  60 */     this.out_buffer[(this.out_buffer_pos++)] = (byte)b;
/*  61 */     if (this.out_buffer_pos >= 2048)
/*     */     {
/*  63 */       this.bo.write(this.out_buffer, 0, 2048);
/*  64 */       this.out_buffer_pos = 0;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void flush() throws IOException
/*     */   {
/*  70 */     if (this.pos != 0) {
/*  71 */       throw new IOException("FATAL: cannot flush since crypto buffer is not aligned.");
/*     */     }
/*  73 */     if (this.out_buffer_pos > 0)
/*     */     {
/*  75 */       this.bo.write(this.out_buffer, 0, this.out_buffer_pos);
/*  76 */       this.out_buffer_pos = 0;
/*     */     }
/*  78 */     this.bo.flush();
/*     */   }
/*     */ 
/*     */   public void changeCipher(BlockCipher bc)
/*     */   {
/*  83 */     this.currentCipher = bc;
/*  84 */     this.blockSize = bc.getBlockSize();
/*  85 */     this.buffer = new byte[this.blockSize];
/*  86 */     this.enc = new byte[this.blockSize];
/*  87 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   private void writeBlock() throws IOException
/*     */   {
/*     */     try
/*     */     {
/*  94 */       this.currentCipher.transformBlock(this.buffer, 0, this.enc, 0);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  98 */       throw ((IOException)new IOException("Error while decrypting block.").initCause(e));
/*     */     }
/*     */ 
/* 101 */     internal_write(this.enc, 0, this.blockSize);
/* 102 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   public void write(byte[] src, int off, int len) throws IOException
/*     */   {
/* 107 */     while (len > 0)
/*     */     {
/* 109 */       int avail = this.blockSize - this.pos;
/* 110 */       int copy = Math.min(avail, len);
/*     */ 
/* 112 */       System.arraycopy(src, off, this.buffer, this.pos, copy);
/* 113 */       this.pos += copy;
/* 114 */       off += copy;
/* 115 */       len -= copy;
/*     */ 
/* 117 */       if (this.pos >= this.blockSize)
/* 118 */         writeBlock();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void write(int b) throws IOException
/*     */   {
/* 124 */     this.buffer[(this.pos++)] = (byte)b;
/* 125 */     if (this.pos >= this.blockSize)
/* 126 */       writeBlock();
/*     */   }
/*     */ 
/*     */   public void writePlain(int b) throws IOException
/*     */   {
/* 131 */     if (this.pos != 0)
/* 132 */       throw new IOException("Cannot write plain since crypto buffer is not aligned.");
/* 133 */     internal_write(b);
/*     */   }
/*     */ 
/*     */   public void writePlain(byte[] b, int off, int len) throws IOException
/*     */   {
/* 138 */     if (this.pos != 0)
/* 139 */       throw new IOException("Cannot write plain since crypto buffer is not aligned.");
/* 140 */     internal_write(b, off, len);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.CipherOutputStream
 * JD-Core Version:    0.6.0
 */