/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.net.SocketException;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class NamedPipeSocketFactory
/*     */   implements SocketFactory
/*     */ {
/*     */   private static final String NAMED_PIPE_PROP_NAME = "namedPipePath";
/*     */   private Socket namedPipeSocket;
/*     */ 
/*     */   public Socket afterHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/* 189 */     return this.namedPipeSocket;
/*     */   }
/*     */ 
/*     */   public Socket beforeHandshake()
/*     */     throws SocketException, IOException
/*     */   {
/* 196 */     return this.namedPipeSocket;
/*     */   }
/*     */ 
/*     */   public Socket connect(String host, int portNumber, Properties props)
/*     */     throws SocketException, IOException
/*     */   {
/* 204 */     String namedPipePath = props.getProperty("namedPipePath");
/*     */ 
/* 206 */     if (namedPipePath == null)
/* 207 */       namedPipePath = "\\\\.\\pipe\\MySQL";
/* 208 */     else if (namedPipePath.length() == 0) {
/* 209 */       throw new SocketException(Messages.getString("NamedPipeSocketFactory.2") + "namedPipePath" + Messages.getString("NamedPipeSocketFactory.3"));
/*     */     }
/*     */ 
/* 215 */     this.namedPipeSocket = new NamedPipeSocketFactory.NamedPipeSocket(this, namedPipePath);
/*     */ 
/* 217 */     return this.namedPipeSocket;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.NamedPipeSocketFactory
 * JD-Core Version:    0.6.0
 */