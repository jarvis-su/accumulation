/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.ByteArrayInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.ObjectInputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.StringReader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.DataTruncation;
/*      */ import java.sql.Date;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.HashMap;
/*      */ import java.util.Locale;
/*      */ import java.util.Map;
/*      */ import java.util.StringTokenizer;
/*      */ import java.util.TimeZone;
/*      */ 
/*      */ public class ResultSet
/*      */   implements java.sql.ResultSet
/*      */ {
/*  123 */   protected static final double MIN_DIFF_PREC = Float.parseFloat(Float.toString(1.4E-45F)) - Double.parseDouble(Float.toString(1.4E-45F));
/*      */ 
/*  129 */   protected static final double MAX_DIFF_PREC = Float.parseFloat(Float.toString(3.4028235E+38F)) - Double.parseDouble(Float.toString(3.4028235E+38F));
/*      */ 
/*  133 */   protected static int resultCounter = 1;
/*      */ 
/*  154 */   protected String catalog = null;
/*      */ 
/*  157 */   protected Map columnNameToIndex = null;
/*      */ 
/*  160 */   protected boolean[] columnUsed = null;
/*      */   protected Connection connection;
/*  166 */   protected long connectionId = 0L;
/*      */ 
/*  169 */   protected int currentRow = -1;
/*      */   private TimeZone defaultTimeZone;
/*  174 */   protected boolean doingUpdates = false;
/*      */ 
/*  176 */   protected ProfileEventSink eventSink = null;
/*      */ 
/*  178 */   private Calendar fastDateCal = null;
/*      */ 
/*  181 */   protected int fetchDirection = 1000;
/*      */ 
/*  184 */   protected int fetchSize = 0;
/*      */   protected Field[] fields;
/*      */   protected char firstCharOfQuery;
/*  197 */   protected Map fullColumnNameToIndex = null;
/*      */ 
/*  199 */   protected boolean hasBuiltIndexMapping = false;
/*      */ 
/*  205 */   protected boolean isBinaryEncoded = false;
/*      */ 
/*  208 */   protected boolean isClosed = false;
/*      */ 
/*  210 */   protected ResultSet nextResultSet = null;
/*      */ 
/*  213 */   protected boolean onInsertRow = false;
/*      */   protected Statement owningStatement;
/*      */   protected Throwable pointOfOrigin;
/*  224 */   protected boolean profileSql = false;
/*      */ 
/*  230 */   protected boolean reallyResult = false;
/*      */   protected int resultId;
/*  236 */   protected int resultSetConcurrency = 0;
/*      */ 
/*  239 */   protected int resultSetType = 0;
/*      */   protected RowData rowData;
/*  248 */   protected String serverInfo = null;
/*      */   private PreparedStatement statementUsedForFetchingRows;
/*  253 */   protected Object[] thisRow = null;
/*      */   protected long updateCount;
/*  267 */   protected long updateId = -1L;
/*      */ 
/*  269 */   private boolean useStrictFloatingPoint = false;
/*      */ 
/*  271 */   protected boolean useUsageAdvisor = false;
/*      */ 
/*  274 */   protected SQLWarning warningChain = null;
/*      */ 
/*  277 */   protected boolean wasNullFlag = false;
/*      */   protected java.sql.Statement wrapperStatement;
/*      */   protected boolean retainOwningStatement;
/*  283 */   protected Calendar gmtCalendar = null;
/*      */ 
/*      */   protected static BigInteger convertLongToUlong(long longVal)
/*      */   {
/*  140 */     byte[] asBytes = new byte[8];
/*  141 */     asBytes[7] = (byte)(int)(longVal & 0xFF);
/*  142 */     asBytes[6] = (byte)(int)(longVal >>> 8);
/*  143 */     asBytes[5] = (byte)(int)(longVal >>> 16);
/*  144 */     asBytes[4] = (byte)(int)(longVal >>> 24);
/*  145 */     asBytes[3] = (byte)(int)(longVal >>> 32);
/*  146 */     asBytes[2] = (byte)(int)(longVal >>> 40);
/*  147 */     asBytes[1] = (byte)(int)(longVal >>> 48);
/*  148 */     asBytes[0] = (byte)(int)(longVal >>> 56);
/*      */ 
/*  150 */     return new BigInteger(1, asBytes);
/*      */   }
/*      */ 
/*      */   public ResultSet(long updateCount, long updateID, Connection conn, Statement creatorStmt)
/*      */   {
/*  299 */     this.updateCount = updateCount;
/*  300 */     this.updateId = updateID;
/*  301 */     this.reallyResult = false;
/*  302 */     this.fields = new Field[0];
/*      */ 
/*  304 */     this.connection = conn;
/*  305 */     this.owningStatement = creatorStmt;
/*      */ 
/*  307 */     this.retainOwningStatement = false;
/*      */ 
/*  309 */     if (this.connection != null) {
/*  310 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*      */ 
/*  313 */       this.connectionId = this.connection.getId();
/*      */     }
/*      */   }
/*      */ 
/*      */   public ResultSet(String catalog, Field[] fields, RowData tuples, Connection conn, Statement creatorStmt)
/*      */     throws SQLException
/*      */   {
/*  336 */     this.connection = conn;
/*      */ 
/*  338 */     this.fastDateCal = new GregorianCalendar(Locale.US);
/*  339 */     this.fastDateCal.setTimeZone(getDefaultTimeZone());
/*      */ 
/*  341 */     if (this.connection != null) {
/*  342 */       this.useStrictFloatingPoint = this.connection.getStrictFloatingPoint();
/*      */ 
/*  344 */       setDefaultTimeZone(this.connection.getDefaultTimeZone());
/*  345 */       this.connectionId = this.connection.getId();
/*      */     }
/*      */ 
/*  348 */     this.owningStatement = creatorStmt;
/*      */ 
/*  350 */     this.catalog = catalog;
/*  351 */     this.profileSql = this.connection.getProfileSql();
/*      */ 
/*  353 */     this.fields = fields;
/*  354 */     this.rowData = tuples;
/*  355 */     this.updateCount = this.rowData.size();
/*      */ 
/*  362 */     this.reallyResult = true;
/*      */ 
/*  365 */     if (this.rowData.size() > 0) {
/*  366 */       if ((this.updateCount == 1L) && 
/*  367 */         (this.thisRow == null)) {
/*  368 */         this.rowData.close();
/*  369 */         this.updateCount = -1L;
/*      */       }
/*      */     }
/*      */     else {
/*  373 */       this.thisRow = null;
/*      */     }
/*      */ 
/*  376 */     this.rowData.setOwner(this);
/*      */ 
/*  378 */     if ((this.profileSql) || (this.connection.getUseUsageAdvisor())) {
/*  379 */       this.columnUsed = new boolean[this.fields.length];
/*  380 */       this.pointOfOrigin = new Throwable();
/*  381 */       this.resultId = (resultCounter++);
/*  382 */       this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  383 */       this.eventSink = ProfileEventSink.getInstance(this.connection);
/*      */     }
/*      */ 
/*  386 */     if (this.connection.getGatherPerformanceMetrics()) {
/*  387 */       this.connection.incrementNumberOfResultSetsCreated();
/*      */ 
/*  389 */       Map tableNamesMap = new HashMap();
/*      */ 
/*  391 */       for (int i = 0; i < this.fields.length; i++) {
/*  392 */         Field f = this.fields[i];
/*      */ 
/*  394 */         String tableName = f.getOriginalTableName();
/*      */ 
/*  396 */         if (tableName == null) {
/*  397 */           tableName = f.getTableName();
/*      */         }
/*      */ 
/*  400 */         if (tableName != null) {
/*  401 */           if (this.connection.lowerCaseTableNames()) {
/*  402 */             tableName = tableName.toLowerCase();
/*      */           }
/*      */ 
/*  406 */           tableNamesMap.put(tableName, null);
/*      */         }
/*      */       }
/*      */ 
/*  410 */       this.connection.reportNumberOfTablesAccessed(tableNamesMap.size());
/*      */     }
/*      */ 
/*  413 */     this.retainOwningStatement = false;
/*      */ 
/*  415 */     if (this.connection != null)
/*  416 */       this.retainOwningStatement = this.connection.getRetainStatementAfterResultSetClose();
/*      */   }
/*      */ 
/*      */   public boolean absolute(int row)
/*      */     throws SQLException
/*      */   {
/*  460 */     checkClosed();
/*      */     boolean b;
/*      */     boolean b;
/*  464 */     if (this.rowData.size() == 0) {
/*  465 */       b = false;
/*      */     } else {
/*  467 */       if (row == 0) {
/*  468 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Cannot_absolute_position_to_row_0_110"), "S1009");
/*      */       }
/*      */ 
/*  474 */       if (this.onInsertRow) {
/*  475 */         this.onInsertRow = false;
/*      */       }
/*      */ 
/*  478 */       if (this.doingUpdates)
/*  479 */         this.doingUpdates = false;
/*      */       boolean b;
/*  482 */       if (row == 1) {
/*  483 */         b = first();
/*      */       }
/*      */       else
/*      */       {
/*      */         boolean b;
/*  484 */         if (row == -1) {
/*  485 */           b = last();
/*      */         }
/*      */         else
/*      */         {
/*      */           boolean b;
/*  486 */           if (row > this.rowData.size()) {
/*  487 */             afterLast();
/*  488 */             b = false;
/*      */           }
/*      */           else
/*      */           {
/*      */             boolean b;
/*  490 */             if (row < 0)
/*      */             {
/*  492 */               int newRowPosition = this.rowData.size() + row + 1;
/*      */               boolean b;
/*  494 */               if (newRowPosition <= 0) {
/*  495 */                 beforeFirst();
/*  496 */                 b = false;
/*      */               } else {
/*  498 */                 b = absolute(newRowPosition);
/*      */               }
/*      */             } else {
/*  501 */               row--;
/*  502 */               this.rowData.setCurrentRow(row);
/*  503 */               this.thisRow = this.rowData.getAt(row);
/*  504 */               b = true;
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*  509 */     return b;
/*      */   }
/*      */ 
/*      */   public void afterLast()
/*      */     throws SQLException
/*      */   {
/*  525 */     checkClosed();
/*      */ 
/*  527 */     if (this.onInsertRow) {
/*  528 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/*  531 */     if (this.doingUpdates) {
/*  532 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/*  535 */     if (this.rowData.size() != 0) {
/*  536 */       this.rowData.afterLast();
/*  537 */       this.thisRow = null;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void beforeFirst()
/*      */     throws SQLException
/*      */   {
/*  554 */     checkClosed();
/*      */ 
/*  556 */     if (this.onInsertRow) {
/*  557 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/*  560 */     if (this.doingUpdates) {
/*  561 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/*  564 */     if (this.rowData.size() == 0) {
/*  565 */       return;
/*      */     }
/*      */ 
/*  568 */     this.rowData.beforeFirst();
/*  569 */     this.thisRow = null;
/*      */   }
/*      */ 
/*      */   protected void buildIndexMapping()
/*      */     throws SQLException
/*      */   {
/*  580 */     int numFields = this.fields.length;
/*  581 */     this.columnNameToIndex = new HashMap(numFields);
/*  582 */     this.fullColumnNameToIndex = new HashMap(numFields);
/*      */ 
/*  596 */     for (int i = numFields - 1; i >= 0; i--) {
/*  597 */       Integer index = new Integer(i);
/*  598 */       String columnName = this.fields[i].getName();
/*  599 */       String fullColumnName = this.fields[i].getFullName();
/*      */ 
/*  601 */       if (columnName != null) {
/*  602 */         this.columnNameToIndex.put(columnName, index);
/*  603 */         this.columnNameToIndex.put(columnName.toUpperCase(), index);
/*  604 */         this.columnNameToIndex.put(columnName.toLowerCase(), index);
/*      */       }
/*      */ 
/*  607 */       if (fullColumnName != null) {
/*  608 */         this.fullColumnNameToIndex.put(fullColumnName, index);
/*  609 */         this.fullColumnNameToIndex.put(fullColumnName.toUpperCase(), index);
/*      */ 
/*  611 */         this.fullColumnNameToIndex.put(fullColumnName.toLowerCase(), index);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  617 */     this.hasBuiltIndexMapping = true;
/*      */   }
/*      */ 
/*      */   public void cancelRowUpdates()
/*      */     throws SQLException
/*      */   {
/*  633 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   protected final void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  643 */     if (this.isClosed)
/*  644 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000");
/*      */   }
/*      */ 
/*      */   protected final void checkColumnBounds(int columnIndex)
/*      */     throws SQLException
/*      */   {
/*  661 */     if ((columnIndex < 1) || (columnIndex > this.fields.length)) {
/*  662 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */     }
/*      */ 
/*  669 */     if ((this.profileSql) || (this.useUsageAdvisor))
/*  670 */       this.columnUsed[(columnIndex - 1)] = true;
/*      */   }
/*      */ 
/*      */   protected void checkRowPos()
/*      */     throws SQLException
/*      */   {
/*  682 */     checkClosed();
/*      */ 
/*  684 */     if ((!this.rowData.isDynamic()) && (this.rowData.size() == 0)) {
/*  685 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_operation_on_empty_result_set"), "S1000");
/*      */     }
/*      */ 
/*  691 */     if (this.rowData.isBeforeFirst()) {
/*  692 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Before_start_of_result_set_146"), "S1000");
/*      */     }
/*      */ 
/*  697 */     if (this.rowData.isAfterLast())
/*  698 */       throw SQLError.createSQLException(Messages.getString("ResultSet.After_end_of_result_set_148"), "S1000");
/*      */   }
/*      */ 
/*      */   protected void clearNextResult()
/*      */   {
/*  709 */     this.nextResultSet = null;
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  720 */     this.warningChain = null;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  741 */     realClose(true);
/*      */   }
/*      */ 
/*      */   private int convertToZeroWithEmptyCheck()
/*      */     throws SQLException
/*      */   {
/*  748 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  749 */       return 0;
/*      */     }
/*      */ 
/*  752 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018");
/*      */   }
/*      */ 
/*      */   private String convertToZeroLiteralStringWithEmptyCheck()
/*      */     throws SQLException
/*      */   {
/*  759 */     if (this.connection.getEmptyStringsConvertToZero()) {
/*  760 */       return "0";
/*      */     }
/*      */ 
/*  763 */     throw SQLError.createSQLException("Can't convert empty string ('') to numeric", "22018");
/*      */   }
/*      */ 
/*      */   protected final ResultSet copy()
/*      */     throws SQLException
/*      */   {
/*  771 */     ResultSet rs = new ResultSet(this.catalog, this.fields, this.rowData, this.connection, this.owningStatement);
/*      */ 
/*  774 */     return rs;
/*      */   }
/*      */ 
/*      */   protected void redefineFieldsForDBMD(Field[] f) {
/*  778 */     this.fields = f;
/*      */ 
/*  780 */     for (int i = 0; i < this.fields.length; i++)
/*  781 */       this.fields[i].setUseOldNameMetadata(true);
/*      */   }
/*      */ 
/*      */   public void deleteRow()
/*      */     throws SQLException
/*      */   {
/*  796 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   private String extractStringFromNativeColumn(int columnIndex, int mysqlType)
/*      */     throws SQLException
/*      */   {
/*  808 */     int columnIndexMinusOne = columnIndex - 1;
/*      */ 
/*  810 */     this.wasNullFlag = false;
/*      */ 
/*  812 */     if ((this.thisRow[columnIndexMinusOne] instanceof String)) {
/*  813 */       return (String)this.thisRow[columnIndexMinusOne];
/*      */     }
/*      */ 
/*  816 */     if (this.thisRow[columnIndexMinusOne] == null) {
/*  817 */       this.wasNullFlag = true;
/*      */ 
/*  819 */       return null;
/*      */     }
/*      */ 
/*  822 */     this.wasNullFlag = false;
/*      */ 
/*  824 */     String stringVal = null;
/*      */ 
/*  826 */     if ((this.connection != null) && (this.connection.getUseUnicode())) {
/*      */       try {
/*  828 */         String encoding = this.fields[columnIndexMinusOne].getCharacterSet();
/*      */ 
/*  831 */         if (encoding == null) {
/*  832 */           stringVal = new String((byte[])this.thisRow[columnIndexMinusOne]);
/*      */         }
/*      */         else {
/*  835 */           SingleByteCharsetConverter converter = this.connection.getCharsetConverter(encoding);
/*      */ 
/*  838 */           if (converter != null) {
/*  839 */             stringVal = converter.toString((byte[])this.thisRow[columnIndexMinusOne]);
/*      */           }
/*      */           else {
/*  842 */             stringVal = new String((byte[])this.thisRow[columnIndexMinusOne], encoding);
/*      */           }
/*      */         }
/*      */       }
/*      */       catch (UnsupportedEncodingException E)
/*      */       {
/*  848 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Unsupported_character_encoding____138") + this.connection.getEncoding() + "'.", "0S100");
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/*  854 */       stringVal = StringUtils.toAsciiString((byte[])this.thisRow[columnIndexMinusOne]);
/*      */     }
/*      */ 
/*  858 */     return stringVal;
/*      */   }
/*      */ 
/*      */   private Date fastDateCreate(Calendar cal, int year, int month, int day)
/*      */   {
/*  863 */     if (cal == null) {
/*  864 */       cal = this.fastDateCal;
/*      */     }
/*      */ 
/*  867 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */ 
/*  869 */     return TimeUtil.fastDateCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day);
/*      */   }
/*      */ 
/*      */   private Time fastTimeCreate(Calendar cal, int hour, int minute, int second)
/*      */     throws SQLException
/*      */   {
/*  876 */     if (cal == null) {
/*  877 */       cal = this.fastDateCal;
/*      */     }
/*      */ 
/*  880 */     return TimeUtil.fastTimeCreate(cal, hour, minute, second);
/*      */   }
/*      */ 
/*      */   private Timestamp fastTimestampCreate(Calendar cal, int year, int month, int day, int hour, int minute, int seconds, int secondsPart)
/*      */   {
/*  886 */     if (cal == null) {
/*  887 */       cal = this.fastDateCal;
/*      */     }
/*      */ 
/*  890 */     boolean useGmtMillis = this.connection.getUseGmtMillisForDatetimes();
/*      */ 
/*  892 */     return TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? getGmtCalendar() : null, cal, year, month, day, hour, minute, seconds, secondsPart);
/*      */   }
/*      */ 
/*      */   public synchronized int findColumn(String columnName)
/*      */     throws SQLException
/*      */   {
/*  930 */     if (!this.hasBuiltIndexMapping) {
/*  931 */       buildIndexMapping();
/*      */     }
/*      */ 
/*  934 */     Integer index = (Integer)this.columnNameToIndex.get(columnName);
/*      */ 
/*  936 */     if (index == null) {
/*  937 */       index = (Integer)this.fullColumnNameToIndex.get(columnName);
/*      */     }
/*      */ 
/*  940 */     if (index != null) {
/*  941 */       return index.intValue() + 1;
/*      */     }
/*      */ 
/*  946 */     for (int i = 0; i < this.fields.length; i++) {
/*  947 */       if (this.fields[i].getName().equalsIgnoreCase(columnName))
/*  948 */         return i + 1;
/*  949 */       if (this.fields[i].getFullName().equalsIgnoreCase(columnName))
/*      */       {
/*  951 */         return i + 1;
/*      */       }
/*      */     }
/*      */ 
/*  955 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022");
/*      */   }
/*      */ 
/*      */   public boolean first()
/*      */     throws SQLException
/*      */   {
/*  975 */     checkClosed();
/*      */ 
/*  977 */     if (this.rowData.isEmpty()) {
/*  978 */       return false;
/*      */     }
/*      */ 
/*  981 */     if (this.onInsertRow) {
/*  982 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/*  985 */     if (this.doingUpdates) {
/*  986 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/*  989 */     this.rowData.beforeFirst();
/*  990 */     this.thisRow = this.rowData.next();
/*      */ 
/*  992 */     return true;
/*      */   }
/*      */ 
/*      */   public Array getArray(int i)
/*      */     throws SQLException
/*      */   {
/* 1009 */     checkColumnBounds(i);
/*      */ 
/* 1011 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Array getArray(String colName)
/*      */     throws SQLException
/*      */   {
/* 1028 */     return getArray(findColumn(colName));
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1057 */     checkRowPos();
/*      */ 
/* 1059 */     if (!this.isBinaryEncoded) {
/* 1060 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */ 
/* 1063 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public InputStream getAsciiStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1078 */     return getAsciiStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1095 */     if (!this.isBinaryEncoded) {
/* 1096 */       String stringVal = getString(columnIndex);
/*      */ 
/* 1099 */       if (stringVal != null) {
/* 1100 */         if (stringVal.length() == 0)
/*      */         {
/* 1102 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */ 
/* 1105 */           return val;
/*      */         }
/*      */         try
/*      */         {
/* 1109 */           BigDecimal val = new BigDecimal(stringVal);
/*      */ 
/* 1111 */           return val;
/*      */         } catch (NumberFormatException ex) {
/* 1113 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1121 */       return null;
/*      */     }
/*      */ 
/* 1124 */     return getNativeBigDecimal(columnIndex);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public BigDecimal getBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1145 */     if (!this.isBinaryEncoded) {
/* 1146 */       String stringVal = getString(columnIndex);
/*      */ 
/* 1149 */       if (stringVal != null) {
/* 1150 */         if (stringVal.length() == 0) {
/* 1151 */           BigDecimal val = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */           try
/*      */           {
/* 1155 */             return val.setScale(scale);
/*      */           } catch (ArithmeticException ex) {
/*      */             try {
/* 1158 */               return val.setScale(scale, 4);
/*      */             }
/*      */             catch (ArithmeticException arEx) {
/* 1161 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal____124") + stringVal + Messages.getString("ResultSet.___in_column__125") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/* 1177 */           val = new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/*      */           BigDecimal val;
/*      */           BigDecimal val;
/* 1179 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1180 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */ 
/* 1182 */             val = new BigDecimal(valueAsLong);
/*      */           } else {
/* 1184 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { new Integer(columnIndex), stringVal }), "S1009");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */         try
/*      */         {
/* 1193 */           return val.setScale(scale);
/*      */         }
/*      */         catch (ArithmeticException ex)
/*      */         {
/*      */           try
/*      */           {
/*      */             BigDecimal val;
/* 1196 */             return val.setScale(scale, 4);
/*      */           } catch (ArithmeticException arithEx) {
/* 1198 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { new Integer(columnIndex), stringVal }), "S1009");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1207 */       return null;
/*      */     }
/*      */ 
/* 1210 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1226 */     return getBigDecimal(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public BigDecimal getBigDecimal(String columnName, int scale)
/*      */     throws SQLException
/*      */   {
/* 1246 */     return getBigDecimal(findColumn(columnName), scale);
/*      */   }
/*      */ 
/*      */   private final BigDecimal getBigDecimalFromString(String stringVal, int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 1253 */     if (stringVal != null) {
/* 1254 */       if (stringVal.length() == 0) {
/* 1255 */         BigDecimal bdVal = new BigDecimal(convertToZeroLiteralStringWithEmptyCheck());
/*      */         try
/*      */         {
/* 1258 */           return bdVal.setScale(scale);
/*      */         } catch (ArithmeticException ex) {
/*      */           try {
/* 1261 */             return bdVal.setScale(scale, 4);
/*      */           } catch (ArithmeticException arEx) {
/* 1263 */             throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009");
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1274 */         return new BigDecimal(stringVal).setScale(scale);
/*      */       } catch (ArithmeticException ex) {
/*      */         try {
/* 1277 */           return new BigDecimal(stringVal).setScale(scale, 4);
/*      */         }
/*      */         catch (ArithmeticException arEx) {
/* 1280 */           throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */       catch (NumberFormatException ex)
/*      */       {
/* 1288 */         if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 1289 */           long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */           try
/*      */           {
/* 1292 */             return new BigDecimal(valueAsLong).setScale(scale);
/*      */           } catch (ArithmeticException arEx1) {
/*      */             try {
/* 1295 */               return new BigDecimal(valueAsLong).setScale(scale, 4);
/*      */             }
/*      */             catch (ArithmeticException arEx2) {
/* 1298 */               throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1307 */         if ((this.fields[(columnIndex - 1)].getMysqlType() == 1) && (this.connection.getTinyInt1isBit()) && (this.fields[(columnIndex - 1)].getLength() == 1L))
/*      */         {
/* 1309 */           return new BigDecimal(stringVal.equalsIgnoreCase("true") ? 1.0D : 0.0D).setScale(scale);
/*      */         }
/*      */ 
/* 1312 */         throw new SQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, new Integer(columnIndex) }), "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1320 */     return null;
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1341 */     checkRowPos();
/*      */ 
/* 1343 */     if (!this.isBinaryEncoded) {
/* 1344 */       byte[] b = getBytes(columnIndex);
/*      */ 
/* 1346 */       if (b != null) {
/* 1347 */         return new ByteArrayInputStream(b);
/*      */       }
/*      */ 
/* 1350 */       return null;
/*      */     }
/*      */ 
/* 1353 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public InputStream getBinaryStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1368 */     return getBinaryStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public java.sql.Blob getBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1383 */     if (!this.isBinaryEncoded) {
/* 1384 */       checkRowPos();
/*      */ 
/* 1386 */       checkColumnBounds(columnIndex);
/*      */ 
/* 1388 */       if ((columnIndex < 1) || (columnIndex > this.fields.length)) {
/* 1389 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 1397 */         if (this.thisRow[(columnIndex - 1)] == null)
/* 1398 */           this.wasNullFlag = true;
/*      */         else
/* 1400 */           this.wasNullFlag = false;
/*      */       }
/*      */       catch (NullPointerException ex) {
/* 1403 */         this.wasNullFlag = true;
/*      */       }
/*      */ 
/* 1406 */       if (this.wasNullFlag) {
/* 1407 */         return null;
/*      */       }
/*      */ 
/* 1410 */       if (!this.connection.getEmulateLocators()) {
/* 1411 */         return new Blob((byte[])this.thisRow[(columnIndex - 1)]);
/*      */       }
/*      */ 
/* 1414 */       return new BlobFromLocator(this, columnIndex);
/*      */     }
/*      */ 
/* 1417 */     return getNativeBlob(columnIndex);
/*      */   }
/*      */ 
/*      */   public java.sql.Blob getBlob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1432 */     return getBlob(findColumn(colName));
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1448 */     checkColumnBounds(columnIndex);
/*      */ 
/* 1455 */     int columnIndexMinusOne = columnIndex - 1;
/*      */ 
/* 1457 */     Field field = this.fields[columnIndexMinusOne];
/*      */ 
/* 1459 */     if (field.getMysqlType() == 16) {
/* 1460 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */ 
/* 1463 */     this.wasNullFlag = false;
/*      */ 
/* 1465 */     int sqlType = field.getSQLType();
/*      */ 
/* 1467 */     switch (sqlType) {
/*      */     case -7:
/*      */     case -6:
/*      */     case -5:
/*      */     case 2:
/*      */     case 3:
/*      */     case 4:
/*      */     case 5:
/*      */     case 6:
/*      */     case 7:
/*      */     case 8:
/*      */     case 16:
/* 1479 */       long boolVal = getLong(columnIndex, false);
/*      */ 
/* 1481 */       return (boolVal == -1L) || (boolVal > 0L);
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/*      */     case -1:
/*      */     case 0:
/*      */     case 1:
/*      */     case 9:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 13:
/*      */     case 14:
/* 1483 */     case 15: } if (this.connection.getPedantic())
/*      */     {
/* 1485 */       switch (sqlType) {
/*      */       case -4:
/*      */       case -3:
/*      */       case -2:
/*      */       case 70:
/*      */       case 91:
/*      */       case 92:
/*      */       case 93:
/*      */       case 2000:
/*      */       case 2002:
/*      */       case 2003:
/*      */       case 2004:
/*      */       case 2005:
/*      */       case 2006:
/* 1499 */         throw SQLError.createSQLException("Required type conversion not allowed", "22018");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1504 */     if ((sqlType == -2) || (sqlType == -3) || (sqlType == -4) || (sqlType == 2004))
/*      */     {
/* 1508 */       return byteArrayToBoolean(columnIndexMinusOne);
/*      */     }
/*      */ 
/* 1511 */     if (this.useUsageAdvisor) {
/* 1512 */       issueConversionViaParsingWarning("getBoolean()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 16, 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 1524 */     String stringVal = getString(columnIndex);
/*      */ 
/* 1526 */     return getBooleanFromString(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   private boolean byteArrayToBoolean(int columnIndexMinusOne)
/*      */   {
/* 1531 */     if (this.thisRow[columnIndexMinusOne] == null) {
/* 1532 */       this.wasNullFlag = true;
/*      */ 
/* 1534 */       return false;
/*      */     }
/*      */ 
/* 1537 */     this.wasNullFlag = false;
/*      */ 
/* 1539 */     if (((byte[])this.thisRow[columnIndexMinusOne]).length == 0) {
/* 1540 */       return false;
/*      */     }
/*      */ 
/* 1543 */     byte boolVal = ((byte[])this.thisRow[columnIndexMinusOne])[0];
/*      */ 
/* 1545 */     return (boolVal == -1) || (boolVal > 0);
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1560 */     return getBoolean(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final boolean getBooleanFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 1565 */     if ((stringVal != null) && (stringVal.length() > 0)) {
/* 1566 */       int c = Character.toLowerCase(stringVal.charAt(0));
/*      */ 
/* 1568 */       return (c == 116) || (c == 121) || (c == 49) || (stringVal.equals("-1"));
/*      */     }
/*      */ 
/* 1572 */     return false;
/*      */   }
/*      */ 
/*      */   public byte getByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1587 */     if (!this.isBinaryEncoded) {
/* 1588 */       String stringVal = getString(columnIndex);
/*      */ 
/* 1590 */       if ((this.wasNullFlag) || (stringVal == null)) {
/* 1591 */         return 0;
/*      */       }
/*      */ 
/* 1594 */       return getByteFromString(stringVal, columnIndex);
/*      */     }
/*      */ 
/* 1597 */     return getNativeByte(columnIndex);
/*      */   }
/*      */ 
/*      */   public byte getByte(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1612 */     return getByte(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final byte getByteFromString(String stringVal, int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1618 */     if ((stringVal != null) && (stringVal.length() == 0)) {
/* 1619 */       return (byte)convertToZeroWithEmptyCheck();
/*      */     }
/*      */ 
/* 1630 */     stringVal = stringVal.trim();
/*      */     try
/*      */     {
/* 1633 */       int decimalIndex = stringVal.indexOf(".");
/*      */ 
/* 1636 */       if (decimalIndex != -1) {
/* 1637 */         double valueAsDouble = Double.parseDouble(stringVal);
/*      */ 
/* 1639 */         if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 1640 */           (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D)))
/*      */         {
/* 1642 */           throwRangeException(stringVal, columnIndex, -6);
/*      */         }
/*      */ 
/* 1647 */         return (byte)(int)valueAsDouble;
/*      */       }
/*      */ 
/* 1650 */       long valueAsLong = Long.parseLong(stringVal);
/*      */ 
/* 1652 */       if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 1653 */         (valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/* 1655 */         throwRangeException(String.valueOf(valueAsLong), columnIndex, -6);
/*      */       }
/*      */ 
/* 1660 */       return (byte)(int)valueAsLong; } catch (NumberFormatException NFE) {
/*      */     }
/* 1662 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Value____173") + stringVal + Messages.getString("ResultSet.___is_out_of_range_[-127,127]_174"), "S1009");
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1687 */     return getBytes(columnIndex, false);
/*      */   }
/*      */ 
/*      */   protected byte[] getBytes(int columnIndex, boolean noConversion) throws SQLException
/*      */   {
/* 1692 */     if (!this.isBinaryEncoded) {
/* 1693 */       checkRowPos();
/*      */ 
/* 1695 */       checkColumnBounds(columnIndex);
/*      */       try
/*      */       {
/* 1698 */         if (this.thisRow[(columnIndex - 1)] == null)
/* 1699 */           this.wasNullFlag = true;
/*      */         else
/* 1701 */           this.wasNullFlag = false;
/*      */       }
/*      */       catch (NullPointerException E) {
/* 1704 */         this.wasNullFlag = true;
/*      */       } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 1706 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */       }
/*      */ 
/* 1713 */       if (this.wasNullFlag) {
/* 1714 */         return null;
/*      */       }
/*      */ 
/* 1717 */       return (byte[])this.thisRow[(columnIndex - 1)];
/*      */     }
/*      */ 
/* 1720 */     return getNativeBytes(columnIndex, noConversion);
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1735 */     return getBytes(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final byte[] getBytesFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 1740 */     if (stringVal != null) {
/* 1741 */       return StringUtils.getBytes(stringVal, this.connection.getEncoding(), this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */     }
/*      */ 
/* 1748 */     return null;
/*      */   }
/*      */ 
/*      */   private Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 1756 */     if (this.connection != null) {
/* 1757 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */ 
/* 1760 */     return new GregorianCalendar();
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1781 */     if (!this.isBinaryEncoded) {
/* 1782 */       String asString = getStringForClob(columnIndex);
/*      */ 
/* 1784 */       if (asString == null) {
/* 1785 */         return null;
/*      */       }
/*      */ 
/* 1788 */       return new StringReader(asString);
/*      */     }
/*      */ 
/* 1791 */     return getNativeCharacterStream(columnIndex);
/*      */   }
/*      */ 
/*      */   public Reader getCharacterStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1811 */     return getCharacterStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final Reader getCharacterStreamFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 1816 */     if (stringVal != null) {
/* 1817 */       return new StringReader(stringVal);
/*      */     }
/*      */ 
/* 1820 */     return null;
/*      */   }
/*      */ 
/*      */   public java.sql.Clob getClob(int i)
/*      */     throws SQLException
/*      */   {
/* 1835 */     if (!this.isBinaryEncoded) {
/* 1836 */       String asString = getStringForClob(i);
/*      */ 
/* 1838 */       if (asString == null) {
/* 1839 */         return null;
/*      */       }
/*      */ 
/* 1842 */       return new Clob(asString);
/*      */     }
/*      */ 
/* 1845 */     return getNativeClob(i);
/*      */   }
/*      */ 
/*      */   public java.sql.Clob getClob(String colName)
/*      */     throws SQLException
/*      */   {
/* 1860 */     return getClob(findColumn(colName));
/*      */   }
/*      */ 
/*      */   private final java.sql.Clob getClobFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 1865 */     return new Clob(stringVal);
/*      */   }
/*      */ 
/*      */   public int getConcurrency()
/*      */     throws SQLException
/*      */   {
/* 1878 */     return 1007;
/*      */   }
/*      */ 
/*      */   public String getCursorName()
/*      */     throws SQLException
/*      */   {
/* 1907 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00");
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 1924 */     return getDate(columnIndex, null);
/*      */   }
/*      */ 
/*      */   public Date getDate(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1945 */     if (this.isBinaryEncoded) {
/* 1946 */       return getNativeDate(columnIndex, cal != null ? cal.getTimeZone() : getDefaultTimeZone());
/*      */     }
/*      */ 
/* 1950 */     String stringVal = getStringInternal(columnIndex, false);
/*      */ 
/* 1952 */     if (stringVal == null) {
/* 1953 */       return null;
/*      */     }
/*      */ 
/* 1956 */     return getDateFromString(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName)
/*      */     throws SQLException
/*      */   {
/* 1972 */     return getDate(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public Date getDate(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1992 */     return getDate(findColumn(columnName), cal); } 
/*      */   private final Date getDateFromString(String stringVal, int columnIndex) throws SQLException { // Byte code:
/*      */     //   0: iconst_0
/*      */     //   1: istore_3
/*      */     //   2: iconst_0
/*      */     //   3: istore 4
/*      */     //   5: iconst_0
/*      */     //   6: istore 5
/*      */     //   8: aload_0
/*      */     //   9: iconst_0
/*      */     //   10: putfield 34	com/mysql/jdbc/ResultSet:wasNullFlag	Z
/*      */     //   13: aload_1
/*      */     //   14: ifnonnull +10 -> 24
/*      */     //   17: aload_0
/*      */     //   18: iconst_1
/*      */     //   19: putfield 34	com/mysql/jdbc/ResultSet:wasNullFlag	Z
/*      */     //   22: aconst_null
/*      */     //   23: areturn
/*      */     //   24: aload_1
/*      */     //   25: invokevirtual 213	java/lang/String:trim	()Ljava/lang/String;
/*      */     //   28: astore_1
/*      */     //   29: aload_1
/*      */     //   30: ldc 112
/*      */     //   32: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   35: ifne +42 -> 77
/*      */     //   38: aload_1
/*      */     //   39: ldc_w 256
/*      */     //   42: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   45: ifne +32 -> 77
/*      */     //   48: aload_1
/*      */     //   49: ldc_w 257
/*      */     //   52: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   55: ifne +22 -> 77
/*      */     //   58: aload_1
/*      */     //   59: ldc_w 258
/*      */     //   62: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   65: ifne +12 -> 77
/*      */     //   68: aload_1
/*      */     //   69: ldc 112
/*      */     //   71: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   74: ifeq +83 -> 157
/*      */     //   77: ldc_w 259
/*      */     //   80: aload_0
/*      */     //   81: getfield 39	com/mysql/jdbc/ResultSet:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   84: invokevirtual 260	com/mysql/jdbc/Connection:getZeroDateTimeBehavior	()Ljava/lang/String;
/*      */     //   87: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   90: ifeq +10 -> 100
/*      */     //   93: aload_0
/*      */     //   94: iconst_1
/*      */     //   95: putfield 34	com/mysql/jdbc/ResultSet:wasNullFlag	Z
/*      */     //   98: aconst_null
/*      */     //   99: areturn
/*      */     //   100: ldc_w 261
/*      */     //   103: aload_0
/*      */     //   104: getfield 39	com/mysql/jdbc/ResultSet:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   107: invokevirtual 260	com/mysql/jdbc/Connection:getZeroDateTimeBehavior	()Ljava/lang/String;
/*      */     //   110: invokevirtual 208	java/lang/String:equals	(Ljava/lang/Object;)Z
/*      */     //   113: ifeq +35 -> 148
/*      */     //   116: new 125	java/lang/StringBuffer
/*      */     //   119: dup
/*      */     //   120: invokespecial 126	java/lang/StringBuffer:<init>	()V
/*      */     //   123: ldc_w 262
/*      */     //   126: invokevirtual 128	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   129: aload_1
/*      */     //   130: invokevirtual 128	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   133: ldc_w 263
/*      */     //   136: invokevirtual 128	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   139: invokevirtual 131	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   142: ldc 78
/*      */     //   144: invokestatic 79	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   147: athrow
/*      */     //   148: aload_0
/*      */     //   149: aconst_null
/*      */     //   150: iconst_1
/*      */     //   151: iconst_1
/*      */     //   152: iconst_1
/*      */     //   153: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   156: areturn
/*      */     //   157: aload_0
/*      */     //   158: getfield 38	com/mysql/jdbc/ResultSet:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   161: iload_2
/*      */     //   162: iconst_1
/*      */     //   163: isub
/*      */     //   164: aaload
/*      */     //   165: invokevirtual 174	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   168: bipush 7
/*      */     //   170: if_icmpne +364 -> 534
/*      */     //   173: aload_1
/*      */     //   174: invokevirtual 158	java/lang/String:length	()I
/*      */     //   177: tableswitch	default:+326 -> 503, 2:+292->469, 3:+326->503, 4:+246->423, 5:+326->503, 6:+187->364, 7:+326->503, 8:+141->318, 9:+326->503, 10:+187->364, 11:+326->503, 12:+187->364, 13:+326->503, 14:+141->318, 15:+326->503, 16:+326->503, 17:+326->503, 18:+326->503, 19:+95->272, 20:+326->503, 21:+95->272
/*      */     //   273: iconst_0
/*      */     //   274: iconst_4
/*      */     //   275: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   278: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   281: istore_3
/*      */     //   282: aload_1
/*      */     //   283: iconst_5
/*      */     //   284: bipush 7
/*      */     //   286: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   289: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   292: istore 4
/*      */     //   294: aload_1
/*      */     //   295: bipush 8
/*      */     //   297: bipush 10
/*      */     //   299: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   302: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   305: istore 5
/*      */     //   307: aload_0
/*      */     //   308: aconst_null
/*      */     //   309: iload_3
/*      */     //   310: iload 4
/*      */     //   312: iload 5
/*      */     //   314: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   317: areturn
/*      */     //   318: aload_1
/*      */     //   319: iconst_0
/*      */     //   320: iconst_4
/*      */     //   321: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   324: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   327: istore_3
/*      */     //   328: aload_1
/*      */     //   329: iconst_4
/*      */     //   330: bipush 6
/*      */     //   332: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   335: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   338: istore 4
/*      */     //   340: aload_1
/*      */     //   341: bipush 6
/*      */     //   343: bipush 8
/*      */     //   345: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   348: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   351: istore 5
/*      */     //   353: aload_0
/*      */     //   354: aconst_null
/*      */     //   355: iload_3
/*      */     //   356: iload 4
/*      */     //   358: iload 5
/*      */     //   360: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   363: areturn
/*      */     //   364: aload_1
/*      */     //   365: iconst_0
/*      */     //   366: iconst_2
/*      */     //   367: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   370: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   373: istore_3
/*      */     //   374: iload_3
/*      */     //   375: bipush 69
/*      */     //   377: if_icmpgt +8 -> 385
/*      */     //   380: iload_3
/*      */     //   381: bipush 100
/*      */     //   383: iadd
/*      */     //   384: istore_3
/*      */     //   385: aload_1
/*      */     //   386: iconst_2
/*      */     //   387: iconst_4
/*      */     //   388: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   391: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   394: istore 4
/*      */     //   396: aload_1
/*      */     //   397: iconst_4
/*      */     //   398: bipush 6
/*      */     //   400: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   403: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   406: istore 5
/*      */     //   408: aload_0
/*      */     //   409: aconst_null
/*      */     //   410: iload_3
/*      */     //   411: sipush 1900
/*      */     //   414: iadd
/*      */     //   415: iload 4
/*      */     //   417: iload 5
/*      */     //   419: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   422: areturn
/*      */     //   423: aload_1
/*      */     //   424: iconst_0
/*      */     //   425: iconst_4
/*      */     //   426: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   429: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   432: istore_3
/*      */     //   433: iload_3
/*      */     //   434: bipush 69
/*      */     //   436: if_icmpgt +8 -> 444
/*      */     //   439: iload_3
/*      */     //   440: bipush 100
/*      */     //   442: iadd
/*      */     //   443: istore_3
/*      */     //   444: aload_1
/*      */     //   445: iconst_2
/*      */     //   446: iconst_4
/*      */     //   447: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   450: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   453: istore 4
/*      */     //   455: aload_0
/*      */     //   456: aconst_null
/*      */     //   457: iload_3
/*      */     //   458: sipush 1900
/*      */     //   461: iadd
/*      */     //   462: iload 4
/*      */     //   464: iconst_1
/*      */     //   465: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   468: areturn
/*      */     //   469: aload_1
/*      */     //   470: iconst_0
/*      */     //   471: iconst_2
/*      */     //   472: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   475: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   478: istore_3
/*      */     //   479: iload_3
/*      */     //   480: bipush 69
/*      */     //   482: if_icmpgt +8 -> 490
/*      */     //   485: iload_3
/*      */     //   486: bipush 100
/*      */     //   488: iadd
/*      */     //   489: istore_3
/*      */     //   490: aload_0
/*      */     //   491: aconst_null
/*      */     //   492: iload_3
/*      */     //   493: sipush 1900
/*      */     //   496: iadd
/*      */     //   497: iconst_1
/*      */     //   498: iconst_1
/*      */     //   499: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   502: areturn
/*      */     //   503: ldc_w 267
/*      */     //   506: iconst_2
/*      */     //   507: anewarray 100	java/lang/Object
/*      */     //   510: dup
/*      */     //   511: iconst_0
/*      */     //   512: aload_1
/*      */     //   513: aastore
/*      */     //   514: dup
/*      */     //   515: iconst_1
/*      */     //   516: new 90	java/lang/Integer
/*      */     //   519: dup
/*      */     //   520: iload_2
/*      */     //   521: invokespecial 91	java/lang/Integer:<init>	(I)V
/*      */     //   524: aastore
/*      */     //   525: invokestatic 101	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   528: ldc 78
/*      */     //   530: invokestatic 79	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   533: athrow
/*      */     //   534: aload_0
/*      */     //   535: getfield 38	com/mysql/jdbc/ResultSet:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   538: iload_2
/*      */     //   539: iconst_1
/*      */     //   540: isub
/*      */     //   541: aaload
/*      */     //   542: invokevirtual 174	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   545: bipush 13
/*      */     //   547: if_icmpne +63 -> 610
/*      */     //   550: aload_1
/*      */     //   551: invokevirtual 158	java/lang/String:length	()I
/*      */     //   554: iconst_2
/*      */     //   555: if_icmpeq +11 -> 566
/*      */     //   558: aload_1
/*      */     //   559: invokevirtual 158	java/lang/String:length	()I
/*      */     //   562: iconst_1
/*      */     //   563: if_icmpne +28 -> 591
/*      */     //   566: aload_1
/*      */     //   567: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   570: istore_3
/*      */     //   571: iload_3
/*      */     //   572: bipush 69
/*      */     //   574: if_icmpgt +8 -> 582
/*      */     //   577: iload_3
/*      */     //   578: bipush 100
/*      */     //   580: iadd
/*      */     //   581: istore_3
/*      */     //   582: iload_3
/*      */     //   583: sipush 1900
/*      */     //   586: iadd
/*      */     //   587: istore_3
/*      */     //   588: goto +13 -> 601
/*      */     //   591: aload_1
/*      */     //   592: iconst_0
/*      */     //   593: iconst_4
/*      */     //   594: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   597: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   600: istore_3
/*      */     //   601: aload_0
/*      */     //   602: aconst_null
/*      */     //   603: iload_3
/*      */     //   604: iconst_1
/*      */     //   605: iconst_1
/*      */     //   606: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   609: areturn
/*      */     //   610: aload_0
/*      */     //   611: getfield 38	com/mysql/jdbc/ResultSet:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   614: iload_2
/*      */     //   615: iconst_1
/*      */     //   616: isub
/*      */     //   617: aaload
/*      */     //   618: invokevirtual 174	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   621: bipush 11
/*      */     //   623: if_icmpne +14 -> 637
/*      */     //   626: aload_0
/*      */     //   627: aconst_null
/*      */     //   628: sipush 1970
/*      */     //   631: iconst_1
/*      */     //   632: iconst_1
/*      */     //   633: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   636: areturn
/*      */     //   637: aload_1
/*      */     //   638: invokevirtual 158	java/lang/String:length	()I
/*      */     //   641: bipush 10
/*      */     //   643: if_icmpge +34 -> 677
/*      */     //   646: ldc_w 267
/*      */     //   649: iconst_2
/*      */     //   650: anewarray 100	java/lang/Object
/*      */     //   653: dup
/*      */     //   654: iconst_0
/*      */     //   655: aload_1
/*      */     //   656: aastore
/*      */     //   657: dup
/*      */     //   658: iconst_1
/*      */     //   659: new 90	java/lang/Integer
/*      */     //   662: dup
/*      */     //   663: iload_2
/*      */     //   664: invokespecial 91	java/lang/Integer:<init>	(I)V
/*      */     //   667: aastore
/*      */     //   668: invokestatic 101	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   671: ldc 78
/*      */     //   673: invokestatic 79	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   676: athrow
/*      */     //   677: aload_1
/*      */     //   678: invokevirtual 158	java/lang/String:length	()I
/*      */     //   681: bipush 18
/*      */     //   683: if_icmpeq +41 -> 724
/*      */     //   686: aload_1
/*      */     //   687: iconst_0
/*      */     //   688: iconst_4
/*      */     //   689: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   692: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   695: istore_3
/*      */     //   696: aload_1
/*      */     //   697: iconst_5
/*      */     //   698: bipush 7
/*      */     //   700: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   703: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   706: istore 4
/*      */     //   708: aload_1
/*      */     //   709: bipush 8
/*      */     //   711: bipush 10
/*      */     //   713: invokevirtual 265	java/lang/String:substring	(II)Ljava/lang/String;
/*      */     //   716: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   719: istore 5
/*      */     //   721: goto +45 -> 766
/*      */     //   724: new 268	java/util/StringTokenizer
/*      */     //   727: dup
/*      */     //   728: aload_1
/*      */     //   729: ldc_w 269
/*      */     //   732: invokespecial 270	java/util/StringTokenizer:<init>	(Ljava/lang/String;Ljava/lang/String;)V
/*      */     //   735: astore 6
/*      */     //   737: aload 6
/*      */     //   739: invokevirtual 271	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
/*      */     //   742: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   745: istore_3
/*      */     //   746: aload 6
/*      */     //   748: invokevirtual 271	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
/*      */     //   751: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   754: istore 4
/*      */     //   756: aload 6
/*      */     //   758: invokevirtual 271	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
/*      */     //   761: invokestatic 266	java/lang/Integer:parseInt	(Ljava/lang/String;)I
/*      */     //   764: istore 5
/*      */     //   766: aload_0
/*      */     //   767: aconst_null
/*      */     //   768: iload_3
/*      */     //   769: iload 4
/*      */     //   771: iload 5
/*      */     //   773: invokespecial 264	com/mysql/jdbc/ResultSet:fastDateCreate	(Ljava/util/Calendar;III)Ljava/sql/Date;
/*      */     //   776: areturn
/*      */     //   777: astore 6
/*      */     //   779: aload 6
/*      */     //   781: athrow
/*      */     //   782: astore 6
/*      */     //   784: ldc_w 267
/*      */     //   787: iconst_2
/*      */     //   788: anewarray 100	java/lang/Object
/*      */     //   791: dup
/*      */     //   792: iconst_0
/*      */     //   793: aload_1
/*      */     //   794: aastore
/*      */     //   795: dup
/*      */     //   796: iconst_1
/*      */     //   797: new 90	java/lang/Integer
/*      */     //   800: dup
/*      */     //   801: iload_2
/*      */     //   802: invokespecial 91	java/lang/Integer:<init>	(I)V
/*      */     //   805: aastore
/*      */     //   806: invokestatic 101	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   809: ldc 78
/*      */     //   811: invokestatic 79	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   814: athrow
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   8	23	777	java/sql/SQLException
/*      */     //   24	99	777	java/sql/SQLException
/*      */     //   100	156	777	java/sql/SQLException
/*      */     //   157	317	777	java/sql/SQLException
/*      */     //   318	363	777	java/sql/SQLException
/*      */     //   364	422	777	java/sql/SQLException
/*      */     //   423	468	777	java/sql/SQLException
/*      */     //   469	502	777	java/sql/SQLException
/*      */     //   503	609	777	java/sql/SQLException
/*      */     //   610	636	777	java/sql/SQLException
/*      */     //   637	776	777	java/sql/SQLException
/*      */     //   8	23	782	java/lang/Exception
/*      */     //   24	99	782	java/lang/Exception
/*      */     //   100	156	782	java/lang/Exception
/*      */     //   157	317	782	java/lang/Exception
/*      */     //   318	363	782	java/lang/Exception
/*      */     //   364	422	782	java/lang/Exception
/*      */     //   423	468	782	java/lang/Exception
/*      */     //   469	502	782	java/lang/Exception
/*      */     //   503	609	782	java/lang/Exception
/*      */     //   610	636	782	java/lang/Exception
/*      */     //   637	776	782	java/lang/Exception } 
/* 2158 */   private TimeZone getDefaultTimeZone() { if (this.defaultTimeZone == null) {
/* 2159 */       this.defaultTimeZone = TimeZone.getDefault();
/*      */     }
/*      */ 
/* 2162 */     return this.defaultTimeZone;
/*      */   }
/*      */ 
/*      */   public double getDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2177 */     if (!this.isBinaryEncoded) {
/* 2178 */       return getDoubleInternal(columnIndex);
/*      */     }
/*      */ 
/* 2181 */     return getNativeDouble(columnIndex);
/*      */   }
/*      */ 
/*      */   public double getDouble(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2196 */     return getDouble(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final double getDoubleFromString(String stringVal, int columnIndex) throws SQLException
/*      */   {
/* 2201 */     return getDoubleInternal(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   protected double getDoubleInternal(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 2217 */     return getDoubleInternal(getString(colIndex), colIndex); } 
/*      */   protected double getDoubleInternal(String stringVal, int colIndex) throws SQLException { // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: ifnonnull +5 -> 6
/*      */     //   4: dconst_0
/*      */     //   5: dreturn
/*      */     //   6: aload_1
/*      */     //   7: invokevirtual 158	java/lang/String:length	()I
/*      */     //   10: ifne +9 -> 19
/*      */     //   13: aload_0
/*      */     //   14: invokespecial 212	com/mysql/jdbc/ResultSet:convertToZeroWithEmptyCheck	()I
/*      */     //   17: i2d
/*      */     //   18: dreturn
/*      */     //   19: aload_1
/*      */     //   20: invokestatic 216	java/lang/Double:parseDouble	(Ljava/lang/String;)D
/*      */     //   23: dstore_3
/*      */     //   24: aload_0
/*      */     //   25: getfield 31	com/mysql/jdbc/ResultSet:useStrictFloatingPoint	Z
/*      */     //   28: ifeq +120 -> 148
/*      */     //   31: dload_3
/*      */     //   32: ldc2_w 279
/*      */     //   35: dcmpl
/*      */     //   36: ifne +10 -> 46
/*      */     //   39: ldc2_w 281
/*      */     //   42: dstore_3
/*      */     //   43: goto +105 -> 148
/*      */     //   46: dload_3
/*      */     //   47: ldc2_w 283
/*      */     //   50: dcmpl
/*      */     //   51: ifne +10 -> 61
/*      */     //   54: ldc2_w 285
/*      */     //   57: dstore_3
/*      */     //   58: goto +90 -> 148
/*      */     //   61: dload_3
/*      */     //   62: ldc2_w 287
/*      */     //   65: dcmpl
/*      */     //   66: ifne +10 -> 76
/*      */     //   69: ldc2_w 289
/*      */     //   72: dstore_3
/*      */     //   73: goto +75 -> 148
/*      */     //   76: dload_3
/*      */     //   77: ldc2_w 291
/*      */     //   80: dcmpl
/*      */     //   81: ifne +10 -> 91
/*      */     //   84: ldc2_w 293
/*      */     //   87: dstore_3
/*      */     //   88: goto +60 -> 148
/*      */     //   91: dload_3
/*      */     //   92: ldc2_w 295
/*      */     //   95: dcmpl
/*      */     //   96: ifne +10 -> 106
/*      */     //   99: ldc2_w 293
/*      */     //   102: dstore_3
/*      */     //   103: goto +45 -> 148
/*      */     //   106: dload_3
/*      */     //   107: ldc2_w 297
/*      */     //   110: dcmpl
/*      */     //   111: ifne +10 -> 121
/*      */     //   114: ldc2_w 299
/*      */     //   117: dstore_3
/*      */     //   118: goto +30 -> 148
/*      */     //   121: dload_3
/*      */     //   122: ldc2_w 301
/*      */     //   125: dcmpl
/*      */     //   126: ifne +10 -> 136
/*      */     //   129: ldc2_w 303
/*      */     //   132: dstore_3
/*      */     //   133: goto +15 -> 148
/*      */     //   136: dload_3
/*      */     //   137: ldc2_w 305
/*      */     //   140: dcmpl
/*      */     //   141: ifne +7 -> 148
/*      */     //   144: ldc2_w 299
/*      */     //   147: dstore_3
/*      */     //   148: dload_3
/*      */     //   149: dreturn
/*      */     //   150: astore_3
/*      */     //   151: aload_0
/*      */     //   152: getfield 38	com/mysql/jdbc/ResultSet:fields	[Lcom/mysql/jdbc/Field;
/*      */     //   155: iload_2
/*      */     //   156: iconst_1
/*      */     //   157: isub
/*      */     //   158: aaload
/*      */     //   159: invokevirtual 174	com/mysql/jdbc/Field:getMysqlType	()I
/*      */     //   162: bipush 16
/*      */     //   164: if_icmpne +14 -> 178
/*      */     //   167: aload_0
/*      */     //   168: iload_2
/*      */     //   169: invokespecial 175	com/mysql/jdbc/ResultSet:getNumericRepresentationOfSQLBitType	(I)J
/*      */     //   172: lstore 4
/*      */     //   174: lload 4
/*      */     //   176: l2d
/*      */     //   177: dreturn
/*      */     //   178: ldc_w 307
/*      */     //   181: iconst_2
/*      */     //   182: anewarray 100	java/lang/Object
/*      */     //   185: dup
/*      */     //   186: iconst_0
/*      */     //   187: aload_1
/*      */     //   188: aastore
/*      */     //   189: dup
/*      */     //   190: iconst_1
/*      */     //   191: new 90	java/lang/Integer
/*      */     //   194: dup
/*      */     //   195: iload_2
/*      */     //   196: invokespecial 91	java/lang/Integer:<init>	(I)V
/*      */     //   199: aastore
/*      */     //   200: invokestatic 101	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
/*      */     //   203: ldc 78
/*      */     //   205: invokestatic 79	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   208: athrow
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	5	150	java/lang/NumberFormatException
/*      */     //   6	18	150	java/lang/NumberFormatException
/*      */     //   19	149	150	java/lang/NumberFormatException } 
/* 2294 */   public int getFetchDirection() throws SQLException { return this.fetchDirection;
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 2306 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */   protected char getFirstCharOfQuery()
/*      */   {
/* 2316 */     return this.firstCharOfQuery;
/*      */   }
/*      */ 
/*      */   public float getFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2331 */     if (!this.isBinaryEncoded) {
/* 2332 */       String val = null;
/*      */ 
/* 2334 */       val = getString(columnIndex);
/*      */ 
/* 2336 */       return getFloatFromString(val, columnIndex);
/*      */     }
/*      */ 
/* 2339 */     return getNativeFloat(columnIndex);
/*      */   }
/*      */ 
/*      */   public float getFloat(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2354 */     return getFloat(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final float getFloatFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 2360 */       if (val != null) {
/* 2361 */         if (val.length() == 0) {
/* 2362 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 2365 */         float f = Float.parseFloat(val);
/*      */ 
/* 2367 */         if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 2368 */           (f == 1.4E-45F) || (f == 3.4028235E+38F))) {
/* 2369 */           double valAsDouble = Double.parseDouble(val);
/*      */ 
/* 2375 */           if ((valAsDouble < 1.401298464324817E-045D - MIN_DIFF_PREC) || (valAsDouble > 3.402823466385289E+038D - MAX_DIFF_PREC))
/*      */           {
/* 2377 */             throwRangeException(String.valueOf(valAsDouble), columnIndex, 6);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2383 */         return f;
/*      */       }
/*      */ 
/* 2386 */       return 0.0F;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2389 */         Double valueAsDouble = new Double(val);
/* 2390 */         float valueAsFloat = valueAsDouble.floatValue();
/*      */ 
/* 2392 */         if (this.connection.getJdbcCompliantTruncationForReads())
/*      */         {
/* 2394 */           if (((this.connection.getJdbcCompliantTruncationForReads()) && (valueAsFloat == (1.0F / -1.0F))) || (valueAsFloat == (1.0F / 1.0F)))
/*      */           {
/* 2397 */             throwRangeException(valueAsDouble.toString(), columnIndex, 6);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2402 */         return valueAsFloat;
/*      */       }
/*      */       catch (NumberFormatException newNfe) {
/*      */       }
/*      */     }
/* 2407 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getFloat()_-____200") + val + Messages.getString("ResultSet.___in_column__201") + columnIndex, "S1009");
/*      */   }
/*      */ 
/*      */   public int getInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2428 */     checkRowPos();
/*      */ 
/* 2430 */     if (!this.isBinaryEncoded) {
/* 2431 */       if (this.connection.getUseFastIntParsing()) {
/* 2432 */         checkColumnBounds(columnIndex);
/*      */         try
/*      */         {
/* 2435 */           if (this.thisRow[(columnIndex - 1)] == null)
/* 2436 */             this.wasNullFlag = true;
/*      */           else
/* 2438 */             this.wasNullFlag = false;
/*      */         }
/*      */         catch (NullPointerException E) {
/* 2441 */           this.wasNullFlag = true;
/*      */         } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 2443 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */         }
/*      */ 
/* 2450 */         if (this.wasNullFlag) {
/* 2451 */           return 0;
/*      */         }
/*      */ 
/* 2454 */         byte[] intAsBytes = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 2456 */         if (intAsBytes.length == 0) {
/* 2457 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 2460 */         boolean needsFullParse = false;
/*      */ 
/* 2462 */         for (int i = 0; i < intAsBytes.length; i++) {
/* 2463 */           if (((char)intAsBytes[i] != 'e') && ((char)intAsBytes[i] != 'E'))
/*      */             continue;
/* 2465 */           needsFullParse = true;
/*      */ 
/* 2467 */           break;
/*      */         }
/*      */ 
/* 2471 */         if (!needsFullParse) {
/*      */           try {
/* 2473 */             return parseIntWithOverflowCheck(columnIndex, intAsBytes, null);
/*      */           }
/*      */           catch (NumberFormatException nfe)
/*      */           {
/*      */             try {
/* 2478 */               return parseIntAsDouble(columnIndex, new String(intAsBytes));
/*      */             }
/*      */             catch (NumberFormatException valueAsLong)
/*      */             {
/* 2484 */               if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 2485 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */ 
/* 2487 */                 if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */                 {
/* 2490 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */                 }
/*      */ 
/* 2494 */                 return (int)valueAsLong;
/*      */               }
/*      */ 
/* 2497 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + new String(intAsBytes) + "'", "S1009");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2507 */       String val = null;
/*      */       try
/*      */       {
/* 2510 */         val = getString(columnIndex);
/*      */ 
/* 2512 */         if (val != null) {
/* 2513 */           if (val.length() == 0) {
/* 2514 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */ 
/* 2517 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */           {
/* 2519 */             return Integer.parseInt(val);
/*      */           }
/*      */ 
/* 2523 */           return parseIntAsDouble(columnIndex, val);
/*      */         }
/*      */ 
/* 2526 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2529 */           return parseIntAsDouble(columnIndex, val);
/*      */         }
/*      */         catch (NumberFormatException valueAsLong)
/*      */         {
/* 2534 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 2535 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */ 
/* 2537 */             if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */             {
/* 2540 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */ 
/* 2544 */             return (int)valueAsLong;
/*      */           }
/*      */ 
/* 2547 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____74") + val + "'", "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2555 */     return getNativeInt(columnIndex);
/*      */   }
/*      */ 
/*      */   public int getInt(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2570 */     return getInt(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final int getIntFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 2576 */       if (val != null)
/*      */       {
/* 2578 */         if (val.length() == 0) {
/* 2579 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 2582 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */         {
/* 2592 */           val = val.trim();
/*      */ 
/* 2594 */           int valueAsInt = Integer.parseInt(val);
/*      */ 
/* 2596 */           if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 2597 */             (valueAsInt == -2147483648) || (valueAsInt == 2147483647)))
/*      */           {
/* 2599 */             long valueAsLong = Long.parseLong(val);
/*      */ 
/* 2601 */             if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))
/*      */             {
/* 2603 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 4);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 2610 */           return valueAsInt;
/*      */         }
/*      */ 
/* 2615 */         double valueAsDouble = Double.parseDouble(val);
/*      */ 
/* 2617 */         if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 2618 */           (valueAsDouble < -2147483648.0D) || (valueAsDouble > 2147483647.0D)))
/*      */         {
/* 2620 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/* 2625 */         return (int)valueAsDouble;
/*      */       }
/*      */ 
/* 2628 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 2631 */         double valueAsDouble = Double.parseDouble(val);
/*      */ 
/* 2633 */         if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 2634 */           (valueAsDouble < -2147483648.0D) || (valueAsDouble > 2147483647.0D)))
/*      */         {
/* 2636 */           throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */         }
/*      */ 
/* 2641 */         return (int)valueAsDouble;
/*      */       }
/*      */       catch (NumberFormatException newNfe) {
/*      */       }
/*      */     }
/* 2646 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getInt()_-____206") + val + Messages.getString("ResultSet.___in_column__207") + columnIndex, "S1009");
/*      */   }
/*      */ 
/*      */   public long getLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2666 */     return getLong(columnIndex, true);
/*      */   }
/*      */ 
/*      */   private long getLong(int columnIndex, boolean overflowCheck) throws SQLException {
/* 2670 */     if (!this.isBinaryEncoded) {
/* 2671 */       checkRowPos();
/*      */ 
/* 2673 */       if (this.connection.getUseFastIntParsing())
/*      */       {
/* 2675 */         checkColumnBounds(columnIndex);
/*      */         try
/*      */         {
/* 2678 */           if (this.thisRow[(columnIndex - 1)] == null)
/* 2679 */             this.wasNullFlag = true;
/*      */           else
/* 2681 */             this.wasNullFlag = false;
/*      */         }
/*      */         catch (NullPointerException E) {
/* 2684 */           this.wasNullFlag = true;
/*      */         } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 2686 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */         }
/*      */ 
/* 2693 */         if (this.wasNullFlag) {
/* 2694 */           return 0L;
/*      */         }
/*      */ 
/* 2697 */         byte[] longAsBytes = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 2699 */         if (longAsBytes.length == 0) {
/* 2700 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 2703 */         boolean needsFullParse = false;
/*      */ 
/* 2705 */         for (int i = 0; i < longAsBytes.length; i++) {
/* 2706 */           if (((char)longAsBytes[i] != 'e') && ((char)longAsBytes[i] != 'E'))
/*      */             continue;
/* 2708 */           needsFullParse = true;
/*      */ 
/* 2710 */           break;
/*      */         }
/*      */ 
/* 2714 */         if (!needsFullParse) {
/*      */           try {
/* 2716 */             return parseLongWithOverflowCheck(columnIndex, longAsBytes, null, overflowCheck);
/*      */           }
/*      */           catch (NumberFormatException nfe)
/*      */           {
/*      */             try {
/* 2721 */               return parseLongAsDouble(columnIndex, new String(longAsBytes));
/*      */             }
/*      */             catch (NumberFormatException newNfe)
/*      */             {
/* 2727 */               if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 2728 */                 return getNumericRepresentationOfSQLBitType(columnIndex);
/*      */               }
/*      */ 
/* 2731 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + new String(longAsBytes) + "'", "S1009");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2741 */       String val = null;
/*      */       try
/*      */       {
/* 2744 */         val = getString(columnIndex);
/*      */ 
/* 2746 */         if (val != null) {
/* 2747 */           if (val.length() == 0) {
/* 2748 */             return convertToZeroWithEmptyCheck();
/*      */           }
/*      */ 
/* 2751 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 2752 */             return parseLongWithOverflowCheck(columnIndex, null, val, overflowCheck);
/*      */           }
/*      */ 
/* 2757 */           return parseLongAsDouble(columnIndex, val);
/*      */         }
/*      */ 
/* 2760 */         return 0L;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 2763 */           return parseLongAsDouble(columnIndex, val);
/*      */         }
/*      */         catch (NumberFormatException newNfe)
/*      */         {
/* 2768 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____79") + val + "'", "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2776 */     return getNativeLong(columnIndex, overflowCheck, true);
/*      */   }
/*      */ 
/*      */   public long getLong(String columnName)
/*      */     throws SQLException
/*      */   {
/* 2791 */     return getLong(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final long getLongFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 2797 */       if (val != null)
/*      */       {
/* 2799 */         if (val.length() == 0) {
/* 2800 */           return convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 2803 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1)) {
/* 2804 */           return parseLongWithOverflowCheck(columnIndex, null, val, true);
/*      */         }
/*      */ 
/* 2808 */         return parseLongAsDouble(columnIndex, val);
/*      */       }
/*      */ 
/* 2811 */       return 0L;
/*      */     }
/*      */     catch (NumberFormatException nfe) {
/*      */       try {
/* 2815 */         return parseLongAsDouble(columnIndex, val);
/*      */       }
/*      */       catch (NumberFormatException newNfe) {
/*      */       }
/*      */     }
/* 2820 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getLong()_-____211") + val + Messages.getString("ResultSet.___in_column__212") + columnIndex, "S1009");
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/* 2839 */     checkClosed();
/*      */ 
/* 2841 */     return new ResultSetMetaData(this.fields, this.connection.getUseOldAliasMetadataBehavior());
/*      */   }
/*      */ 
/*      */   protected Array getNativeArray(int i)
/*      */     throws SQLException
/*      */   {
/* 2859 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   protected InputStream getNativeAsciiStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2889 */     checkRowPos();
/*      */ 
/* 2891 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2910 */     checkColumnBounds(columnIndex);
/*      */ 
/* 2912 */     int scale = this.fields[(columnIndex - 1)].getDecimals();
/*      */ 
/* 2914 */     return getNativeBigDecimal(columnIndex, scale);
/*      */   }
/*      */ 
/*      */   protected BigDecimal getNativeBigDecimal(int columnIndex, int scale)
/*      */     throws SQLException
/*      */   {
/* 2933 */     checkColumnBounds(columnIndex);
/*      */ 
/* 2935 */     String stringVal = null;
/*      */ 
/* 2937 */     Field f = this.fields[(columnIndex - 1)];
/*      */ 
/* 2939 */     if (this.thisRow[(columnIndex - 1)] == null) {
/* 2940 */       this.wasNullFlag = true;
/*      */ 
/* 2942 */       return null;
/*      */     }
/*      */ 
/* 2945 */     this.wasNullFlag = false;
/*      */ 
/* 2947 */     switch (f.getSQLType()) {
/*      */     case 2:
/*      */     case 3:
/* 2950 */       stringVal = StringUtils.toAsciiString((byte[])this.thisRow[(columnIndex - 1)]);
/*      */ 
/* 2952 */       break;
/*      */     default:
/* 2954 */       stringVal = getNativeString(columnIndex);
/*      */     }
/*      */ 
/* 2957 */     return getBigDecimalFromString(stringVal, columnIndex, scale);
/*      */   }
/*      */ 
/*      */   protected InputStream getNativeBinaryStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 2979 */     checkRowPos();
/*      */ 
/* 2981 */     byte[] b = getNativeBytes(columnIndex, false);
/*      */ 
/* 2983 */     if (b != null) {
/* 2984 */       return new ByteArrayInputStream(b);
/*      */     }
/*      */ 
/* 2987 */     return null;
/*      */   }
/*      */ 
/*      */   protected java.sql.Blob getNativeBlob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3002 */     checkRowPos();
/*      */ 
/* 3004 */     checkColumnBounds(columnIndex);
/*      */     try
/*      */     {
/* 3007 */       if (this.thisRow[(columnIndex - 1)] == null)
/* 3008 */         this.wasNullFlag = true;
/*      */       else
/* 3010 */         this.wasNullFlag = false;
/*      */     }
/*      */     catch (NullPointerException ex) {
/* 3013 */       this.wasNullFlag = true;
/*      */     }
/*      */ 
/* 3016 */     if (this.wasNullFlag) {
/* 3017 */       return null;
/*      */     }
/*      */ 
/* 3020 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */ 
/* 3022 */     byte[] dataAsBytes = null;
/*      */ 
/* 3024 */     switch (mysqlType) {
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/* 3029 */       dataAsBytes = (byte[])this.thisRow[(columnIndex - 1)];
/*      */     }
/*      */ 
/* 3032 */     dataAsBytes = getNativeBytes(columnIndex, false);
/*      */ 
/* 3035 */     if (!this.connection.getEmulateLocators()) {
/* 3036 */       return new Blob(dataAsBytes);
/*      */     }
/*      */ 
/* 3039 */     return new BlobFromLocator(this, columnIndex);
/*      */   }
/*      */ 
/*      */   protected byte getNativeByte(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3054 */     return getNativeByte(columnIndex, true);
/*      */   }
/*      */ 
/*      */   protected byte getNativeByte(int columnIndex, boolean overflowCheck) throws SQLException {
/* 3058 */     checkRowPos();
/*      */ 
/* 3060 */     checkColumnBounds(columnIndex);
/*      */ 
/* 3062 */     if (this.thisRow[(columnIndex - 1)] == null) {
/* 3063 */       this.wasNullFlag = true;
/*      */ 
/* 3065 */       return 0;
/*      */     }
/*      */     try
/*      */     {
/* 3069 */       if (this.thisRow[(columnIndex - 1)] == null)
/* 3070 */         this.wasNullFlag = true;
/*      */       else
/* 3072 */         this.wasNullFlag = false;
/*      */     }
/*      */     catch (NullPointerException E) {
/* 3075 */       this.wasNullFlag = true;
/*      */     }
/*      */ 
/* 3078 */     if (this.wasNullFlag) {
/* 3079 */       return 0;
/*      */     }
/*      */ 
/* 3082 */     columnIndex--;
/*      */ 
/* 3084 */     Field field = this.fields[columnIndex];
/*      */ 
/* 3086 */     switch (field.getMysqlType()) {
/*      */     case 16:
/* 3088 */       long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */ 
/* 3090 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/* 3093 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3097 */       return (byte)(int)valueAsLong;
/*      */     case 1:
/* 3099 */       byte valueAsByte = ((byte[])this.thisRow[columnIndex])[0];
/*      */ 
/* 3101 */       if (!field.isUnsigned()) {
/* 3102 */         return valueAsByte;
/*      */       }
/*      */ 
/* 3105 */       short valueAsShort = valueAsByte >= 0 ? (short)valueAsByte : (short)(valueAsByte + 256);
/*      */ 
/* 3108 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && 
/* 3109 */         (valueAsShort > 127)) {
/* 3110 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3115 */       return (byte)valueAsShort;
/*      */     case 2:
/*      */     case 13:
/* 3119 */       short valueAsShort = getNativeShort(columnIndex + 1);
/*      */ 
/* 3121 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3122 */         (valueAsShort < -128) || (valueAsShort > 127)))
/*      */       {
/* 3124 */         throwRangeException(String.valueOf(valueAsShort), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3129 */       return (byte)valueAsShort;
/*      */     case 3:
/*      */     case 9:
/* 3132 */       int valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */ 
/* 3134 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3135 */         (valueAsInt < -128) || (valueAsInt > 127))) {
/* 3136 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3141 */       return (byte)valueAsInt;
/*      */     case 4:
/* 3144 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */ 
/* 3146 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3147 */         (valueAsFloat < -128.0F) || (valueAsFloat > 127.0F)))
/*      */       {
/* 3150 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3155 */       return (byte)(int)valueAsFloat;
/*      */     case 5:
/* 3158 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */ 
/* 3160 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3161 */         (valueAsDouble < -128.0D) || (valueAsDouble > 127.0D)))
/*      */       {
/* 3163 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3168 */       return (byte)(int)valueAsDouble;
/*      */     case 8:
/* 3171 */       long valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */ 
/* 3173 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3174 */         (valueAsLong < -128L) || (valueAsLong > 127L)))
/*      */       {
/* 3176 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, -6);
/*      */       }
/*      */ 
/* 3181 */       return (byte)(int)valueAsLong;
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 14:
/* 3184 */     case 15: } if (this.useUsageAdvisor) {
/* 3185 */       issueConversionViaParsingWarning("getByte()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 3195 */     return getByteFromString(getNativeString(columnIndex + 1), columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected byte[] getNativeBytes(int columnIndex, boolean noConversion)
/*      */     throws SQLException
/*      */   {
/* 3217 */     checkRowPos();
/*      */ 
/* 3219 */     checkColumnBounds(columnIndex);
/*      */     try
/*      */     {
/* 3222 */       if (this.thisRow[(columnIndex - 1)] == null)
/* 3223 */         this.wasNullFlag = true;
/*      */       else
/* 3225 */         this.wasNullFlag = false;
/*      */     }
/*      */     catch (NullPointerException E) {
/* 3228 */       this.wasNullFlag = true;
/*      */     }
/*      */ 
/* 3231 */     if (this.wasNullFlag) {
/* 3232 */       return null;
/*      */     }
/*      */ 
/* 3235 */     Field field = this.fields[(columnIndex - 1)];
/*      */ 
/* 3237 */     int mysqlType = field.getMysqlType();
/*      */ 
/* 3241 */     if (noConversion) {
/* 3242 */       mysqlType = 252;
/*      */     }
/*      */ 
/* 3245 */     switch (mysqlType) {
/*      */     case 16:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/* 3251 */       return (byte[])this.thisRow[(columnIndex - 1)];
/*      */     }
/*      */ 
/* 3254 */     int sqlType = field.getSQLType();
/*      */ 
/* 3256 */     if ((sqlType == -3) || (sqlType == -2)) {
/* 3257 */       return (byte[])this.thisRow[(columnIndex - 1)];
/*      */     }
/*      */ 
/* 3260 */     return getBytesFromString(getNativeString(columnIndex), columnIndex);
/*      */   }
/*      */ 
/*      */   protected Reader getNativeCharacterStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3281 */     String asString = null;
/*      */ 
/* 3283 */     asString = getStringForClob(columnIndex);
/*      */ 
/* 3285 */     if (asString == null) {
/* 3286 */       return null;
/*      */     }
/* 3288 */     return getCharacterStreamFromString(asString, columnIndex);
/*      */   }
/*      */ 
/*      */   protected java.sql.Clob getNativeClob(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3303 */     String stringVal = getStringForClob(columnIndex);
/*      */ 
/* 3305 */     if (stringVal == null) {
/* 3306 */       return null;
/*      */     }
/*      */ 
/* 3309 */     return getClobFromString(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   private String getNativeConvertToString(int columnIndex, Field field)
/*      */     throws SQLException
/*      */   {
/* 3317 */     int sqlType = field.getSQLType();
/* 3318 */     int mysqlType = field.getMysqlType();
/*      */ 
/* 3320 */     switch (sqlType) {
/*      */     case -7:
/* 3322 */       return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex));
/*      */     case 16:
/* 3324 */       boolean booleanVal = getBoolean(columnIndex);
/*      */ 
/* 3326 */       if (this.wasNullFlag) {
/* 3327 */         return null;
/*      */       }
/*      */ 
/* 3330 */       return String.valueOf(booleanVal);
/*      */     case -6:
/* 3333 */       byte tinyintVal = getNativeByte(columnIndex, false);
/*      */ 
/* 3335 */       if (this.wasNullFlag) {
/* 3336 */         return null;
/*      */       }
/*      */ 
/* 3339 */       if ((!field.isUnsigned()) || (tinyintVal >= 0)) {
/* 3340 */         return String.valueOf(tinyintVal);
/*      */       }
/*      */ 
/* 3343 */       short unsignedTinyVal = (short)(tinyintVal & 0xFF);
/*      */ 
/* 3345 */       return String.valueOf(unsignedTinyVal);
/*      */     case 5:
/* 3349 */       int intVal = getNativeInt(columnIndex, false);
/*      */ 
/* 3351 */       if (this.wasNullFlag) {
/* 3352 */         return null;
/*      */       }
/*      */ 
/* 3355 */       if ((!field.isUnsigned()) || (intVal >= 0)) {
/* 3356 */         return String.valueOf(intVal);
/*      */       }
/*      */ 
/* 3359 */       intVal &= 65535;
/*      */ 
/* 3361 */       return String.valueOf(intVal);
/*      */     case 4:
/* 3364 */       int intVal = getNativeInt(columnIndex, false);
/*      */ 
/* 3366 */       if (this.wasNullFlag) {
/* 3367 */         return null;
/*      */       }
/*      */ 
/* 3370 */       if ((!field.isUnsigned()) || (intVal >= 0) || (field.getMysqlType() == 9))
/*      */       {
/* 3373 */         return String.valueOf(intVal);
/*      */       }
/*      */ 
/* 3376 */       long longVal = intVal & 0xFFFFFFFF;
/*      */ 
/* 3378 */       return String.valueOf(longVal);
/*      */     case -5:
/* 3382 */       if (!field.isUnsigned()) {
/* 3383 */         long longVal = getNativeLong(columnIndex, false, true);
/*      */ 
/* 3385 */         if (this.wasNullFlag) {
/* 3386 */           return null;
/*      */         }
/*      */ 
/* 3389 */         return String.valueOf(longVal);
/*      */       }
/*      */ 
/* 3392 */       long longVal = getNativeLong(columnIndex, false, false);
/*      */ 
/* 3394 */       if (this.wasNullFlag) {
/* 3395 */         return null;
/*      */       }
/*      */ 
/* 3398 */       return String.valueOf(convertLongToUlong(longVal));
/*      */     case 7:
/* 3400 */       float floatVal = getNativeFloat(columnIndex);
/*      */ 
/* 3402 */       if (this.wasNullFlag) {
/* 3403 */         return null;
/*      */       }
/*      */ 
/* 3406 */       return String.valueOf(floatVal);
/*      */     case 6:
/*      */     case 8:
/* 3410 */       double doubleVal = getNativeDouble(columnIndex);
/*      */ 
/* 3412 */       if (this.wasNullFlag) {
/* 3413 */         return null;
/*      */       }
/*      */ 
/* 3416 */       return String.valueOf(doubleVal);
/*      */     case 2:
/*      */     case 3:
/* 3420 */       String stringVal = StringUtils.toAsciiString((byte[])this.thisRow[(columnIndex - 1)]);
/*      */ 
/* 3425 */       if (stringVal != null) {
/* 3426 */         this.wasNullFlag = false;
/*      */ 
/* 3428 */         if (stringVal.length() == 0) {
/* 3429 */           BigDecimal val = new BigDecimal(0.0D);
/*      */ 
/* 3431 */           return val.toString();
/*      */         }
/*      */         try
/*      */         {
/* 3435 */           val = new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/*      */           BigDecimal val;
/* 3437 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal____86") + stringVal + Messages.getString("ResultSet.___in_column__87") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009");
/*      */         }
/*      */         BigDecimal val;
/* 3448 */         return val.toString();
/*      */       }
/*      */ 
/* 3451 */       this.wasNullFlag = true;
/*      */ 
/* 3453 */       return null;
/*      */     case -1:
/*      */     case 1:
/*      */     case 12:
/* 3459 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/* 3464 */       if (!field.isBlob())
/* 3465 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/* 3466 */       if (!field.isBinary()) {
/* 3467 */         return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */       }
/* 3469 */       byte[] data = getBytes(columnIndex);
/* 3470 */       Object obj = data;
/*      */ 
/* 3472 */       if ((data != null) && (data.length >= 2)) {
/* 3473 */         if ((data[0] == -84) && (data[1] == -19)) {
/*      */           try
/*      */           {
/* 3476 */             ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */ 
/* 3478 */             ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */ 
/* 3480 */             obj = objIn.readObject();
/* 3481 */             objIn.close();
/* 3482 */             bytesIn.close();
/*      */           } catch (ClassNotFoundException cnfe) {
/* 3484 */             throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"));
/*      */           }
/*      */           catch (IOException ex)
/*      */           {
/* 3491 */             obj = data;
/*      */           }
/*      */         }
/*      */ 
/* 3495 */         return obj.toString();
/*      */       }
/*      */ 
/* 3498 */       return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */     case 91:
/* 3504 */       if (mysqlType == 13) {
/* 3505 */         short shortVal = getNativeShort(columnIndex);
/*      */ 
/* 3507 */         if (!this.connection.getYearIsDateType())
/*      */         {
/* 3509 */           if (this.wasNullFlag) {
/* 3510 */             return null;
/*      */           }
/*      */ 
/* 3513 */           return String.valueOf(shortVal);
/*      */         }
/*      */ 
/* 3516 */         if (field.getLength() == 2L)
/*      */         {
/* 3518 */           if (shortVal <= 69) {
/* 3519 */             shortVal = (short)(shortVal + 100);
/*      */           }
/*      */ 
/* 3522 */           shortVal = (short)(shortVal + 1900);
/*      */         }
/*      */ 
/* 3525 */         return fastDateCreate(null, shortVal, 1, 1).toString();
/*      */       }
/*      */ 
/* 3529 */       Date dt = getNativeDate(columnIndex);
/*      */ 
/* 3531 */       if (dt == null) {
/* 3532 */         return null;
/*      */       }
/*      */ 
/* 3535 */       return String.valueOf(dt);
/*      */     case 92:
/* 3538 */       Time tm = getNativeTime(columnIndex, null, this.defaultTimeZone, false);
/*      */ 
/* 3540 */       if (tm == null) {
/* 3541 */         return null;
/*      */       }
/*      */ 
/* 3544 */       return String.valueOf(tm);
/*      */     case 93:
/* 3547 */       Timestamp tstamp = getNativeTimestamp(columnIndex, null, this.defaultTimeZone, false);
/*      */ 
/* 3550 */       if (tstamp == null) {
/* 3551 */         return null;
/*      */       }
/*      */ 
/* 3554 */       String result = String.valueOf(tstamp);
/*      */ 
/* 3556 */       if (!this.connection.getNoDatetimeStringSync()) {
/* 3557 */         return result;
/*      */       }
/*      */ 
/* 3560 */       if (!result.endsWith(".0")) break;
/* 3561 */       return result.substring(0, result.length() - 2);
/*      */     }
/*      */ 
/* 3565 */     return extractStringFromNativeColumn(columnIndex, mysqlType);
/*      */   }
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3581 */     return getNativeDate(columnIndex, null);
/*      */   }
/*      */ 
/*      */   protected Date getNativeDate(int columnIndex, TimeZone tz)
/*      */     throws SQLException
/*      */   {
/* 3602 */     checkRowPos();
/* 3603 */     checkColumnBounds(columnIndex);
/*      */ 
/* 3605 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */ 
/* 3607 */     if (mysqlType == 10) {
/* 3608 */       byte[] bits = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 3610 */       if (bits == null) {
/* 3611 */         this.wasNullFlag = true;
/*      */ 
/* 3613 */         return null;
/*      */       }
/*      */ 
/* 3616 */       this.wasNullFlag = false;
/*      */ 
/* 3618 */       Date dateToReturn = null;
/*      */ 
/* 3620 */       int year = 0;
/* 3621 */       int month = 0;
/* 3622 */       int day = 0;
/*      */ 
/* 3624 */       int hour = 0;
/* 3625 */       int minute = 0;
/* 3626 */       int seconds = 0;
/*      */ 
/* 3628 */       if (bits.length != 0) {
/* 3629 */         year = bits[0] & 0xFF | (bits[1] & 0xFF) << 8;
/*      */ 
/* 3631 */         month = bits[2];
/* 3632 */         day = bits[3];
/*      */       }
/*      */ 
/* 3635 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 3636 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 3638 */           this.wasNullFlag = true;
/*      */ 
/* 3640 */           return null;
/* 3641 */         }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 3643 */           throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009");
/*      */         }
/*      */ 
/* 3648 */         year = 1;
/* 3649 */         month = 1;
/* 3650 */         day = 1;
/*      */       }
/*      */ 
/* 3653 */       return fastDateCreate(getCalendarInstanceForSessionOrNew(), year, month, day);
/*      */     }
/*      */ 
/* 3657 */     boolean rollForward = (tz != null) && (!tz.equals(getDefaultTimeZone()));
/*      */ 
/* 3659 */     return (Date)getNativeDateTimeValue(columnIndex, null, 91, mysqlType, tz, rollForward);
/*      */   }
/*      */ 
/*      */   private Date getNativeDateViaParseConversion(int columnIndex) throws SQLException
/*      */   {
/* 3664 */     if (this.useUsageAdvisor) {
/* 3665 */       issueConversionViaParsingWarning("getDate()", columnIndex, this.thisRow[(columnIndex - 1)], this.fields[(columnIndex - 1)], new int[] { 10 });
/*      */     }
/*      */ 
/* 3670 */     String stringVal = getNativeString(columnIndex);
/*      */ 
/* 3672 */     return getDateFromString(stringVal, columnIndex);
/*      */   }
/*      */ 
/*      */   protected double getNativeDouble(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3687 */     checkRowPos();
/* 3688 */     checkColumnBounds(columnIndex);
/*      */ 
/* 3690 */     columnIndex--;
/*      */ 
/* 3692 */     if (this.thisRow[columnIndex] == null) {
/* 3693 */       this.wasNullFlag = true;
/*      */ 
/* 3695 */       return 0.0D;
/*      */     }
/*      */ 
/* 3698 */     this.wasNullFlag = false;
/*      */ 
/* 3700 */     Field f = this.fields[columnIndex];
/*      */ 
/* 3702 */     switch (f.getMysqlType()) {
/*      */     case 5:
/* 3704 */       byte[] bits = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 3706 */       long valueAsLong = bits[0] & 0xFF | (bits[1] & 0xFF) << 8 | (bits[2] & 0xFF) << 16 | (bits[3] & 0xFF) << 24 | (bits[4] & 0xFF) << 32 | (bits[5] & 0xFF) << 40 | (bits[6] & 0xFF) << 48 | (bits[7] & 0xFF) << 56;
/*      */ 
/* 3715 */       return Double.longBitsToDouble(valueAsLong);
/*      */     case 1:
/* 3717 */       if (!f.isUnsigned()) {
/* 3718 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */ 
/* 3721 */       return getNativeShort(columnIndex + 1);
/*      */     case 2:
/*      */     case 13:
/* 3724 */       if (!f.isUnsigned()) {
/* 3725 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */ 
/* 3728 */       return getNativeInt(columnIndex + 1);
/*      */     case 3:
/*      */     case 9:
/* 3731 */       if (!f.isUnsigned()) {
/* 3732 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */ 
/* 3735 */       return getNativeLong(columnIndex + 1);
/*      */     case 8:
/* 3737 */       long valueAsLong = getNativeLong(columnIndex + 1);
/*      */ 
/* 3739 */       if (!f.isUnsigned()) {
/* 3740 */         return valueAsLong;
/*      */       }
/*      */ 
/* 3743 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/* 3747 */       return asBigInt.doubleValue();
/*      */     case 4:
/* 3749 */       return getNativeFloat(columnIndex + 1);
/*      */     case 16:
/* 3751 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 14:
/* 3754 */     case 15: } if (this.useUsageAdvisor) {
/* 3755 */       issueConversionViaParsingWarning("getDouble()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 3765 */     String stringVal = getNativeString(columnIndex + 1);
/*      */ 
/* 3767 */     return getDoubleFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected float getNativeFloat(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3783 */     checkRowPos();
/* 3784 */     checkColumnBounds(columnIndex);
/*      */ 
/* 3786 */     columnIndex--;
/*      */ 
/* 3788 */     if (this.thisRow[columnIndex] == null) {
/* 3789 */       this.wasNullFlag = true;
/*      */ 
/* 3791 */       return 0.0F;
/*      */     }
/*      */ 
/* 3794 */     this.wasNullFlag = false;
/*      */ 
/* 3796 */     Field f = this.fields[columnIndex];
/*      */ 
/* 3798 */     switch (f.getMysqlType()) {
/*      */     case 16:
/* 3800 */       long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */ 
/* 3802 */       return (float)valueAsLong;
/*      */     case 5:
/* 3809 */       Double valueAsDouble = new Double(getNativeDouble(columnIndex + 1));
/*      */ 
/* 3811 */       float valueAsFloat = valueAsDouble.floatValue();
/*      */ 
/* 3813 */       if (((this.connection.getJdbcCompliantTruncationForReads()) && (valueAsFloat == (1.0F / -1.0F))) || (valueAsFloat == (1.0F / 1.0F)))
/*      */       {
/* 3816 */         throwRangeException(valueAsDouble.toString(), columnIndex + 1, 6);
/*      */       }
/*      */ 
/* 3820 */       return (float)getNativeDouble(columnIndex + 1);
/*      */     case 1:
/* 3822 */       if (!f.isUnsigned()) {
/* 3823 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */ 
/* 3826 */       return getNativeShort(columnIndex + 1);
/*      */     case 2:
/*      */     case 13:
/* 3829 */       if (!f.isUnsigned()) {
/* 3830 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */ 
/* 3833 */       return getNativeInt(columnIndex + 1);
/*      */     case 3:
/*      */     case 9:
/* 3836 */       if (!f.isUnsigned()) {
/* 3837 */         return getNativeInt(columnIndex + 1);
/*      */       }
/*      */ 
/* 3840 */       return (float)getNativeLong(columnIndex + 1);
/*      */     case 8:
/* 3842 */       long valueAsLong = getNativeLong(columnIndex + 1);
/*      */ 
/* 3844 */       if (!f.isUnsigned()) {
/* 3845 */         return (float)valueAsLong;
/*      */       }
/*      */ 
/* 3848 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/* 3852 */       return asBigInt.floatValue();
/*      */     case 4:
/* 3854 */       byte[] bits = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 3856 */       int asInt = bits[0] & 0xFF | (bits[1] & 0xFF) << 8 | (bits[2] & 0xFF) << 16 | (bits[3] & 0xFF) << 24;
/*      */ 
/* 3859 */       return Float.intBitsToFloat(asInt);
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 14:
/* 3863 */     case 15: } if (this.useUsageAdvisor) {
/* 3864 */       issueConversionViaParsingWarning("getFloat()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 3874 */     String stringVal = getNativeString(columnIndex + 1);
/*      */ 
/* 3876 */     return getFloatFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected int getNativeInt(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 3892 */     return getNativeInt(columnIndex, true);
/*      */   }
/*      */ 
/*      */   protected int getNativeInt(int columnIndex, boolean overflowCheck) throws SQLException {
/* 3896 */     checkRowPos();
/* 3897 */     checkColumnBounds(columnIndex);
/*      */ 
/* 3899 */     columnIndex--;
/*      */ 
/* 3901 */     if (this.thisRow[columnIndex] == null) {
/* 3902 */       this.wasNullFlag = true;
/*      */ 
/* 3904 */       return 0;
/*      */     }
/*      */ 
/* 3907 */     this.wasNullFlag = false;
/*      */ 
/* 3909 */     Field f = this.fields[columnIndex];
/*      */ 
/* 3911 */     switch (f.getMysqlType()) {
/*      */     case 16:
/* 3913 */       long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */ 
/* 3915 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */       {
/* 3918 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */ 
/* 3922 */       return (short)(int)valueAsLong;
/*      */     case 1:
/* 3924 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */ 
/* 3926 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 3927 */         return tinyintVal;
/*      */       }
/*      */ 
/* 3930 */       return tinyintVal + 256;
/*      */     case 2:
/*      */     case 13:
/* 3933 */       short asShort = getNativeShort(columnIndex + 1, false);
/*      */ 
/* 3935 */       if ((!f.isUnsigned()) || (asShort >= 0)) {
/* 3936 */         return asShort;
/*      */       }
/*      */ 
/* 3939 */       return asShort + 65536;
/*      */     case 3:
/*      */     case 9:
/* 3942 */       byte[] bits = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 3944 */       int valueAsInt = bits[0] & 0xFF | (bits[1] & 0xFF) << 8 | (bits[2] & 0xFF) << 16 | (bits[3] & 0xFF) << 24;
/*      */ 
/* 3947 */       if (!f.isUnsigned()) {
/* 3948 */         return valueAsInt;
/*      */       }
/*      */ 
/* 3951 */       long valueAsLong = valueAsInt >= 0 ? valueAsInt : valueAsInt + 4294967296L;
/*      */ 
/* 3954 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (valueAsLong > 2147483647L))
/*      */       {
/* 3956 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */ 
/* 3960 */       return (int)valueAsLong;
/*      */     case 8:
/* 3962 */       long valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */ 
/* 3964 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3965 */         (valueAsLong < -2147483648L) || (valueAsLong > 2147483647L)))
/*      */       {
/* 3967 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 4);
/*      */       }
/*      */ 
/* 3972 */       return (int)valueAsLong;
/*      */     case 5:
/* 3974 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */ 
/* 3976 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3977 */         (valueAsDouble < -2147483648.0D) || (valueAsDouble > 2147483647.0D)))
/*      */       {
/* 3979 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */ 
/* 3984 */       return (int)valueAsDouble;
/*      */     case 4:
/* 3986 */       double valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */ 
/* 3988 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 3989 */         (valueAsDouble < -2147483648.0D) || (valueAsDouble > 2147483647.0D)))
/*      */       {
/* 3991 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 4);
/*      */       }
/*      */ 
/* 3996 */       return (int)valueAsDouble;
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 14:
/* 4000 */     case 15: } if (this.useUsageAdvisor) {
/* 4001 */       issueConversionViaParsingWarning("getInt()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 4011 */     String stringVal = getNativeString(columnIndex + 1);
/*      */ 
/* 4013 */     return getIntFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected long getNativeLong(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4029 */     return getNativeLong(columnIndex, true, true);
/*      */   }
/*      */ 
/*      */   protected long getNativeLong(int columnIndex, boolean overflowCheck, boolean expandUnsignedLong) throws SQLException
/*      */   {
/* 4034 */     checkRowPos();
/* 4035 */     checkColumnBounds(columnIndex);
/*      */ 
/* 4037 */     columnIndex--;
/*      */ 
/* 4039 */     if (this.thisRow[columnIndex] == null) {
/* 4040 */       this.wasNullFlag = true;
/*      */ 
/* 4042 */       return 0L;
/*      */     }
/*      */ 
/* 4045 */     this.wasNullFlag = false;
/*      */ 
/* 4047 */     Field f = this.fields[columnIndex];
/*      */ 
/* 4049 */     switch (f.getMysqlType()) {
/*      */     case 16:
/* 4051 */       return getNumericRepresentationOfSQLBitType(columnIndex + 1);
/*      */     case 1:
/* 4053 */       if (!f.isUnsigned()) {
/* 4054 */         return getNativeByte(columnIndex + 1);
/*      */       }
/*      */ 
/* 4057 */       return getNativeInt(columnIndex + 1);
/*      */     case 2:
/* 4059 */       if (!f.isUnsigned()) {
/* 4060 */         return getNativeShort(columnIndex + 1);
/*      */       }
/*      */ 
/* 4063 */       return getNativeInt(columnIndex + 1, false);
/*      */     case 13:
/* 4066 */       return getNativeShort(columnIndex + 1);
/*      */     case 3:
/*      */     case 9:
/* 4069 */       int asInt = getNativeInt(columnIndex + 1, false);
/*      */ 
/* 4071 */       if ((!f.isUnsigned()) || (asInt >= 0)) {
/* 4072 */         return asInt;
/*      */       }
/*      */ 
/* 4075 */       return asInt + 4294967296L;
/*      */     case 8:
/* 4078 */       byte[] bits = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 4080 */       long valueAsLong = bits[0] & 0xFF | (bits[1] & 0xFF) << 8 | (bits[2] & 0xFF) << 16 | (bits[3] & 0xFF) << 24 | (bits[4] & 0xFF) << 32 | (bits[5] & 0xFF) << 40 | (bits[6] & 0xFF) << 48 | (bits[7] & 0xFF) << 56;
/*      */ 
/* 4089 */       if ((!f.isUnsigned()) || (!expandUnsignedLong)) {
/* 4090 */         return valueAsLong;
/*      */       }
/*      */ 
/* 4093 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/* 4095 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && ((asBigInt.compareTo(new BigInteger(String.valueOf(9223372036854775807L))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(-9223372036854775808L))) < 0)))
/*      */       {
/* 4098 */         throwRangeException(asBigInt.toString(), columnIndex + 1, -5);
/*      */       }
/*      */ 
/* 4102 */       return getLongFromString(asBigInt.toString(), columnIndex + 1);
/*      */     case 5:
/* 4105 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */ 
/* 4107 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 4108 */         (valueAsDouble < -9.223372036854776E+018D) || (valueAsDouble > 9.223372036854776E+018D)))
/*      */       {
/* 4110 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */ 
/* 4115 */       return ()valueAsDouble;
/*      */     case 4:
/* 4117 */       double valueAsDouble = getNativeFloat(columnIndex + 1);
/*      */ 
/* 4119 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 4120 */         (valueAsDouble < -9.223372036854776E+018D) || (valueAsDouble > 9.223372036854776E+018D)))
/*      */       {
/* 4122 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, -5);
/*      */       }
/*      */ 
/* 4127 */       return ()valueAsDouble;
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/*      */     case 12:
/*      */     case 14:
/* 4130 */     case 15: } if (this.useUsageAdvisor) {
/* 4131 */       issueConversionViaParsingWarning("getLong()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 4141 */     String stringVal = getNativeString(columnIndex + 1);
/*      */ 
/* 4143 */     return getLongFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected Ref getNativeRef(int i)
/*      */     throws SQLException
/*      */   {
/* 4161 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   protected short getNativeShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4176 */     return getNativeShort(columnIndex, true);
/*      */   }
/*      */ 
/*      */   protected short getNativeShort(int columnIndex, boolean overflowCheck) throws SQLException {
/* 4180 */     checkRowPos();
/* 4181 */     checkColumnBounds(columnIndex);
/*      */ 
/* 4183 */     columnIndex--;
/*      */ 
/* 4185 */     if (this.thisRow[columnIndex] == null) {
/* 4186 */       this.wasNullFlag = true;
/*      */ 
/* 4188 */       return 0;
/*      */     }
/*      */ 
/* 4191 */     this.wasNullFlag = false;
/*      */ 
/* 4193 */     Field f = this.fields[columnIndex];
/*      */ 
/* 4195 */     switch (f.getMysqlType())
/*      */     {
/*      */     case 1:
/* 4198 */       byte tinyintVal = getNativeByte(columnIndex + 1, false);
/*      */ 
/* 4200 */       if ((!f.isUnsigned()) || (tinyintVal >= 0)) {
/* 4201 */         return (short)tinyintVal;
/*      */       }
/*      */ 
/* 4204 */       return (short)(tinyintVal + 256);
/*      */     case 2:
/*      */     case 13:
/* 4207 */       byte[] bits = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 4209 */       short asShort = (short)(bits[0] & 0xFF | (bits[1] & 0xFF) << 8);
/*      */ 
/* 4211 */       if (!f.isUnsigned()) {
/* 4212 */         return asShort;
/*      */       }
/*      */ 
/* 4215 */       int valueAsInt = asShort & 0xFFFF;
/*      */ 
/* 4217 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (valueAsInt > 32767))
/*      */       {
/* 4219 */         throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */       }
/*      */ 
/* 4223 */       return (short)valueAsInt;
/*      */     case 3:
/*      */     case 9:
/* 4226 */       if (!f.isUnsigned()) {
/* 4227 */         int valueAsInt = getNativeInt(columnIndex + 1, false);
/*      */ 
/* 4229 */         if (((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (valueAsInt > 32767)) || (valueAsInt < -32768))
/*      */         {
/* 4232 */           throwRangeException(String.valueOf(valueAsInt), columnIndex + 1, 5);
/*      */         }
/*      */ 
/* 4236 */         return (short)valueAsInt;
/*      */       }
/*      */ 
/* 4239 */       long valueAsLong = getNativeLong(columnIndex + 1, false, true);
/*      */ 
/* 4241 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (valueAsLong > 32767L))
/*      */       {
/* 4243 */         throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */       }
/*      */ 
/* 4247 */       return (short)(int)valueAsLong;
/*      */     case 8:
/* 4250 */       long valueAsLong = getNativeLong(columnIndex + 1, false, false);
/*      */ 
/* 4252 */       if (!f.isUnsigned()) {
/* 4253 */         if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 4254 */           (valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */         {
/* 4256 */           throwRangeException(String.valueOf(valueAsLong), columnIndex + 1, 5);
/*      */         }
/*      */ 
/* 4261 */         return (short)(int)valueAsLong;
/*      */       }
/*      */ 
/* 4264 */       BigInteger asBigInt = convertLongToUlong(valueAsLong);
/*      */ 
/* 4266 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && ((asBigInt.compareTo(new BigInteger(String.valueOf(32767))) > 0) || (asBigInt.compareTo(new BigInteger(String.valueOf(-32768))) < 0)))
/*      */       {
/* 4269 */         throwRangeException(asBigInt.toString(), columnIndex + 1, 5);
/*      */       }
/*      */ 
/* 4273 */       return (short)getIntFromString(asBigInt.toString(), columnIndex + 1);
/*      */     case 5:
/* 4276 */       double valueAsDouble = getNativeDouble(columnIndex + 1);
/*      */ 
/* 4278 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 4279 */         (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D)))
/*      */       {
/* 4281 */         throwRangeException(String.valueOf(valueAsDouble), columnIndex + 1, 5);
/*      */       }
/*      */ 
/* 4286 */       return (short)(int)valueAsDouble;
/*      */     case 4:
/* 4288 */       float valueAsFloat = getNativeFloat(columnIndex + 1);
/*      */ 
/* 4290 */       if ((overflowCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 4291 */         (valueAsFloat < -32768.0F) || (valueAsFloat > 32767.0F)))
/*      */       {
/* 4293 */         throwRangeException(String.valueOf(valueAsFloat), columnIndex + 1, 5);
/*      */       }
/*      */ 
/* 4298 */       return (short)(int)valueAsFloat;
/*      */     case 6:
/*      */     case 7:
/*      */     case 10:
/*      */     case 11:
/* 4301 */     case 12: } if (this.useUsageAdvisor) {
/* 4302 */       issueConversionViaParsingWarning("getShort()", columnIndex, this.thisRow[columnIndex], this.fields[columnIndex], new int[] { 5, 1, 2, 3, 8, 4 });
/*      */     }
/*      */ 
/* 4312 */     String stringVal = getNativeString(columnIndex + 1);
/*      */ 
/* 4314 */     return getShortFromString(stringVal, columnIndex + 1);
/*      */   }
/*      */ 
/*      */   protected String getNativeString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4330 */     checkRowPos();
/* 4331 */     checkColumnBounds(columnIndex);
/*      */ 
/* 4333 */     if (this.fields == null) {
/* 4334 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_133"), "S1002");
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 4341 */       if (this.thisRow[(columnIndex - 1)] == null) {
/* 4342 */         this.wasNullFlag = true;
/*      */ 
/* 4344 */         return null;
/*      */       }
/*      */ 
/* 4347 */       this.wasNullFlag = false;
/*      */     } catch (NullPointerException E) {
/* 4349 */       this.wasNullFlag = true;
/*      */ 
/* 4351 */       return null;
/*      */     }
/*      */ 
/* 4354 */     String stringVal = null;
/*      */ 
/* 4356 */     if ((this.thisRow[(columnIndex - 1)] instanceof String)) {
/* 4357 */       return (String)this.thisRow[(columnIndex - 1)];
/*      */     }
/*      */ 
/* 4360 */     Field field = this.fields[(columnIndex - 1)];
/*      */ 
/* 4363 */     stringVal = getNativeConvertToString(columnIndex, field);
/*      */ 
/* 4365 */     if ((field.isZeroFill()) && (stringVal != null)) {
/* 4366 */       int origLength = stringVal.length();
/*      */ 
/* 4368 */       StringBuffer zeroFillBuf = new StringBuffer(origLength);
/*      */ 
/* 4370 */       long numZeros = field.getLength() - origLength;
/*      */ 
/* 4372 */       for (long i = 0L; i < numZeros; i += 1L) {
/* 4373 */         zeroFillBuf.append('0');
/*      */       }
/*      */ 
/* 4376 */       zeroFillBuf.append(stringVal);
/*      */ 
/* 4378 */       stringVal = zeroFillBuf.toString();
/*      */     }
/*      */ 
/* 4381 */     return stringVal;
/*      */   }
/*      */ 
/*      */   private Time getNativeTime(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4388 */     checkRowPos();
/* 4389 */     checkColumnBounds(columnIndex);
/*      */ 
/* 4391 */     if (this.thisRow[(columnIndex - 1)] == null) {
/* 4392 */       this.wasNullFlag = true;
/*      */ 
/* 4394 */       return null;
/*      */     }
/* 4396 */     this.wasNullFlag = false;
/*      */ 
/* 4399 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */ 
/* 4401 */     if (mysqlType == 11)
/*      */     {
/* 4403 */       byte[] bits = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 4405 */       int length = bits.length;
/* 4406 */       int hour = 0;
/* 4407 */       int minute = 0;
/* 4408 */       int seconds = 0;
/*      */ 
/* 4410 */       if (length != 0)
/*      */       {
/* 4413 */         hour = bits[5];
/* 4414 */         minute = bits[6];
/* 4415 */         seconds = bits[7];
/*      */       }
/*      */ 
/* 4418 */       Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/* 4420 */       synchronized (sessionCalendar) {
/* 4421 */         Time time = TimeUtil.fastTimeCreate(sessionCalendar, hour, minute, seconds);
/*      */ 
/* 4425 */         Time adjustedTime = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, time, this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/* 4431 */         return adjustedTime;
/*      */       }
/*      */     }
/*      */ 
/* 4435 */     return (Time)getNativeDateTimeValue(columnIndex, targetCalendar, 92, mysqlType, tz, rollForward);
/*      */   }
/*      */ 
/*      */   private Time getNativeTimeViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4442 */     if (this.useUsageAdvisor) {
/* 4443 */       issueConversionViaParsingWarning("getTime()", columnIndex, this.thisRow[(columnIndex - 1)], this.fields[(columnIndex - 1)], new int[] { 11 });
/*      */     }
/*      */ 
/* 4448 */     String strTime = getNativeString(columnIndex);
/*      */ 
/* 4450 */     return getTimeFromString(strTime, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */ 
/*      */   private Timestamp getNativeTimestamp(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4457 */     checkRowPos();
/* 4458 */     checkColumnBounds(columnIndex);
/*      */ 
/* 4460 */     if (this.thisRow[(columnIndex - 1)] == null) {
/* 4461 */       this.wasNullFlag = true;
/*      */ 
/* 4463 */       return null;
/*      */     }
/*      */ 
/* 4466 */     this.wasNullFlag = false;
/*      */ 
/* 4468 */     int mysqlType = this.fields[(columnIndex - 1)].getMysqlType();
/*      */ 
/* 4470 */     switch (mysqlType) {
/*      */     case 7:
/*      */     case 12:
/* 4473 */       byte[] bits = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 4475 */       int length = bits.length;
/*      */ 
/* 4477 */       int year = 0;
/* 4478 */       int month = 0;
/* 4479 */       int day = 0;
/*      */ 
/* 4481 */       int hour = 0;
/* 4482 */       int minute = 0;
/* 4483 */       int seconds = 0;
/*      */ 
/* 4485 */       int nanos = 0;
/*      */ 
/* 4487 */       if (length != 0) {
/* 4488 */         year = bits[0] & 0xFF | (bits[1] & 0xFF) << 8;
/* 4489 */         month = bits[2];
/* 4490 */         day = bits[3];
/*      */ 
/* 4492 */         if (length > 4) {
/* 4493 */           hour = bits[4];
/* 4494 */           minute = bits[5];
/* 4495 */           seconds = bits[6];
/*      */         }
/*      */ 
/* 4498 */         if (length > 7) {
/* 4499 */           nanos = bits[7] & 0xFF | (bits[8] & 0xFF) << 8 | (bits[9] & 0xFF) << 16 | (bits[10] & 0xFF) << 24;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4505 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 4506 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 4508 */           this.wasNullFlag = true;
/*      */ 
/* 4510 */           return null;
/* 4511 */         }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 4513 */           throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009");
/*      */         }
/*      */ 
/* 4518 */         year = 1;
/* 4519 */         month = 1;
/* 4520 */         day = 1;
/*      */       }
/*      */ 
/* 4523 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 4527 */       synchronized (sessionCalendar) {
/* 4528 */         Timestamp ts = fastTimestampCreate(sessionCalendar, year, month, day, hour, minute, seconds, nanos);
/*      */ 
/* 4532 */         Timestamp adjustedTs = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, ts, this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/* 4538 */         return adjustedTs;
/*      */       }
/*      */     }
/*      */ 
/* 4542 */     return (Timestamp)getNativeDateTimeValue(columnIndex, targetCalendar, 93, mysqlType, tz, rollForward);
/*      */   }
/*      */ 
/*      */   private Timestamp getNativeTimestampViaParseConversion(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 4550 */     if (this.useUsageAdvisor) {
/* 4551 */       issueConversionViaParsingWarning("getTimestamp()", columnIndex, this.thisRow[(columnIndex - 1)], this.fields[(columnIndex - 1)], new int[] { 7, 12 });
/*      */     }
/*      */ 
/* 4557 */     String strTimestamp = getNativeString(columnIndex);
/*      */ 
/* 4559 */     return getTimestampFromString(columnIndex, targetCalendar, strTimestamp, tz, rollForward);
/*      */   }
/*      */ 
/*      */   protected InputStream getNativeUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4586 */     checkRowPos();
/*      */ 
/* 4588 */     return getBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   protected URL getNativeURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 4595 */     String val = getString(colIndex);
/*      */ 
/* 4597 */     if (val == null) {
/* 4598 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 4602 */       return new URL(val); } catch (MalformedURLException mfe) {
/*      */     }
/* 4604 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____141") + val + "'", "S1009");
/*      */   }
/*      */ 
/*      */   protected ResultSet getNextResultSet()
/*      */   {
/* 4616 */     return this.nextResultSet;
/*      */   }
/*      */ 
/*      */   public Object getObject(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 4643 */     checkRowPos();
/*      */     try
/*      */     {
/* 4646 */       if (this.thisRow[(columnIndex - 1)] == null) {
/* 4647 */         this.wasNullFlag = true;
/*      */ 
/* 4649 */         return null;
/*      */       }
/*      */     } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 4652 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */     }
/*      */ 
/* 4659 */     this.wasNullFlag = false;
/*      */ 
/* 4662 */     Field field = this.fields[(columnIndex - 1)];
/*      */ 
/* 4670 */     if ((this.isBinaryEncoded) && (!(this.thisRow[(columnIndex - 1)] instanceof byte[])))
/*      */     {
/* 4678 */       if ((field.getSQLType() == -7) && (field.getLength() > 0L))
/*      */       {
/* 4682 */         return new Boolean(getBoolean(columnIndex));
/*      */       }
/*      */ 
/* 4685 */       Object columnValue = this.thisRow[(columnIndex - 1)];
/*      */ 
/* 4687 */       if (columnValue == null) {
/* 4688 */         this.wasNullFlag = true;
/*      */ 
/* 4690 */         return null;
/*      */       }
/*      */ 
/* 4693 */       return columnValue;
/*      */     }
/*      */ 
/* 4696 */     switch (field.getSQLType()) {
/*      */     case -7:
/*      */     case 16:
/* 4699 */       if ((field.getMysqlType() == 16) && (!field.isSingleBit()))
/*      */       {
/* 4701 */         return getBytes(columnIndex);
/*      */       }
/*      */ 
/* 4707 */       return new Boolean(getBoolean(columnIndex));
/*      */     case -6:
/* 4710 */       if (!field.isUnsigned()) {
/* 4711 */         return new Integer(getByte(columnIndex));
/*      */       }
/*      */ 
/* 4714 */       return new Integer(getInt(columnIndex));
/*      */     case 5:
/* 4718 */       return new Integer(getInt(columnIndex));
/*      */     case 4:
/* 4722 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9))
/*      */       {
/* 4724 */         return new Integer(getInt(columnIndex));
/*      */       }
/*      */ 
/* 4727 */       return new Long(getLong(columnIndex));
/*      */     case -5:
/* 4731 */       if (!field.isUnsigned()) {
/* 4732 */         return new Long(getLong(columnIndex));
/*      */       }
/*      */ 
/* 4735 */       String stringVal = getString(columnIndex);
/*      */ 
/* 4737 */       if (stringVal == null) {
/* 4738 */         return null;
/*      */       }
/*      */       try
/*      */       {
/* 4742 */         return new BigInteger(stringVal);
/*      */       } catch (NumberFormatException nfe) {
/* 4744 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] { new Integer(columnIndex), stringVal }), "S1009");
/*      */       }
/*      */ 
/*      */     case 2:
/*      */     case 3:
/* 4752 */       String stringVal = getString(columnIndex);
/*      */ 
/* 4756 */       if (stringVal != null) {
/* 4757 */         if (stringVal.length() == 0) {
/* 4758 */           BigDecimal val = new BigDecimal(0.0D);
/*      */ 
/* 4760 */           return val;
/*      */         }
/*      */         try
/*      */         {
/* 4764 */           val = new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/*      */           BigDecimal val;
/* 4766 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal____86") + stringVal + Messages.getString("ResultSet.___in_column__87") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009");
/*      */         }
/*      */         BigDecimal val;
/* 4777 */         return val;
/*      */       }
/*      */ 
/* 4780 */       return null;
/*      */     case 7:
/* 4783 */       return new Float(getFloat(columnIndex));
/*      */     case 6:
/*      */     case 8:
/* 4787 */       return new Double(getDouble(columnIndex));
/*      */     case 1:
/*      */     case 12:
/* 4791 */       if (!field.isOpaqueBinary()) {
/* 4792 */         return getString(columnIndex);
/*      */       }
/*      */ 
/* 4795 */       return getBytes(columnIndex);
/*      */     case -1:
/* 4797 */       if (!field.isOpaqueBinary()) {
/* 4798 */         return getStringForClob(columnIndex);
/*      */       }
/*      */ 
/* 4801 */       return getBytes(columnIndex);
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/* 4806 */       if (field.getMysqlType() == 255)
/* 4807 */         return getBytes(columnIndex);
/* 4808 */       if ((field.isBinary()) || (field.isBlob())) {
/* 4809 */         byte[] data = getBytes(columnIndex);
/*      */ 
/* 4811 */         if (this.connection.getAutoDeserialize()) {
/* 4812 */           Object obj = data;
/*      */ 
/* 4814 */           if ((data != null) && (data.length >= 2)) {
/* 4815 */             if ((data[0] == -84) && (data[1] == -19))
/*      */               try
/*      */               {
/* 4818 */                 ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
/*      */ 
/* 4820 */                 ObjectInputStream objIn = new ObjectInputStream(bytesIn);
/*      */ 
/* 4822 */                 obj = objIn.readObject();
/* 4823 */                 objIn.close();
/* 4824 */                 bytesIn.close();
/*      */               } catch (ClassNotFoundException cnfe) {
/* 4826 */                 throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + Messages.getString("ResultSet._while_reading_serialized_object_92"));
/*      */               }
/*      */               catch (IOException ex)
/*      */               {
/* 4833 */                 obj = data;
/*      */               }
/*      */             else {
/* 4836 */               return getString(columnIndex);
/*      */             }
/*      */           }
/*      */ 
/* 4840 */           return obj;
/*      */         }
/*      */ 
/* 4843 */         return data;
/*      */       }
/*      */ 
/*      */     case 91:
/* 4847 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType()))
/*      */       {
/* 4849 */         return new Short(getShort(columnIndex));
/*      */       }
/*      */ 
/* 4852 */       return getDate(columnIndex);
/*      */     case 92:
/* 4855 */       return getTime(columnIndex);
/*      */     case 93:
/* 4858 */       return getTimestamp(columnIndex);
/*      */     }
/*      */ 
/* 4861 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */   public Object getObject(int i, Map map)
/*      */     throws SQLException
/*      */   {
/* 4881 */     return getObject(i);
/*      */   }
/*      */ 
/*      */   public Object getObject(String columnName)
/*      */     throws SQLException
/*      */   {
/* 4908 */     return getObject(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public Object getObject(String colName, Map map)
/*      */     throws SQLException
/*      */   {
/* 4928 */     return getObject(findColumn(colName), map);
/*      */   }
/*      */ 
/*      */   protected Object getObjectStoredProc(int columnIndex, int desiredSqlType) throws SQLException
/*      */   {
/* 4933 */     checkRowPos();
/*      */     try
/*      */     {
/* 4936 */       if (this.thisRow[(columnIndex - 1)] == null) {
/* 4937 */         this.wasNullFlag = true;
/*      */ 
/* 4939 */         return null;
/*      */       }
/*      */     } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 4942 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */     }
/*      */ 
/* 4949 */     this.wasNullFlag = false;
/*      */ 
/* 4952 */     Field field = this.fields[(columnIndex - 1)];
/*      */ 
/* 4954 */     switch (desiredSqlType)
/*      */     {
/*      */     case -7:
/*      */     case 16:
/* 4960 */       return new Boolean(getBoolean(columnIndex));
/*      */     case -6:
/* 4963 */       return new Integer(getInt(columnIndex));
/*      */     case 5:
/* 4966 */       return new Integer(getInt(columnIndex));
/*      */     case 4:
/* 4970 */       if ((!field.isUnsigned()) || (field.getMysqlType() == 9))
/*      */       {
/* 4972 */         return new Integer(getInt(columnIndex));
/*      */       }
/*      */ 
/* 4975 */       return new Long(getLong(columnIndex));
/*      */     case -5:
/* 4979 */       if (field.isUnsigned()) {
/* 4980 */         return getBigDecimal(columnIndex);
/*      */       }
/*      */ 
/* 4983 */       return new Long(getLong(columnIndex));
/*      */     case 2:
/*      */     case 3:
/* 4988 */       String stringVal = getString(columnIndex);
/*      */ 
/* 4991 */       if (stringVal != null) {
/* 4992 */         if (stringVal.length() == 0) {
/* 4993 */           BigDecimal val = new BigDecimal(0.0D);
/*      */ 
/* 4995 */           return val;
/*      */         }
/*      */         try
/*      */         {
/* 4999 */           val = new BigDecimal(stringVal);
/*      */         }
/*      */         catch (NumberFormatException ex)
/*      */         {
/*      */           BigDecimal val;
/* 5001 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_BigDecimal____86") + stringVal + Messages.getString("ResultSet.___in_column__87") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009");
/*      */         }
/*      */         BigDecimal val;
/* 5012 */         return val;
/*      */       }
/*      */ 
/* 5015 */       return null;
/*      */     case 7:
/* 5018 */       return new Float(getFloat(columnIndex));
/*      */     case 6:
/* 5022 */       if (!this.connection.getRunningCTS13()) {
/* 5023 */         return new Double(getFloat(columnIndex));
/*      */       }
/* 5025 */       return new Float(getFloat(columnIndex));
/*      */     case 8:
/* 5032 */       return new Double(getDouble(columnIndex));
/*      */     case 1:
/*      */     case 12:
/* 5036 */       return getString(columnIndex);
/*      */     case -1:
/* 5038 */       return getStringForClob(columnIndex);
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/* 5042 */       return getBytes(columnIndex);
/*      */     case 91:
/* 5045 */       if ((field.getMysqlType() == 13) && (!this.connection.getYearIsDateType()))
/*      */       {
/* 5047 */         return new Short(getShort(columnIndex));
/*      */       }
/*      */ 
/* 5050 */       return getDate(columnIndex);
/*      */     case 92:
/* 5053 */       return getTime(columnIndex);
/*      */     case 93:
/* 5056 */       return getTimestamp(columnIndex);
/*      */     }
/*      */ 
/* 5059 */     return getString(columnIndex);
/*      */   }
/*      */ 
/*      */   protected Object getObjectStoredProc(int i, Map map, int desiredSqlType)
/*      */     throws SQLException
/*      */   {
/* 5065 */     return getObjectStoredProc(i, desiredSqlType);
/*      */   }
/*      */ 
/*      */   protected Object getObjectStoredProc(String columnName, int desiredSqlType) throws SQLException
/*      */   {
/* 5070 */     return getObjectStoredProc(findColumn(columnName), desiredSqlType);
/*      */   }
/*      */ 
/*      */   protected Object getObjectStoredProc(String colName, Map map, int desiredSqlType) throws SQLException
/*      */   {
/* 5075 */     return getObjectStoredProc(findColumn(colName), map, desiredSqlType);
/*      */   }
/*      */ 
/*      */   public Ref getRef(int i)
/*      */     throws SQLException
/*      */   {
/* 5092 */     checkColumnBounds(i);
/* 5093 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Ref getRef(String colName)
/*      */     throws SQLException
/*      */   {
/* 5110 */     return getRef(findColumn(colName));
/*      */   }
/*      */ 
/*      */   public int getRow()
/*      */     throws SQLException
/*      */   {
/* 5127 */     checkClosed();
/*      */ 
/* 5129 */     int currentRowNumber = this.rowData.getCurrentRowNumber();
/* 5130 */     int row = 0;
/*      */ 
/* 5134 */     if (!this.rowData.isDynamic()) {
/* 5135 */       if ((currentRowNumber < 0) || (this.rowData.isAfterLast()) || (this.rowData.isEmpty()))
/*      */       {
/* 5137 */         row = 0;
/*      */       }
/* 5139 */       else row = currentRowNumber + 1;
/*      */     }
/*      */     else
/*      */     {
/* 5143 */       row = currentRowNumber + 1;
/*      */     }
/*      */ 
/* 5146 */     return row;
/*      */   }
/*      */ 
/*      */   protected String getServerInfo()
/*      */   {
/* 5155 */     return this.serverInfo;
/*      */   }
/*      */ 
/*      */   private long getNumericRepresentationOfSQLBitType(int columnIndex) throws SQLException
/*      */   {
/* 5160 */     if ((this.fields[(columnIndex - 1)].isSingleBit()) || (((byte[])this.thisRow[(columnIndex - 1)]).length == 1))
/*      */     {
/* 5162 */       return ((byte[])this.thisRow[(columnIndex - 1)])[0];
/*      */     }
/*      */ 
/* 5166 */     byte[] asBytes = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 5169 */     int shift = 0;
/*      */ 
/* 5171 */     long[] steps = new long[asBytes.length];
/*      */ 
/* 5173 */     for (int i = asBytes.length - 1; i >= 0; i--) {
/* 5174 */       steps[i] = ((asBytes[i] & 0xFF) << shift);
/* 5175 */       shift += 8;
/*      */     }
/*      */ 
/* 5178 */     long valueAsLong = 0L;
/*      */ 
/* 5180 */     for (int i = 0; i < asBytes.length; i++) {
/* 5181 */       valueAsLong |= steps[i];
/*      */     }
/*      */ 
/* 5184 */     return valueAsLong;
/*      */   }
/*      */ 
/*      */   public short getShort(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5199 */     if (!this.isBinaryEncoded) {
/* 5200 */       checkRowPos();
/*      */ 
/* 5202 */       if (this.connection.getUseFastIntParsing())
/*      */       {
/* 5204 */         checkColumnBounds(columnIndex);
/*      */         try
/*      */         {
/* 5207 */           if (this.thisRow[(columnIndex - 1)] == null)
/* 5208 */             this.wasNullFlag = true;
/*      */           else
/* 5210 */             this.wasNullFlag = false;
/*      */         }
/*      */         catch (NullPointerException E) {
/* 5213 */           this.wasNullFlag = true;
/*      */         } catch (ArrayIndexOutOfBoundsException aioobEx) {
/* 5215 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Column_Index_out_of_range", new Object[] { new Integer(columnIndex), new Integer(this.fields.length) }), "S1009");
/*      */         }
/*      */ 
/* 5222 */         if (this.wasNullFlag) {
/* 5223 */           return 0;
/*      */         }
/*      */ 
/* 5226 */         byte[] shortAsBytes = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 5228 */         if (shortAsBytes.length == 0) {
/* 5229 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 5232 */         boolean needsFullParse = false;
/*      */ 
/* 5234 */         for (int i = 0; i < shortAsBytes.length; i++) {
/* 5235 */           if (((char)shortAsBytes[i] != 'e') && ((char)shortAsBytes[i] != 'E'))
/*      */             continue;
/* 5237 */           needsFullParse = true;
/*      */ 
/* 5239 */           break;
/*      */         }
/*      */ 
/* 5243 */         if (!needsFullParse) {
/*      */           try {
/* 5245 */             return parseShortWithOverflowCheck(columnIndex, shortAsBytes, null);
/*      */           }
/*      */           catch (NumberFormatException nfe)
/*      */           {
/*      */             try {
/* 5250 */               return parseShortAsDouble(columnIndex, new String(shortAsBytes));
/*      */             }
/*      */             catch (NumberFormatException valueAsLong)
/*      */             {
/* 5256 */               if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5257 */                 long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */ 
/* 5259 */                 if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */                 {
/* 5262 */                   throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */                 }
/*      */ 
/* 5266 */                 return (short)(int)valueAsLong;
/*      */               }
/*      */ 
/* 5269 */               throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + new String(shortAsBytes) + "'", "S1009");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5279 */       String val = null;
/*      */       try
/*      */       {
/* 5282 */         val = getString(columnIndex);
/*      */ 
/* 5284 */         if (val != null)
/*      */         {
/* 5286 */           if (val.length() == 0) {
/* 5287 */             return (short)convertToZeroWithEmptyCheck();
/*      */           }
/*      */ 
/* 5290 */           if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */           {
/* 5292 */             return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */           }
/*      */ 
/* 5297 */           return parseShortAsDouble(columnIndex, val);
/*      */         }
/*      */ 
/* 5300 */         return 0;
/*      */       } catch (NumberFormatException nfe) {
/*      */         try {
/* 5303 */           return parseShortAsDouble(columnIndex, val);
/*      */         }
/*      */         catch (NumberFormatException valueAsLong)
/*      */         {
/* 5308 */           if (this.fields[(columnIndex - 1)].getMysqlType() == 16) {
/* 5309 */             long valueAsLong = getNumericRepresentationOfSQLBitType(columnIndex);
/*      */ 
/* 5311 */             if ((this.connection.getJdbcCompliantTruncationForReads()) && ((valueAsLong < -32768L) || (valueAsLong > 32767L)))
/*      */             {
/* 5314 */               throwRangeException(String.valueOf(valueAsLong), columnIndex, 5);
/*      */             }
/*      */ 
/* 5318 */             return (short)(int)valueAsLong;
/*      */           }
/*      */ 
/* 5321 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____96") + val + "'", "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 5329 */     return getNativeShort(columnIndex);
/*      */   }
/*      */ 
/*      */   public short getShort(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5344 */     return getShort(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private final short getShortFromString(String val, int columnIndex) throws SQLException
/*      */   {
/*      */     try {
/* 5350 */       if (val != null)
/*      */       {
/* 5352 */         if (val.length() == 0) {
/* 5353 */           return (short)convertToZeroWithEmptyCheck();
/*      */         }
/*      */ 
/* 5356 */         if ((val.indexOf("e") == -1) && (val.indexOf("E") == -1) && (val.indexOf(".") == -1))
/*      */         {
/* 5358 */           return parseShortWithOverflowCheck(columnIndex, null, val);
/*      */         }
/*      */ 
/* 5362 */         return parseShortAsDouble(columnIndex, val);
/*      */       }
/*      */ 
/* 5365 */       return 0;
/*      */     } catch (NumberFormatException nfe) {
/*      */       try {
/* 5368 */         return parseShortAsDouble(columnIndex, val);
/*      */       }
/*      */       catch (NumberFormatException newNfe) {
/*      */       }
/*      */     }
/* 5373 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Invalid_value_for_getShort()_-____217") + val + Messages.getString("ResultSet.___in_column__218") + columnIndex, "S1009");
/*      */   }
/*      */ 
/*      */   public java.sql.Statement getStatement()
/*      */     throws SQLException
/*      */   {
/* 5392 */     if ((this.isClosed) && (!this.retainOwningStatement)) {
/* 5393 */       throw SQLError.createSQLException("Operation not allowed on closed ResultSet. Statements can be retained over result set closure by setting the connection property \"retainStatementAfterResultSetClose\" to \"true\".", "S1000");
/*      */     }
/*      */ 
/* 5401 */     if (this.wrapperStatement != null) {
/* 5402 */       return this.wrapperStatement;
/*      */     }
/*      */ 
/* 5405 */     return this.owningStatement;
/*      */   }
/*      */ 
/*      */   public String getString(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5420 */     return getStringInternal(columnIndex, true);
/*      */   }
/*      */ 
/*      */   public String getString(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5436 */     return getString(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   private String getStringForClob(int columnIndex) throws SQLException {
/* 5440 */     String asString = null;
/*      */ 
/* 5442 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */ 
/* 5445 */     if (forcedEncoding == null) {
/* 5446 */       if (!this.isBinaryEncoded)
/* 5447 */         asString = getString(columnIndex);
/*      */       else
/* 5449 */         asString = getNativeString(columnIndex);
/*      */     }
/*      */     else {
/*      */       try {
/* 5453 */         byte[] asBytes = null;
/*      */ 
/* 5455 */         if (!this.isBinaryEncoded)
/* 5456 */           asBytes = getBytes(columnIndex);
/*      */         else {
/* 5458 */           asBytes = getNativeBytes(columnIndex, true);
/*      */         }
/*      */ 
/* 5461 */         if (asBytes != null)
/* 5462 */           asString = new String(asBytes, forcedEncoding);
/*      */       }
/*      */       catch (UnsupportedEncodingException uee) {
/* 5465 */         throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 5470 */     return asString;
/*      */   }
/*      */ 
/*      */   protected String getStringInternal(int columnIndex, boolean checkDateTypes) throws SQLException
/*      */   {
/* 5475 */     if (!this.isBinaryEncoded) {
/* 5476 */       checkRowPos();
/* 5477 */       checkColumnBounds(columnIndex);
/*      */ 
/* 5479 */       if (this.fields == null) {
/* 5480 */         throw SQLError.createSQLException(Messages.getString("ResultSet.Query_generated_no_fields_for_ResultSet_99"), "S1002");
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/* 5487 */         if (this.thisRow[(columnIndex - 1)] == null) {
/* 5488 */           this.wasNullFlag = true;
/*      */ 
/* 5490 */           return null;
/*      */         }
/*      */ 
/* 5493 */         this.wasNullFlag = false;
/*      */       } catch (NullPointerException E) {
/* 5495 */         this.wasNullFlag = true;
/*      */ 
/* 5497 */         return null;
/*      */       }
/*      */ 
/* 5500 */       String stringVal = null;
/* 5501 */       columnIndex--;
/*      */ 
/* 5503 */       if (this.fields[columnIndex].getMysqlType() == 16) {
/* 5504 */         if (this.fields[columnIndex].isSingleBit()) {
/* 5505 */           byte[] asBytes = (byte[])this.thisRow[columnIndex];
/*      */ 
/* 5507 */           if (asBytes.length == 0) {
/* 5508 */             return String.valueOf(convertToZeroWithEmptyCheck());
/*      */           }
/*      */ 
/* 5511 */           return String.valueOf(asBytes[0]);
/*      */         }
/*      */ 
/* 5514 */         return String.valueOf(getNumericRepresentationOfSQLBitType(columnIndex + 1));
/*      */       }
/*      */ 
/* 5517 */       String encoding = this.fields[columnIndex].getCharacterSet();
/*      */ 
/* 5519 */       if ((this.connection != null) && (this.connection.getUseUnicode())) {
/*      */         try {
/* 5521 */           if (encoding == null) {
/* 5522 */             stringVal = new String((byte[])this.thisRow[columnIndex]);
/*      */           }
/*      */           else {
/* 5525 */             SingleByteCharsetConverter converter = this.connection.getCharsetConverter(encoding);
/*      */ 
/* 5528 */             if (converter != null) {
/* 5529 */               stringVal = converter.toString((byte[])this.thisRow[columnIndex]);
/*      */             }
/*      */             else {
/* 5532 */               stringVal = new String((byte[])this.thisRow[columnIndex], encoding);
/*      */             }
/*      */           }
/*      */         }
/*      */         catch (UnsupportedEncodingException E)
/*      */         {
/* 5538 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Unsupported_character_encoding____101") + encoding + "'.", "0S100");
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 5544 */         stringVal = StringUtils.toAsciiString((byte[])this.thisRow[columnIndex]);
/*      */       }
/*      */ 
/* 5553 */       if (this.fields[columnIndex].getMysqlType() == 13) {
/* 5554 */         if (!this.connection.getYearIsDateType()) {
/* 5555 */           return stringVal;
/*      */         }
/*      */ 
/* 5558 */         Date dt = getDateFromString(stringVal, columnIndex + 1);
/*      */ 
/* 5560 */         if (dt == null) {
/* 5561 */           this.wasNullFlag = true;
/*      */ 
/* 5563 */           return null;
/*      */         }
/*      */ 
/* 5566 */         this.wasNullFlag = false;
/*      */ 
/* 5568 */         return dt.toString();
/*      */       }
/*      */ 
/* 5573 */       if ((checkDateTypes) && (!this.connection.getNoDatetimeStringSync())) {
/* 5574 */         switch (this.fields[columnIndex].getSQLType()) {
/*      */         case 92:
/* 5576 */           Time tm = getTimeFromString(stringVal, null, columnIndex + 1, getDefaultTimeZone(), false);
/*      */ 
/* 5579 */           if (tm == null) {
/* 5580 */             this.wasNullFlag = true;
/*      */ 
/* 5582 */             return null;
/*      */           }
/*      */ 
/* 5585 */           this.wasNullFlag = false;
/*      */ 
/* 5587 */           return tm.toString();
/*      */         case 91:
/* 5590 */           Date dt = getDateFromString(stringVal, columnIndex + 1);
/*      */ 
/* 5592 */           if (dt == null) {
/* 5593 */             this.wasNullFlag = true;
/*      */ 
/* 5595 */             return null;
/*      */           }
/*      */ 
/* 5598 */           this.wasNullFlag = false;
/*      */ 
/* 5600 */           return dt.toString();
/*      */         case 93:
/* 5602 */           Timestamp ts = getTimestampFromString(columnIndex + 1, null, stringVal, getDefaultTimeZone(), false);
/*      */ 
/* 5605 */           if (ts == null) {
/* 5606 */             this.wasNullFlag = true;
/*      */ 
/* 5608 */             return null;
/*      */           }
/*      */ 
/* 5611 */           this.wasNullFlag = false;
/*      */ 
/* 5613 */           return ts.toString();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 5619 */       return stringVal;
/*      */     }
/*      */ 
/* 5622 */     return getNativeString(columnIndex);
/*      */   }
/*      */ 
/*      */   public Time getTime(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5637 */     return getTimeInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */ 
/*      */   public Time getTime(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5657 */     return getTimeInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   public Time getTime(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5672 */     return getTime(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public Time getTime(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5692 */     return getTime(findColumn(columnName), cal);
/*      */   }
/*      */ 
/*      */   private Time getTimeFromString(String timeAsString, Calendar targetCalendar, int columnIndex, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 5699 */     int hr = 0;
/* 5700 */     int min = 0;
/* 5701 */     int sec = 0;
/*      */     try
/*      */     {
/* 5705 */       if (timeAsString == null) {
/* 5706 */         this.wasNullFlag = true;
/*      */ 
/* 5708 */         return null;
/*      */       }
/*      */ 
/* 5719 */       timeAsString = timeAsString.trim();
/*      */ 
/* 5721 */       if ((timeAsString.equals("0")) || (timeAsString.equals("0000-00-00")) || (timeAsString.equals("0000-00-00 00:00:00")) || (timeAsString.equals("00000000000000")))
/*      */       {
/* 5725 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 5727 */           this.wasNullFlag = true;
/*      */ 
/* 5729 */           return null;
/* 5730 */         }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 5732 */           throw SQLError.createSQLException("Value '" + timeAsString + " can not be represented as java.sql.Time", "S1009");
/*      */         }
/*      */ 
/* 5739 */         return fastTimeCreate(null, 0, 0, 0);
/*      */       }
/*      */ 
/* 5742 */       this.wasNullFlag = false;
/*      */ 
/* 5744 */       Field timeColField = this.fields[(columnIndex - 1)];
/*      */ 
/* 5746 */       if (timeColField.getMysqlType() == 7)
/*      */       {
/* 5748 */         int length = timeAsString.length();
/*      */ 
/* 5750 */         switch (length) {
/*      */         case 12:
/*      */         case 14:
/* 5753 */           hr = Integer.parseInt(timeAsString.substring(length - 6, length - 4));
/*      */ 
/* 5755 */           min = Integer.parseInt(timeAsString.substring(length - 4, length - 2));
/*      */ 
/* 5757 */           sec = Integer.parseInt(timeAsString.substring(length - 2, length));
/*      */ 
/* 5761 */           break;
/*      */         case 10:
/* 5764 */           hr = Integer.parseInt(timeAsString.substring(6, 8));
/* 5765 */           min = Integer.parseInt(timeAsString.substring(8, 10));
/* 5766 */           sec = 0;
/*      */ 
/* 5769 */           break;
/*      */         case 11:
/*      */         case 13:
/*      */         default:
/* 5772 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Timestamp_too_small_to_convert_to_Time_value_in_column__257") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").", "S1009");
/*      */         }
/*      */ 
/* 5781 */         SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_TIMESTAMP_to_Time_with_getTime()_on_column__261") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").");
/*      */ 
/* 5788 */         if (this.warningChain == null)
/* 5789 */           this.warningChain = precisionLost;
/*      */         else
/* 5791 */           this.warningChain.setNextWarning(precisionLost);
/*      */       }
/* 5793 */       else if (timeColField.getMysqlType() == 12) {
/* 5794 */         hr = Integer.parseInt(timeAsString.substring(11, 13));
/* 5795 */         min = Integer.parseInt(timeAsString.substring(14, 16));
/* 5796 */         sec = Integer.parseInt(timeAsString.substring(17, 19));
/*      */ 
/* 5798 */         SQLWarning precisionLost = new SQLWarning(Messages.getString("ResultSet.Precision_lost_converting_DATETIME_to_Time_with_getTime()_on_column__264") + columnIndex + "(" + this.fields[(columnIndex - 1)] + ").");
/*      */ 
/* 5805 */         if (this.warningChain == null)
/* 5806 */           this.warningChain = precisionLost;
/*      */         else
/* 5808 */           this.warningChain.setNextWarning(precisionLost);
/*      */       } else {
/* 5810 */         if (timeColField.getMysqlType() == 10) {
/* 5811 */           return fastTimeCreate(null, 0, 0, 0);
/*      */         }
/*      */ 
/* 5815 */         if ((timeAsString.length() != 5) && (timeAsString.length() != 8))
/*      */         {
/* 5817 */           throw SQLError.createSQLException(Messages.getString("ResultSet.Bad_format_for_Time____267") + timeAsString + Messages.getString("ResultSet.___in_column__268") + columnIndex, "S1009");
/*      */         }
/*      */ 
/* 5824 */         hr = Integer.parseInt(timeAsString.substring(0, 2));
/* 5825 */         min = Integer.parseInt(timeAsString.substring(3, 5));
/* 5826 */         sec = timeAsString.length() == 5 ? 0 : Integer.parseInt(timeAsString.substring(6));
/*      */       }
/*      */ 
/* 5830 */       Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/* 5832 */       synchronized (sessionCalendar) {
/* 5833 */         return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimeCreate(sessionCalendar, hr, min, sec), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception ex)
/*      */     {
/*      */     }
/*      */ 
/* 5842 */     throw SQLError.createSQLException(ex.toString(), "S1009");
/*      */   }
/*      */ 
/*      */   private Time getTimeInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 5864 */     if (this.isBinaryEncoded) {
/* 5865 */       return getNativeTime(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */ 
/* 5868 */     String timeAsString = getStringInternal(columnIndex, false);
/*      */ 
/* 5870 */     return getTimeFromString(timeAsString, targetCalendar, columnIndex, tz, rollForward);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 5887 */     return getTimestampInternal(columnIndex, null, getDefaultTimeZone(), false);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int columnIndex, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5909 */     return getTimestampInternal(columnIndex, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName)
/*      */     throws SQLException
/*      */   {
/* 5925 */     return getTimestamp(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String columnName, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 5946 */     return getTimestamp(findColumn(columnName), cal);
/*      */   }
/*      */ 
/*      */   private Timestamp getTimestampFromString(int columnIndex, Calendar targetCalendar, String timestampValue, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 5954 */       this.wasNullFlag = false;
/*      */ 
/* 5956 */       if (timestampValue == null) {
/* 5957 */         this.wasNullFlag = true;
/*      */ 
/* 5959 */         return null;
/*      */       }
/*      */ 
/* 5970 */       timestampValue = timestampValue.trim();
/*      */ 
/* 5972 */       int length = timestampValue.length();
/*      */ 
/* 5974 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 5978 */       synchronized (sessionCalendar) {
/* 5979 */         if ((length > 0) && (timestampValue.charAt(0) == '0') && ((timestampValue.equals("0000-00-00")) || (timestampValue.equals("0000-00-00 00:00:00")) || (timestampValue.equals("00000000000000")) || (timestampValue.equals("0"))))
/*      */         {
/* 5986 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 5988 */             this.wasNullFlag = true;
/*      */ 
/* 5990 */             return null;
/* 5991 */           }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 5993 */             throw SQLError.createSQLException("Value '" + timestampValue + " can not be represented as java.sql.Timestamp", "S1009");
/*      */           }
/*      */ 
/* 6000 */           return fastTimestampCreate(null, 1, 1, 1, 0, 0, 0, 0);
/*      */         }
/* 6002 */         if (this.fields[(columnIndex - 1)].getMysqlType() == 13)
/*      */         {
/* 6004 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, Integer.parseInt(timestampValue.substring(0, 4)), 1, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         }
/*      */ 
/* 6014 */         if (timestampValue.endsWith(".")) {
/* 6015 */           timestampValue = timestampValue.substring(0, timestampValue.length() - 1);
/*      */         }
/*      */ 
/* 6020 */         switch (length) {
/*      */         case 19:
/*      */         case 20:
/*      */         case 21:
/*      */         case 22:
/*      */         case 23:
/*      */         case 24:
/*      */         case 25:
/*      */         case 26:
/* 6029 */           int year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6030 */           int month = Integer.parseInt(timestampValue.substring(5, 7));
/*      */ 
/* 6032 */           int day = Integer.parseInt(timestampValue.substring(8, 10));
/* 6033 */           int hour = Integer.parseInt(timestampValue.substring(11, 13));
/*      */ 
/* 6035 */           int minutes = Integer.parseInt(timestampValue.substring(14, 16));
/*      */ 
/* 6037 */           int seconds = Integer.parseInt(timestampValue.substring(17, 19));
/*      */ 
/* 6040 */           int nanos = 0;
/*      */ 
/* 6042 */           if (length > 19) {
/* 6043 */             int decimalIndex = timestampValue.lastIndexOf('.');
/*      */ 
/* 6045 */             if (decimalIndex != -1) {
/* 6046 */               if (decimalIndex + 2 <= timestampValue.length()) {
/* 6047 */                 nanos = Integer.parseInt(timestampValue.substring(decimalIndex + 1));
/*      */               }
/*      */               else {
/* 6050 */                 throw new IllegalArgumentException();
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 6060 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, nanos), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 14:
/* 6069 */           int year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6070 */           int month = Integer.parseInt(timestampValue.substring(4, 6));
/*      */ 
/* 6072 */           int day = Integer.parseInt(timestampValue.substring(6, 8));
/* 6073 */           int hour = Integer.parseInt(timestampValue.substring(8, 10));
/*      */ 
/* 6075 */           int minutes = Integer.parseInt(timestampValue.substring(10, 12));
/*      */ 
/* 6077 */           int seconds = Integer.parseInt(timestampValue.substring(12, 14));
/*      */ 
/* 6080 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, seconds, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 12:
/* 6089 */           int year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6091 */           if (year <= 69) {
/* 6092 */             year += 100;
/*      */           }
/*      */ 
/* 6095 */           int month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */ 
/* 6097 */           int day = Integer.parseInt(timestampValue.substring(4, 6));
/* 6098 */           int hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 6099 */           int minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */ 
/* 6101 */           int seconds = Integer.parseInt(timestampValue.substring(10, 12));
/*      */ 
/* 6104 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year + 1900, month, day, hour, minutes, seconds, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 10:
/*      */           int minutes;
/*      */           int year;
/*      */           int month;
/*      */           int day;
/*      */           int hour;
/*      */           int minutes;
/* 6119 */           if ((this.fields[(columnIndex - 1)].getMysqlType() == 10) || (timestampValue.indexOf("-") != -1))
/*      */           {
/* 6121 */             int year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6122 */             int month = Integer.parseInt(timestampValue.substring(5, 7));
/*      */ 
/* 6124 */             int day = Integer.parseInt(timestampValue.substring(8, 10));
/* 6125 */             int hour = 0;
/* 6126 */             minutes = 0;
/*      */           } else {
/* 6128 */             year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6130 */             if (year <= 69) {
/* 6131 */               year += 100;
/*      */             }
/*      */ 
/* 6134 */             month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */ 
/* 6136 */             day = Integer.parseInt(timestampValue.substring(4, 6));
/* 6137 */             hour = Integer.parseInt(timestampValue.substring(6, 8));
/* 6138 */             minutes = Integer.parseInt(timestampValue.substring(8, 10));
/*      */ 
/* 6141 */             year += 1900;
/*      */           }
/*      */ 
/* 6144 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year, month, day, hour, minutes, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 8:
/* 6153 */           if (timestampValue.indexOf(":") != -1) {
/* 6154 */             int hour = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6156 */             int minutes = Integer.parseInt(timestampValue.substring(3, 5));
/*      */ 
/* 6158 */             int seconds = Integer.parseInt(timestampValue.substring(6, 8));
/*      */ 
/* 6161 */             return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, 70, 0, 1, hour, minutes, seconds, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */           }
/*      */ 
/* 6172 */           int year = Integer.parseInt(timestampValue.substring(0, 4));
/* 6173 */           int month = Integer.parseInt(timestampValue.substring(4, 6));
/*      */ 
/* 6175 */           int day = Integer.parseInt(timestampValue.substring(6, 8));
/*      */ 
/* 6177 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year - 1900, month - 1, day, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 6:
/* 6186 */           int year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6188 */           if (year <= 69) {
/* 6189 */             year += 100;
/*      */           }
/*      */ 
/* 6192 */           int month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */ 
/* 6194 */           int day = Integer.parseInt(timestampValue.substring(4, 6));
/*      */ 
/* 6196 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year + 1900, month, day, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 4:
/* 6205 */           int year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6207 */           if (year <= 69) {
/* 6208 */             year += 100;
/*      */           }
/*      */ 
/* 6211 */           int month = Integer.parseInt(timestampValue.substring(2, 4));
/*      */ 
/* 6214 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(sessionCalendar, year + 1900, month, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 2:
/* 6223 */           int year = Integer.parseInt(timestampValue.substring(0, 2));
/*      */ 
/* 6225 */           if (year <= 69) {
/* 6226 */             year += 100;
/*      */           }
/*      */ 
/* 6229 */           return TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, fastTimestampCreate(null, year + 1900, 1, 1, 0, 0, 0, 0), this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */         case 3:
/*      */         case 5:
/*      */         case 7:
/*      */         case 9:
/*      */         case 11:
/*      */         case 13:
/*      */         case 15:
/*      */         case 16:
/*      */         case 17:
/* 6238 */         case 18: } throw new SQLException("Bad format for Timestamp '" + timestampValue + "' in column " + columnIndex + ".", "S1009");
/*      */       }
/*      */ 
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*      */     }
/*      */ 
/* 6246 */     throw new SQLException("Cannot convert value '" + timestampValue + "' from column " + columnIndex + " to TIMESTAMP.", "S1009");
/*      */   }
/*      */ 
/*      */   private Timestamp getTimestampInternal(int columnIndex, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 6270 */     if (this.isBinaryEncoded) {
/* 6271 */       return getNativeTimestamp(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */ 
/* 6274 */     String timestampValue = getStringInternal(columnIndex, false);
/*      */ 
/* 6276 */     return getTimestampFromString(columnIndex, targetCalendar, timestampValue, tz, rollForward);
/*      */   }
/*      */ 
/*      */   public int getType()
/*      */     throws SQLException
/*      */   {
/* 6292 */     return this.resultSetType;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public InputStream getUnicodeStream(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 6314 */     if (!this.isBinaryEncoded) {
/* 6315 */       checkRowPos();
/*      */ 
/* 6317 */       return getBinaryStream(columnIndex);
/*      */     }
/*      */ 
/* 6320 */     return getNativeBinaryStream(columnIndex);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public InputStream getUnicodeStream(String columnName)
/*      */     throws SQLException
/*      */   {
/* 6337 */     return getUnicodeStream(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   long getUpdateCount() {
/* 6341 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   long getUpdateID() {
/* 6345 */     return this.updateId;
/*      */   }
/*      */ 
/*      */   public URL getURL(int colIndex)
/*      */     throws SQLException
/*      */   {
/* 6352 */     String val = getString(colIndex);
/*      */ 
/* 6354 */     if (val == null) {
/* 6355 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6359 */       return new URL(val); } catch (MalformedURLException mfe) {
/*      */     }
/* 6361 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009");
/*      */   }
/*      */ 
/*      */   public URL getURL(String colName)
/*      */     throws SQLException
/*      */   {
/* 6371 */     String val = getString(colName);
/*      */ 
/* 6373 */     if (val == null) {
/* 6374 */       return null;
/*      */     }
/*      */     try
/*      */     {
/* 6378 */       return new URL(val); } catch (MalformedURLException mfe) {
/*      */     }
/* 6380 */     throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009");
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 6407 */     return this.warningChain;
/*      */   }
/*      */ 
/*      */   public void insertRow()
/*      */     throws SQLException
/*      */   {
/* 6422 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public boolean isAfterLast()
/*      */     throws SQLException
/*      */   {
/* 6439 */     checkClosed();
/*      */ 
/* 6441 */     boolean b = this.rowData.isAfterLast();
/*      */ 
/* 6443 */     return b;
/*      */   }
/*      */ 
/*      */   public boolean isBeforeFirst()
/*      */     throws SQLException
/*      */   {
/* 6460 */     checkClosed();
/*      */ 
/* 6462 */     return this.rowData.isBeforeFirst();
/*      */   }
/*      */ 
/*      */   public boolean isFirst()
/*      */     throws SQLException
/*      */   {
/* 6478 */     checkClosed();
/*      */ 
/* 6480 */     return this.rowData.isFirst();
/*      */   }
/*      */ 
/*      */   public boolean isLast()
/*      */     throws SQLException
/*      */   {
/* 6499 */     checkClosed();
/*      */ 
/* 6501 */     return this.rowData.isLast();
/*      */   }
/*      */ 
/*      */   private void issueConversionViaParsingWarning(String methodName, int columnIndex, Object value, Field fieldInfo, int[] typesWithNoParseConversion)
/*      */     throws SQLException
/*      */   {
/* 6512 */     StringBuffer message = new StringBuffer();
/* 6513 */     message.append("ResultSet type conversion via parsing detected when calling ");
/*      */ 
/* 6515 */     message.append(methodName);
/* 6516 */     message.append(" for column ");
/* 6517 */     message.append(columnIndex + 1);
/* 6518 */     message.append(", (column named '");
/* 6519 */     message.append(fieldInfo.getOriginalName());
/* 6520 */     message.append("' in table '");
/* 6521 */     message.append(fieldInfo.getOriginalTableName());
/* 6522 */     if ((this.owningStatement != null) && ((this.owningStatement instanceof PreparedStatement)))
/*      */     {
/* 6524 */       message.append("' created from query:\n\n");
/* 6525 */       message.append(((PreparedStatement)this.owningStatement).originalSql);
/*      */ 
/* 6527 */       message.append("\n\n");
/*      */     } else {
/* 6529 */       message.append(". ");
/*      */     }
/*      */ 
/* 6532 */     message.append("Java class of column type is '");
/*      */ 
/* 6534 */     if (value != null)
/* 6535 */       message.append(value.getClass().getName());
/*      */     else {
/* 6537 */       message.append(ResultSetMetaData.getClassNameForJavaType(fieldInfo.getSQLType(), fieldInfo.isUnsigned(), fieldInfo.getMysqlType(), (fieldInfo.isBinary()) || (fieldInfo.isBlob()), fieldInfo.isOpaqueBinary()));
/*      */     }
/*      */ 
/* 6544 */     message.append("', MySQL field type is ");
/* 6545 */     message.append(MysqlDefs.typeToName(fieldInfo.getMysqlType()));
/* 6546 */     message.append(".\n\nTypes that could be converted directly without parsing are:\n");
/*      */ 
/* 6549 */     for (int i = 0; i < typesWithNoParseConversion.length; i++) {
/* 6550 */       message.append(MysqlDefs.typeToName(typesWithNoParseConversion[i]));
/* 6551 */       message.append("\n");
/*      */     }
/*      */ 
/* 6554 */     this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message.toString()));
/*      */   }
/*      */ 
/*      */   private void issueDataTruncationWarningIfConfigured(int columnIndex, int readSize, int truncatedToSize)
/*      */   {
/* 6566 */     DataTruncation dt = new DataTruncation(columnIndex, false, true, readSize, truncatedToSize);
/*      */   }
/*      */ 
/*      */   public boolean last()
/*      */     throws SQLException
/*      */   {
/* 6584 */     checkClosed();
/*      */ 
/* 6586 */     if (this.rowData.size() == 0) {
/* 6587 */       return false;
/*      */     }
/*      */ 
/* 6590 */     if (this.onInsertRow) {
/* 6591 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/* 6594 */     if (this.doingUpdates) {
/* 6595 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/* 6598 */     this.rowData.beforeLast();
/* 6599 */     this.thisRow = this.rowData.next();
/*      */ 
/* 6601 */     return true;
/*      */   }
/*      */ 
/*      */   public void moveToCurrentRow()
/*      */     throws SQLException
/*      */   {
/* 6623 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void moveToInsertRow()
/*      */     throws SQLException
/*      */   {
/* 6644 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public boolean next()
/*      */     throws SQLException
/*      */   {
/* 6663 */     checkClosed();
/*      */ 
/* 6665 */     if (this.onInsertRow) {
/* 6666 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/* 6669 */     if (this.doingUpdates) {
/* 6670 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/* 6675 */     if (!reallyResult())
/* 6676 */       throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000");
/*      */     boolean b;
/*      */     boolean b;
/* 6682 */     if (this.rowData.size() == 0) {
/* 6683 */       b = false;
/*      */     }
/*      */     else
/*      */     {
/*      */       boolean b;
/* 6685 */       if (!this.rowData.hasNext())
/*      */       {
/* 6687 */         this.rowData.next();
/* 6688 */         b = false;
/*      */       } else {
/* 6690 */         clearWarnings();
/* 6691 */         this.thisRow = this.rowData.next();
/* 6692 */         b = true;
/*      */       }
/*      */     }
/*      */ 
/* 6696 */     return b;
/*      */   }
/*      */ 
/*      */   private int parseIntAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException
/*      */   {
/* 6701 */     if (val == null) {
/* 6702 */       return 0;
/*      */     }
/*      */ 
/* 6705 */     double valueAsDouble = Double.parseDouble(val);
/*      */ 
/* 6707 */     if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6708 */       (valueAsDouble < -2147483648.0D) || (valueAsDouble > 2147483647.0D)))
/*      */     {
/* 6710 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 4);
/*      */     }
/*      */ 
/* 6715 */     return (int)valueAsDouble;
/*      */   }
/*      */ 
/*      */   private int parseIntWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6721 */     int intValue = 0;
/*      */ 
/* 6723 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6724 */       return 0;
/*      */     }
/*      */ 
/* 6727 */     if (valueAsBytes != null) {
/* 6728 */       intValue = StringUtils.getInt(valueAsBytes);
/*      */     }
/*      */     else
/*      */     {
/* 6738 */       valueAsString = valueAsString.trim();
/*      */ 
/* 6740 */       intValue = Integer.parseInt(valueAsString);
/*      */     }
/*      */ 
/* 6743 */     if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6744 */       (intValue == -2147483648) || (intValue == 2147483647))) {
/* 6745 */       long valueAsLong = Long.parseLong(valueAsString == null ? new String(valueAsBytes) : valueAsString);
/*      */ 
/* 6749 */       if ((valueAsLong < -2147483648L) || (valueAsLong > 2147483647L))
/*      */       {
/* 6751 */         throwRangeException(valueAsString == null ? new String(valueAsBytes) : valueAsString, columnIndex, 4);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 6758 */     return intValue;
/*      */   }
/*      */ 
/*      */   private long parseLongAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException
/*      */   {
/* 6763 */     if (val == null) {
/* 6764 */       return 0L;
/*      */     }
/*      */ 
/* 6767 */     double valueAsDouble = Double.parseDouble(val);
/*      */ 
/* 6769 */     if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6770 */       (valueAsDouble < -9.223372036854776E+018D) || (valueAsDouble > 9.223372036854776E+018D)))
/*      */     {
/* 6772 */       throwRangeException(val, columnIndex, -5);
/*      */     }
/*      */ 
/* 6776 */     return ()valueAsDouble;
/*      */   }
/*      */ 
/*      */   private long parseLongWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString, boolean doCheck)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6783 */     long longValue = 0L;
/*      */ 
/* 6785 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6786 */       return 0L;
/*      */     }
/*      */ 
/* 6789 */     if (valueAsBytes != null) {
/* 6790 */       longValue = StringUtils.getLong(valueAsBytes);
/*      */     }
/*      */     else
/*      */     {
/* 6800 */       valueAsString = valueAsString.trim();
/*      */ 
/* 6802 */       longValue = Long.parseLong(valueAsString);
/*      */     }
/*      */ 
/* 6805 */     if ((doCheck) && (this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6806 */       (longValue == -9223372036854775808L) || (longValue == 9223372036854775807L)))
/*      */     {
/* 6808 */       double valueAsDouble = Double.parseDouble(valueAsString == null ? new String(valueAsBytes) : valueAsString);
/*      */ 
/* 6812 */       if ((valueAsDouble < -9.223372036854776E+018D) || (valueAsDouble > 9.223372036854776E+018D))
/*      */       {
/* 6814 */         throwRangeException(valueAsString == null ? new String(valueAsBytes) : valueAsString, columnIndex, -5);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 6821 */     return longValue;
/*      */   }
/*      */ 
/*      */   private short parseShortAsDouble(int columnIndex, String val) throws NumberFormatException, SQLException
/*      */   {
/* 6826 */     if (val == null) {
/* 6827 */       return 0;
/*      */     }
/*      */ 
/* 6830 */     double valueAsDouble = Double.parseDouble(val);
/*      */ 
/* 6832 */     if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6833 */       (valueAsDouble < -32768.0D) || (valueAsDouble > 32767.0D)))
/*      */     {
/* 6835 */       throwRangeException(String.valueOf(valueAsDouble), columnIndex, 5);
/*      */     }
/*      */ 
/* 6840 */     return (short)(int)valueAsDouble;
/*      */   }
/*      */ 
/*      */   private short parseShortWithOverflowCheck(int columnIndex, byte[] valueAsBytes, String valueAsString)
/*      */     throws NumberFormatException, SQLException
/*      */   {
/* 6847 */     short shortValue = 0;
/*      */ 
/* 6849 */     if ((valueAsBytes == null) && (valueAsString == null)) {
/* 6850 */       return 0;
/*      */     }
/*      */ 
/* 6853 */     if (valueAsBytes != null) {
/* 6854 */       shortValue = StringUtils.getShort(valueAsBytes);
/*      */     }
/*      */     else
/*      */     {
/* 6864 */       valueAsString = valueAsString.trim();
/*      */ 
/* 6866 */       shortValue = Short.parseShort(valueAsString);
/*      */     }
/*      */ 
/* 6869 */     if ((this.connection.getJdbcCompliantTruncationForReads()) && (
/* 6870 */       (shortValue == -32768) || (shortValue == 32767))) {
/* 6871 */       long valueAsLong = Long.parseLong(valueAsString == null ? new String(valueAsBytes) : valueAsString);
/*      */ 
/* 6875 */       if ((valueAsLong < -32768L) || (valueAsLong > 32767L))
/*      */       {
/* 6877 */         throwRangeException(valueAsString == null ? new String(valueAsBytes) : valueAsString, columnIndex, 5);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 6884 */     return shortValue;
/*      */   }
/*      */ 
/*      */   public boolean prev()
/*      */     throws SQLException
/*      */   {
/* 6908 */     checkClosed();
/*      */ 
/* 6910 */     int rowIndex = this.rowData.getCurrentRowNumber();
/*      */ 
/* 6912 */     if (rowIndex - 1 >= 0) {
/* 6913 */       rowIndex--;
/* 6914 */       this.rowData.setCurrentRow(rowIndex);
/* 6915 */       this.thisRow = this.rowData.getAt(rowIndex);
/*      */ 
/* 6917 */       return true;
/* 6918 */     }if (rowIndex - 1 == -1) {
/* 6919 */       rowIndex--;
/* 6920 */       this.rowData.setCurrentRow(rowIndex);
/* 6921 */       this.thisRow = null;
/*      */ 
/* 6923 */       return false;
/*      */     }
/* 6925 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean previous()
/*      */     throws SQLException
/*      */   {
/* 6948 */     if (this.onInsertRow) {
/* 6949 */       this.onInsertRow = false;
/*      */     }
/*      */ 
/* 6952 */     if (this.doingUpdates) {
/* 6953 */       this.doingUpdates = false;
/*      */     }
/*      */ 
/* 6956 */     return prev();
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly)
/*      */     throws SQLException
/*      */   {
/* 6969 */     if (this.isClosed) {
/* 6970 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 6974 */       if (this.useUsageAdvisor) {
/* 6975 */         if (!calledExplicitly) {
/* 6976 */           String message = Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver._150") + Messages.getString("ResultSet._n_nYou_should_close_ResultSets_explicitly_from_your_code_to_free_up_resources_in_a_more_efficient_manner._151");
/*      */ 
/* 6981 */           this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */         }
/*      */ 
/* 6992 */         if (((this.rowData instanceof RowDataStatic)) && (!isLast()) && (!isAfterLast()) && (this.rowData.size() != 0))
/*      */         {
/* 6994 */           StringBuffer messageBuf = new StringBuffer(Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set._Cursor_was_left_on_row__154"));
/*      */ 
/* 6997 */           messageBuf.append(getRow());
/* 6998 */           messageBuf.append(Messages.getString("ResultSet._of__155"));
/* 6999 */           messageBuf.append(this.rowData.size());
/* 7000 */           messageBuf.append(Messages.getString("ResultSet._rows_when_it_was_closed._156"));
/*      */ 
/* 7003 */           messageBuf.append(Messages.getString("ResultSet._n_nYou_should_consider_re-formulating_your_query_to_return_only_the_rows_you_are_interested_in_using._157"));
/*      */ 
/* 7007 */           this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.owningStatement == null ? Messages.getString("ResultSet.N/A_159") : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), this.resultId, System.currentTimeMillis(), 0, null, this.pointOfOrigin, messageBuf.toString()));
/*      */         }
/*      */ 
/* 7023 */         if (this.columnUsed.length > 0) {
/* 7024 */           StringBuffer buf = new StringBuffer(Messages.getString("ResultSet.The_following_columns_were__160"));
/*      */ 
/* 7027 */           buf.append(Messages.getString("ResultSet._part_of_the_SELECT_statement_for_this_result_set,_but_were_161"));
/*      */ 
/* 7030 */           buf.append(Messages.getString("ResultSet._never_referenced___162"));
/*      */ 
/* 7033 */           boolean issueWarn = false;
/*      */ 
/* 7035 */           for (int i = 0; i < this.columnUsed.length; i++) {
/* 7036 */             if (this.columnUsed[i] == 0) {
/* 7037 */               if (!issueWarn)
/* 7038 */                 issueWarn = true;
/*      */               else {
/* 7040 */                 buf.append(", ");
/*      */               }
/*      */ 
/* 7043 */               buf.append(this.fields[i].getFullName());
/*      */             }
/*      */           }
/*      */ 
/* 7047 */           if (issueWarn) {
/* 7048 */             this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.owningStatement == null ? "N/A" : this.owningStatement.currentCatalog, this.connectionId, this.owningStatement == null ? -1 : this.owningStatement.getId(), 0, System.currentTimeMillis(), 0, null, this.pointOfOrigin, buf.toString()));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 7061 */       SQLException exceptionDuringClose = null;
/*      */ 
/* 7063 */       if (this.rowData != null) {
/*      */         try {
/* 7065 */           this.rowData.close();
/*      */         } catch (SQLException sqlEx) {
/* 7067 */           exceptionDuringClose = sqlEx;
/*      */         }
/*      */       }
/*      */ 
/* 7071 */       this.rowData = null;
/* 7072 */       this.defaultTimeZone = null;
/* 7073 */       this.fields = null;
/* 7074 */       this.columnNameToIndex = null;
/* 7075 */       this.fullColumnNameToIndex = null;
/* 7076 */       this.eventSink = null;
/* 7077 */       this.warningChain = null;
/*      */ 
/* 7079 */       if (!this.retainOwningStatement) {
/* 7080 */         this.owningStatement = null;
/*      */       }
/*      */ 
/* 7083 */       this.catalog = null;
/* 7084 */       this.serverInfo = null;
/* 7085 */       this.thisRow = null;
/* 7086 */       this.fastDateCal = null;
/* 7087 */       this.connection = null;
/*      */ 
/* 7089 */       this.isClosed = true;
/*      */ 
/* 7091 */       if (exceptionDuringClose != null)
/* 7092 */         throw exceptionDuringClose;
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean reallyResult()
/*      */   {
/* 7098 */     if (this.rowData != null) {
/* 7099 */       return true;
/*      */     }
/*      */ 
/* 7102 */     return this.reallyResult;
/*      */   }
/*      */ 
/*      */   public void refreshRow()
/*      */     throws SQLException
/*      */   {
/* 7126 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public boolean relative(int rows)
/*      */     throws SQLException
/*      */   {
/* 7156 */     checkClosed();
/*      */ 
/* 7158 */     if (this.rowData.size() == 0) {
/* 7159 */       return false;
/*      */     }
/*      */ 
/* 7162 */     this.rowData.moveRowRelative(rows);
/* 7163 */     this.thisRow = this.rowData.getAt(this.rowData.getCurrentRowNumber());
/*      */ 
/* 7165 */     return (!this.rowData.isAfterLast()) && (!this.rowData.isBeforeFirst());
/*      */   }
/*      */ 
/*      */   public boolean rowDeleted()
/*      */     throws SQLException
/*      */   {
/* 7184 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public boolean rowInserted()
/*      */     throws SQLException
/*      */   {
/* 7202 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public boolean rowUpdated()
/*      */     throws SQLException
/*      */   {
/* 7220 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   protected void setBinaryEncoded()
/*      */   {
/* 7228 */     this.isBinaryEncoded = true;
/*      */   }
/*      */ 
/*      */   private void setDefaultTimeZone(TimeZone defaultTimeZone) {
/* 7232 */     this.defaultTimeZone = defaultTimeZone;
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 7251 */     if ((direction != 1000) && (direction != 1001) && (direction != 1002))
/*      */     {
/* 7253 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009");
/*      */     }
/*      */ 
/* 7259 */     this.fetchDirection = direction;
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 7279 */     if (rows < 0) {
/* 7280 */       throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009");
/*      */     }
/*      */ 
/* 7286 */     this.fetchSize = rows;
/*      */   }
/*      */ 
/*      */   protected void setFirstCharOfQuery(char c)
/*      */   {
/* 7297 */     this.firstCharOfQuery = c;
/*      */   }
/*      */ 
/*      */   protected void setNextResultSet(ResultSet nextResultSet)
/*      */   {
/* 7308 */     this.nextResultSet = nextResultSet;
/*      */   }
/*      */ 
/*      */   protected void setOwningStatement(Statement owningStatement) {
/* 7312 */     this.owningStatement = owningStatement;
/*      */   }
/*      */ 
/*      */   protected void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 7322 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */ 
/*      */   protected void setResultSetType(int typeFlag)
/*      */   {
/* 7333 */     this.resultSetType = typeFlag;
/*      */   }
/*      */ 
/*      */   protected void setServerInfo(String info)
/*      */   {
/* 7343 */     this.serverInfo = info;
/*      */   }
/*      */ 
/*      */   void setStatementUsedForFetchingRows(PreparedStatement stmt) {
/* 7347 */     this.statementUsedForFetchingRows = stmt;
/*      */   }
/*      */ 
/*      */   public void setWrapperStatement(java.sql.Statement wrapperStatement)
/*      */   {
/* 7355 */     this.wrapperStatement = wrapperStatement;
/*      */   }
/*      */ 
/*      */   private void throwRangeException(String valueAsString, int columnIndex, int jdbcType) throws SQLException
/*      */   {
/* 7360 */     String datatype = null;
/*      */ 
/* 7362 */     switch (jdbcType) {
/*      */     case -6:
/* 7364 */       datatype = "TINYINT";
/* 7365 */       break;
/*      */     case 5:
/* 7367 */       datatype = "SMALLINT";
/* 7368 */       break;
/*      */     case 4:
/* 7370 */       datatype = "INTEGER";
/* 7371 */       break;
/*      */     case -5:
/* 7373 */       datatype = "BIGINT";
/* 7374 */       break;
/*      */     case 7:
/* 7376 */       datatype = "REAL";
/* 7377 */       break;
/*      */     case 6:
/* 7379 */       datatype = "FLOAT";
/* 7380 */       break;
/*      */     case 8:
/* 7382 */       datatype = "DOUBLE";
/* 7383 */       break;
/*      */     case 3:
/* 7385 */       datatype = "DECIMAL";
/* 7386 */       break;
/*      */     case -4:
/*      */     case -3:
/*      */     case -2:
/*      */     case -1:
/*      */     case 0:
/*      */     case 1:
/*      */     case 2:
/*      */     default:
/* 7388 */       datatype = " (JDBC type '" + jdbcType + "')";
/*      */     }
/*      */ 
/* 7391 */     throw SQLError.createSQLException("'" + valueAsString + "' in column '" + columnIndex + "' is outside valid range for the datatype " + datatype + ".", "22003");
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 7402 */     if (this.reallyResult) {
/* 7403 */       return super.toString();
/*      */     }
/*      */ 
/* 7406 */     return "Result set representing update count of " + this.updateCount;
/*      */   }
/*      */ 
/*      */   public void updateArray(int arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7413 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void updateArray(String arg0, Array arg1)
/*      */     throws SQLException
/*      */   {
/* 7420 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7444 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateAsciiStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7466 */     updateAsciiStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(int columnIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7487 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBigDecimal(String columnName, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 7506 */     updateBigDecimal(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(int columnIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7530 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBinaryStream(String columnName, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 7552 */     updateBinaryStream(findColumn(columnName), x, length);
/*      */   }
/*      */ 
/*      */   public void updateBlob(int arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7559 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBlob(String arg0, java.sql.Blob arg1)
/*      */     throws SQLException
/*      */   {
/* 7566 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBoolean(int columnIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7586 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBoolean(String columnName, boolean x)
/*      */     throws SQLException
/*      */   {
/* 7604 */     updateBoolean(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateByte(int columnIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 7624 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateByte(String columnName, byte x)
/*      */     throws SQLException
/*      */   {
/* 7642 */     updateByte(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateBytes(int columnIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7662 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateBytes(String columnName, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 7680 */     updateBytes(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(int columnIndex, Reader x, int length)
/*      */     throws SQLException
/*      */   {
/* 7704 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateCharacterStream(String columnName, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 7726 */     updateCharacterStream(findColumn(columnName), reader, length);
/*      */   }
/*      */ 
/*      */   public void updateClob(int arg0, java.sql.Clob arg1)
/*      */     throws SQLException
/*      */   {
/* 7733 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void updateClob(String columnName, java.sql.Clob clob)
/*      */     throws SQLException
/*      */   {
/* 7741 */     updateClob(findColumn(columnName), clob);
/*      */   }
/*      */ 
/*      */   public void updateDate(int columnIndex, Date x)
/*      */     throws SQLException
/*      */   {
/* 7762 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateDate(String columnName, Date x)
/*      */     throws SQLException
/*      */   {
/* 7781 */     updateDate(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateDouble(int columnIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 7801 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateDouble(String columnName, double x)
/*      */     throws SQLException
/*      */   {
/* 7819 */     updateDouble(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateFloat(int columnIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 7839 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateFloat(String columnName, float x)
/*      */     throws SQLException
/*      */   {
/* 7857 */     updateFloat(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateInt(int columnIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 7877 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateInt(String columnName, int x)
/*      */     throws SQLException
/*      */   {
/* 7895 */     updateInt(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateLong(int columnIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 7915 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateLong(String columnName, long x)
/*      */     throws SQLException
/*      */   {
/* 7933 */     updateLong(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateNull(int columnIndex)
/*      */     throws SQLException
/*      */   {
/* 7951 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateNull(String columnName)
/*      */     throws SQLException
/*      */   {
/* 7967 */     updateNull(findColumn(columnName));
/*      */   }
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x)
/*      */     throws SQLException
/*      */   {
/* 7987 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateObject(int columnIndex, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 8012 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateObject(String columnName, Object x)
/*      */     throws SQLException
/*      */   {
/* 8030 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateObject(String columnName, Object x, int scale)
/*      */     throws SQLException
/*      */   {
/* 8053 */     updateObject(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateRef(int arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 8060 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void updateRef(String arg0, Ref arg1)
/*      */     throws SQLException
/*      */   {
/* 8067 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void updateRow()
/*      */     throws SQLException
/*      */   {
/* 8081 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateShort(int columnIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 8101 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateShort(String columnName, short x)
/*      */     throws SQLException
/*      */   {
/* 8119 */     updateShort(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateString(int columnIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 8139 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateString(String columnName, String x)
/*      */     throws SQLException
/*      */   {
/* 8157 */     updateString(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateTime(int columnIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 8178 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateTime(String columnName, Time x)
/*      */     throws SQLException
/*      */   {
/* 8197 */     updateTime(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(int columnIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 8219 */     throw new NotUpdatable();
/*      */   }
/*      */ 
/*      */   public void updateTimestamp(String columnName, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 8238 */     updateTimestamp(findColumn(columnName), x);
/*      */   }
/*      */ 
/*      */   public boolean wasNull()
/*      */     throws SQLException
/*      */   {
/* 8253 */     return this.wasNullFlag;
/*      */   }
/*      */ 
/*      */   protected Calendar getGmtCalendar()
/*      */   {
/* 8260 */     if (this.gmtCalendar == null) {
/* 8261 */       this.gmtCalendar = Calendar.getInstance(TimeZone.getTimeZone("GMT"));
/*      */     }
/*      */ 
/* 8264 */     return this.gmtCalendar;
/*      */   }
/*      */ 
/*      */   private Object getNativeDateTimeValue(int columnIndex, Calendar targetCalendar, int jdbcType, int mysqlType, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 8272 */     int year = 0;
/* 8273 */     int month = 0;
/* 8274 */     int day = 0;
/*      */ 
/* 8276 */     int hour = 0;
/* 8277 */     int minute = 0;
/* 8278 */     int seconds = 0;
/*      */ 
/* 8280 */     int nanos = 0;
/*      */ 
/* 8282 */     byte[] bits = (byte[])this.thisRow[(columnIndex - 1)];
/*      */ 
/* 8284 */     if (bits == null) {
/* 8285 */       this.wasNullFlag = true;
/*      */ 
/* 8287 */       return null;
/*      */     }
/*      */ 
/* 8290 */     Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 8294 */     this.wasNullFlag = false;
/*      */ 
/* 8296 */     boolean populatedFromDateTimeValue = false;
/*      */ 
/* 8298 */     switch (mysqlType) {
/*      */     case 7:
/*      */     case 12:
/* 8301 */       populatedFromDateTimeValue = true;
/*      */ 
/* 8303 */       int length = bits.length;
/*      */ 
/* 8305 */       if (length == 0) break;
/* 8306 */       year = bits[0] & 0xFF | (bits[1] & 0xFF) << 8;
/* 8307 */       month = bits[2];
/* 8308 */       day = bits[3];
/*      */ 
/* 8310 */       if (length > 4) {
/* 8311 */         hour = bits[4];
/* 8312 */         minute = bits[5];
/* 8313 */         seconds = bits[6];
/*      */       }
/*      */ 
/* 8316 */       if (length <= 7) break;
/* 8317 */       nanos = bits[7] & 0xFF | (bits[8] & 0xFF) << 8 | (bits[9] & 0xFF) << 16 | (bits[10] & 0xFF) << 24; break;
/*      */     case 10:
/* 8325 */       populatedFromDateTimeValue = true;
/*      */ 
/* 8327 */       if (bits.length == 0) break;
/* 8328 */       year = bits[0] & 0xFF | (bits[1] & 0xFF) << 8;
/* 8329 */       month = bits[2];
/* 8330 */       day = bits[3]; break;
/*      */     case 11:
/* 8335 */       populatedFromDateTimeValue = true;
/*      */ 
/* 8337 */       if (bits.length != 0)
/*      */       {
/* 8340 */         hour = bits[5];
/* 8341 */         minute = bits[6];
/* 8342 */         seconds = bits[7];
/*      */       }
/*      */ 
/* 8345 */       year = 1970;
/* 8346 */       month = 1;
/* 8347 */       day = 1;
/*      */ 
/* 8349 */       break;
/*      */     case 8:
/*      */     case 9:
/*      */     default:
/* 8351 */       populatedFromDateTimeValue = false;
/*      */     }
/*      */ 
/* 8354 */     switch (jdbcType) {
/*      */     case 92:
/* 8356 */       if (populatedFromDateTimeValue) {
/* 8357 */         Time time = TimeUtil.fastTimeCreate(getCalendarInstanceForSessionOrNew(), hour, minute, seconds);
/*      */ 
/* 8361 */         Time adjustedTime = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, time, this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/* 8367 */         return adjustedTime;
/*      */       }
/*      */ 
/* 8370 */       return getNativeTimeViaParseConversion(columnIndex, targetCalendar, tz, rollForward);
/*      */     case 91:
/* 8374 */       if (populatedFromDateTimeValue) {
/* 8375 */         if ((year == 0) && (month == 0) && (day == 0)) {
/* 8376 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 8378 */             this.wasNullFlag = true;
/*      */ 
/* 8380 */             return null;
/* 8381 */           }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 8383 */             throw new SQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009");
/*      */           }
/*      */ 
/* 8388 */           year = 1;
/* 8389 */           month = 1;
/* 8390 */           day = 1;
/*      */         }
/*      */ 
/* 8393 */         return fastDateCreate(getCalendarInstanceForSessionOrNew(), year, month, day);
/*      */       }
/*      */ 
/* 8397 */       return getNativeDateViaParseConversion(columnIndex);
/*      */     case 93:
/* 8399 */       if (populatedFromDateTimeValue) {
/* 8400 */         if ((year == 0) && (month == 0) && (day == 0)) {
/* 8401 */           if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 8403 */             this.wasNullFlag = true;
/*      */ 
/* 8405 */             return null;
/* 8406 */           }if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 8408 */             throw new SQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009");
/*      */           }
/*      */ 
/* 8413 */           year = 1;
/* 8414 */           month = 1;
/* 8415 */           day = 1;
/*      */         }
/*      */ 
/* 8418 */         Timestamp ts = fastTimestampCreate(getCalendarInstanceForSessionOrNew(), year, month, day, hour, minute, seconds, nanos);
/*      */ 
/* 8422 */         Timestamp adjustedTs = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, ts, this.connection.getServerTimezoneTZ(), tz, rollForward);
/*      */ 
/* 8428 */         return adjustedTs;
/*      */       }
/*      */ 
/* 8431 */       return getNativeTimestampViaParseConversion(columnIndex, targetCalendar, tz, rollForward);
/*      */     }
/*      */ 
/* 8434 */     throw new SQLException("Internal error - conversion method doesn't support this type", "S1000");
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ResultSet
 * JD-Core Version:    0.6.0
 */