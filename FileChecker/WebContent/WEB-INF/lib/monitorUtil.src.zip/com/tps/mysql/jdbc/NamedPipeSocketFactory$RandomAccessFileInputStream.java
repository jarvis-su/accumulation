/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.RandomAccessFile;
/*     */ 
/*     */ class NamedPipeSocketFactory$RandomAccessFileInputStream extends InputStream
/*     */ {
/*     */   RandomAccessFile raFile;
/*     */   private final NamedPipeSocketFactory this$0;
/*     */ 
/*     */   NamedPipeSocketFactory$RandomAccessFileInputStream(NamedPipeSocketFactory this$0, RandomAccessFile file)
/*     */   {
/*  96 */     this.this$0 = this$0;
/*  97 */     this.raFile = file;
/*     */   }
/*     */ 
/*     */   public int available()
/*     */     throws IOException
/*     */   {
/* 104 */     return -1;
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 111 */     this.raFile.close();
/*     */   }
/*     */ 
/*     */   public int read()
/*     */     throws IOException
/*     */   {
/* 118 */     return this.raFile.read();
/*     */   }
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 125 */     return this.raFile.read(b);
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 132 */     return this.raFile.read(b, off, len);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.NamedPipeSocketFactory.RandomAccessFileInputStream
 * JD-Core Version:    0.6.0
 */