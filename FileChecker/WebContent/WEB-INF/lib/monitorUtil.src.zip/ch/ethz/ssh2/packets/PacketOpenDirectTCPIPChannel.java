/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketOpenDirectTCPIPChannel
/*    */ {
/*    */   byte[] payload;
/*    */   int channelID;
/*    */   int initialWindowSize;
/*    */   int maxPacketSize;
/*    */   String host_to_connect;
/*    */   int port_to_connect;
/*    */   String originator_IP_address;
/*    */   int originator_port;
/*    */ 
/*    */   public PacketOpenDirectTCPIPChannel(int channelID, int initialWindowSize, int maxPacketSize, String host_to_connect, int port_to_connect, String originator_IP_address, int originator_port)
/*    */   {
/* 27 */     this.channelID = channelID;
/* 28 */     this.initialWindowSize = initialWindowSize;
/* 29 */     this.maxPacketSize = maxPacketSize;
/* 30 */     this.host_to_connect = host_to_connect;
/* 31 */     this.port_to_connect = port_to_connect;
/* 32 */     this.originator_IP_address = originator_IP_address;
/* 33 */     this.originator_port = originator_port;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 38 */     if (this.payload == null)
/*    */     {
/* 40 */       TypesWriter tw = new TypesWriter();
/*    */ 
/* 42 */       tw.writeByte(90);
/* 43 */       tw.writeString("direct-tcpip");
/* 44 */       tw.writeUINT32(this.channelID);
/* 45 */       tw.writeUINT32(this.initialWindowSize);
/* 46 */       tw.writeUINT32(this.maxPacketSize);
/* 47 */       tw.writeString(this.host_to_connect);
/* 48 */       tw.writeUINT32(this.port_to_connect);
/* 49 */       tw.writeString(this.originator_IP_address);
/* 50 */       tw.writeUINT32(this.originator_port);
/*    */ 
/* 52 */       this.payload = tw.getBytes();
/*    */     }
/* 54 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketOpenDirectTCPIPChannel
 * JD-Core Version:    0.6.0
 */