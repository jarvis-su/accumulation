/*    */ package ch.ethz.ssh2.crypto;
/*    */ 
/*    */ import ch.ethz.ssh2.crypto.digest.HashForSSH2Types;
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class KeyMaterial
/*    */ {
/*    */   public byte[] initial_iv_client_to_server;
/*    */   public byte[] initial_iv_server_to_client;
/*    */   public byte[] enc_key_client_to_server;
/*    */   public byte[] enc_key_server_to_client;
/*    */   public byte[] integrity_key_client_to_server;
/*    */   public byte[] integrity_key_server_to_client;
/*    */ 
/*    */   private static byte[] calculateKey(HashForSSH2Types sh, BigInteger K, byte[] H, byte type, byte[] SessionID, int keyLength)
/*    */   {
/* 26 */     byte[] res = new byte[keyLength];
/*    */ 
/* 28 */     int dglen = sh.getDigestLength();
/* 29 */     int numRounds = (keyLength + dglen - 1) / dglen;
/*    */ 
/* 31 */     byte[][] tmp = new byte[numRounds];
/*    */ 
/* 33 */     sh.reset();
/* 34 */     sh.updateBigInt(K);
/* 35 */     sh.updateBytes(H);
/* 36 */     sh.updateByte(type);
/* 37 */     sh.updateBytes(SessionID);
/*    */ 
/* 39 */     tmp[0] = sh.getDigest();
/*    */ 
/* 41 */     int off = 0;
/* 42 */     int produced = Math.min(dglen, keyLength);
/*    */ 
/* 44 */     System.arraycopy(tmp[0], 0, res, off, produced);
/*    */ 
/* 46 */     keyLength -= produced;
/* 47 */     off += produced;
/*    */ 
/* 49 */     for (int i = 1; i < numRounds; i++)
/*    */     {
/* 51 */       sh.updateBigInt(K);
/* 52 */       sh.updateBytes(H);
/*    */ 
/* 54 */       for (int j = 0; j < i; j++) {
/* 55 */         sh.updateBytes(tmp[j]);
/*    */       }
/* 57 */       tmp[i] = sh.getDigest();
/*    */ 
/* 59 */       produced = Math.min(dglen, keyLength);
/* 60 */       System.arraycopy(tmp[i], 0, res, off, produced);
/* 61 */       keyLength -= produced;
/* 62 */       off += produced;
/*    */     }
/*    */ 
/* 65 */     return res;
/*    */   }
/*    */ 
/*    */   public static KeyMaterial create(String hashType, byte[] H, BigInteger K, byte[] SessionID, int keyLengthCS, int blockSizeCS, int macLengthCS, int keyLengthSC, int blockSizeSC, int macLengthSC)
/*    */     throws IllegalArgumentException
/*    */   {
/* 72 */     KeyMaterial km = new KeyMaterial();
/*    */ 
/* 74 */     HashForSSH2Types sh = new HashForSSH2Types(hashType);
/*    */ 
/* 76 */     km.initial_iv_client_to_server = calculateKey(sh, K, H, 65, SessionID, blockSizeCS);
/*    */ 
/* 78 */     km.initial_iv_server_to_client = calculateKey(sh, K, H, 66, SessionID, blockSizeSC);
/*    */ 
/* 80 */     km.enc_key_client_to_server = calculateKey(sh, K, H, 67, SessionID, keyLengthCS);
/*    */ 
/* 82 */     km.enc_key_server_to_client = calculateKey(sh, K, H, 68, SessionID, keyLengthSC);
/*    */ 
/* 84 */     km.integrity_key_client_to_server = calculateKey(sh, K, H, 69, SessionID, macLengthCS);
/*    */ 
/* 86 */     km.integrity_key_server_to_client = calculateKey(sh, K, H, 70, SessionID, macLengthSC);
/*    */ 
/* 88 */     return km;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.KeyMaterial
 * JD-Core Version:    0.6.0
 */