/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class DSAPublicKey
/*    */ {
/*    */   private BigInteger p;
/*    */   private BigInteger q;
/*    */   private BigInteger g;
/*    */   private BigInteger y;
/*    */ 
/*    */   public DSAPublicKey(BigInteger p, BigInteger q, BigInteger g, BigInteger y)
/*    */   {
/* 20 */     this.p = p;
/* 21 */     this.q = q;
/* 22 */     this.g = g;
/* 23 */     this.y = y;
/*    */   }
/*    */ 
/*    */   public BigInteger getP()
/*    */   {
/* 28 */     return this.p;
/*    */   }
/*    */ 
/*    */   public BigInteger getQ()
/*    */   {
/* 33 */     return this.q;
/*    */   }
/*    */ 
/*    */   public BigInteger getG()
/*    */   {
/* 38 */     return this.g;
/*    */   }
/*    */ 
/*    */   public BigInteger getY()
/*    */   {
/* 43 */     return this.y;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.DSAPublicKey
 * JD-Core Version:    0.6.0
 */