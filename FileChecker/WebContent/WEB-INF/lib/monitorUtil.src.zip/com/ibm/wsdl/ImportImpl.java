package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.wsdl.Definition;
import javax.wsdl.Import;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class ImportImpl
  implements Import
{
  protected String namespaceURI = null;
  protected String locationURI = null;
  protected Definition definition = null;
  protected Element docEl = null;
  protected Map extensionAttributes = new HashMap();
  protected List nativeAttributeNames = Arrays.asList(Constants.IMPORT_ATTR_NAMES);
  public static final long serialVersionUID = 1L;

  public void setNamespaceURI(String paramString)
  {
    this.namespaceURI = paramString;
  }

  public String getNamespaceURI()
  {
    return this.namespaceURI;
  }

  public void setLocationURI(String paramString)
  {
    this.locationURI = paramString;
  }

  public String getLocationURI()
  {
    return this.locationURI;
  }

  public void setDefinition(Definition paramDefinition)
  {
    this.definition = paramDefinition;
  }

  public Definition getDefinition()
  {
    return this.definition;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void setExtensionAttribute(QName paramQName, Object paramObject)
  {
    if (paramObject != null)
      this.extensionAttributes.put(paramQName, paramObject);
    else
      this.extensionAttributes.remove(paramQName);
  }

  public Object getExtensionAttribute(QName paramQName)
  {
    return this.extensionAttributes.get(paramQName);
  }

  public Map getExtensionAttributes()
  {
    return this.extensionAttributes;
  }

  public List getNativeAttributeNames()
  {
    return this.nativeAttributeNames;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Import:");
    if (this.namespaceURI != null)
      localStringBuffer.append("\nnamespaceURI=" + this.namespaceURI);
    if (this.locationURI != null)
      localStringBuffer.append("\nlocationURI=" + this.locationURI);
    if (this.definition != null)
      localStringBuffer.append("\ndefinition=" + this.definition);
    Iterator localIterator = this.extensionAttributes.keySet().iterator();
    while (localIterator.hasNext())
    {
      QName localQName = (QName)localIterator.next();
      localStringBuffer.append("\nextension attribute: " + localQName + "=" + this.extensionAttributes.get(localQName));
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.ImportImpl
 * JD-Core Version:    0.6.0
 */