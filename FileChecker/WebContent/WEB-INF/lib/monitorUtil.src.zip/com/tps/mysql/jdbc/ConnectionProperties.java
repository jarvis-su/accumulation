/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.log.StandardLogger;
/*      */ import java.io.Serializable;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.Field;
/*      */ import java.sql.DriverPropertyInfo;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import java.util.TreeMap;
/*      */ import javax.naming.Reference;
/*      */ 
/*      */ public class ConnectionProperties
/*      */   implements Serializable
/*      */ {
/*      */   private static final long serialVersionUID = 4257801713007640580L;
/*      */   private static final String CONNECTION_AND_AUTH_CATEGORY = "Connection/Authentication";
/*      */   private static final String DEBUGING_PROFILING_CATEGORY = "Debuging/Profiling";
/*      */   private static final String HA_CATEGORY = "High Availability and Clustering";
/*      */   private static final String MISC_CATEGORY = "Miscellaneous";
/*      */   private static final String PERFORMANCE_CATEGORY = "Performance Extensions";
/*      */   private static final String SECURITY_CATEGORY = "Security";
/*  561 */   private static final String[] PROPERTY_CATEGORIES = { "Connection/Authentication", "High Availability and Clustering", "Security", "Performance Extensions", "Debuging/Profiling", "Miscellaneous" };
/*      */ 
/*  565 */   private static final ArrayList PROPERTY_LIST = new ArrayList();
/*      */ 
/*  567 */   private static final String STANDARD_LOGGER_NAME = StandardLogger.class.getName();
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_CONVERT_TO_NULL = "convertToNull";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_EXCEPTION = "exception";
/*      */   protected static final String ZERO_DATETIME_BEHAVIOR_ROUND = "round";
/*  611 */   private ConnectionProperties.BooleanConnectionProperty allowLoadLocalInfile = new ConnectionProperties.BooleanConnectionProperty(this, "allowLoadLocalInfile", true, "Should the driver allow use of 'LOAD DATA LOCAL INFILE...' (defaults to 'true').", "3.0.3", "Security", 2147483647);
/*      */ 
/*  617 */   private ConnectionProperties.BooleanConnectionProperty allowMultiQueries = new ConnectionProperties.BooleanConnectionProperty(this, "allowMultiQueries", false, "Allow the use of ';' to delimit multiple queries during one statement (true/false, defaults to 'false'", "3.1.1", "Security", 1);
/*      */ 
/*  623 */   private ConnectionProperties.BooleanConnectionProperty allowNanAndInf = new ConnectionProperties.BooleanConnectionProperty(this, "allowNanAndInf", false, "Should the driver allow NaN or +/- INF values in PreparedStatement.setDouble()?", "3.1.5", "Miscellaneous", -2147483648);
/*      */ 
/*  629 */   private ConnectionProperties.BooleanConnectionProperty allowUrlInLocalInfile = new ConnectionProperties.BooleanConnectionProperty(this, "allowUrlInLocalInfile", false, "Should the driver allow URLs in 'LOAD DATA LOCAL INFILE' statements?", "3.1.4", "Security", 2147483647);
/*      */ 
/*  635 */   private ConnectionProperties.BooleanConnectionProperty alwaysSendSetIsolation = new ConnectionProperties.BooleanConnectionProperty(this, "alwaysSendSetIsolation", true, "Should the driver always communicate with the database when  Connection.setTransactionIsolation() is called? If set to false, the driver will only communicate with the database when the requested transaction isolation is different than the whichever is newer, the last value that was set via Connection.setTransactionIsolation(), or the value that was read from the server when the connection was established.", "3.1.7", "Performance Extensions", 2147483647);
/*      */ 
/*  647 */   private ConnectionProperties.BooleanConnectionProperty autoClosePStmtStreams = new ConnectionProperties.BooleanConnectionProperty(this, "autoClosePStmtStreams", false, "Should the driver automatically call .close() on streams/readers passed as arguments via set*() methods?", "3.1.12", "Miscellaneous", -2147483648);
/*      */ 
/*  656 */   private ConnectionProperties.BooleanConnectionProperty autoDeserialize = new ConnectionProperties.BooleanConnectionProperty(this, "autoDeserialize", false, "Should the driver automatically detect and de-serialize objects stored in BLOB fields?", "3.1.5", "Miscellaneous", -2147483648);
/*      */ 
/*  662 */   private ConnectionProperties.BooleanConnectionProperty autoGenerateTestcaseScript = new ConnectionProperties.BooleanConnectionProperty(this, "autoGenerateTestcaseScript", false, "Should the driver dump the SQL it is executing, including server-side prepared statements to STDERR?", "3.1.9", "Debuging/Profiling", -2147483648);
/*      */ 
/*  668 */   private boolean autoGenerateTestcaseScriptAsBoolean = false;
/*      */ 
/*  670 */   private ConnectionProperties.BooleanConnectionProperty autoReconnect = new ConnectionProperties.BooleanConnectionProperty(this, "autoReconnect", false, "Should the driver try to re-establish stale and/or dead connections?   If enabled the driver will throw an exception for a queries issued on a stale or dead connection,  which belong to the current transaction, but will attempt reconnect before the next query issued on the connection in a new transaction. The use of this feature is not recommended, because it has side effects related to session state and data consistency when applications don'thandle SQLExceptions properly, and is only designed to be used when you are unable to configure your application to handle SQLExceptions resulting from dead andstale connections properly. Alternatively, investigate setting the MySQL server variable \"wait_timeout\"to some high value rather than the default of 8 hours.", "1.1", "High Availability and Clustering", 0);
/*      */ 
/*  684 */   private ConnectionProperties.BooleanConnectionProperty autoReconnectForPools = new ConnectionProperties.BooleanConnectionProperty(this, "autoReconnectForPools", false, "Use a reconnection strategy appropriate for connection pools (defaults to 'false')", "3.1.3", "High Availability and Clustering", 1);
/*      */ 
/*  690 */   private boolean autoReconnectForPoolsAsBoolean = false;
/*      */ 
/*  692 */   private ConnectionProperties.MemorySizeConnectionProperty blobSendChunkSize = new ConnectionProperties.MemorySizeConnectionProperty(this, "blobSendChunkSize", 1048576, 1, 2147483647, "Chunk to use when sending BLOB/CLOBs via ServerPreparedStatements", "3.1.9", "Performance Extensions", -2147483648);
/*      */ 
/*  700 */   private ConnectionProperties.BooleanConnectionProperty cacheCallableStatements = new ConnectionProperties.BooleanConnectionProperty(this, "cacheCallableStmts", false, "Should the driver cache the parsing stage of CallableStatements", "3.1.2", "Performance Extensions", -2147483648);
/*      */ 
/*  705 */   private ConnectionProperties.BooleanConnectionProperty cachePreparedStatements = new ConnectionProperties.BooleanConnectionProperty(this, "cachePrepStmts", false, "Should the driver cache the parsing stage of PreparedStatements of client-side prepared statements, the \"check\" for suitability of server-side prepared  and server-side prepared statements themselves?", "3.0.10", "Performance Extensions", -2147483648);
/*      */ 
/*  713 */   private ConnectionProperties.BooleanConnectionProperty cacheResultSetMetadata = new ConnectionProperties.BooleanConnectionProperty(this, "cacheResultSetMetadata", false, "Should the driver cache ResultSetMetaData for Statements and PreparedStatements? (Req. JDK-1.4+, true/false, default 'false')", "3.1.1", "Performance Extensions", -2147483648);
/*      */   private boolean cacheResultSetMetaDataAsBoolean;
/*  721 */   private ConnectionProperties.BooleanConnectionProperty cacheServerConfiguration = new ConnectionProperties.BooleanConnectionProperty(this, "cacheServerConfiguration", false, "Should the driver cache the results of 'SHOW VARIABLES' and 'SHOW COLLATION' on a per-URL basis?", "3.1.5", "Performance Extensions", -2147483648);
/*      */ 
/*  728 */   private ConnectionProperties.IntegerConnectionProperty callableStatementCacheSize = new ConnectionProperties.IntegerConnectionProperty(this, "callableStmtCacheSize", 100, 0, 2147483647, "If 'cacheCallableStmts' is enabled, how many callable statements should be cached?", "3.1.2", "Performance Extensions", 5);
/*      */ 
/*  736 */   private ConnectionProperties.BooleanConnectionProperty capitalizeTypeNames = new ConnectionProperties.BooleanConnectionProperty(this, "capitalizeTypeNames", false, "Capitalize type names in DatabaseMetaData? (usually only useful when using WebObjects, true/false, defaults to 'false')", "2.0.7", "Miscellaneous", -2147483648);
/*      */ 
/*  742 */   private ConnectionProperties.StringConnectionProperty characterEncoding = new ConnectionProperties.StringConnectionProperty(this, "characterEncoding", null, "If 'useUnicode' is set to true, what character encoding should the driver use when dealing with strings? (defaults is to 'autodetect')", "1.1g", "Miscellaneous", 5);
/*      */ 
/*  748 */   private String characterEncodingAsString = null;
/*      */ 
/*  750 */   private ConnectionProperties.StringConnectionProperty characterSetResults = new ConnectionProperties.StringConnectionProperty(this, "characterSetResults", null, "Character set to tell the server to return results as.", "3.0.13", "Miscellaneous", 6);
/*      */ 
/*  755 */   private ConnectionProperties.BooleanConnectionProperty clobberStreamingResults = new ConnectionProperties.BooleanConnectionProperty(this, "clobberStreamingResults", false, "This will cause a 'streaming' ResultSet to be automatically closed, and any outstanding data still streaming from the server to be discarded if another query is executed before all the data has been read from the server.", "3.0.9", "Miscellaneous", -2147483648);
/*      */ 
/*  763 */   private ConnectionProperties.StringConnectionProperty clobCharacterEncoding = new ConnectionProperties.StringConnectionProperty(this, "clobCharacterEncoding", null, "The character encoding to use for sending and retrieving TEXT, MEDIUMTEXT and LONGTEXT values instead of the configured connection characterEncoding", "5.0.0", "Miscellaneous", -2147483648);
/*      */ 
/*  770 */   private ConnectionProperties.StringConnectionProperty connectionCollation = new ConnectionProperties.StringConnectionProperty(this, "connectionCollation", null, "If set, tells the server to use this collation via 'set collation_connection'", "3.0.13", "Miscellaneous", 7);
/*      */ 
/*  776 */   private ConnectionProperties.IntegerConnectionProperty connectTimeout = new ConnectionProperties.IntegerConnectionProperty(this, "connectTimeout", 0, 0, 2147483647, "Timeout for socket connect (in milliseconds), with 0 being no timeout. Only works on JDK-1.4 or newer. Defaults to '0'.", "3.0.1", "Connection/Authentication", 9);
/*      */ 
/*  782 */   private ConnectionProperties.BooleanConnectionProperty continueBatchOnError = new ConnectionProperties.BooleanConnectionProperty(this, "continueBatchOnError", true, "Should the driver continue processing batch commands if one statement fails. The JDBC spec allows either way (defaults to 'true').", "3.0.3", "Miscellaneous", -2147483648);
/*      */ 
/*  789 */   private ConnectionProperties.BooleanConnectionProperty createDatabaseIfNotExist = new ConnectionProperties.BooleanConnectionProperty(this, "createDatabaseIfNotExist", false, "Creates the database given in the URL if it doesn't yet exist. Assumes  the configured user has permissions to create databases.", "3.1.9", "Miscellaneous", -2147483648);
/*      */ 
/*  796 */   private ConnectionProperties.IntegerConnectionProperty defaultFetchSize = new ConnectionProperties.IntegerConnectionProperty(this, "defaultFetchSize", 0, "The driver will call setFetchSize(n) with this value on all newly-created Statements", "3.1.9", "Performance Extensions", -2147483648);
/*      */ 
/*  798 */   private ConnectionProperties.BooleanConnectionProperty detectServerPreparedStmts = new ConnectionProperties.BooleanConnectionProperty(this, "useServerPrepStmts", true, "Use server-side prepared statements if the server supports them? (defaults to 'true').", "3.1.0", "Miscellaneous", -2147483648);
/*      */ 
/*  804 */   private ConnectionProperties.BooleanConnectionProperty dontTrackOpenResources = new ConnectionProperties.BooleanConnectionProperty(this, "dontTrackOpenResources", false, "The JDBC specification requires the driver to automatically track and close resources, however if your application doesn't do a good job of explicitly calling close() on statements or result sets, this can cause memory leakage. Setting this property to true relaxes this constraint, and can be more memory efficient for some applications.", "3.1.7", "Performance Extensions", -2147483648);
/*      */ 
/*  815 */   private ConnectionProperties.BooleanConnectionProperty dumpQueriesOnException = new ConnectionProperties.BooleanConnectionProperty(this, "dumpQueriesOnException", false, "Should the driver dump the contents of the query sent to the server in the message for SQLExceptions?", "3.1.3", "Debuging/Profiling", -2147483648);
/*      */ 
/*  821 */   private ConnectionProperties.BooleanConnectionProperty dynamicCalendars = new ConnectionProperties.BooleanConnectionProperty(this, "dynamicCalendars", false, "Should the driver retrieve the default calendar when required, or cache it per connection/session?", "3.1.5", "Performance Extensions", -2147483648);
/*      */ 
/*  828 */   private ConnectionProperties.BooleanConnectionProperty elideSetAutoCommits = new ConnectionProperties.BooleanConnectionProperty(this, "elideSetAutoCommits", false, "If using MySQL-4.1 or newer, should the driver only issue 'set autocommit=n' queries when the server's state doesn't match the requested state by Connection.setAutoCommit(boolean)?", "3.1.3", "Performance Extensions", -2147483648);
/*      */ 
/*  834 */   private ConnectionProperties.BooleanConnectionProperty emptyStringsConvertToZero = new ConnectionProperties.BooleanConnectionProperty(this, "emptyStringsConvertToZero", true, "Should the driver allow conversions from empty string fields to numeric values of '0'?", "3.1.8", "Miscellaneous", -2147483648);
/*      */ 
/*  840 */   private ConnectionProperties.BooleanConnectionProperty emulateLocators = new ConnectionProperties.BooleanConnectionProperty(this, "emulateLocators", false, "N/A", "3.1.0", "Miscellaneous", -2147483648);
/*      */ 
/*  844 */   private ConnectionProperties.BooleanConnectionProperty emulateUnsupportedPstmts = new ConnectionProperties.BooleanConnectionProperty(this, "emulateUnsupportedPstmts", true, "Should the driver detect prepared statements that are not supported by the server, and replace them with client-side emulated versions?", "3.1.7", "Miscellaneous", -2147483648);
/*      */ 
/*  851 */   private ConnectionProperties.BooleanConnectionProperty enableDeprecatedAutoreconnect = new ConnectionProperties.BooleanConnectionProperty(this, "enableDeprecatedAutoreconnect", false, "Auto-reconnect functionality is deprecated starting with version 3.2, and will be removed in version 3.3. Set this property to 'true' to disable the check for the feature being configured.", "3.2.1", "High Availability and Clustering", -2147483648);
/*      */ 
/*  858 */   private ConnectionProperties.BooleanConnectionProperty enablePacketDebug = new ConnectionProperties.BooleanConnectionProperty(this, "enablePacketDebug", false, "When enabled, a ring-buffer of 'packetDebugBufferSize' packets will be kept, and dumped when exceptions are thrown in key areas in the driver's code", "3.1.3", "Debuging/Profiling", -2147483648);
/*      */ 
/*  864 */   private ConnectionProperties.BooleanConnectionProperty explainSlowQueries = new ConnectionProperties.BooleanConnectionProperty(this, "explainSlowQueries", false, "If 'logSlowQueries' is enabled, should the driver automatically issue an 'EXPLAIN' on the server and send the results to the configured log at a WARN level?", "3.1.2", "Debuging/Profiling", -2147483648);
/*      */ 
/*  872 */   private ConnectionProperties.BooleanConnectionProperty failOverReadOnly = new ConnectionProperties.BooleanConnectionProperty(this, "failOverReadOnly", true, "When failing over in autoReconnect mode, should the connection be set to 'read-only'?", "3.0.12", "High Availability and Clustering", 2);
/*      */ 
/*  878 */   private ConnectionProperties.BooleanConnectionProperty gatherPerformanceMetrics = new ConnectionProperties.BooleanConnectionProperty(this, "gatherPerfMetrics", false, "Should the driver gather performance metrics, and report them via the configured logger every 'reportMetricsIntervalMillis' milliseconds?", "3.1.2", "Debuging/Profiling", 1);
/*      */ 
/*  884 */   private boolean highAvailabilityAsBoolean = false;
/*      */ 
/*  886 */   private ConnectionProperties.BooleanConnectionProperty holdResultsOpenOverStatementClose = new ConnectionProperties.BooleanConnectionProperty(this, "holdResultsOpenOverStatementClose", false, "Should the driver close result sets on Statement.close() as required by the JDBC specification?", "3.1.7", "Performance Extensions", -2147483648);
/*      */ 
/*  892 */   private ConnectionProperties.BooleanConnectionProperty ignoreNonTxTables = new ConnectionProperties.BooleanConnectionProperty(this, "ignoreNonTxTables", false, "Ignore non-transactional table warning for rollback? (defaults to 'false').", "3.0.9", "Miscellaneous", -2147483648);
/*      */ 
/*  898 */   private ConnectionProperties.IntegerConnectionProperty initialTimeout = new ConnectionProperties.IntegerConnectionProperty(this, "initialTimeout", 2, 1, 2147483647, "If autoReconnect is enabled, the initial time to wait between re-connect attempts (in seconds, defaults to '2').", "1.1", "High Availability and Clustering", 5);
/*      */ 
/*  905 */   private ConnectionProperties.BooleanConnectionProperty isInteractiveClient = new ConnectionProperties.BooleanConnectionProperty(this, "interactiveClient", false, "Set the CLIENT_INTERACTIVE flag, which tells MySQL to timeout connections based on INTERACTIVE_TIMEOUT instead of WAIT_TIMEOUT", "3.1.0", "Connection/Authentication", -2147483648);
/*      */ 
/*  912 */   private ConnectionProperties.BooleanConnectionProperty jdbcCompliantTruncation = new ConnectionProperties.BooleanConnectionProperty(this, "jdbcCompliantTruncation", true, "Should the driver throw java.sql.DataTruncation exceptions when data is truncated as is required by the JDBC specification when connected to a server that supports warnings(MySQL 4.1.0 and newer)?", "3.1.2", "Miscellaneous", -2147483648);
/*      */ 
/*  920 */   private boolean jdbcCompliantTruncationForReads = this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */ 
/*  923 */   private ConnectionProperties.MemorySizeConnectionProperty locatorFetchBufferSize = new ConnectionProperties.MemorySizeConnectionProperty(this, "locatorFetchBufferSize", 1048576, 0, 2147483647, "If 'emulateLocators' is configured to 'true', what size  buffer should be used when fetching BLOB data for getBinaryInputStream?", "3.2.1", "Performance Extensions", -2147483648);
/*      */ 
/*  932 */   private ConnectionProperties.StringConnectionProperty loggerClassName = new ConnectionProperties.StringConnectionProperty(this, "logger", STANDARD_LOGGER_NAME, "The name of a class that implements '" + Log.class.getName() + "' that will be used to log messages to." + "(default is '" + STANDARD_LOGGER_NAME + "', which " + "logs to STDERR)", "3.1.1", "Debuging/Profiling", 0);
/*      */ 
/*  940 */   private ConnectionProperties.BooleanConnectionProperty logSlowQueries = new ConnectionProperties.BooleanConnectionProperty(this, "logSlowQueries", false, "Should queries that take longer than 'slowQueryThresholdMillis' be logged?", "3.1.2", "Debuging/Profiling", -2147483648);
/*      */ 
/*  946 */   private ConnectionProperties.BooleanConnectionProperty maintainTimeStats = new ConnectionProperties.BooleanConnectionProperty(this, "maintainTimeStats", true, "Should the driver maintain various internal timers to enable idle time calculations as well as more verbose error messages when the connection to the server fails? Setting this property to false removes at least two calls to System.getCurrentTimeMillis() per query.", "3.1.9", "Performance Extensions", 2147483647);
/*      */ 
/*  956 */   private boolean maintainTimeStatsAsBoolean = true;
/*      */ 
/*  958 */   private ConnectionProperties.IntegerConnectionProperty maxQuerySizeToLog = new ConnectionProperties.IntegerConnectionProperty(this, "maxQuerySizeToLog", 2048, 0, 2147483647, "Controls the maximum length/size of a query that will get logged when profiling or tracing", "3.1.3", "Debuging/Profiling", 4);
/*      */ 
/*  966 */   private ConnectionProperties.IntegerConnectionProperty maxReconnects = new ConnectionProperties.IntegerConnectionProperty(this, "maxReconnects", 3, 1, 2147483647, "Maximum number of reconnects to attempt if autoReconnect is true, default is '3'.", "1.1", "High Availability and Clustering", 4);
/*      */ 
/*  974 */   private ConnectionProperties.IntegerConnectionProperty maxRows = new ConnectionProperties.IntegerConnectionProperty(this, "maxRows", -1, -1, 2147483647, "The maximum number of rows to return  (0, the default means return all rows).", "all versions", "Miscellaneous", -2147483648);
/*      */ 
/*  980 */   private int maxRowsAsInt = -1;
/*      */ 
/*  982 */   private ConnectionProperties.IntegerConnectionProperty metadataCacheSize = new ConnectionProperties.IntegerConnectionProperty(this, "metadataCacheSize", 50, 1, 2147483647, "The number of queries to cacheResultSetMetadata for if cacheResultSetMetaData is set to 'true' (default 50)", "3.1.1", "Performance Extensions", 5);
/*      */ 
/*  991 */   private ConnectionProperties.BooleanConnectionProperty noAccessToProcedureBodies = new ConnectionProperties.BooleanConnectionProperty(this, "noAccessToProcedureBodies", false, "When determining procedure parameter types for CallableStatements, and the connected user  can't access procedure bodies through \"SHOW CREATE PROCEDURE\" or select on mysql.proc  should the driver instead create basic metadata (all parameters reported as INOUT VARCHARs) instead  of throwing an exception?", "5.0.3", "Miscellaneous", -2147483648);
/*      */ 
/* 1000 */   private ConnectionProperties.BooleanConnectionProperty noDatetimeStringSync = new ConnectionProperties.BooleanConnectionProperty(this, "noDatetimeStringSync", false, "Don't ensure that ResultSet.getDatetimeType().toString().equals(ResultSet.getString())", "3.1.7", "Miscellaneous", -2147483648);
/*      */ 
/* 1006 */   private ConnectionProperties.BooleanConnectionProperty noTimezoneConversionForTimeType = new ConnectionProperties.BooleanConnectionProperty(this, "noTimezoneConversionForTimeType", false, "Don't convert TIME values using the server timezone if 'useTimezone'='true'", "5.0.0", "Miscellaneous", -2147483648);
/*      */ 
/* 1012 */   private ConnectionProperties.BooleanConnectionProperty nullCatalogMeansCurrent = new ConnectionProperties.BooleanConnectionProperty(this, "nullCatalogMeansCurrent", true, "When DatabaseMetadataMethods ask for a 'catalog' parameter, does the value null mean use the current catalog? (this is not JDBC-compliant, but follows legacy behavior from earlier versions of the driver)", "3.1.8", "Miscellaneous", -2147483648);
/*      */ 
/* 1019 */   private ConnectionProperties.BooleanConnectionProperty nullNamePatternMatchesAll = new ConnectionProperties.BooleanConnectionProperty(this, "nullNamePatternMatchesAll", true, "Should DatabaseMetaData methods that accept *pattern parameters treat null the same as '%'  (this is not JDBC-compliant, however older versions of the driver accepted this departure from the specification)", "3.1.8", "Miscellaneous", -2147483648);
/*      */ 
/* 1026 */   private ConnectionProperties.IntegerConnectionProperty packetDebugBufferSize = new ConnectionProperties.IntegerConnectionProperty(this, "packetDebugBufferSize", 20, 0, 2147483647, "The maximum number of packets to retain when 'enablePacketDebug' is true", "3.1.3", "Debuging/Profiling", 7);
/*      */ 
/* 1034 */   private ConnectionProperties.BooleanConnectionProperty paranoid = new ConnectionProperties.BooleanConnectionProperty(this, "paranoid", false, "Take measures to prevent exposure sensitive information in error messages and clear data structures holding sensitive data when possible? (defaults to 'false')", "3.0.1", "Security", -2147483648);
/*      */ 
/* 1041 */   private ConnectionProperties.BooleanConnectionProperty pedantic = new ConnectionProperties.BooleanConnectionProperty(this, "pedantic", false, "Follow the JDBC spec to the letter.", "3.0.0", "Miscellaneous", -2147483648);
/*      */ 
/* 1045 */   private ConnectionProperties.BooleanConnectionProperty pinGlobalTxToPhysicalConnection = new ConnectionProperties.BooleanConnectionProperty(this, "pinGlobalTxToPhysicalConnection", false, "When using XAConnections, should the driver ensure that  operations on a given XID are always routed to the same physical connection? This allows the XAConnection to support \"XA START ... JOIN\" after \"XA END\" has been called", "5.0.1", "Miscellaneous", -2147483648);
/*      */ 
/* 1051 */   private ConnectionProperties.IntegerConnectionProperty preparedStatementCacheSize = new ConnectionProperties.IntegerConnectionProperty(this, "prepStmtCacheSize", 25, 0, 2147483647, "If prepared statement caching is enabled, how many prepared statements should be cached?", "3.0.10", "Performance Extensions", 10);
/*      */ 
/* 1057 */   private ConnectionProperties.IntegerConnectionProperty preparedStatementCacheSqlLimit = new ConnectionProperties.IntegerConnectionProperty(this, "prepStmtCacheSqlLimit", 256, 1, 2147483647, "If prepared statement caching is enabled, what's the largest SQL the driver will cache the parsing for?", "3.0.10", "Performance Extensions", 11);
/*      */ 
/* 1066 */   private ConnectionProperties.BooleanConnectionProperty processEscapeCodesForPrepStmts = new ConnectionProperties.BooleanConnectionProperty(this, "processEscapeCodesForPrepStmts", true, "Should the driver process escape codes in queries that are prepared?", "3.1.12", "Miscellaneous", -2147483648);
/*      */ 
/* 1073 */   private ConnectionProperties.StringConnectionProperty profileSql = new ConnectionProperties.StringConnectionProperty(this, "profileSql", null, "Deprecated, use 'profileSQL' instead. Trace queries and their execution/fetch times on STDERR (true/false) defaults to 'false'", "2.0.14", "Debuging/Profiling", 3);
/*      */ 
/* 1079 */   private ConnectionProperties.BooleanConnectionProperty profileSQL = new ConnectionProperties.BooleanConnectionProperty(this, "profileSQL", false, "Trace queries and their execution/fetch times to the configured logger (true/false) defaults to 'false'", "3.1.0", "Debuging/Profiling", 1);
/*      */ 
/* 1085 */   private boolean profileSQLAsBoolean = false;
/*      */ 
/* 1087 */   private ConnectionProperties.StringConnectionProperty propertiesTransform = new ConnectionProperties.StringConnectionProperty(this, "propertiesTransform", null, "An implementation of com.mysql.jdbc.ConnectionPropertiesTransform that the driver will use to modify URL properties passed to the driver before attempting a connection", "3.1.4", "Connection/Authentication", -2147483648);
/*      */ 
/* 1093 */   private ConnectionProperties.IntegerConnectionProperty queriesBeforeRetryMaster = new ConnectionProperties.IntegerConnectionProperty(this, "queriesBeforeRetryMaster", 50, 1, 2147483647, "Number of queries to issue before falling back to master when failed over (when using multi-host failover). Whichever condition is met first, 'queriesBeforeRetryMaster' or 'secondsBeforeRetryMaster' will cause an attempt to be made to reconnect to the master. Defaults to 50.", "3.0.2", "High Availability and Clustering", 7);
/*      */ 
/* 1104 */   private ConnectionProperties.BooleanConnectionProperty reconnectAtTxEnd = new ConnectionProperties.BooleanConnectionProperty(this, "reconnectAtTxEnd", false, "If autoReconnect is set to true, should the driver attempt reconnectionsat the end of every transaction?", "3.0.10", "High Availability and Clustering", 4);
/*      */ 
/* 1110 */   private boolean reconnectTxAtEndAsBoolean = false;
/*      */ 
/* 1112 */   private ConnectionProperties.BooleanConnectionProperty relaxAutoCommit = new ConnectionProperties.BooleanConnectionProperty(this, "relaxAutoCommit", false, "If the version of MySQL the driver connects to does not support transactions, still allow calls to commit(), rollback() and setAutoCommit() (true/false, defaults to 'false')?", "2.0.13", "Miscellaneous", -2147483648);
/*      */ 
/* 1118 */   private ConnectionProperties.IntegerConnectionProperty reportMetricsIntervalMillis = new ConnectionProperties.IntegerConnectionProperty(this, "reportMetricsIntervalMillis", 30000, 0, 2147483647, "If 'gatherPerfMetrics' is enabled, how often should they be logged (in ms)?", "3.1.2", "Debuging/Profiling", 3);
/*      */ 
/* 1126 */   private ConnectionProperties.BooleanConnectionProperty requireSSL = new ConnectionProperties.BooleanConnectionProperty(this, "requireSSL", false, "Require SSL connection if useSSL=true? (defaults to 'false').", "3.1.0", "Security", 3);
/*      */ 
/* 1131 */   private ConnectionProperties.StringConnectionProperty resourceId = new ConnectionProperties.StringConnectionProperty(this, "resourceId", null, "A globally unique name that identifies the resource that this datasource or connection is connected to, used for XAResource.isSameRM() when the driver can't determine this value based on hostnames used in the URL", "5.0.1", "High Availability and Clustering", -2147483648);
/*      */ 
/* 1140 */   private ConnectionProperties.BooleanConnectionProperty retainStatementAfterResultSetClose = new ConnectionProperties.BooleanConnectionProperty(this, "retainStatementAfterResultSetClose", false, "Should the driver retain the Statement reference in a ResultSet after ResultSet.close() has been called. This is not JDBC-compliant after JDBC-4.0.", "3.1.11", "Miscellaneous", -2147483648);
/*      */ 
/* 1147 */   private ConnectionProperties.BooleanConnectionProperty rewriteBatchedStatements = new ConnectionProperties.BooleanConnectionProperty(this, "rewriteBatchedStatements", false, "Should the driver use multiqueries (irregardless of the setting of \"allowMultiQueries\") as well as rewriting of prepared statements for INSERT into multi-value inserts when executeBatch() is called? Notice that this has the potential for SQL injection if using plain java.sql.Statements and your code doesn't sanitize input correctly.\n\nNotice that for prepared statements, server-side prepared statements can not currently take advantage of this rewrite option, and that if you don't specify stream lengths when using PreparedStatement.set*Stream(),the driver won't be able to determine the optimium number of parameters per batch and you might receive an error from the driver that the resultant packet is too large.\n\nStatement.getGeneratedKeys() for these rewritten statements only works when the entire batch includes INSERT statements.", "3.1.13", "Performance Extensions", -2147483648);
/*      */ 
/* 1161 */   private ConnectionProperties.BooleanConnectionProperty rollbackOnPooledClose = new ConnectionProperties.BooleanConnectionProperty(this, "rollbackOnPooledClose", true, "Should the driver issue a rollback() when the logical connection in a pool is closed?", "3.0.15", "Miscellaneous", -2147483648);
/*      */ 
/* 1167 */   private ConnectionProperties.BooleanConnectionProperty roundRobinLoadBalance = new ConnectionProperties.BooleanConnectionProperty(this, "roundRobinLoadBalance", false, "When autoReconnect is enabled, and failoverReadonly is false, should we pick hosts to connect to on a round-robin basis?", "3.1.2", "High Availability and Clustering", 5);
/*      */ 
/* 1173 */   private ConnectionProperties.BooleanConnectionProperty runningCTS13 = new ConnectionProperties.BooleanConnectionProperty(this, "runningCTS13", false, "Enables workarounds for bugs in Sun's JDBC compliance testsuite version 1.3", "3.1.7", "Miscellaneous", -2147483648);
/*      */ 
/* 1179 */   private ConnectionProperties.IntegerConnectionProperty secondsBeforeRetryMaster = new ConnectionProperties.IntegerConnectionProperty(this, "secondsBeforeRetryMaster", 30, 1, 2147483647, "How long should the driver wait, when failed over, before attempting to reconnect to the master server? Whichever condition is met first, 'queriesBeforeRetryMaster' or 'secondsBeforeRetryMaster' will cause an attempt to be made to reconnect to the master. Time in seconds, defaults to 30", "3.0.2", "High Availability and Clustering", 8);
/*      */ 
/* 1190 */   private ConnectionProperties.StringConnectionProperty serverTimezone = new ConnectionProperties.StringConnectionProperty(this, "serverTimezone", null, "Override detection/mapping of timezone. Used when timezone from server doesn't map to Java timezone", "3.0.2", "Miscellaneous", -2147483648);
/*      */ 
/* 1196 */   private ConnectionProperties.StringConnectionProperty sessionVariables = new ConnectionProperties.StringConnectionProperty(this, "sessionVariables", null, "A comma-separated list of name/value pairs to be sent as SET SESSION ... to  the server when the driver connects.", "3.1.8", "Miscellaneous", 2147483647);
/*      */ 
/* 1202 */   private ConnectionProperties.IntegerConnectionProperty slowQueryThresholdMillis = new ConnectionProperties.IntegerConnectionProperty(this, "slowQueryThresholdMillis", 2000, 0, 2147483647, "If 'logSlowQueries' is enabled, how long should a query (in ms) before it is logged as 'slow'?", "3.1.2", "Debuging/Profiling", 9);
/*      */ 
/* 1210 */   private ConnectionProperties.StringConnectionProperty socketFactoryClassName = new ConnectionProperties.StringConnectionProperty(this, "socketFactory", StandardSocketFactory.class.getName(), "The name of the class that the driver should use for creating socket connections to the server. This class must implement the interface 'com.mysql.jdbc.SocketFactory' and have public no-args constructor.", "3.0.3", "Connection/Authentication", 4);
/*      */ 
/* 1216 */   private ConnectionProperties.IntegerConnectionProperty socketTimeout = new ConnectionProperties.IntegerConnectionProperty(this, "socketTimeout", 0, 0, 2147483647, "Timeout on network socket operations (0, the default means no timeout).", "3.0.1", "Connection/Authentication", 10);
/*      */ 
/* 1224 */   private ConnectionProperties.BooleanConnectionProperty strictFloatingPoint = new ConnectionProperties.BooleanConnectionProperty(this, "strictFloatingPoint", false, "Used only in older versions of compliance test", "3.0.0", "Miscellaneous", -2147483648);
/*      */ 
/* 1229 */   private ConnectionProperties.BooleanConnectionProperty strictUpdates = new ConnectionProperties.BooleanConnectionProperty(this, "strictUpdates", true, "Should the driver do strict checking (all primary keys selected) of updatable result sets (true, false, defaults to 'true')?", "3.0.4", "Miscellaneous", -2147483648);
/*      */ 
/* 1235 */   private ConnectionProperties.BooleanConnectionProperty overrideSupportsIntegrityEnhancementFacility = new ConnectionProperties.BooleanConnectionProperty(this, "overrideSupportsIntegrityEnhancementFacility", false, "Should the driver return \"true\" for DatabaseMetaData.supportsIntegrityEnhancementFacility() even if the database doesn't support it to workaround applications that require this method to return \"true\" to signal support of foreign keys, even though the SQL specification states that this facility contains much more than just foreign key support (one such application being OpenOffice)?", "3.1.12", "Miscellaneous", -2147483648);
/*      */ 
/* 1244 */   private ConnectionProperties.BooleanConnectionProperty tinyInt1isBit = new ConnectionProperties.BooleanConnectionProperty(this, "tinyInt1isBit", true, "Should the driver treat the datatype TINYINT(1) as the BIT type (because the server silently converts BIT -> TINYINT(1) when creating tables)?", "3.0.16", "Miscellaneous", -2147483648);
/*      */ 
/* 1251 */   private ConnectionProperties.BooleanConnectionProperty traceProtocol = new ConnectionProperties.BooleanConnectionProperty(this, "traceProtocol", false, "Should trace-level network protocol be logged?", "3.1.2", "Debuging/Profiling", -2147483648);
/*      */ 
/* 1256 */   private ConnectionProperties.BooleanConnectionProperty transformedBitIsBoolean = new ConnectionProperties.BooleanConnectionProperty(this, "transformedBitIsBoolean", false, "If the driver converts TINYINT(1) to a different type, should it use BOOLEAN instead of BIT  for future compatibility with MySQL-5.0, as MySQL-5.0 has a BIT type?", "3.1.9", "Miscellaneous", -2147483648);
/*      */ 
/* 1263 */   private ConnectionProperties.BooleanConnectionProperty useCompression = new ConnectionProperties.BooleanConnectionProperty(this, "useCompression", false, "Use zlib compression when communicating with the server (true/false)? Defaults to 'false'.", "3.0.17", "Connection/Authentication", -2147483648);
/*      */ 
/* 1269 */   private ConnectionProperties.StringConnectionProperty useConfig = new ConnectionProperties.StringConnectionProperty(this, "useConfigs", null, "Load the comma-delimited list of configuration properties before parsing the URL or applying user-specified properties. These configurations are explained in the 'Configurations' of the documentation.", "3.1.5", "Connection/Authentication", 2147483647);
/*      */ 
/* 1276 */   private ConnectionProperties.BooleanConnectionProperty useCursorFetch = new ConnectionProperties.BooleanConnectionProperty(this, "useCursorFetch", false, "If connected to MySQL > 5.0.2, and setFetchSize() > 0 on a statement, should  that statement use cursor-based fetching to retrieve rows?", "5.0.0", "Performance Extensions", 2147483647);
/*      */ 
/* 1283 */   private ConnectionProperties.BooleanConnectionProperty useFastIntParsing = new ConnectionProperties.BooleanConnectionProperty(this, "useFastIntParsing", true, "Use internal String->Integer conversion routines to avoid excessive object creation?", "3.1.4", "Performance Extensions", -2147483648);
/*      */ 
/* 1289 */   private ConnectionProperties.BooleanConnectionProperty useHostsInPrivileges = new ConnectionProperties.BooleanConnectionProperty(this, "useHostsInPrivileges", true, "Add '@hostname' to users in DatabaseMetaData.getColumn/TablePrivileges() (true/false), defaults to 'true'.", "3.0.2", "Miscellaneous", -2147483648);
/*      */ 
/* 1294 */   private ConnectionProperties.BooleanConnectionProperty useInformationSchema = new ConnectionProperties.BooleanConnectionProperty(this, "useInformationSchema", false, "When connected to MySQL-5.0.7 or newer, should the driver use the INFORMATION_SCHEMA to  derive information used by DatabaseMetaData?", "5.0.0", "Miscellaneous", -2147483648);
/*      */ 
/* 1300 */   private ConnectionProperties.BooleanConnectionProperty useJDBCCompliantTimezoneShift = new ConnectionProperties.BooleanConnectionProperty(this, "useJDBCCompliantTimezoneShift", false, "Should the driver use JDBC-compliant rules when converting TIME/TIMESTAMP/DATETIME values' timezone information for those JDBC arguments which take a java.util.Calendar argument? (Notice that this option is exclusive of the \"useTimezone=true\" configuration option.)", "5.0.0", "Miscellaneous", -2147483648);
/*      */ 
/* 1308 */   private ConnectionProperties.BooleanConnectionProperty useLocalSessionState = new ConnectionProperties.BooleanConnectionProperty(this, "useLocalSessionState", false, "Should the driver refer to the internal values of autocommit and transaction isolation that are set  by Connection.setAutoCommit() and Connection.setTransactionIsolation(), rather than querying the database?", "3.1.7", "Performance Extensions", -2147483648);
/*      */ 
/* 1315 */   private ConnectionProperties.BooleanConnectionProperty useOldAliasMetadataBehavior = new ConnectionProperties.BooleanConnectionProperty(this, "useOldAliasMetadataBehavior", true, "Should the driver use the legacy behavior for \"AS\" clauses on columns and tables, and only return aliases (if any) for ResultSetMetaData.getColumnName() or ResultSetMetaData.getTableName() rather than the original column/table name?", "5.0.4", "Miscellaneous", -2147483648);
/*      */ 
/* 1325 */   private ConnectionProperties.BooleanConnectionProperty useOldUTF8Behavior = new ConnectionProperties.BooleanConnectionProperty(this, "useOldUTF8Behavior", false, "Use the UTF-8 behavior the driver did when communicating with 4.0 and older servers", "3.1.6", "Miscellaneous", -2147483648);
/*      */ 
/* 1331 */   private boolean useOldUTF8BehaviorAsBoolean = false;
/*      */ 
/* 1333 */   private ConnectionProperties.BooleanConnectionProperty useOnlyServerErrorMessages = new ConnectionProperties.BooleanConnectionProperty(this, "useOnlyServerErrorMessages", true, "Don't prepend 'standard' SQLState error messages to error messages returned by the server.", "3.0.15", "Miscellaneous", -2147483648);
/*      */ 
/* 1339 */   private ConnectionProperties.BooleanConnectionProperty useReadAheadInput = new ConnectionProperties.BooleanConnectionProperty(this, "useReadAheadInput", true, "Use newer, optimized non-blocking, buffered input stream when reading from the server?", "3.1.5", "Performance Extensions", -2147483648);
/*      */ 
/* 1345 */   private ConnectionProperties.BooleanConnectionProperty useSqlStateCodes = new ConnectionProperties.BooleanConnectionProperty(this, "useSqlStateCodes", true, "Use SQL Standard state codes instead of 'legacy' X/Open/SQL state codes (true/false), default is 'true'", "3.1.3", "Miscellaneous", -2147483648);
/*      */ 
/* 1351 */   private ConnectionProperties.BooleanConnectionProperty useSSL = new ConnectionProperties.BooleanConnectionProperty(this, "useSSL", false, "Use SSL when communicating with the server (true/false), defaults to 'false'", "3.0.2", "Security", 2);
/*      */ 
/* 1357 */   private ConnectionProperties.BooleanConnectionProperty useStreamLengthsInPrepStmts = new ConnectionProperties.BooleanConnectionProperty(this, "useStreamLengthsInPrepStmts", true, "Honor stream length parameter in PreparedStatement/ResultSet.setXXXStream() method calls (true/false, defaults to 'true')?", "3.0.2", "Miscellaneous", -2147483648);
/*      */ 
/* 1364 */   private ConnectionProperties.BooleanConnectionProperty useTimezone = new ConnectionProperties.BooleanConnectionProperty(this, "useTimezone", false, "Convert time/date types between client and server timezones (true/false, defaults to 'false')?", "3.0.2", "Miscellaneous", -2147483648);
/*      */ 
/* 1370 */   private ConnectionProperties.BooleanConnectionProperty useUltraDevWorkAround = new ConnectionProperties.BooleanConnectionProperty(this, "ultraDevHack", false, "Create PreparedStatements for prepareCall() when required, because UltraDev  is broken and issues a prepareCall() for _all_ statements? (true/false, defaults to 'false')", "2.0.3", "Miscellaneous", -2147483648);
/*      */ 
/* 1377 */   private ConnectionProperties.BooleanConnectionProperty useUnbufferedInput = new ConnectionProperties.BooleanConnectionProperty(this, "useUnbufferedInput", true, "Don't use BufferedInputStream for reading data from the server", "3.0.11", "Miscellaneous", -2147483648);
/*      */ 
/* 1382 */   private ConnectionProperties.BooleanConnectionProperty useUnicode = new ConnectionProperties.BooleanConnectionProperty(this, "useUnicode", true, "Should the driver use Unicode character encodings when handling strings? Should only be used when the driver can't determine the character set mapping, or you are trying to 'force' the driver to use a character set that MySQL either doesn't natively support (such as UTF-8), true/false, defaults to 'true'", "1.1g", "Miscellaneous", 0);
/*      */ 
/* 1389 */   private boolean useUnicodeAsBoolean = true;
/*      */ 
/* 1391 */   private ConnectionProperties.BooleanConnectionProperty useUsageAdvisor = new ConnectionProperties.BooleanConnectionProperty(this, "useUsageAdvisor", false, "Should the driver issue 'usage' warnings advising proper and efficient usage of JDBC and MySQL Connector/J to the log (true/false, defaults to 'false')?", "3.1.1", "Debuging/Profiling", 10);
/*      */ 
/* 1397 */   private boolean useUsageAdvisorAsBoolean = false;
/*      */ 
/* 1399 */   private ConnectionProperties.BooleanConnectionProperty yearIsDateType = new ConnectionProperties.BooleanConnectionProperty(this, "yearIsDateType", true, "Should the JDBC driver treat the MySQL type \"YEAR\" as a java.sql.Date, or as a SHORT?", "3.1.9", "Miscellaneous", -2147483648);
/*      */ 
/* 1405 */   private ConnectionProperties.StringConnectionProperty zeroDateTimeBehavior = new ConnectionProperties.StringConnectionProperty(this, "zeroDateTimeBehavior", "exception", new String[] { "exception", "round", "convertToNull" }, "What should happen when the driver encounters DATETIME values that are composed entirely of zeroes (used by MySQL to represent invalid dates)? Valid values are 'exception', 'round' and 'convertToNull'.", "3.1.4", "Miscellaneous", -2147483648);
/*      */ 
/* 1421 */   private ConnectionProperties.BooleanConnectionProperty useJvmCharsetConverters = new ConnectionProperties.BooleanConnectionProperty(this, "useJvmCharsetConverters", true, "Always use the character encoding routines built into the JVM, rather than using lookup tables for single-byte character sets? (The default of \"true\" for this is appropriate for newer JVMs", "5.0.1", "Performance Extensions", -2147483648);
/*      */ 
/* 1426 */   private ConnectionProperties.BooleanConnectionProperty useGmtMillisForDatetimes = new ConnectionProperties.BooleanConnectionProperty(this, "useGmtMillisForDatetimes", false, "Convert between session timezone and GMT before creating Date and Timestamp instances (value of \"false\" is legacy behavior, \"true\" leads to more JDBC-compliant behavior.", "3.1.12", "Miscellaneous", -2147483648);
/*      */ 
/* 1428 */   private ConnectionProperties.BooleanConnectionProperty dumpMetadataOnColumnNotFound = new ConnectionProperties.BooleanConnectionProperty(this, "dumpMetadataOnColumnNotFound", false, "Should the driver dump the field-level metadata of a result set into the exception message when ResultSet.findColumn() fails?", "3.1.13", "Debuging/Profiling", -2147483648);
/*      */ 
/*      */   protected static DriverPropertyInfo[] exposeAsDriverPropertyInfo(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/*  607 */     return new ConnectionProperties.1().exposeAsDriverPropertyInfoInternal(info, slotsToReserve);
/*      */   }
/*      */ 
/*      */   protected DriverPropertyInfo[] exposeAsDriverPropertyInfoInternal(Properties info, int slotsToReserve)
/*      */     throws SQLException
/*      */   {
/* 1432 */     initializeProperties(info);
/*      */ 
/* 1434 */     int numProperties = PROPERTY_LIST.size();
/*      */ 
/* 1436 */     int listSize = numProperties + slotsToReserve;
/*      */ 
/* 1438 */     DriverPropertyInfo[] driverProperties = new DriverPropertyInfo[listSize];
/*      */ 
/* 1440 */     for (int i = slotsToReserve; i < listSize; i++) {
/* 1441 */       Field propertyField = (Field)PROPERTY_LIST.get(i - slotsToReserve);
/*      */       try
/*      */       {
/* 1445 */         ConnectionProperties.ConnectionProperty propToExpose = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 1448 */         if (info != null) {
/* 1449 */           propToExpose.initializeFrom(info);
/*      */         }
/*      */ 
/* 1453 */         driverProperties[i] = propToExpose.getAsDriverPropertyInfo();
/*      */       } catch (IllegalAccessException iae) {
/* 1455 */         throw SQLError.createSQLException("Internal properties failure", "S1000");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1460 */     return driverProperties;
/*      */   }
/*      */ 
/*      */   protected Properties exposeAsProperties(Properties info) throws SQLException
/*      */   {
/* 1465 */     if (info == null) {
/* 1466 */       info = new Properties();
/*      */     }
/*      */ 
/* 1469 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */ 
/* 1471 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 1472 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 1476 */         ConnectionProperties.ConnectionProperty propToGet = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 1479 */         Object propValue = propToGet.getValueAsObject();
/*      */ 
/* 1481 */         if (propValue != null)
/* 1482 */           info.setProperty(propToGet.getPropertyName(), propValue.toString());
/*      */       }
/*      */       catch (IllegalAccessException iae)
/*      */       {
/* 1486 */         throw SQLError.createSQLException("Internal properties failure", "S1000");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1491 */     return info;
/*      */   }
/*      */ 
/*      */   public String exposeAsXml()
/*      */     throws SQLException
/*      */   {
/* 1502 */     StringBuffer xmlBuf = new StringBuffer();
/* 1503 */     xmlBuf.append("<ConnectionProperties>");
/*      */ 
/* 1505 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */ 
/* 1507 */     int numCategories = PROPERTY_CATEGORIES.length;
/*      */ 
/* 1509 */     Map propertyListByCategory = new HashMap();
/*      */ 
/* 1511 */     for (int i = 0; i < numCategories; i++) {
/* 1512 */       propertyListByCategory.put(PROPERTY_CATEGORIES[i], new Map[] { new TreeMap(), new TreeMap() });
/*      */     }
/*      */ 
/* 1522 */     ConnectionProperties.StringConnectionProperty userProp = new ConnectionProperties.StringConnectionProperty(this, "user", null, "The user to connect as", "all", "Connection/Authentication", -2147483647);
/*      */ 
/* 1526 */     ConnectionProperties.StringConnectionProperty passwordProp = new ConnectionProperties.StringConnectionProperty(this, "password", null, "The password to use when connecting", "all", "Connection/Authentication", -2147483646);
/*      */ 
/* 1531 */     Map[] connectionSortMaps = (Map[])propertyListByCategory.get("Connection/Authentication");
/*      */ 
/* 1533 */     connectionSortMaps[0].put(new Integer(userProp.getOrder()), userProp);
/* 1534 */     connectionSortMaps[0].put(new Integer(passwordProp.getOrder()), passwordProp);
/*      */     try
/*      */     {
/* 1538 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 1539 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */ 
/* 1541 */         ConnectionProperties.ConnectionProperty propToGet = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 1543 */         Map[] sortMaps = (Map[])propertyListByCategory.get(propToGet.getCategoryName());
/*      */ 
/* 1545 */         int orderInCategory = propToGet.getOrder();
/*      */ 
/* 1547 */         if (orderInCategory == -2147483648)
/* 1548 */           sortMaps[1].put(propToGet.getPropertyName(), propToGet);
/*      */         else {
/* 1550 */           sortMaps[0].put(new Integer(orderInCategory), propToGet);
/*      */         }
/*      */       }
/*      */ 
/* 1554 */       for (int j = 0; j < numCategories; j++) {
/* 1555 */         Map[] sortMaps = (Map[])propertyListByCategory.get(PROPERTY_CATEGORIES[j]);
/*      */ 
/* 1557 */         Iterator orderedIter = sortMaps[0].values().iterator();
/* 1558 */         Iterator alphaIter = sortMaps[1].values().iterator();
/*      */ 
/* 1560 */         xmlBuf.append("\n <PropertyCategory name=\"");
/* 1561 */         xmlBuf.append(PROPERTY_CATEGORIES[j]);
/* 1562 */         xmlBuf.append("\">");
/*      */ 
/* 1564 */         while (orderedIter.hasNext()) {
/* 1565 */           ConnectionProperties.ConnectionProperty propToGet = (ConnectionProperties.ConnectionProperty)orderedIter.next();
/*      */ 
/* 1568 */           xmlBuf.append("\n  <Property name=\"");
/* 1569 */           xmlBuf.append(propToGet.getPropertyName());
/* 1570 */           xmlBuf.append("\" required=\"");
/* 1571 */           xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */ 
/* 1573 */           xmlBuf.append("\" default=\"");
/*      */ 
/* 1575 */           if (propToGet.getDefaultValue() != null) {
/* 1576 */             xmlBuf.append(propToGet.getDefaultValue());
/*      */           }
/*      */ 
/* 1579 */           xmlBuf.append("\" sortOrder=\"");
/* 1580 */           xmlBuf.append(propToGet.getOrder());
/* 1581 */           xmlBuf.append("\" since=\"");
/* 1582 */           xmlBuf.append(propToGet.sinceVersion);
/* 1583 */           xmlBuf.append("\">\n");
/* 1584 */           xmlBuf.append("    ");
/* 1585 */           xmlBuf.append(propToGet.description);
/* 1586 */           xmlBuf.append("\n  </Property>");
/*      */         }
/*      */ 
/* 1589 */         while (alphaIter.hasNext()) {
/* 1590 */           ConnectionProperties.ConnectionProperty propToGet = (ConnectionProperties.ConnectionProperty)alphaIter.next();
/*      */ 
/* 1593 */           xmlBuf.append("\n  <Property name=\"");
/* 1594 */           xmlBuf.append(propToGet.getPropertyName());
/* 1595 */           xmlBuf.append("\" required=\"");
/* 1596 */           xmlBuf.append(propToGet.required ? "Yes" : "No");
/*      */ 
/* 1598 */           xmlBuf.append("\" default=\"");
/*      */ 
/* 1600 */           if (propToGet.getDefaultValue() != null) {
/* 1601 */             xmlBuf.append(propToGet.getDefaultValue());
/*      */           }
/*      */ 
/* 1604 */           xmlBuf.append("\" sortOrder=\"alpha\" since=\"");
/* 1605 */           xmlBuf.append(propToGet.sinceVersion);
/* 1606 */           xmlBuf.append("\">\n");
/* 1607 */           xmlBuf.append("    ");
/* 1608 */           xmlBuf.append(propToGet.description);
/* 1609 */           xmlBuf.append("\n  </Property>");
/*      */         }
/*      */ 
/* 1612 */         xmlBuf.append("\n </PropertyCategory>");
/*      */       }
/*      */     } catch (IllegalAccessException iae) {
/* 1615 */       throw SQLError.createSQLException("Internal properties failure", "S1000");
/*      */     }
/*      */ 
/* 1619 */     xmlBuf.append("\n</ConnectionProperties>");
/*      */ 
/* 1621 */     return xmlBuf.toString();
/*      */   }
/*      */ 
/*      */   public boolean getAllowLoadLocalInfile()
/*      */   {
/* 1630 */     return this.allowLoadLocalInfile.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAllowMultiQueries()
/*      */   {
/* 1639 */     return this.allowMultiQueries.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAllowNanAndInf()
/*      */   {
/* 1646 */     return this.allowNanAndInf.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAllowUrlInLocalInfile()
/*      */   {
/* 1653 */     return this.allowUrlInLocalInfile.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAlwaysSendSetIsolation()
/*      */   {
/* 1660 */     return this.alwaysSendSetIsolation.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAutoDeserialize()
/*      */   {
/* 1667 */     return this.autoDeserialize.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getAutoGenerateTestcaseScript() {
/* 1671 */     return this.autoGenerateTestcaseScriptAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getAutoReconnectForPools()
/*      */   {
/* 1680 */     return this.autoReconnectForPoolsAsBoolean;
/*      */   }
/*      */ 
/*      */   public int getBlobSendChunkSize()
/*      */   {
/* 1687 */     return this.blobSendChunkSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getCacheCallableStatements()
/*      */   {
/* 1696 */     return this.cacheCallableStatements.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getCachePreparedStatements()
/*      */   {
/* 1705 */     return ((Boolean)this.cachePreparedStatements.getValueAsObject()).booleanValue();
/*      */   }
/*      */ 
/*      */   public boolean getCacheResultSetMetadata()
/*      */   {
/* 1715 */     return this.cacheResultSetMetaDataAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getCacheServerConfiguration()
/*      */   {
/* 1722 */     return this.cacheServerConfiguration.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getCallableStatementCacheSize()
/*      */   {
/* 1731 */     return this.callableStatementCacheSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getCapitalizeTypeNames()
/*      */   {
/* 1740 */     return this.capitalizeTypeNames.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public String getCharacterSetResults()
/*      */   {
/* 1749 */     return this.characterSetResults.getValueAsString();
/*      */   }
/*      */ 
/*      */   public boolean getClobberStreamingResults()
/*      */   {
/* 1758 */     return this.clobberStreamingResults.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public String getClobCharacterEncoding() {
/* 1762 */     return this.clobCharacterEncoding.getValueAsString();
/*      */   }
/*      */ 
/*      */   public String getConnectionCollation()
/*      */   {
/* 1771 */     return this.connectionCollation.getValueAsString();
/*      */   }
/*      */ 
/*      */   public int getConnectTimeout()
/*      */   {
/* 1780 */     return this.connectTimeout.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getContinueBatchOnError()
/*      */   {
/* 1789 */     return this.continueBatchOnError.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getCreateDatabaseIfNotExist() {
/* 1793 */     return this.createDatabaseIfNotExist.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getDefaultFetchSize() {
/* 1797 */     return this.defaultFetchSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getDontTrackOpenResources()
/*      */   {
/* 1804 */     return this.dontTrackOpenResources.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getDumpQueriesOnException()
/*      */   {
/* 1813 */     return this.dumpQueriesOnException.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getDynamicCalendars()
/*      */   {
/* 1820 */     return this.dynamicCalendars.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getElideSetAutoCommits()
/*      */   {
/* 1829 */     return this.elideSetAutoCommits.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getEmptyStringsConvertToZero() {
/* 1833 */     return this.emptyStringsConvertToZero.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getEmulateLocators()
/*      */   {
/* 1842 */     return this.emulateLocators.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getEmulateUnsupportedPstmts()
/*      */   {
/* 1849 */     return this.emulateUnsupportedPstmts.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getEnablePacketDebug()
/*      */   {
/* 1858 */     return this.enablePacketDebug.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public String getEncoding()
/*      */   {
/* 1867 */     return this.characterEncodingAsString;
/*      */   }
/*      */ 
/*      */   public boolean getExplainSlowQueries()
/*      */   {
/* 1876 */     return this.explainSlowQueries.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getFailOverReadOnly()
/*      */   {
/* 1885 */     return this.failOverReadOnly.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getGatherPerformanceMetrics()
/*      */   {
/* 1894 */     return this.gatherPerformanceMetrics.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   protected boolean getHighAvailability()
/*      */   {
/* 1903 */     return this.highAvailabilityAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getHoldResultsOpenOverStatementClose()
/*      */   {
/* 1910 */     return this.holdResultsOpenOverStatementClose.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getIgnoreNonTxTables()
/*      */   {
/* 1919 */     return this.ignoreNonTxTables.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getInitialTimeout()
/*      */   {
/* 1928 */     return this.initialTimeout.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getInteractiveClient()
/*      */   {
/* 1937 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getIsInteractiveClient()
/*      */   {
/* 1946 */     return this.isInteractiveClient.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getJdbcCompliantTruncation()
/*      */   {
/* 1955 */     return this.jdbcCompliantTruncation.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getLocatorFetchBufferSize()
/*      */   {
/* 1962 */     return this.locatorFetchBufferSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public String getLogger()
/*      */   {
/* 1971 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */ 
/*      */   public String getLoggerClassName()
/*      */   {
/* 1980 */     return this.loggerClassName.getValueAsString();
/*      */   }
/*      */ 
/*      */   public boolean getLogSlowQueries()
/*      */   {
/* 1989 */     return this.logSlowQueries.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getMaintainTimeStats() {
/* 1993 */     return this.maintainTimeStatsAsBoolean;
/*      */   }
/*      */ 
/*      */   public int getMaxQuerySizeToLog()
/*      */   {
/* 2002 */     return this.maxQuerySizeToLog.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public int getMaxReconnects()
/*      */   {
/* 2011 */     return this.maxReconnects.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public int getMaxRows()
/*      */   {
/* 2020 */     return this.maxRowsAsInt;
/*      */   }
/*      */ 
/*      */   public int getMetadataCacheSize()
/*      */   {
/* 2030 */     return this.metadataCacheSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getNoDatetimeStringSync()
/*      */   {
/* 2037 */     return this.noDatetimeStringSync.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getNullCatalogMeansCurrent() {
/* 2041 */     return this.nullCatalogMeansCurrent.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getNullNamePatternMatchesAll() {
/* 2045 */     return this.nullNamePatternMatchesAll.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getPacketDebugBufferSize()
/*      */   {
/* 2054 */     return this.packetDebugBufferSize.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getParanoid()
/*      */   {
/* 2063 */     return this.paranoid.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getPedantic()
/*      */   {
/* 2072 */     return this.pedantic.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getPreparedStatementCacheSize()
/*      */   {
/* 2081 */     return ((Integer)this.preparedStatementCacheSize.getValueAsObject()).intValue();
/*      */   }
/*      */ 
/*      */   public int getPreparedStatementCacheSqlLimit()
/*      */   {
/* 2091 */     return ((Integer)this.preparedStatementCacheSqlLimit.getValueAsObject()).intValue();
/*      */   }
/*      */ 
/*      */   public boolean getProfileSql()
/*      */   {
/* 2101 */     return this.profileSQLAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getProfileSQL()
/*      */   {
/* 2110 */     return this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public String getPropertiesTransform()
/*      */   {
/* 2117 */     return this.propertiesTransform.getValueAsString();
/*      */   }
/*      */ 
/*      */   public int getQueriesBeforeRetryMaster()
/*      */   {
/* 2126 */     return this.queriesBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getReconnectAtTxEnd()
/*      */   {
/* 2135 */     return this.reconnectTxAtEndAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getRelaxAutoCommit()
/*      */   {
/* 2144 */     return this.relaxAutoCommit.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getReportMetricsIntervalMillis()
/*      */   {
/* 2153 */     return this.reportMetricsIntervalMillis.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getRequireSSL()
/*      */   {
/* 2162 */     return this.requireSSL.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   protected boolean getRetainStatementAfterResultSetClose() {
/* 2166 */     return this.retainStatementAfterResultSetClose.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getRollbackOnPooledClose()
/*      */   {
/* 2173 */     return this.rollbackOnPooledClose.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getRoundRobinLoadBalance()
/*      */   {
/* 2182 */     return this.roundRobinLoadBalance.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getRunningCTS13()
/*      */   {
/* 2189 */     return this.runningCTS13.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public int getSecondsBeforeRetryMaster()
/*      */   {
/* 2198 */     return this.secondsBeforeRetryMaster.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public String getServerTimezone()
/*      */   {
/* 2207 */     return this.serverTimezone.getValueAsString();
/*      */   }
/*      */ 
/*      */   public String getSessionVariables()
/*      */   {
/* 2214 */     return this.sessionVariables.getValueAsString();
/*      */   }
/*      */ 
/*      */   public int getSlowQueryThresholdMillis()
/*      */   {
/* 2223 */     return this.slowQueryThresholdMillis.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public String getSocketFactoryClassName()
/*      */   {
/* 2232 */     return this.socketFactoryClassName.getValueAsString();
/*      */   }
/*      */ 
/*      */   public int getSocketTimeout()
/*      */   {
/* 2241 */     return this.socketTimeout.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public boolean getStrictFloatingPoint()
/*      */   {
/* 2250 */     return this.strictFloatingPoint.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getStrictUpdates()
/*      */   {
/* 2259 */     return this.strictUpdates.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getTinyInt1isBit()
/*      */   {
/* 2266 */     return this.tinyInt1isBit.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getTraceProtocol()
/*      */   {
/* 2275 */     return this.traceProtocol.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getTransformedBitIsBoolean() {
/* 2279 */     return this.transformedBitIsBoolean.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseCompression()
/*      */   {
/* 2288 */     return this.useCompression.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseFastIntParsing()
/*      */   {
/* 2295 */     return this.useFastIntParsing.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseHostsInPrivileges()
/*      */   {
/* 2304 */     return this.useHostsInPrivileges.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseInformationSchema() {
/* 2308 */     return this.useInformationSchema.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseLocalSessionState()
/*      */   {
/* 2315 */     return this.useLocalSessionState.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseOldUTF8Behavior()
/*      */   {
/* 2322 */     return this.useOldUTF8BehaviorAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getUseOnlyServerErrorMessages()
/*      */   {
/* 2329 */     return this.useOnlyServerErrorMessages.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseReadAheadInput()
/*      */   {
/* 2336 */     return this.useReadAheadInput.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseServerPreparedStmts()
/*      */   {
/* 2345 */     return this.detectServerPreparedStmts.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseSqlStateCodes()
/*      */   {
/* 2354 */     return this.useSqlStateCodes.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseSSL()
/*      */   {
/* 2363 */     return this.useSSL.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseStreamLengthsInPrepStmts()
/*      */   {
/* 2372 */     return this.useStreamLengthsInPrepStmts.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseTimezone()
/*      */   {
/* 2381 */     return this.useTimezone.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseUltraDevWorkAround()
/*      */   {
/* 2390 */     return this.useUltraDevWorkAround.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseUnbufferedInput()
/*      */   {
/* 2399 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseUnicode()
/*      */   {
/* 2408 */     return this.useUnicodeAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getUseUsageAdvisor()
/*      */   {
/* 2417 */     return this.useUsageAdvisorAsBoolean;
/*      */   }
/*      */ 
/*      */   public boolean getYearIsDateType() {
/* 2421 */     return this.yearIsDateType.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public String getZeroDateTimeBehavior()
/*      */   {
/* 2428 */     return this.zeroDateTimeBehavior.getValueAsString();
/*      */   }
/*      */ 
/*      */   protected void initializeFromRef(Reference ref)
/*      */     throws SQLException
/*      */   {
/* 2442 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */ 
/* 2444 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 2445 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 2449 */         ConnectionProperties.ConnectionProperty propToSet = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 2452 */         if (ref != null)
/* 2453 */           propToSet.initializeFrom(ref);
/*      */       }
/*      */       catch (IllegalAccessException iae) {
/* 2456 */         throw SQLError.createSQLException("Internal properties failure", "S1000");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2461 */     postInitialization();
/*      */   }
/*      */ 
/*      */   protected void initializeProperties(Properties info)
/*      */     throws SQLException
/*      */   {
/* 2474 */     if (info != null)
/*      */     {
/* 2476 */       String profileSqlLc = info.getProperty("profileSql");
/*      */ 
/* 2478 */       if (profileSqlLc != null) {
/* 2479 */         info.put("profileSQL", profileSqlLc);
/*      */       }
/*      */ 
/* 2482 */       Properties infoCopy = (Properties)info.clone();
/*      */ 
/* 2484 */       infoCopy.remove("HOST");
/* 2485 */       infoCopy.remove("user");
/* 2486 */       infoCopy.remove("password");
/* 2487 */       infoCopy.remove("DBNAME");
/* 2488 */       infoCopy.remove("PORT");
/* 2489 */       infoCopy.remove("profileSql");
/*      */ 
/* 2491 */       int numPropertiesToSet = PROPERTY_LIST.size();
/*      */ 
/* 2493 */       for (int i = 0; i < numPropertiesToSet; i++) {
/* 2494 */         Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */         try
/*      */         {
/* 2498 */           ConnectionProperties.ConnectionProperty propToSet = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 2501 */           propToSet.initializeFrom(infoCopy);
/*      */         } catch (IllegalAccessException iae) {
/* 2503 */           throw SQLError.createSQLException("Unable to initialize driver properties due to " + iae.toString(), "S1000");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2526 */       postInitialization();
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void postInitialization()
/*      */     throws SQLException
/*      */   {
/* 2533 */     if (this.profileSql.getValueAsObject() != null) {
/* 2534 */       this.profileSQL.initializeFrom(this.profileSql.getValueAsObject().toString());
/*      */     }
/*      */ 
/* 2538 */     this.reconnectTxAtEndAsBoolean = ((Boolean)this.reconnectAtTxEnd.getValueAsObject()).booleanValue();
/*      */ 
/* 2542 */     if (getMaxRows() == 0)
/*      */     {
/* 2545 */       this.maxRows.setValueAsObject(new Integer(-1));
/*      */     }
/*      */ 
/* 2551 */     String testEncoding = getEncoding();
/*      */ 
/* 2553 */     if (testEncoding != null)
/*      */     {
/*      */       try
/*      */       {
/* 2557 */         String testString = "abc";
/* 2558 */         testString.getBytes(testEncoding);
/*      */       } catch (UnsupportedEncodingException UE) {
/* 2560 */         throw SQLError.createSQLException("Unsupported character encoding '" + testEncoding + "'.", "0S100");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2568 */     if (((Boolean)this.cacheResultSetMetadata.getValueAsObject()).booleanValue()) {
/*      */       try
/*      */       {
/* 2571 */         Class.forName("java.util.LinkedHashMap");
/*      */       } catch (ClassNotFoundException cnfe) {
/* 2573 */         this.cacheResultSetMetadata.setValue(false);
/*      */       }
/*      */     }
/*      */ 
/* 2577 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */ 
/* 2579 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/* 2580 */     this.characterEncodingAsString = ((String)this.characterEncoding.getValueAsObject());
/*      */ 
/* 2582 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/* 2583 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */ 
/* 2585 */     this.maxRowsAsInt = ((Integer)this.maxRows.getValueAsObject()).intValue();
/*      */ 
/* 2587 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/* 2588 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */ 
/* 2590 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */ 
/* 2592 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */ 
/* 2594 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */ 
/* 2596 */     this.jdbcCompliantTruncationForReads = getJdbcCompliantTruncation();
/*      */   }
/*      */ 
/*      */   public void setAllowLoadLocalInfile(boolean property)
/*      */   {
/* 2605 */     this.allowLoadLocalInfile.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setAllowMultiQueries(boolean property)
/*      */   {
/* 2614 */     this.allowMultiQueries.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setAllowNanAndInf(boolean flag)
/*      */   {
/* 2622 */     this.allowNanAndInf.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setAllowUrlInLocalInfile(boolean flag)
/*      */   {
/* 2630 */     this.allowUrlInLocalInfile.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setAlwaysSendSetIsolation(boolean flag)
/*      */   {
/* 2638 */     this.alwaysSendSetIsolation.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setAutoDeserialize(boolean flag)
/*      */   {
/* 2646 */     this.autoDeserialize.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setAutoGenerateTestcaseScript(boolean flag) {
/* 2650 */     this.autoGenerateTestcaseScript.setValue(flag);
/* 2651 */     this.autoGenerateTestcaseScriptAsBoolean = this.autoGenerateTestcaseScript.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setAutoReconnect(boolean flag)
/*      */   {
/* 2662 */     this.autoReconnect.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setAutoReconnectForConnectionPools(boolean property)
/*      */   {
/* 2671 */     this.autoReconnectForPools.setValue(property);
/* 2672 */     this.autoReconnectForPoolsAsBoolean = this.autoReconnectForPools.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setAutoReconnectForPools(boolean flag)
/*      */   {
/* 2683 */     this.autoReconnectForPools.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setBlobSendChunkSize(String value)
/*      */     throws SQLException
/*      */   {
/* 2691 */     this.blobSendChunkSize.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setCacheCallableStatements(boolean flag)
/*      */   {
/* 2701 */     this.cacheCallableStatements.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setCachePreparedStatements(boolean flag)
/*      */   {
/* 2711 */     this.cachePreparedStatements.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setCacheResultSetMetadata(boolean property)
/*      */   {
/* 2720 */     this.cacheResultSetMetadata.setValue(property);
/* 2721 */     this.cacheResultSetMetaDataAsBoolean = this.cacheResultSetMetadata.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setCacheServerConfiguration(boolean flag)
/*      */   {
/* 2730 */     this.cacheServerConfiguration.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setCallableStatementCacheSize(int size)
/*      */   {
/* 2741 */     this.callableStatementCacheSize.setValue(size);
/*      */   }
/*      */ 
/*      */   public void setCapitalizeDBMDTypes(boolean property)
/*      */   {
/* 2750 */     this.capitalizeTypeNames.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setCapitalizeTypeNames(boolean flag)
/*      */   {
/* 2760 */     this.capitalizeTypeNames.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setCharacterEncoding(String encoding)
/*      */   {
/* 2770 */     this.characterEncoding.setValue(encoding);
/*      */   }
/*      */ 
/*      */   public void setCharacterSetResults(String characterSet)
/*      */   {
/* 2780 */     this.characterSetResults.setValue(characterSet);
/*      */   }
/*      */ 
/*      */   public void setClobberStreamingResults(boolean flag)
/*      */   {
/* 2790 */     this.clobberStreamingResults.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setClobCharacterEncoding(String encoding) {
/* 2794 */     this.clobCharacterEncoding.setValue(encoding);
/*      */   }
/*      */ 
/*      */   public void setConnectionCollation(String collation)
/*      */   {
/* 2804 */     this.connectionCollation.setValue(collation);
/*      */   }
/*      */ 
/*      */   public void setConnectTimeout(int timeoutMs)
/*      */   {
/* 2813 */     this.connectTimeout.setValue(timeoutMs);
/*      */   }
/*      */ 
/*      */   public void setContinueBatchOnError(boolean property)
/*      */   {
/* 2822 */     this.continueBatchOnError.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setCreateDatabaseIfNotExist(boolean flag) {
/* 2826 */     this.createDatabaseIfNotExist.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setDefaultFetchSize(int n) {
/* 2830 */     this.defaultFetchSize.setValue(n);
/*      */   }
/*      */ 
/*      */   public void setDetectServerPreparedStmts(boolean property)
/*      */   {
/* 2839 */     this.detectServerPreparedStmts.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setDontTrackOpenResources(boolean flag)
/*      */   {
/* 2847 */     this.dontTrackOpenResources.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setDumpQueriesOnException(boolean flag)
/*      */   {
/* 2857 */     this.dumpQueriesOnException.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setDynamicCalendars(boolean flag)
/*      */   {
/* 2865 */     this.dynamicCalendars.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setElideSetAutoCommits(boolean flag)
/*      */   {
/* 2875 */     this.elideSetAutoCommits.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setEmptyStringsConvertToZero(boolean flag) {
/* 2879 */     this.emptyStringsConvertToZero.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setEmulateLocators(boolean property)
/*      */   {
/* 2888 */     this.emulateLocators.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setEmulateUnsupportedPstmts(boolean flag)
/*      */   {
/* 2896 */     this.emulateUnsupportedPstmts.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setEnablePacketDebug(boolean flag)
/*      */   {
/* 2906 */     this.enablePacketDebug.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setEncoding(String property)
/*      */   {
/* 2915 */     this.characterEncoding.setValue(property);
/* 2916 */     this.characterEncodingAsString = this.characterEncoding.getValueAsString();
/*      */   }
/*      */ 
/*      */   public void setExplainSlowQueries(boolean flag)
/*      */   {
/* 2927 */     this.explainSlowQueries.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setFailOverReadOnly(boolean flag)
/*      */   {
/* 2937 */     this.failOverReadOnly.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setGatherPerformanceMetrics(boolean flag)
/*      */   {
/* 2947 */     this.gatherPerformanceMetrics.setValue(flag);
/*      */   }
/*      */ 
/*      */   protected void setHighAvailability(boolean property)
/*      */   {
/* 2956 */     this.autoReconnect.setValue(property);
/* 2957 */     this.highAvailabilityAsBoolean = this.autoReconnect.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setHoldResultsOpenOverStatementClose(boolean flag)
/*      */   {
/* 2965 */     this.holdResultsOpenOverStatementClose.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setIgnoreNonTxTables(boolean property)
/*      */   {
/* 2974 */     this.ignoreNonTxTables.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setInitialTimeout(int property)
/*      */   {
/* 2983 */     this.initialTimeout.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setIsInteractiveClient(boolean property)
/*      */   {
/* 2992 */     this.isInteractiveClient.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setJdbcCompliantTruncation(boolean flag)
/*      */   {
/* 3002 */     this.jdbcCompliantTruncation.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setLocatorFetchBufferSize(String value)
/*      */     throws SQLException
/*      */   {
/* 3010 */     this.locatorFetchBufferSize.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setLogger(String property)
/*      */   {
/* 3019 */     this.loggerClassName.setValueAsObject(property);
/*      */   }
/*      */ 
/*      */   public void setLoggerClassName(String className)
/*      */   {
/* 3029 */     this.loggerClassName.setValue(className);
/*      */   }
/*      */ 
/*      */   public void setLogSlowQueries(boolean flag)
/*      */   {
/* 3039 */     this.logSlowQueries.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setMaintainTimeStats(boolean flag) {
/* 3043 */     this.maintainTimeStats.setValue(flag);
/* 3044 */     this.maintainTimeStatsAsBoolean = this.maintainTimeStats.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setMaxQuerySizeToLog(int sizeInBytes)
/*      */   {
/* 3055 */     this.maxQuerySizeToLog.setValue(sizeInBytes);
/*      */   }
/*      */ 
/*      */   public void setMaxReconnects(int property)
/*      */   {
/* 3064 */     this.maxReconnects.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int property)
/*      */   {
/* 3073 */     this.maxRows.setValue(property);
/* 3074 */     this.maxRowsAsInt = this.maxRows.getValueAsInt();
/*      */   }
/*      */ 
/*      */   public void setMetadataCacheSize(int value)
/*      */   {
/* 3085 */     this.metadataCacheSize.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setNoDatetimeStringSync(boolean flag)
/*      */   {
/* 3093 */     this.noDatetimeStringSync.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setNullCatalogMeansCurrent(boolean value) {
/* 3097 */     this.nullCatalogMeansCurrent.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setNullNamePatternMatchesAll(boolean value) {
/* 3101 */     this.nullNamePatternMatchesAll.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setPacketDebugBufferSize(int size)
/*      */   {
/* 3111 */     this.packetDebugBufferSize.setValue(size);
/*      */   }
/*      */ 
/*      */   public void setParanoid(boolean property)
/*      */   {
/* 3120 */     this.paranoid.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setPedantic(boolean property)
/*      */   {
/* 3129 */     this.pedantic.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setPreparedStatementCacheSize(int cacheSize)
/*      */   {
/* 3139 */     this.preparedStatementCacheSize.setValue(cacheSize);
/*      */   }
/*      */ 
/*      */   public void setPreparedStatementCacheSqlLimit(int cacheSqlLimit)
/*      */   {
/* 3149 */     this.preparedStatementCacheSqlLimit.setValue(cacheSqlLimit);
/*      */   }
/*      */ 
/*      */   public void setProfileSql(boolean property)
/*      */   {
/* 3158 */     this.profileSQL.setValue(property);
/* 3159 */     this.profileSQLAsBoolean = this.profileSQL.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setProfileSQL(boolean flag)
/*      */   {
/* 3169 */     this.profileSQL.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setPropertiesTransform(String value)
/*      */   {
/* 3177 */     this.propertiesTransform.setValue(value);
/*      */   }
/*      */ 
/*      */   public void setQueriesBeforeRetryMaster(int property)
/*      */   {
/* 3186 */     this.queriesBeforeRetryMaster.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setReconnectAtTxEnd(boolean property)
/*      */   {
/* 3195 */     this.reconnectAtTxEnd.setValue(property);
/* 3196 */     this.reconnectTxAtEndAsBoolean = this.reconnectAtTxEnd.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setRelaxAutoCommit(boolean property)
/*      */   {
/* 3206 */     this.relaxAutoCommit.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setReportMetricsIntervalMillis(int millis)
/*      */   {
/* 3216 */     this.reportMetricsIntervalMillis.setValue(millis);
/*      */   }
/*      */ 
/*      */   public void setRequireSSL(boolean property)
/*      */   {
/* 3225 */     this.requireSSL.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setRetainStatementAfterResultSetClose(boolean flag) {
/* 3229 */     this.retainStatementAfterResultSetClose.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setRollbackOnPooledClose(boolean flag)
/*      */   {
/* 3237 */     this.rollbackOnPooledClose.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setRoundRobinLoadBalance(boolean flag)
/*      */   {
/* 3247 */     this.roundRobinLoadBalance.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setRunningCTS13(boolean flag)
/*      */   {
/* 3255 */     this.runningCTS13.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setSecondsBeforeRetryMaster(int property)
/*      */   {
/* 3264 */     this.secondsBeforeRetryMaster.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setServerTimezone(String property)
/*      */   {
/* 3274 */     this.serverTimezone.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setSessionVariables(String variables)
/*      */   {
/* 3282 */     this.sessionVariables.setValue(variables);
/*      */   }
/*      */ 
/*      */   public void setSlowQueryThresholdMillis(int millis)
/*      */   {
/* 3292 */     this.slowQueryThresholdMillis.setValue(millis);
/*      */   }
/*      */ 
/*      */   public void setSocketFactoryClassName(String property)
/*      */   {
/* 3301 */     this.socketFactoryClassName.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setSocketTimeout(int property)
/*      */   {
/* 3310 */     this.socketTimeout.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setStrictFloatingPoint(boolean property)
/*      */   {
/* 3319 */     this.strictFloatingPoint.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setStrictUpdates(boolean property)
/*      */   {
/* 3328 */     this.strictUpdates.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setTinyInt1isBit(boolean flag)
/*      */   {
/* 3336 */     this.tinyInt1isBit.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setTraceProtocol(boolean flag)
/*      */   {
/* 3346 */     this.traceProtocol.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setTransformedBitIsBoolean(boolean flag) {
/* 3350 */     this.transformedBitIsBoolean.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseCompression(boolean property)
/*      */   {
/* 3359 */     this.useCompression.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseFastIntParsing(boolean flag)
/*      */   {
/* 3367 */     this.useFastIntParsing.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseHostsInPrivileges(boolean property)
/*      */   {
/* 3376 */     this.useHostsInPrivileges.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseInformationSchema(boolean flag) {
/* 3380 */     this.useInformationSchema.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseLocalSessionState(boolean flag)
/*      */   {
/* 3388 */     this.useLocalSessionState.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseOldUTF8Behavior(boolean flag)
/*      */   {
/* 3396 */     this.useOldUTF8Behavior.setValue(flag);
/* 3397 */     this.useOldUTF8BehaviorAsBoolean = this.useOldUTF8Behavior.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseOnlyServerErrorMessages(boolean flag)
/*      */   {
/* 3406 */     this.useOnlyServerErrorMessages.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseReadAheadInput(boolean flag)
/*      */   {
/* 3414 */     this.useReadAheadInput.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseServerPreparedStmts(boolean flag)
/*      */   {
/* 3424 */     this.detectServerPreparedStmts.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseSqlStateCodes(boolean flag)
/*      */   {
/* 3434 */     this.useSqlStateCodes.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseSSL(boolean property)
/*      */   {
/* 3443 */     this.useSSL.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseStreamLengthsInPrepStmts(boolean property)
/*      */   {
/* 3452 */     this.useStreamLengthsInPrepStmts.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseTimezone(boolean property)
/*      */   {
/* 3461 */     this.useTimezone.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseUltraDevWorkAround(boolean property)
/*      */   {
/* 3470 */     this.useUltraDevWorkAround.setValue(property);
/*      */   }
/*      */ 
/*      */   public void setUseUnbufferedInput(boolean flag)
/*      */   {
/* 3480 */     this.useUnbufferedInput.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseUnicode(boolean flag)
/*      */   {
/* 3490 */     this.useUnicode.setValue(flag);
/* 3491 */     this.useUnicodeAsBoolean = this.useUnicode.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseUsageAdvisor(boolean useUsageAdvisorFlag)
/*      */   {
/* 3501 */     this.useUsageAdvisor.setValue(useUsageAdvisorFlag);
/* 3502 */     this.useUsageAdvisorAsBoolean = this.useUsageAdvisor.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setYearIsDateType(boolean flag)
/*      */   {
/* 3507 */     this.yearIsDateType.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setZeroDateTimeBehavior(String behavior)
/*      */   {
/* 3515 */     this.zeroDateTimeBehavior.setValue(behavior);
/*      */   }
/*      */ 
/*      */   protected void storeToRef(Reference ref) throws SQLException {
/* 3519 */     int numPropertiesToSet = PROPERTY_LIST.size();
/*      */ 
/* 3521 */     for (int i = 0; i < numPropertiesToSet; i++) {
/* 3522 */       Field propertyField = (Field)PROPERTY_LIST.get(i);
/*      */       try
/*      */       {
/* 3526 */         ConnectionProperties.ConnectionProperty propToStore = (ConnectionProperties.ConnectionProperty)propertyField.get(this);
/*      */ 
/* 3529 */         if (ref != null)
/* 3530 */           propToStore.storeTo(ref);
/*      */       }
/*      */       catch (IllegalAccessException iae) {
/* 3533 */         throw SQLError.createSQLException("Huh?");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean useUnbufferedInput()
/*      */   {
/* 3544 */     return this.useUnbufferedInput.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public boolean getUseCursorFetch() {
/* 3548 */     return this.useCursorFetch.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseCursorFetch(boolean flag) {
/* 3552 */     this.useCursorFetch.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getOverrideSupportsIntegrityEnhancementFacility() {
/* 3556 */     return this.overrideSupportsIntegrityEnhancementFacility.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setOverrideSupportsIntegrityEnhancementFacility(boolean flag) {
/* 3560 */     this.overrideSupportsIntegrityEnhancementFacility.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getNoTimezoneConversionForTimeType() {
/* 3564 */     return this.noTimezoneConversionForTimeType.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setNoTimezoneConversionForTimeType(boolean flag) {
/* 3568 */     this.noTimezoneConversionForTimeType.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getUseJDBCCompliantTimezoneShift() {
/* 3572 */     return this.useJDBCCompliantTimezoneShift.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseJDBCCompliantTimezoneShift(boolean flag) {
/* 3576 */     this.useJDBCCompliantTimezoneShift.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getAutoClosePStmtStreams() {
/* 3580 */     return this.autoClosePStmtStreams.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setAutoClosePStmtStreams(boolean flag) {
/* 3584 */     this.autoClosePStmtStreams.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getProcessEscapeCodesForPrepStmts() {
/* 3588 */     return this.processEscapeCodesForPrepStmts.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setProcessEscapeCodesForPrepStmts(boolean flag) {
/* 3592 */     this.processEscapeCodesForPrepStmts.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getUseGmtMillisForDatetimes() {
/* 3596 */     return this.useGmtMillisForDatetimes.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseGmtMillisForDatetimes(boolean flag) {
/* 3600 */     this.useGmtMillisForDatetimes.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getDumpMetadataOnColumnNotFound() {
/* 3604 */     return this.dumpMetadataOnColumnNotFound.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setDumpMetadataOnColumnNotFound(boolean flag) {
/* 3608 */     this.dumpMetadataOnColumnNotFound.setValue(flag);
/*      */   }
/*      */ 
/*      */   public String getResourceId() {
/* 3612 */     return this.resourceId.getValueAsString();
/*      */   }
/*      */ 
/*      */   public void setResourceId(String resourceId) {
/* 3616 */     this.resourceId.setValue(resourceId);
/*      */   }
/*      */ 
/*      */   public boolean getRewriteBatchedStatements() {
/* 3620 */     return this.rewriteBatchedStatements.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setRewriteBatchedStatements(boolean flag) {
/* 3624 */     this.rewriteBatchedStatements.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getJdbcCompliantTruncationForReads() {
/* 3628 */     return this.jdbcCompliantTruncationForReads;
/*      */   }
/*      */ 
/*      */   public void setJdbcCompliantTruncationForReads(boolean jdbcCompliantTruncationForReads)
/*      */   {
/* 3633 */     this.jdbcCompliantTruncationForReads = jdbcCompliantTruncationForReads;
/*      */   }
/*      */ 
/*      */   public boolean getUseJvmCharsetConverters() {
/* 3637 */     return this.useJvmCharsetConverters.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseJvmCharsetConverters(boolean flag) {
/* 3641 */     this.useJvmCharsetConverters.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getPinGlobalTxToPhysicalConnection() {
/* 3645 */     return this.pinGlobalTxToPhysicalConnection.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setPinGlobalTxToPhysicalConnection(boolean flag) {
/* 3649 */     this.pinGlobalTxToPhysicalConnection.setValue(flag);
/*      */   }
/*      */ 
/*      */   public void setUseServerPrepStmts(boolean flag)
/*      */   {
/* 3658 */     setUseServerPreparedStmts(flag);
/*      */   }
/*      */ 
/*      */   public boolean getUseServerPrepStmts() {
/* 3662 */     return getUseServerPreparedStmts();
/*      */   }
/*      */ 
/*      */   public void setCacheCallableStmts(boolean flag) {
/* 3666 */     setCacheCallableStatements(flag);
/*      */   }
/*      */ 
/*      */   public boolean getCacheCallableStmts() {
/* 3670 */     return getCacheCallableStatements();
/*      */   }
/*      */ 
/*      */   public void setCachePrepStmts(boolean flag) {
/* 3674 */     setCachePreparedStatements(flag);
/*      */   }
/*      */ 
/*      */   public boolean getCachePrepStmts() {
/* 3678 */     return getCachePreparedStatements();
/*      */   }
/*      */ 
/*      */   public void setCallableStmtCacheSize(int cacheSize) {
/* 3682 */     setCallableStatementCacheSize(cacheSize);
/*      */   }
/*      */ 
/*      */   public int getCallableStmtCacheSize() {
/* 3686 */     return getCallableStatementCacheSize();
/*      */   }
/*      */ 
/*      */   public void setPrepStmtCacheSize(int cacheSize) {
/* 3690 */     setPreparedStatementCacheSize(cacheSize);
/*      */   }
/*      */ 
/*      */   public int getPrepStmtCacheSize() {
/* 3694 */     return getPreparedStatementCacheSize();
/*      */   }
/*      */ 
/*      */   public void setPrepStmtCacheSqlLimit(int sqlLimit) {
/* 3698 */     setPreparedStatementCacheSqlLimit(sqlLimit);
/*      */   }
/*      */ 
/*      */   public int getPrepStmtCacheSqlLimit() {
/* 3702 */     return getPreparedStatementCacheSqlLimit();
/*      */   }
/*      */ 
/*      */   public boolean getNoAccessToProcedureBodies() {
/* 3706 */     return this.noAccessToProcedureBodies.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setNoAccessToProcedureBodies(boolean flag) {
/* 3710 */     this.noAccessToProcedureBodies.setValue(flag);
/*      */   }
/*      */ 
/*      */   public boolean getUseOldAliasMetadataBehavior() {
/* 3714 */     return this.useOldAliasMetadataBehavior.getValueAsBoolean();
/*      */   }
/*      */ 
/*      */   public void setUseOldAliasMetadataBehavior(boolean flag) {
/* 3718 */     this.useOldAliasMetadataBehavior.setValue(flag);
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*      */     try
/*      */     {
/*  577 */       Field[] declaredFields = ConnectionProperties.class.getDeclaredFields();
/*      */ 
/*  580 */       for (int i = 0; i < declaredFields.length; i++) {
/*  581 */         if (!ConnectionProperties.ConnectionProperty.class.isAssignableFrom(declaredFields[i].getType()))
/*      */           continue;
/*  583 */         PROPERTY_LIST.add(declaredFields[i]);
/*      */       }
/*      */     }
/*      */     catch (Exception ex) {
/*  587 */       throw new RuntimeException(ex.toString());
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties
 * JD-Core Version:    0.6.0
 */