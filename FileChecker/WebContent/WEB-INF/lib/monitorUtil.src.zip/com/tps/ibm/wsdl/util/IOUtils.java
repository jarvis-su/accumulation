package com.ibm.wsdl.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.StringWriter;

public class IOUtils
{
  static boolean debug = false;

  public static String getStringFromReader(Reader paramReader)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(paramReader);
    StringWriter localStringWriter = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter(localStringWriter);
    String str;
    while ((str = localBufferedReader.readLine()) != null)
      localPrintWriter.println(str);
    localPrintWriter.flush();
    return localStringWriter.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.IOUtils
 * JD-Core Version:    0.6.0
 */