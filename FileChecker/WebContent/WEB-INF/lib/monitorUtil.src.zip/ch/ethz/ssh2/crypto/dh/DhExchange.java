/*     */ package ch.ethz.ssh2.crypto.dh;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.digest.HashForSSH2Types;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import java.math.BigInteger;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class DhExchange
/*     */ {
/*  18 */   private static final Logger log = Logger.getLogger(DhExchange.class);
/*     */   static final BigInteger p1;
/*     */   static final BigInteger p14;
/*     */   static final BigInteger g;
/*     */   BigInteger p;
/*     */   BigInteger e;
/*     */   BigInteger x;
/*     */   BigInteger f;
/*     */   BigInteger k;
/*     */ 
/*     */   static
/*     */   {
/*  42 */     String p1_string = "179769313486231590770839156793787453197860296048756011706444423684197180216158519368947833795864925541502180565485980503646440548199239100050792877003355816639229553136239076508735759914822574862575007425302077447712589550957937778424442426617334727629299387668709205606050270810842907692932019128194467627007";
/*     */ 
/*  48 */     String p14_string = "FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF";
/*     */ 
/*  57 */     p1 = new BigInteger("179769313486231590770839156793787453197860296048756011706444423684197180216158519368947833795864925541502180565485980503646440548199239100050792877003355816639229553136239076508735759914822574862575007425302077447712589550957937778424442426617334727629299387668709205606050270810842907692932019128194467627007");
/*  58 */     p14 = new BigInteger("FFFFFFFFFFFFFFFFC90FDAA22168C234C4C6628B80DC1CD129024E088A67CC74020BBEA63B139B22514A08798E3404DDEF9519B3CD3A431B302B0A6DF25F14374FE1356D6D51C245E485B576625E7EC6F44C42E9A637ED6B0BFF5CB6F406B7EDEE386BFB5A899FA5AE9F24117C4B1FE649286651ECE45B3DC2007CB8A163BF0598DA48361C55D39A69163FA8FD24CF5F83655D23DCA3AD961C62F356208552BB9ED529077096966D670C354E4ABC9804F1746C08CA18217C32905E462E36CE3BE39E772C180E86039B2783A2EC07A28FB5C55DF06F4C52C9DE2BCBF6955817183995497CEA956AE515D2261898FA051015728E5A8AACAA68FFFFFFFFFFFFFFFF", 16);
/*  59 */     g = new BigInteger("2");
/*     */   }
/*     */ 
/*     */   public void init(int group, SecureRandom rnd)
/*     */   {
/*  68 */     this.k = null;
/*     */ 
/*  70 */     if (group == 1)
/*  71 */       this.p = p1;
/*  72 */     else if (group == 14)
/*  73 */       this.p = p14;
/*     */     else {
/*  75 */       throw new IllegalArgumentException("Unknown DH group " + group);
/*     */     }
/*  77 */     this.x = new BigInteger(this.p.bitLength() - 1, rnd);
/*     */ 
/*  79 */     this.e = g.modPow(this.x, this.p);
/*     */   }
/*     */ 
/*     */   public BigInteger getE()
/*     */   {
/*  88 */     if (this.e == null) {
/*  89 */       throw new IllegalStateException("DhDsaExchange not initialized!");
/*     */     }
/*  91 */     return this.e;
/*     */   }
/*     */ 
/*     */   public BigInteger getK()
/*     */   {
/* 100 */     if (this.k == null) {
/* 101 */       throw new IllegalStateException("Shared secret not yet known, need f first!");
/*     */     }
/* 103 */     return this.k;
/*     */   }
/*     */ 
/*     */   public void setF(BigInteger f)
/*     */   {
/* 111 */     if (this.e == null) {
/* 112 */       throw new IllegalStateException("DhDsaExchange not initialized!");
/*     */     }
/* 114 */     BigInteger zero = BigInteger.valueOf(0L);
/*     */ 
/* 116 */     if ((zero.compareTo(f) >= 0) || (this.p.compareTo(f) <= 0)) {
/* 117 */       throw new IllegalArgumentException("Invalid f specified!");
/*     */     }
/* 119 */     this.f = f;
/* 120 */     this.k = f.modPow(this.x, this.p);
/*     */   }
/*     */ 
/*     */   public byte[] calculateH(byte[] clientversion, byte[] serverversion, byte[] clientKexPayload, byte[] serverKexPayload, byte[] hostKey)
/*     */   {
/* 126 */     HashForSSH2Types hash = new HashForSSH2Types("SHA1");
/*     */ 
/* 128 */     if (log.isEnabled())
/*     */     {
/* 130 */       log.log(90, "Client: '" + new String(clientversion) + "'");
/* 131 */       log.log(90, "Server: '" + new String(serverversion) + "'");
/*     */     }
/*     */ 
/* 134 */     hash.updateByteString(clientversion);
/* 135 */     hash.updateByteString(serverversion);
/* 136 */     hash.updateByteString(clientKexPayload);
/* 137 */     hash.updateByteString(serverKexPayload);
/* 138 */     hash.updateByteString(hostKey);
/* 139 */     hash.updateBigInt(this.e);
/* 140 */     hash.updateBigInt(this.f);
/* 141 */     hash.updateBigInt(this.k);
/*     */ 
/* 143 */     return hash.getDigest();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.dh.DhExchange
 * JD-Core Version:    0.6.0
 */