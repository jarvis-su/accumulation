/*    */ package com.mysql.jdbc.util;
/*    */ 
/*    */ import com.mysql.jdbc.SQLError;
/*    */ 
/*    */ public class ErrorMappingsDocGenerator
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 41 */     SQLError.dumpSqlStatesMappingsAsXml();
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.util.ErrorMappingsDocGenerator
 * JD-Core Version:    0.6.0
 */