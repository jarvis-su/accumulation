/*     */ package ch.ethz.ssh2.transport;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ public class ClientServerHello
/*     */ {
/*     */   String server_line;
/*     */   String client_line;
/*     */   String server_versioncomment;
/*     */ 
/*     */   public static final int readLineRN(InputStream is, byte[] buffer)
/*     */     throws IOException
/*     */   {
/*  25 */     int pos = 0;
/*  26 */     boolean need10 = false;
/*  27 */     int len = 0;
/*     */     while (true)
/*     */     {
/*  30 */       int c = is.read();
/*  31 */       if (c == -1) {
/*  32 */         throw new IOException("Premature connection close");
/*     */       }
/*  34 */       buffer[(pos++)] = (byte)c;
/*     */ 
/*  36 */       if (c == 13)
/*     */       {
/*  38 */         need10 = true;
/*  39 */         continue;
/*     */       }
/*     */ 
/*  42 */       if (c == 10) {
/*     */         break;
/*     */       }
/*  45 */       if (need10) {
/*  46 */         throw new IOException("Malformed line sent by the server, the line does not end correctly.");
/*     */       }
/*  48 */       len++;
/*  49 */       if (pos >= buffer.length) {
/*  50 */         throw new IOException("The server sent a too long line.");
/*     */       }
/*     */     }
/*  53 */     return len;
/*     */   }
/*     */ 
/*     */   public ClientServerHello(InputStream bi, OutputStream bo) throws IOException
/*     */   {
/*  58 */     this.client_line = "SSH-2.0-Ganymed Build_210";
/*     */ 
/*  60 */     bo.write((this.client_line + "\r\n").getBytes());
/*  61 */     bo.flush();
/*     */ 
/*  63 */     byte[] serverVersion = new byte[512];
/*     */ 
/*  65 */     for (int i = 0; i < 50; i++)
/*     */     {
/*  67 */       int len = readLineRN(bi, serverVersion);
/*     */ 
/*  69 */       this.server_line = new String(serverVersion, 0, len);
/*     */ 
/*  71 */       if (this.server_line.startsWith("SSH-")) {
/*     */         break;
/*     */       }
/*     */     }
/*  75 */     if (!this.server_line.startsWith("SSH-")) {
/*  76 */       throw new IOException(
/*  77 */         "Malformed server identification string. There was no line starting with 'SSH-' amongst the first 50 lines.");
/*     */     }
/*  79 */     if (this.server_line.startsWith("SSH-1.99-"))
/*  80 */       this.server_versioncomment = this.server_line.substring(9);
/*  81 */     else if (this.server_line.startsWith("SSH-2.0-"))
/*  82 */       this.server_versioncomment = this.server_line.substring(8);
/*     */     else
/*  84 */       throw new IOException("Server uses incompatible protocol, it is not SSH-2 compatible.");
/*     */   }
/*     */ 
/*     */   public byte[] getClientString()
/*     */   {
/*  92 */     return this.client_line.getBytes();
/*     */   }
/*     */ 
/*     */   public byte[] getServerString()
/*     */   {
/* 100 */     return this.server_line.getBytes();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.ClientServerHello
 * JD-Core Version:    0.6.0
 */