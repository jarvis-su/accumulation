/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ class RowDataDynamic$OperationNotSupportedException extends SQLException
/*    */ {
/*    */   private final RowDataDynamic this$0;
/*    */ 
/*    */   RowDataDynamic$OperationNotSupportedException(RowDataDynamic this$0)
/*    */   {
/* 44 */     super(Messages.getString("RowDataDynamic.10"), "S1009");
/*    */ 
/* 43 */     this.this$0 = this$0;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.RowDataDynamic.OperationNotSupportedException
 * JD-Core Version:    0.6.0
 */