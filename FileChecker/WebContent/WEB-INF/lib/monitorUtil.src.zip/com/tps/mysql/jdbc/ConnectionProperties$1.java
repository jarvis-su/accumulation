package com.mysql.jdbc;

class ConnectionProperties$1 extends ConnectionProperties
{
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.1
 * JD-Core Version:    0.6.0
 */