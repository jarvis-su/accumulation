/*     */ package com.acs.fileChecker.fileserver;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.net.URL;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Properties;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class Validate
/*     */ {
/*     */   private String _error;
/*     */   private String _state;
/*     */   private RandomAccessFile raf;
/*     */   private File _curFile;
/*     */   private double _rejectThreshold;
/*     */   private double _recordThreshold;
/*     */   public static final int FTYPE_OTHER = 0;
/*     */   public static final int FTYPE_TXT = 1;
/*     */   public static final int FTYPE_DAT = 2;
/*     */   public static final int FTYPE_PDF = 4;
/*     */   public static final int FTYPE_LOG = 8;
/*     */   public static final int FTYPE_SUM = 16;
/*     */   public static final int FTYPE_CARDMAILER = 32;
/*     */   public static final int FTYPE_CARDMAILDATE = 48;
/*     */   public static final int FTYPE_ACHDEP = 64;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  20 */     File f = new File(args[0]);
/*  21 */     Validate v = new Validate(f);
/*  22 */     System.out.println(f.toString() + " " + v.validateFile());
/*     */   }
/*     */ 
/*     */   public Validate(String fileName)
/*     */   {
/*  27 */     this._rejectThreshold = 0.05D;
/*  28 */     this._recordThreshold = 0.05D;
/*  29 */     this._curFile = new File(fileName);
/*  30 */     this._error = null;
/*  31 */     this._state = "";
/*     */   }
/*     */ 
/*     */   public Validate(File f)
/*     */   {
/*  36 */     this._rejectThreshold = 0.05D;
/*  37 */     this._recordThreshold = 0.05D;
/*  38 */     this._curFile = f;
/*  39 */     this._error = null;
/*  40 */     this._state = "";
/*     */   }
/*     */ 
/*     */   public Validate()
/*     */   {
/*  45 */     this(null);
/*     */   }
/*     */ 
/*     */   public String validateTXT()
/*     */   {
/*  50 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateDAT()
/*     */   {
/*  55 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateLOG()
/*     */   {
/*  60 */     if ((!isTrailer("SQR: End of Run.")) && (!isTrailer("Jasper - End of Run.")))
/*  61 */       this._state = "has a bad trailer";
/*  62 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateSUM()
/*     */   {
/*  67 */     Matcher matcher = null;
/*  68 */     if (getFirstLineLike(".*General Database Failure.*") != null) {
/*  69 */       this._state = "General Database Failure";
/*     */     }
/*  71 */     else if ((matcher = getLastLineLike("^\\s*Total records rejected\\s*:\\s*([1-9][0-9]*)")) != null) {
/*  72 */       this._state = String.format("rejected %s records", new Object[] { 
/*  73 */         matcher.group(1) });
/*     */     }
/*  75 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateACH()
/*     */   {
/*  80 */     String processedC = "^\\s*Total Credits Processed\\s*:\\s*([0-9]*)";
/*  81 */     String rejectedC = "^\\s*Total Credits Rejected\\s*:\\s*([0-9]*)";
/*  82 */     String recordsPreprocessed = "^\\s*Total records (pre-processed|detail)\\s*:\\s*([0-9]*)";
/*  83 */     String recordsProcessed = "^\\s*Total records processed( \\(detail\\))?\\s*:\\s*([0-9]*)";
/*  84 */     String recordsRejected = "^\\s*Total records rejected\\s*:\\s*([0-9]*)";
/*  85 */     String processedD = "^\\s*Total Debits Processed\\s*:\\s*([0-9]*)";
/*  86 */     String rejectedD = "^\\s*Total Debits Rejected\\s*:\\s*([0-9]*)";
/*  87 */     String empty = "^\\s*NO FILE WAS PROCESSED.*";
/*     */     try
/*     */     {
/*  90 */       String s = getFirstLineLike(empty);
/*     */ 
/*  92 */       if (s != null)
/*  93 */         return "";
/*  94 */       Matcher matcher = getLastLineLike(recordsRejected);
/*  95 */       double rej = Double.parseDouble(matcher.group(1));
/*  96 */       matcher = getLastLineLike(recordsProcessed);
/*  97 */       double pro = Double.parseDouble(matcher.group(2));
/*  98 */       matcher = getLastLineLike(recordsPreprocessed);
/*  99 */       double prePro = Double.parseDouble(matcher.group(2));
/* 100 */       double pctR = rej / prePro;
/* 101 */       if (pro + rej != prePro) {
/* 102 */         this._state = "Invalid Summary; Processed + Rejected != PreProcessed";
/* 103 */         return this._state;
/*     */       }
/* 105 */       if (pctR >= this._recordThreshold) {
/* 106 */         this._state = String.format("rejected %2.2f%% of total records!", new Object[] { 
/* 107 */           Double.valueOf(pctR * 100.0D) });
/*     */ 
/* 109 */         return this._state;
/*     */       }
/*     */ 
/* 112 */       matcher = getLastLineLike(processedC);
/* 113 */       pro = Double.parseDouble(matcher.group(1));
/* 114 */       matcher = getLastLineLike(rejectedC);
/* 115 */       rej = Double.parseDouble(matcher.group(1));
/* 116 */       double pctC = rej / (pro + rej);
/* 117 */       if ((!Double.isNaN(pctC)) && (pctC > this._rejectThreshold)) {
/* 118 */         this._state = String.format("rejected %2.2f%% of total credits!", new Object[] { 
/* 119 */           Double.valueOf(pctC * 100.0D) });
/*     */ 
/* 121 */         return this._state;
/*     */       }
/* 123 */       matcher = getLastLineLike(processedD);
/* 124 */       pro = Double.parseDouble(matcher.group(1));
/* 125 */       matcher = getLastLineLike(rejectedD);
/* 126 */       rej = Double.parseDouble(matcher.group(1));
/* 127 */       double pctD = rej / (pro + rej);
/* 128 */       if ((!Double.isNaN(pctD)) && (pctD > pctC) && (pctD > this._rejectThreshold)) {
/* 129 */         this._state = String.format("rejected %2.2f%% of total debits!", new Object[] { 
/* 130 */           Double.valueOf(pctD * 100.0D) });
/*     */ 
/* 132 */         return this._state;
/*     */       }
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 137 */       this._state = "monitor could not determine number of rejects";
/*     */     }
/* 139 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateCustom(String customname)
/*     */   {
/* 150 */     Properties props = new Properties();
/* 151 */     URL url = ClassLoader.getSystemResource(customname + ".rules");
/*     */     try {
/* 153 */       props.load(new FileInputStream(new File(url.getFile()))); } catch (IOException localIOException) {
/*     */     }
/* 155 */     String tmp = props.getProperty("check.exists", "true");
/* 156 */     if (!this._curFile.exists()) {
/* 157 */       if (tmp.equals("true")) {
/* 158 */         return "does not exist";
/*     */       }
/* 160 */       return "";
/*     */     }
/*     */ 
/* 163 */     tmp = props.getProperty("check.sizeAtLeast");
/* 164 */     if ((tmp != null) && 
/* 165 */       (this._curFile.length() < Integer.parseInt(tmp))) {
/* 166 */       return "is smaller than expected";
/*     */     }
/* 168 */     tmp = props.getProperty("check.sizeAtMost");
/* 169 */     if ((tmp != null) && 
/* 170 */       (this._curFile.length() > Integer.parseInt(tmp))) {
/* 171 */       return "is larger than expected";
/*     */     }
/* 173 */     return "";
/*     */   }
/*     */ 
/*     */   public String validatePDF()
/*     */   {
/* 178 */     if (!isTrailer(".*%%EOF\\s*"))
/* 179 */       this._state = "has a bad trailer";
/* 180 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateCARDMAILER()
/*     */   {
/* 185 */     if (!isTrailer("T[0-9]*.*"))
/* 186 */       this._state = "has a bad trailer";
/* 187 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateCARDMAILDATE()
/*     */   {
/* 192 */     if (getFirstLineLike("Error") != null)
/* 193 */       this._state = "Please Contact OM";
/* 194 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateGeneral()
/*     */   {
/*     */     String retCode;
/*     */     String retCode;
/* 200 */     if (!this._curFile.exists()) {
/* 201 */       retCode = "doesn't exist";
/*     */     }
/*     */     else
/*     */     {
/*     */       String retCode;
/* 203 */       if (this._curFile.length() == 0L)
/* 204 */         retCode = "is zero length";
/*     */       else
/* 206 */         retCode = ""; 
/*     */     }
/* 207 */     return retCode;
/*     */   }
/*     */ 
/*     */   public int getFileType()
/*     */   {
/* 212 */     String name = this._curFile.toString();
/* 213 */     String type = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
/*     */     int t;
/*     */     int t;
/* 215 */     if (name.endsWith("CARDMAILER")) {
/* 216 */       t = 32;
/*     */     }
/*     */     else
/*     */     {
/*     */       int t;
/* 218 */       if (name.endsWith("CARDMAILDATE.summary")) {
/* 219 */         t = 48;
/*     */       }
/*     */       else
/*     */       {
/*     */         int t;
/* 221 */         if (name.endsWith("ACHDEP.summary")) {
/* 222 */           t = 64;
/*     */         }
/*     */         else
/*     */         {
/*     */           int t;
/* 224 */           if (type.equals("txt")) {
/* 225 */             t = 1;
/*     */           }
/*     */           else
/*     */           {
/*     */             int t;
/* 227 */             if (type.equals("dat")) {
/* 228 */               t = 2;
/*     */             }
/*     */             else
/*     */             {
/*     */               int t;
/* 230 */               if (type.equals("pdf")) {
/* 231 */                 t = 4;
/*     */               }
/*     */               else
/*     */               {
/*     */                 int t;
/* 233 */                 if (type.equals("log")) {
/* 234 */                   t = 8;
/*     */                 }
/*     */                 else
/*     */                 {
/*     */                   int t;
/* 236 */                   if (type.equals("summary"))
/* 237 */                     t = 16;
/*     */                   else
/* 239 */                     t = 0; 
/*     */                 }
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 240 */     return t;
/*     */   }
/*     */ 
/*     */   public String validateFile()
/*     */   {
/* 245 */     int type = getFileType();
/* 246 */     String ret = validateGeneral();
/* 247 */     if (!ret.equals(""))
/*     */     {
/* 249 */       if ((type == 64) && (!this._curFile.exists()))
/* 250 */         return "";
/* 251 */       return ret;
/*     */     }
/* 253 */     switch (type)
/*     */     {
/*     */     case 48:
/* 256 */       ret = validateCARDMAILDATE();
/* 257 */       break;
/*     */     case 32:
/* 259 */       ret = validateCARDMAILER();
/* 260 */       break;
/*     */     case 64:
/* 262 */       ret = validateACH();
/* 263 */       break;
/*     */     case 1:
/* 265 */       ret = validateTXT();
/* 266 */       break;
/*     */     case 2:
/* 268 */       ret = validateDAT();
/* 269 */       break;
/*     */     case 4:
/* 271 */       ret = validatePDF();
/* 272 */       break;
/*     */     case 16:
/* 274 */       ret = validateSUM();
/* 275 */       break;
/*     */     case 8:
/* 277 */       ret = validateLOG();
/*     */     }
/*     */ 
/* 280 */     return ret;
/*     */   }
/*     */ 
/*     */   public long getFileSize()
/*     */   {
/* 285 */     long tmp = this._curFile.length();
/* 286 */     return tmp;
/*     */   }
/*     */ 
/*     */   public String getFileMod()
/*     */   {
/* 291 */     SimpleDateFormat time = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
/* 292 */     Date d = new Date(this._curFile.lastModified());
/* 293 */     return time.format(d);
/*     */   }
/*     */ 
/*     */   private String getFirstLineLike(String str)
/*     */   {
/* 298 */     String ret = null;
/* 299 */     String line = null;
/*     */     try
/*     */     {
/* 302 */       this.raf = new RandomAccessFile(this._curFile, "r");
/* 303 */       for (line = this.raf.readLine(); line != null; line = this.raf.readLine())
/*     */       {
/* 305 */         if (!line.matches(str))
/*     */           continue;
/* 307 */         ret = line;
/* 308 */         break;
/*     */       }
/*     */ 
/* 311 */       this.raf.close();
/*     */     } catch (IOException localIOException) {
/*     */     }
/* 314 */     return ret;
/*     */   }
/*     */ 
/*     */   private Matcher getLastLineLike(String str)
/*     */   {
/* 319 */     String line = null;
/* 320 */     Pattern pattern = Pattern.compile(str);
/* 321 */     Matcher matcher = null;
/*     */     try
/*     */     {
/* 324 */       this.raf = new RandomAccessFile(this._curFile, "r");
/* 325 */       this.raf.seek(this._curFile.length() - 1L);
/* 326 */       for (line = readLineReverse(); line != null; )
/*     */       {
/* 328 */         matcher = pattern.matcher(line);
/* 329 */         if (matcher.matches())
/*     */           break;
/*     */         try
/*     */         {
/* 333 */           line = readLineReverse();
/*     */         }
/*     */         catch (Exception e)
/*     */         {
/* 337 */           e.printStackTrace();
/*     */         }
/* 339 */         matcher = null;
/*     */       }
/*     */ 
/* 342 */       this.raf.close();
/*     */     } catch (Exception localException1) {
/*     */     }
/* 345 */     return matcher;
/*     */   }
/*     */ 
/*     */   private boolean isTrailer(String str)
/*     */   {
/* 350 */     boolean match = false;
/*     */     try
/*     */     {
/* 353 */       this.raf = new RandomAccessFile(this._curFile, "r");
/* 354 */       this.raf.seek(this._curFile.length() - 1L);
/* 355 */       String line = readLineReverse();
/* 356 */       if (line.matches(str))
/* 357 */         match = true;
/* 358 */       this.raf.close();
/*     */     } catch (Exception localException) {
/*     */     }
/* 361 */     return match;
/*     */   }
/*     */ 
/*     */   public String getError()
/*     */   {
/* 366 */     return this._error;
/*     */   }
/*     */ 
/*     */   public String readLineReverse()
/*     */     throws Exception
/*     */   {
/* 372 */     long position = this.raf.getFilePointer();
/* 373 */     String finalLine = "";
/* 374 */     boolean justStarting = true;
/* 375 */     if (position == 0L)
/* 376 */       return null;
/*     */     while (true)
/*     */     {
/* 379 */       if (position < 0L)
/*     */       {
/* 381 */         this.raf.seek(0L);
/* 382 */         break;
/*     */       }
/* 384 */       this.raf.seek(position);
/* 385 */       int thisCode = this.raf.readByte();
/* 386 */       char thisChar = (char)thisCode;
/* 387 */       if ((thisCode == 13) || (thisCode == 10))
/*     */       {
/* 389 */         this.raf.seek(position - 1L);
/* 390 */         int nextCode = this.raf.readByte();
/* 391 */         if (((thisCode == 10) && (nextCode == 13)) || ((thisCode == 13) && (nextCode == 10))) {
/* 392 */           position -= 1L;
/*     */         }
/* 394 */         else if (justStarting)
/*     */         {
/* 396 */           position -= 1L;
/* 397 */           finalLine = (char)nextCode + finalLine;
/*     */         }
/* 399 */         if (!justStarting)
/*     */         {
/* 401 */           position -= 1L;
/* 402 */           break;
/*     */         }
/*     */       }
/*     */       else {
/* 406 */         finalLine = thisChar + finalLine;
/*     */       }
/* 408 */       position -= 1L;
/* 409 */       justStarting = false;
/*     */     }
/* 411 */     return finalLine;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.fileserver.Validate
 * JD-Core Version:    0.6.0
 */