/*     */ package ch.ethz.ssh2.crypto.dh;
/*     */ 
/*     */ import ch.ethz.ssh2.DHGexParameters;
/*     */ import ch.ethz.ssh2.crypto.digest.HashForSSH2Types;
/*     */ import java.math.BigInteger;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class DhGroupExchange
/*     */ {
/*     */   private BigInteger p;
/*     */   private BigInteger g;
/*     */   private BigInteger e;
/*     */   private BigInteger x;
/*     */   private BigInteger f;
/*     */   private BigInteger k;
/*     */ 
/*     */   public DhGroupExchange(BigInteger p, BigInteger g)
/*     */   {
/*  38 */     this.p = p;
/*  39 */     this.g = g;
/*     */   }
/*     */ 
/*     */   public void init(SecureRandom rnd)
/*     */   {
/*  44 */     this.k = null;
/*     */ 
/*  46 */     this.x = new BigInteger(this.p.bitLength() - 1, rnd);
/*  47 */     this.e = this.g.modPow(this.x, this.p);
/*     */   }
/*     */ 
/*     */   public BigInteger getE()
/*     */   {
/*  55 */     if (this.e == null) {
/*  56 */       throw new IllegalStateException("Not initialized!");
/*     */     }
/*  58 */     return this.e;
/*     */   }
/*     */ 
/*     */   public BigInteger getK()
/*     */   {
/*  66 */     if (this.k == null) {
/*  67 */       throw new IllegalStateException("Shared secret not yet known, need f first!");
/*     */     }
/*  69 */     return this.k;
/*     */   }
/*     */ 
/*     */   public void setF(BigInteger f)
/*     */   {
/*  77 */     if (this.e == null) {
/*  78 */       throw new IllegalStateException("Not initialized!");
/*     */     }
/*  80 */     BigInteger zero = BigInteger.valueOf(0L);
/*     */ 
/*  82 */     if ((zero.compareTo(f) >= 0) || (this.p.compareTo(f) <= 0)) {
/*  83 */       throw new IllegalArgumentException("Invalid f specified!");
/*     */     }
/*  85 */     this.f = f;
/*  86 */     this.k = f.modPow(this.x, this.p);
/*     */   }
/*     */ 
/*     */   public byte[] calculateH(byte[] clientversion, byte[] serverversion, byte[] clientKexPayload, byte[] serverKexPayload, byte[] hostKey, DHGexParameters para)
/*     */   {
/*  92 */     HashForSSH2Types hash = new HashForSSH2Types("SHA1");
/*     */ 
/*  94 */     hash.updateByteString(clientversion);
/*  95 */     hash.updateByteString(serverversion);
/*  96 */     hash.updateByteString(clientKexPayload);
/*  97 */     hash.updateByteString(serverKexPayload);
/*  98 */     hash.updateByteString(hostKey);
/*  99 */     if (para.getMin_group_len() > 0)
/* 100 */       hash.updateUINT32(para.getMin_group_len());
/* 101 */     hash.updateUINT32(para.getPref_group_len());
/* 102 */     if (para.getMax_group_len() > 0)
/* 103 */       hash.updateUINT32(para.getMax_group_len());
/* 104 */     hash.updateBigInt(this.p);
/* 105 */     hash.updateBigInt(this.g);
/* 106 */     hash.updateBigInt(this.e);
/* 107 */     hash.updateBigInt(this.f);
/* 108 */     hash.updateBigInt(this.k);
/*     */ 
/* 110 */     return hash.getDigest();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.dh.DhGroupExchange
 * JD-Core Version:    0.6.0
 */