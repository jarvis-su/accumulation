package com.ibm.wsdl.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

public class StringUtils
{
  public static final String lineSeparator = System.getProperty("line.separator", "\n");
  public static final String lineSeparatorStr = cleanString(lineSeparator);

  public static String cleanString(String paramString)
  {
    if (paramString == null)
      return null;
    char[] arrayOfChar = paramString.toCharArray();
    StringBuffer localStringBuffer = new StringBuffer();
    for (int i = 0; i < arrayOfChar.length; i++)
      switch (arrayOfChar[i])
      {
      case '"':
        localStringBuffer.append("\\\"");
        break;
      case '\\':
        localStringBuffer.append("\\\\");
        break;
      case '\n':
        localStringBuffer.append("\\n");
        break;
      case '\r':
        localStringBuffer.append("\\r");
        break;
      default:
        localStringBuffer.append(arrayOfChar[i]);
      }
    return localStringBuffer.toString();
  }

  public static String getClassName(Class paramClass)
  {
    String str = paramClass.getName();
    return paramClass.isArray() ? parseDescriptor(str) : str;
  }

  private static String parseDescriptor(String paramString)
  {
    char[] arrayOfChar = paramString.toCharArray();
    int i = 0;
    for (int j = 0; arrayOfChar[j] == '['; j++)
      i++;
    StringBuffer localStringBuffer = new StringBuffer();
    switch (arrayOfChar[(j++)])
    {
    case 'B':
      localStringBuffer.append("byte");
      break;
    case 'C':
      localStringBuffer.append("char");
      break;
    case 'D':
      localStringBuffer.append("double");
      break;
    case 'F':
      localStringBuffer.append("float");
      break;
    case 'I':
      localStringBuffer.append("int");
      break;
    case 'J':
      localStringBuffer.append("long");
      break;
    case 'S':
      localStringBuffer.append("short");
      break;
    case 'Z':
      localStringBuffer.append("boolean");
      break;
    case 'L':
      localStringBuffer.append(arrayOfChar, j, arrayOfChar.length - j - 1);
    case 'E':
    case 'G':
    case 'H':
    case 'K':
    case 'M':
    case 'N':
    case 'O':
    case 'P':
    case 'Q':
    case 'R':
    case 'T':
    case 'U':
    case 'V':
    case 'W':
    case 'X':
    case 'Y':
    }
    for (j = 0; j < i; j++)
      localStringBuffer.append("[]");
    return localStringBuffer.toString();
  }

  public static URL getURL(URL paramURL, String paramString)
    throws MalformedURLException
  {
    if (paramURL != null)
    {
      File localFile = new File(paramString);
      if (localFile.isAbsolute())
        return localFile.toURL();
    }
    try
    {
      return new URL(paramURL, paramString);
    }
    catch (MalformedURLException localMalformedURLException)
    {
      if (paramURL == null)
        return new File(paramString).toURL();
    }
    throw localMalformedURLException;
  }

  public static InputStream getContentAsInputStream(URL paramURL)
    throws SecurityException, IllegalArgumentException, IOException
  {
    if (paramURL == null)
      throw new IllegalArgumentException("URL cannot be null.");
    try
    {
      Object localObject = paramURL.getContent();
      if (localObject == null)
        throw new IllegalArgumentException("No content.");
      if ((localObject instanceof InputStream))
        return (InputStream)localObject;
      throw new IllegalArgumentException("This URL points to a: " + getClassName(localObject.getClass()));
    }
    catch (SecurityException localSecurityException)
    {
      throw new SecurityException("Your JVM's SecurityManager has disallowed this.");
    }
    catch (FileNotFoundException localFileNotFoundException)
    {
    }
    throw new FileNotFoundException("This file was not found: " + paramURL);
  }

  public static List parseNMTokens(String paramString)
  {
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " ");
    Vector localVector = new Vector();
    while (localStringTokenizer.hasMoreTokens())
      localVector.add(localStringTokenizer.nextToken());
    return localVector;
  }

  public static String getNMTokens(List paramList)
  {
    if (paramList != null)
    {
      StringBuffer localStringBuffer = new StringBuffer();
      int i = paramList.size();
      for (int j = 0; j < i; j++)
      {
        String str = (String)paramList.get(j);
        localStringBuffer.append((j > 0 ? " " : "") + str);
      }
      return localStringBuffer.toString();
    }
    return null;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.StringUtils
 * JD-Core Version:    0.6.0
 */