/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLDecoder;
/*     */ import java.sql.Driver;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ 
/*     */ public class NonRegisteringDriver
/*     */   implements Driver
/*     */ {
/*     */   public static final String DBNAME_PROPERTY_KEY = "DBNAME";
/*     */   public static final boolean DEBUG = false;
/*     */   public static final int HOST_NAME_INDEX = 0;
/*     */   public static final String HOST_PROPERTY_KEY = "HOST";
/*     */   public static final String PASSWORD_PROPERTY_KEY = "password";
/*     */   public static final int PORT_NUMBER_INDEX = 1;
/*     */   public static final String PORT_PROPERTY_KEY = "PORT";
/*     */   public static final String PROPERTIES_TRANSFORM_KEY = "propertiesTransform";
/*     */   public static final boolean TRACE = false;
/*     */   public static final String USE_CONFIG_PROPERTY_KEY = "useConfigs";
/*     */   public static final String USER_PROPERTY_KEY = "user";
/*     */ 
/*     */   static int getMajorVersionInternal()
/*     */   {
/* 121 */     return safeIntParse("5");
/*     */   }
/*     */ 
/*     */   static int getMinorVersionInternal()
/*     */   {
/* 130 */     return safeIntParse("0");
/*     */   }
/*     */ 
/*     */   protected static String[] parseHostPortPair(String hostPortPair)
/*     */     throws SQLException
/*     */   {
/* 149 */     int portIndex = hostPortPair.indexOf(":");
/*     */ 
/* 151 */     String[] splitValues = new String[2];
/*     */ 
/* 153 */     String hostname = null;
/*     */ 
/* 155 */     if (portIndex != -1) {
/* 156 */       if (portIndex + 1 < hostPortPair.length()) {
/* 157 */         String portAsString = hostPortPair.substring(portIndex + 1);
/* 158 */         hostname = hostPortPair.substring(0, portIndex);
/*     */ 
/* 160 */         splitValues[0] = hostname;
/*     */ 
/* 162 */         splitValues[1] = portAsString;
/*     */       } else {
/* 164 */         throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.37"), "01S00");
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 169 */       splitValues[0] = hostPortPair;
/* 170 */       splitValues[1] = null;
/*     */     }
/*     */ 
/* 173 */     return splitValues;
/*     */   }
/*     */ 
/*     */   private static int safeIntParse(String intAsString) {
/*     */     try {
/* 178 */       return Integer.parseInt(intAsString); } catch (NumberFormatException nfe) {
/*     */     }
/* 180 */     return 0;
/*     */   }
/*     */ 
/*     */   public NonRegisteringDriver()
/*     */     throws SQLException
/*     */   {
/*     */   }
/*     */ 
/*     */   public boolean acceptsURL(String url)
/*     */     throws SQLException
/*     */   {
/* 210 */     return parseURL(url, null) != null;
/*     */   }
/*     */ 
/*     */   public java.sql.Connection connect(String url, Properties info)
/*     */     throws SQLException
/*     */   {
/* 259 */     Properties props = null;
/*     */ 
/* 261 */     if ((props = parseURL(url, info)) == null) {
/* 262 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 266 */       Connection newConn = new Connection(host(props), port(props), props, database(props), url);
/*     */ 
/* 269 */       return newConn;
/*     */     }
/*     */     catch (SQLException sqlEx)
/*     */     {
/* 273 */       throw sqlEx; } catch (Exception ex) {
/*     */     }
/* 275 */     throw SQLError.createSQLException(Messages.getString("NonRegisteringDriver.17") + ex.toString() + Messages.getString("NonRegisteringDriver.18"), "08001");
/*     */   }
/*     */ 
/*     */   public String database(Properties props)
/*     */   {
/* 292 */     return props.getProperty("DBNAME");
/*     */   }
/*     */ 
/*     */   public int getMajorVersion()
/*     */   {
/* 301 */     return getMajorVersionInternal();
/*     */   }
/*     */ 
/*     */   public int getMinorVersion()
/*     */   {
/* 310 */     return getMinorVersionInternal();
/*     */   }
/*     */ 
/*     */   public DriverPropertyInfo[] getPropertyInfo(String url, Properties info)
/*     */     throws SQLException
/*     */   {
/* 341 */     if (info == null) {
/* 342 */       info = new Properties();
/*     */     }
/*     */ 
/* 345 */     if ((url != null) && (url.startsWith("jdbc:mysql://"))) {
/* 346 */       info = parseURL(url, info);
/*     */     }
/*     */ 
/* 349 */     DriverPropertyInfo hostProp = new DriverPropertyInfo("HOST", info.getProperty("HOST"));
/*     */ 
/* 351 */     hostProp.required = true;
/* 352 */     hostProp.description = Messages.getString("NonRegisteringDriver.3");
/*     */ 
/* 354 */     DriverPropertyInfo portProp = new DriverPropertyInfo("PORT", info.getProperty("PORT", "3306"));
/*     */ 
/* 356 */     portProp.required = false;
/* 357 */     portProp.description = Messages.getString("NonRegisteringDriver.7");
/*     */ 
/* 359 */     DriverPropertyInfo dbProp = new DriverPropertyInfo("DBNAME", info.getProperty("DBNAME"));
/*     */ 
/* 361 */     dbProp.required = false;
/* 362 */     dbProp.description = "Database name";
/*     */ 
/* 364 */     DriverPropertyInfo userProp = new DriverPropertyInfo("user", info.getProperty("user"));
/*     */ 
/* 366 */     userProp.required = true;
/* 367 */     userProp.description = Messages.getString("NonRegisteringDriver.13");
/*     */ 
/* 369 */     DriverPropertyInfo passwordProp = new DriverPropertyInfo("password", info.getProperty("password"));
/*     */ 
/* 372 */     passwordProp.required = true;
/* 373 */     passwordProp.description = Messages.getString("NonRegisteringDriver.16");
/*     */ 
/* 376 */     DriverPropertyInfo[] dpi = ConnectionProperties.exposeAsDriverPropertyInfo(info, 5);
/*     */ 
/* 379 */     dpi[0] = hostProp;
/* 380 */     dpi[1] = portProp;
/* 381 */     dpi[2] = dbProp;
/* 382 */     dpi[3] = userProp;
/* 383 */     dpi[4] = passwordProp;
/*     */ 
/* 385 */     return dpi;
/*     */   }
/*     */ 
/*     */   public String host(Properties props)
/*     */   {
/* 402 */     return props.getProperty("HOST", "localhost");
/*     */   }
/*     */ 
/*     */   public boolean jdbcCompliant()
/*     */   {
/* 418 */     return false;
/*     */   }
/*     */ 
/*     */   public Properties parseURL(String url, Properties defaults)
/*     */     throws SQLException
/*     */   {
/* 436 */     Properties urlProps = defaults != null ? new Properties(defaults) : new Properties();
/*     */ 
/* 439 */     if (url == null) {
/* 440 */       return null;
/*     */     }
/*     */ 
/* 443 */     if ((!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql://")) && (!StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://")))
/*     */     {
/* 446 */       return null;
/*     */     }
/*     */ 
/* 449 */     int beginningOfSlashes = 13;
/*     */ 
/* 451 */     if (StringUtils.startsWithIgnoreCase(url, "jdbc:mysql:mxj://")) {
/* 452 */       beginningOfSlashes = 17;
/*     */ 
/* 454 */       urlProps.setProperty("socketFactory", "com.mysql.management.driverlaunched.ServerLauncherSocketFactory");
/*     */     }
/*     */ 
/* 462 */     int index = url.indexOf("?");
/*     */ 
/* 464 */     if (index != -1) {
/* 465 */       String paramString = url.substring(index + 1, url.length());
/* 466 */       url = url.substring(0, index);
/*     */ 
/* 468 */       StringTokenizer queryParams = new StringTokenizer(paramString, "&");
/*     */ 
/* 470 */       while (queryParams.hasMoreTokens()) {
/* 471 */         String parameterValuePair = queryParams.nextToken();
/*     */ 
/* 473 */         int indexOfEquals = StringUtils.indexOfIgnoreCase(0, parameterValuePair, "=");
/*     */ 
/* 476 */         String parameter = null;
/* 477 */         String value = null;
/*     */ 
/* 479 */         if (indexOfEquals != -1) {
/* 480 */           parameter = parameterValuePair.substring(0, indexOfEquals);
/*     */ 
/* 482 */           if (indexOfEquals + 1 < parameterValuePair.length()) {
/* 483 */             value = parameterValuePair.substring(indexOfEquals + 1);
/*     */           }
/*     */         }
/*     */ 
/* 487 */         if ((value != null) && (value.length() > 0) && (parameter != null) && (parameter.length() > 0)) {
/*     */           try
/*     */           {
/* 490 */             urlProps.put(parameter, URLDecoder.decode(value, "UTF-8"));
/*     */           }
/*     */           catch (UnsupportedEncodingException badEncoding)
/*     */           {
/* 494 */             urlProps.put(parameter, URLDecoder.decode(value));
/*     */           }
/*     */           catch (NoSuchMethodError nsme) {
/* 497 */             urlProps.put(parameter, URLDecoder.decode(value));
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 503 */     url = url.substring(beginningOfSlashes);
/*     */ 
/* 505 */     String hostStuff = null;
/*     */ 
/* 507 */     int slashIndex = url.indexOf("/");
/*     */ 
/* 509 */     if (slashIndex != -1) {
/* 510 */       hostStuff = url.substring(0, slashIndex);
/*     */ 
/* 512 */       if (slashIndex + 1 < url.length())
/* 513 */         urlProps.put("DBNAME", url.substring(slashIndex + 1, url.length()));
/*     */     }
/*     */     else
/*     */     {
/* 517 */       return null;
/*     */     }
/*     */ 
/* 520 */     if ((hostStuff != null) && (hostStuff.length() > 0)) {
/* 521 */       urlProps.put("HOST", hostStuff);
/*     */     }
/*     */ 
/* 524 */     String propertiesTransformClassName = urlProps.getProperty("propertiesTransform");
/*     */ 
/* 527 */     if (propertiesTransformClassName != null) {
/*     */       try {
/* 529 */         ConnectionPropertiesTransform propTransformer = (ConnectionPropertiesTransform)Class.forName(propertiesTransformClassName).newInstance();
/*     */ 
/* 532 */         urlProps = propTransformer.transformProperties(urlProps);
/*     */       } catch (InstantiationException e) {
/* 534 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00");
/*     */       }
/*     */       catch (IllegalAccessException e)
/*     */       {
/* 541 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00");
/*     */       }
/*     */       catch (ClassNotFoundException e)
/*     */       {
/* 548 */         throw SQLError.createSQLException("Unable to create properties transform instance '" + propertiesTransformClassName + "' due to underlying exception: " + e.toString(), "01S00");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 560 */     String configNames = null;
/*     */ 
/* 562 */     if (defaults != null) {
/* 563 */       configNames = defaults.getProperty("useConfigs");
/*     */     }
/*     */ 
/* 566 */     if (configNames == null) {
/* 567 */       configNames = urlProps.getProperty("useConfigs");
/*     */     }
/*     */ 
/* 570 */     if (configNames != null) {
/* 571 */       List splitNames = StringUtils.split(configNames, ",", true);
/*     */ 
/* 573 */       Properties configProps = new Properties();
/*     */ 
/* 575 */       Iterator namesIter = splitNames.iterator();
/*     */ 
/* 577 */       while (namesIter.hasNext()) {
/* 578 */         String configName = (String)namesIter.next();
/*     */         try
/*     */         {
/* 581 */           InputStream configAsStream = getClass().getResourceAsStream("configs/" + configName + ".properties");
/*     */ 
/* 585 */           if (configAsStream == null) {
/* 586 */             throw SQLError.createSQLException("Can't find configuration template named '" + configName + "'", "01S00");
/*     */           }
/*     */ 
/* 591 */           configProps.load(configAsStream);
/*     */         } catch (IOException ioEx) {
/* 593 */           throw SQLError.createSQLException("Unable to load configuration template '" + configName + "' due to underlying IOException: " + ioEx, "01S00");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 602 */       Iterator propsIter = urlProps.keySet().iterator();
/*     */ 
/* 604 */       while (propsIter.hasNext()) {
/* 605 */         String key = propsIter.next().toString();
/* 606 */         String property = urlProps.getProperty(key);
/* 607 */         configProps.setProperty(key, property);
/*     */       }
/*     */ 
/* 610 */       urlProps = configProps;
/*     */     }
/*     */ 
/* 615 */     if (defaults != null) {
/* 616 */       Iterator propsIter = defaults.keySet().iterator();
/*     */ 
/* 618 */       while (propsIter.hasNext()) {
/* 619 */         String key = propsIter.next().toString();
/* 620 */         String property = defaults.getProperty(key);
/* 621 */         urlProps.setProperty(key, property);
/*     */       }
/*     */     }
/*     */ 
/* 625 */     return urlProps;
/*     */   }
/*     */ 
/*     */   public int port(Properties props)
/*     */   {
/* 637 */     return Integer.parseInt(props.getProperty("PORT", "3306"));
/*     */   }
/*     */ 
/*     */   public String property(String name, Properties props)
/*     */   {
/* 651 */     return props.getProperty(name);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.NonRegisteringDriver
 * JD-Core Version:    0.6.0
 */