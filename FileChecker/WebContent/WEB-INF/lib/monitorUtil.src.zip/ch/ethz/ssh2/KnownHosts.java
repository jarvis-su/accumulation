/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.Base64;
/*     */ import ch.ethz.ssh2.crypto.digest.Digest;
/*     */ import ch.ethz.ssh2.crypto.digest.HMAC;
/*     */ import ch.ethz.ssh2.crypto.digest.MD5;
/*     */ import ch.ethz.ssh2.crypto.digest.SHA1;
/*     */ import ch.ethz.ssh2.signature.DSAPublicKey;
/*     */ import ch.ethz.ssh2.signature.DSASHA1Verify;
/*     */ import ch.ethz.ssh2.signature.RSAPublicKey;
/*     */ import ch.ethz.ssh2.signature.RSASHA1Verify;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.CharArrayReader;
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.math.BigInteger;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedList;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class KnownHosts
/*     */ {
/*     */   public static final int HOSTKEY_IS_OK = 0;
/*     */   public static final int HOSTKEY_IS_NEW = 1;
/*     */   public static final int HOSTKEY_HAS_CHANGED = 2;
/*  62 */   private LinkedList publicKeys = new LinkedList();
/*     */ 
/*     */   public KnownHosts()
/*     */   {
/*     */   }
/*     */ 
/*     */   public KnownHosts(char[] knownHostsData) throws IOException
/*     */   {
/*  70 */     initialize(knownHostsData);
/*     */   }
/*     */ 
/*     */   public KnownHosts(File knownHosts) throws IOException
/*     */   {
/*  75 */     initialize(knownHosts);
/*     */   }
/*     */ 
/*     */   public void addHostkey(String[] hostnames, String serverHostKeyAlgorithm, byte[] serverHostKey)
/*     */     throws IOException
/*     */   {
/*  91 */     if (hostnames == null) {
/*  92 */       throw new IllegalArgumentException("hostnames may not be null");
/*     */     }
/*  94 */     if ("ssh-rsa".equals(serverHostKeyAlgorithm))
/*     */     {
/*  96 */       RSAPublicKey rpk = RSASHA1Verify.decodeSSHRSAPublicKey(serverHostKey);
/*     */ 
/*  98 */       synchronized (this.publicKeys)
/*     */       {
/* 100 */         this.publicKeys.add(new KnownHostsEntry(hostnames, rpk));
/*     */       }
/*     */     }
/* 103 */     else if ("ssh-dss".equals(serverHostKeyAlgorithm))
/*     */     {
/* 105 */       DSAPublicKey dpk = DSASHA1Verify.decodeSSHDSAPublicKey(serverHostKey);
/*     */ 
/* 107 */       synchronized (this.publicKeys)
/*     */       {
/* 109 */         this.publicKeys.add(new KnownHostsEntry(hostnames, dpk));
/*     */       }
/*     */     }
/*     */     else {
/* 113 */       throw new IOException("Unknwon host key type (" + serverHostKeyAlgorithm + ")");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addHostkeys(char[] knownHostsData)
/*     */     throws IOException
/*     */   {
/* 124 */     initialize(knownHostsData);
/*     */   }
/*     */ 
/*     */   public void addHostkeys(File knownHosts)
/*     */     throws IOException
/*     */   {
/* 135 */     initialize(knownHosts);
/*     */   }
/*     */ 
/*     */   public static final String createHashedHostname(String hostname)
/*     */   {
/* 147 */     SHA1 sha1 = new SHA1();
/*     */ 
/* 149 */     byte[] salt = new byte[sha1.getDigestLength()];
/*     */ 
/* 151 */     new SecureRandom().nextBytes(salt);
/*     */ 
/* 153 */     byte[] hash = hmacSha1Hash(salt, hostname);
/*     */ 
/* 155 */     String base64_salt = new String(Base64.encode(salt));
/* 156 */     String base64_hash = new String(Base64.encode(hash));
/*     */ 
/* 158 */     return new String("|1|" + base64_salt + "|" + base64_hash);
/*     */   }
/*     */ 
/*     */   private static final byte[] hmacSha1Hash(byte[] salt, String hostname)
/*     */   {
/* 163 */     SHA1 sha1 = new SHA1();
/*     */ 
/* 165 */     if (salt.length != sha1.getDigestLength()) {
/* 166 */       throw new IllegalArgumentException("Salt has wrong length (" + salt.length + ")");
/*     */     }
/* 168 */     HMAC hmac = new HMAC(sha1, salt, salt.length);
/*     */ 
/* 170 */     hmac.update(hostname.getBytes());
/*     */ 
/* 172 */     byte[] dig = new byte[hmac.getDigestLength()];
/*     */ 
/* 174 */     hmac.digest(dig);
/*     */ 
/* 176 */     return dig;
/*     */   }
/*     */ 
/*     */   private final boolean checkHashed(String entry, String hostname)
/*     */   {
/* 181 */     if (!entry.startsWith("|1|")) {
/* 182 */       return false;
/*     */     }
/* 184 */     int delim_idx = entry.indexOf('|', 3);
/*     */ 
/* 186 */     if (delim_idx == -1) {
/* 187 */       return false;
/*     */     }
/* 189 */     String salt_base64 = entry.substring(3, delim_idx);
/* 190 */     String hash_base64 = entry.substring(delim_idx + 1);
/*     */ 
/* 192 */     byte[] salt = (byte[])null;
/* 193 */     byte[] hash = (byte[])null;
/*     */     try
/*     */     {
/* 197 */       salt = Base64.decode(salt_base64.toCharArray());
/* 198 */       hash = Base64.decode(hash_base64.toCharArray());
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 202 */       return false;
/*     */     }
/*     */ 
/* 205 */     SHA1 sha1 = new SHA1();
/*     */ 
/* 207 */     if (salt.length != sha1.getDigestLength()) {
/* 208 */       return false;
/*     */     }
/* 210 */     byte[] dig = hmacSha1Hash(salt, hostname);
/*     */ 
/* 212 */     for (int i = 0; i < dig.length; i++) {
/* 213 */       if (dig[i] != hash[i])
/* 214 */         return false;
/*     */     }
/* 216 */     return true;
/*     */   }
/*     */ 
/*     */   private int checkKey(String remoteHostname, Object remoteKey)
/*     */   {
/* 221 */     int result = 1;
/*     */ 
/* 223 */     synchronized (this.publicKeys)
/*     */     {
/* 225 */       Iterator i = this.publicKeys.iterator();
/*     */ 
/* 227 */       while (i.hasNext())
/*     */       {
/* 229 */         KnownHostsEntry ke = (KnownHostsEntry)i.next();
/*     */ 
/* 231 */         if (!hostnameMatches(ke.patterns, remoteHostname)) {
/*     */           continue;
/*     */         }
/* 234 */         boolean res = matchKeys(ke.key, remoteKey);
/*     */ 
/* 236 */         if (res) {
/* 237 */           return 0;
/*     */         }
/* 239 */         result = 2;
/*     */       }
/*     */     }
/* 242 */     return result;
/*     */   }
/*     */ 
/*     */   private Vector getAllKeys(String hostname)
/*     */   {
/* 247 */     Vector keys = new Vector();
/*     */ 
/* 249 */     synchronized (this.publicKeys)
/*     */     {
/* 251 */       Iterator i = this.publicKeys.iterator();
/*     */ 
/* 253 */       while (i.hasNext())
/*     */       {
/* 255 */         KnownHostsEntry ke = (KnownHostsEntry)i.next();
/*     */ 
/* 257 */         if (!hostnameMatches(ke.patterns, hostname)) {
/*     */           continue;
/*     */         }
/* 260 */         keys.addElement(ke.key);
/*     */       }
/*     */     }
/*     */ 
/* 264 */     return keys;
/*     */   }
/*     */ 
/*     */   public String[] getPreferredServerHostkeyAlgorithmOrder(String hostname)
/*     */   {
/* 281 */     String[] algos = recommendHostkeyAlgorithms(hostname);
/*     */ 
/* 283 */     if (algos != null) {
/* 284 */       return algos;
/*     */     }
/* 286 */     InetAddress[] ipAdresses = (InetAddress[])null;
/*     */     try
/*     */     {
/* 290 */       ipAdresses = InetAddress.getAllByName(hostname);
/*     */     }
/*     */     catch (UnknownHostException e)
/*     */     {
/* 294 */       return null;
/*     */     }
/*     */ 
/* 297 */     for (int i = 0; i < ipAdresses.length; i++)
/*     */     {
/* 299 */       algos = recommendHostkeyAlgorithms(ipAdresses[i].getHostAddress());
/*     */ 
/* 301 */       if (algos != null) {
/* 302 */         return algos;
/*     */       }
/*     */     }
/* 305 */     return null;
/*     */   }
/*     */ 
/*     */   private final boolean hostnameMatches(String[] hostpatterns, String hostname)
/*     */   {
/* 310 */     boolean isMatch = false;
/* 311 */     boolean negate = false;
/*     */ 
/* 313 */     hostname = hostname.toLowerCase();
/*     */ 
/* 315 */     for (int k = 0; k < hostpatterns.length; k++)
/*     */     {
/* 317 */       if (hostpatterns[k] == null) {
/*     */         continue;
/*     */       }
/* 320 */       String pattern = null;
/*     */ 
/* 326 */       if ((hostpatterns[k].length() > 0) && (hostpatterns[k].charAt(0) == '!'))
/*     */       {
/* 328 */         pattern = hostpatterns[k].substring(1);
/* 329 */         negate = true;
/*     */       }
/*     */       else
/*     */       {
/* 333 */         pattern = hostpatterns[k];
/* 334 */         negate = false;
/*     */       }
/*     */ 
/* 339 */       if ((isMatch) && (!negate))
/*     */       {
/*     */         continue;
/*     */       }
/*     */ 
/* 344 */       if (pattern.charAt(0) == '|')
/*     */       {
/* 346 */         if (!checkHashed(pattern, hostname))
/*     */           continue;
/* 348 */         if (negate)
/* 349 */           return false;
/* 350 */         isMatch = true;
/*     */       }
/*     */       else
/*     */       {
/* 355 */         pattern = pattern.toLowerCase();
/*     */ 
/* 357 */         if ((pattern.indexOf('?') != -1) || (pattern.indexOf('*') != -1))
/*     */         {
/* 359 */           if (!pseudoRegex(pattern.toCharArray(), 0, hostname.toCharArray(), 0))
/*     */             continue;
/* 361 */           if (negate)
/* 362 */             return false;
/* 363 */           isMatch = true;
/*     */         }
/*     */         else {
/* 366 */           if (pattern.compareTo(hostname) != 0)
/*     */             continue;
/* 368 */           if (negate)
/* 369 */             return false;
/* 370 */           isMatch = true;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 375 */     return isMatch;
/*     */   }
/*     */ 
/*     */   private void initialize(char[] knownHostsData) throws IOException
/*     */   {
/* 380 */     BufferedReader br = new BufferedReader(new CharArrayReader(knownHostsData));
/*     */     while (true)
/*     */     {
/* 384 */       String line = br.readLine();
/*     */ 
/* 386 */       if (line == null) {
/*     */         break;
/*     */       }
/* 389 */       line = line.trim();
/*     */ 
/* 391 */       if (line.startsWith("#")) {
/*     */         continue;
/*     */       }
/* 394 */       String[] arr = line.split(" ");
/*     */ 
/* 396 */       if ((arr.length < 3) || (
/* 398 */         (arr[1].compareTo("ssh-rsa") != 0) && (arr[1].compareTo("ssh-dss") != 0)))
/*     */         continue;
/* 400 */       String[] hostnames = arr[0].split(",");
/*     */ 
/* 402 */       byte[] msg = Base64.decode(arr[2].toCharArray());
/*     */ 
/* 404 */       addHostkey(hostnames, arr[1], msg);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void initialize(File knownHosts)
/*     */     throws IOException
/*     */   {
/* 412 */     char[] buff = new char[512];
/*     */ 
/* 414 */     CharArrayWriter cw = new CharArrayWriter();
/*     */ 
/* 416 */     knownHosts.createNewFile();
/*     */ 
/* 418 */     FileReader fr = new FileReader(knownHosts);
/*     */     while (true)
/*     */     {
/* 422 */       int len = fr.read(buff);
/* 423 */       if (len < 0)
/*     */         break;
/* 425 */       cw.write(buff, 0, len);
/*     */     }
/*     */ 
/* 428 */     fr.close();
/*     */ 
/* 430 */     initialize(cw.toCharArray());
/*     */   }
/*     */ 
/*     */   private final boolean matchKeys(Object key1, Object key2)
/*     */   {
/* 435 */     if (((key1 instanceof RSAPublicKey)) && ((key2 instanceof RSAPublicKey)))
/*     */     {
/* 437 */       RSAPublicKey savedRSAKey = (RSAPublicKey)key1;
/* 438 */       RSAPublicKey remoteRSAKey = (RSAPublicKey)key2;
/*     */ 
/* 440 */       if (!savedRSAKey.getE().equals(remoteRSAKey.getE())) {
/* 441 */         return false;
/*     */       }
/*     */ 
/* 444 */       return savedRSAKey.getN().equals(remoteRSAKey.getN());
/*     */     }
/*     */ 
/* 449 */     if (((key1 instanceof DSAPublicKey)) && ((key2 instanceof DSAPublicKey)))
/*     */     {
/* 451 */       DSAPublicKey savedDSAKey = (DSAPublicKey)key1;
/* 452 */       DSAPublicKey remoteDSAKey = (DSAPublicKey)key2;
/*     */ 
/* 454 */       if (!savedDSAKey.getG().equals(remoteDSAKey.getG())) {
/* 455 */         return false;
/*     */       }
/* 457 */       if (!savedDSAKey.getP().equals(remoteDSAKey.getP())) {
/* 458 */         return false;
/*     */       }
/* 460 */       if (!savedDSAKey.getQ().equals(remoteDSAKey.getQ())) {
/* 461 */         return false;
/*     */       }
/*     */ 
/* 464 */       return savedDSAKey.getY().equals(remoteDSAKey.getY());
/*     */     }
/*     */ 
/* 469 */     return false;
/*     */   }
/*     */ 
/*     */   private final boolean pseudoRegex(char[] pattern, int i, char[] match, int j)
/*     */   {
/*     */     while (true)
/*     */     {
/* 480 */       if (pattern.length == i) {
/* 481 */         return match.length == j;
/*     */       }
/* 483 */       if (pattern[i] == '*')
/*     */       {
/* 485 */         i++;
/*     */ 
/* 487 */         if (pattern.length == i) {
/* 488 */           return true;
/*     */         }
/* 490 */         if ((pattern[i] != '*') && (pattern[i] != '?'))
/*     */         {
/*     */           while (true)
/*     */           {
/* 494 */             if ((pattern[i] == match[j]) && (pseudoRegex(pattern, i + 1, match, j + 1)))
/* 495 */               return true;
/* 496 */             j++;
/* 497 */             if (match.length == j) {
/* 498 */               return false;
/*     */             }
/*     */           }
/*     */         }
/*     */         while (true)
/*     */         {
/* 504 */           if (pseudoRegex(pattern, i, match, j))
/* 505 */             return true;
/* 506 */           j++;
/* 507 */           if (match.length == j) {
/* 508 */             return false;
/*     */           }
/*     */         }
/*     */       }
/* 512 */       if (match.length == j) {
/* 513 */         return false;
/*     */       }
/* 515 */       if ((pattern[i] != '?') && (pattern[i] != match[j])) {
/* 516 */         return false;
/*     */       }
/* 518 */       i++;
/* 519 */       j++;
/*     */     }
/*     */   }
/*     */ 
/*     */   private String[] recommendHostkeyAlgorithms(String hostname)
/*     */   {
/* 525 */     String preferredAlgo = null;
/*     */ 
/* 527 */     Vector keys = getAllKeys(hostname);
/*     */ 
/* 529 */     for (int i = 0; i < keys.size(); i++)
/*     */     {
/* 531 */       String thisAlgo = null;
/*     */ 
/* 533 */       if ((keys.elementAt(i) instanceof RSAPublicKey)) {
/* 534 */         thisAlgo = "ssh-rsa"; } else {
/* 535 */         if (!(keys.elementAt(i) instanceof DSAPublicKey)) continue;
/* 536 */         thisAlgo = "ssh-dss"; break label58;
/*     */ 
/* 538 */         continue;
/*     */       }
/* 540 */       label58: if (preferredAlgo == null)
/*     */       {
/*     */         continue;
/*     */       }
/* 544 */       if (preferredAlgo.compareTo(thisAlgo) != 0) {
/* 545 */         return null;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 555 */     if (preferredAlgo == null) {
/* 556 */       return null;
/*     */     }
/*     */ 
/* 570 */     if (preferredAlgo.equals("ssh-rsa")) {
/* 571 */       return new String[] { "ssh-rsa", "ssh-dss" };
/*     */     }
/* 573 */     return new String[] { "ssh-dss", "ssh-rsa" };
/*     */   }
/*     */ 
/*     */   public int verifyHostkey(String hostname, String serverHostKeyAlgorithm, byte[] serverHostKey)
/*     */     throws IOException
/*     */   {
/* 594 */     Object remoteKey = null;
/*     */ 
/* 596 */     if ("ssh-rsa".equals(serverHostKeyAlgorithm))
/*     */     {
/* 598 */       remoteKey = RSASHA1Verify.decodeSSHRSAPublicKey(serverHostKey);
/*     */     }
/* 600 */     else if ("ssh-dss".equals(serverHostKeyAlgorithm))
/*     */     {
/* 602 */       remoteKey = DSASHA1Verify.decodeSSHDSAPublicKey(serverHostKey);
/*     */     }
/*     */     else {
/* 605 */       throw new IllegalArgumentException("Unknown hostkey type " + serverHostKeyAlgorithm);
/*     */     }
/* 607 */     int result = checkKey(hostname, remoteKey);
/*     */ 
/* 609 */     if (result == 0) {
/* 610 */       return result;
/*     */     }
/* 612 */     InetAddress[] ipAdresses = (InetAddress[])null;
/*     */     try
/*     */     {
/* 616 */       ipAdresses = InetAddress.getAllByName(hostname);
/*     */     }
/*     */     catch (UnknownHostException e)
/*     */     {
/* 620 */       return result;
/*     */     }
/*     */ 
/* 623 */     for (int i = 0; i < ipAdresses.length; i++)
/*     */     {
/* 625 */       int newresult = checkKey(ipAdresses[i].getHostAddress(), remoteKey);
/*     */ 
/* 627 */       if (newresult == 0) {
/* 628 */         return newresult;
/*     */       }
/* 630 */       if (newresult == 2) {
/* 631 */         result = 2;
/*     */       }
/*     */     }
/* 634 */     return result;
/*     */   }
/*     */ 
/*     */   public static final void addHostkeyToFile(File knownHosts, String[] hostnames, String serverHostKeyAlgorithm, byte[] serverHostKey)
/*     */     throws IOException
/*     */   {
/* 651 */     if ((hostnames == null) || (hostnames.length == 0)) {
/* 652 */       throw new IllegalArgumentException("Need at least one hostname specification");
/*     */     }
/* 654 */     if ((serverHostKeyAlgorithm == null) || (serverHostKey == null)) {
/* 655 */       throw new IllegalArgumentException();
/*     */     }
/* 657 */     CharArrayWriter writer = new CharArrayWriter();
/*     */ 
/* 659 */     for (int i = 0; i < hostnames.length; i++)
/*     */     {
/* 661 */       if (i != 0)
/* 662 */         writer.write(44);
/* 663 */       writer.write(hostnames[i]);
/*     */     }
/*     */ 
/* 666 */     writer.write(32);
/* 667 */     writer.write(serverHostKeyAlgorithm);
/* 668 */     writer.write(32);
/* 669 */     writer.write(Base64.encode(serverHostKey));
/* 670 */     writer.write("\n");
/*     */ 
/* 672 */     char[] entry = writer.toCharArray();
/*     */ 
/* 674 */     RandomAccessFile raf = new RandomAccessFile(knownHosts, "rw");
/*     */ 
/* 676 */     long len = raf.length();
/*     */ 
/* 678 */     if (len > 0L)
/*     */     {
/* 680 */       raf.seek(len - 1L);
/* 681 */       int last = raf.read();
/* 682 */       if (last != 10) {
/* 683 */         raf.write(10);
/*     */       }
/*     */     }
/* 686 */     raf.write(new String(entry).getBytes());
/* 687 */     raf.close();
/*     */   }
/*     */ 
/*     */   private static final byte[] rawFingerPrint(String type, String keyType, byte[] hostkey)
/*     */   {
/* 700 */     Digest dig = null;
/*     */ 
/* 702 */     if ("md5".equals(type))
/*     */     {
/* 704 */       dig = new MD5();
/*     */     }
/* 706 */     else if ("sha1".equals(type))
/*     */     {
/* 708 */       dig = new SHA1();
/*     */     }
/*     */     else {
/* 711 */       throw new IllegalArgumentException("Unknown hash type " + type);
/*     */     }
/* 713 */     if (!"ssh-rsa".equals(keyType))
/*     */     {
/* 716 */       if (!"ssh-dss".equals(keyType))
/*     */       {
/* 720 */         throw new IllegalArgumentException("Unknown key type " + keyType);
/*     */       }
/*     */     }
/* 722 */     if (hostkey == null) {
/* 723 */       throw new IllegalArgumentException("hostkey is null");
/*     */     }
/* 725 */     dig.update(hostkey);
/* 726 */     byte[] res = new byte[dig.getDigestLength()];
/* 727 */     dig.digest(res);
/* 728 */     return res;
/*     */   }
/*     */ 
/*     */   private static final String rawToHexFingerprint(byte[] fingerprint)
/*     */   {
/* 738 */     char[] alpha = "0123456789abcdef".toCharArray();
/*     */ 
/* 740 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 742 */     for (int i = 0; i < fingerprint.length; i++)
/*     */     {
/* 744 */       if (i != 0)
/* 745 */         sb.append(':');
/* 746 */       int b = fingerprint[i] & 0xFF;
/* 747 */       sb.append(alpha[(b >> 4)]);
/* 748 */       sb.append(alpha[(b & 0xF)]);
/*     */     }
/*     */ 
/* 751 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private static final String rawToBubblebabbleFingerprint(byte[] raw)
/*     */   {
/* 761 */     char[] v = "aeiouy".toCharArray();
/* 762 */     char[] c = "bcdfghklmnprstvzx".toCharArray();
/*     */ 
/* 764 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 766 */     int seed = 1;
/*     */ 
/* 768 */     int rounds = raw.length / 2 + 1;
/*     */ 
/* 770 */     sb.append('x');
/*     */ 
/* 772 */     for (int i = 0; i < rounds; i++)
/*     */     {
/* 774 */       if ((i + 1 < rounds) || (raw.length % 2 != 0))
/*     */       {
/* 776 */         sb.append(v[(((raw[(2 * i)] >> 6 & 0x3) + seed) % 6)]);
/* 777 */         sb.append(c[(raw[(2 * i)] >> 2 & 0xF)]);
/* 778 */         sb.append(v[(((raw[(2 * i)] & 0x3) + seed / 6) % 6)]);
/*     */ 
/* 780 */         if (i + 1 >= rounds)
/*     */           continue;
/* 782 */         sb.append(c[(raw[(2 * i + 1)] >> 4 & 0xF)]);
/* 783 */         sb.append('-');
/* 784 */         sb.append(c[(raw[(2 * i + 1)] & 0xF)]);
/*     */ 
/* 786 */         seed = (seed * 5 + ((raw[(2 * i)] & 0xFF) * 7 + (raw[(2 * i + 1)] & 0xFF))) % 36;
/*     */       }
/*     */       else
/*     */       {
/* 791 */         sb.append(v[(seed % 6)]);
/* 792 */         sb.append('x');
/* 793 */         sb.append(v[(seed / 6)]);
/*     */       }
/*     */     }
/*     */ 
/* 797 */     sb.append('x');
/*     */ 
/* 799 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static final String createHexFingerprint(String keytype, byte[] publickey)
/*     */   {
/* 814 */     byte[] raw = rawFingerPrint("md5", keytype, publickey);
/* 815 */     return rawToHexFingerprint(raw);
/*     */   }
/*     */ 
/*     */   public static final String createBubblebabbleFingerprint(String keytype, byte[] publickey)
/*     */   {
/* 831 */     byte[] raw = rawFingerPrint("sha1", keytype, publickey);
/* 832 */     return rawToBubblebabbleFingerprint(raw);
/*     */   }
/*     */ 
/*     */   private class KnownHostsEntry
/*     */   {
/*     */     String[] patterns;
/*     */     Object key;
/*     */ 
/*     */     KnownHostsEntry(String[] patterns, Object key)
/*     */     {
/*  57 */       this.patterns = patterns;
/*  58 */       this.key = key;
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.KnownHosts
 * JD-Core Version:    0.6.0
 */