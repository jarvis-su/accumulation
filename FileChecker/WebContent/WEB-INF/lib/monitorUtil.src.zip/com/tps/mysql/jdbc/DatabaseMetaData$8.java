/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ 
/*      */ class DatabaseMetaData$8 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$procNamePattern;
/*      */   private final boolean val$returnProcedures;
/*      */   private final Map val$procedureRowsOrderedByName;
/*      */   private final boolean val$returnFunctions;
/*      */   private final ArrayList val$procedureRows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 3760 */     String db = catalogStr.toString();
/*      */ 
/* 3762 */     boolean fromSelect = false;
/* 3763 */     ResultSet proceduresRs = null;
/* 3764 */     boolean needsClientFiltering = true;
/* 3765 */     PreparedStatement proceduresStmt = this.this$0.conn.clientPrepareStatement("SELECT name, type FROM mysql.proc WHERE name like ? and db <=> ? ORDER BY name");
/*      */     try
/*      */     {
/* 3774 */       boolean hasTypeColumn = false;
/*      */ 
/* 3776 */       if (db != null)
/* 3777 */         proceduresStmt.setString(2, db);
/*      */       else {
/* 3779 */         proceduresStmt.setNull(2, 12);
/*      */       }
/*      */ 
/* 3782 */       int nameIndex = 1;
/*      */ 
/* 3784 */       if (proceduresStmt.getMaxRows() != 0) {
/* 3785 */         proceduresStmt.setMaxRows(0);
/*      */       }
/*      */ 
/* 3788 */       proceduresStmt.setString(1, this.val$procNamePattern);
/*      */       try
/*      */       {
/* 3791 */         proceduresRs = proceduresStmt.executeQuery();
/* 3792 */         fromSelect = true;
/* 3793 */         needsClientFiltering = false;
/* 3794 */         hasTypeColumn = true;
/*      */       }
/*      */       catch (SQLException sqlEx)
/*      */       {
/* 3802 */         proceduresStmt.close();
/*      */ 
/* 3804 */         fromSelect = false;
/*      */ 
/* 3806 */         if (this.this$0.conn.versionMeetsMinimum(5, 0, 1))
/* 3807 */           nameIndex = 2;
/*      */         else {
/* 3809 */           nameIndex = 1;
/*      */         }
/*      */ 
/* 3812 */         proceduresStmt = this.this$0.conn.clientPrepareStatement("SHOW PROCEDURE STATUS LIKE ?");
/*      */ 
/* 3815 */         if (proceduresStmt.getMaxRows() != 0) {
/* 3816 */           proceduresStmt.setMaxRows(0);
/*      */         }
/*      */ 
/* 3819 */         proceduresStmt.setString(1, this.val$procNamePattern);
/*      */ 
/* 3821 */         proceduresRs = proceduresStmt.executeQuery();
/*      */       }
/*      */ 
/* 3824 */       if (this.val$returnProcedures) {
/* 3825 */         DatabaseMetaData.access$700(this.this$0, fromSelect, db, proceduresRs, needsClientFiltering, db, this.val$procedureRowsOrderedByName, nameIndex);
/*      */       }
/*      */ 
/* 3830 */       if (!hasTypeColumn)
/*      */       {
/* 3832 */         if (proceduresStmt != null) {
/* 3833 */           proceduresStmt.close();
/*      */         }
/*      */ 
/* 3836 */         proceduresStmt = this.this$0.conn.clientPrepareStatement("SHOW FUNCTION STATUS LIKE ?");
/*      */ 
/* 3839 */         if (proceduresStmt.getMaxRows() != 0) {
/* 3840 */           proceduresStmt.setMaxRows(0);
/*      */         }
/*      */ 
/* 3843 */         proceduresStmt.setString(1, this.val$procNamePattern);
/*      */ 
/* 3845 */         proceduresRs = proceduresStmt.executeQuery();
/*      */ 
/* 3847 */         if (this.val$returnFunctions) {
/* 3848 */           DatabaseMetaData.access$800(this.this$0, db, proceduresRs, needsClientFiltering, db, this.val$procedureRowsOrderedByName, nameIndex);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3856 */       Iterator proceduresIter = this.val$procedureRowsOrderedByName.values().iterator();
/*      */ 
/* 3859 */       while (proceduresIter.hasNext())
/* 3860 */         this.val$procedureRows.add(proceduresIter.next());
/*      */     }
/*      */     finally {
/* 3863 */       SQLException rethrowSqlEx = null;
/*      */ 
/* 3865 */       if (proceduresRs != null) {
/*      */         try {
/* 3867 */           proceduresRs.close();
/*      */         } catch (SQLException sqlEx) {
/* 3869 */           rethrowSqlEx = sqlEx;
/*      */         }
/*      */       }
/*      */ 
/* 3873 */       if (proceduresStmt != null) {
/*      */         try {
/* 3875 */           proceduresStmt.close();
/*      */         } catch (SQLException sqlEx) {
/* 3877 */           rethrowSqlEx = sqlEx;
/*      */         }
/*      */       }
/*      */ 
/* 3881 */       if (rethrowSqlEx != null)
/* 3882 */         throw rethrowSqlEx;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.8
 * JD-Core Version:    0.6.0
 */