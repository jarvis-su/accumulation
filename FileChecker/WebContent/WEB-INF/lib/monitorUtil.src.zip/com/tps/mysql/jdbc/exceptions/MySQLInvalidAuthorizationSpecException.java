/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ public class MySQLInvalidAuthorizationSpecException extends MySQLNonTransientException
/*    */ {
/*    */   public MySQLInvalidAuthorizationSpecException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MySQLInvalidAuthorizationSpecException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 34 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLInvalidAuthorizationSpecException(String reason, String SQLState) {
/* 38 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLInvalidAuthorizationSpecException(String reason) {
/* 42 */     super(reason);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLInvalidAuthorizationSpecException
 * JD-Core Version:    0.6.0
 */