/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.CallableStatement;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.SQLWarning;
/*     */ import java.sql.Savepoint;
/*     */ import java.sql.Statement;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ 
/*     */ public class ReplicationConnection
/*     */   implements java.sql.Connection
/*     */ {
/*     */   private Connection currentConnection;
/*     */   private Connection masterConnection;
/*     */   private Connection slavesConnection;
/*     */ 
/*     */   public ReplicationConnection(Properties masterProperties, Properties slaveProperties)
/*     */     throws SQLException
/*     */   {
/*  51 */     Driver driver = new Driver();
/*     */ 
/*  53 */     StringBuffer masterUrl = new StringBuffer("jdbc:mysql://");
/*  54 */     StringBuffer slaveUrl = new StringBuffer("jdbc:mysql://");
/*     */ 
/*  56 */     String masterHost = masterProperties.getProperty("HOST");
/*     */ 
/*  59 */     if (masterHost != null) {
/*  60 */       masterUrl.append(masterHost);
/*     */     }
/*     */ 
/*  63 */     String slaveHost = slaveProperties.getProperty("HOST");
/*     */ 
/*  66 */     if (slaveHost != null) {
/*  67 */       slaveUrl.append(slaveHost);
/*     */     }
/*     */ 
/*  70 */     String masterDb = masterProperties.getProperty("DBNAME");
/*     */ 
/*  73 */     masterUrl.append("/");
/*     */ 
/*  75 */     if (masterDb != null) {
/*  76 */       masterUrl.append(masterDb);
/*     */     }
/*     */ 
/*  79 */     String slaveDb = slaveProperties.getProperty("DBNAME");
/*     */ 
/*  82 */     slaveUrl.append("/");
/*     */ 
/*  84 */     if (slaveDb != null) {
/*  85 */       slaveUrl.append(slaveDb);
/*     */     }
/*     */ 
/*  88 */     this.masterConnection = ((Connection)driver.connect(masterUrl.toString(), masterProperties));
/*     */ 
/*  90 */     this.slavesConnection = ((Connection)driver.connect(slaveUrl.toString(), slaveProperties));
/*     */ 
/*  93 */     this.currentConnection = this.masterConnection;
/*     */   }
/*     */ 
/*     */   public synchronized void clearWarnings()
/*     */     throws SQLException
/*     */   {
/* 102 */     this.currentConnection.clearWarnings();
/*     */   }
/*     */ 
/*     */   public synchronized void close()
/*     */     throws SQLException
/*     */   {
/* 111 */     this.masterConnection.close();
/* 112 */     this.slavesConnection.close();
/*     */   }
/*     */ 
/*     */   public synchronized void commit()
/*     */     throws SQLException
/*     */   {
/* 121 */     this.currentConnection.commit();
/*     */   }
/*     */ 
/*     */   public Statement createStatement()
/*     */     throws SQLException
/*     */   {
/* 130 */     return this.currentConnection.createStatement();
/*     */   }
/*     */ 
/*     */   public synchronized Statement createStatement(int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 140 */     return this.currentConnection.createStatement(resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public synchronized Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 152 */     return this.currentConnection.createStatement(resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public synchronized boolean getAutoCommit()
/*     */     throws SQLException
/*     */   {
/* 162 */     return this.currentConnection.getAutoCommit();
/*     */   }
/*     */ 
/*     */   public synchronized String getCatalog()
/*     */     throws SQLException
/*     */   {
/* 171 */     return this.currentConnection.getCatalog();
/*     */   }
/*     */ 
/*     */   public synchronized Connection getCurrentConnection() {
/* 175 */     return this.currentConnection;
/*     */   }
/*     */ 
/*     */   public synchronized int getHoldability()
/*     */     throws SQLException
/*     */   {
/* 184 */     return this.currentConnection.getHoldability();
/*     */   }
/*     */ 
/*     */   public synchronized Connection getMasterConnection() {
/* 188 */     return this.masterConnection;
/*     */   }
/*     */ 
/*     */   public synchronized DatabaseMetaData getMetaData()
/*     */     throws SQLException
/*     */   {
/* 197 */     return this.currentConnection.getMetaData();
/*     */   }
/*     */ 
/*     */   public synchronized Connection getSlavesConnection() {
/* 201 */     return this.slavesConnection;
/*     */   }
/*     */ 
/*     */   public synchronized int getTransactionIsolation()
/*     */     throws SQLException
/*     */   {
/* 210 */     return this.currentConnection.getTransactionIsolation();
/*     */   }
/*     */ 
/*     */   public synchronized Map getTypeMap()
/*     */     throws SQLException
/*     */   {
/* 219 */     return this.currentConnection.getTypeMap();
/*     */   }
/*     */ 
/*     */   public synchronized SQLWarning getWarnings()
/*     */     throws SQLException
/*     */   {
/* 228 */     return this.currentConnection.getWarnings();
/*     */   }
/*     */ 
/*     */   public synchronized boolean isClosed()
/*     */     throws SQLException
/*     */   {
/* 237 */     return this.currentConnection.isClosed();
/*     */   }
/*     */ 
/*     */   public synchronized boolean isReadOnly()
/*     */     throws SQLException
/*     */   {
/* 246 */     return this.currentConnection == this.slavesConnection;
/*     */   }
/*     */ 
/*     */   public synchronized String nativeSQL(String sql)
/*     */     throws SQLException
/*     */   {
/* 255 */     return this.currentConnection.nativeSQL(sql);
/*     */   }
/*     */ 
/*     */   public CallableStatement prepareCall(String sql)
/*     */     throws SQLException
/*     */   {
/* 264 */     return this.currentConnection.prepareCall(sql);
/*     */   }
/*     */ 
/*     */   public synchronized CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 274 */     return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public synchronized CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 286 */     return this.currentConnection.prepareCall(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public PreparedStatement prepareStatement(String sql)
/*     */     throws SQLException
/*     */   {
/* 296 */     return this.currentConnection.prepareStatement(sql);
/*     */   }
/*     */ 
/*     */   public synchronized PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
/*     */     throws SQLException
/*     */   {
/* 306 */     return this.currentConnection.prepareStatement(sql, autoGeneratedKeys);
/*     */   }
/*     */ 
/*     */   public synchronized PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
/*     */     throws SQLException
/*     */   {
/* 316 */     return this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency);
/*     */   }
/*     */ 
/*     */   public synchronized PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
/*     */     throws SQLException
/*     */   {
/* 329 */     return this.currentConnection.prepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability);
/*     */   }
/*     */ 
/*     */   public synchronized PreparedStatement prepareStatement(String sql, int[] columnIndexes)
/*     */     throws SQLException
/*     */   {
/* 340 */     return this.currentConnection.prepareStatement(sql, columnIndexes);
/*     */   }
/*     */ 
/*     */   public synchronized PreparedStatement prepareStatement(String sql, String[] columnNames)
/*     */     throws SQLException
/*     */   {
/* 351 */     return this.currentConnection.prepareStatement(sql, columnNames);
/*     */   }
/*     */ 
/*     */   public synchronized void releaseSavepoint(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 361 */     this.currentConnection.releaseSavepoint(savepoint);
/*     */   }
/*     */ 
/*     */   public synchronized void rollback()
/*     */     throws SQLException
/*     */   {
/* 370 */     this.currentConnection.rollback();
/*     */   }
/*     */ 
/*     */   public synchronized void rollback(Savepoint savepoint)
/*     */     throws SQLException
/*     */   {
/* 379 */     this.currentConnection.rollback(savepoint);
/*     */   }
/*     */ 
/*     */   public synchronized void setAutoCommit(boolean autoCommit)
/*     */     throws SQLException
/*     */   {
/* 389 */     this.currentConnection.setAutoCommit(autoCommit);
/*     */   }
/*     */ 
/*     */   public synchronized void setCatalog(String catalog)
/*     */     throws SQLException
/*     */   {
/* 398 */     this.currentConnection.setCatalog(catalog);
/*     */   }
/*     */ 
/*     */   public synchronized void setHoldability(int holdability)
/*     */     throws SQLException
/*     */   {
/* 408 */     this.currentConnection.setHoldability(holdability);
/*     */   }
/*     */ 
/*     */   public synchronized void setReadOnly(boolean readOnly)
/*     */     throws SQLException
/*     */   {
/* 417 */     if (readOnly) {
/* 418 */       if (this.currentConnection != this.slavesConnection) {
/* 419 */         switchToSlavesConnection();
/*     */       }
/*     */     }
/* 422 */     else if (this.currentConnection != this.masterConnection)
/* 423 */       switchToMasterConnection();
/*     */   }
/*     */ 
/*     */   public synchronized Savepoint setSavepoint()
/*     */     throws SQLException
/*     */   {
/* 434 */     return this.currentConnection.setSavepoint();
/*     */   }
/*     */ 
/*     */   public synchronized Savepoint setSavepoint(String name)
/*     */     throws SQLException
/*     */   {
/* 443 */     return this.currentConnection.setSavepoint(name);
/*     */   }
/*     */ 
/*     */   public synchronized void setTransactionIsolation(int level)
/*     */     throws SQLException
/*     */   {
/* 453 */     this.currentConnection.setTransactionIsolation(level);
/*     */   }
/*     */ 
/*     */   public synchronized void setTypeMap(Map arg0)
/*     */     throws SQLException
/*     */   {
/* 464 */     this.currentConnection.setTypeMap(arg0);
/*     */   }
/*     */ 
/*     */   private synchronized void switchToMasterConnection() throws SQLException {
/* 468 */     swapConnections(this.masterConnection, this.slavesConnection);
/*     */   }
/*     */ 
/*     */   private synchronized void switchToSlavesConnection() throws SQLException {
/* 472 */     swapConnections(this.slavesConnection, this.masterConnection);
/*     */   }
/*     */ 
/*     */   private synchronized void swapConnections(Connection switchToConnection, Connection switchFromConnection)
/*     */     throws SQLException
/*     */   {
/* 487 */     String switchFromCatalog = switchFromConnection.getCatalog();
/* 488 */     String switchToCatalog = switchToConnection.getCatalog();
/*     */ 
/* 490 */     if ((switchToCatalog != null) && (!switchToCatalog.equals(switchFromCatalog)))
/* 491 */       switchToConnection.setCatalog(switchFromCatalog);
/* 492 */     else if (switchFromCatalog != null) {
/* 493 */       switchToConnection.setCatalog(switchFromCatalog);
/*     */     }
/*     */ 
/* 496 */     boolean switchToAutoCommit = switchToConnection.getAutoCommit();
/* 497 */     boolean switchFromConnectionAutoCommit = switchFromConnection.getAutoCommit();
/*     */ 
/* 499 */     if (switchFromConnectionAutoCommit != switchToAutoCommit) {
/* 500 */       switchToConnection.setAutoCommit(switchFromConnectionAutoCommit);
/*     */     }
/*     */ 
/* 503 */     int switchToIsolation = switchToConnection.getTransactionIsolation();
/*     */ 
/* 506 */     int switchFromIsolation = switchFromConnection.getTransactionIsolation();
/*     */ 
/* 508 */     if (switchFromIsolation != switchToIsolation) {
/* 509 */       switchToConnection.setTransactionIsolation(switchFromIsolation);
/*     */     }
/*     */ 
/* 513 */     this.currentConnection = switchToConnection;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ReplicationConnection
 * JD-Core Version:    0.6.0
 */