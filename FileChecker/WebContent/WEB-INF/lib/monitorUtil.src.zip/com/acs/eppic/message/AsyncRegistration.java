/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class AsyncRegistration extends RegistrationData
/*    */ {
/*    */   private static final long serialVersionUID = 7577915541524726710L;
/*    */   private static final String DEST_DB = "DEST_DB";
/*    */   private static final String SRC_DB = "SRC_DB";
/*    */ 
/*    */   public AsyncRegistration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AsyncRegistration(HashMap map)
/*    */   {
/* 20 */     setData(map);
/*    */   }
/*    */ 
/*    */   public AsyncRegistration(String src_db, String dest_db) {
/* 24 */     setData("SRC_DB", src_db);
/* 25 */     setData("DEST_DB", dest_db);
/*    */   }
/*    */ 
/*    */   public String getDestDB() {
/* 29 */     String destDB = "";
/* 30 */     if (getData("DEST_DB") != null) {
/* 31 */       destDB = (String)getData("DEST_DB");
/*    */     }
/* 33 */     return destDB;
/*    */   }
/*    */ 
/*    */   public String getSourceDB() {
/* 37 */     String srcDB = "";
/* 38 */     if (getData("SRC_DB") != null) {
/* 39 */       srcDB = (String)getData("SRC_DB");
/*    */     }
/* 41 */     return srcDB;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return super.toString() + 
/* 46 */       "  SRC: + " + getSourceDB() + "\n" + 
/* 47 */       "  DEST: " + getDestDB() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.AsyncRegistration
 * JD-Core Version:    0.6.0
 */