/*    */ package com.acs.eppic.messageservice.web;
/*    */ 
/*    */ import com.acs.eppic.message.AlertData;
/*    */ import com.acs.eppic.message.AsyncAlert;
/*    */ import com.acs.eppic.message.AsyncRegistration;
/*    */ import com.acs.eppic.message.CorbaProxyAlert;
/*    */ import com.acs.eppic.message.ExtFileAlert;
/*    */ import com.acs.eppic.message.ExtFileInfo;
/*    */ import com.acs.eppic.message.FesRegistration;
/*    */ import com.acs.eppic.message.HeartbeatData;
/*    */ import com.acs.eppic.message.InfoData;
/*    */ import com.acs.eppic.message.Message;
/*    */ import com.acs.eppic.message.MessageData;
/*    */ import com.acs.eppic.message.MessageType;
/*    */ import com.acs.eppic.message.PersistenceAlert;
/*    */ import com.acs.eppic.message.PersistenceRegistration;
/*    */ import com.acs.eppic.message.RegistrationData;
/*    */ import com.acs.eppic.message.ReportAlert;
/*    */ import com.acs.eppic.message.ReportInfo;
/*    */ import com.acs.eppic.message.SysMgrAlert;
/*    */ import com.acs.eppic.message.SysProcAlert;
/*    */ import com.acs.eppic.message.SysProcInfo;
/*    */ import com.acs.eppic.messageservice.MessageService;
/*    */ import java.rmi.RemoteException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class MessageWebServiceSoapBindingImpl
/*    */   implements MessageWebService
/*    */ {
/* 18 */   protected static final Logger logger = Logger.getLogger("MessageReceive");
/*    */ 
/*    */   public void sendMessage(Message in0)
/*    */     throws RemoteException
/*    */   {
/* 24 */     if (in0.getM_MessageData() != null) {
/* 25 */       switch (in0.getType().getTypeId()) {
/*    */       case 1:
/* 27 */         if (in0.getServiceId().equals("EXTFILE"))
/* 28 */           in0.setM_MessageData(new ExtFileAlert(in0.getM_MessageData().getData()));
/* 29 */         else if (in0.getServiceId().equals("ASYNC"))
/* 30 */           in0.setM_MessageData(new AsyncAlert(in0.getM_MessageData().getData()));
/* 31 */         else if (in0.getServiceId().equals("VRU"))
/* 32 */           in0.setM_MessageData(new CorbaProxyAlert(in0.getM_MessageData().getData()));
/* 33 */         else if (in0.getServiceId().equals("PERSISTANCE"))
/* 34 */           in0.setM_MessageData(new PersistenceAlert(in0.getM_MessageData().getData()));
/* 35 */         else if (in0.getServiceId().equals("PROCESS"))
/* 36 */           in0.setM_MessageData(new SysProcAlert(in0.getM_MessageData().getData()));
/* 37 */         else if (in0.getServiceId().equals("SYSMGR"))
/* 38 */           in0.setM_MessageData(new SysMgrAlert(in0.getM_MessageData().getData()));
/* 39 */         else if (in0.getServiceId().equals("REPORTS"))
/* 40 */           in0.setM_MessageData(new ReportAlert(in0.getM_MessageData().getData()));
/*    */         else {
/* 42 */           in0.setM_MessageData(new AlertData(in0.getM_MessageData().getData()));
/*    */         }
/* 44 */         break;
/*    */       case 3:
/* 46 */         in0.setM_MessageData(new HeartbeatData(in0.getM_MessageData().getData()));
/* 47 */         break;
/*    */       case 4:
/* 49 */         if (in0.getServiceId().equals("EXTFILE"))
/* 50 */           in0.setM_MessageData(new ExtFileInfo(in0.getM_MessageData().getData()));
/* 51 */         else if (in0.getServiceId().equals("REPORTS"))
/* 52 */           in0.setM_MessageData(new ReportInfo(in0.getM_MessageData().getData()));
/* 53 */         else if (in0.getServiceId().equals("PROCESS"))
/* 54 */           in0.setM_MessageData(new SysProcInfo(in0.getM_MessageData().getData()));
/*    */         else {
/* 56 */           in0.setM_MessageData(new InfoData(in0.getM_MessageData().getData()));
/*    */         }
/* 58 */         break;
/*    */       case 5:
/* 60 */         if (in0.getServiceId().equals("PERSISTANCE"))
/* 61 */           in0.setM_MessageData(new PersistenceRegistration(in0.getM_MessageData().getData()));
/* 62 */         else if (in0.getServiceId().equals("ASYNC"))
/* 63 */           in0.setM_MessageData(new AsyncRegistration(in0.getM_MessageData().getData()));
/* 64 */         else if (in0.getServiceId().equals("FES"))
/* 65 */           in0.setM_MessageData(new FesRegistration(in0.getM_MessageData().getData()));
/*    */         else {
/* 67 */           in0.setM_MessageData(new RegistrationData(in0.getM_MessageData().getData()));
/*    */         }
/*    */ 
/*    */       case 2:
/*    */       }
/*    */ 
/*    */     }
/*    */ 
/* 75 */     logger.debug(in0);
/* 76 */     MessageService.getSoleInstance().receive(in0);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.web.MessageWebServiceSoapBindingImpl
 * JD-Core Version:    0.6.0
 */