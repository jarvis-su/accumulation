/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class RSASignature
/*    */ {
/*    */   BigInteger s;
/*    */ 
/*    */   public BigInteger getS()
/*    */   {
/* 20 */     return this.s;
/*    */   }
/*    */ 
/*    */   public RSASignature(BigInteger s)
/*    */   {
/* 25 */     this.s = s;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.RSASignature
 * JD-Core Version:    0.6.0
 */