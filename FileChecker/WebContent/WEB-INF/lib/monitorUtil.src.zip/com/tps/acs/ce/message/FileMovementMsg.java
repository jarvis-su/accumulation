/*     */ package com.acs.ce.message;
/*     */ 
/*     */ import com.acs.eppic.message.FileMovementInfo;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.messageservice.MessageSender;
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.util.Date;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class FileMovementMsg
/*     */ {
/*     */   public static void usage(int argSize)
/*     */   {
/*  14 */     System.out.println("Usage:\nFileMovementMsg [systemId] fileName destServer sourceServer status\n");
/*     */   }
/*     */ 
/*     */   public static void enableService(MessageSender ms)
/*     */   {
/*  19 */     ms.setServiceEnabled(true);
/*     */   }
/*     */ 
/*     */   public static void disableService(MessageSender ms)
/*     */   {
/*     */     try {
/*  25 */       Thread.sleep(1000L);
/*     */     } catch (InterruptedException e) {
/*  27 */       e.printStackTrace();
/*     */     }
/*  29 */     ms.setServiceEnabled(false);
/*     */   }
/*     */ 
/*     */   public static void sendMessage(MessageSender ms, String system, String fileName, String destServer, String sourceServer, String status, Date time, long size) {
/*  33 */     boolean isStart = false;
/*  34 */     if (status.equalsIgnoreCase("start"))
/*  35 */       isStart = true;
/*  36 */     Message m = new Message(system, "FILEMOVEMENT", 4, "");
/*  37 */     m.setM_MessageData(new FileMovementInfo(fileName, destServer, sourceServer, status, time, isStart, size));
/*  38 */     ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public static void sendMessage(String system, String fileName, String destServer, String sourceServer, String status, Date time, long size) {
/*  42 */     MessageSender ms = new MessageSender();
/*  43 */     enableService(ms);
/*  44 */     sendMessage(ms, system, fileName, destServer, sourceServer, status, time, size);
/*  45 */     disableService(ms);
/*     */   }
/*     */ 
/*     */   public static long getFileSize(File f) {
/*  49 */     if (!f.exists())
/*  50 */       return -1L;
/*  51 */     return f.length();
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  67 */     String fileName = "CA57-CALWIN-20100120095703012621000-FSBEBENEMAINT";
/*  68 */     File file = new File(fileName);
/*  69 */     long size = getFileSize(file);
/*     */ 
/*  71 */     MessageSender ms = new MessageSender();
/*  72 */     enableService(ms);
/*     */ 
/*  74 */     Random r = new Random();
/*     */ 
/*  76 */     for (int i = 0; i < 1000; i++) {
/*  77 */       System.out.println("Sending " + i);
/*  78 */       sendMessage(ms, "CAEBT", file.getName() + i, 
/*  79 */         "caftp@192.168.179.98:sarsftp/outgoing", 
/*  80 */         "192.168.179.220", 
/*  81 */         "START", 
/*  82 */         new Date(System.currentTimeMillis()), 
/*  83 */         103600L);
/*     */ 
/*  86 */       long l = r.nextInt(5000);
/*  87 */       System.out.println("    Pretending to send " + l);
/*     */       try { Thread.sleep(l); } catch (InterruptedException localInterruptedException) {
/*     */       }
/*  90 */       sendMessage(ms, "CAEBT", file.getName() + i, 
/*  91 */         "caftp@192.168.179.98:sarsftp/outgoing", 
/*  92 */         "192.168.179.220", 
/*  93 */         "TRANSFERRED", 
/*  94 */         new Date(System.currentTimeMillis()), 
/*  95 */         103600L);
/*  96 */       l = r.nextInt(5000);
/*  97 */       System.out.println("    Waiting " + l);
/*     */       try { Thread.sleep(l); } catch (InterruptedException localInterruptedException1) {
/*     */       }
/*     */     }
/* 100 */     disableService(ms);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.ce.message.FileMovementMsg
 * JD-Core Version:    0.6.0
 */