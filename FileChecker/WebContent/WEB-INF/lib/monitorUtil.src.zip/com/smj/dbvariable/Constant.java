/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class Constant extends DBVar
/*    */ {
/*    */   public Constant()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Constant(String s)
/*    */   {
/* 21 */     super(s);
/*    */   }
/*    */ 
/*    */   protected Vector<String> resolveInternal(VarCache c, Properties env)
/*    */     throws Exception
/*    */   {
/* 27 */     Vector v = new Vector();
/* 28 */     v.add(getInitialValue());
/* 29 */     return v;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.smj.dbvariable.Constant
 * JD-Core Version:    0.6.0
 */