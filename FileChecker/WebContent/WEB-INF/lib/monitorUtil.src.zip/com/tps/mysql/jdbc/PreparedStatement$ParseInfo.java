/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ 
/*     */ class PreparedStatement$ParseInfo
/*     */ {
/*     */   char firstStmtChar;
/*     */   boolean foundLimitClause;
/*     */   boolean foundLoadData;
/*     */   long lastUsed;
/*     */   int statementLength;
/*     */   byte[][] staticSql;
/*     */   private final PreparedStatement this$0;
/*     */ 
/*     */   public PreparedStatement$ParseInfo(PreparedStatement this$0, String sql, Connection conn, DatabaseMetaData dbmd, String encoding, SingleByteCharsetConverter converter)
/*     */     throws SQLException
/*     */   {
/* 146 */     this.this$0 = this$0;
/*     */ 
/* 129 */     this.firstStmtChar = '\000';
/*     */ 
/* 131 */     this.foundLimitClause = false;
/*     */ 
/* 133 */     this.foundLoadData = false;
/*     */ 
/* 135 */     this.lastUsed = 0L;
/*     */ 
/* 137 */     this.statementLength = 0;
/*     */ 
/* 139 */     this.staticSql = ((byte[][])null);
/*     */ 
/* 147 */     if (sql == null) {
/* 148 */       throw SQLError.createSQLException(Messages.getString("PreparedStatement.61"), "S1009");
/*     */     }
/*     */ 
/* 153 */     this.lastUsed = System.currentTimeMillis();
/*     */ 
/* 155 */     String quotedIdentifierString = dbmd.getIdentifierQuoteString();
/*     */ 
/* 157 */     char quotedIdentifierChar = '\000';
/*     */ 
/* 159 */     if ((quotedIdentifierString != null) && (!quotedIdentifierString.equals(" ")) && (quotedIdentifierString.length() > 0))
/*     */     {
/* 162 */       quotedIdentifierChar = quotedIdentifierString.charAt(0);
/*     */     }
/*     */ 
/* 165 */     this.statementLength = sql.length();
/*     */ 
/* 167 */     ArrayList endpointList = new ArrayList();
/* 168 */     boolean inQuotes = false;
/* 169 */     char quoteChar = '\000';
/* 170 */     boolean inQuotedId = false;
/* 171 */     int lastParmEnd = 0;
/*     */ 
/* 174 */     int stopLookingForLimitClause = this.statementLength - 5;
/*     */ 
/* 176 */     this.foundLimitClause = false;
/*     */ 
/* 178 */     boolean noBackslashEscapes = this$0.connection.isNoBackslashEscapesSet();
/*     */ 
/* 180 */     for (int i = 0; i < this.statementLength; i++) {
/* 181 */       char c = sql.charAt(i);
/*     */ 
/* 183 */       if ((this.firstStmtChar == 0) && (!Character.isWhitespace(c)))
/*     */       {
/* 186 */         this.firstStmtChar = Character.toUpperCase(c);
/*     */       }
/*     */ 
/* 189 */       if ((!noBackslashEscapes) && (c == '\\') && (i < this.statementLength - 1))
/*     */       {
/* 191 */         i++;
/*     */       }
/*     */       else
/*     */       {
/* 197 */         if ((!inQuotes) && (quotedIdentifierChar != 0) && (c == quotedIdentifierChar))
/*     */         {
/* 199 */           inQuotedId = !inQuotedId;
/* 200 */         } else if (!inQuotedId)
/*     */         {
/* 203 */           if (inQuotes) {
/* 204 */             if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/* 205 */               if ((i < this.statementLength - 1) && (sql.charAt(i + 1) == quoteChar)) {
/* 206 */                 i++;
/* 207 */                 continue;
/*     */               }
/*     */ 
/* 210 */               inQuotes = !inQuotes;
/* 211 */               quoteChar = '\000';
/* 212 */             } else if (((c == '\'') || (c == '"')) && (c == quoteChar)) {
/* 213 */               inQuotes = !inQuotes;
/* 214 */               quoteChar = '\000';
/*     */             }
/*     */           }
/* 217 */           else if ((c == '\'') || (c == '"')) {
/* 218 */             inQuotes = true;
/* 219 */             quoteChar = c;
/* 220 */           } else if ((c == '\'') || (c == '"')) {
/* 221 */             inQuotes = true;
/* 222 */             quoteChar = c;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/* 227 */         if ((c == '?') && (!inQuotes) && (!inQuotedId)) {
/* 228 */           endpointList.add(new int[] { lastParmEnd, i });
/* 229 */           lastParmEnd = i + 1;
/*     */         }
/*     */ 
/* 232 */         if ((inQuotes) || (i >= stopLookingForLimitClause) || (
/* 233 */           (c != 'L') && (c != 'l'))) continue;
/* 234 */         char posI1 = sql.charAt(i + 1);
/*     */ 
/* 236 */         if ((posI1 == 'I') || (posI1 == 'i')) {
/* 237 */           char posM = sql.charAt(i + 2);
/*     */ 
/* 239 */           if ((posM == 'M') || (posM == 'm')) {
/* 240 */             char posI2 = sql.charAt(i + 3);
/*     */ 
/* 242 */             if ((posI2 == 'I') || (posI2 == 'i')) {
/* 243 */               char posT = sql.charAt(i + 4);
/*     */ 
/* 245 */               if ((posT == 'T') || (posT == 't')) {
/* 246 */                 this.foundLimitClause = true;
/*     */               }
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 255 */     if (this.firstStmtChar == 'L') {
/* 256 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA"))
/* 257 */         this.foundLoadData = true;
/*     */       else
/* 259 */         this.foundLoadData = false;
/*     */     }
/*     */     else {
/* 262 */       this.foundLoadData = false;
/*     */     }
/*     */ 
/* 265 */     endpointList.add(new int[] { lastParmEnd, this.statementLength });
/* 266 */     this.staticSql = new byte[endpointList.size()][];
/* 267 */     char[] asCharArray = sql.toCharArray();
/*     */ 
/* 269 */     for (i = 0; i < this.staticSql.length; i++) {
/* 270 */       int[] ep = (int[])endpointList.get(i);
/* 271 */       int end = ep[1];
/* 272 */       int begin = ep[0];
/* 273 */       int len = end - begin;
/*     */ 
/* 275 */       if (this.foundLoadData) {
/* 276 */         String temp = new String(asCharArray, begin, len);
/* 277 */         this.staticSql[i] = temp.getBytes();
/* 278 */       } else if (encoding == null) {
/* 279 */         byte[] buf = new byte[len];
/*     */ 
/* 281 */         for (int j = 0; j < len; j++) {
/* 282 */           buf[j] = (byte)sql.charAt(begin + j);
/*     */         }
/*     */ 
/* 285 */         this.staticSql[i] = buf;
/*     */       }
/* 287 */       else if (converter != null) {
/* 288 */         this.staticSql[i] = StringUtils.getBytes(sql, converter, encoding, this$0.connection.getServerCharacterEncoding(), begin, len, this$0.connection.parserKnowsUnicode());
/*     */       }
/*     */       else
/*     */       {
/* 293 */         String temp = new String(asCharArray, begin, len);
/*     */ 
/* 295 */         this.staticSql[i] = StringUtils.getBytes(temp, encoding, this$0.connection.getServerCharacterEncoding(), this$0.connection.parserKnowsUnicode(), conn);
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.PreparedStatement.ParseInfo
 * JD-Core Version:    0.6.0
 */