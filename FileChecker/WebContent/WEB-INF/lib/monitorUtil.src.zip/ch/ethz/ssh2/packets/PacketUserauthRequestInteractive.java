/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketUserauthRequestInteractive
/*    */ {
/*    */   byte[] payload;
/*    */   String userName;
/*    */   String serviceName;
/*    */   String[] submethods;
/*    */ 
/*    */   public PacketUserauthRequestInteractive(String serviceName, String user, String[] submethods)
/*    */   {
/* 20 */     this.serviceName = serviceName;
/* 21 */     this.userName = user;
/* 22 */     this.submethods = submethods;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 27 */     if (this.payload == null)
/*    */     {
/* 29 */       TypesWriter tw = new TypesWriter();
/* 30 */       tw.writeByte(50);
/* 31 */       tw.writeString(this.userName);
/* 32 */       tw.writeString(this.serviceName);
/* 33 */       tw.writeString("keyboard-interactive");
/* 34 */       tw.writeString("");
/*    */ 
/* 36 */       tw.writeNameList(this.submethods);
/*    */ 
/* 38 */       this.payload = tw.getBytes();
/*    */     }
/* 40 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthRequestInteractive
 * JD-Core Version:    0.6.0
 */