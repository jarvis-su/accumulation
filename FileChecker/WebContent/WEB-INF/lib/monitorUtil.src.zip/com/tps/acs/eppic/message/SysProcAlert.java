/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class SysProcAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = 4106781584315702011L;
/*    */   private static final String ARGUMENTS = "ARGUMENTS";
/*    */   private static final String PROC_NAME = "PROC_NAME";
/*    */ 
/*    */   public SysProcAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SysProcAlert(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public SysProcAlert(String code, String description, String procName, String arguments) {
/* 23 */     super(code, description);
/* 24 */     setData("PROC_NAME", procName);
/* 25 */     setData("ARGUMENTS", arguments);
/*    */   }
/*    */ 
/*    */   public String getArguments() {
/* 29 */     String list = "";
/* 30 */     if (getData("ARGUMENTS") != null) {
/* 31 */       list = (String)getData("ARGUMENTS");
/*    */     }
/* 33 */     return list;
/*    */   }
/*    */ 
/*    */   public String getProcName() {
/* 37 */     String procName = "";
/* 38 */     if (getData("PROC_NAME") != null) {
/* 39 */       procName = (String)getData("PROC_NAME");
/*    */     }
/* 41 */     return procName;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return super.toString() + 
/* 46 */       "  ProcessName: " + getProcName() + "\n" + 
/* 47 */       "  Arguments: " + getArguments() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.SysProcAlert
 * JD-Core Version:    0.6.0
 */