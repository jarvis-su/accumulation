/*     */ package ch.ethz.ssh2.crypto;
/*     */ 
/*     */ import java.io.CharArrayWriter;
/*     */ import java.io.IOException;
/*     */ 
/*     */ public class Base64
/*     */ {
/*  15 */   static final char[] alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
/*     */ 
/*     */   public static char[] encode(byte[] content)
/*     */   {
/*  19 */     CharArrayWriter cw = new CharArrayWriter(4 * content.length / 3);
/*     */ 
/*  21 */     int idx = 0;
/*     */ 
/*  23 */     int x = 0;
/*     */ 
/*  25 */     for (int i = 0; i < content.length; i++)
/*     */     {
/*  27 */       if (idx == 0)
/*  28 */         x = (content[i] & 0xFF) << 16;
/*  29 */       else if (idx == 1)
/*  30 */         x |= (content[i] & 0xFF) << 8;
/*     */       else {
/*  32 */         x |= content[i] & 0xFF;
/*     */       }
/*  34 */       idx++;
/*     */ 
/*  36 */       if (idx != 3)
/*     */         continue;
/*  38 */       cw.write(alphabet[(x >> 18)]);
/*  39 */       cw.write(alphabet[(x >> 12 & 0x3F)]);
/*  40 */       cw.write(alphabet[(x >> 6 & 0x3F)]);
/*  41 */       cw.write(alphabet[(x & 0x3F)]);
/*     */ 
/*  43 */       idx = 0;
/*     */     }
/*     */ 
/*  47 */     if (idx == 1)
/*     */     {
/*  49 */       cw.write(alphabet[(x >> 18)]);
/*  50 */       cw.write(alphabet[(x >> 12 & 0x3F)]);
/*  51 */       cw.write(61);
/*  52 */       cw.write(61);
/*     */     }
/*     */ 
/*  55 */     if (idx == 2)
/*     */     {
/*  57 */       cw.write(alphabet[(x >> 18)]);
/*  58 */       cw.write(alphabet[(x >> 12 & 0x3F)]);
/*  59 */       cw.write(alphabet[(x >> 6 & 0x3F)]);
/*  60 */       cw.write(61);
/*     */     }
/*     */ 
/*  63 */     return cw.toCharArray();
/*     */   }
/*     */ 
/*     */   public static byte[] decode(char[] message) throws IOException
/*     */   {
/*  68 */     byte[] buff = new byte[4];
/*  69 */     byte[] dest = new byte[message.length];
/*     */ 
/*  71 */     int bpos = 0;
/*  72 */     int destpos = 0;
/*     */ 
/*  74 */     for (int i = 0; i < message.length; i++)
/*     */     {
/*  76 */       int c = message[i];
/*     */ 
/*  78 */       if ((c == 10) || (c == 13) || (c == 32) || (c == 9)) {
/*     */         continue;
/*     */       }
/*  81 */       if ((c >= 65) && (c <= 90))
/*     */       {
/*  83 */         buff[(bpos++)] = (byte)(c - 65);
/*     */       }
/*  85 */       else if ((c >= 97) && (c <= 122))
/*     */       {
/*  87 */         buff[(bpos++)] = (byte)(c - 97 + 26);
/*     */       }
/*  89 */       else if ((c >= 48) && (c <= 57))
/*     */       {
/*  91 */         buff[(bpos++)] = (byte)(c - 48 + 52);
/*     */       }
/*  93 */       else if (c == 43)
/*     */       {
/*  95 */         buff[(bpos++)] = 62;
/*     */       }
/*  97 */       else if (c == 47)
/*     */       {
/*  99 */         buff[(bpos++)] = 63;
/*     */       }
/* 101 */       else if (c == 61)
/*     */       {
/* 103 */         buff[(bpos++)] = 64;
/*     */       }
/*     */       else
/*     */       {
/* 107 */         throw new IOException("Illegal char in base64 code.");
/*     */       }
/*     */ 
/* 110 */       if (bpos != 4)
/*     */         continue;
/* 112 */       bpos = 0;
/*     */ 
/* 114 */       if (buff[0] == 64) {
/*     */         break;
/*     */       }
/* 117 */       if (buff[1] == 64) {
/* 118 */         throw new IOException("Unexpected '=' in base64 code.");
/*     */       }
/* 120 */       if (buff[2] == 64)
/*     */       {
/* 122 */         int v = (buff[0] & 0x3F) << 6 | buff[1] & 0x3F;
/* 123 */         dest[(destpos++)] = (byte)(v >> 4);
/* 124 */         break;
/*     */       }
/* 126 */       if (buff[3] == 64)
/*     */       {
/* 128 */         int v = (buff[0] & 0x3F) << 12 | (buff[1] & 0x3F) << 6 | buff[2] & 0x3F;
/* 129 */         dest[(destpos++)] = (byte)(v >> 10);
/* 130 */         dest[(destpos++)] = (byte)(v >> 2);
/* 131 */         break;
/*     */       }
/*     */ 
/* 135 */       int v = (buff[0] & 0x3F) << 18 | (buff[1] & 0x3F) << 12 | (buff[2] & 0x3F) << 6 | buff[3] & 0x3F;
/* 136 */       dest[(destpos++)] = (byte)(v >> 16);
/* 137 */       dest[(destpos++)] = (byte)(v >> 8);
/* 138 */       dest[(destpos++)] = (byte)v;
/*     */     }
/*     */ 
/* 143 */     byte[] res = new byte[destpos];
/* 144 */     System.arraycopy(dest, 0, res, 0, destpos);
/*     */ 
/* 146 */     return res;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.Base64
 * JD-Core Version:    0.6.0
 */