/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.util.LinkedList;
/*     */ 
/*     */ class MessageSender$OutgoingQueue
/*     */ {
/*     */   private final MessageSender.OutgoingQueue.QueueWorker[] threads;
/*     */   private final LinkedList alertQueue;
/*     */   private final LinkedList messageQueue;
/*     */   private MessageWebServiceServiceLocator mwsl;
/* 193 */   Object semObj = new Object();
/*     */ 
/*     */   public MessageSender$OutgoingQueue(MessageSender arg1) {
/* 196 */     this.mwsl = new MessageWebServiceServiceLocator();
/* 197 */     this.alertQueue = new LinkedList();
/* 198 */     this.messageQueue = new LinkedList();
/* 199 */     this.threads = new MessageSender.OutgoingQueue.QueueWorker[1];
/* 200 */     for (int i = 0; i < this.threads.length; i++) {
/* 201 */       this.threads[i] = new MessageSender.OutgoingQueue.QueueWorker(this, null);
/* 202 */       this.threads[i].setName("OUTGOING_QUEUE_" + i);
/* 203 */       this.threads[i].start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void disable()
/*     */   {
/* 210 */     synchronized (this.semObj) {
/* 211 */       this.semObj.notifyAll();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message) {
/* 216 */     boolean notify = false;
/* 217 */     if ((message.getServiceId() == "HEARTBEAT") || 
/* 218 */       (message.getType().getTypeId() == 1) || 
/* 219 */       (message.getType().getTypeId() == 0))
/*     */     {
/* 221 */       synchronized (this.alertQueue) {
/* 222 */         this.alertQueue.addLast(message);
/* 223 */         if (this.alertQueue.size() <= MessageSender.access$2(this.this$0))
/* 224 */           notify = true;
/*     */         else {
/* 226 */           notify = false;
/*     */         }
/*     */       }
/*     */     }
/* 230 */     synchronized (this.messageQueue) {
/* 231 */       if (this.messageQueue.size() <= MessageSender.access$3(this.this$0)) {
/* 232 */         this.messageQueue.addLast(message);
/* 233 */         if (this.messageQueue.size() >= MessageSender.access$4(this.this$0))
/* 234 */           notify = true;
/*     */         else {
/* 236 */           notify = false;
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 241 */     if (notify)
/* 242 */       synchronized (this.semObj) {
/* 243 */         this.semObj.notifyAll();
/*     */       }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 319 */     return "CLASS: OutgoingQueue\n";
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageSender.OutgoingQueue
 * JD-Core Version:    0.6.0
 */