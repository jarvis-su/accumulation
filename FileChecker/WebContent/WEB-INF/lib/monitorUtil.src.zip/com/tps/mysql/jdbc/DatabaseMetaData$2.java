/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ 
/*      */ class DatabaseMetaData$2 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$tableNamePattern;
/*      */   private final String val$catalog;
/*      */   private final String val$schemaPattern;
/*      */   private final String val$colPattern;
/*      */   private final Statement val$stmt;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 1933 */     ArrayList tableNameList = new ArrayList();
/*      */ 
/* 1935 */     if (this.val$tableNamePattern == null)
/*      */     {
/* 1937 */       ResultSet tables = null;
/*      */       try
/*      */       {
/* 1940 */         tables = this.this$0.getTables(this.val$catalog, this.val$schemaPattern, "%", new String[0]);
/*      */ 
/* 1943 */         while (tables.next()) {
/* 1944 */           String tableNameFromList = tables.getString("TABLE_NAME");
/*      */ 
/* 1946 */           tableNameList.add(tableNameFromList);
/*      */         }
/*      */       } finally {
/* 1949 */         if (tables != null) {
/*      */           try {
/* 1951 */             tables.close();
/*      */           } catch (Exception sqlEx) {
/* 1953 */             AssertionFailedException.shouldNotHappen(sqlEx);
/*      */           }
/*      */ 
/* 1957 */           tables = null;
/*      */         }
/*      */       }
/*      */     } else {
/* 1961 */       ResultSet tables = null;
/*      */       try
/*      */       {
/* 1964 */         tables = this.this$0.getTables(this.val$catalog, this.val$schemaPattern, this.val$tableNamePattern, new String[0]);
/*      */ 
/* 1967 */         while (tables.next()) {
/* 1968 */           String tableNameFromList = tables.getString("TABLE_NAME");
/*      */ 
/* 1970 */           tableNameList.add(tableNameFromList);
/*      */         }
/*      */       } finally {
/* 1973 */         if (tables != null) {
/*      */           try {
/* 1975 */             tables.close();
/*      */           } catch (SQLException sqlEx) {
/* 1977 */             AssertionFailedException.shouldNotHappen(sqlEx);
/*      */           }
/*      */ 
/* 1981 */           tables = null;
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1986 */     Iterator tableNames = tableNameList.iterator();
/*      */ 
/* 1988 */     while (tableNames.hasNext()) {
/* 1989 */       String tableName = (String)tableNames.next();
/*      */ 
/* 1991 */       ResultSet results = null;
/*      */       try
/*      */       {
/* 1994 */         StringBuffer queryBuf = new StringBuffer("SHOW ");
/*      */ 
/* 1996 */         if (this.this$0.conn.versionMeetsMinimum(4, 1, 0)) {
/* 1997 */           queryBuf.append("FULL ");
/*      */         }
/*      */ 
/* 2000 */         queryBuf.append("COLUMNS FROM ");
/* 2001 */         queryBuf.append(this.this$0.quotedId);
/* 2002 */         queryBuf.append(tableName);
/* 2003 */         queryBuf.append(this.this$0.quotedId);
/* 2004 */         queryBuf.append(" FROM ");
/* 2005 */         queryBuf.append(this.this$0.quotedId);
/* 2006 */         queryBuf.append(catalogStr.toString());
/* 2007 */         queryBuf.append(this.this$0.quotedId);
/* 2008 */         queryBuf.append(" LIKE '");
/* 2009 */         queryBuf.append(this.val$colPattern);
/* 2010 */         queryBuf.append("'");
/*      */ 
/* 2017 */         boolean fixUpOrdinalsRequired = false;
/* 2018 */         Object ordinalFixUpMap = null;
/*      */ 
/* 2020 */         if (!this.val$colPattern.equals("%")) {
/* 2021 */           fixUpOrdinalsRequired = true;
/*      */ 
/* 2023 */           StringBuffer fullColumnQueryBuf = new StringBuffer("SHOW ");
/*      */ 
/* 2026 */           if (this.this$0.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2027 */             fullColumnQueryBuf.append("FULL ");
/*      */           }
/*      */ 
/* 2030 */           fullColumnQueryBuf.append("COLUMNS FROM ");
/* 2031 */           fullColumnQueryBuf.append(this.this$0.quotedId);
/* 2032 */           fullColumnQueryBuf.append(tableName);
/* 2033 */           fullColumnQueryBuf.append(this.this$0.quotedId);
/* 2034 */           fullColumnQueryBuf.append(" FROM ");
/* 2035 */           fullColumnQueryBuf.append(this.this$0.quotedId);
/* 2036 */           fullColumnQueryBuf.append(catalogStr.toString());
/*      */ 
/* 2038 */           fullColumnQueryBuf.append(this.this$0.quotedId);
/*      */ 
/* 2040 */           results = this.val$stmt.executeQuery(fullColumnQueryBuf.toString());
/*      */ 
/* 2043 */           ordinalFixUpMap = new HashMap();
/*      */ 
/* 2045 */           int fullOrdinalPos = 1;
/*      */ 
/* 2047 */           while (results.next()) {
/* 2048 */             String fullOrdColName = results.getString("Field");
/*      */ 
/* 2051 */             ((Map)ordinalFixUpMap).put(fullOrdColName, new Integer(fullOrdinalPos++));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2056 */         results = this.val$stmt.executeQuery(queryBuf.toString());
/*      */ 
/* 2058 */         int ordPos = 1;
/*      */ 
/* 2060 */         while (results.next()) {
/* 2061 */           byte[][] rowVal = new byte[18][];
/* 2062 */           rowVal[0] = DatabaseMetaData.access$000(this.this$0, this.val$catalog);
/* 2063 */           rowVal[1] = null;
/*      */ 
/* 2066 */           rowVal[2] = DatabaseMetaData.access$000(this.this$0, tableName);
/* 2067 */           rowVal[3] = results.getBytes("Field");
/*      */ 
/* 2069 */           DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(this.this$0, results.getString("Type"), results.getString("Null"));
/*      */ 
/* 2073 */           rowVal[4] = Short.toString(typeDesc.dataType).getBytes();
/*      */ 
/* 2077 */           rowVal[5] = DatabaseMetaData.access$000(this.this$0, typeDesc.typeName);
/*      */ 
/* 2079 */           rowVal[6] = DatabaseMetaData.access$000(this.this$0, Integer.toString(typeDesc.columnSize));
/*      */ 
/* 2081 */           rowVal[7] = DatabaseMetaData.access$000(this.this$0, Integer.toString(typeDesc.bufferLength));
/*      */ 
/* 2083 */           rowVal[8] = DatabaseMetaData.access$000(this.this$0, Integer.toString(typeDesc.decimalDigits));
/*      */ 
/* 2085 */           rowVal[9] = DatabaseMetaData.access$000(this.this$0, Integer.toString(typeDesc.numPrecRadix));
/*      */ 
/* 2087 */           rowVal[10] = DatabaseMetaData.access$000(this.this$0, Integer.toString(typeDesc.nullability));
/*      */           try
/*      */           {
/* 2098 */             if (this.this$0.conn.versionMeetsMinimum(4, 1, 0)) {
/* 2099 */               rowVal[11] = results.getBytes("Comment");
/*      */             }
/*      */             else
/* 2102 */               rowVal[11] = results.getBytes("Extra");
/*      */           }
/*      */           catch (Exception E) {
/* 2105 */             rowVal[11] = new byte[0];
/*      */           }
/*      */ 
/* 2109 */           rowVal[12] = results.getBytes("Default");
/*      */ 
/* 2111 */           rowVal[13] = { 48 };
/* 2112 */           rowVal[14] = { 48 };
/* 2113 */           rowVal[15] = rowVal[6];
/*      */ 
/* 2116 */           if (!fixUpOrdinalsRequired) {
/* 2117 */             rowVal[16] = Integer.toString(ordPos++).getBytes();
/*      */           }
/*      */           else {
/* 2120 */             String origColName = results.getString("Field");
/*      */ 
/* 2122 */             Integer realOrdinal = (Integer)((Map)ordinalFixUpMap).get(origColName);
/*      */ 
/* 2125 */             if (realOrdinal != null) {
/* 2126 */               rowVal[16] = realOrdinal.toString().getBytes();
/*      */             }
/*      */             else {
/* 2129 */               throw SQLError.createSQLException("Can not find column in full column list to determine true ordinal position.", "S1000");
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 2135 */           rowVal[17] = DatabaseMetaData.access$000(this.this$0, typeDesc.isNullable);
/*      */ 
/* 2137 */           this.val$rows.add(rowVal);
/*      */         }
/*      */       } finally {
/* 2140 */         if (results != null) {
/*      */           try {
/* 2142 */             results.close();
/*      */           }
/*      */           catch (Exception ex)
/*      */           {
/*      */           }
/* 2147 */           results = null;
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.2
 * JD-Core Version:    0.6.0
 */