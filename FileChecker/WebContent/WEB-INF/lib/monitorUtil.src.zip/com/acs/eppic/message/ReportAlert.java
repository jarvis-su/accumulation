/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ReportAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = 4526540078561267732L;
/*    */   private static final String ARGUMENTS = "ARGUMENTS";
/*    */   private static final String REPORT_NAME = "REPORT_NAME";
/*    */ 
/*    */   public ReportAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReportAlert(HashMap map)
/*    */   {
/* 20 */     setData(map);
/*    */   }
/*    */ 
/*    */   public ReportAlert(String code, String description, String reportName, String arguments) {
/* 24 */     super(code, description);
/* 25 */     setData("REPORT_NAME", reportName);
/* 26 */     setData("ARGUMENTS", arguments);
/*    */   }
/*    */ 
/*    */   public String getArguments() {
/* 30 */     String list = "";
/* 31 */     if (getData("ARGUMENTS") != null) {
/* 32 */       list = (String)getData("ARGUMENTS");
/*    */     }
/* 34 */     return list;
/*    */   }
/*    */ 
/*    */   public String getReportName() {
/* 38 */     String reportName = "";
/* 39 */     if (getData("REPORT_NAME") != null) {
/* 40 */       reportName = (String)getData("REPORT_NAME");
/*    */     }
/* 42 */     return reportName;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 46 */     return super.toString() + 
/* 47 */       "  ReportName: " + getReportName() + "\n" + 
/* 48 */       "  Arguments: " + getArguments() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.ReportAlert
 * JD-Core Version:    0.6.0
 */