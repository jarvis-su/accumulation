/*      */ package ch.ethz.ssh2;
/*      */ 
/*      */ import ch.ethz.ssh2.packets.TypesReader;
/*      */ import ch.ethz.ssh2.packets.TypesWriter;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PrintStream;
/*      */ import java.nio.charset.Charset;
/*      */ import java.util.HashMap;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class SFTPv3Client
/*      */ {
/*      */   final Connection conn;
/*      */   final Session sess;
/*      */   final PrintStream debug;
/*   66 */   boolean flag_closed = false;
/*      */   InputStream is;
/*      */   OutputStream os;
/*   71 */   int protocol_version = 0;
/*   72 */   HashMap server_extensions = new HashMap();
/*      */ 
/*   74 */   int next_request_id = 1000;
/*      */ 
/*   76 */   String charsetName = null;
/*      */ 
/*      */   /** @deprecated */
/*      */   public SFTPv3Client(Connection conn, PrintStream debug)
/*      */     throws IOException
/*      */   {
/*   90 */     if (conn == null) {
/*   91 */       throw new IllegalArgumentException("Cannot accept null argument!");
/*      */     }
/*   93 */     this.conn = conn;
/*   94 */     this.debug = debug;
/*      */ 
/*   96 */     if (debug != null) {
/*   97 */       debug.println("Opening session and starting SFTP subsystem.");
/*      */     }
/*   99 */     this.sess = conn.openSession();
/*  100 */     this.sess.startSubSystem("sftp");
/*      */ 
/*  102 */     this.is = this.sess.getStdout();
/*  103 */     this.os = new BufferedOutputStream(this.sess.getStdin(), 2048);
/*      */ 
/*  105 */     if ((this.is == null) || (this.os == null)) {
/*  106 */       throw new IOException("There is a problem with the streams of the underlying channel.");
/*      */     }
/*  108 */     init();
/*      */   }
/*      */ 
/*      */   public SFTPv3Client(Connection conn)
/*      */     throws IOException
/*      */   {
/*  119 */     this(conn, null);
/*      */   }
/*      */ 
/*      */   public void setCharset(String charset)
/*      */     throws IOException
/*      */   {
/*  143 */     if (charset == null)
/*      */     {
/*  145 */       this.charsetName = charset;
/*  146 */       return;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  151 */       Charset.forName(charset);
/*      */     }
/*      */     catch (Exception e)
/*      */     {
/*  155 */       throw ((IOException)new IOException("This charset is not supported").initCause(e));
/*      */     }
/*  157 */     this.charsetName = charset;
/*      */   }
/*      */ 
/*      */   public String getCharset()
/*      */   {
/*  169 */     return this.charsetName;
/*      */   }
/*      */ 
/*      */   private final void checkHandleValidAndOpen(SFTPv3FileHandle handle) throws IOException
/*      */   {
/*  174 */     if (handle.client != this) {
/*  175 */       throw new IOException("The file handle was created with another SFTPv3FileHandle instance.");
/*      */     }
/*  177 */     if (handle.isClosed)
/*  178 */       throw new IOException("The file handle is closed.");
/*      */   }
/*      */ 
/*      */   private final void sendMessage(int type, int requestId, byte[] msg, int off, int len) throws IOException
/*      */   {
/*  183 */     int msglen = len + 1;
/*      */ 
/*  185 */     if (type != 1) {
/*  186 */       msglen += 4;
/*      */     }
/*  188 */     this.os.write(msglen >> 24);
/*  189 */     this.os.write(msglen >> 16);
/*  190 */     this.os.write(msglen >> 8);
/*  191 */     this.os.write(msglen);
/*  192 */     this.os.write(type);
/*      */ 
/*  194 */     if (type != 1)
/*      */     {
/*  196 */       this.os.write(requestId >> 24);
/*  197 */       this.os.write(requestId >> 16);
/*  198 */       this.os.write(requestId >> 8);
/*  199 */       this.os.write(requestId);
/*      */     }
/*      */ 
/*  202 */     this.os.write(msg, off, len);
/*  203 */     this.os.flush();
/*      */   }
/*      */ 
/*      */   private final void sendMessage(int type, int requestId, byte[] msg) throws IOException
/*      */   {
/*  208 */     sendMessage(type, requestId, msg, 0, msg.length);
/*      */   }
/*      */ 
/*      */   private final void readBytes(byte[] buff, int pos, int len) throws IOException
/*      */   {
/*  213 */     while (len > 0)
/*      */     {
/*  215 */       int count = this.is.read(buff, pos, len);
/*  216 */       if (count < 0)
/*  217 */         throw new IOException("Unexpected end of sftp stream.");
/*  218 */       if ((count == 0) || (count > len))
/*  219 */         throw new IOException("Underlying stream implementation is bogus!");
/*  220 */       len -= count;
/*  221 */       pos += count;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final byte[] receiveMessage(int maxlen)
/*      */     throws IOException
/*      */   {
/*  238 */     byte[] msglen = new byte[4];
/*      */ 
/*  240 */     readBytes(msglen, 0, 4);
/*      */ 
/*  242 */     int len = (msglen[0] & 0xFF) << 24 | (msglen[1] & 0xFF) << 16 | (msglen[2] & 0xFF) << 8 | msglen[3] & 0xFF;
/*      */ 
/*  244 */     if ((len > maxlen) || (len <= 0)) {
/*  245 */       throw new IOException("Illegal sftp packet len: " + len);
/*      */     }
/*  247 */     byte[] msg = new byte[len];
/*      */ 
/*  249 */     readBytes(msg, 0, len);
/*      */ 
/*  251 */     return msg;
/*      */   }
/*      */ 
/*      */   private final int generateNextRequestID()
/*      */   {
/*  256 */     synchronized (this)
/*      */     {
/*  258 */       return this.next_request_id++;
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void closeHandle(byte[] handle) throws IOException
/*      */   {
/*  264 */     int req_id = generateNextRequestID();
/*      */ 
/*  266 */     TypesWriter tw = new TypesWriter();
/*  267 */     tw.writeString(handle, 0, handle.length);
/*      */ 
/*  269 */     sendMessage(4, req_id, tw.getBytes());
/*      */ 
/*  271 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   private SFTPv3FileAttributes readAttrs(TypesReader tr)
/*      */     throws IOException
/*      */   {
/*  291 */     SFTPv3FileAttributes fa = new SFTPv3FileAttributes();
/*      */ 
/*  293 */     int flags = tr.readUINT32();
/*      */ 
/*  295 */     if ((flags & 0x1) != 0)
/*      */     {
/*  297 */       if (this.debug != null)
/*  298 */         this.debug.println("SSH_FILEXFER_ATTR_SIZE");
/*  299 */       fa.size = new Long(tr.readUINT64());
/*      */     }
/*      */ 
/*  302 */     if ((flags & 0x2) != 0)
/*      */     {
/*  304 */       if (this.debug != null)
/*  305 */         this.debug.println("SSH_FILEXFER_ATTR_V3_UIDGID");
/*  306 */       fa.uid = new Integer(tr.readUINT32());
/*  307 */       fa.gid = new Integer(tr.readUINT32());
/*      */     }
/*      */ 
/*  310 */     if ((flags & 0x4) != 0)
/*      */     {
/*  312 */       if (this.debug != null)
/*  313 */         this.debug.println("SSH_FILEXFER_ATTR_PERMISSIONS");
/*  314 */       fa.permissions = new Integer(tr.readUINT32());
/*      */     }
/*      */ 
/*  317 */     if ((flags & 0x8) != 0)
/*      */     {
/*  319 */       if (this.debug != null)
/*  320 */         this.debug.println("SSH_FILEXFER_ATTR_V3_ACMODTIME");
/*  321 */       fa.atime = new Integer(tr.readUINT32());
/*  322 */       fa.mtime = new Integer(tr.readUINT32());
/*      */     }
/*      */ 
/*  326 */     if ((flags & 0x80000000) != 0)
/*      */     {
/*  328 */       int count = tr.readUINT32();
/*      */ 
/*  330 */       if (this.debug != null) {
/*  331 */         this.debug.println("SSH_FILEXFER_ATTR_EXTENDED (" + count + ")");
/*      */       }
/*      */ 
/*  335 */       while (count > 0)
/*      */       {
/*  337 */         tr.readByteString();
/*  338 */         tr.readByteString();
/*  339 */         count--;
/*      */       }
/*      */     }
/*      */ 
/*  343 */     return fa;
/*      */   }
/*      */ 
/*      */   public SFTPv3FileAttributes fstat(SFTPv3FileHandle handle)
/*      */     throws IOException
/*      */   {
/*  355 */     checkHandleValidAndOpen(handle);
/*      */ 
/*  357 */     int req_id = generateNextRequestID();
/*      */ 
/*  359 */     TypesWriter tw = new TypesWriter();
/*  360 */     tw.writeString(handle.fileHandle, 0, handle.fileHandle.length);
/*      */ 
/*  362 */     if (this.debug != null)
/*      */     {
/*  364 */       this.debug.println("Sending SSH_FXP_FSTAT...");
/*  365 */       this.debug.flush();
/*      */     }
/*      */ 
/*  368 */     sendMessage(8, req_id, tw.getBytes());
/*      */ 
/*  370 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  372 */     if (this.debug != null)
/*      */     {
/*  374 */       this.debug.println("Got REPLY.");
/*  375 */       this.debug.flush();
/*      */     }
/*      */ 
/*  378 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  380 */     int t = tr.readByte();
/*      */ 
/*  382 */     int rep_id = tr.readUINT32();
/*  383 */     if (rep_id != req_id) {
/*  384 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  386 */     if (t == 105)
/*      */     {
/*  388 */       return readAttrs(tr);
/*      */     }
/*      */ 
/*  391 */     if (t != 101) {
/*  392 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  394 */     int errorCode = tr.readUINT32();
/*      */ 
/*  396 */     throw new SFTPException(tr.readString(), errorCode);
/*      */   }
/*      */ 
/*      */   private SFTPv3FileAttributes statBoth(String path, int statMethod) throws IOException
/*      */   {
/*  401 */     int req_id = generateNextRequestID();
/*      */ 
/*  403 */     TypesWriter tw = new TypesWriter();
/*  404 */     tw.writeString(path, this.charsetName);
/*      */ 
/*  406 */     if (this.debug != null)
/*      */     {
/*  408 */       this.debug.println("Sending SSH_FXP_STAT/SSH_FXP_LSTAT...");
/*  409 */       this.debug.flush();
/*      */     }
/*      */ 
/*  412 */     sendMessage(statMethod, req_id, tw.getBytes());
/*      */ 
/*  414 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  416 */     if (this.debug != null)
/*      */     {
/*  418 */       this.debug.println("Got REPLY.");
/*  419 */       this.debug.flush();
/*      */     }
/*      */ 
/*  422 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  424 */     int t = tr.readByte();
/*      */ 
/*  426 */     int rep_id = tr.readUINT32();
/*  427 */     if (rep_id != req_id) {
/*  428 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  430 */     if (t == 105)
/*      */     {
/*  432 */       return readAttrs(tr);
/*      */     }
/*      */ 
/*  435 */     if (t != 101) {
/*  436 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  438 */     int errorCode = tr.readUINT32();
/*      */ 
/*  440 */     throw new SFTPException(tr.readString(), errorCode);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileAttributes stat(String path)
/*      */     throws IOException
/*      */   {
/*  455 */     return statBoth(path, 17);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileAttributes lstat(String path)
/*      */     throws IOException
/*      */   {
/*  470 */     return statBoth(path, 7);
/*      */   }
/*      */ 
/*      */   public String readLink(String path)
/*      */     throws IOException
/*      */   {
/*  482 */     int req_id = generateNextRequestID();
/*      */ 
/*  484 */     TypesWriter tw = new TypesWriter();
/*  485 */     tw.writeString(path, this.charsetName);
/*      */ 
/*  487 */     if (this.debug != null)
/*      */     {
/*  489 */       this.debug.println("Sending SSH_FXP_READLINK...");
/*  490 */       this.debug.flush();
/*      */     }
/*      */ 
/*  493 */     sendMessage(19, req_id, tw.getBytes());
/*      */ 
/*  495 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  497 */     if (this.debug != null)
/*      */     {
/*  499 */       this.debug.println("Got REPLY.");
/*  500 */       this.debug.flush();
/*      */     }
/*      */ 
/*  503 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  505 */     int t = tr.readByte();
/*      */ 
/*  507 */     int rep_id = tr.readUINT32();
/*  508 */     if (rep_id != req_id) {
/*  509 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  511 */     if (t == 104)
/*      */     {
/*  513 */       int count = tr.readUINT32();
/*      */ 
/*  515 */       if (count != 1) {
/*  516 */         throw new IOException("The server sent an invalid SSH_FXP_NAME packet.");
/*      */       }
/*  518 */       return tr.readString(this.charsetName);
/*      */     }
/*      */ 
/*  521 */     if (t != 101) {
/*  522 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  524 */     int errorCode = tr.readUINT32();
/*      */ 
/*  526 */     throw new SFTPException(tr.readString(), errorCode);
/*      */   }
/*      */ 
/*      */   private void expectStatusOKMessage(int id) throws IOException
/*      */   {
/*  531 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  533 */     if (this.debug != null)
/*      */     {
/*  535 */       this.debug.println("Got REPLY.");
/*  536 */       this.debug.flush();
/*      */     }
/*      */ 
/*  539 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  541 */     int t = tr.readByte();
/*      */ 
/*  543 */     int rep_id = tr.readUINT32();
/*  544 */     if (rep_id != id) {
/*  545 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  547 */     if (t != 101) {
/*  548 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  550 */     int errorCode = tr.readUINT32();
/*      */ 
/*  552 */     if (errorCode == 0) {
/*  553 */       return;
/*      */     }
/*  555 */     throw new SFTPException(tr.readString(), errorCode);
/*      */   }
/*      */ 
/*      */   public void setstat(String path, SFTPv3FileAttributes attr)
/*      */     throws IOException
/*      */   {
/*  569 */     int req_id = generateNextRequestID();
/*      */ 
/*  571 */     TypesWriter tw = new TypesWriter();
/*  572 */     tw.writeString(path, this.charsetName);
/*  573 */     tw.writeBytes(createAttrs(attr));
/*      */ 
/*  575 */     if (this.debug != null)
/*      */     {
/*  577 */       this.debug.println("Sending SSH_FXP_SETSTAT...");
/*  578 */       this.debug.flush();
/*      */     }
/*      */ 
/*  581 */     sendMessage(9, req_id, tw.getBytes());
/*      */ 
/*  583 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public void fsetstat(SFTPv3FileHandle handle, SFTPv3FileAttributes attr)
/*      */     throws IOException
/*      */   {
/*  597 */     checkHandleValidAndOpen(handle);
/*      */ 
/*  599 */     int req_id = generateNextRequestID();
/*      */ 
/*  601 */     TypesWriter tw = new TypesWriter();
/*  602 */     tw.writeString(handle.fileHandle, 0, handle.fileHandle.length);
/*  603 */     tw.writeBytes(createAttrs(attr));
/*      */ 
/*  605 */     if (this.debug != null)
/*      */     {
/*  607 */       this.debug.println("Sending SSH_FXP_FSETSTAT...");
/*  608 */       this.debug.flush();
/*      */     }
/*      */ 
/*  611 */     sendMessage(10, req_id, tw.getBytes());
/*      */ 
/*  613 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public void createSymlink(String src, String target)
/*      */     throws IOException
/*      */   {
/*  626 */     int req_id = generateNextRequestID();
/*      */ 
/*  632 */     TypesWriter tw = new TypesWriter();
/*  633 */     tw.writeString(target, this.charsetName);
/*  634 */     tw.writeString(src, this.charsetName);
/*      */ 
/*  636 */     if (this.debug != null)
/*      */     {
/*  638 */       this.debug.println("Sending SSH_FXP_SYMLINK...");
/*  639 */       this.debug.flush();
/*      */     }
/*      */ 
/*  642 */     sendMessage(20, req_id, tw.getBytes());
/*      */ 
/*  644 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public String canonicalPath(String path)
/*      */     throws IOException
/*      */   {
/*  658 */     int req_id = generateNextRequestID();
/*      */ 
/*  660 */     TypesWriter tw = new TypesWriter();
/*  661 */     tw.writeString(path, this.charsetName);
/*      */ 
/*  663 */     if (this.debug != null)
/*      */     {
/*  665 */       this.debug.println("Sending SSH_FXP_REALPATH...");
/*  666 */       this.debug.flush();
/*      */     }
/*      */ 
/*  669 */     sendMessage(16, req_id, tw.getBytes());
/*      */ 
/*  671 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  673 */     if (this.debug != null)
/*      */     {
/*  675 */       this.debug.println("Got REPLY.");
/*  676 */       this.debug.flush();
/*      */     }
/*      */ 
/*  679 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  681 */     int t = tr.readByte();
/*      */ 
/*  683 */     int rep_id = tr.readUINT32();
/*  684 */     if (rep_id != req_id) {
/*  685 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  687 */     if (t == 104)
/*      */     {
/*  689 */       int count = tr.readUINT32();
/*      */ 
/*  691 */       if (count != 1) {
/*  692 */         throw new IOException("The server sent an invalid SSH_FXP_NAME packet.");
/*      */       }
/*  694 */       return tr.readString(this.charsetName);
/*      */     }
/*      */ 
/*  697 */     if (t != 101) {
/*  698 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  700 */     int errorCode = tr.readUINT32();
/*      */ 
/*  702 */     throw new SFTPException(tr.readString(), errorCode);
/*      */   }
/*      */ 
/*      */   private final Vector scanDirectory(byte[] handle) throws IOException
/*      */   {
/*  707 */     Vector files = new Vector();
/*      */     while (true)
/*      */     {
/*  711 */       int req_id = generateNextRequestID();
/*      */ 
/*  713 */       TypesWriter tw = new TypesWriter();
/*  714 */       tw.writeString(handle, 0, handle.length);
/*      */ 
/*  716 */       if (this.debug != null)
/*      */       {
/*  718 */         this.debug.println("Sending SSH_FXP_READDIR...");
/*  719 */         this.debug.flush();
/*      */       }
/*      */ 
/*  722 */       sendMessage(12, req_id, tw.getBytes());
/*      */ 
/*  724 */       byte[] resp = receiveMessage(34000);
/*      */ 
/*  726 */       if (this.debug != null)
/*      */       {
/*  728 */         this.debug.println("Got REPLY.");
/*  729 */         this.debug.flush();
/*      */       }
/*      */ 
/*  732 */       TypesReader tr = new TypesReader(resp);
/*      */ 
/*  734 */       int t = tr.readByte();
/*      */ 
/*  736 */       int rep_id = tr.readUINT32();
/*  737 */       if (rep_id != req_id) {
/*  738 */         throw new IOException("The server sent an invalid id field.");
/*      */       }
/*  740 */       if (t == 104)
/*      */       {
/*  742 */         int count = tr.readUINT32();
/*      */ 
/*  744 */         if (this.debug != null) {
/*  745 */           this.debug.println("Parsing " + count + " name entries...");
/*      */         }
/*  747 */         while (count > 0)
/*      */         {
/*  749 */           SFTPv3DirectoryEntry dirEnt = new SFTPv3DirectoryEntry();
/*      */ 
/*  751 */           dirEnt.filename = tr.readString(this.charsetName);
/*  752 */           dirEnt.longEntry = tr.readString(this.charsetName);
/*      */ 
/*  754 */           dirEnt.attributes = readAttrs(tr);
/*  755 */           files.addElement(dirEnt);
/*      */ 
/*  757 */           if (this.debug != null)
/*  758 */             this.debug.println("File: '" + dirEnt.filename + "'");
/*  759 */           count--;
/*      */         }
/*  761 */         continue;
/*      */       }
/*      */ 
/*  764 */       if (t != 101) {
/*  765 */         throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */       }
/*  767 */       int errorCode = tr.readUINT32();
/*      */ 
/*  769 */       if (errorCode == 1) {
/*  770 */         return files;
/*      */       }
/*  772 */       throw new SFTPException(tr.readString(), errorCode);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final byte[] openDirectory(String path) throws IOException
/*      */   {
/*  778 */     int req_id = generateNextRequestID();
/*      */ 
/*  780 */     TypesWriter tw = new TypesWriter();
/*  781 */     tw.writeString(path, this.charsetName);
/*      */ 
/*  783 */     if (this.debug != null)
/*      */     {
/*  785 */       this.debug.println("Sending SSH_FXP_OPENDIR...");
/*  786 */       this.debug.flush();
/*      */     }
/*      */ 
/*  789 */     sendMessage(11, req_id, tw.getBytes());
/*      */ 
/*  791 */     byte[] resp = receiveMessage(34000);
/*      */ 
/*  793 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/*  795 */     int t = tr.readByte();
/*      */ 
/*  797 */     int rep_id = tr.readUINT32();
/*  798 */     if (rep_id != req_id) {
/*  799 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/*  801 */     if (t == 102)
/*      */     {
/*  803 */       if (this.debug != null)
/*      */       {
/*  805 */         this.debug.println("Got SSH_FXP_HANDLE.");
/*  806 */         this.debug.flush();
/*      */       }
/*      */ 
/*  809 */       byte[] handle = tr.readByteString();
/*  810 */       return handle;
/*      */     }
/*      */ 
/*  813 */     if (t != 101) {
/*  814 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/*  816 */     int errorCode = tr.readUINT32();
/*  817 */     String errorMessage = tr.readString();
/*      */ 
/*  819 */     throw new SFTPException(errorMessage, errorCode);
/*      */   }
/*      */ 
/*      */   private final String expandString(byte[] b, int off, int len)
/*      */   {
/*  824 */     StringBuffer sb = new StringBuffer();
/*      */ 
/*  826 */     for (int i = 0; i < len; i++)
/*      */     {
/*  828 */       int c = b[(off + i)] & 0xFF;
/*      */ 
/*  830 */       if ((c >= 32) && (c <= 126))
/*      */       {
/*  832 */         sb.append((char)c);
/*      */       }
/*      */       else
/*      */       {
/*  836 */         sb.append("{0x" + Integer.toHexString(c) + "}");
/*      */       }
/*      */     }
/*      */ 
/*  840 */     return sb.toString();
/*      */   }
/*      */ 
/*      */   private void init()
/*      */     throws IOException
/*      */   {
/*  847 */     int client_version = 3;
/*      */ 
/*  849 */     if (this.debug != null) {
/*  850 */       this.debug.println("Sending SSH_FXP_INIT (3)...");
/*      */     }
/*  852 */     TypesWriter tw = new TypesWriter();
/*  853 */     tw.writeUINT32(3);
/*  854 */     sendMessage(1, 0, tw.getBytes());
/*      */ 
/*  858 */     if (this.debug != null) {
/*  859 */       this.debug.println("Waiting for SSH_FXP_VERSION...");
/*      */     }
/*  861 */     TypesReader tr = new TypesReader(receiveMessage(34000));
/*      */ 
/*  863 */     int type = tr.readByte();
/*      */ 
/*  865 */     if (type != 2)
/*      */     {
/*  867 */       throw new IOException("The server did not send a SSH_FXP_VERSION packet (got " + type + ")");
/*      */     }
/*      */ 
/*  870 */     this.protocol_version = tr.readUINT32();
/*      */ 
/*  872 */     if (this.debug != null) {
/*  873 */       this.debug.println("SSH_FXP_VERSION: protocol_version = " + this.protocol_version);
/*      */     }
/*  875 */     if (this.protocol_version != 3) {
/*  876 */       throw new IOException("Server version " + this.protocol_version + " is currently not supported");
/*      */     }
/*      */ 
/*  880 */     while (tr.remain() != 0)
/*      */     {
/*  882 */       String name = tr.readString();
/*  883 */       byte[] value = tr.readByteString();
/*  884 */       this.server_extensions.put(name, value);
/*      */ 
/*  886 */       if (this.debug != null)
/*  887 */         this.debug.println("SSH_FXP_VERSION: extension: " + name + " = '" + expandString(value, 0, value.length) + 
/*  888 */           "'");
/*      */     }
/*      */   }
/*      */ 
/*      */   public int getProtocolVersion()
/*      */   {
/*  900 */     return this.protocol_version;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */   {
/*  914 */     this.sess.close();
/*      */   }
/*      */ 
/*      */   public Vector ls(String dirName)
/*      */     throws IOException
/*      */   {
/*  926 */     byte[] handle = openDirectory(dirName);
/*  927 */     Vector result = scanDirectory(handle);
/*  928 */     closeHandle(handle);
/*  929 */     return result;
/*      */   }
/*      */ 
/*      */   public void mkdir(String dirName, int posixPermissions)
/*      */     throws IOException
/*      */   {
/*  942 */     int req_id = generateNextRequestID();
/*      */ 
/*  944 */     TypesWriter tw = new TypesWriter();
/*  945 */     tw.writeString(dirName, this.charsetName);
/*  946 */     tw.writeUINT32(4);
/*  947 */     tw.writeUINT32(posixPermissions);
/*      */ 
/*  949 */     sendMessage(14, req_id, tw.getBytes());
/*      */ 
/*  951 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public void rm(String fileName)
/*      */     throws IOException
/*      */   {
/*  962 */     int req_id = generateNextRequestID();
/*      */ 
/*  964 */     TypesWriter tw = new TypesWriter();
/*  965 */     tw.writeString(fileName, this.charsetName);
/*      */ 
/*  967 */     sendMessage(13, req_id, tw.getBytes());
/*      */ 
/*  969 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public void rmdir(String dirName)
/*      */     throws IOException
/*      */   {
/*  980 */     int req_id = generateNextRequestID();
/*      */ 
/*  982 */     TypesWriter tw = new TypesWriter();
/*  983 */     tw.writeString(dirName, this.charsetName);
/*      */ 
/*  985 */     sendMessage(15, req_id, tw.getBytes());
/*      */ 
/*  987 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public void mv(String oldPath, String newPath)
/*      */     throws IOException
/*      */   {
/*  999 */     int req_id = generateNextRequestID();
/*      */ 
/* 1001 */     TypesWriter tw = new TypesWriter();
/* 1002 */     tw.writeString(oldPath, this.charsetName);
/* 1003 */     tw.writeString(newPath, this.charsetName);
/*      */ 
/* 1005 */     sendMessage(18, req_id, tw.getBytes());
/*      */ 
/* 1007 */     expectStatusOKMessage(req_id);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle openFileRO(String fileName)
/*      */     throws IOException
/*      */   {
/* 1019 */     return openFile(fileName, 1, null);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle openFileRW(String fileName)
/*      */     throws IOException
/*      */   {
/* 1031 */     return openFile(fileName, 3, null);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle createFile(String fileName)
/*      */     throws IOException
/*      */   {
/* 1051 */     return createFile(fileName, null);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle createFile(String fileName, SFTPv3FileAttributes attr)
/*      */     throws IOException
/*      */   {
/* 1070 */     return openFile(fileName, 11, attr);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle createFileTruncate(String fileName)
/*      */     throws IOException
/*      */   {
/* 1083 */     return createFileTruncate(fileName, null);
/*      */   }
/*      */ 
/*      */   public SFTPv3FileHandle createFileTruncate(String fileName, SFTPv3FileAttributes attr)
/*      */     throws IOException
/*      */   {
/* 1102 */     return openFile(fileName, 27, attr);
/*      */   }
/*      */ 
/*      */   private byte[] createAttrs(SFTPv3FileAttributes attr)
/*      */   {
/* 1107 */     TypesWriter tw = new TypesWriter();
/*      */ 
/* 1109 */     int attrFlags = 0;
/*      */ 
/* 1111 */     if (attr == null)
/*      */     {
/* 1113 */       tw.writeUINT32(0);
/*      */     }
/*      */     else
/*      */     {
/* 1117 */       if (attr.size != null) {
/* 1118 */         attrFlags |= 1;
/*      */       }
/* 1120 */       if ((attr.uid != null) && (attr.gid != null)) {
/* 1121 */         attrFlags |= 2;
/*      */       }
/* 1123 */       if (attr.permissions != null) {
/* 1124 */         attrFlags |= 4;
/*      */       }
/* 1126 */       if ((attr.atime != null) && (attr.mtime != null)) {
/* 1127 */         attrFlags |= 8;
/*      */       }
/* 1129 */       tw.writeUINT32(attrFlags);
/*      */ 
/* 1131 */       if (attr.size != null) {
/* 1132 */         tw.writeUINT64(attr.size.longValue());
/*      */       }
/* 1134 */       if ((attr.uid != null) && (attr.gid != null))
/*      */       {
/* 1136 */         tw.writeUINT32(attr.uid.intValue());
/* 1137 */         tw.writeUINT32(attr.gid.intValue());
/*      */       }
/*      */ 
/* 1140 */       if (attr.permissions != null) {
/* 1141 */         tw.writeUINT32(attr.permissions.intValue());
/*      */       }
/* 1143 */       if ((attr.atime != null) && (attr.mtime != null))
/*      */       {
/* 1145 */         tw.writeUINT32(attr.atime.intValue());
/* 1146 */         tw.writeUINT32(attr.mtime.intValue());
/*      */       }
/*      */     }
/*      */ 
/* 1150 */     return tw.getBytes();
/*      */   }
/*      */ 
/*      */   private SFTPv3FileHandle openFile(String fileName, int flags, SFTPv3FileAttributes attr) throws IOException
/*      */   {
/* 1155 */     int req_id = generateNextRequestID();
/*      */ 
/* 1157 */     TypesWriter tw = new TypesWriter();
/* 1158 */     tw.writeString(fileName, this.charsetName);
/* 1159 */     tw.writeUINT32(flags);
/* 1160 */     tw.writeBytes(createAttrs(attr));
/*      */ 
/* 1162 */     if (this.debug != null)
/*      */     {
/* 1164 */       this.debug.println("Sending SSH_FXP_OPEN...");
/* 1165 */       this.debug.flush();
/*      */     }
/*      */ 
/* 1168 */     sendMessage(3, req_id, tw.getBytes());
/*      */ 
/* 1170 */     byte[] resp = receiveMessage(34000);
/*      */ 
/* 1172 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/* 1174 */     int t = tr.readByte();
/*      */ 
/* 1176 */     int rep_id = tr.readUINT32();
/* 1177 */     if (rep_id != req_id) {
/* 1178 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/* 1180 */     if (t == 102)
/*      */     {
/* 1182 */       if (this.debug != null)
/*      */       {
/* 1184 */         this.debug.println("Got SSH_FXP_HANDLE.");
/* 1185 */         this.debug.flush();
/*      */       }
/*      */ 
/* 1188 */       return new SFTPv3FileHandle(this, tr.readByteString());
/*      */     }
/*      */ 
/* 1191 */     if (t != 101) {
/* 1192 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/* 1194 */     int errorCode = tr.readUINT32();
/* 1195 */     String errorMessage = tr.readString();
/*      */ 
/* 1197 */     throw new SFTPException(errorMessage, errorCode);
/*      */   }
/*      */ 
/*      */   public int read(SFTPv3FileHandle handle, long fileOffset, byte[] dst, int dstoff, int len)
/*      */     throws IOException
/*      */   {
/* 1225 */     checkHandleValidAndOpen(handle);
/*      */ 
/* 1227 */     if ((len > 32768) || (len <= 0)) {
/* 1228 */       throw new IllegalArgumentException("invalid len argument");
/*      */     }
/* 1230 */     int req_id = generateNextRequestID();
/*      */ 
/* 1232 */     TypesWriter tw = new TypesWriter();
/* 1233 */     tw.writeString(handle.fileHandle, 0, handle.fileHandle.length);
/* 1234 */     tw.writeUINT64(fileOffset);
/* 1235 */     tw.writeUINT32(len);
/*      */ 
/* 1237 */     if (this.debug != null)
/*      */     {
/* 1239 */       this.debug.println("Sending SSH_FXP_READ...");
/* 1240 */       this.debug.flush();
/*      */     }
/*      */ 
/* 1243 */     sendMessage(5, req_id, tw.getBytes());
/*      */ 
/* 1245 */     byte[] resp = receiveMessage(34000);
/*      */ 
/* 1247 */     TypesReader tr = new TypesReader(resp);
/*      */ 
/* 1249 */     int t = tr.readByte();
/*      */ 
/* 1251 */     int rep_id = tr.readUINT32();
/* 1252 */     if (rep_id != req_id) {
/* 1253 */       throw new IOException("The server sent an invalid id field.");
/*      */     }
/* 1255 */     if (t == 103)
/*      */     {
/* 1257 */       if (this.debug != null)
/*      */       {
/* 1259 */         this.debug.println("Got SSH_FXP_DATA...");
/* 1260 */         this.debug.flush();
/*      */       }
/*      */ 
/* 1263 */       int readLen = tr.readUINT32();
/*      */ 
/* 1265 */       if ((readLen < 0) || (readLen > len)) {
/* 1266 */         throw new IOException("The server sent an invalid length field.");
/*      */       }
/* 1268 */       tr.readBytes(dst, dstoff, readLen);
/*      */ 
/* 1270 */       return readLen;
/*      */     }
/*      */ 
/* 1273 */     if (t != 101) {
/* 1274 */       throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */     }
/* 1276 */     int errorCode = tr.readUINT32();
/*      */ 
/* 1278 */     if (errorCode == 1)
/*      */     {
/* 1280 */       if (this.debug != null)
/*      */       {
/* 1282 */         this.debug.println("Got SSH_FX_EOF.");
/* 1283 */         this.debug.flush();
/*      */       }
/*      */ 
/* 1286 */       return -1;
/*      */     }
/*      */ 
/* 1289 */     String errorMessage = tr.readString();
/*      */ 
/* 1291 */     throw new SFTPException(errorMessage, errorCode);
/*      */   }
/*      */ 
/*      */   public void write(SFTPv3FileHandle handle, long fileOffset, byte[] src, int srcoff, int len)
/*      */     throws IOException
/*      */   {
/* 1307 */     checkHandleValidAndOpen(handle);
/*      */ 
/* 1309 */     if (len < 0)
/*      */     {
/* 1311 */       while (len > 0)
/*      */       {
/* 1313 */         int writeRequestLen = len;
/*      */ 
/* 1315 */         if (writeRequestLen > 32768) {
/* 1316 */           writeRequestLen = 32768;
/*      */         }
/* 1318 */         int req_id = generateNextRequestID();
/*      */ 
/* 1320 */         TypesWriter tw = new TypesWriter();
/* 1321 */         tw.writeString(handle.fileHandle, 0, handle.fileHandle.length);
/* 1322 */         tw.writeUINT64(fileOffset);
/* 1323 */         tw.writeString(src, srcoff, writeRequestLen);
/*      */ 
/* 1325 */         if (this.debug != null)
/*      */         {
/* 1327 */           this.debug.println("Sending SSH_FXP_WRITE...");
/* 1328 */           this.debug.flush();
/*      */         }
/*      */ 
/* 1331 */         sendMessage(6, req_id, tw.getBytes());
/*      */ 
/* 1333 */         fileOffset += writeRequestLen;
/*      */ 
/* 1335 */         srcoff += writeRequestLen;
/* 1336 */         len -= writeRequestLen;
/*      */ 
/* 1338 */         byte[] resp = receiveMessage(34000);
/*      */ 
/* 1340 */         TypesReader tr = new TypesReader(resp);
/*      */ 
/* 1342 */         int t = tr.readByte();
/*      */ 
/* 1344 */         int rep_id = tr.readUINT32();
/* 1345 */         if (rep_id != req_id) {
/* 1346 */           throw new IOException("The server sent an invalid id field.");
/*      */         }
/* 1348 */         if (t != 101) {
/* 1349 */           throw new IOException("The SFTP server sent an unexpected packet type (" + t + ")");
/*      */         }
/* 1351 */         int errorCode = tr.readUINT32();
/*      */ 
/* 1353 */         if (errorCode == 0) {
/*      */           continue;
/*      */         }
/* 1356 */         String errorMessage = tr.readString();
/*      */ 
/* 1358 */         throw new SFTPException(errorMessage, errorCode);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void closeFile(SFTPv3FileHandle handle)
/*      */     throws IOException
/*      */   {
/* 1370 */     if (handle == null) {
/* 1371 */       throw new IllegalArgumentException("the handle argument may not be null");
/*      */     }
/*      */     try
/*      */     {
/* 1375 */       if (!handle.isClosed)
/*      */       {
/* 1377 */         closeHandle(handle.fileHandle);
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1382 */       handle.isClosed = true;
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SFTPv3Client
 * JD-Core Version:    0.6.0
 */