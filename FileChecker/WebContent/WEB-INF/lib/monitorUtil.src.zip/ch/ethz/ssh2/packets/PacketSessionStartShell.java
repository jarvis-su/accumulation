/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketSessionStartShell
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public boolean wantReply;
/*    */ 
/*    */   public PacketSessionStartShell(int recipientChannelID, boolean wantReply)
/*    */   {
/* 19 */     this.recipientChannelID = recipientChannelID;
/* 20 */     this.wantReply = wantReply;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 25 */     if (this.payload == null)
/*    */     {
/* 27 */       TypesWriter tw = new TypesWriter();
/* 28 */       tw.writeByte(98);
/* 29 */       tw.writeUINT32(this.recipientChannelID);
/* 30 */       tw.writeString("shell");
/* 31 */       tw.writeBoolean(this.wantReply);
/* 32 */       this.payload = tw.getBytes();
/*    */     }
/* 34 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketSessionStartShell
 * JD-Core Version:    0.6.0
 */