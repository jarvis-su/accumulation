/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketSessionPtyRequest
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public boolean wantReply;
/*    */   public String term;
/*    */   public int character_width;
/*    */   public int character_height;
/*    */   public int pixel_width;
/*    */   public int pixel_height;
/*    */   public byte[] terminal_modes;
/*    */ 
/*    */   public PacketSessionPtyRequest(int recipientChannelID, boolean wantReply, String term, int character_width, int character_height, int pixel_width, int pixel_height, byte[] terminal_modes)
/*    */   {
/* 27 */     this.recipientChannelID = recipientChannelID;
/* 28 */     this.wantReply = wantReply;
/* 29 */     this.term = term;
/* 30 */     this.character_width = character_width;
/* 31 */     this.character_height = character_height;
/* 32 */     this.pixel_width = pixel_width;
/* 33 */     this.pixel_height = pixel_height;
/* 34 */     this.terminal_modes = terminal_modes;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 39 */     if (this.payload == null)
/*    */     {
/* 41 */       TypesWriter tw = new TypesWriter();
/* 42 */       tw.writeByte(98);
/* 43 */       tw.writeUINT32(this.recipientChannelID);
/* 44 */       tw.writeString("pty-req");
/* 45 */       tw.writeBoolean(this.wantReply);
/* 46 */       tw.writeString(this.term);
/* 47 */       tw.writeUINT32(this.character_width);
/* 48 */       tw.writeUINT32(this.character_height);
/* 49 */       tw.writeUINT32(this.pixel_width);
/* 50 */       tw.writeUINT32(this.pixel_height);
/* 51 */       tw.writeString(this.terminal_modes, 0, this.terminal_modes.length);
/*    */ 
/* 53 */       this.payload = tw.getBytes();
/*    */     }
/* 55 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketSessionPtyRequest
 * JD-Core Version:    0.6.0
 */