package ch.ethz.ssh2.crypto.digest;

public abstract interface Digest
{
  public abstract int getDigestLength();

  public abstract void update(byte paramByte);

  public abstract void update(byte[] paramArrayOfByte);

  public abstract void update(byte[] paramArrayOfByte, int paramInt1, int paramInt2);

  public abstract void reset();

  public abstract void digest(byte[] paramArrayOfByte);

  public abstract void digest(byte[] paramArrayOfByte, int paramInt);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.Digest
 * JD-Core Version:    0.6.0
 */