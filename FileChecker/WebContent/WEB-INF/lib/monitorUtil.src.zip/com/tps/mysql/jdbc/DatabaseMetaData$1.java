/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ class DatabaseMetaData$1 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$table;
/*      */   private final Statement val$stmt;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 1015 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 1018 */       StringBuffer queryBuf = new StringBuffer("SHOW COLUMNS FROM ");
/*      */ 
/* 1020 */       queryBuf.append(this.this$0.quotedId);
/* 1021 */       queryBuf.append(this.val$table);
/* 1022 */       queryBuf.append(this.this$0.quotedId);
/* 1023 */       queryBuf.append(" FROM ");
/* 1024 */       queryBuf.append(this.this$0.quotedId);
/* 1025 */       queryBuf.append(catalogStr.toString());
/* 1026 */       queryBuf.append(this.this$0.quotedId);
/*      */ 
/* 1028 */       results = this.val$stmt.executeQuery(queryBuf.toString());
/*      */ 
/* 1030 */       while (results.next()) {
/* 1031 */         String keyType = results.getString("Key");
/*      */ 
/* 1033 */         if ((keyType != null) && 
/* 1034 */           (StringUtils.startsWithIgnoreCase(keyType, "PRI")))
/*      */         {
/* 1036 */           byte[][] rowVal = new byte[8][];
/* 1037 */           rowVal[0] = Integer.toString(2).getBytes();
/*      */ 
/* 1041 */           rowVal[1] = results.getBytes("Field");
/*      */ 
/* 1043 */           String type = results.getString("Type");
/* 1044 */           int size = MysqlIO.getMaxBuf();
/* 1045 */           int decimals = 0;
/*      */ 
/* 1050 */           if (type.indexOf("enum") != -1) {
/* 1051 */             String temp = type.substring(type.indexOf("("), type.indexOf(")"));
/*      */ 
/* 1054 */             StringTokenizer tokenizer = new StringTokenizer(temp, ",");
/*      */ 
/* 1056 */             int maxLength = 0;
/*      */ 
/* 1058 */             while (tokenizer.hasMoreTokens()) {
/* 1059 */               maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
/*      */             }
/*      */ 
/* 1064 */             size = maxLength;
/* 1065 */             decimals = 0;
/* 1066 */             type = "enum";
/* 1067 */           } else if (type.indexOf("(") != -1) {
/* 1068 */             if (type.indexOf(",") != -1) {
/* 1069 */               size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
/*      */ 
/* 1073 */               decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
/*      */             }
/*      */             else
/*      */             {
/* 1078 */               size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
/*      */             }
/*      */ 
/* 1084 */             type = type.substring(0, type.indexOf("("));
/*      */           }
/*      */ 
/* 1088 */           rowVal[2] = DatabaseMetaData.access$000(this.this$0, String.valueOf(MysqlDefs.mysqlToJavaType(type)));
/*      */ 
/* 1090 */           rowVal[3] = DatabaseMetaData.access$000(this.this$0, type);
/* 1091 */           rowVal[4] = Integer.toString(size + decimals).getBytes();
/*      */ 
/* 1093 */           rowVal[5] = Integer.toString(size + decimals).getBytes();
/*      */ 
/* 1095 */           rowVal[6] = Integer.toString(decimals).getBytes();
/*      */ 
/* 1097 */           rowVal[7] = Integer.toString(1).getBytes();
/*      */ 
/* 1102 */           this.val$rows.add(rowVal);
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 1108 */       if (results != null) {
/*      */         try {
/* 1110 */           results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 1115 */         results = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.1
 * JD-Core Version:    0.6.0
 */