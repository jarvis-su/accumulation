/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class ExtFileAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = -5385811450132382731L;
/*    */   private static final String FILENAME = "FILENAME";
/*    */ 
/*    */   public ExtFileAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ExtFileAlert(HashMap map)
/*    */   {
/* 18 */     setData(map);
/*    */   }
/*    */ 
/*    */   public ExtFileAlert(String code, String description, String filename) {
/* 22 */     super(code, description);
/* 23 */     setData("FILENAME", filename);
/*    */   }
/*    */ 
/*    */   public String getFilename() {
/* 27 */     String filename = "";
/* 28 */     if (getData("FILENAME") != null) {
/* 29 */       filename = (String)getData("FILENAME");
/*    */     }
/* 31 */     return filename;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return super.toString() + 
/* 36 */       "  Filename" + getFilename() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.ExtFileAlert
 * JD-Core Version:    0.6.0
 */