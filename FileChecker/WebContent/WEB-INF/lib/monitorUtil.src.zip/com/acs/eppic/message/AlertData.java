/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class AlertData extends MessageData
/*    */ {
/*    */   private static final long serialVersionUID = -2102676152156664945L;
/*    */   public static final String CODE = "CODE";
/*    */   public static final String DESCRIPTION = "DESCRIPTION";
/*    */ 
/*    */   public AlertData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AlertData(HashMap map)
/*    */   {
/* 20 */     setData(map);
/*    */   }
/*    */ 
/*    */   public AlertData(String code, String description)
/*    */   {
/* 25 */     setData("CODE", code);
/* 26 */     setData("DESCRIPTION", description);
/*    */   }
/*    */ 
/*    */   public String getCode() {
/* 30 */     String code = "";
/* 31 */     if (getData("CODE") != null) {
/* 32 */       code = (String)getData("CODE");
/*    */     }
/* 34 */     return code;
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 38 */     String descr = "";
/* 39 */     if (getData("DESCRIPTION") != null) {
/* 40 */       descr = (String)getData("DESCRIPTION");
/*    */     }
/* 42 */     return descr;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 46 */     return "  Code: " + getCode() + "\n" + 
/* 47 */       "  Description: " + getDescription() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.AlertData
 * JD-Core Version:    0.6.0
 */