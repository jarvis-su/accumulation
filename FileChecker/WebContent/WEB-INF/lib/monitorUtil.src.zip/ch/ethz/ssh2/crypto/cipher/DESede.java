/*    */ package ch.ethz.ssh2.crypto.cipher;
/*    */ 
/*    */ public class DESede extends DES
/*    */ {
/* 39 */   private int[] key1 = null;
/* 40 */   private int[] key2 = null;
/* 41 */   private int[] key3 = null;
/*    */   private boolean encrypt;
/*    */ 
/*    */   public void init(boolean encrypting, byte[] key)
/*    */   {
/* 64 */     this.key1 = generateWorkingKey(encrypting, key, 0);
/* 65 */     this.key2 = generateWorkingKey(!encrypting, key, 8);
/* 66 */     this.key3 = generateWorkingKey(encrypting, key, 16);
/*    */ 
/* 68 */     this.encrypt = encrypting;
/*    */   }
/*    */ 
/*    */   public String getAlgorithmName()
/*    */   {
/* 73 */     return "DESede";
/*    */   }
/*    */ 
/*    */   public int getBlockSize()
/*    */   {
/* 78 */     return 8;
/*    */   }
/*    */ 
/*    */   public void transformBlock(byte[] in, int inOff, byte[] out, int outOff)
/*    */   {
/* 83 */     if (this.key1 == null)
/*    */     {
/* 85 */       throw new IllegalStateException("DESede engine not initialised!");
/*    */     }
/*    */ 
/* 88 */     if (this.encrypt)
/*    */     {
/* 90 */       desFunc(this.key1, in, inOff, out, outOff);
/* 91 */       desFunc(this.key2, out, outOff, out, outOff);
/* 92 */       desFunc(this.key3, out, outOff, out, outOff);
/*    */     }
/*    */     else
/*    */     {
/* 96 */       desFunc(this.key3, in, inOff, out, outOff);
/* 97 */       desFunc(this.key2, out, outOff, out, outOff);
/* 98 */       desFunc(this.key1, out, outOff, out, outOff);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void reset()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.DESede
 * JD-Core Version:    0.6.0
 */