/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.math.BigDecimal;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ public class StringUtils
/*      */ {
/*      */   private static final int BYTE_RANGE = 256;
/*   49 */   private static byte[] allBytes = new byte[256];
/*      */ 
/*   51 */   private static char[] byteToChars = new char[256];
/*      */   private static Method toPlainStringMethod;
/*      */   static final int WILD_COMPARE_MATCH_NO_WILD = 0;
/*      */   static final int WILD_COMPARE_MATCH_WITH_WILD = 1;
/*      */   static final int WILD_COMPARE_NO_MATCH = -1;
/*      */ 
/*      */   public static String consistentToString(BigDecimal decimal)
/*      */   {
/*   94 */     if (decimal == null) {
/*   95 */       return null;
/*      */     }
/*      */ 
/*   98 */     if (toPlainStringMethod != null)
/*      */       try {
/*  100 */         return (String)toPlainStringMethod.invoke(decimal, null);
/*      */       }
/*      */       catch (InvocationTargetException invokeEx)
/*      */       {
/*      */       }
/*      */       catch (IllegalAccessException accessEx)
/*      */       {
/*      */       }
/*  108 */     return decimal.toString();
/*      */   }
/*      */ 
/*      */   public static final String dumpAsHex(byte[] byteBuffer, int length)
/*      */   {
/*  122 */     StringBuffer outputBuf = new StringBuffer(length * 4);
/*      */ 
/*  124 */     int p = 0;
/*  125 */     int rows = length / 8;
/*      */ 
/*  127 */     for (int i = 0; (i < rows) && (p < length); i++) {
/*  128 */       int ptemp = p;
/*      */ 
/*  130 */       for (int j = 0; j < 8; j++) {
/*  131 */         String hexVal = Integer.toHexString(byteBuffer[ptemp] & 0xFF);
/*      */ 
/*  133 */         if (hexVal.length() == 1) {
/*  134 */           hexVal = "0" + hexVal;
/*      */         }
/*      */ 
/*  137 */         outputBuf.append(hexVal + " ");
/*  138 */         ptemp++;
/*      */       }
/*      */ 
/*  141 */       outputBuf.append("    ");
/*      */ 
/*  143 */       for (int j = 0; j < 8; j++) {
/*  144 */         if ((byteBuffer[p] > 32) && (byteBuffer[p] < 127))
/*  145 */           outputBuf.append((char)byteBuffer[p] + " ");
/*      */         else {
/*  147 */           outputBuf.append(". ");
/*      */         }
/*      */ 
/*  150 */         p++;
/*      */       }
/*      */ 
/*  153 */       outputBuf.append("\n");
/*      */     }
/*      */ 
/*  156 */     int n = 0;
/*      */ 
/*  158 */     for (int i = p; i < length; i++) {
/*  159 */       String hexVal = Integer.toHexString(byteBuffer[i] & 0xFF);
/*      */ 
/*  161 */       if (hexVal.length() == 1) {
/*  162 */         hexVal = "0" + hexVal;
/*      */       }
/*      */ 
/*  165 */       outputBuf.append(hexVal + " ");
/*  166 */       n++;
/*      */     }
/*      */ 
/*  169 */     for (int i = n; i < 8; i++) {
/*  170 */       outputBuf.append("   ");
/*      */     }
/*      */ 
/*  173 */     outputBuf.append("    ");
/*      */ 
/*  175 */     for (int i = p; i < length; i++) {
/*  176 */       if ((byteBuffer[i] > 32) && (byteBuffer[i] < 127))
/*  177 */         outputBuf.append((char)byteBuffer[i] + " ");
/*      */       else {
/*  179 */         outputBuf.append(". ");
/*      */       }
/*      */     }
/*      */ 
/*  183 */     outputBuf.append("\n");
/*      */ 
/*  185 */     return outputBuf.toString();
/*      */   }
/*      */ 
/*      */   private static boolean endsWith(byte[] dataFrom, String suffix) {
/*  189 */     for (int i = 1; i <= suffix.length(); i++) {
/*  190 */       int dfOffset = dataFrom.length - i;
/*  191 */       int suffixOffset = suffix.length() - i;
/*  192 */       if (dataFrom[dfOffset] != suffix.charAt(suffixOffset)) {
/*  193 */         return false;
/*      */       }
/*      */     }
/*  196 */     return true;
/*      */   }
/*      */ 
/*      */   public static byte[] escapeEasternUnicodeByteStream(byte[] origBytes, String origString, int offset, int length)
/*      */   {
/*  216 */     if ((origBytes == null) || (origBytes.length == 0)) {
/*  217 */       return origBytes;
/*      */     }
/*      */ 
/*  220 */     int bytesLen = origBytes.length;
/*  221 */     int bufIndex = 0;
/*  222 */     int strIndex = 0;
/*      */ 
/*  224 */     ByteArrayOutputStream bytesOut = new ByteArrayOutputStream(bytesLen);
/*      */     while (true)
/*      */     {
/*  227 */       if (origString.charAt(strIndex) == '\\')
/*      */       {
/*  229 */         bytesOut.write(origBytes[(bufIndex++)]);
/*      */       }
/*      */       else
/*      */       {
/*  234 */         int loByte = origBytes[bufIndex];
/*      */ 
/*  236 */         if (loByte < 0) {
/*  237 */           loByte += 256;
/*      */         }
/*      */ 
/*  241 */         bytesOut.write(loByte);
/*      */ 
/*  259 */         if (loByte >= 128) {
/*  260 */           if (bufIndex < bytesLen - 1) {
/*  261 */             int hiByte = origBytes[(bufIndex + 1)];
/*      */ 
/*  263 */             if (hiByte < 0) {
/*  264 */               hiByte += 256;
/*      */             }
/*      */ 
/*  269 */             bytesOut.write(hiByte);
/*  270 */             bufIndex++;
/*      */ 
/*  273 */             if (hiByte == 92)
/*  274 */               bytesOut.write(hiByte);
/*      */           }
/*      */         }
/*  277 */         else if ((loByte == 92) && 
/*  278 */           (bufIndex < bytesLen - 1)) {
/*  279 */           int hiByte = origBytes[(bufIndex + 1)];
/*      */ 
/*  281 */           if (hiByte < 0) {
/*  282 */             hiByte += 256;
/*      */           }
/*      */ 
/*  285 */           if (hiByte == 98)
/*      */           {
/*  287 */             bytesOut.write(92);
/*  288 */             bytesOut.write(98);
/*  289 */             bufIndex++;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  294 */         bufIndex++;
/*      */       }
/*      */ 
/*  297 */       if (bufIndex >= bytesLen)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  302 */       strIndex++;
/*      */     }
/*      */ 
/*  305 */     return bytesOut.toByteArray();
/*      */   }
/*      */ 
/*      */   public static char firstNonWsCharUc(String searchIn)
/*      */   {
/*  317 */     if (searchIn == null) {
/*  318 */       return '\000';
/*      */     }
/*      */ 
/*  321 */     int length = searchIn.length();
/*      */ 
/*  323 */     for (int i = 0; i < length; i++) {
/*  324 */       char c = searchIn.charAt(i);
/*      */ 
/*  326 */       if (!Character.isWhitespace(c)) {
/*  327 */         return Character.toUpperCase(c);
/*      */       }
/*      */     }
/*      */ 
/*  331 */     return '\000';
/*      */   }
/*      */ 
/*      */   public static final String fixDecimalExponent(String dString)
/*      */   {
/*  344 */     int ePos = dString.indexOf("E");
/*      */ 
/*  346 */     if (ePos == -1) {
/*  347 */       ePos = dString.indexOf("e");
/*      */     }
/*      */ 
/*  350 */     if ((ePos != -1) && 
/*  351 */       (dString.length() > ePos + 1)) {
/*  352 */       char maybeMinusChar = dString.charAt(ePos + 1);
/*      */ 
/*  354 */       if ((maybeMinusChar != '-') && (maybeMinusChar != '+')) {
/*  355 */         StringBuffer buf = new StringBuffer(dString.length() + 1);
/*  356 */         buf.append(dString.substring(0, ePos + 1));
/*  357 */         buf.append('+');
/*  358 */         buf.append(dString.substring(ePos + 1, dString.length()));
/*  359 */         dString = buf.toString();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  364 */     return dString;
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  372 */       byte[] b = null;
/*      */ 
/*  374 */       if (converter != null) {
/*  375 */         b = converter.toBytes(c);
/*  376 */       } else if (encoding == null) {
/*  377 */         b = new String(c).getBytes();
/*      */       } else {
/*  379 */         String s = new String(c);
/*      */ 
/*  381 */         b = s.getBytes(encoding);
/*      */ 
/*  383 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*  387 */           if (!encoding.equalsIgnoreCase(serverEncoding)) {
/*  388 */             b = escapeEasternUnicodeByteStream(b, s, 0, s.length());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  393 */       return b; } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  395 */     throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009");
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(char[] c, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  406 */       byte[] b = null;
/*      */ 
/*  408 */       if (converter != null) {
/*  409 */         b = converter.toBytes(c, offset, length);
/*  410 */       } else if (encoding == null) {
/*  411 */         byte[] temp = new String(c, offset, length).getBytes();
/*      */ 
/*  413 */         length = temp.length;
/*      */ 
/*  415 */         b = new byte[length];
/*  416 */         System.arraycopy(temp, 0, b, 0, length);
/*      */       } else {
/*  418 */         String s = new String(c, offset, length);
/*      */ 
/*  420 */         byte[] temp = s.getBytes(encoding);
/*      */ 
/*  422 */         length = temp.length;
/*      */ 
/*  424 */         b = new byte[length];
/*  425 */         System.arraycopy(temp, 0, b, 0, length);
/*      */ 
/*  427 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*  431 */           if (!encoding.equalsIgnoreCase(serverEncoding)) {
/*  432 */             b = escapeEasternUnicodeByteStream(b, s, offset, length);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  437 */       return b; } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  439 */     throw SQLError.createSQLException(Messages.getString("StringUtils.10") + encoding + Messages.getString("StringUtils.11"), "S1009");
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(char[] c, String encoding, String serverEncoding, boolean parserKnowsUnicode, Connection conn)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  450 */       SingleByteCharsetConverter converter = null;
/*      */ 
/*  452 */       if (conn != null)
/*  453 */         converter = conn.getCharsetConverter(encoding);
/*      */       else {
/*  455 */         converter = SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       }
/*      */ 
/*  458 */       return getBytes(c, converter, encoding, serverEncoding, parserKnowsUnicode);
/*      */     } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  461 */     throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009");
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, boolean parserKnowsUnicode)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  492 */       byte[] b = null;
/*      */ 
/*  494 */       if (converter != null) {
/*  495 */         b = converter.toBytes(s);
/*  496 */       } else if (encoding == null) {
/*  497 */         b = s.getBytes();
/*      */       } else {
/*  499 */         b = s.getBytes(encoding);
/*      */ 
/*  501 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*  505 */           if (!encoding.equalsIgnoreCase(serverEncoding)) {
/*  506 */             b = escapeEasternUnicodeByteStream(b, s, 0, s.length());
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  511 */       return b; } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  513 */     throw SQLError.createSQLException(Messages.getString("StringUtils.5") + encoding + Messages.getString("StringUtils.6"), "S1009");
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(String s, SingleByteCharsetConverter converter, String encoding, String serverEncoding, int offset, int length, boolean parserKnowsUnicode)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  547 */       byte[] b = null;
/*      */ 
/*  549 */       if (converter != null) {
/*  550 */         b = converter.toBytes(s, offset, length);
/*  551 */       } else if (encoding == null) {
/*  552 */         byte[] temp = s.substring(offset, offset + length).getBytes();
/*      */ 
/*  554 */         length = temp.length;
/*      */ 
/*  556 */         b = new byte[length];
/*  557 */         System.arraycopy(temp, 0, b, 0, length);
/*      */       }
/*      */       else {
/*  560 */         byte[] temp = s.substring(offset, offset + length).getBytes(encoding);
/*      */ 
/*  563 */         length = temp.length;
/*      */ 
/*  565 */         b = new byte[length];
/*  566 */         System.arraycopy(temp, 0, b, 0, length);
/*      */ 
/*  568 */         if ((!parserKnowsUnicode) && ((encoding.equalsIgnoreCase("SJIS")) || (encoding.equalsIgnoreCase("BIG5")) || (encoding.equalsIgnoreCase("GBK"))))
/*      */         {
/*  572 */           if (!encoding.equalsIgnoreCase(serverEncoding)) {
/*  573 */             b = escapeEasternUnicodeByteStream(b, s, offset, length);
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  578 */       return b; } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  580 */     throw SQLError.createSQLException(Messages.getString("StringUtils.10") + encoding + Messages.getString("StringUtils.11"), "S1009");
/*      */   }
/*      */ 
/*      */   public static final byte[] getBytes(String s, String encoding, String serverEncoding, boolean parserKnowsUnicode, Connection conn)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  606 */       SingleByteCharsetConverter converter = null;
/*      */ 
/*  608 */       if (conn != null)
/*  609 */         converter = conn.getCharsetConverter(encoding);
/*      */       else {
/*  611 */         converter = SingleByteCharsetConverter.getInstance(encoding, null);
/*      */       }
/*      */ 
/*  614 */       return getBytes(s, converter, encoding, serverEncoding, parserKnowsUnicode);
/*      */     } catch (UnsupportedEncodingException uee) {
/*      */     }
/*  617 */     throw SQLError.createSQLException(Messages.getString("StringUtils.0") + encoding + Messages.getString("StringUtils.1"), "S1009");
/*      */   }
/*      */ 
/*      */   public static int getInt(byte[] buf)
/*      */     throws NumberFormatException
/*      */   {
/*  624 */     int base = 10;
/*      */ 
/*  626 */     int s = 0;
/*      */ 
/*  629 */     while ((Character.isWhitespace((char)buf[s])) && (s < buf.length)) {
/*  630 */       s++;
/*      */     }
/*      */ 
/*  633 */     if (s == buf.length) {
/*  634 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  638 */     boolean negative = false;
/*      */ 
/*  640 */     if ((char)buf[s] == '-') {
/*  641 */       negative = true;
/*  642 */       s++;
/*  643 */     } else if ((char)buf[s] == '+') {
/*  644 */       s++;
/*      */     }
/*      */ 
/*  648 */     int save = s;
/*      */ 
/*  650 */     int cutoff = 2147483647 / base;
/*  651 */     int cutlim = 2147483647 % base;
/*      */ 
/*  653 */     if (negative) {
/*  654 */       cutlim++;
/*      */     }
/*      */ 
/*  657 */     boolean overflow = false;
/*      */ 
/*  659 */     int i = 0;
/*      */ 
/*  661 */     for (; s < buf.length; s++) {
/*  662 */       char c = (char)buf[s];
/*      */ 
/*  664 */       if (Character.isDigit(c)) {
/*  665 */         c = (char)(c - '0'); } else {
/*  666 */         if (!Character.isLetter(c)) break;
/*  667 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */ 
/*  672 */       if (c >= base)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  677 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  678 */         overflow = true;
/*      */       } else {
/*  680 */         i *= base;
/*  681 */         i += c;
/*      */       }
/*      */     }
/*      */ 
/*  685 */     if (s == save) {
/*  686 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  689 */     if (overflow) {
/*  690 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  694 */     return negative ? -i : i;
/*      */   }
/*      */ 
/*      */   public static long getLong(byte[] buf) throws NumberFormatException {
/*  698 */     int base = 10;
/*      */ 
/*  700 */     int s = 0;
/*      */ 
/*  703 */     while ((Character.isWhitespace((char)buf[s])) && (s < buf.length)) {
/*  704 */       s++;
/*      */     }
/*      */ 
/*  707 */     if (s == buf.length) {
/*  708 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  712 */     boolean negative = false;
/*      */ 
/*  714 */     if ((char)buf[s] == '-') {
/*  715 */       negative = true;
/*  716 */       s++;
/*  717 */     } else if ((char)buf[s] == '+') {
/*  718 */       s++;
/*      */     }
/*      */ 
/*  722 */     int save = s;
/*      */ 
/*  724 */     long cutoff = 9223372036854775807L / base;
/*  725 */     long cutlim = (int)(9223372036854775807L % base);
/*      */ 
/*  727 */     if (negative) {
/*  728 */       cutlim += 1L;
/*      */     }
/*      */ 
/*  731 */     boolean overflow = false;
/*  732 */     long i = 0L;
/*      */ 
/*  734 */     for (; s < buf.length; s++) {
/*  735 */       char c = (char)buf[s];
/*      */ 
/*  737 */       if (Character.isDigit(c)) {
/*  738 */         c = (char)(c - '0'); } else {
/*  739 */         if (!Character.isLetter(c)) break;
/*  740 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */ 
/*  745 */       if (c >= base)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  750 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  751 */         overflow = true;
/*      */       } else {
/*  753 */         i *= base;
/*  754 */         i += c;
/*      */       }
/*      */     }
/*      */ 
/*  758 */     if (s == save) {
/*  759 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  762 */     if (overflow) {
/*  763 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  767 */     return negative ? -i : i;
/*      */   }
/*      */ 
/*      */   public static short getShort(byte[] buf) throws NumberFormatException {
/*  771 */     short base = 10;
/*      */ 
/*  773 */     int s = 0;
/*      */ 
/*  776 */     while ((Character.isWhitespace((char)buf[s])) && (s < buf.length)) {
/*  777 */       s++;
/*      */     }
/*      */ 
/*  780 */     if (s == buf.length) {
/*  781 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  785 */     boolean negative = false;
/*      */ 
/*  787 */     if ((char)buf[s] == '-') {
/*  788 */       negative = true;
/*  789 */       s++;
/*  790 */     } else if ((char)buf[s] == '+') {
/*  791 */       s++;
/*      */     }
/*      */ 
/*  795 */     int save = s;
/*      */ 
/*  797 */     short cutoff = (short)(32767 / base);
/*  798 */     short cutlim = (short)(32767 % base);
/*      */ 
/*  800 */     if (negative) {
/*  801 */       cutlim = (short)(cutlim + 1);
/*      */     }
/*      */ 
/*  804 */     boolean overflow = false;
/*  805 */     short i = 0;
/*      */ 
/*  807 */     for (; s < buf.length; s++) {
/*  808 */       char c = (char)buf[s];
/*      */ 
/*  810 */       if (Character.isDigit(c)) {
/*  811 */         c = (char)(c - '0'); } else {
/*  812 */         if (!Character.isLetter(c)) break;
/*  813 */         c = (char)(Character.toUpperCase(c) - 'A' + 10);
/*      */       }
/*      */ 
/*  818 */       if (c >= base)
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/*  823 */       if ((i > cutoff) || ((i == cutoff) && (c > cutlim))) {
/*  824 */         overflow = true;
/*      */       } else {
/*  826 */         i = (short)(i * base);
/*  827 */         i = (short)(i + c);
/*      */       }
/*      */     }
/*      */ 
/*  831 */     if (s == save) {
/*  832 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  835 */     if (overflow) {
/*  836 */       throw new NumberFormatException(new String(buf));
/*      */     }
/*      */ 
/*  840 */     return negative ? (short)(-i) : i;
/*      */   }
/*      */ 
/*      */   public static final int indexOfIgnoreCase(int startingPosition, String searchIn, String searchFor)
/*      */   {
/*  845 */     if ((searchIn == null) || (searchFor == null) || (startingPosition > searchIn.length()))
/*      */     {
/*  847 */       return -1;
/*      */     }
/*      */ 
/*  850 */     int patternLength = searchFor.length();
/*  851 */     int stringLength = searchIn.length();
/*  852 */     int stopSearchingAt = stringLength - patternLength;
/*      */ 
/*  854 */     int i = startingPosition;
/*      */ 
/*  856 */     if (patternLength == 0) {
/*  857 */       return -1;
/*      */     }
/*      */ 
/*  862 */     char firstCharOfPatternUc = Character.toUpperCase(searchFor.charAt(0));
/*  863 */     char firstCharOfPatternLc = Character.toLowerCase(searchFor.charAt(0));
/*      */ 
/*  868 */     while ((i < stopSearchingAt) && (Character.toUpperCase(searchIn.charAt(i)) != firstCharOfPatternUc) && (Character.toLowerCase(searchIn.charAt(i)) != firstCharOfPatternLc)) {
/*  869 */       i++;
/*      */     }
/*      */ 
/*  872 */     if (i > stopSearchingAt) {
/*  873 */       return -1;
/*      */     }
/*      */ 
/*  876 */     int j = i + 1;
/*  877 */     int end = j + patternLength - 1;
/*      */ 
/*  879 */     int k = 1;
/*      */     while (true) {
/*  881 */       if (j >= end) break label209; int searchInPos = j++;
/*  883 */       int searchForPos = k++;
/*      */ 
/*  885 */       if (Character.toUpperCase(searchIn.charAt(searchInPos)) != Character.toUpperCase(searchFor.charAt(searchForPos)))
/*      */       {
/*  887 */         i++;
/*      */ 
/*  890 */         break;
/*      */       }
/*      */ 
/*  896 */       if (Character.toLowerCase(searchIn.charAt(searchInPos)) != Character.toLowerCase(searchFor.charAt(searchForPos)))
/*      */       {
/*  898 */         i++;
/*      */ 
/*  901 */         break;
/*      */       }
/*      */     }
/*      */ 
/*  905 */     label209: return i;
/*      */   }
/*      */ 
/*      */   public static final int indexOfIgnoreCase(String searchIn, String searchFor)
/*      */   {
/*  920 */     return indexOfIgnoreCase(0, searchIn, searchFor);
/*      */   }
/*      */ 
/*      */   public static int indexOfIgnoreCaseRespectMarker(int startAt, String src, String target, String marker, String markerCloses, boolean allowBackslashEscapes)
/*      */   {
/*  926 */     char contextMarker = '\000';
/*  927 */     boolean escaped = false;
/*  928 */     int markerTypeFound = 0;
/*  929 */     int srcLength = src.length();
/*  930 */     int ind = 0;
/*      */ 
/*  932 */     for (int i = startAt; i < srcLength; i++) {
/*  933 */       char c = src.charAt(i);
/*      */ 
/*  935 */       if ((allowBackslashEscapes) && (c == '\\')) {
/*  936 */         escaped = !escaped;
/*  937 */       } else if ((c == markerCloses.charAt(markerTypeFound)) && (!escaped)) {
/*  938 */         contextMarker = '\000';
/*  939 */       } else if (((ind = marker.indexOf(c)) != -1) && (!escaped) && (contextMarker == 0))
/*      */       {
/*  941 */         markerTypeFound = ind;
/*  942 */         contextMarker = c; } else {
/*  943 */         if ((c != target.charAt(0)) || (escaped) || (contextMarker != 0))
/*      */           continue;
/*  945 */         if (indexOfIgnoreCase(i, src, target) != -1) {
/*  946 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*  950 */     return -1;
/*      */   }
/*      */ 
/*      */   public static int indexOfIgnoreCaseRespectQuotes(int startAt, String src, String target, char quoteChar, boolean allowBackslashEscapes)
/*      */   {
/*  956 */     char contextMarker = '\000';
/*  957 */     boolean escaped = false;
/*      */ 
/*  959 */     int srcLength = src.length();
/*      */ 
/*  961 */     for (int i = startAt; i < srcLength; i++) {
/*  962 */       char c = src.charAt(i);
/*      */ 
/*  964 */       if ((allowBackslashEscapes) && (c == '\\')) {
/*  965 */         escaped = !escaped;
/*  966 */       } else if ((c == contextMarker) && (!escaped)) {
/*  967 */         contextMarker = '\000';
/*  968 */       } else if ((c == quoteChar) && (!escaped) && (contextMarker == 0))
/*      */       {
/*  970 */         contextMarker = c; } else {
/*  971 */         if ((c != target.charAt(0)) || (escaped) || (contextMarker != 0))
/*      */           continue;
/*  973 */         if (startsWithIgnoreCase(src, i, target)) {
/*  974 */           return i;
/*      */         }
/*      */       }
/*      */     }
/*  978 */     return -1;
/*      */   }
/*      */ 
/*      */   public static final List split(String stringToSplit, String delimitter, boolean trim)
/*      */   {
/*  999 */     if (stringToSplit == null) {
/* 1000 */       return new ArrayList();
/*      */     }
/*      */ 
/* 1003 */     if (delimitter == null) {
/* 1004 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/* 1007 */     StringTokenizer tokenizer = new StringTokenizer(stringToSplit, delimitter, false);
/*      */ 
/* 1010 */     List splitTokens = new ArrayList(tokenizer.countTokens());
/*      */ 
/* 1012 */     while (tokenizer.hasMoreTokens()) {
/* 1013 */       String token = tokenizer.nextToken();
/*      */ 
/* 1015 */       if (trim) {
/* 1016 */         token = token.trim();
/*      */       }
/*      */ 
/* 1019 */       splitTokens.add(token);
/*      */     }
/*      */ 
/* 1022 */     return splitTokens;
/*      */   }
/*      */ 
/*      */   public static final List split(String stringToSplit, String delimiter, String markers, String markerCloses, boolean trim)
/*      */   {
/* 1042 */     if (stringToSplit == null) {
/* 1043 */       return new ArrayList();
/*      */     }
/*      */ 
/* 1046 */     if (delimiter == null) {
/* 1047 */       throw new IllegalArgumentException();
/*      */     }
/*      */ 
/* 1050 */     int delimPos = 0;
/* 1051 */     int currentPos = 0;
/*      */ 
/* 1053 */     List splitTokens = new ArrayList();
/*      */ 
/* 1056 */     while ((delimPos = indexOfIgnoreCaseRespectMarker(currentPos, stringToSplit, delimiter, markers, markerCloses, false)) != -1) {
/* 1057 */       String token = stringToSplit.substring(currentPos, delimPos);
/*      */ 
/* 1059 */       if (trim) {
/* 1060 */         token = token.trim();
/*      */       }
/*      */ 
/* 1063 */       splitTokens.add(token);
/* 1064 */       currentPos = delimPos + 1;
/*      */     }
/*      */ 
/* 1067 */     if (currentPos < stringToSplit.length()) {
/* 1068 */       String token = stringToSplit.substring(currentPos);
/*      */ 
/* 1070 */       if (trim) {
/* 1071 */         token = token.trim();
/*      */       }
/*      */ 
/* 1074 */       splitTokens.add(token);
/*      */     }
/*      */ 
/* 1077 */     return splitTokens;
/*      */   }
/*      */ 
/*      */   private static boolean startsWith(byte[] dataFrom, String chars) {
/* 1081 */     for (int i = 0; i < chars.length(); i++) {
/* 1082 */       if (dataFrom[i] != chars.charAt(i)) {
/* 1083 */         return false;
/*      */       }
/*      */     }
/* 1086 */     return true;
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, int startAt, String searchFor)
/*      */   {
/* 1105 */     return searchIn.regionMatches(true, startAt, searchFor, 0, searchFor.length());
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCase(String searchIn, String searchFor)
/*      */   {
/* 1121 */     return startsWithIgnoreCase(searchIn, 0, searchFor);
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndNonAlphaNumeric(String searchIn, String searchFor)
/*      */   {
/* 1138 */     if (searchIn == null) {
/* 1139 */       return searchFor == null;
/*      */     }
/*      */ 
/* 1142 */     int beginPos = 0;
/*      */ 
/* 1144 */     int inLength = searchIn.length();
/*      */ 
/* 1146 */     for (beginPos = 0; beginPos < inLength; beginPos++) {
/* 1147 */       char c = searchIn.charAt(beginPos);
/*      */ 
/* 1149 */       if (Character.isLetterOrDigit(c))
/*      */       {
/*      */         break;
/*      */       }
/*      */     }
/* 1154 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor)
/*      */   {
/* 1170 */     return startsWithIgnoreCaseAndWs(searchIn, searchFor, 0);
/*      */   }
/*      */ 
/*      */   public static boolean startsWithIgnoreCaseAndWs(String searchIn, String searchFor, int beginPos)
/*      */   {
/* 1189 */     if (searchIn == null) {
/* 1190 */       return searchFor == null;
/*      */     }
/*      */ 
/* 1193 */     int inLength = searchIn.length();
/*      */ 
/* 1195 */     while ((beginPos < inLength) && 
/* 1196 */       (Character.isWhitespace(searchIn.charAt(beginPos)))) {
/* 1195 */       beginPos++;
/*      */     }
/*      */ 
/* 1201 */     return startsWithIgnoreCase(searchIn, beginPos, searchFor);
/*      */   }
/*      */ 
/*      */   public static byte[] stripEnclosure(byte[] source, String prefix, String suffix)
/*      */   {
/* 1212 */     if ((source.length >= prefix.length() + suffix.length()) && (startsWith(source, prefix)) && (endsWith(source, suffix)))
/*      */     {
/* 1215 */       int totalToStrip = prefix.length() + suffix.length();
/* 1216 */       int enclosedLength = source.length - totalToStrip;
/* 1217 */       byte[] enclosed = new byte[enclosedLength];
/*      */ 
/* 1219 */       int startPos = prefix.length();
/* 1220 */       int numToCopy = enclosed.length;
/* 1221 */       System.arraycopy(source, startPos, enclosed, 0, numToCopy);
/*      */ 
/* 1223 */       return enclosed;
/*      */     }
/* 1225 */     return source;
/*      */   }
/*      */ 
/*      */   public static final String toAsciiString(byte[] buffer)
/*      */   {
/* 1237 */     return toAsciiString(buffer, 0, buffer.length);
/*      */   }
/*      */ 
/*      */   public static final String toAsciiString(byte[] buffer, int startPos, int length)
/*      */   {
/* 1254 */     char[] charArray = new char[length];
/* 1255 */     int readpoint = startPos;
/*      */ 
/* 1257 */     for (int i = 0; i < length; i++) {
/* 1258 */       charArray[i] = (char)buffer[readpoint];
/* 1259 */       readpoint++;
/*      */     }
/*      */ 
/* 1262 */     return new String(charArray);
/*      */   }
/*      */ 
/*      */   public static int wildCompare(String searchIn, String searchForWildcard)
/*      */   {
/* 1280 */     if ((searchIn == null) || (searchForWildcard == null)) {
/* 1281 */       return -1;
/*      */     }
/*      */ 
/* 1284 */     if (searchForWildcard.equals("%"))
/*      */     {
/* 1286 */       return 1;
/*      */     }
/*      */ 
/* 1289 */     int result = -1;
/*      */ 
/* 1291 */     char wildcardMany = '%';
/* 1292 */     char wildcardOne = '_';
/* 1293 */     char wildcardEscape = '\\';
/*      */ 
/* 1295 */     int searchForPos = 0;
/* 1296 */     int searchForEnd = searchForWildcard.length();
/*      */ 
/* 1298 */     int searchInPos = 0;
/* 1299 */     int searchInEnd = searchIn.length();
/*      */ 
/* 1301 */     while (searchForPos != searchForEnd) {
/* 1302 */       char wildstrChar = searchForWildcard.charAt(searchForPos);
/*      */ 
/* 1305 */       while ((searchForWildcard.charAt(searchForPos) != wildcardMany) && (wildstrChar != wildcardOne)) {
/* 1306 */         if ((searchForWildcard.charAt(searchForPos) == wildcardEscape) && (searchForPos + 1 != searchForEnd))
/*      */         {
/* 1308 */           searchForPos++;
/*      */         }
/*      */ 
/* 1311 */         if ((searchInPos == searchInEnd) || (Character.toUpperCase(searchForWildcard.charAt(searchForPos++)) != Character.toUpperCase(searchIn.charAt(searchInPos++))))
/*      */         {
/* 1315 */           return 1;
/*      */         }
/*      */ 
/* 1318 */         if (searchForPos == searchForEnd) {
/* 1319 */           return searchInPos != searchInEnd ? 1 : 0;
/*      */         }
/*      */ 
/* 1326 */         result = 1;
/*      */       }
/*      */ 
/* 1329 */       if (searchForWildcard.charAt(searchForPos) == wildcardOne) {
/*      */         do {
/* 1331 */           if (searchInPos == searchInEnd)
/*      */           {
/* 1336 */             return result;
/*      */           }
/*      */ 
/* 1339 */           searchInPos++;
/*      */ 
/* 1341 */           searchForPos++; } while ((searchForPos < searchForEnd) && (searchForWildcard.charAt(searchForPos) == wildcardOne));
/*      */ 
/* 1343 */         if (searchForPos == searchForEnd)
/*      */         {
/*      */           break;
/*      */         }
/*      */       }
/* 1348 */       if (searchForWildcard.charAt(searchForPos) == wildcardMany)
/*      */       {
/* 1355 */         searchForPos++;
/*      */ 
/* 1358 */         for (; searchForPos != searchForEnd; searchForPos++) {
/* 1359 */           if (searchForWildcard.charAt(searchForPos) == wildcardMany)
/*      */           {
/*      */             continue;
/*      */           }
/* 1363 */           if (searchForWildcard.charAt(searchForPos) != wildcardOne) break;
/* 1364 */           if (searchInPos == searchInEnd) {
/* 1365 */             return -1;
/*      */           }
/*      */ 
/* 1368 */           searchInPos++;
/*      */         }
/*      */ 
/* 1376 */         if (searchForPos == searchForEnd) {
/* 1377 */           return 0;
/*      */         }
/*      */ 
/* 1380 */         if (searchInPos == searchInEnd)
/* 1381 */           return -1;
/*      */         char cmp;
/* 1384 */         if (((cmp = searchForWildcard.charAt(searchForPos)) == wildcardEscape) && (searchForPos + 1 != searchForEnd))
/*      */         {
/* 1386 */           searchForPos++; cmp = searchForWildcard.charAt(searchForPos);
/*      */         }
/*      */ 
/* 1389 */         searchForPos++;
/*      */         do
/*      */         {
/* 1393 */           while ((searchInPos != searchInEnd) && (Character.toUpperCase(searchIn.charAt(searchInPos)) != Character.toUpperCase(cmp)))
/*      */           {
/* 1396 */             searchInPos++;
/*      */           }
/* 1398 */           if (searchInPos++ == searchInEnd) {
/* 1399 */             return -1;
/*      */           }
/*      */ 
/* 1403 */           int tmp = wildCompare(searchIn, searchForWildcard);
/*      */ 
/* 1405 */           if (tmp <= 0) {
/* 1406 */             return tmp;
/*      */           }
/*      */         }
/*      */ 
/* 1410 */         while ((searchInPos != searchInEnd) && (searchForWildcard.charAt(0) != wildcardMany));
/*      */ 
/* 1412 */         return -1;
/*      */       }
/*      */     }
/*      */ 
/* 1416 */     return searchInPos != searchInEnd ? 1 : 0;
/*      */   }
/*      */ 
/*      */   static byte[] s2b(String s, Connection conn) throws SQLException
/*      */   {
/* 1421 */     if (s == null) {
/* 1422 */       return null;
/*      */     }
/*      */ 
/* 1425 */     if ((conn != null) && (conn.getUseUnicode())) {
/*      */       try {
/* 1427 */         String encoding = conn.getEncoding();
/*      */ 
/* 1429 */         if (encoding == null) {
/* 1430 */           return s.getBytes();
/*      */         }
/*      */ 
/* 1433 */         SingleByteCharsetConverter converter = conn.getCharsetConverter(encoding);
/*      */ 
/* 1436 */         if (converter != null) {
/* 1437 */           return converter.toBytes(s);
/*      */         }
/*      */ 
/* 1440 */         return s.getBytes(encoding);
/*      */       } catch (UnsupportedEncodingException E) {
/* 1442 */         return s.getBytes();
/*      */       }
/*      */     }
/*      */ 
/* 1446 */     return s.getBytes();
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*   62 */     for (int i = -128; i <= 127; i++) {
/*   63 */       allBytes[(i - -128)] = (byte)i;
/*      */     }
/*      */ 
/*   66 */     String allBytesString = new String(allBytes, 0, 255);
/*      */ 
/*   69 */     int allBytesStringLen = allBytesString.length();
/*      */ 
/*   71 */     int i = 0;
/*   72 */     for (; (i < 255) && (i < allBytesStringLen); i++) {
/*   73 */       byteToChars[i] = allBytesString.charAt(i);
/*      */     }
/*      */     try
/*      */     {
/*   77 */       toPlainStringMethod = BigDecimal.class.getMethod("toPlainString", new Class[0]);
/*      */     }
/*      */     catch (NoSuchMethodException nsme)
/*      */     {
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.StringUtils
 * JD-Core Version:    0.6.0
 */