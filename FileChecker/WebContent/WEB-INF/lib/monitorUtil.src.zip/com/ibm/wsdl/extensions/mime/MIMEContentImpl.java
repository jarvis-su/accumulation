package com.ibm.wsdl.extensions.mime;

import javax.wsdl.extensions.mime.MIMEContent;
import javax.xml.namespace.QName;

public class MIMEContentImpl
  implements MIMEContent
{
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_CONTENT;
  protected Boolean required = null;
  protected String part = null;
  protected String type = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setPart(String paramString)
  {
    this.part = paramString;
  }

  public String getPart()
  {
    return this.part;
  }

  public void setType(String paramString)
  {
    this.type = paramString;
  }

  public String getType()
  {
    return this.type;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("MIMEContent (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.part != null)
      localStringBuffer.append("\npart=" + this.part);
    if (this.type != null)
      localStringBuffer.append("\ntype=" + this.type);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.mime.MIMEContentImpl
 * JD-Core Version:    0.6.0
 */