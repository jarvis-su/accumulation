package ch.ethz.ssh2.channel;

public class X11ServerData
{
  public String hostname;
  public int port;
  public byte[] x11_magic_cookie;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.X11ServerData
 * JD-Core Version:    0.6.0
 */