/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class BlobFromLocator$LocatorInputStream extends InputStream
/*     */ {
/*     */   long currentPositionInBlob;
/*     */   long length;
/*     */   PreparedStatement pStmt;
/*     */   private final BlobFromLocator this$0;
/*     */ 
/*     */   BlobFromLocator$LocatorInputStream(BlobFromLocator this$0)
/*     */     throws SQLException
/*     */   {
/* 574 */     this.this$0 = this$0;
/*     */ 
/* 568 */     this.currentPositionInBlob = 0L;
/*     */ 
/* 570 */     this.length = 0L;
/*     */ 
/* 572 */     this.pStmt = null;
/*     */ 
/* 575 */     this.length = this$0.length();
/* 576 */     this.pStmt = this$0.createGetBytesStatement();
/*     */   }
/*     */ 
/*     */   public int read() throws IOException {
/* 580 */     if (this.currentPositionInBlob + 1L > this.length) {
/* 581 */       return -1;
/*     */     }
/*     */     try
/*     */     {
/* 585 */       byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob++ + 1L, 1);
/*     */ 
/* 588 */       if (asBytes == null) {
/* 589 */         return -1;
/*     */       }
/*     */ 
/* 592 */       return asBytes[0]; } catch (SQLException sqlEx) {
/*     */     }
/* 594 */     throw new IOException(sqlEx.toString());
/*     */   }
/*     */ 
/*     */   public int read(byte[] b, int off, int len)
/*     */     throws IOException
/*     */   {
/* 604 */     if (this.currentPositionInBlob + 1L > this.length) {
/* 605 */       return -1;
/*     */     }
/*     */     try
/*     */     {
/* 609 */       byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, len);
/*     */ 
/* 612 */       if (asBytes == null) {
/* 613 */         return -1;
/*     */       }
/*     */ 
/* 616 */       System.arraycopy(asBytes, 0, b, off, asBytes.length);
/*     */ 
/* 618 */       this.currentPositionInBlob += asBytes.length;
/*     */ 
/* 620 */       return asBytes.length; } catch (SQLException sqlEx) {
/*     */     }
/* 622 */     throw new IOException(sqlEx.toString());
/*     */   }
/*     */ 
/*     */   public int read(byte[] b)
/*     */     throws IOException
/*     */   {
/* 632 */     if (this.currentPositionInBlob + 1L > this.length) {
/* 633 */       return -1;
/*     */     }
/*     */     try
/*     */     {
/* 637 */       byte[] asBytes = this.this$0.getBytesInternal(this.pStmt, this.currentPositionInBlob + 1L, b.length);
/*     */ 
/* 640 */       if (asBytes == null) {
/* 641 */         return -1;
/*     */       }
/*     */ 
/* 644 */       System.arraycopy(asBytes, 0, b, 0, asBytes.length);
/*     */ 
/* 646 */       this.currentPositionInBlob += asBytes.length;
/*     */ 
/* 648 */       return asBytes.length; } catch (SQLException sqlEx) {
/*     */     }
/* 650 */     throw new IOException(sqlEx.toString());
/*     */   }
/*     */ 
/*     */   public void close()
/*     */     throws IOException
/*     */   {
/* 660 */     if (this.pStmt != null) {
/*     */       try {
/* 662 */         this.pStmt.close();
/*     */       } catch (SQLException sqlEx) {
/* 664 */         throw new IOException(sqlEx.toString());
/*     */       }
/*     */     }
/*     */ 
/* 668 */     super.close();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.BlobFromLocator.LocatorInputStream
 * JD-Core Version:    0.6.0
 */