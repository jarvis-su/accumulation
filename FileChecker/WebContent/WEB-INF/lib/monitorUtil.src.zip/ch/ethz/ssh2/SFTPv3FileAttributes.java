/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ public class SFTPv3FileAttributes
/*     */ {
/*  17 */   public Long size = null;
/*     */ 
/*  22 */   public Integer uid = null;
/*     */ 
/*  27 */   public Integer gid = null;
/*     */ 
/*  62 */   public Integer permissions = null;
/*     */ 
/*  68 */   public Integer atime = null;
/*     */ 
/*  74 */   public Integer mtime = null;
/*     */ 
/*     */   public boolean isDirectory()
/*     */   {
/*  84 */     if (this.permissions == null) {
/*  85 */       return false;
/*     */     }
/*  87 */     return (this.permissions.intValue() & 0x4000) != 0;
/*     */   }
/*     */ 
/*     */   public boolean isRegularFile()
/*     */   {
/*  98 */     if (this.permissions == null) {
/*  99 */       return false;
/*     */     }
/* 101 */     return (this.permissions.intValue() & 0x8000) != 0;
/*     */   }
/*     */ 
/*     */   public boolean isSymlink()
/*     */   {
/* 112 */     if (this.permissions == null) {
/* 113 */       return false;
/*     */     }
/* 115 */     return (this.permissions.intValue() & 0xA000) != 0;
/*     */   }
/*     */ 
/*     */   public String getOctalPermissions()
/*     */   {
/* 126 */     if (this.permissions == null) {
/* 127 */       return null;
/*     */     }
/* 129 */     String res = Integer.toString(this.permissions.intValue() & 0xFFFF, 8);
/*     */ 
/* 131 */     StringBuffer sb = new StringBuffer();
/*     */ 
/* 133 */     int leadingZeros = 7 - res.length();
/*     */ 
/* 135 */     while (leadingZeros > 0)
/*     */     {
/* 137 */       sb.append('0');
/* 138 */       leadingZeros--;
/*     */     }
/*     */ 
/* 141 */     sb.append(res);
/*     */ 
/* 143 */     return sb.toString();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SFTPv3FileAttributes
 * JD-Core Version:    0.6.0
 */