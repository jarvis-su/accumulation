/*     */ package ch.ethz.ssh2.packets;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigInteger;
/*     */ 
/*     */ public class TypesWriter
/*     */ {
/*     */   byte[] arr;
/*     */   int pos;
/*     */ 
/*     */   public TypesWriter()
/*     */   {
/*  20 */     this.arr = new byte[256];
/*  21 */     this.pos = 0;
/*     */   }
/*     */ 
/*     */   private void resize(int len)
/*     */   {
/*  26 */     byte[] new_arr = new byte[len];
/*  27 */     System.arraycopy(this.arr, 0, new_arr, 0, this.arr.length);
/*  28 */     this.arr = new_arr;
/*     */   }
/*     */ 
/*     */   public int length()
/*     */   {
/*  33 */     return this.pos;
/*     */   }
/*     */ 
/*     */   public byte[] getBytes()
/*     */   {
/*  38 */     byte[] dst = new byte[this.pos];
/*  39 */     System.arraycopy(this.arr, 0, dst, 0, this.pos);
/*  40 */     return dst;
/*     */   }
/*     */ 
/*     */   public void getBytes(byte[] dst)
/*     */   {
/*  45 */     System.arraycopy(this.arr, 0, dst, 0, this.pos);
/*     */   }
/*     */ 
/*     */   public void writeUINT32(int val, int off)
/*     */   {
/*  50 */     if (off + 4 > this.arr.length) {
/*  51 */       resize(off + 32);
/*     */     }
/*  53 */     this.arr[(off++)] = (byte)(val >> 24);
/*  54 */     this.arr[(off++)] = (byte)(val >> 16);
/*  55 */     this.arr[(off++)] = (byte)(val >> 8);
/*  56 */     this.arr[(off++)] = (byte)val;
/*     */   }
/*     */ 
/*     */   public void writeUINT32(int val)
/*     */   {
/*  61 */     writeUINT32(val, this.pos);
/*  62 */     this.pos += 4;
/*     */   }
/*     */ 
/*     */   public void writeUINT64(long val)
/*     */   {
/*  67 */     if (this.pos + 8 > this.arr.length) {
/*  68 */       resize(this.arr.length + 32);
/*     */     }
/*  70 */     this.arr[(this.pos++)] = (byte)(int)(val >> 56);
/*  71 */     this.arr[(this.pos++)] = (byte)(int)(val >> 48);
/*  72 */     this.arr[(this.pos++)] = (byte)(int)(val >> 40);
/*  73 */     this.arr[(this.pos++)] = (byte)(int)(val >> 32);
/*  74 */     this.arr[(this.pos++)] = (byte)(int)(val >> 24);
/*  75 */     this.arr[(this.pos++)] = (byte)(int)(val >> 16);
/*  76 */     this.arr[(this.pos++)] = (byte)(int)(val >> 8);
/*  77 */     this.arr[(this.pos++)] = (byte)(int)val;
/*     */   }
/*     */ 
/*     */   public void writeBoolean(boolean v)
/*     */   {
/*  82 */     if (this.pos + 1 > this.arr.length) {
/*  83 */       resize(this.arr.length + 32);
/*     */     }
/*  85 */     this.arr[(this.pos++)] = (v ? 1 : 0);
/*     */   }
/*     */ 
/*     */   public void writeByte(int v, int off)
/*     */   {
/*  90 */     if (off + 1 > this.arr.length) {
/*  91 */       resize(off + 32);
/*     */     }
/*  93 */     this.arr[off] = (byte)v;
/*     */   }
/*     */ 
/*     */   public void writeByte(int v)
/*     */   {
/*  98 */     writeByte(v, this.pos);
/*  99 */     this.pos += 1;
/*     */   }
/*     */ 
/*     */   public void writeMPInt(BigInteger b)
/*     */   {
/* 104 */     byte[] raw = b.toByteArray();
/*     */ 
/* 106 */     if ((raw.length == 1) && (raw[0] == 0))
/* 107 */       writeUINT32(0);
/*     */     else
/* 109 */       writeString(raw, 0, raw.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] buff)
/*     */   {
/* 114 */     writeBytes(buff, 0, buff.length);
/*     */   }
/*     */ 
/*     */   public void writeBytes(byte[] buff, int off, int len)
/*     */   {
/* 119 */     if (this.pos + len > this.arr.length) {
/* 120 */       resize(this.arr.length + len + 32);
/*     */     }
/* 122 */     System.arraycopy(buff, off, this.arr, this.pos, len);
/* 123 */     this.pos += len;
/*     */   }
/*     */ 
/*     */   public void writeString(byte[] buff, int off, int len)
/*     */   {
/* 128 */     writeUINT32(len);
/* 129 */     writeBytes(buff, off, len);
/*     */   }
/*     */ 
/*     */   public void writeString(String v)
/*     */   {
/* 134 */     byte[] b = v.getBytes();
/*     */ 
/* 136 */     writeUINT32(b.length);
/* 137 */     writeBytes(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void writeString(String v, String charsetName) throws UnsupportedEncodingException
/*     */   {
/* 142 */     byte[] b = charsetName == null ? v.getBytes() : v.getBytes(charsetName);
/*     */ 
/* 144 */     writeUINT32(b.length);
/* 145 */     writeBytes(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public void writeNameList(String[] v)
/*     */   {
/* 150 */     StringBuffer sb = new StringBuffer();
/* 151 */     for (int i = 0; i < v.length; i++)
/*     */     {
/* 153 */       if (i > 0)
/* 154 */         sb.append(',');
/* 155 */       sb.append(v[i]);
/*     */     }
/* 157 */     writeString(sb.toString());
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.TypesWriter
 * JD-Core Version:    0.6.0
 */