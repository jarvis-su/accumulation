/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class CharsetMapping
/*     */ {
/*  48 */   private static final Properties CHARSET_CONFIG = new Properties();
/*     */   public static final String[] INDEX_TO_CHARSET;
/*     */   private static final Map JAVA_TO_MYSQL_CHARSET_MAP;
/*     */   private static final Map JAVA_UC_TO_MYSQL_CHARSET_MAP;
/*     */   private static final Map ERROR_MESSAGE_FILE_TO_MYSQL_CHARSET_MAP;
/*     */   private static final Map MULTIBYTE_CHARSETS;
/*     */   private static final Map MYSQL_TO_JAVA_CHARSET_MAP;
/*     */ 
/*     */   static final String getJavaEncodingForMysqlEncoding(String mysqlEncoding, Connection conn)
/*     */     throws SQLException
/*     */   {
/* 519 */     if ((conn != null) && (conn.versionMeetsMinimum(4, 1, 0)) && ("latin1".equalsIgnoreCase(mysqlEncoding)))
/*     */     {
/* 521 */       return "Cp1252";
/*     */     }
/*     */ 
/* 524 */     return (String)MYSQL_TO_JAVA_CHARSET_MAP.get(mysqlEncoding);
/*     */   }
/*     */ 
/*     */   static final String getMysqlEncodingForJavaEncoding(String javaEncodingUC, Connection conn) throws SQLException
/*     */   {
/* 529 */     List mysqlEncodings = (List)JAVA_UC_TO_MYSQL_CHARSET_MAP.get(javaEncodingUC);
/*     */ 
/* 533 */     if (mysqlEncodings != null) {
/* 534 */       Iterator iter = mysqlEncodings.iterator();
/*     */ 
/* 536 */       VersionedStringProperty versionedProp = null;
/*     */ 
/* 538 */       while (iter.hasNext()) {
/* 539 */         VersionedStringProperty propToCheck = (VersionedStringProperty)iter.next();
/*     */ 
/* 542 */         if (conn == null)
/*     */         {
/* 545 */           return propToCheck.toString();
/*     */         }
/*     */ 
/* 548 */         if ((versionedProp != null) && (!versionedProp.preferredValue) && 
/* 549 */           (versionedProp.majorVersion == propToCheck.majorVersion) && (versionedProp.minorVersion == propToCheck.minorVersion) && (versionedProp.subminorVersion == propToCheck.subminorVersion))
/*     */         {
/* 552 */           return versionedProp.toString();
/*     */         }
/*     */ 
/* 556 */         if (!propToCheck.isOkayForVersion(conn)) break;
/* 557 */         if (propToCheck.preferredValue) {
/* 558 */           return propToCheck.toString();
/*     */         }
/*     */ 
/* 561 */         versionedProp = propToCheck;
/*     */       }
/*     */ 
/* 567 */       if (versionedProp != null) {
/* 568 */         return versionedProp.toString();
/*     */       }
/*     */     }
/*     */ 
/* 572 */     return null;
/*     */   }
/*     */ 
/*     */   static final int getNumberOfCharsetsConfigured() {
/* 576 */     return MYSQL_TO_JAVA_CHARSET_MAP.size() / 2;
/*     */   }
/*     */ 
/*     */   static final String getCharacterEncodingForErrorMessages(Connection conn)
/*     */     throws SQLException
/*     */   {
/* 592 */     String errorMessageFile = conn.getServerVariable("language");
/*     */ 
/* 594 */     if ((errorMessageFile == null) || (errorMessageFile.length() == 0))
/*     */     {
/* 596 */       return "Cp1252";
/*     */     }
/*     */ 
/* 599 */     int endWithoutSlash = errorMessageFile.length();
/*     */ 
/* 601 */     if ((errorMessageFile.endsWith("/")) || (errorMessageFile.endsWith("\\"))) {
/* 602 */       endWithoutSlash--;
/*     */     }
/*     */ 
/* 605 */     int lastSlashIndex = errorMessageFile.lastIndexOf('/', endWithoutSlash - 1);
/*     */ 
/* 607 */     if (lastSlashIndex == -1) {
/* 608 */       lastSlashIndex = errorMessageFile.lastIndexOf('\\', endWithoutSlash - 1);
/*     */     }
/*     */ 
/* 611 */     if (lastSlashIndex == -1) {
/* 612 */       lastSlashIndex = 0;
/*     */     }
/*     */ 
/* 615 */     if ((lastSlashIndex == endWithoutSlash) || (endWithoutSlash < lastSlashIndex))
/*     */     {
/* 617 */       return "Cp1252";
/*     */     }
/*     */ 
/* 620 */     errorMessageFile = errorMessageFile.substring(lastSlashIndex + 1, endWithoutSlash);
/*     */ 
/* 622 */     String errorMessageEncodingMysql = (String)ERROR_MESSAGE_FILE_TO_MYSQL_CHARSET_MAP.get(errorMessageFile);
/*     */ 
/* 624 */     if (errorMessageEncodingMysql == null)
/*     */     {
/* 626 */       return "Cp1252";
/*     */     }
/*     */ 
/* 629 */     String javaEncoding = getJavaEncodingForMysqlEncoding(errorMessageEncodingMysql, conn);
/*     */ 
/* 631 */     if (javaEncoding == null)
/*     */     {
/* 633 */       return "Cp1252";
/*     */     }
/*     */ 
/* 636 */     return javaEncoding;
/*     */   }
/*     */ 
/*     */   static final boolean isAliasForSjis(String encoding) {
/* 640 */     return ("SJIS".equalsIgnoreCase(encoding)) || ("WINDOWS-31J".equalsIgnoreCase(encoding)) || ("MS932".equalsIgnoreCase(encoding)) || ("SHIFT_JIS".equalsIgnoreCase(encoding)) || ("CP943".equalsIgnoreCase(encoding));
/*     */   }
/*     */ 
/*     */   static final boolean isMultibyteCharset(String javaEncodingName)
/*     */   {
/* 649 */     String javaEncodingNameUC = javaEncodingName.toUpperCase(Locale.ENGLISH);
/*     */ 
/* 652 */     return MULTIBYTE_CHARSETS.containsKey(javaEncodingNameUC);
/*     */   }
/*     */ 
/*     */   private static void populateMapWithKeyValuePairs(String configKey, Map mapToPopulate, boolean addVersionedProperties, boolean addUppercaseKeys)
/*     */   {
/* 658 */     String javaToMysqlConfig = CHARSET_CONFIG.getProperty(configKey);
/*     */ 
/* 660 */     if (javaToMysqlConfig != null) {
/* 661 */       List mappings = StringUtils.split(javaToMysqlConfig, ",", true);
/*     */ 
/* 663 */       if (mappings != null) {
/* 664 */         Iterator mappingsIter = mappings.iterator();
/*     */ 
/* 666 */         while (mappingsIter.hasNext()) {
/* 667 */           String aMapping = (String)mappingsIter.next();
/*     */ 
/* 669 */           List parsedPair = StringUtils.split(aMapping, "=", true);
/*     */ 
/* 671 */           if (parsedPair.size() == 2) {
/* 672 */             String key = parsedPair.get(0).toString();
/* 673 */             String value = parsedPair.get(1).toString();
/*     */ 
/* 675 */             if (addVersionedProperties) {
/* 676 */               List versionedProperties = (List)mapToPopulate.get(key);
/*     */ 
/* 679 */               if (versionedProperties == null) {
/* 680 */                 versionedProperties = new ArrayList();
/* 681 */                 mapToPopulate.put(key, versionedProperties);
/*     */               }
/*     */ 
/* 684 */               VersionedStringProperty verProp = new VersionedStringProperty(value);
/*     */ 
/* 686 */               versionedProperties.add(verProp);
/*     */ 
/* 688 */               if (addUppercaseKeys) {
/* 689 */                 String keyUc = key.toUpperCase(Locale.ENGLISH);
/*     */ 
/* 691 */                 versionedProperties = (List)mapToPopulate.get(keyUc);
/*     */ 
/* 694 */                 if (versionedProperties == null) {
/* 695 */                   versionedProperties = new ArrayList();
/* 696 */                   mapToPopulate.put(keyUc, versionedProperties);
/*     */                 }
/*     */ 
/* 700 */                 versionedProperties.add(verProp);
/*     */               }
/*     */             } else {
/* 703 */               mapToPopulate.put(key, value);
/*     */ 
/* 705 */               if (addUppercaseKeys)
/* 706 */                 mapToPopulate.put(key.toUpperCase(Locale.ENGLISH), value);
/*     */             }
/*     */           }
/*     */           else
/*     */           {
/* 711 */             throw new RuntimeException("Syntax error in Charsets.properties resource for token \"" + aMapping + "\".");
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */       else
/*     */       {
/* 718 */         throw new RuntimeException("Missing/corrupt entry for \"" + configKey + "\" in Charsets.properties.");
/*     */       }
/*     */     }
/*     */     else {
/* 722 */       throw new RuntimeException("Could not find configuration value \"" + configKey + "\" in Charsets.properties resource");
/*     */     }
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  69 */     CHARSET_CONFIG.setProperty("javaToMysqlMappings", "US-ASCII =\t\t\tusa7,US-ASCII =\t\t\tascii,Big5 = \t\t\t\tbig5,GBK = \t\t\t\tgbk,SJIS = \t\t\t\tsjis,EUC_CN = \t\t\tgb2312,EUC_JP = \t\t\tujis,EUC_JP_Solaris = \t>5.0.3 eucjpms,EUC_KR = \t\t\teuc_kr,EUC_KR = \t\t\t>4.1.0 euckr,ISO8859_1 =\t\t\t*latin1,ISO8859_1 =\t\t\tlatin1_de,ISO8859_1 =\t\t\tgerman1,ISO8859_1 =\t\t\tdanish,ISO8859_2 =\t\t\tlatin2,ISO8859_2 =\t\t\tczech,ISO8859_2 =\t\t\thungarian,ISO8859_2  =\t\tcroat,ISO8859_7  =\t\tgreek,ISO8859_7  =\t\tlatin7,ISO8859_8  = \t\thebrew,ISO8859_9  =\t\tlatin5,ISO8859_13 =\t\tlatvian,ISO8859_13 =\t\tlatvian1,ISO8859_13 =\t\testonia,Cp437 =             *>4.1.0 cp850,Cp437 =\t\t\t\tdos,Cp850 =\t\t\t\tCp850,Cp852 = \t\t\tCp852,Cp866 = \t\t\tcp866,KOI8_R = \t\t\tkoi8_ru,KOI8_R = \t\t\t>4.1.0 koi8r,TIS620 = \t\t\ttis620,Cp1250 = \t\t\tcp1250,Cp1250 = \t\t\twin1250,Cp1251 = \t\t\t*>4.1.0 cp1251,Cp1251 = \t\t\twin1251,Cp1251 = \t\t\tcp1251cias,Cp1251 = \t\t\tcp1251csas,Cp1256 = \t\t\tcp1256,Cp1251 = \t\t\twin1251ukr,Cp1252 =             latin1,Cp1257 = \t\t\tcp1257,MacRoman = \t\t\tmacroman,MacCentralEurope = \tmacce,UTF-8 = \t\tutf8,UnicodeBig = \tucs2,US-ASCII =\t\tbinary,Cp943 =        \tsjis,MS932 =\t\t\tsjis,MS932 =        \t>4.1.11 cp932,WINDOWS-31J =\tsjis,WINDOWS-31J = \t>4.1.11 cp932,CP932 =\t\t\tsjis,CP932 =\t\t\t*>4.1.11 cp932,SHIFT_JIS = \tsjis,ASCII =\t\t\tascii,LATIN5 =\t\tlatin5,LATIN7 =\t\tlatin7,HEBREW =\t\thebrew,GREEK =\t\t\tgreek,EUCKR =\t\t\teuckr,GB2312 =\t\tgb2312,LATIN2 =\t\tlatin2");
/*     */ 
/* 144 */     HashMap javaToMysqlMap = new HashMap();
/*     */ 
/* 146 */     populateMapWithKeyValuePairs("javaToMysqlMappings", javaToMysqlMap, true, false);
/*     */ 
/* 148 */     JAVA_TO_MYSQL_CHARSET_MAP = Collections.unmodifiableMap(javaToMysqlMap);
/*     */ 
/* 150 */     HashMap mysqlToJavaMap = new HashMap();
/*     */ 
/* 152 */     Set keySet = JAVA_TO_MYSQL_CHARSET_MAP.keySet();
/*     */ 
/* 154 */     Iterator javaCharsets = keySet.iterator();
/*     */ 
/* 156 */     while (javaCharsets.hasNext()) {
/* 157 */       Object javaEncodingName = javaCharsets.next();
/* 158 */       List mysqlEncodingList = (List)JAVA_TO_MYSQL_CHARSET_MAP.get(javaEncodingName);
/*     */ 
/* 161 */       Iterator mysqlEncodings = mysqlEncodingList.iterator();
/*     */ 
/* 163 */       String mysqlEncodingName = null;
/*     */ 
/* 165 */       while (mysqlEncodings.hasNext()) {
/* 166 */         VersionedStringProperty mysqlProp = (VersionedStringProperty)mysqlEncodings.next();
/*     */ 
/* 168 */         mysqlEncodingName = mysqlProp.toString();
/*     */ 
/* 170 */         mysqlToJavaMap.put(mysqlEncodingName, javaEncodingName);
/* 171 */         mysqlToJavaMap.put(mysqlEncodingName.toUpperCase(Locale.ENGLISH), javaEncodingName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 177 */     mysqlToJavaMap.put("cp932", "Windows-31J");
/* 178 */     mysqlToJavaMap.put("CP932", "Windows-31J");
/*     */ 
/* 180 */     MYSQL_TO_JAVA_CHARSET_MAP = Collections.unmodifiableMap(mysqlToJavaMap);
/*     */ 
/* 182 */     HashMap ucMap = new HashMap(JAVA_TO_MYSQL_CHARSET_MAP.size());
/*     */ 
/* 184 */     Iterator javaNamesKeys = JAVA_TO_MYSQL_CHARSET_MAP.keySet().iterator();
/*     */ 
/* 186 */     while (javaNamesKeys.hasNext()) {
/* 187 */       String key = (String)javaNamesKeys.next();
/*     */ 
/* 189 */       ucMap.put(key.toUpperCase(Locale.ENGLISH), JAVA_TO_MYSQL_CHARSET_MAP.get(key));
/*     */     }
/*     */ 
/* 193 */     JAVA_UC_TO_MYSQL_CHARSET_MAP = Collections.unmodifiableMap(ucMap);
/*     */ 
/* 199 */     HashMap tempMapMulti = new HashMap();
/*     */ 
/* 201 */     CHARSET_CONFIG.setProperty("multibyteCharsets", "Big5 = \t\t\tbig5,GBK = \t\t\tgbk,SJIS = \t\t\tsjis,EUC_CN = \t\tgb2312,EUC_JP = \t\tujis,EUC_JP_Solaris = eucjpms,EUC_KR = \t\teuc_kr,EUC_KR = \t\t>4.1.0 euckr,Cp943 =        \tsjis,Cp943 = \t\tcp943,WINDOWS-31J =\tsjis,WINDOWS-31J = \tcp932,CP932 =\t\t\tcp932,MS932 =\t\t\tsjis,MS932 =        \tcp932,SHIFT_JIS = \tsjis,EUCKR =\t\t\teuckr,GB2312 =\t\tgb2312,UTF-8 = \t\tutf8,utf8 =          utf8,UnicodeBig = \tucs2");
/*     */ 
/* 233 */     populateMapWithKeyValuePairs("multibyteCharsets", tempMapMulti, false, true);
/*     */ 
/* 236 */     MULTIBYTE_CHARSETS = Collections.unmodifiableMap(tempMapMulti);
/*     */ 
/* 238 */     INDEX_TO_CHARSET = new String['Ó'];
/*     */     try
/*     */     {
/* 241 */       INDEX_TO_CHARSET[1] = getJavaEncodingForMysqlEncoding("big5", null);
/* 242 */       INDEX_TO_CHARSET[2] = getJavaEncodingForMysqlEncoding("czech", null);
/* 243 */       INDEX_TO_CHARSET[3] = getJavaEncodingForMysqlEncoding("dec8", null);
/* 244 */       INDEX_TO_CHARSET[4] = getJavaEncodingForMysqlEncoding("dos", null);
/* 245 */       INDEX_TO_CHARSET[5] = getJavaEncodingForMysqlEncoding("german1", null);
/*     */ 
/* 247 */       INDEX_TO_CHARSET[6] = getJavaEncodingForMysqlEncoding("hp8", null);
/* 248 */       INDEX_TO_CHARSET[7] = getJavaEncodingForMysqlEncoding("koi8_ru", null);
/*     */ 
/* 250 */       INDEX_TO_CHARSET[8] = getJavaEncodingForMysqlEncoding("latin1", null);
/*     */ 
/* 252 */       INDEX_TO_CHARSET[9] = getJavaEncodingForMysqlEncoding("latin2", null);
/*     */ 
/* 254 */       INDEX_TO_CHARSET[10] = getJavaEncodingForMysqlEncoding("swe7", null);
/* 255 */       INDEX_TO_CHARSET[11] = getJavaEncodingForMysqlEncoding("usa7", null);
/* 256 */       INDEX_TO_CHARSET[12] = getJavaEncodingForMysqlEncoding("ujis", null);
/* 257 */       INDEX_TO_CHARSET[13] = getJavaEncodingForMysqlEncoding("sjis", null);
/* 258 */       INDEX_TO_CHARSET[14] = getJavaEncodingForMysqlEncoding("cp1251", null);
/*     */ 
/* 260 */       INDEX_TO_CHARSET[15] = getJavaEncodingForMysqlEncoding("danish", null);
/*     */ 
/* 262 */       INDEX_TO_CHARSET[16] = getJavaEncodingForMysqlEncoding("hebrew", null);
/*     */ 
/* 264 */       INDEX_TO_CHARSET[18] = getJavaEncodingForMysqlEncoding("tis620", null);
/*     */ 
/* 266 */       INDEX_TO_CHARSET[19] = getJavaEncodingForMysqlEncoding("euc_kr", null);
/*     */ 
/* 268 */       INDEX_TO_CHARSET[20] = getJavaEncodingForMysqlEncoding("estonia", null);
/*     */ 
/* 270 */       INDEX_TO_CHARSET[21] = getJavaEncodingForMysqlEncoding("hungarian", null);
/*     */ 
/* 272 */       INDEX_TO_CHARSET[22] = getJavaEncodingForMysqlEncoding("koi8_ukr", null);
/*     */ 
/* 274 */       INDEX_TO_CHARSET[23] = getJavaEncodingForMysqlEncoding("win1251ukr", null);
/*     */ 
/* 276 */       INDEX_TO_CHARSET[24] = getJavaEncodingForMysqlEncoding("gb2312", null);
/*     */ 
/* 278 */       INDEX_TO_CHARSET[25] = getJavaEncodingForMysqlEncoding("greek", null);
/*     */ 
/* 280 */       INDEX_TO_CHARSET[26] = getJavaEncodingForMysqlEncoding("win1250", null);
/*     */ 
/* 282 */       INDEX_TO_CHARSET[27] = getJavaEncodingForMysqlEncoding("croat", null);
/*     */ 
/* 284 */       INDEX_TO_CHARSET[28] = getJavaEncodingForMysqlEncoding("gbk", null);
/* 285 */       INDEX_TO_CHARSET[29] = getJavaEncodingForMysqlEncoding("cp1257", null);
/*     */ 
/* 287 */       INDEX_TO_CHARSET[30] = getJavaEncodingForMysqlEncoding("latin5", null);
/*     */ 
/* 289 */       INDEX_TO_CHARSET[31] = getJavaEncodingForMysqlEncoding("latin1_de", null);
/*     */ 
/* 291 */       INDEX_TO_CHARSET[32] = getJavaEncodingForMysqlEncoding("armscii8", null);
/*     */ 
/* 293 */       INDEX_TO_CHARSET[33] = getJavaEncodingForMysqlEncoding("utf8", null);
/* 294 */       INDEX_TO_CHARSET[34] = getJavaEncodingForMysqlEncoding("win1250ch", null);
/*     */ 
/* 296 */       INDEX_TO_CHARSET[35] = getJavaEncodingForMysqlEncoding("ucs2", null);
/* 297 */       INDEX_TO_CHARSET[36] = getJavaEncodingForMysqlEncoding("cp866", null);
/*     */ 
/* 299 */       INDEX_TO_CHARSET[37] = getJavaEncodingForMysqlEncoding("keybcs2", null);
/*     */ 
/* 301 */       INDEX_TO_CHARSET[38] = getJavaEncodingForMysqlEncoding("macce", null);
/*     */ 
/* 303 */       INDEX_TO_CHARSET[39] = getJavaEncodingForMysqlEncoding("macroman", null);
/*     */ 
/* 305 */       INDEX_TO_CHARSET[40] = getJavaEncodingForMysqlEncoding("pclatin2", null);
/*     */ 
/* 307 */       INDEX_TO_CHARSET[41] = getJavaEncodingForMysqlEncoding("latvian", null);
/*     */ 
/* 309 */       INDEX_TO_CHARSET[42] = getJavaEncodingForMysqlEncoding("latvian1", null);
/*     */ 
/* 311 */       INDEX_TO_CHARSET[43] = getJavaEncodingForMysqlEncoding("maccebin", null);
/*     */ 
/* 313 */       INDEX_TO_CHARSET[44] = getJavaEncodingForMysqlEncoding("macceciai", null);
/*     */ 
/* 315 */       INDEX_TO_CHARSET[45] = getJavaEncodingForMysqlEncoding("maccecias", null);
/*     */ 
/* 317 */       INDEX_TO_CHARSET[46] = getJavaEncodingForMysqlEncoding("maccecsas", null);
/*     */ 
/* 319 */       INDEX_TO_CHARSET[47] = getJavaEncodingForMysqlEncoding("latin1bin", null);
/*     */ 
/* 321 */       INDEX_TO_CHARSET[48] = getJavaEncodingForMysqlEncoding("latin1cias", null);
/*     */ 
/* 323 */       INDEX_TO_CHARSET[49] = getJavaEncodingForMysqlEncoding("latin1csas", null);
/*     */ 
/* 325 */       INDEX_TO_CHARSET[50] = getJavaEncodingForMysqlEncoding("cp1251bin", null);
/*     */ 
/* 327 */       INDEX_TO_CHARSET[51] = getJavaEncodingForMysqlEncoding("cp1251cias", null);
/*     */ 
/* 329 */       INDEX_TO_CHARSET[52] = getJavaEncodingForMysqlEncoding("cp1251csas", null);
/*     */ 
/* 331 */       INDEX_TO_CHARSET[53] = getJavaEncodingForMysqlEncoding("macromanbin", null);
/*     */ 
/* 333 */       INDEX_TO_CHARSET[54] = getJavaEncodingForMysqlEncoding("macromancias", null);
/*     */ 
/* 335 */       INDEX_TO_CHARSET[55] = getJavaEncodingForMysqlEncoding("macromanciai", null);
/*     */ 
/* 337 */       INDEX_TO_CHARSET[56] = getJavaEncodingForMysqlEncoding("macromancsas", null);
/*     */ 
/* 339 */       INDEX_TO_CHARSET[57] = getJavaEncodingForMysqlEncoding("cp1256", null);
/*     */ 
/* 341 */       INDEX_TO_CHARSET[63] = getJavaEncodingForMysqlEncoding("binary", null);
/*     */ 
/* 343 */       INDEX_TO_CHARSET[64] = getJavaEncodingForMysqlEncoding("armscii", null);
/*     */ 
/* 345 */       INDEX_TO_CHARSET[65] = getJavaEncodingForMysqlEncoding("ascii", null);
/*     */ 
/* 347 */       INDEX_TO_CHARSET[66] = getJavaEncodingForMysqlEncoding("cp1250", null);
/*     */ 
/* 349 */       INDEX_TO_CHARSET[67] = getJavaEncodingForMysqlEncoding("cp1256", null);
/*     */ 
/* 351 */       INDEX_TO_CHARSET[68] = getJavaEncodingForMysqlEncoding("cp866", null);
/*     */ 
/* 353 */       INDEX_TO_CHARSET[69] = getJavaEncodingForMysqlEncoding("dec8", null);
/* 354 */       INDEX_TO_CHARSET[70] = getJavaEncodingForMysqlEncoding("greek", null);
/*     */ 
/* 356 */       INDEX_TO_CHARSET[71] = getJavaEncodingForMysqlEncoding("hebrew", null);
/*     */ 
/* 358 */       INDEX_TO_CHARSET[72] = getJavaEncodingForMysqlEncoding("hp8", null);
/* 359 */       INDEX_TO_CHARSET[73] = getJavaEncodingForMysqlEncoding("keybcs2", null);
/*     */ 
/* 361 */       INDEX_TO_CHARSET[74] = getJavaEncodingForMysqlEncoding("koi8r", null);
/*     */ 
/* 363 */       INDEX_TO_CHARSET[75] = getJavaEncodingForMysqlEncoding("koi8ukr", null);
/*     */ 
/* 365 */       INDEX_TO_CHARSET[77] = getJavaEncodingForMysqlEncoding("latin2", null);
/*     */ 
/* 367 */       INDEX_TO_CHARSET[78] = getJavaEncodingForMysqlEncoding("latin5", null);
/*     */ 
/* 369 */       INDEX_TO_CHARSET[79] = getJavaEncodingForMysqlEncoding("latin7", null);
/*     */ 
/* 371 */       INDEX_TO_CHARSET[80] = getJavaEncodingForMysqlEncoding("cp850", null);
/*     */ 
/* 373 */       INDEX_TO_CHARSET[81] = getJavaEncodingForMysqlEncoding("cp852", null);
/*     */ 
/* 375 */       INDEX_TO_CHARSET[82] = getJavaEncodingForMysqlEncoding("swe7", null);
/* 376 */       INDEX_TO_CHARSET[83] = getJavaEncodingForMysqlEncoding("utf8", null);
/* 377 */       INDEX_TO_CHARSET[84] = getJavaEncodingForMysqlEncoding("big5", null);
/* 378 */       INDEX_TO_CHARSET[85] = getJavaEncodingForMysqlEncoding("euckr", null);
/*     */ 
/* 380 */       INDEX_TO_CHARSET[86] = getJavaEncodingForMysqlEncoding("gb2312", null);
/*     */ 
/* 382 */       INDEX_TO_CHARSET[87] = getJavaEncodingForMysqlEncoding("gbk", null);
/* 383 */       INDEX_TO_CHARSET[88] = getJavaEncodingForMysqlEncoding("sjis", null);
/* 384 */       INDEX_TO_CHARSET[89] = getJavaEncodingForMysqlEncoding("tis620", null);
/*     */ 
/* 386 */       INDEX_TO_CHARSET[90] = getJavaEncodingForMysqlEncoding("ucs2", null);
/* 387 */       INDEX_TO_CHARSET[91] = getJavaEncodingForMysqlEncoding("ujis", null);
/* 388 */       INDEX_TO_CHARSET[92] = getJavaEncodingForMysqlEncoding("geostd8", null);
/*     */ 
/* 390 */       INDEX_TO_CHARSET[93] = getJavaEncodingForMysqlEncoding("geostd8", null);
/*     */ 
/* 392 */       INDEX_TO_CHARSET[94] = getJavaEncodingForMysqlEncoding("latin1", null);
/*     */ 
/* 394 */       INDEX_TO_CHARSET[95] = getJavaEncodingForMysqlEncoding("cp932", null);
/*     */ 
/* 396 */       INDEX_TO_CHARSET[96] = getJavaEncodingForMysqlEncoding("cp932", null);
/*     */ 
/* 398 */       INDEX_TO_CHARSET[97] = getJavaEncodingForMysqlEncoding("eucjpms", null);
/*     */ 
/* 400 */       INDEX_TO_CHARSET[98] = getJavaEncodingForMysqlEncoding("eucjpms", null);
/*     */ 
/* 403 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 405 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 407 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 409 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 411 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 413 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 415 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 417 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 419 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 421 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 423 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 425 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 427 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 429 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 431 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 433 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 435 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 437 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 439 */       INDEX_TO_CHARSET[''] = getJavaEncodingForMysqlEncoding("ucs2", null);
/*     */ 
/* 442 */       INDEX_TO_CHARSET['À'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 444 */       INDEX_TO_CHARSET['Á'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 446 */       INDEX_TO_CHARSET['Â'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 448 */       INDEX_TO_CHARSET['Ã'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 450 */       INDEX_TO_CHARSET['Ä'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 452 */       INDEX_TO_CHARSET['Å'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 454 */       INDEX_TO_CHARSET['Æ'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 456 */       INDEX_TO_CHARSET['Ç'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 458 */       INDEX_TO_CHARSET['È'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 460 */       INDEX_TO_CHARSET['É'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 462 */       INDEX_TO_CHARSET['Ê'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 464 */       INDEX_TO_CHARSET['Ë'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 466 */       INDEX_TO_CHARSET['Ì'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 468 */       INDEX_TO_CHARSET['Í'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 470 */       INDEX_TO_CHARSET['Î'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 472 */       INDEX_TO_CHARSET['Ï'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 474 */       INDEX_TO_CHARSET['Ð'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 476 */       INDEX_TO_CHARSET['Ñ'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */ 
/* 478 */       INDEX_TO_CHARSET['Ò'] = getJavaEncodingForMysqlEncoding("utf8", null);
/*     */     }
/*     */     catch (SQLException sqlEx)
/*     */     {
/*     */     }
/*     */ 
/* 485 */     Map tempMap = new HashMap();
/*     */ 
/* 487 */     tempMap.put("czech", "latin2");
/* 488 */     tempMap.put("danish", "latin1");
/* 489 */     tempMap.put("dutch", "latin1");
/* 490 */     tempMap.put("english", "latin1");
/* 491 */     tempMap.put("estonian", "latin7");
/* 492 */     tempMap.put("french", "latin1");
/* 493 */     tempMap.put("german", "latin1");
/* 494 */     tempMap.put("greek", "greek");
/* 495 */     tempMap.put("hungarian", "latin2");
/* 496 */     tempMap.put("italian", "latin1");
/* 497 */     tempMap.put("japanese", "ujis");
/* 498 */     tempMap.put("japanese-sjis", "sjis");
/* 499 */     tempMap.put("korean", "euckr");
/* 500 */     tempMap.put("norwegian", "latin1");
/* 501 */     tempMap.put("norwegian-ny", "latin1");
/* 502 */     tempMap.put("polish", "latin2");
/* 503 */     tempMap.put("portuguese", "latin1");
/* 504 */     tempMap.put("romanian", "latin2");
/* 505 */     tempMap.put("russian", "koi8r");
/* 506 */     tempMap.put("serbian", "cp1250");
/* 507 */     tempMap.put("slovak", "latin2");
/* 508 */     tempMap.put("spanish", "latin1");
/* 509 */     tempMap.put("swedish", "latin1");
/* 510 */     tempMap.put("ukrainian", "koi8u");
/*     */ 
/* 512 */     ERROR_MESSAGE_FILE_TO_MYSQL_CHARSET_MAP = Collections.unmodifiableMap(tempMap);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CharsetMapping
 * JD-Core Version:    0.6.0
 */