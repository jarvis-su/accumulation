/*     */ package com.mysql.jdbc.jdbc2.optional;
/*     */ 
/*     */ import com.mysql.jdbc.log.Log;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.sql.XAConnection;
/*     */ import javax.transaction.xa.XAException;
/*     */ import javax.transaction.xa.XAResource;
/*     */ import javax.transaction.xa.Xid;
/*     */ 
/*     */ public class MysqlXAConnection extends MysqlPooledConnection
/*     */   implements XAConnection, XAResource
/*     */ {
/*     */   private com.mysql.jdbc.Connection underlyingConnection;
/*     */   private static final Map MYSQL_ERROR_CODES_TO_XA_ERROR_CODES;
/*     */   private Log log;
/*     */ 
/*     */   public MysqlXAConnection(com.mysql.jdbc.Connection connection)
/*     */     throws SQLException
/*     */   {
/*  88 */     super(connection);
/*  89 */     this.underlyingConnection = connection;
/*  90 */     this.log = connection.getLog();
/*     */   }
/*     */ 
/*     */   public XAResource getXAResource()
/*     */     throws SQLException
/*     */   {
/* 103 */     return this;
/*     */   }
/*     */ 
/*     */   public int getTransactionTimeout()
/*     */     throws XAException
/*     */   {
/* 121 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean setTransactionTimeout(int arg0)
/*     */     throws XAException
/*     */   {
/* 147 */     return false;
/*     */   }
/*     */ 
/*     */   public boolean isSameRM(XAResource xares)
/*     */     throws XAException
/*     */   {
/* 167 */     if ((xares instanceof MysqlXAConnection)) {
/* 168 */       return this.underlyingConnection.isSameResource(((MysqlXAConnection)xares).underlyingConnection);
/*     */     }
/*     */ 
/* 172 */     return false;
/*     */   }
/*     */ 
/*     */   public Xid[] recover(int flag)
/*     */     throws XAException
/*     */   {
/* 213 */     return recover(this.underlyingConnection, flag);
/*     */   }
/*     */ 
/*     */   protected static Xid[] recover(java.sql.Connection c, int flag)
/*     */     throws XAException
/*     */   {
/* 237 */     boolean startRscan = (flag & 0x1000000) > 0;
/* 238 */     boolean endRscan = (flag & 0x800000) > 0;
/*     */ 
/* 240 */     if ((!startRscan) && (!endRscan) && (flag != 0)) {
/* 241 */       throw new MysqlXAException(-5, "Invalid flag, must use TMNOFLAGS, or any combination of TMSTARTRSCAN and TMENDRSCAN", null);
/*     */     }
/*     */ 
/* 254 */     if (!startRscan) {
/* 255 */       return new Xid[0];
/*     */     }
/*     */ 
/* 258 */     ResultSet rs = null;
/* 259 */     Statement stmt = null;
/*     */ 
/* 261 */     List recoveredXidList = new ArrayList();
/*     */     try
/*     */     {
/* 265 */       stmt = c.createStatement();
/*     */ 
/* 267 */       rs = stmt.executeQuery("XA RECOVER");
/*     */ 
/* 269 */       while (rs.next()) {
/* 270 */         int formatId = rs.getInt(1);
/* 271 */         int gtridLength = rs.getInt(2);
/* 272 */         int bqualLength = rs.getInt(3);
/* 273 */         byte[] gtridAndBqual = rs.getBytes(4);
/*     */ 
/* 275 */         byte[] gtrid = new byte[gtridLength];
/* 276 */         byte[] bqual = new byte[bqualLength];
/*     */ 
/* 278 */         if (gtridAndBqual.length != gtridLength + bqualLength) {
/* 279 */           throw new MysqlXAException(105, "Error while recovering XIDs from RM. GTRID and BQUAL are wrong sizes", null);
/*     */         }
/*     */ 
/* 284 */         System.arraycopy(gtridAndBqual, 0, gtrid, 0, gtridLength);
/*     */ 
/* 286 */         System.arraycopy(gtridAndBqual, gtridLength, bqual, 0, bqualLength);
/*     */ 
/* 289 */         recoveredXidList.add(new MysqlXid(gtrid, bqual, formatId));
/*     */       }
/*     */     }
/*     */     catch (SQLException sqlEx) {
/* 293 */       throw mapXAExceptionFromSQLException(sqlEx);
/*     */     } finally {
/* 295 */       if (rs != null) {
/*     */         try {
/* 297 */           rs.close();
/*     */         } catch (SQLException sqlEx) {
/* 299 */           throw mapXAExceptionFromSQLException(sqlEx);
/*     */         }
/*     */       }
/*     */ 
/* 303 */       if (stmt != null) {
/*     */         try {
/* 305 */           stmt.close();
/*     */         } catch (SQLException sqlEx) {
/* 307 */           throw mapXAExceptionFromSQLException(sqlEx);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 312 */     int numXids = recoveredXidList.size();
/*     */ 
/* 314 */     Xid[] asXids = new Xid[numXids];
/* 315 */     Object[] asObjects = recoveredXidList.toArray();
/*     */ 
/* 317 */     for (int i = 0; i < numXids; i++) {
/* 318 */       asXids[i] = ((Xid)asObjects[i]);
/*     */     }
/*     */ 
/* 321 */     return asXids;
/*     */   }
/*     */ 
/*     */   public int prepare(Xid xid)
/*     */     throws XAException
/*     */   {
/* 343 */     StringBuffer commandBuf = new StringBuffer();
/* 344 */     commandBuf.append("XA PREPARE ");
/* 345 */     commandBuf.append(xidToString(xid));
/*     */ 
/* 347 */     dispatchCommand(commandBuf.toString());
/*     */ 
/* 349 */     return 0;
/*     */   }
/*     */ 
/*     */   public void forget(Xid xid)
/*     */     throws XAException
/*     */   {
/*     */   }
/*     */ 
/*     */   public void rollback(Xid xid)
/*     */     throws XAException
/*     */   {
/* 385 */     StringBuffer commandBuf = new StringBuffer();
/* 386 */     commandBuf.append("XA ROLLBACK ");
/* 387 */     commandBuf.append(xidToString(xid));
/*     */     try
/*     */     {
/* 390 */       dispatchCommand(commandBuf.toString());
/*     */     } finally {
/* 392 */       this.underlyingConnection.setInGlobalTx(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void end(Xid xid, int flags)
/*     */     throws XAException
/*     */   {
/* 424 */     StringBuffer commandBuf = new StringBuffer();
/* 425 */     commandBuf.append("XA END ");
/* 426 */     commandBuf.append(xidToString(xid));
/*     */ 
/* 428 */     switch (flags) {
/*     */     case 67108864:
/* 430 */       break;
/*     */     case 33554432:
/* 432 */       commandBuf.append(" SUSPEND");
/* 433 */       break;
/*     */     case 536870912:
/* 435 */       break;
/*     */     default:
/* 437 */       throw new XAException(-5);
/*     */     }
/*     */ 
/* 440 */     dispatchCommand(commandBuf.toString());
/*     */   }
/*     */ 
/*     */   public void start(Xid xid, int flags)
/*     */     throws XAException
/*     */   {
/* 467 */     StringBuffer commandBuf = new StringBuffer();
/* 468 */     commandBuf.append("XA START ");
/* 469 */     commandBuf.append(xidToString(xid));
/*     */ 
/* 471 */     switch (flags) {
/*     */     case 2097152:
/* 473 */       commandBuf.append(" JOIN");
/* 474 */       break;
/*     */     case 134217728:
/* 476 */       commandBuf.append(" RESUME");
/* 477 */       break;
/*     */     case 0:
/* 480 */       break;
/*     */     default:
/* 482 */       throw new XAException(-5);
/*     */     }
/*     */ 
/* 485 */     dispatchCommand(commandBuf.toString());
/*     */ 
/* 487 */     this.underlyingConnection.setInGlobalTx(true);
/*     */   }
/*     */ 
/*     */   public void commit(Xid xid, boolean onePhase)
/*     */     throws XAException
/*     */   {
/* 512 */     StringBuffer commandBuf = new StringBuffer();
/* 513 */     commandBuf.append("XA COMMIT ");
/* 514 */     commandBuf.append(xidToString(xid));
/*     */ 
/* 516 */     if (onePhase) {
/* 517 */       commandBuf.append(" ONE PHASE");
/*     */     }
/*     */     try
/*     */     {
/* 521 */       dispatchCommand(commandBuf.toString());
/*     */     } finally {
/* 523 */       this.underlyingConnection.setInGlobalTx(false);
/*     */     }
/*     */   }
/*     */ 
/*     */   private ResultSet dispatchCommand(String command) throws XAException {
/* 528 */     Statement stmt = null;
/*     */     try
/*     */     {
/* 531 */       if (this.log.isDebugEnabled()) {
/* 532 */         this.log.logDebug("Executing XA statement: " + command);
/*     */       }
/*     */ 
/* 536 */       stmt = this.underlyingConnection.createStatement();
/*     */ 
/* 539 */       stmt.execute(command);
/*     */ 
/* 541 */       ResultSet rs = stmt.getResultSet();
/*     */ 
/* 543 */       localResultSet1 = rs;
/*     */     }
/*     */     catch (SQLException sqlEx)
/*     */     {
/*     */       ResultSet localResultSet1;
/* 545 */       throw mapXAExceptionFromSQLException(sqlEx);
/*     */     } finally {
/* 547 */       if (stmt != null)
/*     */         try {
/* 549 */           stmt.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   protected static XAException mapXAExceptionFromSQLException(SQLException sqlEx) {
/* 558 */     Integer xaCode = (Integer)MYSQL_ERROR_CODES_TO_XA_ERROR_CODES.get(new Integer(sqlEx.getErrorCode()));
/*     */ 
/* 561 */     if (xaCode != null) {
/* 562 */       return new MysqlXAException(xaCode.intValue(), sqlEx.getMessage(), null);
/*     */     }
/*     */ 
/* 566 */     return new MysqlXAException(sqlEx.getMessage(), null);
/*     */   }
/*     */ 
/*     */   private static String xidToString(Xid xid) {
/* 570 */     byte[] gtrid = xid.getGlobalTransactionId();
/*     */ 
/* 572 */     byte[] btrid = xid.getBranchQualifier();
/*     */ 
/* 574 */     int lengthAsString = 6;
/*     */ 
/* 576 */     if (gtrid != null) {
/* 577 */       lengthAsString += 2 * gtrid.length;
/*     */     }
/*     */ 
/* 580 */     if (btrid != null) {
/* 581 */       lengthAsString += 2 * btrid.length;
/*     */     }
/*     */ 
/* 584 */     String formatIdInHex = Integer.toHexString(xid.getFormatId());
/*     */ 
/* 586 */     lengthAsString += formatIdInHex.length();
/* 587 */     lengthAsString += 3;
/*     */ 
/* 589 */     StringBuffer asString = new StringBuffer(lengthAsString);
/*     */ 
/* 591 */     asString.append("0x");
/*     */ 
/* 593 */     if (gtrid != null) {
/* 594 */       for (int i = 0; i < gtrid.length; i++) {
/* 595 */         String asHex = Integer.toHexString(gtrid[i] & 0xFF);
/*     */ 
/* 597 */         if (asHex.length() == 1) {
/* 598 */           asString.append("0");
/*     */         }
/*     */ 
/* 601 */         asString.append(asHex);
/*     */       }
/*     */     }
/*     */ 
/* 605 */     asString.append(",");
/*     */ 
/* 607 */     if (btrid != null) {
/* 608 */       asString.append("0x");
/*     */ 
/* 610 */       for (int i = 0; i < btrid.length; i++) {
/* 611 */         String asHex = Integer.toHexString(btrid[i] & 0xFF);
/*     */ 
/* 613 */         if (asHex.length() == 1) {
/* 614 */           asString.append("0");
/*     */         }
/*     */ 
/* 617 */         asString.append(asHex);
/*     */       }
/*     */     }
/*     */ 
/* 621 */     asString.append(",0x");
/* 622 */     asString.append(formatIdInHex);
/*     */ 
/* 624 */     return asString.toString();
/*     */   }
/*     */ 
/*     */   public synchronized java.sql.Connection getConnection()
/*     */     throws SQLException
/*     */   {
/* 633 */     java.sql.Connection connToWrap = getConnection(false, true);
/*     */ 
/* 635 */     return connToWrap;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  71 */     HashMap temp = new HashMap();
/*     */ 
/*  73 */     temp.put(new Integer(1397), new Integer(-4));
/*  74 */     temp.put(new Integer(1398), new Integer(-5));
/*  75 */     temp.put(new Integer(1399), new Integer(-7));
/*  76 */     temp.put(new Integer(1400), new Integer(-9));
/*  77 */     temp.put(new Integer(1401), new Integer(-3));
/*  78 */     temp.put(new Integer(1402), new Integer(100));
/*     */ 
/*  80 */     MYSQL_ERROR_CODES_TO_XA_ERROR_CODES = Collections.unmodifiableMap(temp);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.jdbc2.optional.MysqlXAConnection
 * JD-Core Version:    0.6.0
 */