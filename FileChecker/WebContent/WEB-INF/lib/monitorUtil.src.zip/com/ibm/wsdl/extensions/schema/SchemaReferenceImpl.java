package com.ibm.wsdl.extensions.schema;

import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaReference;

public class SchemaReferenceImpl
  implements SchemaReference
{
  public static final long serialVersionUID = 1L;
  private String id = null;
  private String schemaLocation = null;
  private Schema referencedSchema = null;

  public String getId()
  {
    return this.id;
  }

  public void setId(String paramString)
  {
    this.id = paramString;
  }

  public String getSchemaLocationURI()
  {
    return this.schemaLocation;
  }

  public void setSchemaLocationURI(String paramString)
  {
    this.schemaLocation = paramString;
  }

  public Schema getReferencedSchema()
  {
    return this.referencedSchema;
  }

  public void setReferencedSchema(Schema paramSchema)
  {
    this.referencedSchema = paramSchema;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.schema.SchemaReferenceImpl
 * JD-Core Version:    0.6.0
 */