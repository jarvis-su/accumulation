package com.ibm.wsdl.extensions.mime;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.extensions.mime.MIMEMultipartRelated;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;

public class MIMEMultipartRelatedImpl
  implements MIMEMultipartRelated
{
  protected QName elementType = MIMEConstants.Q_ELEM_MIME_MULTIPART_RELATED;
  protected Boolean required = null;
  protected List mimeParts = new Vector();
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void addMIMEPart(MIMEPart paramMIMEPart)
  {
    this.mimeParts.add(paramMIMEPart);
  }

  public List getMIMEParts()
  {
    return this.mimeParts;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("MIMEMultipartRelated (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.mimeParts != null)
    {
      Iterator localIterator = this.mimeParts.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.mime.MIMEMultipartRelatedImpl
 * JD-Core Version:    0.6.0
 */