/*     */ package ch.ethz.ssh2.signature;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.digest.SHA1;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import ch.ethz.ssh2.packets.TypesReader;
/*     */ import ch.ethz.ssh2.packets.TypesWriter;
/*     */ import java.io.IOException;
/*     */ import java.math.BigInteger;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class DSASHA1Verify
/*     */ {
/*  21 */   private static final Logger log = Logger.getLogger(DSASHA1Verify.class);
/*     */ 
/*     */   public static DSAPublicKey decodeSSHDSAPublicKey(byte[] key) throws IOException
/*     */   {
/*  25 */     TypesReader tr = new TypesReader(key);
/*     */ 
/*  27 */     String key_format = tr.readString();
/*     */ 
/*  29 */     if (!key_format.equals("ssh-dss")) {
/*  30 */       throw new IllegalArgumentException("This is not a ssh-dss public key!");
/*     */     }
/*  32 */     BigInteger p = tr.readMPINT();
/*  33 */     BigInteger q = tr.readMPINT();
/*  34 */     BigInteger g = tr.readMPINT();
/*  35 */     BigInteger y = tr.readMPINT();
/*     */ 
/*  37 */     if (tr.remain() != 0) {
/*  38 */       throw new IOException("Padding in DSA public key!");
/*     */     }
/*  40 */     return new DSAPublicKey(p, q, g, y);
/*     */   }
/*     */ 
/*     */   public static byte[] encodeSSHDSAPublicKey(DSAPublicKey pk) throws IOException
/*     */   {
/*  45 */     TypesWriter tw = new TypesWriter();
/*     */ 
/*  47 */     tw.writeString("ssh-dss");
/*  48 */     tw.writeMPInt(pk.getP());
/*  49 */     tw.writeMPInt(pk.getQ());
/*  50 */     tw.writeMPInt(pk.getG());
/*  51 */     tw.writeMPInt(pk.getY());
/*     */ 
/*  53 */     return tw.getBytes();
/*     */   }
/*     */ 
/*     */   public static byte[] encodeSSHDSASignature(DSASignature ds)
/*     */   {
/*  58 */     TypesWriter tw = new TypesWriter();
/*     */ 
/*  60 */     tw.writeString("ssh-dss");
/*     */ 
/*  62 */     byte[] r = ds.getR().toByteArray();
/*  63 */     byte[] s = ds.getS().toByteArray();
/*     */ 
/*  65 */     byte[] a40 = new byte[40];
/*     */ 
/*  69 */     int r_copylen = r.length < 20 ? r.length : 20;
/*  70 */     int s_copylen = s.length < 20 ? s.length : 20;
/*     */ 
/*  72 */     System.arraycopy(r, r.length - r_copylen, a40, 20 - r_copylen, r_copylen);
/*  73 */     System.arraycopy(s, s.length - s_copylen, a40, 40 - s_copylen, s_copylen);
/*     */ 
/*  75 */     tw.writeString(a40, 0, 40);
/*     */ 
/*  77 */     return tw.getBytes();
/*     */   }
/*     */ 
/*     */   public static DSASignature decodeSSHDSASignature(byte[] sig) throws IOException
/*     */   {
/*  82 */     TypesReader tr = new TypesReader(sig);
/*     */ 
/*  84 */     String sig_format = tr.readString();
/*     */ 
/*  86 */     if (!sig_format.equals("ssh-dss")) {
/*  87 */       throw new IOException("Peer sent wrong signature format");
/*     */     }
/*  89 */     byte[] rsArray = tr.readByteString();
/*     */ 
/*  91 */     if (rsArray.length != 40) {
/*  92 */       throw new IOException("Peer sent corrupt signature");
/*     */     }
/*  94 */     if (tr.remain() != 0) {
/*  95 */       throw new IOException("Padding in DSA signature!");
/*     */     }
/*     */ 
/*  99 */     byte[] tmp = new byte[20];
/*     */ 
/* 101 */     System.arraycopy(rsArray, 0, tmp, 0, 20);
/* 102 */     BigInteger r = new BigInteger(1, tmp);
/*     */ 
/* 104 */     System.arraycopy(rsArray, 20, tmp, 0, 20);
/* 105 */     BigInteger s = new BigInteger(1, tmp);
/*     */ 
/* 107 */     if (log.isEnabled())
/*     */     {
/* 109 */       log.log(30, "decoded ssh-dss signature: first bytes r(" + (rsArray[0] & 0xFF) + "), s(" + (
/* 110 */         rsArray[20] & 0xFF) + ")");
/*     */     }
/*     */ 
/* 113 */     return new DSASignature(r, s);
/*     */   }
/*     */ 
/*     */   public static boolean verifySignature(byte[] message, DSASignature ds, DSAPublicKey dpk)
/*     */     throws IOException
/*     */   {
/* 120 */     SHA1 md = new SHA1();
/* 121 */     md.update(message);
/* 122 */     byte[] sha_message = new byte[md.getDigestLength()];
/* 123 */     md.digest(sha_message);
/*     */ 
/* 125 */     BigInteger m = new BigInteger(1, sha_message);
/*     */ 
/* 127 */     BigInteger r = ds.getR();
/* 128 */     BigInteger s = ds.getS();
/*     */ 
/* 130 */     BigInteger g = dpk.getG();
/* 131 */     BigInteger p = dpk.getP();
/* 132 */     BigInteger q = dpk.getQ();
/* 133 */     BigInteger y = dpk.getY();
/*     */ 
/* 135 */     BigInteger zero = BigInteger.ZERO;
/*     */ 
/* 137 */     if (log.isEnabled())
/*     */     {
/* 139 */       log.log(60, "ssh-dss signature: m: " + m.toString(16));
/* 140 */       log.log(60, "ssh-dss signature: r: " + r.toString(16));
/* 141 */       log.log(60, "ssh-dss signature: s: " + s.toString(16));
/* 142 */       log.log(60, "ssh-dss signature: g: " + g.toString(16));
/* 143 */       log.log(60, "ssh-dss signature: p: " + p.toString(16));
/* 144 */       log.log(60, "ssh-dss signature: q: " + q.toString(16));
/* 145 */       log.log(60, "ssh-dss signature: y: " + y.toString(16));
/*     */     }
/*     */ 
/* 148 */     if ((zero.compareTo(r) >= 0) || (q.compareTo(r) <= 0))
/*     */     {
/* 150 */       log.log(20, "ssh-dss signature: zero.compareTo(r) >= 0 || q.compareTo(r) <= 0");
/* 151 */       return false;
/*     */     }
/*     */ 
/* 154 */     if ((zero.compareTo(s) >= 0) || (q.compareTo(s) <= 0))
/*     */     {
/* 156 */       log.log(20, "ssh-dss signature: zero.compareTo(s) >= 0 || q.compareTo(s) <= 0");
/* 157 */       return false;
/*     */     }
/*     */ 
/* 160 */     BigInteger w = s.modInverse(q);
/*     */ 
/* 162 */     BigInteger u1 = m.multiply(w).mod(q);
/* 163 */     BigInteger u2 = r.multiply(w).mod(q);
/*     */ 
/* 165 */     u1 = g.modPow(u1, p);
/* 166 */     u2 = y.modPow(u2, p);
/*     */ 
/* 168 */     BigInteger v = u1.multiply(u2).mod(p).mod(q);
/*     */ 
/* 170 */     return v.equals(r);
/*     */   }
/*     */ 
/*     */   public static DSASignature generateSignature(byte[] message, DSAPrivateKey pk, SecureRandom rnd)
/*     */   {
/* 175 */     SHA1 md = new SHA1();
/* 176 */     md.update(message);
/* 177 */     byte[] sha_message = new byte[md.getDigestLength()];
/* 178 */     md.digest(sha_message);
/*     */ 
/* 180 */     BigInteger m = new BigInteger(1, sha_message);
/*     */ 
/* 182 */     int qBitLength = pk.getQ().bitLength();
/*     */     do
/*     */     {
/* 186 */       k = new BigInteger(qBitLength, rnd);
/*     */     }
/* 188 */     while (k.compareTo(pk.getQ()) >= 0);
/*     */ 
/* 190 */     BigInteger r = pk.getG().modPow(k, pk.getP()).mod(pk.getQ());
/*     */ 
/* 192 */     BigInteger k = k.modInverse(pk.getQ()).multiply(m.add(pk.getX().multiply(r)));
/*     */ 
/* 194 */     BigInteger s = k.mod(pk.getQ());
/*     */ 
/* 196 */     return new DSASignature(r, s);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.DSASHA1Verify
 * JD-Core Version:    0.6.0
 */