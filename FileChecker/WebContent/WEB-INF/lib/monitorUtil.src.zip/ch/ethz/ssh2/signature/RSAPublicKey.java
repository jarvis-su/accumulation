/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class RSAPublicKey
/*    */ {
/*    */   BigInteger e;
/*    */   BigInteger n;
/*    */ 
/*    */   public RSAPublicKey(BigInteger e, BigInteger n)
/*    */   {
/* 18 */     this.e = e;
/* 19 */     this.n = n;
/*    */   }
/*    */ 
/*    */   public BigInteger getE()
/*    */   {
/* 24 */     return this.e;
/*    */   }
/*    */ 
/*    */   public BigInteger getN()
/*    */   {
/* 29 */     return this.n;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.RSAPublicKey
 * JD-Core Version:    0.6.0
 */