package com.ibm.wsdl.util.xml;

import java.io.PrintWriter;
import java.util.List;
import java.util.ListIterator;
import java.util.Vector;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.xml.namespace.QName;
import org.w3c.dom.Attr;
import org.w3c.dom.CharacterData;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;

public class DOMUtils
{
  private static String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
  private static final String ATTR_XMLNS = "xmlns";

  public static List getAttributes(Element paramElement)
  {
    String str2 = null;
    Vector localVector = new Vector();
    NamedNodeMap localNamedNodeMap = paramElement.getAttributes();
    for (int i = 0; i < localNamedNodeMap.getLength(); i++)
    {
      String str1 = localNamedNodeMap.item(i).getNodeName();
      str2 = localNamedNodeMap.item(i).getPrefix();
      if (("xmlns".equals(str1)) || ("xmlns".equals(str2)))
        continue;
      localVector.add(localNamedNodeMap.item(i));
    }
    return localVector;
  }

  public static String getAttribute(Element paramElement, String paramString)
  {
    String str = null;
    Attr localAttr = paramElement.getAttributeNode(paramString);
    if (localAttr != null)
      str = localAttr.getValue();
    return str;
  }

  public static String getAttribute(Element paramElement, String paramString, List paramList)
  {
    String str = null;
    Attr localAttr = paramElement.getAttributeNode(paramString);
    if (localAttr != null)
    {
      str = localAttr.getValue();
      paramList.remove(localAttr);
    }
    return str;
  }

  public static String getAttributeNS(Element paramElement, String paramString1, String paramString2)
  {
    String str = null;
    Attr localAttr = paramElement.getAttributeNodeNS(paramString1, paramString2);
    if (localAttr != null)
      str = localAttr.getValue();
    return str;
  }

  public static String getChildCharacterData(Element paramElement)
  {
    if (paramElement == null)
      return null;
    Node localNode = paramElement.getFirstChild();
    StringBuffer localStringBuffer = new StringBuffer();
    while (localNode != null)
    {
      switch (localNode.getNodeType())
      {
      case 3:
      case 4:
        CharacterData localCharacterData = (CharacterData)localNode;
        localStringBuffer.append(localCharacterData.getData());
      }
      localNode = localNode.getNextSibling();
    }
    return localStringBuffer.toString();
  }

  public static Element getFirstChildElement(Element paramElement)
  {
    for (Node localNode = paramElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
      if (localNode.getNodeType() == 1)
        return (Element)localNode;
    return null;
  }

  public static Element getNextSiblingElement(Element paramElement)
  {
    for (Node localNode = paramElement.getNextSibling(); localNode != null; localNode = localNode.getNextSibling())
      if (localNode.getNodeType() == 1)
        return (Element)localNode;
    return null;
  }

  public static Element findChildElementWithAttribute(Element paramElement, String paramString1, String paramString2)
  {
    for (Node localNode = paramElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
      if ((localNode.getNodeType() == 1) && (paramString2.equals(getAttribute((Element)localNode, paramString1))))
        return (Element)localNode;
    return null;
  }

  public static int countKids(Element paramElement, short paramShort)
  {
    int i = 0;
    for (Node localNode = paramElement.getFirstChild(); localNode != null; localNode = localNode.getNextSibling())
    {
      if (localNode.getNodeType() != paramShort)
        continue;
      i++;
    }
    return i;
  }

  public static String getNamespaceURIFromPrefix(Node paramNode, String paramString)
  {
    int i = paramNode.getNodeType();
    Object localObject = null;
    switch (i)
    {
    case 2:
      localObject = ((Attr)paramNode).getOwnerElement();
      break;
    case 1:
      localObject = paramNode;
      break;
    }
    Element localElement;
    for (localObject = paramNode.getParentNode(); (localObject != null) && (((Node)localObject).getNodeType() == 1); localObject = localElement.getParentNode())
    {
      localElement = (Element)localObject;
      String str = paramString == null ? getAttribute(localElement, "xmlns") : getAttributeNS(localElement, NS_URI_XMLNS, paramString);
      if (str != null)
        return str;
    }
    return (String)null;
  }

  public static QName getQName(String paramString, Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    int i = paramString.indexOf(':');
    String str1 = i != -1 ? paramString.substring(0, i) : null;
    String str2 = paramString.substring(i + 1);
    String str3 = getNamespaceURIFromPrefix(paramElement, str1);
    if (str3 != null)
    {
      registerUniquePrefix(str1, str3, paramDefinition);
      return new QName(str3, str2);
    }
    String str4 = str1 == null ? "NO_PREFIX_SPECIFIED" : "UNBOUND_PREFIX";
    WSDLException localWSDLException = new WSDLException(str4, "Unable to determine namespace of '" + paramString + "'.");
    localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
    throw localWSDLException;
  }

  public static void registerUniquePrefix(String paramString1, String paramString2, Definition paramDefinition)
  {
    String str = paramDefinition.getNamespace(paramString1);
    if ((str != null) && (str.equals(paramString2)))
      return;
    while ((str != null) && (!str.equals(paramString2)))
    {
      paramString1 = paramString1 + "_";
      str = paramDefinition.getNamespace(paramString1);
    }
    paramDefinition.addNamespace(paramString1, paramString2);
  }

  public static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, boolean paramBoolean, Definition paramDefinition)
    throws WSDLException
  {
    String str = getAttribute(paramElement, paramString1);
    if (str != null)
      return getQName(str, paramElement, paramDefinition);
    if (paramBoolean)
    {
      WSDLException localWSDLException = new WSDLException("INVALID_WSDL", "The '" + paramString1 + "' attribute must be " + "specified for every " + paramString2 + " element.");
      localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      throw localWSDLException;
    }
    return null;
  }

  public static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, boolean paramBoolean, Definition paramDefinition, List paramList)
    throws WSDLException
  {
    String str = null;
    str = getAttribute(paramElement, paramString1, paramList);
    if (str != null)
      return getQName(str, paramElement, paramDefinition);
    if (paramBoolean)
    {
      WSDLException localWSDLException = new WSDLException("INVALID_WSDL", "The '" + paramString1 + "' attribute must be " + "specified for every " + paramString2 + " element.");
      localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      throw localWSDLException;
    }
    return null;
  }

  public static void throwWSDLException(Element paramElement)
    throws WSDLException
  {
    String str = QNameUtils.newQName(paramElement).toString();
    WSDLException localWSDLException = new WSDLException("INVALID_WSDL", "Encountered unexpected element '" + str + "'.");
    localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
    throw localWSDLException;
  }

  public static void throwWSDLException(Element paramElement, List paramList)
    throws WSDLException
  {
    String str = QNameUtils.newQName(paramElement).toString();
    StringBuffer localStringBuffer = new StringBuffer();
    ListIterator localListIterator = paramList.listIterator();
    while (localListIterator.hasNext())
    {
      localObject = QNameUtils.newQName((Attr)localListIterator.next()).toString();
      localStringBuffer.append((String)localObject);
      localStringBuffer.append(localListIterator.hasNext() ? " " : "");
    }
    Object localObject = new WSDLException("INVALID_WSDL", "Element '" + str + "' contained unexpected attributes: '" + localStringBuffer.toString() + "'");
    ((WSDLException)localObject).setLocation(XPathUtils.getXPathExprFromNode(paramElement));
    throw ((Throwable)localObject);
  }

  public static void printAttribute(String paramString1, String paramString2, PrintWriter paramPrintWriter)
  {
    if (paramString2 != null)
      paramPrintWriter.print(' ' + paramString1 + "=\"" + cleanString(paramString2) + '"');
  }

  public static void printQualifiedAttribute(QName paramQName, String paramString, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramQName != null)
      printAttribute(getQualifiedValue(paramQName.getNamespaceURI(), paramQName.getLocalPart(), paramDefinition), paramString, paramPrintWriter);
  }

  public static void printQualifiedAttribute(QName paramQName1, QName paramQName2, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramQName2 != null)
      printAttribute(getQualifiedValue(paramQName1.getNamespaceURI(), paramQName1.getLocalPart(), paramDefinition), getQualifiedValue(paramQName2.getNamespaceURI(), paramQName2.getLocalPart(), paramDefinition), paramPrintWriter);
  }

  public static void printQualifiedAttribute(String paramString, QName paramQName, Definition paramDefinition, PrintWriter paramPrintWriter)
    throws WSDLException
  {
    if (paramQName != null)
      printAttribute(paramString, getQualifiedValue(paramQName.getNamespaceURI(), paramQName.getLocalPart(), paramDefinition), paramPrintWriter);
  }

  public static String getQualifiedValue(String paramString1, String paramString2, Definition paramDefinition)
    throws WSDLException
  {
    String str = null;
    if ((paramString1 != null) && (!paramString1.equals("")))
      str = getPrefix(paramString1, paramDefinition);
    return ((str != null) && (!str.equals("")) ? str + ":" : "") + paramString2;
  }

  public static String getPrefix(String paramString, Definition paramDefinition)
    throws WSDLException
  {
    String str = paramDefinition.getPrefix(paramString);
    if (str == null)
      throw new WSDLException("OTHER_ERROR", "Can't find prefix for '" + paramString + "'. Namespace prefixes must be set on the" + " Definition object using the " + "addNamespace(...) method.");
    return str;
  }

  public static String cleanString(String paramString)
  {
    if (paramString == null)
      return "";
    StringBuffer localStringBuffer = new StringBuffer();
    char[] arrayOfChar = paramString.toCharArray();
    int i = 0;
    for (int j = 0; j < arrayOfChar.length; j++)
      if (i == 0)
      {
        switch (arrayOfChar[j])
        {
        case '&':
          localStringBuffer.append("&amp;");
          break;
        case '"':
          localStringBuffer.append("&quot;");
          break;
        case '\'':
          localStringBuffer.append("&apos;");
          break;
        case '<':
          if (arrayOfChar.length >= j + 9)
          {
            String str = new String(arrayOfChar, j, 9);
            if (str.equals("<![CDATA["))
            {
              localStringBuffer.append(str);
              j += 8;
              i = 1;
              continue;
            }
            localStringBuffer.append("&lt;");
            continue;
          }
          localStringBuffer.append("&lt;");
          break;
        case '>':
          localStringBuffer.append("&gt;");
          break;
        default:
          localStringBuffer.append(arrayOfChar[j]);
          break;
        }
      }
      else
      {
        localStringBuffer.append(arrayOfChar[j]);
        if ((arrayOfChar[j] != '>') || (arrayOfChar[(j - 1)] != ']') || (arrayOfChar[(j - 2)] != ']'))
          continue;
        i = 0;
      }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.xml.DOMUtils
 * JD-Core Version:    0.6.0
 */