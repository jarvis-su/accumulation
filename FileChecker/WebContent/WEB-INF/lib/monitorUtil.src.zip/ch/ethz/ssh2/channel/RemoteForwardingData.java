package ch.ethz.ssh2.channel;

public class RemoteForwardingData
{
  public String bindAddress;
  public int bindPort;
  String targetAddress;
  int targetPort;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.RemoteForwardingData
 * JD-Core Version:    0.6.0
 */