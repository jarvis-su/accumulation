/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import java.text.SimpleDateFormat;
/*    */ import java.util.Calendar;
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class VarDate extends DBVar
/*    */ {
/*    */   private Properties _runtimeEnv;
/*    */ 
/*    */   protected Vector<String> resolveInternal(VarCache c, Properties env)
/*    */     throws Exception
/*    */   {
/* 29 */     this._runtimeEnv = env;
/* 30 */     Vector v = new Vector();
/* 31 */     String dateFormat = getInitialValue();
/* 32 */     Calendar cal = getCalendar();
/*    */ 
/* 34 */     if (dateFormat.endsWith("MM")) {
/* 35 */       cal.set(5, 1);
/*    */     }
/* 37 */     while ((dateFormat.length() > 0) && (dateFormat.charAt(0) == '-')) {
/* 38 */       cal.add(5, -1);
/* 39 */       dateFormat = dateFormat.substring(1);
/*    */     }
/* 41 */     SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
/* 42 */     v.add(sdf.format(cal.getTime()));
/* 43 */     return v;
/*    */   }
/*    */ 
/*    */   public Calendar getCalendar() {
/* 47 */     Calendar c1 = (Calendar)this._runtimeEnv.get("DATEFOR");
/*    */     Calendar c;
/*    */     Calendar c;
/* 49 */     if (c1 == null)
/* 50 */       c = Calendar.getInstance();
/*    */     else
/* 52 */       c = (Calendar)c1.clone();
/* 53 */     return c;
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) throws Exception {
/* 57 */     VarDate v = new VarDate();
/* 58 */     v.setInitialValue("---yyyyMMdd");
/* 59 */     VarCache.getInstance().putVar("{TODAY}", v);
/* 60 */     System.out.print(VarCache.resolve("{TODAY}"));
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.smj.dbvariable.VarDate
 * JD-Core Version:    0.6.0
 */