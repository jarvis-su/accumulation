/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public abstract class DBVar
/*    */ {
/*  7 */   private String _initialVal = null;
/*  8 */   private Vector<String> _values = new Vector();
/*    */ 
/* 10 */   private DBVar.Status _status = DBVar.Status.NADA;
/*    */ 
/*    */   public DBVar() {
/* 13 */     this(null);
/*    */   }
/*    */ 
/*    */   public DBVar(String s) {
/* 17 */     setInitialValue(s);
/*    */   }
/*    */ 
/*    */   public final void setInitialValue(String val) {
/* 21 */     this._initialVal = val;
/*    */   }
/*    */ 
/*    */   public final String getInitialValue() {
/* 25 */     return this._initialVal;
/*    */   }
/*    */ 
/*    */   public final boolean isResolved() {
/* 29 */     return this._status == DBVar.Status.RESOLVED;
/*    */   }
/*    */ 
/*    */   public final boolean isDirty() {
/* 33 */     return this._status == DBVar.Status.DIRTY;
/*    */   }
/*    */ 
/*    */   public final Vector<String> getValues() {
/* 37 */     return this._values;
/*    */   }
/*    */ 
/*    */   protected final void addValue(String val) {
/* 41 */     this._values.add(val);
/*    */   }
/*    */ 
/*    */   protected final void deleteValue(String val) {
/* 45 */     this._values.remove(val);
/*    */   }
/*    */ 
/*    */   protected final void updateValue(int loc, String val) {
/* 49 */     this._values.set(loc, val);
/*    */   }
/*    */ 
/*    */   protected final Vector<String> resolve(VarCache c, Properties env) throws Exception {
/* 53 */     this._status = DBVar.Status.DIRTY;
/* 54 */     Vector ret = resolveInternal(c, env);
/* 55 */     this._status = DBVar.Status.RESOLVED;
/* 56 */     return ret;
/*    */   }
/*    */ 
/*    */   protected abstract Vector<String> resolveInternal(VarCache paramVarCache, Properties paramProperties)
/*    */     throws Exception;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.DBVar
 * JD-Core Version:    0.6.0
 */