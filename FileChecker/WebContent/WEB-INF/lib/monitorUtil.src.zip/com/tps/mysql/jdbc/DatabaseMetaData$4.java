/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ class DatabaseMetaData$4 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final Statement val$stmt;
/*      */   private final String val$table;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 2613 */     ResultSet fkresults = null;
/*      */     try
/*      */     {
/* 2620 */       if (this.this$0.conn.versionMeetsMinimum(3, 23, 50))
/*      */       {
/* 2623 */         fkresults = this.this$0.extractForeignKeyFromCreateTable(catalogStr.toString(), null);
/*      */       }
/*      */       else {
/* 2626 */         StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS FROM ");
/*      */ 
/* 2628 */         queryBuf.append(this.this$0.quotedId);
/* 2629 */         queryBuf.append(catalogStr.toString());
/* 2630 */         queryBuf.append(this.this$0.quotedId);
/*      */ 
/* 2632 */         fkresults = this.val$stmt.executeQuery(queryBuf.toString());
/*      */       }
/*      */ 
/* 2637 */       String tableNameWithCase = DatabaseMetaData.access$100(this.this$0, this.val$table);
/*      */ 
/* 2643 */       while (fkresults.next()) {
/* 2644 */         String tableType = fkresults.getString("Type");
/*      */ 
/* 2646 */         if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */         {
/* 2650 */           String comment = fkresults.getString("Comment").trim();
/*      */ 
/* 2653 */           if (comment != null) {
/* 2654 */             StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */ 
/* 2657 */             if (commentTokens.hasMoreTokens()) {
/* 2658 */               commentTokens.nextToken();
/*      */ 
/* 2663 */               while (commentTokens.hasMoreTokens()) {
/* 2664 */                 String keys = commentTokens.nextToken();
/*      */ 
/* 2666 */                 DatabaseMetaData.access$500(this.this$0, catalogStr.toString(), tableNameWithCase, keys, this.val$rows, fkresults.getString("Name"));
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */     finally
/*      */     {
/* 2680 */       if (fkresults != null) {
/*      */         try {
/* 2682 */           fkresults.close();
/*      */         } catch (SQLException sqlEx) {
/* 2684 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */ 
/* 2688 */         fkresults = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.4
 * JD-Core Version:    0.6.0
 */