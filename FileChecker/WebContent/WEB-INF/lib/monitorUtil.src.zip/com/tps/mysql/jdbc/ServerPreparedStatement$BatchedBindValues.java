/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ class ServerPreparedStatement$BatchedBindValues
/*    */ {
/*    */   ServerPreparedStatement.BindValue[] batchedParameterValues;
/*    */ 
/*    */   ServerPreparedStatement$BatchedBindValues(ServerPreparedStatement.BindValue[] paramVals)
/*    */   {
/* 73 */     int numParams = paramVals.length;
/*    */ 
/* 75 */     this.batchedParameterValues = new ServerPreparedStatement.BindValue[numParams];
/*    */ 
/* 77 */     for (int i = 0; i < numParams; i++)
/* 78 */       this.batchedParameterValues[i] = new ServerPreparedStatement.BindValue(paramVals[i]);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ServerPreparedStatement.BatchedBindValues
 * JD-Core Version:    0.6.0
 */