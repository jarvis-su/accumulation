/*     */ package com.acs.fileChecker.fileserver;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.PrintStream;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ public class Validate
/*     */ {
/*     */   private String _error;
/*     */   private String _state;
/*     */   private RandomAccessFile raf;
/*     */   private File _curFile;
/*     */   public static final int FTYPE_OTHER = 0;
/*     */   public static final int FTYPE_TXT = 1;
/*     */   public static final int FTYPE_DAT = 2;
/*     */   public static final int FTYPE_PDF = 4;
/*     */   public static final int FTYPE_LOG = 8;
/*     */   public static final int FTYPE_SUM = 16;
/*     */   public static final int FTYPE_CARDMAILER = 32;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  28 */     File f = new File(args[0]);
/*  29 */     Validate v = new Validate(f);
/*  30 */     System.out.println(f.toString() + " " + v.validateFile());
/*     */   }
/*     */ 
/*     */   public Validate(String fileName) {
/*  34 */     this._curFile = new File(fileName);
/*  35 */     this._error = null;
/*     */   }
/*     */ 
/*     */   public Validate(File f) {
/*  39 */     this._curFile = f;
/*  40 */     this._error = null;
/*     */   }
/*     */ 
/*     */   public Validate() {
/*  44 */     this(null);
/*     */   }
/*     */ 
/*     */   public String validateTXT() {
/*  48 */     this._state = validateGeneral();
/*  49 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateDAT() {
/*  53 */     this._state = validateGeneral();
/*  54 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateLOG()
/*     */   {
/*  59 */     this._state = validateGeneral();
/*  60 */     if (!this._state.equals("")) return this._state;
/*     */ 
/*  62 */     if (!isTrailer("SQR: End of Run.")) this._state = "has a bad trailer";
/*     */ 
/*  64 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateSUM()
/*     */   {
/*  69 */     this._state = validateGeneral();
/*  70 */     if (!this._state.equals("")) return this._state;
/*     */ 
/*  72 */     if (isInFile("^\\s*Total records rejected\\s*:\\s*[1-9][0-9]*")) this._state = "rejected records";
/*     */ 
/*  74 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validatePDF()
/*     */   {
/*  79 */     this._state = validateGeneral();
/*  80 */     if (!this._state.equals("")) return this._state;
/*     */ 
/*  82 */     if (!isTrailer(".*%%EOF\\s*")) this._state = "has a bad trailer";
/*     */ 
/*  84 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateCARDMAILER() {
/*  88 */     this._state = validateGeneral();
/*  89 */     if (!this._state.equals("")) return this._state;
/*     */ 
/*  92 */     if (!isTrailer("T[0-9]*")) this._state = "has a bad trailer";
/*  93 */     return this._state;
/*     */   }
/*     */ 
/*     */   public String validateGeneral()
/*     */   {
/*     */     String retCode;
/*     */     String retCode;
/*  99 */     if (!this._curFile.exists()) {
/* 100 */       retCode = "doesn't exist";
/*     */     }
/*     */     else
/*     */     {
/*     */       String retCode;
/* 102 */       if (this._curFile.length() == 0L)
/* 103 */         retCode = "is zero length";
/*     */       else
/* 105 */         retCode = ""; 
/*     */     }
/* 106 */     return retCode;
/*     */   }
/*     */ 
/*     */   public int getFileType()
/*     */   {
/* 111 */     String name = this._curFile.toString();
/* 112 */     String type = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
/*     */     int t;
/*     */     int t;
/* 114 */     if (name.endsWith("CARDMAILER")) { t = 32;
/*     */     }
/*     */     else
/*     */     {
/* 115 */       int t;
/* 115 */       if (type.equals("txt")) { t = 1;
/*     */       }
/*     */       else
/*     */       {
/* 116 */         int t;
/* 116 */         if (type.equals("dat")) { t = 2;
/*     */         }
/*     */         else
/*     */         {
/* 117 */           int t;
/* 117 */           if (type.equals("pdf")) { t = 4;
/*     */           }
/*     */           else
/*     */           {
/* 118 */             int t;
/* 118 */             if (type.equals("log")) { t = 8;
/*     */             }
/*     */             else
/*     */             {
/* 119 */               int t;
/* 119 */               if (type.equals("summary")) t = 16; else
/* 120 */                 t = 0; 
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 121 */     return t;
/*     */   }
/*     */ 
/*     */   public String validateFile() {
/* 125 */     int type = getFileType();
/* 126 */     switch (type) {
/*     */     case 32:
/* 128 */       return validateCARDMAILER();
/*     */     case 1:
/* 130 */       return validateTXT();
/*     */     case 2:
/* 132 */       return validateDAT();
/*     */     case 4:
/* 134 */       return validatePDF();
/*     */     case 16:
/* 136 */       return validateSUM();
/*     */     case 8:
/* 138 */       return validateLOG();
/*     */     }
/* 140 */     return validateGeneral();
/*     */   }
/*     */ 
/*     */   public long getFileSize()
/*     */   {
/* 155 */     long tmp = this._curFile.length();
/*     */ 
/* 159 */     return tmp;
/*     */   }
/*     */ 
/*     */   public String getFileMod() {
/* 163 */     SimpleDateFormat time = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
/*     */ 
/* 167 */     Date d = new Date(this._curFile.lastModified());
/* 168 */     return time.format(d);
/*     */   }
/*     */ 
/*     */   private boolean isInFile(String str) {
/* 172 */     boolean match = false;
/*     */     try
/*     */     {
/* 175 */       this.raf = new RandomAccessFile(this._curFile, "r");
/* 176 */       String line = this.raf.readLine();
/* 177 */       while (line != null) {
/* 178 */         if (line.matches(str)) {
/* 179 */           match = true;
/* 180 */           break;
/*     */         }
/* 182 */         line = this.raf.readLine();
/*     */       }
/* 184 */       this.raf.close();
/*     */     } catch (Exception localException) {
/*     */     }
/* 187 */     return match;
/*     */   }
/*     */ 
/*     */   private boolean isTrailer(String str) {
/* 191 */     boolean match = false;
/*     */     try
/*     */     {
/* 194 */       this.raf = new RandomAccessFile(this._curFile, "r");
/*     */ 
/* 197 */       this.raf.seek(this._curFile.length() - 1L);
/* 198 */       String line = readLineReverse();
/* 199 */       if (line.matches(str)) {
/* 200 */         match = true;
/*     */       }
/* 202 */       this.raf.close();
/*     */     } catch (Exception localException) {
/*     */     }
/* 205 */     return match;
/*     */   }
/*     */ 
/*     */   public String getError() {
/* 209 */     return this._error;
/*     */   }
/*     */ 
/*     */   public String readLineReverse() throws Exception {
/* 213 */     long position = this.raf.getFilePointer();
/*     */ 
/* 216 */     String finalLine = "";
/*     */ 
/* 218 */     boolean justStarting = true;
/*     */ 
/* 222 */     if (position < 0L) {
/* 223 */       return null;
/*     */     }
/*     */ 
/* 228 */     while (position >= 0L)
/*     */     {
/* 232 */       this.raf.seek(position);
/*     */ 
/* 235 */       int thisCode = this.raf.readByte();
/* 236 */       char thisChar = (char)thisCode;
/*     */ 
/* 239 */       if ((thisCode == 13) || (thisCode == 10))
/*     */       {
/* 242 */         this.raf.seek(position - 1L);
/* 243 */         int nextCode = this.raf.readByte();
/* 244 */         if (((thisCode == 10) && (nextCode == 13)) || ((thisCode == 13) && (nextCode == 10)))
/*     */         {
/* 246 */           position -= 1L;
/*     */         }
/* 248 */         else if (justStarting)
/*     */         {
/* 250 */           position -= 1L;
/* 251 */           finalLine = (char)nextCode + finalLine;
/*     */         }
/*     */ 
/* 254 */         if (!justStarting)
/*     */         {
/* 257 */           position -= 1L;
/* 258 */           break;
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 263 */         finalLine = thisChar + finalLine;
/*     */       }
/*     */ 
/* 266 */       position -= 1L;
/* 267 */       justStarting = false;
/*     */     }
/*     */ 
/* 270 */     return finalLine;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.fileserver.Validate
 * JD-Core Version:    0.6.0
 */