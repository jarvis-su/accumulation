/*     */ package ch.ethz.ssh2.transport;
/*     */ 
/*     */ import ch.ethz.ssh2.crypto.cipher.BlockCipher;
/*     */ import ch.ethz.ssh2.crypto.cipher.CipherInputStream;
/*     */ import ch.ethz.ssh2.crypto.cipher.CipherOutputStream;
/*     */ import ch.ethz.ssh2.crypto.cipher.NullCipher;
/*     */ import ch.ethz.ssh2.crypto.digest.MAC;
/*     */ import ch.ethz.ssh2.log.Logger;
/*     */ import ch.ethz.ssh2.packets.Packets;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.security.SecureRandom;
/*     */ 
/*     */ public class TransportConnection
/*     */ {
/*  25 */   private static final Logger log = Logger.getLogger(TransportConnection.class);
/*     */ 
/*  27 */   int send_seq_number = 0;
/*     */ 
/*  29 */   int recv_seq_number = 0;
/*     */   CipherInputStream cis;
/*     */   CipherOutputStream cos;
/*  35 */   boolean useRandomPadding = false;
/*     */   MAC send_mac;
/*     */   byte[] send_mac_buffer;
/*  43 */   int send_padd_blocksize = 8;
/*     */   MAC recv_mac;
/*     */   byte[] recv_mac_buffer;
/*     */   byte[] recv_mac_buffer_cmp;
/*  51 */   int recv_padd_blocksize = 8;
/*     */ 
/*  55 */   final byte[] send_padding_buffer = new byte[256];
/*     */ 
/*  57 */   final byte[] send_packet_header_buffer = new byte[5];
/*     */ 
/*  59 */   final byte[] recv_padding_buffer = new byte[256];
/*     */ 
/*  61 */   final byte[] recv_packet_header_buffer = new byte[5];
/*     */ 
/*  63 */   boolean recv_packet_header_present = false;
/*     */   ClientServerHello csh;
/*     */   final SecureRandom rnd;
/*     */ 
/*     */   public TransportConnection(InputStream is, OutputStream os, SecureRandom rnd)
/*     */   {
/*  71 */     this.cis = new CipherInputStream(new NullCipher(), is);
/*  72 */     this.cos = new CipherOutputStream(new NullCipher(), os);
/*  73 */     this.rnd = rnd;
/*     */   }
/*     */ 
/*     */   public void changeRecvCipher(BlockCipher bc, MAC mac)
/*     */   {
/*  78 */     this.cis.changeCipher(bc);
/*  79 */     this.recv_mac = mac;
/*  80 */     this.recv_mac_buffer = (mac != null ? new byte[mac.size()] : null);
/*  81 */     this.recv_mac_buffer_cmp = (mac != null ? new byte[mac.size()] : null);
/*  82 */     this.recv_padd_blocksize = bc.getBlockSize();
/*  83 */     if (this.recv_padd_blocksize < 8)
/*  84 */       this.recv_padd_blocksize = 8;
/*     */   }
/*     */ 
/*     */   public void changeSendCipher(BlockCipher bc, MAC mac)
/*     */   {
/*  89 */     if (!(bc instanceof NullCipher))
/*     */     {
/*  92 */       this.useRandomPadding = true;
/*     */     }
/*     */ 
/*  96 */     this.cos.changeCipher(bc);
/*  97 */     this.send_mac = mac;
/*  98 */     this.send_mac_buffer = (mac != null ? new byte[mac.size()] : null);
/*  99 */     this.send_padd_blocksize = bc.getBlockSize();
/* 100 */     if (this.send_padd_blocksize < 8)
/* 101 */       this.send_padd_blocksize = 8;
/*     */   }
/*     */ 
/*     */   public void sendMessage(byte[] message) throws IOException
/*     */   {
/* 106 */     sendMessage(message, 0, message.length, 0);
/*     */   }
/*     */ 
/*     */   public void sendMessage(byte[] message, int off, int len) throws IOException
/*     */   {
/* 111 */     sendMessage(message, off, len, 0);
/*     */   }
/*     */ 
/*     */   public int getPacketOverheadEstimate()
/*     */   {
/* 117 */     return 9 + (this.send_padd_blocksize - 1) + this.send_mac_buffer.length;
/*     */   }
/*     */ 
/*     */   public void sendMessage(byte[] message, int off, int len, int padd) throws IOException
/*     */   {
/* 122 */     if (padd < 4)
/* 123 */       padd = 4;
/* 124 */     else if (padd > 64) {
/* 125 */       padd = 64;
/*     */     }
/* 127 */     int packet_len = 5 + len + padd;
/*     */ 
/* 129 */     int slack = packet_len % this.send_padd_blocksize;
/*     */ 
/* 131 */     if (slack != 0)
/*     */     {
/* 133 */       packet_len += this.send_padd_blocksize - slack;
/*     */     }
/*     */ 
/* 136 */     if (packet_len < 16) {
/* 137 */       packet_len = 16;
/*     */     }
/* 139 */     int padd_len = packet_len - (5 + len);
/*     */ 
/* 141 */     if (this.useRandomPadding)
/*     */     {
/* 143 */       for (int i = 0; i < padd_len; i += 4)
/*     */       {
/* 153 */         int r = this.rnd.nextInt();
/* 154 */         this.send_padding_buffer[i] = (byte)r;
/* 155 */         this.send_padding_buffer[(i + 1)] = (byte)(r >> 8);
/* 156 */         this.send_padding_buffer[(i + 2)] = (byte)(r >> 16);
/* 157 */         this.send_padding_buffer[(i + 3)] = (byte)(r >> 24);
/*     */       }
/*     */ 
/*     */     }
/*     */     else
/*     */     {
/* 163 */       for (int i = 0; i < padd_len; i++) {
/* 164 */         this.send_padding_buffer[i] = 0;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 171 */     this.send_packet_header_buffer[0] = (byte)(packet_len - 4 >> 24);
/* 172 */     this.send_packet_header_buffer[1] = (byte)(packet_len - 4 >> 16);
/* 173 */     this.send_packet_header_buffer[2] = (byte)(packet_len - 4 >> 8);
/* 174 */     this.send_packet_header_buffer[3] = (byte)(packet_len - 4);
/* 175 */     this.send_packet_header_buffer[4] = (byte)padd_len;
/*     */ 
/* 177 */     this.cos.write(this.send_packet_header_buffer, 0, 5);
/* 178 */     this.cos.write(message, off, len);
/* 179 */     this.cos.write(this.send_padding_buffer, 0, padd_len);
/*     */ 
/* 181 */     if (this.send_mac != null)
/*     */     {
/* 183 */       this.send_mac.initMac(this.send_seq_number);
/* 184 */       this.send_mac.update(this.send_packet_header_buffer, 0, 5);
/* 185 */       this.send_mac.update(message, off, len);
/* 186 */       this.send_mac.update(this.send_padding_buffer, 0, padd_len);
/*     */ 
/* 188 */       this.send_mac.getMac(this.send_mac_buffer, 0);
/* 189 */       this.cos.writePlain(this.send_mac_buffer, 0, this.send_mac_buffer.length);
/*     */     }
/*     */ 
/* 192 */     this.cos.flush();
/*     */ 
/* 194 */     if (log.isEnabled())
/*     */     {
/* 196 */       log.log(90, "Sent " + Packets.getMessageName(message[off] & 0xFF) + " " + len + " bytes payload");
/*     */     }
/*     */ 
/* 199 */     this.send_seq_number += 1;
/*     */   }
/*     */ 
/*     */   public int peekNextMessageLength() throws IOException
/*     */   {
/* 204 */     if (!this.recv_packet_header_present)
/*     */     {
/* 206 */       this.cis.read(this.recv_packet_header_buffer, 0, 5);
/* 207 */       this.recv_packet_header_present = true;
/*     */     }
/*     */ 
/* 210 */     int packet_length = (this.recv_packet_header_buffer[0] & 0xFF) << 24 | 
/* 211 */       (this.recv_packet_header_buffer[1] & 0xFF) << 16 | (this.recv_packet_header_buffer[2] & 0xFF) << 8 | 
/* 212 */       this.recv_packet_header_buffer[3] & 0xFF;
/*     */ 
/* 214 */     int padding_length = this.recv_packet_header_buffer[4] & 0xFF;
/*     */ 
/* 216 */     if ((packet_length > 35000) || (packet_length < 12)) {
/* 217 */       throw new IOException("Illegal packet size! (" + packet_length + ")");
/*     */     }
/* 219 */     int payload_length = packet_length - padding_length - 1;
/*     */ 
/* 221 */     if (payload_length < 0) {
/* 222 */       throw new IOException("Illegal padding_length in packet from remote (" + padding_length + ")");
/*     */     }
/* 224 */     return payload_length;
/*     */   }
/*     */ 
/*     */   public int receiveMessage(byte[] buffer, int off, int len) throws IOException
/*     */   {
/* 229 */     if (!this.recv_packet_header_present)
/*     */     {
/* 231 */       this.cis.read(this.recv_packet_header_buffer, 0, 5);
/*     */     }
/*     */     else {
/* 234 */       this.recv_packet_header_present = false;
/*     */     }
/* 236 */     int packet_length = (this.recv_packet_header_buffer[0] & 0xFF) << 24 | 
/* 237 */       (this.recv_packet_header_buffer[1] & 0xFF) << 16 | (this.recv_packet_header_buffer[2] & 0xFF) << 8 | 
/* 238 */       this.recv_packet_header_buffer[3] & 0xFF;
/*     */ 
/* 240 */     int padding_length = this.recv_packet_header_buffer[4] & 0xFF;
/*     */ 
/* 242 */     if ((packet_length > 35000) || (packet_length < 12)) {
/* 243 */       throw new IOException("Illegal packet size! (" + packet_length + ")");
/*     */     }
/* 245 */     int payload_length = packet_length - padding_length - 1;
/*     */ 
/* 247 */     if (payload_length < 0) {
/* 248 */       throw new IOException("Illegal padding_length in packet from remote (" + padding_length + ")");
/*     */     }
/* 250 */     if (payload_length >= len) {
/* 251 */       throw new IOException("Receive buffer too small (" + len + ", need " + payload_length + ")");
/*     */     }
/* 253 */     this.cis.read(buffer, off, payload_length);
/* 254 */     this.cis.read(this.recv_padding_buffer, 0, padding_length);
/*     */ 
/* 256 */     if (this.recv_mac != null)
/*     */     {
/* 258 */       this.cis.readPlain(this.recv_mac_buffer, 0, this.recv_mac_buffer.length);
/*     */ 
/* 260 */       this.recv_mac.initMac(this.recv_seq_number);
/* 261 */       this.recv_mac.update(this.recv_packet_header_buffer, 0, 5);
/* 262 */       this.recv_mac.update(buffer, off, payload_length);
/* 263 */       this.recv_mac.update(this.recv_padding_buffer, 0, padding_length);
/* 264 */       this.recv_mac.getMac(this.recv_mac_buffer_cmp, 0);
/*     */ 
/* 266 */       for (int i = 0; i < this.recv_mac_buffer.length; i++)
/*     */       {
/* 268 */         if (this.recv_mac_buffer[i] != this.recv_mac_buffer_cmp[i]) {
/* 269 */           throw new IOException("Remote sent corrupt MAC.");
/*     */         }
/*     */       }
/*     */     }
/* 273 */     this.recv_seq_number += 1;
/*     */ 
/* 275 */     if (log.isEnabled())
/*     */     {
/* 277 */       log.log(90, "Received " + Packets.getMessageName(buffer[off] & 0xFF) + " " + payload_length + 
/* 278 */         " bytes payload");
/*     */     }
/*     */ 
/* 281 */     return payload_length;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.transport.TransportConnection
 * JD-Core Version:    0.6.0
 */