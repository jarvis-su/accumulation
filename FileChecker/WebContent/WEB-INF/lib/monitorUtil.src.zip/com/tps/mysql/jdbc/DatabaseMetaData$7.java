/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ class DatabaseMetaData$7 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$table;
/*      */   private final Statement val$stmt;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 3464 */     ResultSet rs = null;
/*      */     try
/*      */     {
/* 3468 */       StringBuffer queryBuf = new StringBuffer("SHOW KEYS FROM ");
/*      */ 
/* 3470 */       queryBuf.append(this.this$0.quotedId);
/* 3471 */       queryBuf.append(this.val$table);
/* 3472 */       queryBuf.append(this.this$0.quotedId);
/* 3473 */       queryBuf.append(" FROM ");
/* 3474 */       queryBuf.append(this.this$0.quotedId);
/* 3475 */       queryBuf.append(catalogStr.toString());
/* 3476 */       queryBuf.append(this.this$0.quotedId);
/*      */ 
/* 3478 */       rs = this.val$stmt.executeQuery(queryBuf.toString());
/*      */ 
/* 3480 */       ArrayList tuples = new ArrayList();
/* 3481 */       TreeMap sortMap = new TreeMap();
/*      */ 
/* 3483 */       while (rs.next()) {
/* 3484 */         String keyType = rs.getString("Key_name");
/*      */ 
/* 3486 */         if ((keyType != null) && (
/* 3487 */           (keyType.equalsIgnoreCase("PRIMARY")) || (keyType.equalsIgnoreCase("PRI"))))
/*      */         {
/* 3489 */           byte[][] tuple = new byte[6][];
/* 3490 */           tuple[0] = (catalogStr.toString() == null ? new byte[0] : DatabaseMetaData.access$000(this.this$0, catalogStr.toString()));
/*      */ 
/* 3492 */           tuple[1] = null;
/* 3493 */           tuple[2] = DatabaseMetaData.access$000(this.this$0, this.val$table);
/*      */ 
/* 3495 */           String columnName = rs.getString("Column_name");
/*      */ 
/* 3497 */           tuple[3] = DatabaseMetaData.access$000(this.this$0, columnName);
/* 3498 */           tuple[4] = DatabaseMetaData.access$000(this.this$0, rs.getString("Seq_in_index"));
/* 3499 */           tuple[5] = DatabaseMetaData.access$000(this.this$0, keyType);
/* 3500 */           sortMap.put(columnName, tuple);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3506 */       Iterator sortedIterator = sortMap.values().iterator();
/*      */ 
/* 3508 */       while (sortedIterator.hasNext())
/* 3509 */         this.val$rows.add(sortedIterator.next());
/*      */     }
/*      */     finally
/*      */     {
/* 3513 */       if (rs != null) {
/*      */         try {
/* 3515 */           rs.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 3520 */         rs = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.7
 * JD-Core Version:    0.6.0
 */