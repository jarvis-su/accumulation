/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.ResultSetMetaData;
/*    */ import java.util.Map;
/*    */ 
/*    */ class Statement$CachedResultSetMetaData
/*    */ {
/*    */   Map columnNameToIndex;
/*    */   Field[] fields;
/*    */   Map fullColumnNameToIndex;
/*    */   ResultSetMetaData metadata;
/*    */   private final Statement this$0;
/*    */ 
/*    */   Statement$CachedResultSetMetaData(Statement this$0)
/*    */   {
/* 66 */     this.this$0 = this$0;
/*    */ 
/* 68 */     this.columnNameToIndex = null;
/*    */ 
/* 74 */     this.fullColumnNameToIndex = null;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Statement.CachedResultSetMetaData
 * JD-Core Version:    0.6.0
 */