package ch.ethz.ssh2.channel;

abstract interface IChannelWorkerThread
{
  public abstract void stopWorking();
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.IChannelWorkerThread
 * JD-Core Version:    0.6.0
 */