package com.acs.eppic.messageservice;

import com.acs.eppic.message.Message;

public abstract interface MessageRecipient
{
  public abstract void receiveIncoming(Message paramMessage);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageRecipient
 * JD-Core Version:    0.6.0
 */