/*    */ package ch.ethz.ssh2.crypto;
/*    */ 
/*    */ import ch.ethz.ssh2.crypto.cipher.BlockCipherFactory;
/*    */ import ch.ethz.ssh2.crypto.digest.MAC;
/*    */ import ch.ethz.ssh2.transport.KexManager;
/*    */ 
/*    */ public class CryptoWishList
/*    */ {
/* 16 */   public String[] kexAlgorithms = KexManager.getDefaultKexAlgorithmList();
/* 17 */   public String[] serverHostKeyAlgorithms = KexManager.getDefaultServerHostkeyAlgorithmList();
/* 18 */   public String[] c2s_enc_algos = BlockCipherFactory.getDefaultCipherList();
/* 19 */   public String[] s2c_enc_algos = BlockCipherFactory.getDefaultCipherList();
/* 20 */   public String[] c2s_mac_algos = MAC.getMacList();
/* 21 */   public String[] s2c_mac_algos = MAC.getMacList();
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.CryptoWishList
 * JD-Core Version:    0.6.0
 */