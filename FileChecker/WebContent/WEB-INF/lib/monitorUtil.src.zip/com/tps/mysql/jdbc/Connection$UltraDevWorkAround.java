/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.Blob;
/*      */ import java.sql.CallableStatement;
/*      */ import java.sql.Clob;
/*      */ import java.sql.Date;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.PreparedStatement;
/*      */ import java.sql.Ref;
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.ResultSetMetaData;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.Calendar;
/*      */ import java.util.Map;
/*      */ 
/*      */ class Connection$UltraDevWorkAround
/*      */   implements CallableStatement
/*      */ {
/*      */   private PreparedStatement delegate;
/*      */   private final Connection this$0;
/*      */ 
/*      */   Connection$UltraDevWorkAround(Connection this$0, PreparedStatement pstmt)
/*      */   {
/*  152 */     this.this$0 = this$0;
/*      */ 
/*  150 */     this.delegate = null;
/*      */ 
/*  153 */     this.delegate = pstmt;
/*      */   }
/*      */ 
/*      */   public void addBatch() throws SQLException {
/*  157 */     this.delegate.addBatch();
/*      */   }
/*      */ 
/*      */   public void addBatch(String p1) throws SQLException {
/*  161 */     this.delegate.addBatch(p1);
/*      */   }
/*      */ 
/*      */   public void cancel() throws SQLException {
/*  165 */     this.delegate.cancel();
/*      */   }
/*      */ 
/*      */   public void clearBatch() throws SQLException {
/*  169 */     this.delegate.clearBatch();
/*      */   }
/*      */ 
/*      */   public void clearParameters() throws SQLException {
/*  173 */     this.delegate.clearParameters();
/*      */   }
/*      */ 
/*      */   public void clearWarnings() throws SQLException {
/*  177 */     this.delegate.clearWarnings();
/*      */   }
/*      */ 
/*      */   public void close() throws SQLException {
/*  181 */     this.delegate.close();
/*      */   }
/*      */ 
/*      */   public boolean execute() throws SQLException {
/*  185 */     return this.delegate.execute();
/*      */   }
/*      */ 
/*      */   public boolean execute(String p1) throws SQLException {
/*  189 */     return this.delegate.execute(p1);
/*      */   }
/*      */ 
/*      */   public boolean execute(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  196 */     return this.delegate.execute(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public boolean execute(String arg0, int[] arg1)
/*      */     throws SQLException
/*      */   {
/*  203 */     return this.delegate.execute(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public boolean execute(String arg0, String[] arg1)
/*      */     throws SQLException
/*      */   {
/*  210 */     return this.delegate.execute(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public int[] executeBatch() throws SQLException {
/*  214 */     return this.delegate.executeBatch();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery() throws SQLException {
/*  218 */     return this.delegate.executeQuery();
/*      */   }
/*      */ 
/*      */   public ResultSet executeQuery(String p1) throws SQLException
/*      */   {
/*  223 */     return this.delegate.executeQuery(p1);
/*      */   }
/*      */ 
/*      */   public int executeUpdate() throws SQLException {
/*  227 */     return this.delegate.executeUpdate();
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String p1) throws SQLException {
/*  231 */     return this.delegate.executeUpdate(p1);
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  238 */     return this.delegate.executeUpdate(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String arg0, int[] arg1)
/*      */     throws SQLException
/*      */   {
/*  245 */     return this.delegate.executeUpdate(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String arg0, String[] arg1)
/*      */     throws SQLException
/*      */   {
/*  253 */     return this.delegate.executeUpdate(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public Array getArray(int p1) throws SQLException {
/*  257 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Array getArray(String arg0)
/*      */     throws SQLException
/*      */   {
/*  264 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(int p1) throws SQLException {
/*  268 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public BigDecimal getBigDecimal(int p1, int p2)
/*      */     throws SQLException
/*      */   {
/*  285 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public BigDecimal getBigDecimal(String arg0)
/*      */     throws SQLException
/*      */   {
/*  292 */     return null;
/*      */   }
/*      */ 
/*      */   public Blob getBlob(int p1) throws SQLException {
/*  296 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Blob getBlob(String arg0)
/*      */     throws SQLException
/*      */   {
/*  303 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(int p1) throws SQLException {
/*  307 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public boolean getBoolean(String arg0)
/*      */     throws SQLException
/*      */   {
/*  314 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public byte getByte(int p1) throws SQLException {
/*  318 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public byte getByte(String arg0)
/*      */     throws SQLException
/*      */   {
/*  325 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(int p1) throws SQLException {
/*  329 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public byte[] getBytes(String arg0)
/*      */     throws SQLException
/*      */   {
/*  336 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Clob getClob(int p1) throws SQLException {
/*  340 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Clob getClob(String arg0)
/*      */     throws SQLException
/*      */   {
/*  347 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public java.sql.Connection getConnection() throws SQLException {
/*  351 */     return this.delegate.getConnection();
/*      */   }
/*      */ 
/*      */   public Date getDate(int p1) throws SQLException {
/*  355 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Date getDate(int p1, Calendar p2) throws SQLException
/*      */   {
/*  360 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Date getDate(String arg0)
/*      */     throws SQLException
/*      */   {
/*  367 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Date getDate(String arg0, Calendar arg1)
/*      */     throws SQLException
/*      */   {
/*  374 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public double getDouble(int p1) throws SQLException {
/*  378 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public double getDouble(String arg0)
/*      */     throws SQLException
/*      */   {
/*  385 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public int getFetchDirection() throws SQLException {
/*  389 */     return this.delegate.getFetchDirection();
/*      */   }
/*      */ 
/*      */   public int getFetchSize() throws SQLException {
/*  393 */     return this.delegate.getFetchSize();
/*      */   }
/*      */ 
/*      */   public float getFloat(int p1) throws SQLException {
/*  397 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public float getFloat(String arg0)
/*      */     throws SQLException
/*      */   {
/*  404 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/*  411 */     return this.delegate.getGeneratedKeys();
/*      */   }
/*      */ 
/*      */   public int getInt(int p1) throws SQLException {
/*  415 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public int getInt(String arg0)
/*      */     throws SQLException
/*      */   {
/*  422 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public long getLong(int p1) throws SQLException {
/*  426 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public long getLong(String arg0)
/*      */     throws SQLException
/*      */   {
/*  433 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public int getMaxFieldSize() throws SQLException {
/*  437 */     return this.delegate.getMaxFieldSize();
/*      */   }
/*      */ 
/*      */   public int getMaxRows() throws SQLException {
/*  441 */     return this.delegate.getMaxRows();
/*      */   }
/*      */ 
/*      */   public ResultSetMetaData getMetaData() throws SQLException {
/*  445 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults() throws SQLException {
/*  449 */     return this.delegate.getMoreResults();
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults(int arg0)
/*      */     throws SQLException
/*      */   {
/*  456 */     return this.delegate.getMoreResults();
/*      */   }
/*      */ 
/*      */   public Object getObject(int p1) throws SQLException {
/*  460 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Object getObject(int p1, Map p2) throws SQLException
/*      */   {
/*  465 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Object getObject(String arg0)
/*      */     throws SQLException
/*      */   {
/*  472 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Object getObject(String arg0, Map arg1)
/*      */     throws SQLException
/*      */   {
/*  479 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/*  486 */     return this.delegate.getParameterMetaData();
/*      */   }
/*      */ 
/*      */   public int getQueryTimeout() throws SQLException {
/*  490 */     return this.delegate.getQueryTimeout();
/*      */   }
/*      */ 
/*      */   public Ref getRef(int p1) throws SQLException {
/*  494 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Ref getRef(String arg0)
/*      */     throws SQLException
/*      */   {
/*  501 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public ResultSet getResultSet() throws SQLException {
/*  505 */     return this.delegate.getResultSet();
/*      */   }
/*      */ 
/*      */   public int getResultSetConcurrency() throws SQLException {
/*  509 */     return this.delegate.getResultSetConcurrency();
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/*  516 */     return this.delegate.getResultSetHoldability();
/*      */   }
/*      */ 
/*      */   public int getResultSetType() throws SQLException {
/*  520 */     return this.delegate.getResultSetType();
/*      */   }
/*      */ 
/*      */   public short getShort(int p1) throws SQLException {
/*  524 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public short getShort(String arg0)
/*      */     throws SQLException
/*      */   {
/*  531 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public String getString(int p1) throws SQLException {
/*  535 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public String getString(String arg0)
/*      */     throws SQLException
/*      */   {
/*  542 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Time getTime(int p1) throws SQLException {
/*  546 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Time getTime(int p1, Calendar p2) throws SQLException
/*      */   {
/*  551 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Time getTime(String arg0)
/*      */     throws SQLException
/*      */   {
/*  558 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Time getTime(String arg0, Calendar arg1)
/*      */     throws SQLException
/*      */   {
/*  565 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int p1) throws SQLException {
/*  569 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(int p1, Calendar p2) throws SQLException
/*      */   {
/*  574 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String arg0)
/*      */     throws SQLException
/*      */   {
/*  581 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public Timestamp getTimestamp(String arg0, Calendar arg1)
/*      */     throws SQLException
/*      */   {
/*  589 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public int getUpdateCount() throws SQLException {
/*  593 */     return this.delegate.getUpdateCount();
/*      */   }
/*      */ 
/*      */   public URL getURL(int arg0)
/*      */     throws SQLException
/*      */   {
/*  600 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public URL getURL(String arg0)
/*      */     throws SQLException
/*      */   {
/*  607 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings() throws SQLException {
/*  611 */     return this.delegate.getWarnings();
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int p1, int p2) throws SQLException {
/*  615 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int p1, int p2, int p3) throws SQLException
/*      */   {
/*  620 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(int p1, int p2, String p3) throws SQLException
/*      */   {
/*  625 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  633 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String arg0, int arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  641 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void registerOutParameter(String arg0, int arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/*  649 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setArray(int p1, Array p2) throws SQLException
/*      */   {
/*  654 */     this.delegate.setArray(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(int p1, InputStream p2, int p3) throws SQLException
/*      */   {
/*  659 */     this.delegate.setAsciiStream(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(String arg0, InputStream arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  667 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(int p1, BigDecimal p2) throws SQLException
/*      */   {
/*  672 */     this.delegate.setBigDecimal(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(String arg0, BigDecimal arg1)
/*      */     throws SQLException
/*      */   {
/*  680 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(int p1, InputStream p2, int p3) throws SQLException
/*      */   {
/*  685 */     this.delegate.setBinaryStream(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(String arg0, InputStream arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  693 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setBlob(int p1, Blob p2) throws SQLException {
/*  697 */     this.delegate.setBlob(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setBoolean(int p1, boolean p2) throws SQLException {
/*  701 */     this.delegate.setBoolean(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setBoolean(String arg0, boolean arg1)
/*      */     throws SQLException
/*      */   {
/*  708 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setByte(int p1, byte p2) throws SQLException {
/*  712 */     this.delegate.setByte(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setByte(String arg0, byte arg1)
/*      */     throws SQLException
/*      */   {
/*  719 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setBytes(int p1, byte[] p2) throws SQLException {
/*  723 */     this.delegate.setBytes(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setBytes(String arg0, byte[] arg1)
/*      */     throws SQLException
/*      */   {
/*  730 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(int p1, Reader p2, int p3) throws SQLException
/*      */   {
/*  735 */     this.delegate.setCharacterStream(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(String arg0, Reader arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  743 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setClob(int p1, Clob p2) throws SQLException {
/*  747 */     this.delegate.setClob(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setCursorName(String p1) throws SQLException {
/*  751 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void setDate(int p1, Date p2) throws SQLException {
/*  755 */     this.delegate.setDate(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setDate(int p1, Date p2, Calendar p3) throws SQLException
/*      */   {
/*  760 */     this.delegate.setDate(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setDate(String arg0, Date arg1)
/*      */     throws SQLException
/*      */   {
/*  767 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setDate(String arg0, Date arg1, Calendar arg2)
/*      */     throws SQLException
/*      */   {
/*  775 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setDouble(int p1, double p2) throws SQLException {
/*  779 */     this.delegate.setDouble(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setDouble(String arg0, double arg1)
/*      */     throws SQLException
/*      */   {
/*  786 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setEscapeProcessing(boolean p1) throws SQLException {
/*  790 */     this.delegate.setEscapeProcessing(p1);
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int p1) throws SQLException {
/*  794 */     this.delegate.setFetchDirection(p1);
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int p1) throws SQLException {
/*  798 */     this.delegate.setFetchSize(p1);
/*      */   }
/*      */ 
/*      */   public void setFloat(int p1, float p2) throws SQLException {
/*  802 */     this.delegate.setFloat(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setFloat(String arg0, float arg1)
/*      */     throws SQLException
/*      */   {
/*  809 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setInt(int p1, int p2) throws SQLException {
/*  813 */     this.delegate.setInt(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setInt(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  820 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setLong(int p1, long p2) throws SQLException {
/*  824 */     this.delegate.setLong(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setLong(String arg0, long arg1)
/*      */     throws SQLException
/*      */   {
/*  831 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setMaxFieldSize(int p1) throws SQLException {
/*  835 */     this.delegate.setMaxFieldSize(p1);
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int p1) throws SQLException {
/*  839 */     this.delegate.setMaxRows(p1);
/*      */   }
/*      */ 
/*      */   public void setNull(int p1, int p2) throws SQLException {
/*  843 */     this.delegate.setNull(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setNull(int p1, int p2, String p3) throws SQLException
/*      */   {
/*  848 */     this.delegate.setNull(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setNull(String arg0, int arg1)
/*      */     throws SQLException
/*      */   {
/*  855 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setNull(String arg0, int arg1, String arg2)
/*      */     throws SQLException
/*      */   {
/*  863 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setObject(int p1, Object p2) throws SQLException
/*      */   {
/*  868 */     this.delegate.setObject(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setObject(int p1, Object p2, int p3) throws SQLException
/*      */   {
/*  873 */     this.delegate.setObject(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setObject(int p1, Object p2, int p3, int p4) throws SQLException
/*      */   {
/*  878 */     this.delegate.setObject(p1, p2, p3, p4);
/*      */   }
/*      */ 
/*      */   public void setObject(String arg0, Object arg1)
/*      */     throws SQLException
/*      */   {
/*  885 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setObject(String arg0, Object arg1, int arg2)
/*      */     throws SQLException
/*      */   {
/*  893 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setObject(String arg0, Object arg1, int arg2, int arg3)
/*      */     throws SQLException
/*      */   {
/*  901 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setQueryTimeout(int p1) throws SQLException {
/*  905 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void setRef(int p1, Ref p2) throws SQLException {
/*  909 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ 
/*      */   public void setShort(int p1, short p2) throws SQLException {
/*  913 */     this.delegate.setShort(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setShort(String arg0, short arg1)
/*      */     throws SQLException
/*      */   {
/*  920 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setString(int p1, String p2) throws SQLException
/*      */   {
/*  925 */     this.delegate.setString(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setString(String arg0, String arg1)
/*      */     throws SQLException
/*      */   {
/*  932 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setTime(int p1, Time p2) throws SQLException {
/*  936 */     this.delegate.setTime(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setTime(int p1, Time p2, Calendar p3) throws SQLException
/*      */   {
/*  941 */     this.delegate.setTime(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setTime(String arg0, Time arg1)
/*      */     throws SQLException
/*      */   {
/*  948 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setTime(String arg0, Time arg1, Calendar arg2)
/*      */     throws SQLException
/*      */   {
/*  956 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int p1, Timestamp p2) throws SQLException
/*      */   {
/*  961 */     this.delegate.setTimestamp(p1, p2);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int p1, Timestamp p2, Calendar p3) throws SQLException
/*      */   {
/*  966 */     this.delegate.setTimestamp(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String arg0, Timestamp arg1)
/*      */     throws SQLException
/*      */   {
/*  974 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setTimestamp(String arg0, Timestamp arg1, Calendar arg2)
/*      */     throws SQLException
/*      */   {
/*  982 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void setUnicodeStream(int p1, InputStream p2, int p3)
/*      */     throws SQLException
/*      */   {
/* 1000 */     this.delegate.setUnicodeStream(p1, p2, p3);
/*      */   }
/*      */ 
/*      */   public void setURL(int arg0, URL arg1)
/*      */     throws SQLException
/*      */   {
/* 1007 */     this.delegate.setURL(arg0, arg1);
/*      */   }
/*      */ 
/*      */   public void setURL(String arg0, URL arg1)
/*      */     throws SQLException
/*      */   {
/* 1014 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public boolean wasNull() throws SQLException {
/* 1018 */     throw SQLError.createSQLException("Not supported");
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Connection.UltraDevWorkAround
 * JD-Core Version:    0.6.0
 */