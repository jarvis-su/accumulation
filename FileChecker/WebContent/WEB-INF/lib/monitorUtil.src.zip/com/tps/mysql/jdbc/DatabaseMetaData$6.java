/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ 
/*      */ class DatabaseMetaData$6 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$table;
/*      */   private final Statement val$stmt;
/*      */   private final boolean val$unique;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 3083 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 3086 */       StringBuffer queryBuf = new StringBuffer("SHOW INDEX FROM ");
/*      */ 
/* 3088 */       queryBuf.append(this.this$0.quotedId);
/* 3089 */       queryBuf.append(this.val$table);
/* 3090 */       queryBuf.append(this.this$0.quotedId);
/* 3091 */       queryBuf.append(" FROM ");
/* 3092 */       queryBuf.append(this.this$0.quotedId);
/* 3093 */       queryBuf.append(catalogStr.toString());
/* 3094 */       queryBuf.append(this.this$0.quotedId);
/*      */       try
/*      */       {
/* 3097 */         results = this.val$stmt.executeQuery(queryBuf.toString());
/*      */       } catch (SQLException sqlEx) {
/* 3099 */         int errorCode = sqlEx.getErrorCode();
/*      */ 
/* 3103 */         if (!"42S02".equals(sqlEx.getSQLState()))
/*      */         {
/* 3106 */           if (errorCode != 1146) {
/* 3107 */             throw sqlEx;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 3112 */       while ((results != null) && (results.next())) {
/* 3113 */         byte[][] row = new byte[14][];
/* 3114 */         row[0] = (catalogStr.toString() == null ? new byte[0] : DatabaseMetaData.access$000(this.this$0, catalogStr.toString()));
/*      */ 
/* 3117 */         row[1] = null;
/* 3118 */         row[2] = results.getBytes("Table");
/*      */ 
/* 3120 */         boolean indexIsUnique = results.getInt("Non_unique") == 0;
/*      */ 
/* 3123 */         row[3] = (!indexIsUnique ? DatabaseMetaData.access$000(this.this$0, "true") : DatabaseMetaData.access$000(this.this$0, "false"));
/*      */ 
/* 3125 */         row[4] = new byte[0];
/* 3126 */         row[5] = results.getBytes("Key_name");
/* 3127 */         row[6] = Integer.toString(3).getBytes();
/*      */ 
/* 3130 */         row[7] = results.getBytes("Seq_in_index");
/* 3131 */         row[8] = results.getBytes("Column_name");
/* 3132 */         row[9] = results.getBytes("Collation");
/* 3133 */         row[10] = results.getBytes("Cardinality");
/* 3134 */         row[11] = DatabaseMetaData.access$000(this.this$0, "0");
/* 3135 */         row[12] = null;
/*      */ 
/* 3137 */         if (this.val$unique) {
/* 3138 */           if (indexIsUnique) {
/* 3139 */             this.val$rows.add(row);
/*      */           }
/*      */         }
/*      */         else
/* 3143 */           this.val$rows.add(row);
/*      */       }
/*      */     }
/*      */     finally {
/* 3147 */       if (results != null) {
/*      */         try {
/* 3149 */           results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 3154 */         results = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.6
 * JD-Core Version:    0.6.0
 */