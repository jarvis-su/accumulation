/*     */ package ch.ethz.ssh2.auth;
/*     */ 
/*     */ import ch.ethz.ssh2.InteractiveCallback;
/*     */ import ch.ethz.ssh2.crypto.PEMDecoder;
/*     */ import ch.ethz.ssh2.packets.PacketServiceAccept;
/*     */ import ch.ethz.ssh2.packets.PacketServiceRequest;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthBanner;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthFailure;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthInfoRequest;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthInfoResponse;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthRequestInteractive;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthRequestNone;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthRequestPassword;
/*     */ import ch.ethz.ssh2.packets.PacketUserauthRequestPublicKey;
/*     */ import ch.ethz.ssh2.packets.TypesWriter;
/*     */ import ch.ethz.ssh2.signature.DSAPrivateKey;
/*     */ import ch.ethz.ssh2.signature.DSASHA1Verify;
/*     */ import ch.ethz.ssh2.signature.DSASignature;
/*     */ import ch.ethz.ssh2.signature.RSAPrivateKey;
/*     */ import ch.ethz.ssh2.signature.RSASHA1Verify;
/*     */ import ch.ethz.ssh2.signature.RSASignature;
/*     */ import ch.ethz.ssh2.transport.MessageHandler;
/*     */ import ch.ethz.ssh2.transport.TransportManager;
/*     */ import java.io.IOException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Vector;
/*     */ 
/*     */ public class AuthenticationManager
/*     */   implements MessageHandler
/*     */ {
/*     */   TransportManager tm;
/*  41 */   Vector packets = new Vector();
/*  42 */   boolean connectionClosed = false;
/*     */   String banner;
/*  46 */   String[] remainingMethods = null;
/*  47 */   boolean isPartialSuccess = false;
/*     */ 
/*  49 */   boolean authenticated = false;
/*  50 */   boolean initDone = false;
/*     */ 
/*     */   public AuthenticationManager(TransportManager tm)
/*     */   {
/*  54 */     this.tm = tm;
/*     */   }
/*     */ 
/*     */   boolean methodPossible(String methName)
/*     */   {
/*  59 */     if (this.remainingMethods == null) {
/*  60 */       return false;
/*     */     }
/*  62 */     for (int i = 0; i < this.remainingMethods.length; i++)
/*     */     {
/*  64 */       if (this.remainingMethods[i].compareTo(methName) == 0)
/*  65 */         return true;
/*     */     }
/*  67 */     return false;
/*     */   }
/*     */ 
/*     */   byte[] deQueue() throws IOException
/*     */   {
/*  72 */     synchronized (this.packets)
/*     */     {
/*  74 */       while (this.packets.size() == 0)
/*     */       {
/*  76 */         if (this.connectionClosed) {
/*  77 */           throw ((IOException)new IOException("The connection is closed.").initCause(
/*  78 */             this.tm.getReasonClosedCause()));
/*     */         }
/*     */         try
/*     */         {
/*  82 */           this.packets.wait();
/*     */         }
/*     */         catch (InterruptedException localInterruptedException)
/*     */         {
/*     */         }
/*     */       }
/*     */ 
/*  89 */       byte[] res = (byte[])this.packets.firstElement();
/*  90 */       this.packets.removeElementAt(0);
/*  91 */       return res;
/*     */     }
/*     */   }
/*     */ 
/*     */   byte[] getNextMessage() throws IOException
/*     */   {
/*     */     while (true)
/*     */     {
/*  99 */       byte[] msg = deQueue();
/*     */ 
/* 101 */       if (msg[0] != 53) {
/* 102 */         return msg;
/*     */       }
/* 104 */       PacketUserauthBanner sb = new PacketUserauthBanner(msg, 0, msg.length);
/*     */ 
/* 106 */       this.banner = sb.getBanner();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String[] getRemainingMethods(String user) throws IOException
/*     */   {
/* 112 */     initialize(user);
/* 113 */     return this.remainingMethods;
/*     */   }
/*     */ 
/*     */   public boolean getPartialSuccess()
/*     */   {
/* 118 */     return this.isPartialSuccess;
/*     */   }
/*     */ 
/*     */   private boolean initialize(String user) throws IOException
/*     */   {
/* 123 */     if (!this.initDone)
/*     */     {
/* 125 */       this.tm.registerMessageHandler(this, 0, 255);
/*     */ 
/* 127 */       PacketServiceRequest sr = new PacketServiceRequest("ssh-userauth");
/* 128 */       this.tm.sendMessage(sr.getPayload());
/*     */ 
/* 130 */       PacketUserauthRequestNone urn = new PacketUserauthRequestNone("ssh-connection", user);
/* 131 */       this.tm.sendMessage(urn.getPayload());
/*     */ 
/* 133 */       byte[] msg = getNextMessage();
/* 134 */       new PacketServiceAccept(msg, 0, msg.length);
/* 135 */       msg = getNextMessage();
/*     */ 
/* 137 */       this.initDone = true;
/*     */ 
/* 139 */       if (msg[0] == 52)
/*     */       {
/* 141 */         this.authenticated = true;
/* 142 */         return true;
/*     */       }
/*     */ 
/* 145 */       if (msg[0] == 51)
/*     */       {
/* 147 */         PacketUserauthFailure puf = new PacketUserauthFailure(msg, 0, msg.length);
/*     */ 
/* 149 */         this.remainingMethods = puf.getAuthThatCanContinue();
/* 150 */         this.isPartialSuccess = puf.isPartialSuccess();
/* 151 */         return false;
/*     */       }
/*     */ 
/* 154 */       throw new IOException("Unexpected SSH message (type " + msg[0] + ")");
/*     */     }
/* 156 */     return this.authenticated;
/*     */   }
/*     */ 
/*     */   public boolean authenticatePublicKey(String user, char[] PEMPrivateKey, String password, SecureRandom rnd) throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 163 */       initialize(user);
/*     */ 
/* 165 */       if (!methodPossible("publickey")) {
/* 166 */         throw new IOException("Authentication method publickey not supported by the server at this stage.");
/*     */       }
/* 168 */       Object key = PEMDecoder.decode(PEMPrivateKey, password);
/*     */ 
/* 170 */       if ((key instanceof DSAPrivateKey))
/*     */       {
/* 172 */         DSAPrivateKey pk = (DSAPrivateKey)key;
/*     */ 
/* 174 */         byte[] pk_enc = DSASHA1Verify.encodeSSHDSAPublicKey(pk.getPublicKey());
/*     */ 
/* 176 */         TypesWriter tw = new TypesWriter();
/*     */ 
/* 178 */         byte[] H = this.tm.getSessionIdentifier();
/*     */ 
/* 180 */         tw.writeString(H, 0, H.length);
/* 181 */         tw.writeByte(50);
/* 182 */         tw.writeString(user);
/* 183 */         tw.writeString("ssh-connection");
/* 184 */         tw.writeString("publickey");
/* 185 */         tw.writeBoolean(true);
/* 186 */         tw.writeString("ssh-dss");
/* 187 */         tw.writeString(pk_enc, 0, pk_enc.length);
/*     */ 
/* 189 */         byte[] msg = tw.getBytes();
/*     */ 
/* 191 */         DSASignature ds = DSASHA1Verify.generateSignature(msg, pk, rnd);
/*     */ 
/* 193 */         byte[] ds_enc = DSASHA1Verify.encodeSSHDSASignature(ds);
/*     */ 
/* 195 */         PacketUserauthRequestPublicKey ua = new PacketUserauthRequestPublicKey("ssh-connection", user, 
/* 196 */           "ssh-dss", pk_enc, ds_enc);
/* 197 */         this.tm.sendMessage(ua.getPayload());
/*     */       }
/* 199 */       else if ((key instanceof RSAPrivateKey))
/*     */       {
/* 201 */         RSAPrivateKey pk = (RSAPrivateKey)key;
/*     */ 
/* 203 */         byte[] pk_enc = RSASHA1Verify.encodeSSHRSAPublicKey(pk.getPublicKey());
/*     */ 
/* 205 */         TypesWriter tw = new TypesWriter();
/*     */ 
/* 207 */         byte[] H = this.tm.getSessionIdentifier();
/*     */ 
/* 209 */         tw.writeString(H, 0, H.length);
/* 210 */         tw.writeByte(50);
/* 211 */         tw.writeString(user);
/* 212 */         tw.writeString("ssh-connection");
/* 213 */         tw.writeString("publickey");
/* 214 */         tw.writeBoolean(true);
/* 215 */         tw.writeString("ssh-rsa");
/* 216 */         tw.writeString(pk_enc, 0, pk_enc.length);
/*     */ 
/* 219 */         byte[] msg = tw.getBytes();
/*     */ 
/* 221 */         RSASignature ds = RSASHA1Verify.generateSignature(msg, pk);
/*     */ 
/* 223 */         byte[] rsa_sig_enc = RSASHA1Verify.encodeSSHRSASignature(ds);
/*     */ 
/* 225 */         PacketUserauthRequestPublicKey ua = new PacketUserauthRequestPublicKey("ssh-connection", user, 
/* 226 */           "ssh-rsa", pk_enc, rsa_sig_enc);
/* 227 */         this.tm.sendMessage(ua.getPayload());
/*     */       }
/*     */       else
/*     */       {
/* 231 */         throw new IOException("Unknown private key type returned by the PEM decoder.");
/*     */       }
/*     */ 
/* 234 */       byte[] ar = getNextMessage();
/*     */ 
/* 236 */       if (ar[0] == 52)
/*     */       {
/* 238 */         this.authenticated = true;
/* 239 */         this.tm.removeMessageHandler(this, 0, 255);
/* 240 */         return true;
/*     */       }
/*     */ 
/* 243 */       if (ar[0] == 51)
/*     */       {
/* 245 */         PacketUserauthFailure puf = new PacketUserauthFailure(ar, 0, ar.length);
/*     */ 
/* 247 */         this.remainingMethods = puf.getAuthThatCanContinue();
/* 248 */         this.isPartialSuccess = puf.isPartialSuccess();
/*     */ 
/* 250 */         return false;
/*     */       }
/*     */ 
/* 253 */       throw new IOException("Unexpected SSH message (type " + ar[0] + ")");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 258 */       this.tm.close(e, false);
/* 259 */     }throw ((IOException)new IOException("Publickey authentication failed.").initCause(e));
/*     */   }
/*     */ 
/*     */   public boolean authenticatePassword(String user, String pass)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 267 */       initialize(user);
/*     */ 
/* 269 */       if (!methodPossible("password")) {
/* 270 */         throw new IOException("Authentication method password not supported by the server at this stage.");
/*     */       }
/* 272 */       PacketUserauthRequestPassword ua = new PacketUserauthRequestPassword("ssh-connection", user, pass);
/* 273 */       this.tm.sendMessage(ua.getPayload());
/*     */ 
/* 275 */       byte[] ar = getNextMessage();
/*     */ 
/* 277 */       if (ar[0] == 52)
/*     */       {
/* 279 */         this.authenticated = true;
/* 280 */         this.tm.removeMessageHandler(this, 0, 255);
/* 281 */         return true;
/*     */       }
/*     */ 
/* 284 */       if (ar[0] == 51)
/*     */       {
/* 286 */         PacketUserauthFailure puf = new PacketUserauthFailure(ar, 0, ar.length);
/*     */ 
/* 288 */         this.remainingMethods = puf.getAuthThatCanContinue();
/* 289 */         this.isPartialSuccess = puf.isPartialSuccess();
/*     */ 
/* 291 */         return false;
/*     */       }
/*     */ 
/* 294 */       throw new IOException("Unexpected SSH message (type " + ar[0] + ")");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 299 */       this.tm.close(e, false);
/* 300 */     }throw ((IOException)new IOException("Password authentication failed.").initCause(e));
/*     */   }
/*     */ 
/*     */   public boolean authenticateInteractive(String user, String[] submethods, InteractiveCallback cb)
/*     */     throws IOException
/*     */   {
/*     */     try
/*     */     {
/* 308 */       initialize(user);
/*     */ 
/* 310 */       if (!methodPossible("keyboard-interactive")) {
/* 311 */         throw new IOException(
/* 312 */           "Authentication method keyboard-interactive not supported by the server at this stage.");
/*     */       }
/* 314 */       if (submethods == null) {
/* 315 */         submethods = new String[0];
/*     */       }
/* 317 */       PacketUserauthRequestInteractive ua = new PacketUserauthRequestInteractive("ssh-connection", user, 
/* 318 */         submethods);
/*     */ 
/* 320 */       this.tm.sendMessage(ua.getPayload());
/*     */       while (true)
/*     */       {
/* 324 */         byte[] ar = getNextMessage();
/*     */ 
/* 326 */         if (ar[0] == 52)
/*     */         {
/* 328 */           this.authenticated = true;
/* 329 */           this.tm.removeMessageHandler(this, 0, 255);
/* 330 */           return true;
/*     */         }
/*     */ 
/* 333 */         if (ar[0] == 51)
/*     */         {
/* 335 */           PacketUserauthFailure puf = new PacketUserauthFailure(ar, 0, ar.length);
/*     */ 
/* 337 */           this.remainingMethods = puf.getAuthThatCanContinue();
/* 338 */           this.isPartialSuccess = puf.isPartialSuccess();
/*     */ 
/* 340 */           return false;
/*     */         }
/*     */ 
/* 343 */         if (ar[0] == 60)
/*     */         {
/* 345 */           PacketUserauthInfoRequest pui = new PacketUserauthInfoRequest(ar, 0, ar.length);
/*     */           try
/*     */           {
/* 351 */             responses = cb.replyToChallenge(pui.getName(), pui.getInstruction(), pui.getNumPrompts(), 
/* 352 */               pui.getPrompt(), pui.getEcho());
/*     */           }
/*     */           catch (Exception e)
/*     */           {
/*     */             String[] responses;
/* 356 */             throw ((IOException)new IOException("Exception in callback.").initCause(e));
/*     */           }
/*     */           String[] responses;
/* 359 */           if (responses == null) {
/* 360 */             throw new IOException("Your callback may not return NULL!");
/*     */           }
/* 362 */           PacketUserauthInfoResponse puir = new PacketUserauthInfoResponse(responses);
/* 363 */           this.tm.sendMessage(puir.getPayload());
/*     */ 
/* 365 */           continue;
/*     */         }
/*     */ 
/* 368 */         throw new IOException("Unexpected SSH message (type " + ar[0] + ")");
/*     */       }
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 373 */       this.tm.close(e, false);
/* 374 */     }throw ((IOException)new IOException("Keyboard-interactive authentication failed.").initCause(e));
/*     */   }
/*     */ 
/*     */   public void handleMessage(byte[] msg, int msglen)
/*     */     throws IOException
/*     */   {
/* 380 */     synchronized (this.packets)
/*     */     {
/* 382 */       if (msg == null)
/*     */       {
/* 384 */         this.connectionClosed = true;
/*     */       }
/*     */       else
/*     */       {
/* 388 */         byte[] tmp = new byte[msglen];
/* 389 */         System.arraycopy(msg, 0, tmp, 0, msglen);
/* 390 */         this.packets.addElement(tmp);
/*     */       }
/*     */ 
/* 393 */       this.packets.notifyAll();
/*     */ 
/* 395 */       if (this.packets.size() > 5)
/*     */       {
/* 397 */         this.connectionClosed = true;
/* 398 */         throw new IOException("Error, peer is flooding us with authentication packets.");
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.auth.AuthenticationManager
 * JD-Core Version:    0.6.0
 */