package com.mysql.jdbc;

import java.sql.SQLException;
import java.util.Map;

class LicenseConfiguration
{
  static void checkLicenseType(Map serverVariables)
    throws SQLException
  {
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.LicenseConfiguration
 * JD-Core Version:    0.6.0
 */