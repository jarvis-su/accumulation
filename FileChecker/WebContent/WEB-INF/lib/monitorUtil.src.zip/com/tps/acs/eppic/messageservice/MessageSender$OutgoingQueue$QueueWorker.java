/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.messageservice.web.MessageWebService;
/*     */ import com.acs.eppic.messageservice.web.MessageWebServiceServiceLocator;
/*     */ import java.net.URL;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ class MessageSender$OutgoingQueue$QueueWorker extends Thread
/*     */ {
/* 253 */   boolean alertQueueWait = false;
/* 254 */   boolean messageQueueWait = false;
/*     */ 
/*     */   private MessageSender$OutgoingQueue$QueueWorker(MessageSender.OutgoingQueue paramOutgoingQueue) {  } 
/* 256 */   public void run() { List messageList = new LinkedList();
/*     */ 
/* 259 */     while (MessageSender.OutgoingQueue.access$3(this.this$1).isServiceEnabled()) {
/* 260 */       messageList.clear();
/* 261 */       synchronized (MessageSender.OutgoingQueue.access$0(this.this$1)) {
/* 262 */         if (MessageSender.OutgoingQueue.access$0(this.this$1).isEmpty()) {
/* 263 */           this.alertQueueWait = true;
/*     */         }
/*     */         else {
/* 266 */           this.alertQueueWait = false;
/*     */           do
/*     */           {
/* 269 */             messageList.add(MessageSender.OutgoingQueue.access$0(this.this$1).removeFirst());
/*     */ 
/* 268 */             if (messageList.size() >= MessageSender.access$0(MessageSender.OutgoingQueue.access$3(this.this$1))) break; 
/* 268 */           }while (!MessageSender.OutgoingQueue.access$0(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 273 */       synchronized (MessageSender.OutgoingQueue.access$1(this.this$1)) {
/* 274 */         if (MessageSender.OutgoingQueue.access$1(this.this$1).isEmpty()) {
/* 275 */           this.messageQueueWait = true;
/*     */         }
/*     */         else {
/* 278 */           this.messageQueueWait = false;
/*     */           do
/*     */           {
/* 281 */             messageList.add(MessageSender.OutgoingQueue.access$1(this.this$1).removeFirst());
/*     */ 
/* 280 */             if (messageList.size() >= MessageSender.access$0(MessageSender.OutgoingQueue.access$3(this.this$1))) break; 
/* 280 */           }while (!MessageSender.OutgoingQueue.access$1(this.this$1).isEmpty());
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 286 */       if ((this.alertQueueWait) && (this.messageQueueWait)) {
/* 287 */         synchronized (this.this$1.semObj) {
/*     */           try {
/* 289 */             this.this$1.semObj.wait();
/*     */           }
/*     */           catch (InterruptedException localInterruptedException)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/* 296 */       MessageWebService mws = null;
/* 297 */       int sentMessages = 0;
/*     */ 
/* 299 */       while (!messageList.isEmpty()) {
/* 300 */         Message message = (Message)messageList.remove(0);
/*     */         try {
/* 302 */           if (mws == null) {
/* 303 */             mws = MessageSender.OutgoingQueue.access$2(this.this$1).getMessageWebService(new URL(MessageSender.access$1(MessageSender.OutgoingQueue.access$3(this.this$1))));
/*     */           }
/* 305 */           MessageSender.logger.debug(getName() + "Sending Message(s)...\n" + message);
/* 306 */           mws.sendMessage(message);
/* 307 */           sentMessages++;
/*     */         } catch (Throwable e) {
/* 309 */           MessageSender.logger.error("Send Message Failed" + message, e);
/* 310 */           mws = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageSender.OutgoingQueue.QueueWorker
 * JD-Core Version:    0.6.0
 */