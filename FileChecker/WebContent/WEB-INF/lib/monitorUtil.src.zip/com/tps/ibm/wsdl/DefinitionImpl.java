package com.ibm.wsdl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class DefinitionImpl
  implements Definition
{
  protected String documentBaseURI = null;
  protected QName name = null;
  protected String targetNamespace = null;
  protected Map namespaces = new HashMap();
  protected Map imports = new HashMap();
  protected Types types = null;
  protected Map messages = new HashMap();
  protected Map bindings = new HashMap();
  protected Map portTypes = new HashMap();
  protected Map services = new HashMap();
  protected Element docEl = null;
  protected List extElements = new Vector();
  protected ExtensionRegistry extReg = null;
  public static final long serialVersionUID = 1L;

  public void setDocumentBaseURI(String paramString)
  {
    this.documentBaseURI = paramString;
  }

  public String getDocumentBaseURI()
  {
    return this.documentBaseURI;
  }

  public void setQName(QName paramQName)
  {
    this.name = paramQName;
  }

  public QName getQName()
  {
    return this.name;
  }

  public void setTargetNamespace(String paramString)
  {
    this.targetNamespace = paramString;
  }

  public String getTargetNamespace()
  {
    return this.targetNamespace;
  }

  public void addNamespace(String paramString1, String paramString2)
  {
    if (paramString1 == null)
      paramString1 = "";
    if (paramString2 != null)
      this.namespaces.put(paramString1, paramString2);
    else
      this.namespaces.remove(paramString1);
  }

  public String getNamespace(String paramString)
  {
    if (paramString == null)
      paramString = "";
    return (String)this.namespaces.get(paramString);
  }

  public String getPrefix(String paramString)
  {
    if (paramString == null)
      return null;
    Iterator localIterator = this.namespaces.entrySet().iterator();
    while (localIterator.hasNext())
    {
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String str1 = (String)localEntry.getKey();
      String str2 = (String)localEntry.getValue();
      if (paramString.equals(str2))
        return str1;
    }
    return null;
  }

  public Map getNamespaces()
  {
    return this.namespaces;
  }

  public void setTypes(Types paramTypes)
  {
    this.types = paramTypes;
  }

  public Types getTypes()
  {
    return this.types;
  }

  public void addImport(Import paramImport)
  {
    String str = paramImport.getNamespaceURI();
    Object localObject = (List)this.imports.get(str);
    if (localObject == null)
    {
      localObject = new Vector();
      this.imports.put(str, localObject);
    }
    ((List)localObject).add(paramImport);
  }

  public List getImports(String paramString)
  {
    return (List)this.imports.get(paramString);
  }

  public Map getImports()
  {
    return this.imports;
  }

  public void addMessage(Message paramMessage)
  {
    this.messages.put(paramMessage.getQName(), paramMessage);
  }

  public Message getMessage(QName paramQName)
  {
    Message localMessage = (Message)this.messages.get(paramQName);
    if ((localMessage == null) && (paramQName != null))
      localMessage = (Message)getFromImports("message", paramQName);
    return localMessage;
  }

  public Message removeMessage(QName paramQName)
  {
    return (Message)this.messages.remove(paramQName);
  }

  public Map getMessages()
  {
    return this.messages;
  }

  public void addBinding(Binding paramBinding)
  {
    this.bindings.put(paramBinding.getQName(), paramBinding);
  }

  public Binding getBinding(QName paramQName)
  {
    Binding localBinding = (Binding)this.bindings.get(paramQName);
    if ((localBinding == null) && (paramQName != null))
      localBinding = (Binding)getFromImports("binding", paramQName);
    return localBinding;
  }

  public Binding removeBinding(QName paramQName)
  {
    return (Binding)this.bindings.remove(paramQName);
  }

  public Map getBindings()
  {
    return this.bindings;
  }

  public void addPortType(PortType paramPortType)
  {
    this.portTypes.put(paramPortType.getQName(), paramPortType);
  }

  public PortType getPortType(QName paramQName)
  {
    PortType localPortType = (PortType)this.portTypes.get(paramQName);
    if ((localPortType == null) && (paramQName != null))
      localPortType = (PortType)getFromImports("portType", paramQName);
    return localPortType;
  }

  public PortType removePortType(QName paramQName)
  {
    return (PortType)this.portTypes.remove(paramQName);
  }

  public Map getPortTypes()
  {
    return this.portTypes;
  }

  public void addService(Service paramService)
  {
    this.services.put(paramService.getQName(), paramService);
  }

  public Service getService(QName paramQName)
  {
    Service localService = (Service)this.services.get(paramQName);
    if ((localService == null) && (paramQName != null))
      localService = (Service)getFromImports("service", paramQName);
    return localService;
  }

  public Service removeService(QName paramQName)
  {
    return (Service)this.services.remove(paramQName);
  }

  public Map getServices()
  {
    return this.services;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public Binding createBinding()
  {
    return new BindingImpl();
  }

  public BindingFault createBindingFault()
  {
    return new BindingFaultImpl();
  }

  public BindingInput createBindingInput()
  {
    return new BindingInputImpl();
  }

  public BindingOperation createBindingOperation()
  {
    return new BindingOperationImpl();
  }

  public BindingOutput createBindingOutput()
  {
    return new BindingOutputImpl();
  }

  public Fault createFault()
  {
    return new FaultImpl();
  }

  public Import createImport()
  {
    return new ImportImpl();
  }

  public Input createInput()
  {
    return new InputImpl();
  }

  public Message createMessage()
  {
    return new MessageImpl();
  }

  public Operation createOperation()
  {
    return new OperationImpl();
  }

  public Output createOutput()
  {
    return new OutputImpl();
  }

  public Part createPart()
  {
    return new PartImpl();
  }

  public Port createPort()
  {
    return new PortImpl();
  }

  public PortType createPortType()
  {
    return new PortTypeImpl();
  }

  public Service createService()
  {
    return new ServiceImpl();
  }

  public Types createTypes()
  {
    return new TypesImpl();
  }

  public void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry)
  {
    this.extReg = paramExtensionRegistry;
  }

  public ExtensionRegistry getExtensionRegistry()
  {
    return this.extReg;
  }

  private Object getFromImports(String paramString, QName paramQName)
  {
    Object localObject = null;
    List localList = getImports(paramQName.getNamespaceURI());
    if (localList != null)
    {
      Iterator localIterator = localList.iterator();
      while (localIterator.hasNext())
      {
        Import localImport = (Import)localIterator.next();
        if (localImport == null)
          continue;
        Definition localDefinition = localImport.getDefinition();
        if (localDefinition == null)
          continue;
        if (paramString == "service")
          localObject = localDefinition.getService(paramQName);
        else if (paramString == "message")
          localObject = localDefinition.getMessage(paramQName);
        else if (paramString == "binding")
          localObject = localDefinition.getBinding(paramQName);
        else if (paramString == "portType")
          localObject = localDefinition.getPortType(paramQName);
        if (localObject != null)
          return localObject;
      }
    }
    return localObject;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Definition: name=" + this.name + " targetNamespace=" + this.targetNamespace);
    Iterator localIterator;
    if (this.imports != null)
    {
      localIterator = this.imports.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.types != null)
      localStringBuffer.append("\n" + this.types);
    if (this.messages != null)
    {
      localIterator = this.messages.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.portTypes != null)
    {
      localIterator = this.portTypes.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.bindings != null)
    {
      localIterator = this.bindings.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.services != null)
    {
      localIterator = this.services.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.DefinitionImpl
 * JD-Core Version:    0.6.0
 */