package com.ibm.wsdl.xml;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.extensions.schema.SchemaConstants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import com.ibm.wsdl.util.xml.XPathUtils;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Definition;
import javax.wsdl.Fault;
import javax.wsdl.Import;
import javax.wsdl.Input;
import javax.wsdl.Message;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.Output;
import javax.wsdl.Part;
import javax.wsdl.Port;
import javax.wsdl.PortType;
import javax.wsdl.Service;
import javax.wsdl.Types;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.AttributeExtensible;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLLocator;
import javax.wsdl.xml.WSDLReader;
import javax.xml.namespace.QName;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

public class WSDLReaderImpl
  implements WSDLReader
{
  private static final List STYLE_ONE_WAY = Arrays.asList(new String[] { "input" });
  private static final List STYLE_REQUEST_RESPONSE = Arrays.asList(new String[] { "input", "output" });
  private static final List STYLE_SOLICIT_RESPONSE = Arrays.asList(new String[] { "output", "input" });
  private static final List STYLE_NOTIFICATION = Arrays.asList(new String[] { "output" });
  protected boolean verbose = true;
  protected boolean importDocuments = true;
  protected ExtensionRegistry extReg = null;
  protected String factoryImplName = null;
  protected WSDLLocator loc = null;
  protected Map allSchemas = new Hashtable();

  public void setFeature(String paramString, boolean paramBoolean)
    throws IllegalArgumentException
  {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null.");
    if (paramString.equals("javax.wsdl.verbose"))
      this.verbose = paramBoolean;
    else if (paramString.equals("javax.wsdl.importDocuments"))
      this.importDocuments = paramBoolean;
    else
      throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }

  public boolean getFeature(String paramString)
    throws IllegalArgumentException
  {
    if (paramString == null)
      throw new IllegalArgumentException("Feature name must not be null.");
    if (paramString.equals("javax.wsdl.verbose"))
      return this.verbose;
    if (paramString.equals("javax.wsdl.importDocuments"))
      return this.importDocuments;
    throw new IllegalArgumentException("Feature name '" + paramString + "' not recognized.");
  }

  public void setExtensionRegistry(ExtensionRegistry paramExtensionRegistry)
  {
    this.extReg = paramExtensionRegistry;
  }

  public ExtensionRegistry getExtensionRegistry()
  {
    return this.extReg;
  }

  public void setFactoryImplName(String paramString)
    throws UnsupportedOperationException
  {
    this.factoryImplName = paramString;
  }

  public String getFactoryImplName()
  {
    return this.factoryImplName;
  }

  protected Definition parseDefinitions(String paramString, Element paramElement, Map paramMap)
    throws WSDLException
  {
    checkElementName(paramElement, Constants.Q_ELEM_DEFINITIONS);
    WSDLFactory localWSDLFactory = this.factoryImplName != null ? WSDLFactory.newInstance(this.factoryImplName) : WSDLFactory.newInstance();
    Definition localDefinition = localWSDLFactory.newDefinition();
    if (this.extReg != null)
      localDefinition.setExtensionRegistry(this.extReg);
    String str1 = DOMUtils.getAttribute(paramElement, "name");
    String str2 = DOMUtils.getAttribute(paramElement, "targetNamespace");
    NamedNodeMap localNamedNodeMap = paramElement.getAttributes();
    if (paramString != null)
      localDefinition.setDocumentBaseURI(paramString);
    if (str1 != null)
      localDefinition.setQName(new QName(str2, str1));
    if (str2 != null)
      localDefinition.setTargetNamespace(str2);
    int i = localNamedNodeMap.getLength();
    for (int j = 0; j < i; j++)
    {
      Attr localAttr = (Attr)localNamedNodeMap.item(j);
      String str3 = localAttr.getNamespaceURI();
      String str4 = localAttr.getLocalName();
      String str5 = localAttr.getValue();
      if ((str3 == null) || (!str3.equals("http://www.w3.org/2000/xmlns/")))
        continue;
      if ((str4 != null) && (!str4.equals("xmlns")))
        localDefinition.addNamespace(str4, str5);
      else
        localDefinition.addNamespace(null, str5);
    }
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_IMPORT, localElement))
      {
        if (paramMap == null)
          paramMap = new Hashtable();
        if (paramString != null)
          paramMap.put(paramString, localDefinition);
        localDefinition.addImport(parseImport(localElement, localDefinition, paramMap));
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
      {
        localDefinition.setDocumentationElement(localElement);
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_TYPES, localElement))
      {
        localDefinition.setTypes(parseTypes(localElement, localDefinition));
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_MESSAGE, localElement))
      {
        localDefinition.addMessage(parseMessage(localElement, localDefinition));
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_PORT_TYPE, localElement))
      {
        localDefinition.addPortType(parsePortType(localElement, localDefinition));
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_BINDING, localElement))
      {
        localDefinition.addBinding(parseBinding(localElement, localDefinition));
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_SERVICE, localElement))
      {
        localDefinition.addService(parseService(localElement, localDefinition));
      }
      else
      {
        localDefinition.addExtensibilityElement(parseExtensibilityElement(Definition.class, localElement, localDefinition));
      }
    return localDefinition;
  }

  protected Import parseImport(Element paramElement, Definition paramDefinition, Map paramMap)
    throws WSDLException
  {
    Import localImport = paramDefinition.createImport();
    try
    {
      String str1 = DOMUtils.getAttribute(paramElement, "namespace");
      str2 = DOMUtils.getAttribute(paramElement, "location");
      String str3 = null;
      if (str1 != null)
        localImport.setNamespaceURI(str1);
      if (str2 != null)
      {
        localImport.setLocationURI(str2);
        if (this.importDocuments)
          try
          {
            str3 = paramDefinition.getDocumentBaseURI();
            Definition localDefinition = null;
            InputStream localInputStream = null;
            InputSource localInputSource = null;
            URL localURL = null;
            Object localObject1;
            if (this.loc != null)
            {
              localInputSource = this.loc.getImportInputSource(str3, str2);
              localObject1 = this.loc.getLatestImportURI();
              localDefinition = (Definition)paramMap.get(localObject1);
              localInputSource.setSystemId((String)localObject1);
            }
            else
            {
              localObject1 = str3 != null ? StringUtils.getURL(null, str3) : null;
              localURL = StringUtils.getURL((URL)localObject1, str2);
              localDefinition = (Definition)paramMap.get(localURL.toString());
              if (localDefinition == null)
              {
                localInputStream = StringUtils.getContentAsInputStream(localURL);
                if (localInputStream != null)
                {
                  localInputSource = new InputSource(localInputStream);
                  localInputSource.setSystemId(localURL.toString());
                }
              }
            }
            if (localDefinition == null)
            {
              if (localInputSource == null)
                throw new WSDLException("OTHER_ERROR", "Unable to locate imported document at '" + str2 + "'" + (str3 == null ? "." : new StringBuffer().append(", relative to '").append(str3).append("'.").toString()));
              localObject1 = getDocument(localInputSource, localInputSource.getSystemId());
              if (localInputStream != null)
                localInputStream.close();
              Element localElement2 = ((Document)localObject1).getDocumentElement();
              Object localObject2;
              if (QNameUtils.matches(Constants.Q_ELEM_DEFINITIONS, localElement2))
              {
                if (this.verbose)
                  System.out.println("Retrieving document at '" + str2 + "'" + (str3 == null ? "." : new StringBuffer().append(", relative to '").append(str3).append("'.").toString()));
                localObject2 = localURL != null ? localURL.toString() : this.loc != null ? this.loc.getLatestImportURI() : str2;
                localDefinition = readWSDL((String)localObject2, localElement2, paramMap);
              }
              else
              {
                localObject2 = QNameUtils.newQName(localElement2);
                if (SchemaConstants.XSD_QNAME_LIST.contains(localObject2))
                {
                  WSDLFactory localWSDLFactory = this.factoryImplName != null ? WSDLFactory.newInstance(this.factoryImplName) : WSDLFactory.newInstance();
                  localDefinition = localWSDLFactory.newDefinition();
                  if (this.extReg != null)
                    localDefinition.setExtensionRegistry(this.extReg);
                  String str4 = localURL != null ? localURL.toString() : this.loc != null ? this.loc.getLatestImportURI() : str2;
                  localDefinition.setDocumentBaseURI(str4);
                  Types localTypes = localDefinition.createTypes();
                  localTypes.addExtensibilityElement(parseSchema(Types.class, localElement2, localDefinition));
                  localDefinition.setTypes(localTypes);
                }
              }
            }
            if (localDefinition != null)
              localImport.setDefinition(localDefinition);
          }
          catch (WSDLException localWSDLException2)
          {
            throw localWSDLException2;
          }
          catch (Throwable localThrowable)
          {
            throw new WSDLException("OTHER_ERROR", "Unable to resolve imported document at '" + str2 + (str3 == null ? "'." : new StringBuffer().append("', relative to '").append(str3).append("'").toString()), localThrowable);
          }
      }
    }
    catch (WSDLException localWSDLException1)
    {
      String str2;
      if (localWSDLException1.getLocation() == null)
      {
        localWSDLException1.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      }
      else
      {
        str2 = XPathUtils.getXPathExprFromNode(paramElement) + localWSDLException1.getLocation();
        localWSDLException1.setLocation(str2);
      }
      throw localWSDLException1;
    }
    for (Element localElement1 = DOMUtils.getFirstChildElement(paramElement); localElement1 != null; localElement1 = DOMUtils.getNextSiblingElement(localElement1))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement1))
        localImport.setDocumentationElement(localElement1);
      else
        DOMUtils.throwWSDLException(localElement1);
    parseExtensibilityAttributes(paramElement, Import.class, localImport, paramDefinition);
    return (Import)(Import)localImport;
  }

  protected Types parseTypes(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    List localList = DOMUtils.getAttributes(paramElement);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    Types localTypes = paramDefinition.createTypes();
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
    {
      QName localQName = QNameUtils.newQName(localElement);
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localTypes.setDocumentationElement(localElement);
      else if (SchemaConstants.XSD_QNAME_LIST.contains(localQName))
        localTypes.addExtensibilityElement(parseSchema(Types.class, localElement, paramDefinition));
      else
        localTypes.addExtensibilityElement(parseExtensibilityElement(Types.class, localElement, paramDefinition));
    }
    return localTypes;
  }

  protected ExtensibilityElement parseSchema(Class paramClass, Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Object localObject = null;
    ExtensionRegistry localExtensionRegistry = null;
    try
    {
      localExtensionRegistry = paramDefinition.getExtensionRegistry();
      if (localExtensionRegistry == null)
        throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to deserialize a '" + localObject + "' element in the " + "context of a '" + paramClass.getName() + "'.");
      return parseSchema(paramClass, paramElement, paramDefinition, localExtensionRegistry);
    }
    catch (WSDLException localWSDLException)
    {
      if (localWSDLException.getLocation() == null)
        localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
    }
    throw localWSDLException;
  }

  protected ExtensibilityElement parseSchema(Class paramClass, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    Schema localSchema1 = null;
    SchemaReference localSchemaReference = null;
    try
    {
      QName localQName = QNameUtils.newQName(paramElement);
      localObject1 = paramExtensionRegistry.queryDeserializer(paramClass, localQName);
      ExtensibilityElement localExtensibilityElement = ((ExtensionDeserializer)localObject1).unmarshall(paramClass, localQName, paramElement, paramDefinition, paramExtensionRegistry);
      if ((localExtensibilityElement instanceof Schema))
        localSchema1 = (Schema)localExtensibilityElement;
      else
        return localExtensibilityElement;
      if (localSchema1.getDocumentBaseURI() != null)
        this.allSchemas.put(localSchema1.getDocumentBaseURI(), localSchema1);
      ArrayList localArrayList = new ArrayList();
      Collection localCollection = localSchema1.getImports().values();
      Iterator localIterator = localCollection.iterator();
      while (localIterator.hasNext())
        localArrayList.addAll((Collection)localIterator.next());
      localArrayList.addAll(localSchema1.getIncludes());
      localArrayList.addAll(localSchema1.getRedefines());
      ListIterator localListIterator = localArrayList.listIterator();
      while (localListIterator.hasNext())
        try
        {
          localSchemaReference = (SchemaReference)localListIterator.next();
          if (localSchemaReference.getSchemaLocationURI() == null)
            continue;
          if (this.verbose)
            System.out.println("Retrieving schema at '" + localSchemaReference.getSchemaLocationURI() + (localSchema1.getDocumentBaseURI() == null ? "'." : new StringBuffer().append("', relative to '").append(localSchema1.getDocumentBaseURI()).append("'.").toString()));
          InputStream localInputStream = null;
          InputSource localInputSource = null;
          Schema localSchema2 = null;
          String str = null;
          Object localObject2;
          Object localObject3;
          Object localObject4;
          if (this.loc != null)
          {
            localInputSource = this.loc.getImportInputSource(localSchema1.getDocumentBaseURI(), localSchemaReference.getSchemaLocationURI());
            if (localInputSource == null)
              throw new WSDLException("OTHER_ERROR", "Unable to locate with a locator the schema referenced at '" + localSchemaReference.getSchemaLocationURI() + "' relative to document base '" + localSchema1.getDocumentBaseURI() + "'");
            str = this.loc.getLatestImportURI();
            localSchema2 = (Schema)this.allSchemas.get(str);
          }
          else
          {
            localObject2 = localSchema1.getDocumentBaseURI();
            localObject3 = localObject2 != null ? StringUtils.getURL(null, (String)localObject2) : null;
            localObject4 = StringUtils.getURL((URL)localObject3, localSchemaReference.getSchemaLocationURI());
            str = ((URL)localObject4).toExternalForm();
            localSchema2 = (Schema)this.allSchemas.get(str);
            if (localSchema2 == null)
            {
              localInputStream = StringUtils.getContentAsInputStream((URL)localObject4);
              if (localInputStream != null)
                localInputSource = new InputSource(localInputStream);
              if (localInputSource == null)
                throw new WSDLException("OTHER_ERROR", "Unable to locate with a url the document referenced at '" + localSchemaReference.getSchemaLocationURI() + "'" + (localObject2 == null ? "." : new StringBuffer().append(", relative to '").append((String)localObject2).append("'.").toString()));
            }
          }
          if (localSchema2 == null)
          {
            localInputSource.setSystemId(str);
            localObject2 = getDocument(localInputSource, str);
            if (localInputStream != null)
              localInputStream.close();
            localObject3 = ((Document)localObject2).getDocumentElement();
            localObject4 = QNameUtils.newQName((Node)localObject3);
            if (SchemaConstants.XSD_QNAME_LIST.contains(localObject4))
            {
              WSDLFactory localWSDLFactory = this.factoryImplName != null ? WSDLFactory.newInstance(this.factoryImplName) : WSDLFactory.newInstance();
              Definition localDefinition = localWSDLFactory.newDefinition();
              localDefinition.setDocumentBaseURI(str);
              localSchema2 = (Schema)parseSchema(paramClass, (Element)localObject3, localDefinition, paramExtensionRegistry);
            }
          }
          localSchemaReference.setReferencedSchema(localSchema2);
        }
        catch (WSDLException localWSDLException2)
        {
          throw localWSDLException2;
        }
        catch (Throwable localThrowable)
        {
          throw new WSDLException("OTHER_ERROR", "An error occurred trying to resolve schema referenced at '" + localSchemaReference.getSchemaLocationURI() + "'" + (localSchema1.getDocumentBaseURI() == null ? "." : new StringBuffer().append(", relative to '").append(localSchema1.getDocumentBaseURI()).append("'.").toString()), localThrowable);
        }
      return localSchema1;
    }
    catch (WSDLException localWSDLException1)
    {
      Object localObject1;
      if (localWSDLException1.getLocation() == null)
      {
        localWSDLException1.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      }
      else
      {
        localObject1 = XPathUtils.getXPathExprFromNode(paramElement) + localWSDLException1.getLocation();
        localWSDLException1.setLocation((String)localObject1);
      }
    }
    throw localWSDLException1;
  }

  protected Binding parseBinding(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Binding localBinding = null;
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    QName localQName = getQualifiedAttributeValue(paramElement, "type", "binding", paramDefinition, localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    PortType localPortType = null;
    if (str != null)
    {
      localObject = new QName(paramDefinition.getTargetNamespace(), str);
      localBinding = paramDefinition.getBinding((QName)localObject);
      if (localBinding == null)
      {
        localBinding = paramDefinition.createBinding();
        localBinding.setQName((QName)localObject);
      }
    }
    else
    {
      localBinding = paramDefinition.createBinding();
    }
    localBinding.setUndefined(false);
    if (localQName != null)
    {
      localPortType = paramDefinition.getPortType(localQName);
      if (localPortType == null)
      {
        localPortType = paramDefinition.createPortType();
        localPortType.setQName(localQName);
        paramDefinition.addPortType(localPortType);
      }
      localBinding.setPortType(localPortType);
    }
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localBinding.setDocumentationElement((Element)localObject);
      else if (QNameUtils.matches(Constants.Q_ELEM_OPERATION, (Node)localObject))
        localBinding.addBindingOperation(parseBindingOperation((Element)localObject, localPortType, paramDefinition));
      else
        localBinding.addExtensibilityElement(parseExtensibilityElement(Binding.class, (Element)localObject, paramDefinition));
    return (Binding)localBinding;
  }

  protected BindingOperation parseBindingOperation(Element paramElement, PortType paramPortType, Definition paramDefinition)
    throws WSDLException
  {
    BindingOperation localBindingOperation = paramDefinition.createBindingOperation();
    List localList = DOMUtils.getAttributes(paramElement);
    String str1 = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str1 != null)
      localBindingOperation.setName(str1);
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localBindingOperation.setDocumentationElement(localElement);
      else if (QNameUtils.matches(Constants.Q_ELEM_INPUT, localElement))
        localBindingOperation.setBindingInput(parseBindingInput(localElement, paramDefinition));
      else if (QNameUtils.matches(Constants.Q_ELEM_OUTPUT, localElement))
        localBindingOperation.setBindingOutput(parseBindingOutput(localElement, paramDefinition));
      else if (QNameUtils.matches(Constants.Q_ELEM_FAULT, localElement))
        localBindingOperation.addBindingFault(parseBindingFault(localElement, paramDefinition));
      else
        localBindingOperation.addExtensibilityElement(parseExtensibilityElement(BindingOperation.class, localElement, paramDefinition));
    if (paramPortType != null)
    {
      BindingInput localBindingInput = localBindingOperation.getBindingInput();
      BindingOutput localBindingOutput = localBindingOperation.getBindingOutput();
      String str2 = localBindingInput != null ? localBindingInput.getName() : null;
      String str3 = localBindingOutput != null ? localBindingOutput.getName() : null;
      Operation localOperation = paramPortType.getOperation(str1, str2, str3);
      if (localOperation == null)
      {
        Input localInput = paramDefinition.createInput();
        Output localOutput = paramDefinition.createOutput();
        localOperation = paramDefinition.createOperation();
        localOperation.setName(str1);
        localInput.setName(str2);
        localOutput.setName(str3);
        localOperation.setInput(localInput);
        localOperation.setOutput(localOutput);
        paramPortType.addOperation(localOperation);
      }
      localBindingOperation.setOperation(localOperation);
    }
    return localBindingOperation;
  }

  protected BindingInput parseBindingInput(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    BindingInput localBindingInput = paramDefinition.createBindingInput();
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
      localBindingInput.setName(str);
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localBindingInput.setDocumentationElement(localElement);
      else
        localBindingInput.addExtensibilityElement(parseExtensibilityElement(BindingInput.class, localElement, paramDefinition));
    return localBindingInput;
  }

  protected BindingOutput parseBindingOutput(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    BindingOutput localBindingOutput = paramDefinition.createBindingOutput();
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
      localBindingOutput.setName(str);
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localBindingOutput.setDocumentationElement(localElement);
      else
        localBindingOutput.addExtensibilityElement(parseExtensibilityElement(BindingOutput.class, localElement, paramDefinition));
    return localBindingOutput;
  }

  protected BindingFault parseBindingFault(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    BindingFault localBindingFault = paramDefinition.createBindingFault();
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
      localBindingFault.setName(str);
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localBindingFault.setDocumentationElement(localElement);
      else
        localBindingFault.addExtensibilityElement(parseExtensibilityElement(BindingFault.class, localElement, paramDefinition));
    return localBindingFault;
  }

  protected Message parseMessage(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Message localMessage = null;
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
    {
      localObject = new QName(paramDefinition.getTargetNamespace(), str);
      localMessage = paramDefinition.getMessage((QName)localObject);
      if (localMessage == null)
      {
        localMessage = paramDefinition.createMessage();
        localMessage.setQName((QName)localObject);
      }
    }
    else
    {
      localMessage = paramDefinition.createMessage();
    }
    localMessage.setUndefined(false);
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localMessage.setDocumentationElement((Element)localObject);
      else if (QNameUtils.matches(Constants.Q_ELEM_PART, (Node)localObject))
        localMessage.addPart(parsePart((Element)localObject, paramDefinition));
      else
        localMessage.addExtensibilityElement(parseExtensibilityElement(Message.class, (Element)localObject, paramDefinition));
    return (Message)localMessage;
  }

  protected Part parsePart(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Part localPart = paramDefinition.createPart();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName localQName1 = getQualifiedAttributeValue(paramElement, "element", "message", paramDefinition);
    QName localQName2 = getQualifiedAttributeValue(paramElement, "type", "message", paramDefinition);
    if (str != null)
      localPart.setName(str);
    if (localQName1 != null)
      localPart.setElementName(localQName1);
    if (localQName2 != null)
      localPart.setTypeName(localQName2);
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localPart.setDocumentationElement(localElement);
      else
        DOMUtils.throwWSDLException(localElement);
    parseExtensibilityAttributes(paramElement, Part.class, localPart, paramDefinition);
    return localPart;
  }

  protected void parseExtensibilityAttributes(Element paramElement, Class paramClass, AttributeExtensible paramAttributeExtensible, Definition paramDefinition)
    throws WSDLException
  {
    List localList = paramAttributeExtensible.getNativeAttributeNames();
    NamedNodeMap localNamedNodeMap = paramElement.getAttributes();
    int i = localNamedNodeMap.getLength();
    for (int j = 0; j < i; j++)
    {
      Attr localAttr = (Attr)localNamedNodeMap.item(j);
      String str1 = localAttr.getLocalName();
      String str2 = localAttr.getNamespaceURI();
      String str3 = localAttr.getPrefix();
      QName localQName = new QName(str2, str1);
      Object localObject1;
      if ((str2 != null) && (!str2.equals("http://schemas.xmlsoap.org/wsdl/")))
      {
        if (str2.equals("http://www.w3.org/2000/xmlns/"))
          continue;
        DOMUtils.registerUniquePrefix(str3, str2, paramDefinition);
        localObject1 = localAttr.getValue();
        int k = -1;
        ExtensionRegistry localExtensionRegistry = paramDefinition.getExtensionRegistry();
        if (localExtensionRegistry != null)
          k = localExtensionRegistry.queryExtensionAttributeType(paramClass, localQName);
        Object localObject2 = parseExtensibilityAttribute(paramElement, k, (String)localObject1, paramDefinition);
        paramAttributeExtensible.setExtensionAttribute(localQName, localObject2);
      }
      else
      {
        if (localList.contains(str1))
          continue;
        localObject1 = new WSDLException("INVALID_WSDL", "Encountered illegal extension attribute '" + localQName + "'. Extension " + "attributes must be in " + "a namespace other than " + "WSDL's.");
        ((WSDLException)localObject1).setLocation(XPathUtils.getXPathExprFromNode(paramElement));
        throw ((Throwable)localObject1);
      }
    }
  }

  protected Object parseExtensibilityAttribute(Element paramElement, int paramInt, String paramString, Definition paramDefinition)
    throws WSDLException
  {
    if (paramInt == 1)
      return DOMUtils.getQName(paramString, paramElement, paramDefinition);
    if (paramInt == 2)
      return StringUtils.parseNMTokens(paramString);
    if (paramInt == 3)
    {
      localObject = StringUtils.parseNMTokens(paramString);
      int i = ((List)localObject).size();
      Vector localVector = new Vector(i);
      for (int j = 0; j < i; j++)
      {
        String str = (String)((List)localObject).get(j);
        QName localQName = DOMUtils.getQName(str, paramElement, paramDefinition);
        localVector.add(localQName);
      }
      return localVector;
    }
    if (paramInt == 0)
      return paramString;
    Object localObject = null;
    try
    {
      localObject = DOMUtils.getQName(paramString, paramElement, paramDefinition);
    }
    catch (WSDLException localWSDLException)
    {
      localObject = new QName(paramString);
    }
    return localObject;
  }

  protected PortType parsePortType(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    PortType localPortType = null;
    String str = DOMUtils.getAttribute(paramElement, "name");
    if (str != null)
    {
      localObject = new QName(paramDefinition.getTargetNamespace(), str);
      localPortType = paramDefinition.getPortType((QName)localObject);
      if (localPortType == null)
      {
        localPortType = paramDefinition.createPortType();
        localPortType.setQName((QName)localObject);
      }
    }
    else
    {
      localPortType = paramDefinition.createPortType();
    }
    localPortType.setUndefined(false);
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
      {
        localPortType.setDocumentationElement((Element)localObject);
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_OPERATION, (Node)localObject))
      {
        Operation localOperation = parseOperation((Element)localObject, localPortType, paramDefinition);
        if (localOperation == null)
          continue;
        localPortType.addOperation(localOperation);
      }
      else
      {
        DOMUtils.throwWSDLException((Element)localObject);
      }
    parseExtensibilityAttributes(paramElement, PortType.class, localPortType, paramDefinition);
    return (PortType)localPortType;
  }

  protected Operation parseOperation(Element paramElement, PortType paramPortType, Definition paramDefinition)
    throws WSDLException
  {
    Operation localOperation = null;
    List localList = DOMUtils.getAttributes(paramElement);
    String str1 = DOMUtils.getAttribute(paramElement, "name", localList);
    String str2 = DOMUtils.getAttribute(paramElement, "parameterOrder", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    Element localElement1 = DOMUtils.getFirstChildElement(paramElement);
    Vector localVector1 = new Vector();
    Element localElement2 = null;
    Input localInput = null;
    Output localOutput = null;
    Vector localVector2 = new Vector();
    Vector localVector3 = new Vector();
    int i = 1;
    while (localElement1 != null)
    {
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement1))
      {
        localElement2 = localElement1;
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_INPUT, localElement1))
      {
        localInput = parseInput(localElement1, paramDefinition);
        localVector1.add("input");
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_OUTPUT, localElement1))
      {
        localOutput = parseOutput(localElement1, paramDefinition);
        localVector1.add("output");
      }
      else if (QNameUtils.matches(Constants.Q_ELEM_FAULT, localElement1))
      {
        localVector2.add(parseFault(localElement1, paramDefinition));
      }
      else
      {
        localVector3.add(parseExtensibilityElement(Operation.class, localElement1, paramDefinition));
      }
      localElement1 = DOMUtils.getNextSiblingElement(localElement1);
    }
    if (str1 != null)
    {
      localObject1 = localInput != null ? localInput.getName() : null;
      String str3 = localOutput != null ? localOutput.getName() : null;
      localOperation = paramPortType.getOperation(str1, (String)localObject1, str3);
      if ((localOperation != null) && (!localOperation.isUndefined()))
        localOperation = null;
      Object localObject2;
      if ((localOperation != null) && (localObject1 == null))
      {
        localObject2 = localOperation.getInput();
        if ((localObject2 != null) && (((Input)localObject2).getName() != null))
          localOperation = null;
      }
      if ((localOperation != null) && (str3 == null))
      {
        localObject2 = localOperation.getOutput();
        if ((localObject2 != null) && (((Output)localObject2).getName() != null))
          localOperation = null;
      }
      if (localOperation == null)
      {
        localOperation = paramDefinition.createOperation();
        localOperation.setName(str1);
        i = 0;
      }
    }
    else
    {
      localOperation = paramDefinition.createOperation();
      i = 0;
    }
    localOperation.setUndefined(false);
    if (str2 != null)
      localOperation.setParameterOrdering(StringUtils.parseNMTokens(str2));
    if (localElement2 != null)
      localOperation.setDocumentationElement(localElement2);
    if (localInput != null)
      localOperation.setInput(localInput);
    if (localOutput != null)
      localOperation.setOutput(localOutput);
    if (localVector2.size() > 0)
    {
      localObject1 = localVector2.iterator();
      while (((Iterator)localObject1).hasNext())
        localOperation.addFault((Fault)((Iterator)localObject1).next());
    }
    if (localVector3.size() > 0)
    {
      localObject1 = localVector3.iterator();
      while (((Iterator)localObject1).hasNext())
        localOperation.addExtensibilityElement((ExtensibilityElement)((Iterator)localObject1).next());
    }
    Object localObject1 = null;
    if (localVector1.equals(STYLE_ONE_WAY))
      localObject1 = OperationType.ONE_WAY;
    else if (localVector1.equals(STYLE_REQUEST_RESPONSE))
      localObject1 = OperationType.REQUEST_RESPONSE;
    else if (localVector1.equals(STYLE_SOLICIT_RESPONSE))
      localObject1 = OperationType.SOLICIT_RESPONSE;
    else if (localVector1.equals(STYLE_NOTIFICATION))
      localObject1 = OperationType.NOTIFICATION;
    if (localObject1 != null)
      localOperation.setStyle((OperationType)localObject1);
    if (i != 0)
      localOperation = null;
    return (Operation)(Operation)localOperation;
  }

  protected Service parseService(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Service localService = paramDefinition.createService();
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
      localService.setQName(new QName(paramDefinition.getTargetNamespace(), str));
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, localElement))
        localService.setDocumentationElement(localElement);
      else if (QNameUtils.matches(Constants.Q_ELEM_PORT, localElement))
        localService.addPort(parsePort(localElement, paramDefinition));
      else
        localService.addExtensibilityElement(parseExtensibilityElement(Service.class, localElement, paramDefinition));
    return localService;
  }

  protected Port parsePort(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Port localPort = paramDefinition.createPort();
    List localList = DOMUtils.getAttributes(paramElement);
    String str = DOMUtils.getAttribute(paramElement, "name", localList);
    QName localQName = getQualifiedAttributeValue(paramElement, "binding", "port", paramDefinition, localList);
    if (!localList.isEmpty())
      DOMUtils.throwWSDLException(paramElement, localList);
    if (str != null)
      localPort.setName(str);
    if (localQName != null)
    {
      localObject = paramDefinition.getBinding(localQName);
      if (localObject == null)
      {
        localObject = paramDefinition.createBinding();
        ((Binding)localObject).setQName(localQName);
        paramDefinition.addBinding((Binding)localObject);
      }
      localPort.setBinding((Binding)localObject);
    }
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localPort.setDocumentationElement((Element)localObject);
      else
        localPort.addExtensibilityElement(parseExtensibilityElement(Port.class, (Element)localObject, paramDefinition));
    return (Port)localPort;
  }

  protected ExtensibilityElement parseExtensibilityElement(Class paramClass, Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    QName localQName = QNameUtils.newQName(paramElement);
    String str = paramElement.getNamespaceURI();
    try
    {
      if ((str == null) || (str.equals("http://schemas.xmlsoap.org/wsdl/")))
        throw new WSDLException("INVALID_WSDL", "Encountered illegal extension element '" + localQName + "' in the context of a '" + paramClass.getName() + "'. Extension elements must be in " + "a namespace other than WSDL's.");
      ExtensionRegistry localExtensionRegistry = paramDefinition.getExtensionRegistry();
      if (localExtensionRegistry == null)
        throw new WSDLException("CONFIGURATION_ERROR", "No ExtensionRegistry set for this Definition, so unable to deserialize a '" + localQName + "' element in the " + "context of a '" + paramClass.getName() + "'.");
      ExtensionDeserializer localExtensionDeserializer = localExtensionRegistry.queryDeserializer(paramClass, localQName);
      return localExtensionDeserializer.unmarshall(paramClass, localQName, paramElement, paramDefinition, localExtensionRegistry);
    }
    catch (WSDLException localWSDLException)
    {
      if (localWSDLException.getLocation() == null)
        localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
    }
    throw localWSDLException;
  }

  protected Input parseInput(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Input localInput = paramDefinition.createInput();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName localQName = getQualifiedAttributeValue(paramElement, "message", "input", paramDefinition);
    if (str != null)
      localInput.setName(str);
    if (localQName != null)
    {
      localObject = paramDefinition.getMessage(localQName);
      if (localObject == null)
      {
        localObject = paramDefinition.createMessage();
        ((Message)localObject).setQName(localQName);
        paramDefinition.addMessage((Message)localObject);
      }
      localInput.setMessage((Message)localObject);
    }
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localInput.setDocumentationElement((Element)localObject);
      else
        DOMUtils.throwWSDLException((Element)localObject);
    parseExtensibilityAttributes(paramElement, Input.class, localInput, paramDefinition);
    return (Input)localInput;
  }

  protected Output parseOutput(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Output localOutput = paramDefinition.createOutput();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName localQName = getQualifiedAttributeValue(paramElement, "message", "output", paramDefinition);
    if (str != null)
      localOutput.setName(str);
    if (localQName != null)
    {
      localObject = paramDefinition.getMessage(localQName);
      if (localObject == null)
      {
        localObject = paramDefinition.createMessage();
        ((Message)localObject).setQName(localQName);
        paramDefinition.addMessage((Message)localObject);
      }
      localOutput.setMessage((Message)localObject);
    }
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localOutput.setDocumentationElement((Element)localObject);
      else
        DOMUtils.throwWSDLException((Element)localObject);
    parseExtensibilityAttributes(paramElement, Output.class, localOutput, paramDefinition);
    return (Output)localOutput;
  }

  protected Fault parseFault(Element paramElement, Definition paramDefinition)
    throws WSDLException
  {
    Fault localFault = paramDefinition.createFault();
    String str = DOMUtils.getAttribute(paramElement, "name");
    QName localQName = getQualifiedAttributeValue(paramElement, "message", "fault", paramDefinition);
    if (str != null)
      localFault.setName(str);
    if (localQName != null)
    {
      localObject = paramDefinition.getMessage(localQName);
      if (localObject == null)
      {
        localObject = paramDefinition.createMessage();
        ((Message)localObject).setQName(localQName);
        paramDefinition.addMessage((Message)localObject);
      }
      localFault.setMessage((Message)localObject);
    }
    for (Object localObject = DOMUtils.getFirstChildElement(paramElement); localObject != null; localObject = DOMUtils.getNextSiblingElement((Element)localObject))
      if (QNameUtils.matches(Constants.Q_ELEM_DOCUMENTATION, (Node)localObject))
        localFault.setDocumentationElement((Element)localObject);
      else
        DOMUtils.throwWSDLException((Element)localObject);
    parseExtensibilityAttributes(paramElement, Fault.class, localFault, paramDefinition);
    return (Fault)localFault;
  }

  private static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, Definition paramDefinition)
    throws WSDLException
  {
    try
    {
      return DOMUtils.getQualifiedAttributeValue(paramElement, paramString1, paramString2, false, paramDefinition);
    }
    catch (WSDLException localWSDLException)
    {
      if (localWSDLException.getFaultCode().equals("NO_PREFIX_SPECIFIED"))
      {
        String str = DOMUtils.getAttribute(paramElement, paramString1);
        return new QName(str);
      }
    }
    throw localWSDLException;
  }

  private static QName getQualifiedAttributeValue(Element paramElement, String paramString1, String paramString2, Definition paramDefinition, List paramList)
    throws WSDLException
  {
    try
    {
      return DOMUtils.getQualifiedAttributeValue(paramElement, paramString1, paramString2, false, paramDefinition, paramList);
    }
    catch (WSDLException localWSDLException)
    {
      if (localWSDLException.getFaultCode().equals("NO_PREFIX_SPECIFIED"))
      {
        String str = DOMUtils.getAttribute(paramElement, paramString1, paramList);
        return new QName(str);
      }
    }
    throw localWSDLException;
  }

  private static void checkElementName(Element paramElement, QName paramQName)
    throws WSDLException
  {
    if (!QNameUtils.matches(paramQName, paramElement))
    {
      WSDLException localWSDLException = new WSDLException("INVALID_WSDL", "Expected element '" + paramQName + "'.");
      localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(paramElement));
      throw localWSDLException;
    }
  }

  private static Document getDocument(InputSource paramInputSource, String paramString)
    throws WSDLException
  {
    DocumentBuilderFactory localDocumentBuilderFactory = DocumentBuilderFactory.newInstance();
    localDocumentBuilderFactory.setNamespaceAware(true);
    localDocumentBuilderFactory.setValidating(false);
    try
    {
      DocumentBuilder localDocumentBuilder = localDocumentBuilderFactory.newDocumentBuilder();
      Document localDocument = localDocumentBuilder.parse(paramInputSource);
      return localDocument;
    }
    catch (Throwable localThrowable)
    {
    }
    throw new WSDLException("PARSER_ERROR", "Problem parsing '" + paramString + "'.", localThrowable);
  }

  public Definition readWSDL(String paramString)
    throws WSDLException
  {
    return readWSDL(null, paramString);
  }

  public Definition readWSDL(String paramString1, String paramString2)
    throws WSDLException
  {
    try
    {
      if (this.verbose)
        System.out.println("Retrieving document at '" + paramString2 + "'" + (paramString1 == null ? "." : new StringBuffer().append(", relative to '").append(paramString1).append("'.").toString()));
      URL localURL1 = paramString1 != null ? StringUtils.getURL(null, paramString1) : null;
      URL localURL2 = StringUtils.getURL(localURL1, paramString2);
      InputStream localInputStream = StringUtils.getContentAsInputStream(localURL2);
      InputSource localInputSource = new InputSource(localInputStream);
      localInputSource.setSystemId(localURL2.toString());
      Document localDocument = getDocument(localInputSource, localURL2.toString());
      localInputStream.close();
      Definition localDefinition = readWSDL(localURL2.toString(), localDocument);
      return localDefinition;
    }
    catch (WSDLException localWSDLException)
    {
      throw localWSDLException;
    }
    catch (Throwable localThrowable)
    {
      if (paramString1 == null)
        tmpTernaryOp = "'.";
    }
    throw new WSDLException("OTHER_ERROR", "Unable to resolve imported document at '" + paramString2 + new StringBuffer().append("', relative to '").append(paramString1).append("'.").toString(), localThrowable);
  }

  public Definition readWSDL(String paramString, Element paramElement)
    throws WSDLException
  {
    return readWSDL(paramString, paramElement, null);
  }

  protected Definition readWSDL(String paramString, Element paramElement, Map paramMap)
    throws WSDLException
  {
    return parseDefinitions(paramString, paramElement, paramMap);
  }

  public Definition readWSDL(String paramString, Document paramDocument)
    throws WSDLException
  {
    return readWSDL(paramString, paramDocument.getDocumentElement());
  }

  public Definition readWSDL(String paramString, InputSource paramInputSource)
    throws WSDLException
  {
    String str = paramInputSource.getSystemId() != null ? paramInputSource.getSystemId() : "- WSDL Document -";
    return readWSDL(paramString, getDocument(paramInputSource, str));
  }

  public Definition readWSDL(WSDLLocator paramWSDLLocator)
    throws WSDLException
  {
    InputSource localInputSource = paramWSDLLocator.getBaseInputSource();
    String str = paramWSDLLocator.getBaseURI();
    localInputSource.setSystemId(str);
    if (localInputSource == null)
      throw new WSDLException("OTHER_ERROR", "Unable to locate document at '" + str + "'.");
    this.loc = paramWSDLLocator;
    if (this.verbose)
      System.out.println("Retrieving document at '" + str + "'.");
    return readWSDL(str, localInputSource);
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.xml.WSDLReaderImpl
 * JD-Core Version:    0.6.0
 */