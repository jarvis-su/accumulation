/*    */ package ch.ethz.ssh2.util;
/*    */ 
/*    */ public class Tokenizer
/*    */ {
/*    */   public static String[] parseTokens(String source, char delimiter)
/*    */   {
/* 22 */     int numtoken = 1;
/*    */ 
/* 24 */     for (int i = 0; i < source.length(); i++)
/*    */     {
/* 26 */       if (source.charAt(i) == delimiter) {
/* 27 */         numtoken++;
/*    */       }
/*    */     }
/* 30 */     String[] list = new String[numtoken];
/* 31 */     int nextfield = 0;
/*    */ 
/* 33 */     for (int i = 0; i < numtoken; i++)
/*    */     {
/* 35 */       if (nextfield >= source.length())
/*    */       {
/* 37 */         list[i] = "";
/*    */       }
/*    */       else
/*    */       {
/* 41 */         int idx = source.indexOf(delimiter, nextfield);
/* 42 */         if (idx == -1)
/* 43 */           idx = source.length();
/* 44 */         list[i] = source.substring(nextfield, idx);
/* 45 */         nextfield = idx + 1;
/*    */       }
/*    */     }
/*    */ 
/* 49 */     return list;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.util.Tokenizer
 * JD-Core Version:    0.6.0
 */