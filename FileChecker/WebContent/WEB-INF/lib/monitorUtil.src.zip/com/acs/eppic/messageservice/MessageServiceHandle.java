/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.AlertData;
/*     */ import com.acs.eppic.message.AsyncAlert;
/*     */ import com.acs.eppic.message.CorbaProxyAlert;
/*     */ import com.acs.eppic.message.ExtFileAlert;
/*     */ import com.acs.eppic.message.ExtFileInfo;
/*     */ import com.acs.eppic.message.InfoData;
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import com.acs.eppic.message.PersistenceAlert;
/*     */ import com.acs.eppic.message.RegistrationData;
/*     */ import com.acs.eppic.message.ReportAlert;
/*     */ import com.acs.eppic.message.ReportInfo;
/*     */ import com.acs.eppic.message.SysMgrAlert;
/*     */ import com.acs.eppic.message.SysProcAlert;
/*     */ import com.acs.eppic.message.SysProcInfo;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MessageServiceHandle
/*     */ {
/*  17 */   protected MessageService ms = MessageService.getSoleInstance();
/*  18 */   protected Logger logger = Logger.getLogger("MessageService");
/*     */   private HashMap sentMap;
/*     */   private String svcId;
/*     */   private String sysId;
/*     */   private String port;
/*     */   protected MessageRecipient recipient;
/*     */ 
/*     */   public MessageServiceHandle(String systemId, String serviceId, String port, MessageRecipient recipient)
/*     */   {
/*  30 */     this.svcId = serviceId;
/*  31 */     this.sysId = systemId;
/*  32 */     this.port = port;
/*  33 */     this.recipient = recipient;
/*  34 */     this.sentMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public void receiveIncoming(Message message)
/*     */   {
/*  46 */     if (this.recipient != null)
/*  47 */       this.recipient.receiveIncoming(message);
/*     */     else
/*  49 */       switch (message.getType().getTypeId()) {
/*     */       case 0:
/*  51 */         this.logger.info("SystemId: " + getSysId() + ", " + 
/*  52 */           "ServiceId: " + getSvcId() + " is connected to the monitor");
/*  53 */         break;
/*     */       case 1:
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*  59 */         this.logger.error("UNABLE TO PROCESS MESSAGES OF THIS TYPE.\n" + message);
/*  60 */         break;
/*     */       default:
/*  62 */         this.logger.error("INVALID MESSAGE TYPE.\n" + message);
/*     */       }
/*     */   }
/*     */ 
/*     */   public void register()
/*     */   {
/*  69 */     Message m = new Message(this.sysId, this.svcId, 5, this.port);
/*  70 */     m.setM_MessageData(new RegistrationData(this.ms.getRegistration_timeout()));
/*  71 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public void sendAck(Message forMsg)
/*     */   {
/*  80 */     Message m = new Message(forMsg.getSystemId(), forMsg.getServiceId(), 0, forMsg.getIP(), forMsg.getPort());
/*  81 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public boolean isOkToSend(String hashKey)
/*     */   {
/* 101 */     if (!this.ms.isServiceEnabled()) {
/* 102 */       return false;
/*     */     }
/* 104 */     boolean sendIt = false;
/*     */ 
/* 106 */     Date d2 = new Date();
/* 107 */     synchronized (this.sentMap)
/*     */     {
/* 109 */       Date d1 = (Date)this.sentMap.get(hashKey);
/* 110 */       if ((d1 == null) || (d2.getTime() - d1.getTime() > this.ms.getResend_interval() * 1000))
/*     */       {
/* 112 */         this.sentMap.put(hashKey, d2);
/* 113 */         sendIt = true;
/*     */       }
/*     */     }
/*     */     Date d1;
/* 116 */     return sendIt;
/*     */   }
/*     */ 
/*     */   public void sendAlert(String code, String description)
/*     */   {
/* 122 */     if (isOkToSend(code)) {
/* 123 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 124 */       m.setM_MessageData(new AlertData(code, description));
/* 125 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendAsyncAlert(String code, String description, int cc, int tlogId, ArrayList idTable)
/*     */   {
/* 132 */     if (isOkToSend(code)) {
/* 133 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 134 */       m.setM_MessageData(new AsyncAlert(code, description, cc, idTable, tlogId));
/* 135 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendCORBAProxyAlert(String code, String description, String methodName, long responseTime)
/*     */   {
/* 141 */     if (isOkToSend(code + methodName)) {
/* 142 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 143 */       m.setM_MessageData(new CorbaProxyAlert(code, description, methodName, responseTime));
/* 144 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendExtFileAlert(String code, String description, String fileName)
/*     */   {
/* 150 */     if (isOkToSend(code + fileName)) {
/* 151 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 152 */       m.setM_MessageData(new ExtFileAlert(code, description, fileName));
/* 153 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendFESAlert(String code, String description)
/*     */   {
/* 159 */     if (isOkToSend(code))
/* 160 */       sendAlert(code, description);
/*     */   }
/*     */ 
/*     */   public void sendPersistenceAlert(String code, String description, int numSqlErrors, int numTimeouts)
/*     */   {
/* 167 */     if (isOkToSend(code)) {
/* 168 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 169 */       m.setM_MessageData(new PersistenceAlert(code, description, numSqlErrors, numTimeouts));
/* 170 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendReportAlert(String code, String description, String reportName, String arguments)
/*     */   {
/* 177 */     if (isOkToSend(code + reportName)) {
/* 178 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 179 */       m.setM_MessageData(new ReportAlert(code, description, reportName, arguments));
/* 180 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendSysMgrAlert(String code, String description, int memRemaining)
/*     */   {
/* 186 */     if (isOkToSend(code)) {
/* 187 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 188 */       m.setM_MessageData(new SysMgrAlert(code, description, memRemaining));
/* 189 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void sendSysProcAlert(String code, String description, String arguments, String procName)
/*     */   {
/* 196 */     if (isOkToSend(code + procName)) {
/* 197 */       Message m = new Message(this.sysId, this.svcId, 1, this.port);
/* 198 */       m.setM_MessageData(new SysProcAlert(code, description, procName, arguments));
/* 199 */       this.ms.enqueue(m);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void disconnect()
/*     */   {
/* 209 */     Message m = new Message(this.sysId, this.svcId, 2, this.port);
/* 210 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public void sendInfo()
/*     */   {
/* 218 */     Message m = new Message(this.sysId, this.svcId, 4, this.port);
/* 219 */     m.setM_MessageData(new InfoData());
/* 220 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public void sendExtFileInfo(String fileName, boolean isStart, int recLen, int numProcessed, int numRejected)
/*     */   {
/* 226 */     Message m = new Message(this.sysId, this.svcId, 4, this.port);
/* 227 */     m.setM_MessageData(new ExtFileInfo(fileName, numProcessed, numRejected, recLen, isStart));
/* 228 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public void sendReportInfo(String reportName, boolean isAuto, boolean isStart)
/*     */   {
/* 233 */     Message m = new Message(this.sysId, this.svcId, 4, this.port);
/* 234 */     m.setM_MessageData(new ReportInfo(reportName, isAuto, isStart));
/* 235 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public void sendSysProcInfo(String processName, boolean isStart) {
/* 239 */     Message m = new Message(this.sysId, this.svcId, 4, this.port);
/* 240 */     m.setM_MessageData(new SysProcInfo(processName, isStart));
/* 241 */     this.ms.enqueue(m);
/*     */   }
/*     */ 
/*     */   public String getSvcId()
/*     */   {
/* 246 */     return this.svcId;
/*     */   }
/*     */ 
/*     */   public String getSysId() {
/* 250 */     return this.sysId;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.MessageServiceHandle
 * JD-Core Version:    0.6.0
 */