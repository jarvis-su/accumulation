package com.acs.eppic.messageservice;

public class MessageServiceLookup
{
  public static final String SERVICE_NAME_HEARBEAT = "HEARTBEAT";
  public static final String SERVICE_NAME_MONITOR = "MONITOR";
  public static final String SERVICE_NAME_EXTFILE = "EXTFILE";
  public static final String SERVICE_NAME_REPORTS = "REPORTS";
  public static final String SERVICE_NAME_ASYNC = "ASYNC";
  public static final String SERVICE_NAME_PERSISTANCE = "PERSISTANCE";
  public static final String SERVICE_NAME_PROCESS = "PROCESS";
  public static final String SERVICE_NAME_SYSMGR = "SYSMGR";
  public static final String SERVICE_NAME_FES = "FES";
  public static final String SERVICE_NAME_VRU = "VRU";
  public static final String SERVICE_NAME_HOST2HOST = "HOST2HOST";
  public static final String SERVICE_NAME_FILECHECK = "FILECHECK";
  public static final String SERVICE_NAME_GENERIC1 = "_GENERIC_1";
  public static final String SERVICE_NAME_GENERIC2 = "_GENERIC_2";
  public static final String SERVICE_NAME_GENERIC3 = "_GENERIC_3";
  public static final String SERVICE_NAME_GENERIC4 = "_GENERIC_4";
  public static final String EXTFILE_ERROR_ON_STARTUP = "EXT0001";
  public static final String EXTFILE_ERROR_SKIPPED_FILE = "EXT0002";
  public static final String EXTFILE_ERROR_MOVING_FILE = "EXT0003";
  public static final String EXTFILE_ERROR_COMPLETE_FILE_FAILURE = "EXT0004";
  public static final String EXTFILE_ERROR_UNKNOWN = "EXT9999";
  public static final String FES_ERROR_ON_STARTUP = "FES0001";
  public static final String FES_ERROR_UNKNOWN = "FES9999";
  public static final String IVR_ERROR_ON_STARTUP = "IVR0001";
  public static final String IVR_ERROR_DISK_IO = "IVR0002";
  public static final String IVR_SLOW_RESPONSE = "IVR0003";
  public static final String IVR_ERROR_EPPIC_DOWN = "IVR0004";
  public static final String IVR_UNHANDLED_ERROR = "IVR0005";
  public static final String IVR_ERROR_UNKNOWN = "IVR9999";
  public static final String SYSTEM_ERROR_ON_STARTUP = "SYS0001";
  public static final String SYSTEM_ERROR_ALL_THREADS = "SYS0002";
  public static final String SYSTEM_ERROR_TWO_INSTANCES = "SYS0003";
  public static final String REPORTS_ERROR_MISSING = "REP0001";
  public static final String REPORTS_ERROR_COMPILING = "REP0002";
  public static final String REPORTS_ERROR_WRITING = "REP0003";
  public static final String REPORTS_ERROR_SQL = "REP0004";
  public static final String REPORTS_ERROR_RULES = "REP0005";
  public static final String REPORTS_ERROR_JASPER = "REP0006";
  public static final String SYSPROC_ERROR_UNKNOWN = "SPR9999";
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.MessageServiceLookup
 * JD-Core Version:    0.6.0
 */