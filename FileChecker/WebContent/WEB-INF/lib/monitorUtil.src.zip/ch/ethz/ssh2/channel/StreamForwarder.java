/*    */ package ch.ethz.ssh2.channel;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.Socket;
/*    */ 
/*    */ public class StreamForwarder extends Thread
/*    */ {
/*    */   OutputStream os;
/*    */   InputStream is;
/* 22 */   byte[] buffer = new byte[30000];
/*    */   Channel c;
/*    */   StreamForwarder sibling;
/*    */   Socket s;
/*    */   String mode;
/*    */ 
/*    */   StreamForwarder(Channel c, StreamForwarder sibling, Socket s, InputStream is, OutputStream os, String mode)
/*    */     throws IOException
/*    */   {
/* 31 */     this.is = is;
/* 32 */     this.os = os;
/* 33 */     this.mode = mode;
/* 34 */     this.c = c;
/* 35 */     this.sibling = sibling;
/* 36 */     this.s = s;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/*    */       while (true)
/*    */       {
/* 45 */         int len = this.is.read(this.buffer);
/* 46 */         if (len <= 0)
/*    */           break;
/* 48 */         this.os.write(this.buffer, 0, len);
/* 49 */         this.os.flush();
/*    */       }
/*    */     }
/*    */     catch (IOException ignore)
/*    */     {
/*    */       try
/*    */       {
/* 56 */         this.c.cm.closeChannel(this.c, "Closed due to exception in StreamForwarder (" + this.mode + "): " + 
/* 57 */           ignore.getMessage(), true);
/*    */       }
/*    */       catch (IOException localIOException1)
/*    */       {
/*    */       }
/*    */     }
/*    */     finally
/*    */     {
/*    */       try
/*    */       {
/* 67 */         this.os.close();
/*    */       }
/*    */       catch (IOException localIOException2)
/*    */       {
/*    */       }
/*    */       try
/*    */       {
/* 74 */         this.is.close();
/*    */       }
/*    */       catch (IOException localIOException3)
/*    */       {
/*    */       }
/*    */ 
/* 80 */       if (this.sibling != null)
/*    */       {
/* 82 */         while (this.sibling.isAlive())
/*    */         {
/*    */           try
/*    */           {
/* 86 */             this.sibling.join();
/*    */           }
/*    */           catch (InterruptedException localInterruptedException)
/*    */           {
/*    */           }
/*    */         }
/*    */ 
/*    */         try
/*    */         {
/* 95 */           this.c.cm.closeChannel(this.c, "StreamForwarder (" + this.mode + ") is cleaning up the connection", true);
/*    */         }
/*    */         catch (IOException localIOException4)
/*    */         {
/*    */         }
/*    */ 
/*    */         try
/*    */         {
/* 103 */           if (this.s != null)
/* 104 */             this.s.close();
/*    */         }
/*    */         catch (IOException localIOException5)
/*    */         {
/*    */         }
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.StreamForwarder
 * JD-Core Version:    0.6.0
 */