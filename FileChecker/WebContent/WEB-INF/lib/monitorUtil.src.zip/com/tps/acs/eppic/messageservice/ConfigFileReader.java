/*    */ package com.acs.eppic.messageservice;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ConfigFileReader
/*    */ {
/*    */   private Logger _logger;
/* 13 */   protected static final String PATH_SEPARATOR = System.getProperty("file.separator");
/* 14 */   private final String CONFIG_DIR = "/com/tps/config/";
/*    */   private Properties _propFile;
/*    */ 
/*    */   public ConfigFileReader(String filename)
/*    */   {
/* 18 */     this(filename, true);
/*    */   }
/*    */ 
/*    */   public ConfigFileReader(String filename, boolean useConfigPath)
/*    */   {
/* 23 */     this._logger = Logger.getLogger(getClass().getName());
/* 24 */     this._propFile = new Properties();
/* 25 */     String filepath = filename;
/* 26 */     if (useConfigPath)
/* 27 */       filepath = "/com/tps/config/" + filename;
/*    */     try
/*    */     {
/* 30 */       InputStream is = ConfigFileReader.class.getResourceAsStream(filepath);
/* 31 */       if (is != null)
/* 32 */         this._propFile.load(is);
/*    */       else
/* 34 */         this._logger.error("Can not load property file " + filename);
/*    */     }
/*    */     catch (IOException ioEx) {
/* 37 */       this._logger.error("Can not load property file " + filename, ioEx);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String readConfigValueString(String id)
/*    */   {
/* 43 */     String value = "";
/* 44 */     if ((this._propFile != null) && 
/* 45 */       (id != null)) {
/* 46 */       value = this._propFile.getProperty(id.trim());
/*    */     }
/*    */ 
/* 49 */     return value;
/*    */   }
/*    */ 
/*    */   public int readConfigValueInteger(String id)
/*    */   {
/* 54 */     String value = "";
/*    */ 
/* 56 */     if ((this._propFile != null) && 
/* 57 */       (id != null))
/* 58 */       value = this._propFile.getProperty(id.trim());
/*    */     int retValue;
/*    */     try
/*    */     {
/* 63 */       retValue = Integer.parseInt(value);
/*    */     }
/*    */     catch (NumberFormatException nfEx)
/*    */     {
/*    */       int retValue;
/* 65 */       retValue = -1;
/*    */     }
/* 67 */     return retValue;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.ConfigFileReader
 * JD-Core Version:    0.6.0
 */