package com.ibm.wsdl.extensions.http;

import javax.wsdl.extensions.http.HTTPBinding;
import javax.xml.namespace.QName;

public class HTTPBindingImpl
  implements HTTPBinding
{
  protected QName elementType = HTTPConstants.Q_ELEM_HTTP_BINDING;
  protected Boolean required = null;
  protected String verb = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public void setVerb(String paramString)
  {
    this.verb = paramString;
  }

  public String getVerb()
  {
    return this.verb;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("HTTPBinding (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    if (this.verb != null)
      localStringBuffer.append("\nverb=" + this.verb);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.http.HTTPBindingImpl
 * JD-Core Version:    0.6.0
 */