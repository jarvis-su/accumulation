/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthInfoRequest
/*    */ {
/*    */   byte[] payload;
/*    */   String name;
/*    */   String instruction;
/*    */   String languageTag;
/*    */   int numPrompts;
/*    */   String[] prompt;
/*    */   boolean[] echo;
/*    */ 
/*    */   public PacketUserauthInfoRequest(byte[] payload, int off, int len)
/*    */     throws IOException
/*    */   {
/* 26 */     this.payload = new byte[len];
/* 27 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 29 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 31 */     int packet_type = tr.readByte();
/*    */ 
/* 33 */     if (packet_type != 60) {
/* 34 */       throw new IOException("This is not a SSH_MSG_USERAUTH_INFO_REQUEST! (" + packet_type + ")");
/*    */     }
/* 36 */     this.name = tr.readString();
/* 37 */     this.instruction = tr.readString();
/* 38 */     this.languageTag = tr.readString();
/*    */ 
/* 40 */     this.numPrompts = tr.readUINT32();
/*    */ 
/* 42 */     this.prompt = new String[this.numPrompts];
/* 43 */     this.echo = new boolean[this.numPrompts];
/*    */ 
/* 45 */     for (int i = 0; i < this.numPrompts; i++)
/*    */     {
/* 47 */       this.prompt[i] = tr.readString();
/* 48 */       this.echo[i] = tr.readBoolean();
/*    */     }
/*    */ 
/* 51 */     if (tr.remain() != 0)
/* 52 */       throw new IOException("Padding in SSH_MSG_USERAUTH_INFO_REQUEST packet!");
/*    */   }
/*    */ 
/*    */   public boolean[] getEcho()
/*    */   {
/* 57 */     return this.echo;
/*    */   }
/*    */ 
/*    */   public String getInstruction()
/*    */   {
/* 62 */     return this.instruction;
/*    */   }
/*    */ 
/*    */   public String getLanguageTag()
/*    */   {
/* 67 */     return this.languageTag;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 72 */     return this.name;
/*    */   }
/*    */ 
/*    */   public int getNumPrompts()
/*    */   {
/* 77 */     return this.numPrompts;
/*    */   }
/*    */ 
/*    */   public String[] getPrompt()
/*    */   {
/* 82 */     return this.prompt;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthInfoRequest
 * JD-Core Version:    0.6.0
 */