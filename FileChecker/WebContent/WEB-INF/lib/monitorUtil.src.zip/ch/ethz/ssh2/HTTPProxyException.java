/*    */ package ch.ethz.ssh2;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class HTTPProxyException extends IOException
/*    */ {
/*    */   private static final long serialVersionUID = 2241537397104426186L;
/*    */   public final String httpResponse;
/*    */   public final int httpErrorCode;
/*    */ 
/*    */   public HTTPProxyException(String httpResponse, int httpErrorCode)
/*    */   {
/* 25 */     super("HTTP Proxy Error (" + httpErrorCode + " " + httpResponse + ")");
/* 26 */     this.httpResponse = httpResponse;
/* 27 */     this.httpErrorCode = httpErrorCode;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.HTTPProxyException
 * JD-Core Version:    0.6.0
 */