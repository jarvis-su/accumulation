/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ public class MySQLTransactionRollbackException extends MySQLTransientException
/*    */ {
/*    */   public MySQLTransactionRollbackException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 30 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLTransactionRollbackException(String reason, String SQLState) {
/* 34 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLTransactionRollbackException(String reason) {
/* 38 */     super(reason);
/*    */   }
/*    */ 
/*    */   public MySQLTransactionRollbackException()
/*    */   {
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLTransactionRollbackException
 * JD-Core Version:    0.6.0
 */