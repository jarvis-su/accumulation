package com.ibm.wsdl;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.Port;
import javax.wsdl.extensions.ExtensibilityElement;
import org.w3c.dom.Element;

public class PortImpl
  implements Port
{
  protected String name = null;
  protected Binding binding = null;
  protected Element docEl = null;
  protected List extElements = new Vector();
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setBinding(Binding paramBinding)
  {
    this.binding = paramBinding;
  }

  public Binding getBinding()
  {
    return this.binding;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Port: name=" + this.name);
    if (this.binding != null)
      localStringBuffer.append("\n" + this.binding);
    if (this.extElements != null)
    {
      Iterator localIterator = this.extElements.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.PortImpl
 * JD-Core Version:    0.6.0
 */