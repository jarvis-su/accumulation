/*     */ package ch.ethz.ssh2;
/*     */ 
/*     */ public class DHGexParameters
/*     */ {
/*     */   private final int min_group_len;
/*     */   private final int pref_group_len;
/*     */   private final int max_group_len;
/*     */   private static final int MIN_ALLOWED = 1024;
/*     */   private static final int MAX_ALLOWED = 8192;
/*     */ 
/*     */   public DHGexParameters()
/*     */   {
/*  33 */     this(1024, 1024, 4096);
/*     */   }
/*     */ 
/*     */   public DHGexParameters(int pref_group_len)
/*     */   {
/*  46 */     if ((pref_group_len < 1024) || (pref_group_len > 8192)) {
/*  47 */       throw new IllegalArgumentException("pref_group_len out of range!");
/*     */     }
/*  49 */     this.pref_group_len = pref_group_len;
/*  50 */     this.min_group_len = 0;
/*  51 */     this.max_group_len = 0;
/*     */   }
/*     */ 
/*     */   public DHGexParameters(int min_group_len, int pref_group_len, int max_group_len)
/*     */   {
/*  70 */     if ((min_group_len < 1024) || (min_group_len > 8192)) {
/*  71 */       throw new IllegalArgumentException("min_group_len out of range!");
/*     */     }
/*  73 */     if ((pref_group_len < 1024) || (pref_group_len > 8192)) {
/*  74 */       throw new IllegalArgumentException("pref_group_len out of range!");
/*     */     }
/*  76 */     if ((max_group_len < 1024) || (max_group_len > 8192)) {
/*  77 */       throw new IllegalArgumentException("max_group_len out of range!");
/*     */     }
/*  79 */     if ((pref_group_len < min_group_len) || (pref_group_len > max_group_len)) {
/*  80 */       throw new IllegalArgumentException("pref_group_len is incompatible with min and max!");
/*     */     }
/*  82 */     if (max_group_len < min_group_len) {
/*  83 */       throw new IllegalArgumentException("max_group_len must not be smaller than min_group_len!");
/*     */     }
/*  85 */     this.min_group_len = min_group_len;
/*  86 */     this.pref_group_len = pref_group_len;
/*  87 */     this.max_group_len = max_group_len;
/*     */   }
/*     */ 
/*     */   public int getMax_group_len()
/*     */   {
/*  98 */     return this.max_group_len;
/*     */   }
/*     */ 
/*     */   public int getMin_group_len()
/*     */   {
/* 109 */     return this.min_group_len;
/*     */   }
/*     */ 
/*     */   public int getPref_group_len()
/*     */   {
/* 119 */     return this.pref_group_len;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.DHGexParameters
 * JD-Core Version:    0.6.0
 */