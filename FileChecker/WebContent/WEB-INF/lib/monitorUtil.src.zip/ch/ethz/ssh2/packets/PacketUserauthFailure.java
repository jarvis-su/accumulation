/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketUserauthFailure
/*    */ {
/*    */   byte[] payload;
/*    */   String[] authThatCanContinue;
/*    */   boolean partialSuccess;
/*    */ 
/*    */   public PacketUserauthFailure(String[] authThatCanContinue, boolean partialSuccess)
/*    */   {
/* 21 */     this.authThatCanContinue = authThatCanContinue;
/* 22 */     this.partialSuccess = partialSuccess;
/*    */   }
/*    */ 
/*    */   public PacketUserauthFailure(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 27 */     this.payload = new byte[len];
/* 28 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 30 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 32 */     int packet_type = tr.readByte();
/*    */ 
/* 34 */     if (packet_type != 51) {
/* 35 */       throw new IOException("This is not a SSH_MSG_USERAUTH_FAILURE! (" + packet_type + ")");
/*    */     }
/* 37 */     this.authThatCanContinue = tr.readNameList();
/* 38 */     this.partialSuccess = tr.readBoolean();
/*    */ 
/* 40 */     if (tr.remain() != 0)
/* 41 */       throw new IOException("Padding in SSH_MSG_USERAUTH_FAILURE packet!");
/*    */   }
/*    */ 
/*    */   public String[] getAuthThatCanContinue()
/*    */   {
/* 46 */     return this.authThatCanContinue;
/*    */   }
/*    */ 
/*    */   public boolean isPartialSuccess()
/*    */   {
/* 51 */     return this.partialSuccess;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthFailure
 * JD-Core Version:    0.6.0
 */