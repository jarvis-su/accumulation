/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class Statement$1 extends Thread
/*     */ {
/*     */   private final Statement.CancelTask this$1;
/*     */ 
/*     */   public void run()
/*     */   {
/*  98 */     Connection cancelConn = null;
/*  99 */     java.sql.Statement cancelStmt = null;
/*     */     try
/*     */     {
/* 102 */       cancelConn = Statement.CancelTask.access$000(this.this$1).connection.duplicate();
/* 103 */       cancelStmt = cancelConn.createStatement();
/* 104 */       cancelStmt.execute("KILL QUERY " + this.this$1.connectionId);
/* 105 */       Statement.CancelTask.access$000(this.this$1).wasCancelled = true;
/*     */     } catch (SQLException sqlEx) {
/* 107 */       throw new RuntimeException(sqlEx.toString());
/*     */     } finally {
/* 109 */       if (cancelStmt != null) {
/*     */         try {
/* 111 */           cancelStmt.close();
/*     */         } catch (SQLException sqlEx) {
/* 113 */           throw new RuntimeException(sqlEx.toString());
/*     */         }
/*     */       }
/*     */ 
/* 117 */       if (cancelConn != null)
/*     */         try {
/* 119 */           cancelConn.close();
/*     */         } catch (SQLException sqlEx) {
/* 121 */           throw new RuntimeException(sqlEx.toString());
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Statement.1
 * JD-Core Version:    0.6.0
 */