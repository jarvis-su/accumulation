/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.io.UnsupportedEncodingException;
/*      */ import java.math.BigDecimal;
/*      */ import java.net.URL;
/*      */ import java.sql.Array;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.Blob;
/*      */ import java.sql.Clob;
/*      */ import java.sql.ParameterMetaData;
/*      */ import java.sql.Ref;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Time;
/*      */ import java.sql.Timestamp;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.List;
/*      */ import java.util.TimeZone;
/*      */ import java.util.Timer;
/*      */ 
/*      */ public class ServerPreparedStatement extends PreparedStatement
/*      */ {
/*      */   protected static final int BLOB_STREAM_READ_BUF_SIZE = 8192;
/*      */   private static final byte MAX_DATE_REP_LENGTH = 5;
/*      */   private static final byte MAX_DATETIME_REP_LENGTH = 12;
/*      */   private static final byte MAX_TIME_REP_LENGTH = 13;
/*  235 */   private boolean detectedLongParameterSwitch = false;
/*      */   private int fieldCount;
/*  244 */   private boolean invalid = false;
/*      */   private SQLException invalidationException;
/*      */   private boolean isSelectQuery;
/*      */   private Buffer outByteBuffer;
/*      */   private ServerPreparedStatement.BindValue[] parameterBindings;
/*      */   private Field[] parameterFields;
/*      */   private Field[] resultFields;
/*  264 */   private boolean sendTypesToServer = false;
/*      */   private long serverStatementId;
/*  270 */   private int stringTypeCode = 254;
/*      */   private boolean serverNeedsResetBeforeEachExecution;
/*  461 */   protected boolean isCached = false;
/*      */ 
/*      */   private void storeTime(Buffer intoBuf, Time tm)
/*      */     throws SQLException
/*      */   {
/*  208 */     intoBuf.ensureCapacity(9);
/*  209 */     intoBuf.writeByte(8);
/*  210 */     intoBuf.writeByte(0);
/*  211 */     intoBuf.writeLong(0L);
/*      */ 
/*  213 */     Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/*  215 */     synchronized (sessionCalendar) {
/*  216 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try {
/*  218 */         sessionCalendar.setTime(tm);
/*  219 */         intoBuf.writeByte((byte)sessionCalendar.get(11));
/*  220 */         intoBuf.writeByte((byte)sessionCalendar.get(12));
/*  221 */         intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */       }
/*      */       finally
/*      */       {
/*  225 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public ServerPreparedStatement(Connection conn, String sql, String catalog, int resultSetType, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/*  290 */     super(conn, catalog);
/*      */ 
/*  292 */     checkNullOrEmptyQuery(sql);
/*      */ 
/*  294 */     this.isSelectQuery = StringUtils.startsWithIgnoreCaseAndWs(sql, "SELECT");
/*      */ 
/*  297 */     if (this.connection.versionMeetsMinimum(5, 0, 0)) {
/*  298 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(5, 0, 3));
/*      */     }
/*      */     else {
/*  301 */       this.serverNeedsResetBeforeEachExecution = (!this.connection.versionMeetsMinimum(4, 1, 10));
/*      */     }
/*      */ 
/*  305 */     this.useTrueBoolean = this.connection.versionMeetsMinimum(3, 21, 23);
/*  306 */     this.hasLimitClause = (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1);
/*  307 */     this.firstCharOfStmt = StringUtils.firstNonWsCharUc(sql);
/*  308 */     this.originalSql = sql;
/*      */ 
/*  310 */     if (this.connection.versionMeetsMinimum(4, 1, 2))
/*  311 */       this.stringTypeCode = 253;
/*      */     else {
/*  313 */       this.stringTypeCode = 254;
/*      */     }
/*      */     try
/*      */     {
/*  317 */       serverPrepare(sql);
/*      */     } catch (SQLException sqlEx) {
/*  319 */       realClose(false, true);
/*      */ 
/*  321 */       throw sqlEx;
/*      */     } catch (Exception ex) {
/*  323 */       realClose(false, true);
/*      */ 
/*  325 */       throw SQLError.createSQLException(ex.toString(), "S1000");
/*      */     }
/*      */ 
/*  329 */     setResultSetType(resultSetType);
/*  330 */     setResultSetConcurrency(resultSetConcurrency);
/*      */   }
/*      */ 
/*      */   public synchronized void addBatch()
/*      */     throws SQLException
/*      */   {
/*  342 */     checkClosed();
/*      */ 
/*  344 */     if (this.batchedArgs == null) {
/*  345 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */ 
/*  348 */     this.batchedArgs.add(new ServerPreparedStatement.BatchedBindValues(this.parameterBindings));
/*      */   }
/*      */ 
/*      */   protected String asSql(boolean quoteStreamsAndUnknowns) throws SQLException
/*      */   {
/*  353 */     if (this.isClosed) {
/*  354 */       return "statement has been closed, no further internal information available";
/*      */     }
/*      */ 
/*  357 */     PreparedStatement pStmtForSub = null;
/*      */     try
/*      */     {
/*  360 */       pStmtForSub = new PreparedStatement(this.connection, this.originalSql, this.currentCatalog);
/*      */ 
/*  363 */       int numParameters = pStmtForSub.parameterCount;
/*  364 */       int ourNumParameters = this.parameterCount;
/*      */ 
/*  366 */       for (i = 0; (i < numParameters) && (i < ourNumParameters); i++) {
/*  367 */         if (this.parameterBindings[i] != null) {
/*  368 */           if (this.parameterBindings[i].isNull) {
/*  369 */             pStmtForSub.setNull(i + 1, 0);
/*      */           } else {
/*  371 */             ServerPreparedStatement.BindValue bindValue = this.parameterBindings[i];
/*      */ 
/*  376 */             switch (bindValue.bufferType)
/*      */             {
/*      */             case 1:
/*  379 */               pStmtForSub.setByte(i + 1, bindValue.byteBinding);
/*  380 */               break;
/*      */             case 2:
/*  382 */               pStmtForSub.setShort(i + 1, bindValue.shortBinding);
/*  383 */               break;
/*      */             case 3:
/*  385 */               pStmtForSub.setInt(i + 1, bindValue.intBinding);
/*  386 */               break;
/*      */             case 8:
/*  388 */               pStmtForSub.setLong(i + 1, bindValue.longBinding);
/*  389 */               break;
/*      */             case 4:
/*  391 */               pStmtForSub.setFloat(i + 1, bindValue.floatBinding);
/*  392 */               break;
/*      */             case 5:
/*  394 */               pStmtForSub.setDouble(i + 1, bindValue.doubleBinding);
/*      */ 
/*  396 */               break;
/*      */             case 6:
/*      */             case 7:
/*      */             default:
/*  398 */               pStmtForSub.setObject(i + 1, this.parameterBindings[i].value);
/*      */             }
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  406 */       i = pStmtForSub.asSql(quoteStreamsAndUnknowns);
/*      */     }
/*      */     finally
/*      */     {
/*      */       int i;
/*  408 */       if (pStmtForSub != null)
/*      */         try {
/*  410 */           pStmtForSub.close();
/*      */         }
/*      */         catch (SQLException sqlEx)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  424 */     if (this.invalid) {
/*  425 */       throw this.invalidationException;
/*      */     }
/*      */ 
/*  428 */     super.checkClosed();
/*      */   }
/*      */ 
/*      */   public void clearParameters()
/*      */     throws SQLException
/*      */   {
/*  435 */     checkClosed();
/*  436 */     clearParametersInternal(true);
/*      */   }
/*      */ 
/*      */   private void clearParametersInternal(boolean clearServerParameters) throws SQLException
/*      */   {
/*  441 */     boolean hadLongData = false;
/*      */ 
/*  443 */     if (this.parameterBindings != null) {
/*  444 */       for (int i = 0; i < this.parameterCount; i++) {
/*  445 */         if ((this.parameterBindings[i] != null) && (this.parameterBindings[i].isLongData))
/*      */         {
/*  447 */           hadLongData = true;
/*      */         }
/*      */ 
/*  450 */         this.parameterBindings[i].reset();
/*      */       }
/*      */     }
/*      */ 
/*  454 */     if ((clearServerParameters) && (hadLongData)) {
/*  455 */       serverResetStatement();
/*      */ 
/*  457 */       this.detectedLongParameterSwitch = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void setClosed(boolean flag)
/*      */   {
/*  464 */     this.isClosed = flag;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  470 */     if (this.isCached) {
/*  471 */       this.isClosed = true;
/*  472 */       this.connection.recachePreparedStatement(this);
/*  473 */       return;
/*      */     }
/*      */ 
/*  476 */     realClose(true, true);
/*      */   }
/*      */ 
/*      */   private void dumpCloseForTestcase() {
/*  480 */     StringBuffer buf = new StringBuffer();
/*  481 */     this.connection.generateConnectionCommentBlock(buf);
/*  482 */     buf.append("DEALLOCATE PREPARE debug_stmt_");
/*  483 */     buf.append(this.statementId);
/*  484 */     buf.append(";\n");
/*      */ 
/*  486 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */ 
/*      */   private void dumpExecuteForTestcase() throws SQLException {
/*  490 */     StringBuffer buf = new StringBuffer();
/*      */ 
/*  492 */     for (int i = 0; i < this.parameterCount; i++) {
/*  493 */       this.connection.generateConnectionCommentBlock(buf);
/*      */ 
/*  495 */       buf.append("SET @debug_stmt_param");
/*  496 */       buf.append(this.statementId);
/*  497 */       buf.append("_");
/*  498 */       buf.append(i);
/*  499 */       buf.append("=");
/*      */ 
/*  501 */       if (this.parameterBindings[i].isNull)
/*  502 */         buf.append("NULL");
/*      */       else {
/*  504 */         buf.append(this.parameterBindings[i].toString(true));
/*      */       }
/*      */ 
/*  507 */       buf.append(";\n");
/*      */     }
/*      */ 
/*  510 */     this.connection.generateConnectionCommentBlock(buf);
/*      */ 
/*  512 */     buf.append("EXECUTE debug_stmt_");
/*  513 */     buf.append(this.statementId);
/*      */ 
/*  515 */     if (this.parameterCount > 0) {
/*  516 */       buf.append(" USING ");
/*  517 */       for (int i = 0; i < this.parameterCount; i++) {
/*  518 */         if (i > 0) {
/*  519 */           buf.append(", ");
/*      */         }
/*      */ 
/*  522 */         buf.append("@debug_stmt_param");
/*  523 */         buf.append(this.statementId);
/*  524 */         buf.append("_");
/*  525 */         buf.append(i);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  530 */     buf.append(";\n");
/*      */ 
/*  532 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */ 
/*      */   private void dumpPrepareForTestcase() throws SQLException
/*      */   {
/*  537 */     StringBuffer buf = new StringBuffer(this.originalSql.length() + 64);
/*      */ 
/*  539 */     this.connection.generateConnectionCommentBlock(buf);
/*      */ 
/*  541 */     buf.append("PREPARE debug_stmt_");
/*  542 */     buf.append(this.statementId);
/*  543 */     buf.append(" FROM \"");
/*  544 */     buf.append(this.originalSql);
/*  545 */     buf.append("\";\n");
/*      */ 
/*  547 */     this.connection.dumpTestcaseQuery(buf.toString());
/*      */   }
/*      */ 
/*      */   public synchronized int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/*  554 */     if (this.connection.isReadOnly()) {
/*  555 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009");
/*      */     }
/*      */ 
/*  561 */     checkClosed();
/*      */ 
/*  563 */     synchronized (this.connection.getMutex()) {
/*  564 */       clearWarnings();
/*      */ 
/*  568 */       ServerPreparedStatement.BindValue[] oldBindValues = this.parameterBindings;
/*      */       try
/*      */       {
/*  571 */         int[] updateCounts = null;
/*      */ 
/*  573 */         if (this.batchedArgs != null) {
/*  574 */           nbrCommands = this.batchedArgs.size();
/*  575 */           updateCounts = new int[nbrCommands];
/*      */ 
/*  577 */           if (this.retrieveGeneratedKeys) {
/*  578 */             this.batchedGeneratedKeys = new ArrayList(nbrCommands);
/*      */           }
/*      */ 
/*  581 */           for (int i = 0; i < nbrCommands; i++) {
/*  582 */             updateCounts[i] = -3;
/*      */           }
/*      */ 
/*  585 */           SQLException sqlEx = null;
/*      */ 
/*  587 */           int commandIndex = 0;
/*      */ 
/*  589 */           ServerPreparedStatement.BindValue[] previousBindValuesForBatch = null;
/*      */ 
/*  591 */           for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*  592 */             Object arg = this.batchedArgs.get(commandIndex);
/*      */ 
/*  594 */             if ((arg instanceof String)) {
/*  595 */               updateCounts[commandIndex] = executeUpdate((String)arg);
/*      */             } else {
/*  597 */               this.parameterBindings = ((ServerPreparedStatement.BatchedBindValues)arg).batchedParameterValues;
/*      */               try
/*      */               {
/*  604 */                 if (previousBindValuesForBatch != null) {
/*  605 */                   for (int j = 0; j < this.parameterBindings.length; j++) {
/*  606 */                     if (this.parameterBindings[j].bufferType != previousBindValuesForBatch[j].bufferType) {
/*  607 */                       this.sendTypesToServer = true;
/*      */ 
/*  609 */                       break;
/*      */                     }
/*      */                   }
/*      */                 }
/*      */                 try
/*      */                 {
/*  615 */                   updateCounts[commandIndex] = executeUpdate(false, true);
/*      */                 } finally {
/*  617 */                   previousBindValuesForBatch = this.parameterBindings;
/*      */                 }
/*      */ 
/*  620 */                 if (this.retrieveGeneratedKeys) {
/*  621 */                   java.sql.ResultSet rs = null;
/*      */                   try
/*      */                   {
/*  633 */                     rs = getGeneratedKeysInternal();
/*      */ 
/*  635 */                     while (rs.next()) {
/*  636 */                       this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
/*      */                     }
/*      */                   }
/*      */                   finally
/*      */                   {
/*  641 */                     if (rs != null)
/*  642 */                       rs.close();
/*      */                   }
/*      */                 }
/*      */               }
/*      */               catch (SQLException ex) {
/*  647 */                 updateCounts[commandIndex] = -3;
/*      */ 
/*  649 */                 if (this.continueBatchOnError) {
/*  650 */                   sqlEx = ex;
/*      */                 } else {
/*  652 */                   int[] newUpdateCounts = new int[commandIndex];
/*  653 */                   System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */ 
/*  656 */                   throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */                 }
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  664 */           if (sqlEx != null) {
/*  665 */             throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  671 */         int nbrCommands = updateCounts != null ? updateCounts : new int[0]; jsr 16; return nbrCommands;
/*      */       } finally {
/*  673 */         jsr 6; } localObject4 = returnAddress; this.parameterBindings = oldBindValues;
/*  674 */       this.sendTypesToServer = true;
/*      */ 
/*  676 */       clearBatch(); ret;
/*      */     }
/*      */   }
/*      */ 
/*      */   protected ResultSet executeInternal(int maxRowsToRetrieve, Buffer sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, boolean unpackFields, boolean isBatch) throws SQLException
/*      */   {
/*  689 */     this.numberOfExecutions += 1;
/*      */     SQLException sqlEx;
/*      */     try {
/*  693 */       return serverExecute(maxRowsToRetrieve, createStreamingResultSet);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  696 */       if (this.connection.getEnablePacketDebug()) {
/*  697 */         this.connection.getIO().dumpPacketRingBuffer();
/*      */       }
/*      */ 
/*  700 */       if (this.connection.getDumpQueriesOnException()) {
/*  701 */         String extractedSql = toString();
/*  702 */         StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */ 
/*  704 */         messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");
/*      */ 
/*  706 */         messageBuf.append(extractedSql);
/*      */ 
/*  708 */         sqlEx = Connection.appendMessageToException(sqlEx, messageBuf.toString());
/*      */       }
/*      */ 
/*  712 */       throw sqlEx;
/*      */     } catch (Exception ex) {
/*  714 */       if (this.connection.getEnablePacketDebug()) {
/*  715 */         this.connection.getIO().dumpPacketRingBuffer();
/*      */       }
/*      */ 
/*  718 */       sqlEx = SQLError.createSQLException(ex.toString(), "S1000");
/*      */ 
/*  721 */       if (this.connection.getDumpQueriesOnException()) {
/*  722 */         String extractedSql = toString();
/*  723 */         StringBuffer messageBuf = new StringBuffer(extractedSql.length() + 32);
/*      */ 
/*  725 */         messageBuf.append("\n\nQuery being executed when exception was thrown:\n\n");
/*      */ 
/*  727 */         messageBuf.append(extractedSql);
/*      */ 
/*  729 */         sqlEx = Connection.appendMessageToException(sqlEx, messageBuf.toString());
/*      */       }
/*      */     }
/*      */ 
/*  733 */     throw sqlEx;
/*      */   }
/*      */ 
/*      */   protected Buffer fillSendPacket()
/*      */     throws SQLException
/*      */   {
/*  741 */     return null;
/*      */   }
/*      */ 
/*      */   protected Buffer fillSendPacket(byte[][] batchedParameterStrings, InputStream[] batchedParameterStreams, boolean[] batchedIsStream, int[] batchedStreamLengths)
/*      */     throws SQLException
/*      */   {
/*  751 */     return null;
/*      */   }
/*      */ 
/*      */   private ServerPreparedStatement.BindValue getBinding(int parameterIndex, boolean forLongData) throws SQLException
/*      */   {
/*  756 */     checkClosed();
/*      */ 
/*  758 */     if (this.parameterBindings.length == 0) {
/*  759 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.8"), "S1009");
/*      */     }
/*      */ 
/*  764 */     parameterIndex--;
/*      */ 
/*  766 */     if ((parameterIndex < 0) || (parameterIndex >= this.parameterBindings.length))
/*      */     {
/*  768 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + this.parameterBindings.length, "S1009");
/*      */     }
/*      */ 
/*  776 */     if (this.parameterBindings[parameterIndex] == null) {
/*  777 */       this.parameterBindings[parameterIndex] = new ServerPreparedStatement.BindValue();
/*      */     }
/*  779 */     else if ((this.parameterBindings[parameterIndex].isLongData) && (!forLongData))
/*      */     {
/*  781 */       this.detectedLongParameterSwitch = true;
/*      */     }
/*      */ 
/*  785 */     this.parameterBindings[parameterIndex].isSet = true;
/*  786 */     this.parameterBindings[parameterIndex].boundBeforeExecutionNum = this.numberOfExecutions;
/*      */ 
/*  788 */     return this.parameterBindings[parameterIndex];
/*      */   }
/*      */ 
/*      */   byte[] getBytes(int parameterIndex)
/*      */     throws SQLException
/*      */   {
/*  795 */     ServerPreparedStatement.BindValue bindValue = getBinding(parameterIndex, false);
/*      */ 
/*  797 */     if (bindValue.isNull)
/*  798 */       return null;
/*  799 */     if (bindValue.isLongData) {
/*  800 */       throw new NotImplemented();
/*      */     }
/*  802 */     if (this.outByteBuffer == null) {
/*  803 */       this.outByteBuffer = new Buffer(this.connection.getNetBufferLength());
/*      */     }
/*      */ 
/*  807 */     this.outByteBuffer.clear();
/*      */ 
/*  809 */     int originalPosition = this.outByteBuffer.getPosition();
/*      */ 
/*  811 */     storeBinding(this.outByteBuffer, bindValue, this.connection.getIO());
/*      */ 
/*  813 */     int newPosition = this.outByteBuffer.getPosition();
/*      */ 
/*  815 */     int length = newPosition - originalPosition;
/*      */ 
/*  817 */     byte[] valueAsBytes = new byte[length];
/*      */ 
/*  819 */     System.arraycopy(this.outByteBuffer.getByteBuffer(), originalPosition, valueAsBytes, 0, length);
/*      */ 
/*  822 */     return valueAsBytes;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSetMetaData getMetaData()
/*      */     throws SQLException
/*      */   {
/*  830 */     checkClosed();
/*      */ 
/*  832 */     if (this.resultFields == null) {
/*  833 */       return null;
/*      */     }
/*      */ 
/*  836 */     return new ResultSetMetaData(this.resultFields, this.connection.getUseOldAliasMetadataBehavior());
/*      */   }
/*      */ 
/*      */   public ParameterMetaData getParameterMetaData()
/*      */     throws SQLException
/*      */   {
/*  844 */     checkClosed();
/*      */ 
/*  846 */     if (this.parameterMetaData == null) {
/*  847 */       this.parameterMetaData = new MysqlParameterMetadata(this.parameterFields, this.parameterCount);
/*      */     }
/*      */ 
/*  851 */     return this.parameterMetaData;
/*      */   }
/*      */ 
/*      */   boolean isNull(int paramIndex)
/*      */   {
/*  858 */     throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/*  873 */     if (this.isClosed) {
/*  874 */       return;
/*      */     }
/*      */ 
/*  877 */     if (this.connection != null) {
/*  878 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/*  879 */         dumpCloseForTestcase();
/*      */       }
/*      */ 
/*  882 */       synchronized (this.connection.getMutex())
/*      */       {
/*  895 */         SQLException exceptionDuringClose = null;
/*      */ 
/*  898 */         if (calledExplicitly) {
/*      */           try
/*      */           {
/*  901 */             MysqlIO mysql = this.connection.getIO();
/*      */ 
/*  903 */             Buffer packet = mysql.getSharedSendPacket();
/*      */ 
/*  905 */             packet.writeByte(25);
/*  906 */             packet.writeLong(this.serverStatementId);
/*      */ 
/*  908 */             mysql.sendCommand(25, null, packet, true, null);
/*      */           }
/*      */           catch (SQLException sqlEx) {
/*  911 */             exceptionDuringClose = sqlEx;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  916 */         super.realClose(calledExplicitly, closeOpenResults);
/*      */ 
/*  918 */         clearParametersInternal(false);
/*  919 */         this.parameterBindings = null;
/*      */ 
/*  921 */         this.parameterFields = null;
/*  922 */         this.resultFields = null;
/*      */ 
/*  924 */         if (exceptionDuringClose != null)
/*  925 */           throw exceptionDuringClose;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void rePrepare()
/*      */     throws SQLException
/*      */   {
/*  939 */     this.invalidationException = null;
/*      */     try
/*      */     {
/*  942 */       serverPrepare(this.originalSql);
/*      */     }
/*      */     catch (SQLException sqlEx) {
/*  945 */       this.invalidationException = sqlEx;
/*      */     } catch (Exception ex) {
/*  947 */       this.invalidationException = SQLError.createSQLException(ex.toString(), "S1000");
/*      */     }
/*      */ 
/*  951 */     if (this.invalidationException != null) {
/*  952 */       this.invalid = true;
/*      */ 
/*  954 */       this.parameterBindings = null;
/*      */ 
/*  956 */       this.parameterFields = null;
/*  957 */       this.resultFields = null;
/*      */ 
/*  959 */       if (this.results != null) {
/*      */         try {
/*  961 */           this.results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/*      */       }
/*  967 */       if (this.connection != null) {
/*  968 */         if (this.maxRowsChanged) {
/*  969 */           this.connection.unsetMaxRows(this);
/*      */         }
/*      */ 
/*  972 */         if (!this.connection.getDontTrackOpenResources())
/*  973 */           this.connection.unregisterStatement(this);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private ResultSet serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet)
/*      */     throws SQLException
/*      */   {
/* 1014 */     synchronized (this.connection.getMutex()) {
/* 1015 */       if (this.detectedLongParameterSwitch)
/*      */       {
/* 1017 */         boolean firstFound = false;
/* 1018 */         long boundTimeToCheck = 0L;
/*      */ 
/* 1020 */         for (int i = 0; i < this.parameterCount - 1; i++) {
/* 1021 */           if (this.parameterBindings[i].isLongData) {
/* 1022 */             if ((firstFound) && (boundTimeToCheck != this.parameterBindings[i].boundBeforeExecutionNum))
/*      */             {
/* 1024 */               throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.11") + Messages.getString("ServerPreparedStatement.12"), "S1C00");
/*      */             }
/*      */ 
/* 1029 */             firstFound = true;
/* 1030 */             boundTimeToCheck = this.parameterBindings[i].boundBeforeExecutionNum;
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1038 */         serverResetStatement();
/*      */       }
/*      */ 
/* 1043 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1044 */         if (!this.parameterBindings[i].isSet) {
/* 1045 */           throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.13") + (i + 1) + Messages.getString("ServerPreparedStatement.14"), "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1055 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1056 */         if (this.parameterBindings[i].isLongData) {
/* 1057 */           serverLongData(i, this.parameterBindings[i]);
/*      */         }
/*      */       }
/*      */ 
/* 1061 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1062 */         dumpExecuteForTestcase();
/*      */       }
/*      */ 
/* 1068 */       MysqlIO mysql = this.connection.getIO();
/*      */ 
/* 1070 */       Buffer packet = mysql.getSharedSendPacket();
/*      */ 
/* 1072 */       packet.clear();
/* 1073 */       packet.writeByte(23);
/* 1074 */       packet.writeLong(this.serverStatementId);
/*      */ 
/* 1076 */       boolean usingCursor = false;
/*      */ 
/* 1078 */       if (this.connection.versionMeetsMinimum(4, 1, 2))
/*      */       {
/* 1085 */         if ((this.resultFields != null) && (this.connection.isCursorFetchEnabled()) && (getResultSetType() == 1003) && (getResultSetConcurrency() == 1007) && (getFetchSize() > 0))
/*      */         {
/* 1090 */           packet.writeByte(1);
/* 1091 */           usingCursor = true;
/*      */         } else {
/* 1093 */           packet.writeByte(0);
/*      */         }
/*      */ 
/* 1096 */         packet.writeLong(1L);
/*      */       }
/*      */ 
/* 1101 */       int nullCount = (this.parameterCount + 7) / 8;
/*      */ 
/* 1106 */       int nullBitsPosition = packet.getPosition();
/*      */ 
/* 1108 */       for (int i = 0; i < nullCount; i++) {
/* 1109 */         packet.writeByte(0);
/*      */       }
/*      */ 
/* 1112 */       byte[] nullBitsBuffer = new byte[nullCount];
/*      */ 
/* 1115 */       packet.writeByte(this.sendTypesToServer ? 1 : 0);
/*      */ 
/* 1117 */       if (this.sendTypesToServer)
/*      */       {
/* 1122 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1123 */           packet.writeInt(this.parameterBindings[i].bufferType);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1130 */       for (int i = 0; i < this.parameterCount; i++) {
/* 1131 */         if (!this.parameterBindings[i].isLongData) {
/* 1132 */           if (!this.parameterBindings[i].isNull) {
/* 1133 */             storeBinding(packet, this.parameterBindings[i], mysql);
/*      */           }
/*      */           else
/*      */           {
/*      */             int tmp544_543 = (i / 8);
/*      */             byte[] tmp544_537 = nullBitsBuffer; tmp544_537[tmp544_543] = (byte)(tmp544_537[tmp544_543] | 1 << (i & 0x7));
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 1144 */       int endPosition = packet.getPosition();
/* 1145 */       packet.setPosition(nullBitsPosition);
/* 1146 */       packet.writeBytesNoNull(nullBitsBuffer);
/* 1147 */       packet.setPosition(endPosition);
/*      */ 
/* 1149 */       long begin = 0L;
/*      */ 
/* 1151 */       if ((this.connection.getProfileSql()) || (this.connection.getLogSlowQueries()) || (this.connection.getGatherPerformanceMetrics()))
/*      */       {
/* 1154 */         begin = System.currentTimeMillis();
/*      */       }
/*      */ 
/* 1157 */       this.wasCancelled = false;
/*      */ 
/* 1159 */       Statement.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1162 */         if ((this.timeoutInMillis != 0) && (this.connection.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/* 1164 */           timeoutTask = new Statement.CancelTask(this);
/* 1165 */           Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */ 
/* 1169 */         Buffer resultPacket = mysql.sendCommand(23, null, packet, false, null);
/*      */ 
/* 1172 */         if (timeoutTask != null) {
/* 1173 */           timeoutTask.cancel();
/* 1174 */           timeoutTask = null;
/*      */         }
/*      */ 
/* 1177 */         if (this.wasCancelled) {
/* 1178 */           this.wasCancelled = false;
/* 1179 */           throw new MySQLTimeoutException();
/*      */         }
/*      */ 
/* 1182 */         this.connection.incrementNumberOfPreparedExecutes();
/*      */ 
/* 1184 */         if (this.connection.getProfileSql()) {
/* 1185 */           this.eventSink = ProfileEventSink.getInstance(this.connection);
/*      */ 
/* 1187 */           this.eventSink.consumeEvent(new ProfilerEvent(4, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), (int)(System.currentTimeMillis() - begin), null, new Throwable(), truncateQueryToLog(asSql(true))));
/*      */         }
/*      */ 
/* 1195 */         ResultSet rs = mysql.readAllResults(this, maxRowsToRetrieve, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet, this.currentCatalog, resultPacket, true, this.fieldCount, true);
/*      */ 
/* 1202 */         if ((!createStreamingResultSet) && (this.serverNeedsResetBeforeEachExecution))
/*      */         {
/* 1204 */           serverResetStatement();
/*      */         }
/*      */ 
/* 1207 */         this.sendTypesToServer = false;
/* 1208 */         this.results = rs;
/*      */ 
/* 1210 */         if ((this.connection.getLogSlowQueries()) || (this.connection.getGatherPerformanceMetrics()))
/*      */         {
/* 1212 */           elapsedTime = System.currentTimeMillis() - begin;
/*      */ 
/* 1214 */           if ((this.connection.getLogSlowQueries()) && (elapsedTime >= this.connection.getSlowQueryThresholdMillis()))
/*      */           {
/* 1217 */             StringBuffer mesgBuf = new StringBuffer(48 + this.originalSql.length());
/*      */ 
/* 1219 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15"));
/*      */ 
/* 1221 */             mesgBuf.append(this.connection.getSlowQueryThresholdMillis());
/*      */ 
/* 1223 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.15a"));
/*      */ 
/* 1225 */             mesgBuf.append(elapsedTime);
/* 1226 */             mesgBuf.append(Messages.getString("ServerPreparedStatement.16"));
/*      */ 
/* 1229 */             mesgBuf.append("as prepared: ");
/* 1230 */             mesgBuf.append(this.originalSql);
/* 1231 */             mesgBuf.append("\n\n with parameters bound:\n\n");
/* 1232 */             mesgBuf.append(asSql(true));
/*      */ 
/* 1234 */             this.connection.getLog().logWarn(mesgBuf.toString());
/*      */ 
/* 1236 */             if (this.connection.getExplainSlowQueries()) {
/* 1237 */               String queryAsString = asSql(true);
/*      */ 
/* 1239 */               mysql.explainSlowQuery(queryAsString.getBytes(), queryAsString);
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/* 1244 */           if (this.connection.getGatherPerformanceMetrics()) {
/* 1245 */             this.connection.registerQueryExecutionTime(elapsedTime);
/*      */           }
/*      */         }
/*      */ 
/* 1249 */         if (mysql.hadWarnings()) {
/* 1250 */           mysql.scanForAndThrowDataTruncation();
/*      */         }
/*      */ 
/* 1253 */         long elapsedTime = rs;
/*      */ 
/* 1255 */         if (timeoutTask != null)
/* 1256 */           timeoutTask.cancel(); return elapsedTime;
/*      */       }
/*      */       finally
/*      */       {
/* 1255 */         if (timeoutTask != null)
/* 1256 */           timeoutTask.cancel();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void serverLongData(int parameterIndex, ServerPreparedStatement.BindValue longData)
/*      */     throws SQLException
/*      */   {
/* 1292 */     synchronized (this.connection.getMutex()) {
/* 1293 */       MysqlIO mysql = this.connection.getIO();
/*      */ 
/* 1295 */       Buffer packet = mysql.getSharedSendPacket();
/*      */ 
/* 1297 */       Object value = longData.value;
/*      */ 
/* 1299 */       if ((value instanceof byte[])) {
/* 1300 */         packet.clear();
/* 1301 */         packet.writeByte(24);
/* 1302 */         packet.writeLong(this.serverStatementId);
/* 1303 */         packet.writeInt(parameterIndex);
/*      */ 
/* 1305 */         packet.writeBytesNoNull((byte[])longData.value);
/*      */ 
/* 1307 */         mysql.sendCommand(24, null, packet, true, null);
/*      */       }
/* 1309 */       else if ((value instanceof InputStream)) {
/* 1310 */         storeStream(mysql, parameterIndex, packet, (InputStream)value);
/* 1311 */       } else if ((value instanceof Blob)) {
/* 1312 */         storeStream(mysql, parameterIndex, packet, ((Blob)value).getBinaryStream());
/*      */       }
/* 1314 */       else if ((value instanceof Reader)) {
/* 1315 */         storeReader(mysql, parameterIndex, packet, (Reader)value);
/*      */       } else {
/* 1317 */         throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.18") + value.getClass().getName() + "'", "S1009");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void serverPrepare(String sql)
/*      */     throws SQLException
/*      */   {
/* 1326 */     synchronized (this.connection.getMutex()) {
/* 1327 */       MysqlIO mysql = this.connection.getIO();
/*      */ 
/* 1329 */       if (this.connection.getAutoGenerateTestcaseScript()) {
/* 1330 */         dumpPrepareForTestcase();
/*      */       }
/*      */       try
/*      */       {
/* 1334 */         long begin = 0L;
/*      */ 
/* 1336 */         if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA"))
/* 1337 */           this.isLoadDataQuery = true;
/*      */         else {
/* 1339 */           this.isLoadDataQuery = false;
/*      */         }
/*      */ 
/* 1342 */         if (this.connection.getProfileSql()) {
/* 1343 */           begin = System.currentTimeMillis();
/*      */         }
/*      */ 
/* 1346 */         String characterEncoding = null;
/* 1347 */         String connectionEncoding = this.connection.getEncoding();
/*      */ 
/* 1349 */         if ((!this.isLoadDataQuery) && (this.connection.getUseUnicode()) && (connectionEncoding != null))
/*      */         {
/* 1351 */           characterEncoding = connectionEncoding;
/*      */         }
/*      */ 
/* 1354 */         Buffer prepareResultPacket = mysql.sendCommand(22, sql, null, false, characterEncoding);
/*      */ 
/* 1358 */         if (this.connection.versionMeetsMinimum(4, 1, 1))
/*      */         {
/* 1363 */           prepareResultPacket.setPosition(1);
/*      */         }
/*      */         else
/*      */         {
/* 1367 */           prepareResultPacket.setPosition(0);
/*      */         }
/*      */ 
/* 1370 */         this.serverStatementId = prepareResultPacket.readLong();
/* 1371 */         this.fieldCount = prepareResultPacket.readInt();
/* 1372 */         this.parameterCount = prepareResultPacket.readInt();
/* 1373 */         this.parameterBindings = new ServerPreparedStatement.BindValue[this.parameterCount];
/*      */ 
/* 1375 */         for (int i = 0; i < this.parameterCount; i++) {
/* 1376 */           this.parameterBindings[i] = new ServerPreparedStatement.BindValue();
/*      */         }
/*      */ 
/* 1379 */         this.connection.incrementNumberOfPrepares();
/*      */ 
/* 1381 */         if (this.connection.getProfileSql()) {
/* 1382 */           this.eventSink = ProfileEventSink.getInstance(this.connection);
/*      */ 
/* 1385 */           this.eventSink.consumeEvent(new ProfilerEvent(2, "", this.currentCatalog, this.connectionId, this.statementId, -1, System.currentTimeMillis(), (int)(System.currentTimeMillis() - begin), null, new Throwable(), truncateQueryToLog(sql)));
/*      */         }
/*      */ 
/* 1394 */         if ((this.parameterCount > 0) && 
/* 1395 */           (this.connection.versionMeetsMinimum(4, 1, 2)) && (!mysql.isVersion(5, 0, 0)))
/*      */         {
/* 1397 */           this.parameterFields = new Field[this.parameterCount];
/*      */ 
/* 1399 */           Buffer metaDataPacket = mysql.readPacket();
/*      */ 
/* 1401 */           int i = 0;
/*      */ 
/* 1404 */           while ((!metaDataPacket.isLastDataPacket()) && (i < this.parameterCount)) {
/* 1405 */             this.parameterFields[(i++)] = mysql.unpackField(metaDataPacket, false);
/*      */ 
/* 1407 */             metaDataPacket = mysql.readPacket();
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 1412 */         if (this.fieldCount > 0) {
/* 1413 */           this.resultFields = new Field[this.fieldCount];
/*      */ 
/* 1415 */           Buffer fieldPacket = mysql.readPacket();
/*      */ 
/* 1417 */           int i = 0;
/*      */ 
/* 1421 */           while ((!fieldPacket.isLastDataPacket()) && (i < this.fieldCount)) {
/* 1422 */             this.resultFields[(i++)] = mysql.unpackField(fieldPacket, false);
/*      */ 
/* 1424 */             fieldPacket = mysql.readPacket();
/*      */           }
/*      */         }
/*      */       } catch (SQLException sqlEx) {
/* 1428 */         if (this.connection.getDumpQueriesOnException()) {
/* 1429 */           StringBuffer messageBuf = new StringBuffer(this.originalSql.length() + 32);
/*      */ 
/* 1431 */           messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
/*      */ 
/* 1433 */           messageBuf.append(this.originalSql);
/*      */ 
/* 1435 */           sqlEx = Connection.appendMessageToException(sqlEx, messageBuf.toString());
/*      */         }
/*      */ 
/* 1439 */         throw sqlEx;
/*      */       }
/*      */       finally
/*      */       {
/* 1444 */         this.connection.getIO().clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private String truncateQueryToLog(String sql) {
/* 1450 */     String query = null;
/*      */ 
/* 1452 */     if (sql.length() > this.connection.getMaxQuerySizeToLog()) {
/* 1453 */       StringBuffer queryBuf = new StringBuffer(this.connection.getMaxQuerySizeToLog() + 12);
/*      */ 
/* 1455 */       queryBuf.append(sql.substring(0, this.connection.getMaxQuerySizeToLog()));
/* 1456 */       queryBuf.append(Messages.getString("MysqlIO.25"));
/*      */ 
/* 1458 */       query = queryBuf.toString();
/*      */     } else {
/* 1460 */       query = sql;
/*      */     }
/*      */ 
/* 1463 */     return query;
/*      */   }
/*      */ 
/*      */   private void serverResetStatement() throws SQLException {
/* 1467 */     synchronized (this.connection.getMutex())
/*      */     {
/* 1469 */       MysqlIO mysql = this.connection.getIO();
/*      */ 
/* 1471 */       Buffer packet = mysql.getSharedSendPacket();
/*      */ 
/* 1473 */       packet.clear();
/* 1474 */       packet.writeByte(26);
/* 1475 */       packet.writeLong(this.serverStatementId);
/*      */       try
/*      */       {
/* 1478 */         mysql.sendCommand(26, null, packet, !this.connection.versionMeetsMinimum(4, 1, 2), null);
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 1481 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 1483 */         throw SQLError.createSQLException(ex.toString(), "S1000");
/*      */       }
/*      */       finally {
/* 1486 */         mysql.clearInputStream();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setArray(int i, Array x)
/*      */     throws SQLException
/*      */   {
/* 1495 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setAsciiStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1504 */     checkClosed();
/*      */ 
/* 1506 */     if (x == null) {
/* 1507 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1509 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, true);
/* 1510 */       setType(binding, 252);
/*      */ 
/* 1512 */       binding.value = x;
/* 1513 */       binding.isNull = false;
/* 1514 */       binding.isLongData = true;
/*      */ 
/* 1516 */       if (this.connection.getUseStreamLengthsInPrepStmts())
/* 1517 */         binding.bindLength = length;
/*      */       else
/* 1519 */         binding.bindLength = -1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBigDecimal(int parameterIndex, BigDecimal x)
/*      */     throws SQLException
/*      */   {
/* 1529 */     checkClosed();
/*      */ 
/* 1531 */     if (x == null) {
/* 1532 */       setNull(parameterIndex, 3);
/*      */     }
/*      */     else {
/* 1535 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/*      */ 
/* 1537 */       if (this.connection.versionMeetsMinimum(5, 0, 3))
/* 1538 */         setType(binding, 246);
/*      */       else {
/* 1540 */         setType(binding, this.stringTypeCode);
/*      */       }
/*      */ 
/* 1543 */       binding.value = StringUtils.fixDecimalExponent(x.toString());
/* 1544 */       binding.isNull = false;
/* 1545 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBinaryStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 1555 */     checkClosed();
/*      */ 
/* 1557 */     if (x == null) {
/* 1558 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1560 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, true);
/* 1561 */       setType(binding, 252);
/*      */ 
/* 1563 */       binding.value = x;
/* 1564 */       binding.isNull = false;
/* 1565 */       binding.isLongData = true;
/*      */ 
/* 1567 */       if (this.connection.getUseStreamLengthsInPrepStmts())
/* 1568 */         binding.bindLength = length;
/*      */       else
/* 1570 */         binding.bindLength = -1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBlob(int parameterIndex, Blob x)
/*      */     throws SQLException
/*      */   {
/* 1579 */     checkClosed();
/*      */ 
/* 1581 */     if (x == null) {
/* 1582 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1584 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, true);
/* 1585 */       setType(binding, 252);
/*      */ 
/* 1587 */       binding.value = x;
/* 1588 */       binding.isNull = false;
/* 1589 */       binding.isLongData = true;
/*      */ 
/* 1591 */       if (this.connection.getUseStreamLengthsInPrepStmts())
/* 1592 */         binding.bindLength = x.length();
/*      */       else
/* 1594 */         binding.bindLength = -1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setBoolean(int parameterIndex, boolean x)
/*      */     throws SQLException
/*      */   {
/* 1603 */     setByte(parameterIndex, x ? 1 : 0);
/*      */   }
/*      */ 
/*      */   public void setByte(int parameterIndex, byte x)
/*      */     throws SQLException
/*      */   {
/* 1610 */     checkClosed();
/*      */ 
/* 1612 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1613 */     setType(binding, 1);
/*      */ 
/* 1615 */     binding.value = null;
/* 1616 */     binding.byteBinding = x;
/* 1617 */     binding.isNull = false;
/* 1618 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setBytes(int parameterIndex, byte[] x)
/*      */     throws SQLException
/*      */   {
/* 1625 */     checkClosed();
/*      */ 
/* 1627 */     if (x == null) {
/* 1628 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1630 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1631 */       setType(binding, 253);
/*      */ 
/* 1633 */       binding.value = x;
/* 1634 */       binding.isNull = false;
/* 1635 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setCharacterStream(int parameterIndex, Reader reader, int length)
/*      */     throws SQLException
/*      */   {
/* 1645 */     checkClosed();
/*      */ 
/* 1647 */     if (reader == null) {
/* 1648 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1650 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, true);
/* 1651 */       setType(binding, 252);
/*      */ 
/* 1653 */       binding.value = reader;
/* 1654 */       binding.isNull = false;
/* 1655 */       binding.isLongData = true;
/*      */ 
/* 1657 */       if (this.connection.getUseStreamLengthsInPrepStmts())
/* 1658 */         binding.bindLength = length;
/*      */       else
/* 1660 */         binding.bindLength = -1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setClob(int parameterIndex, Clob x)
/*      */     throws SQLException
/*      */   {
/* 1669 */     checkClosed();
/*      */ 
/* 1671 */     if (x == null) {
/* 1672 */       setNull(parameterIndex, -2);
/*      */     } else {
/* 1674 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, true);
/* 1675 */       setType(binding, 252);
/*      */ 
/* 1677 */       binding.value = x.getCharacterStream();
/* 1678 */       binding.isNull = false;
/* 1679 */       binding.isLongData = true;
/*      */ 
/* 1681 */       if (this.connection.getUseStreamLengthsInPrepStmts())
/* 1682 */         binding.bindLength = x.length();
/*      */       else
/* 1684 */         binding.bindLength = -1L;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x)
/*      */     throws SQLException
/*      */   {
/* 1702 */     setDate(parameterIndex, x, null);
/*      */   }
/*      */ 
/*      */   public void setDate(int parameterIndex, java.sql.Date x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1721 */     if (x == null) {
/* 1722 */       setNull(parameterIndex, 91);
/*      */     } else {
/* 1724 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1725 */       setType(binding, 10);
/*      */ 
/* 1727 */       binding.value = x;
/* 1728 */       binding.isNull = false;
/* 1729 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setDouble(int parameterIndex, double x)
/*      */     throws SQLException
/*      */   {
/* 1737 */     checkClosed();
/*      */ 
/* 1739 */     if ((!this.connection.getAllowNanAndInf()) && ((x == (1.0D / 0.0D)) || (x == (-1.0D / 0.0D)) || (Double.isNaN(x))))
/*      */     {
/* 1742 */       throw SQLError.createSQLException("'" + x + "' is not a valid numeric or approximate numeric value", "S1009");
/*      */     }
/*      */ 
/* 1748 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1749 */     setType(binding, 5);
/*      */ 
/* 1751 */     binding.value = null;
/* 1752 */     binding.doubleBinding = x;
/* 1753 */     binding.isNull = false;
/* 1754 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setFloat(int parameterIndex, float x)
/*      */     throws SQLException
/*      */   {
/* 1761 */     checkClosed();
/*      */ 
/* 1763 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1764 */     setType(binding, 4);
/*      */ 
/* 1766 */     binding.value = null;
/* 1767 */     binding.floatBinding = x;
/* 1768 */     binding.isNull = false;
/* 1769 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setInt(int parameterIndex, int x)
/*      */     throws SQLException
/*      */   {
/* 1776 */     checkClosed();
/*      */ 
/* 1778 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1779 */     setType(binding, 3);
/*      */ 
/* 1781 */     binding.value = null;
/* 1782 */     binding.intBinding = x;
/* 1783 */     binding.isNull = false;
/* 1784 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setLong(int parameterIndex, long x)
/*      */     throws SQLException
/*      */   {
/* 1791 */     checkClosed();
/*      */ 
/* 1793 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1794 */     setType(binding, 8);
/*      */ 
/* 1796 */     binding.value = null;
/* 1797 */     binding.longBinding = x;
/* 1798 */     binding.isNull = false;
/* 1799 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType)
/*      */     throws SQLException
/*      */   {
/* 1806 */     checkClosed();
/*      */ 
/* 1808 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/*      */ 
/* 1814 */     if (binding.bufferType == 0) {
/* 1815 */       setType(binding, 6);
/*      */     }
/*      */ 
/* 1818 */     binding.value = null;
/* 1819 */     binding.isNull = true;
/* 1820 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setNull(int parameterIndex, int sqlType, String typeName)
/*      */     throws SQLException
/*      */   {
/* 1828 */     checkClosed();
/*      */ 
/* 1830 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/*      */ 
/* 1836 */     if (binding.bufferType == 0) {
/* 1837 */       setType(binding, 6);
/*      */     }
/*      */ 
/* 1840 */     binding.value = null;
/* 1841 */     binding.isNull = true;
/* 1842 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setRef(int i, Ref x)
/*      */     throws SQLException
/*      */   {
/* 1849 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setShort(int parameterIndex, short x)
/*      */     throws SQLException
/*      */   {
/* 1856 */     checkClosed();
/*      */ 
/* 1858 */     ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1859 */     setType(binding, 2);
/*      */ 
/* 1861 */     binding.value = null;
/* 1862 */     binding.shortBinding = x;
/* 1863 */     binding.isNull = false;
/* 1864 */     binding.isLongData = false;
/*      */   }
/*      */ 
/*      */   public void setString(int parameterIndex, String x)
/*      */     throws SQLException
/*      */   {
/* 1871 */     checkClosed();
/*      */ 
/* 1873 */     if (x == null) {
/* 1874 */       setNull(parameterIndex, 1);
/*      */     } else {
/* 1876 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/*      */ 
/* 1878 */       setType(binding, this.stringTypeCode);
/*      */ 
/* 1880 */       binding.value = x;
/* 1881 */       binding.isNull = false;
/* 1882 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x)
/*      */     throws SQLException
/*      */   {
/* 1899 */     setTimeInternal(parameterIndex, x, null, TimeZone.getDefault(), false);
/*      */   }
/*      */ 
/*      */   public void setTime(int parameterIndex, Time x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1919 */     setTimeInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   public void setTimeInternal(int parameterIndex, Time x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 1940 */     if (x == null) {
/* 1941 */       setNull(parameterIndex, 92);
/*      */     } else {
/* 1943 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 1944 */       setType(binding, 11);
/*      */ 
/* 1946 */       Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/* 1948 */       synchronized (sessionCalendar) {
/* 1949 */         binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */       }
/*      */ 
/* 1957 */       binding.isNull = false;
/* 1958 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x)
/*      */     throws SQLException
/*      */   {
/* 1976 */     setTimestampInternal(parameterIndex, x, null, TimeZone.getDefault(), false);
/*      */   }
/*      */ 
/*      */   public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
/*      */     throws SQLException
/*      */   {
/* 1995 */     setTimestampInternal(parameterIndex, x, cal, cal.getTimeZone(), true);
/*      */   }
/*      */ 
/*      */   protected void setTimestampInternal(int parameterIndex, Timestamp x, Calendar targetCalendar, TimeZone tz, boolean rollForward)
/*      */     throws SQLException
/*      */   {
/* 2002 */     if (x == null) {
/* 2003 */       setNull(parameterIndex, 93);
/*      */     } else {
/* 2005 */       ServerPreparedStatement.BindValue binding = getBinding(parameterIndex, false);
/* 2006 */       setType(binding, 12);
/*      */ 
/* 2008 */       Calendar sessionCalendar = this.connection.getUseJDBCCompliantTimezoneShift() ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 2012 */       synchronized (sessionCalendar) {
/* 2013 */         binding.value = TimeUtil.changeTimezone(this.connection, sessionCalendar, targetCalendar, x, tz, this.connection.getServerTimezoneTZ(), rollForward);
/*      */       }
/*      */ 
/* 2021 */       binding.isNull = false;
/* 2022 */       binding.isLongData = false;
/*      */     }
/*      */   }
/*      */ 
/*      */   private void setType(ServerPreparedStatement.BindValue oldValue, int bufferType) {
/* 2027 */     if (oldValue.bufferType != bufferType) {
/* 2028 */       this.sendTypesToServer = true;
/*      */     }
/*      */ 
/* 2031 */     oldValue.bufferType = bufferType;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void setUnicodeStream(int parameterIndex, InputStream x, int length)
/*      */     throws SQLException
/*      */   {
/* 2055 */     checkClosed();
/*      */ 
/* 2057 */     throw new NotImplemented();
/*      */   }
/*      */ 
/*      */   public void setURL(int parameterIndex, URL x)
/*      */     throws SQLException
/*      */   {
/* 2064 */     checkClosed();
/*      */ 
/* 2066 */     setString(parameterIndex, x.toString());
/*      */   }
/*      */ 
/*      */   private void storeBinding(Buffer packet, ServerPreparedStatement.BindValue bindValue, MysqlIO mysql)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2083 */       Object value = bindValue.value;
/*      */ 
/* 2088 */       switch (bindValue.bufferType)
/*      */       {
/*      */       case 1:
/* 2091 */         packet.writeByte(bindValue.byteBinding);
/* 2092 */         return;
/*      */       case 2:
/* 2094 */         packet.ensureCapacity(2);
/* 2095 */         packet.writeInt(bindValue.shortBinding);
/* 2096 */         return;
/*      */       case 3:
/* 2098 */         packet.ensureCapacity(4);
/* 2099 */         packet.writeLong(bindValue.intBinding);
/* 2100 */         return;
/*      */       case 8:
/* 2102 */         packet.ensureCapacity(8);
/* 2103 */         packet.writeLongLong(bindValue.longBinding);
/* 2104 */         return;
/*      */       case 4:
/* 2106 */         packet.ensureCapacity(4);
/* 2107 */         packet.writeFloat(bindValue.floatBinding);
/* 2108 */         return;
/*      */       case 5:
/* 2110 */         packet.ensureCapacity(8);
/* 2111 */         packet.writeDouble(bindValue.doubleBinding);
/* 2112 */         return;
/*      */       case 11:
/* 2114 */         storeTime(packet, (Time)value);
/* 2115 */         return;
/*      */       case 7:
/*      */       case 10:
/*      */       case 12:
/* 2119 */         storeDateTime(packet, (java.util.Date)value, mysql);
/* 2120 */         return;
/*      */       case 0:
/*      */       case 15:
/*      */       case 246:
/*      */       case 253:
/*      */       case 254:
/* 2126 */         if ((value instanceof byte[]))
/* 2127 */           packet.writeLenBytes((byte[])value);
/* 2128 */         else if (!this.isLoadDataQuery) {
/* 2129 */           packet.writeLenString((String)value, this.charEncoding, this.connection.getServerCharacterEncoding(), this.charConverter, this.connection.parserKnowsUnicode(), this.connection);
/*      */         }
/*      */         else
/*      */         {
/* 2135 */           packet.writeLenBytes(((String)value).getBytes());
/*      */         }
/*      */ 
/* 2138 */         return;
/*      */       }
/*      */     }
/*      */     catch (UnsupportedEncodingException uEE)
/*      */     {
/* 2143 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.22") + this.connection.getEncoding() + "'", "S1000");
/*      */     }
/*      */   }
/*      */ 
/*      */   private void storeDataTime412AndOlder(Buffer intoBuf, java.util.Date dt)
/*      */     throws SQLException
/*      */   {
/* 2153 */     Calendar sessionCalendar = getCalendarInstanceForSessionOrNew();
/*      */ 
/* 2155 */     synchronized (sessionCalendar) {
/* 2156 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2159 */         intoBuf.ensureCapacity(8);
/* 2160 */         intoBuf.writeByte(7);
/*      */ 
/* 2162 */         sessionCalendar.setTime(dt);
/*      */ 
/* 2164 */         int year = sessionCalendar.get(1);
/* 2165 */         int month = sessionCalendar.get(2) + 1;
/* 2166 */         int date = sessionCalendar.get(5);
/*      */ 
/* 2168 */         intoBuf.writeInt(year);
/* 2169 */         intoBuf.writeByte((byte)month);
/* 2170 */         intoBuf.writeByte((byte)date);
/*      */ 
/* 2172 */         if ((dt instanceof java.sql.Date)) {
/* 2173 */           intoBuf.writeByte(0);
/* 2174 */           intoBuf.writeByte(0);
/* 2175 */           intoBuf.writeByte(0);
/*      */         } else {
/* 2177 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/*      */ 
/* 2179 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/*      */ 
/* 2181 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */       }
/*      */       finally {
/* 2185 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void storeDateTime(Buffer intoBuf, java.util.Date dt, MysqlIO mysql) throws SQLException
/*      */   {
/* 2192 */     if (this.connection.versionMeetsMinimum(4, 1, 3))
/* 2193 */       storeDateTime413AndNewer(intoBuf, dt);
/*      */     else
/* 2195 */       storeDataTime412AndOlder(intoBuf, dt);
/*      */   }
/*      */ 
/*      */   private void storeDateTime413AndNewer(Buffer intoBuf, java.util.Date dt)
/*      */     throws SQLException
/*      */   {
/* 2201 */     Calendar sessionCalendar = ((dt instanceof Timestamp)) && (this.connection.getUseJDBCCompliantTimezoneShift()) ? this.connection.getUtcCalendar() : getCalendarInstanceForSessionOrNew();
/*      */ 
/* 2205 */     synchronized (sessionCalendar) {
/* 2206 */       java.util.Date oldTime = sessionCalendar.getTime();
/*      */       try
/*      */       {
/* 2210 */         sessionCalendar.setTime(dt);
/*      */ 
/* 2212 */         if ((dt instanceof java.sql.Date)) {
/* 2213 */           sessionCalendar.set(11, 0);
/* 2214 */           sessionCalendar.set(12, 0);
/* 2215 */           sessionCalendar.set(13, 0);
/*      */         }
/*      */ 
/* 2218 */         byte length = 7;
/*      */ 
/* 2220 */         intoBuf.ensureCapacity(length);
/*      */ 
/* 2222 */         if ((dt instanceof Timestamp)) {
/* 2223 */           length = 11;
/*      */         }
/*      */ 
/* 2226 */         intoBuf.writeByte(length);
/*      */ 
/* 2228 */         int year = sessionCalendar.get(1);
/* 2229 */         int month = sessionCalendar.get(2) + 1;
/* 2230 */         int date = sessionCalendar.get(5);
/*      */ 
/* 2232 */         intoBuf.writeInt(year);
/* 2233 */         intoBuf.writeByte((byte)month);
/* 2234 */         intoBuf.writeByte((byte)date);
/*      */ 
/* 2236 */         if ((dt instanceof java.sql.Date)) {
/* 2237 */           intoBuf.writeByte(0);
/* 2238 */           intoBuf.writeByte(0);
/* 2239 */           intoBuf.writeByte(0);
/*      */         } else {
/* 2241 */           intoBuf.writeByte((byte)sessionCalendar.get(11));
/*      */ 
/* 2243 */           intoBuf.writeByte((byte)sessionCalendar.get(12));
/*      */ 
/* 2245 */           intoBuf.writeByte((byte)sessionCalendar.get(13));
/*      */         }
/*      */ 
/* 2249 */         if (length == 11)
/* 2250 */           intoBuf.writeLong(((Timestamp)dt).getNanos());
/*      */       }
/*      */       finally
/*      */       {
/* 2254 */         sessionCalendar.setTime(oldTime);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void storeReader(MysqlIO mysql, int parameterIndex, Buffer packet, Reader inStream)
/*      */     throws SQLException
/*      */   {
/* 2264 */     String forcedEncoding = this.connection.getClobCharacterEncoding();
/*      */ 
/* 2266 */     String clobEncoding = forcedEncoding == null ? this.connection.getEncoding() : forcedEncoding;
/*      */ 
/* 2269 */     int maxBytesChar = 2;
/*      */ 
/* 2271 */     if (clobEncoding != null) {
/* 2272 */       if (!clobEncoding.equals("UTF-16")) {
/* 2273 */         maxBytesChar = this.connection.getMaxBytesPerChar(clobEncoding);
/*      */ 
/* 2275 */         if (maxBytesChar == 1)
/* 2276 */           maxBytesChar = 2;
/*      */       }
/*      */       else {
/* 2279 */         maxBytesChar = 4;
/*      */       }
/*      */     }
/*      */ 
/* 2283 */     char[] buf = new char[8192 / maxBytesChar];
/*      */ 
/* 2285 */     int numRead = 0;
/*      */ 
/* 2287 */     int bytesInPacket = 0;
/* 2288 */     int totalBytesRead = 0;
/* 2289 */     int bytesReadAtLastSend = 0;
/* 2290 */     int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */     try
/*      */     {
/* 2295 */       packet.clear();
/* 2296 */       packet.writeByte(24);
/* 2297 */       packet.writeLong(this.serverStatementId);
/* 2298 */       packet.writeInt(parameterIndex);
/*      */ 
/* 2300 */       boolean readAny = false;
/*      */ 
/* 2302 */       while ((numRead = inStream.read(buf)) != -1) {
/* 2303 */         readAny = true;
/*      */ 
/* 2305 */         byte[] valueAsBytes = StringUtils.getBytes(buf, null, clobEncoding, this.connection.getServerCharacterEncoding(), 0, numRead, this.connection.parserKnowsUnicode());
/*      */ 
/* 2310 */         packet.writeBytesNoNull(valueAsBytes, 0, valueAsBytes.length);
/*      */ 
/* 2312 */         bytesInPacket += valueAsBytes.length;
/* 2313 */         totalBytesRead += valueAsBytes.length;
/*      */ 
/* 2315 */         if (bytesInPacket >= packetIsFullAt) {
/* 2316 */           bytesReadAtLastSend = totalBytesRead;
/*      */ 
/* 2318 */           mysql.sendCommand(24, null, packet, true, null);
/*      */ 
/* 2321 */           bytesInPacket = 0;
/* 2322 */           packet.clear();
/* 2323 */           packet.writeByte(24);
/* 2324 */           packet.writeLong(this.serverStatementId);
/* 2325 */           packet.writeInt(parameterIndex);
/*      */         }
/*      */       }
/*      */ 
/* 2329 */       if (totalBytesRead != bytesReadAtLastSend) {
/* 2330 */         mysql.sendCommand(24, null, packet, true, null);
/*      */       }
/*      */ 
/* 2334 */       if (!readAny)
/* 2335 */         mysql.sendCommand(24, null, packet, true, null);
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/* 2339 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.24") + ioEx.toString(), "S1000");
/*      */     }
/*      */     finally
/*      */     {
/* 2343 */       if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2344 */         (inStream != null))
/*      */         try {
/* 2346 */           inStream.close();
/*      */         }
/*      */         catch (IOException ioEx)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   private void storeStream(MysqlIO mysql, int parameterIndex, Buffer packet, InputStream inStream)
/*      */     throws SQLException
/*      */   {
/* 2357 */     byte[] buf = new byte[8192];
/*      */ 
/* 2359 */     int numRead = 0;
/*      */     try
/*      */     {
/* 2362 */       int bytesInPacket = 0;
/* 2363 */       int totalBytesRead = 0;
/* 2364 */       int bytesReadAtLastSend = 0;
/* 2365 */       int packetIsFullAt = this.connection.getBlobSendChunkSize();
/*      */ 
/* 2367 */       packet.clear();
/* 2368 */       packet.writeByte(24);
/* 2369 */       packet.writeLong(this.serverStatementId);
/* 2370 */       packet.writeInt(parameterIndex);
/*      */ 
/* 2372 */       boolean readAny = false;
/*      */ 
/* 2374 */       while ((numRead = inStream.read(buf)) != -1)
/*      */       {
/* 2376 */         readAny = true;
/*      */ 
/* 2378 */         packet.writeBytesNoNull(buf, 0, numRead);
/* 2379 */         bytesInPacket += numRead;
/* 2380 */         totalBytesRead += numRead;
/*      */ 
/* 2382 */         if (bytesInPacket >= packetIsFullAt) {
/* 2383 */           bytesReadAtLastSend = totalBytesRead;
/*      */ 
/* 2385 */           mysql.sendCommand(24, null, packet, true, null);
/*      */ 
/* 2388 */           bytesInPacket = 0;
/* 2389 */           packet.clear();
/* 2390 */           packet.writeByte(24);
/* 2391 */           packet.writeLong(this.serverStatementId);
/* 2392 */           packet.writeInt(parameterIndex);
/*      */         }
/*      */       }
/*      */ 
/* 2396 */       if (totalBytesRead != bytesReadAtLastSend) {
/* 2397 */         mysql.sendCommand(24, null, packet, true, null);
/*      */       }
/*      */ 
/* 2401 */       if (!readAny)
/* 2402 */         mysql.sendCommand(24, null, packet, true, null);
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/* 2406 */       throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.25") + ioEx.toString(), "S1000");
/*      */     }
/*      */     finally
/*      */     {
/* 2410 */       if ((this.connection.getAutoClosePStmtStreams()) && 
/* 2411 */         (inStream != null))
/*      */         try {
/* 2413 */           inStream.close();
/*      */         }
/*      */         catch (IOException ioEx)
/*      */         {
/*      */         }
/*      */     }
/*      */   }
/*      */ 
/*      */   public String toString()
/*      */   {
/* 2426 */     StringBuffer toStringBuf = new StringBuffer();
/*      */ 
/* 2428 */     toStringBuf.append("com.mysql.jdbc.ServerPreparedStatement[");
/* 2429 */     toStringBuf.append(this.serverStatementId);
/* 2430 */     toStringBuf.append("] - ");
/*      */     try
/*      */     {
/* 2433 */       toStringBuf.append(asSql());
/*      */     } catch (SQLException sqlEx) {
/* 2435 */       toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
/* 2436 */       toStringBuf.append(sqlEx);
/*      */     }
/*      */ 
/* 2439 */     return toStringBuf.toString();
/*      */   }
/*      */ 
/*      */   protected long getServerStatementId() {
/* 2443 */     return this.serverStatementId;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ServerPreparedStatement
 * JD-Core Version:    0.6.0
 */