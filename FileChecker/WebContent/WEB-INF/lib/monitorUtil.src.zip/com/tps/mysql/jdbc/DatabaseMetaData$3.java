/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ class DatabaseMetaData$3 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final Statement val$stmt;
/*      */   private final String val$foreignTable;
/*      */   private final String val$primaryTable;
/*      */   private final String val$foreignCatalog;
/*      */   private final String val$foreignSchema;
/*      */   private final String val$primaryCatalog;
/*      */   private final String val$primarySchema;
/*      */   private final ArrayList val$tuples;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 2278 */     ResultSet fkresults = null;
/*      */     try
/*      */     {
/* 2285 */       if (this.this$0.conn.versionMeetsMinimum(3, 23, 50)) {
/* 2286 */         fkresults = this.this$0.extractForeignKeyFromCreateTable(catalogStr.toString(), null);
/*      */       }
/*      */       else {
/* 2289 */         StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS FROM ");
/*      */ 
/* 2291 */         queryBuf.append(this.this$0.quotedId);
/* 2292 */         queryBuf.append(catalogStr.toString());
/* 2293 */         queryBuf.append(this.this$0.quotedId);
/*      */ 
/* 2295 */         fkresults = this.val$stmt.executeQuery(queryBuf.toString());
/*      */       }
/*      */ 
/* 2299 */       String foreignTableWithCase = DatabaseMetaData.access$100(this.this$0, this.val$foreignTable);
/* 2300 */       String primaryTableWithCase = DatabaseMetaData.access$100(this.this$0, this.val$primaryTable);
/*      */ 
/* 2308 */       while (fkresults.next()) {
/* 2309 */         String tableType = fkresults.getString("Type");
/*      */ 
/* 2311 */         if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */         {
/* 2315 */           String comment = fkresults.getString("Comment").trim();
/*      */ 
/* 2318 */           if (comment != null) {
/* 2319 */             StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */             String dummy;
/* 2322 */             if (commentTokens.hasMoreTokens()) {
/* 2323 */               dummy = commentTokens.nextToken();
/*      */             }
/*      */ 
/* 2328 */             while (commentTokens.hasMoreTokens()) {
/* 2329 */               String keys = commentTokens.nextToken();
/*      */ 
/* 2331 */               DatabaseMetaData.LocalAndReferencedColumns parsedInfo = DatabaseMetaData.access$200(this.this$0, keys);
/*      */ 
/* 2333 */               int keySeq = 0;
/*      */ 
/* 2335 */               Iterator referencingColumns = parsedInfo.localColumnsList.iterator();
/*      */ 
/* 2337 */               Iterator referencedColumns = parsedInfo.referencedColumnsList.iterator();
/*      */ 
/* 2340 */               while (referencingColumns.hasNext()) {
/* 2341 */                 String referencingColumn = DatabaseMetaData.access$300(this.this$0, referencingColumns.next().toString());
/*      */ 
/* 2347 */                 byte[][] tuple = new byte[14][];
/* 2348 */                 tuple[4] = (this.val$foreignCatalog == null ? null : DatabaseMetaData.access$000(this.this$0, this.val$foreignCatalog));
/*      */ 
/* 2350 */                 tuple[5] = (this.val$foreignSchema == null ? null : DatabaseMetaData.access$000(this.this$0, this.val$foreignSchema));
/*      */ 
/* 2352 */                 String dummy = fkresults.getString("Name");
/*      */ 
/* 2355 */                 if (dummy.compareTo(foreignTableWithCase) != 0)
/*      */                 {
/*      */                   continue;
/*      */                 }
/*      */ 
/* 2360 */                 tuple[6] = DatabaseMetaData.access$000(this.this$0, dummy);
/*      */ 
/* 2362 */                 tuple[7] = DatabaseMetaData.access$000(this.this$0, referencingColumn);
/* 2363 */                 tuple[0] = (this.val$primaryCatalog == null ? null : DatabaseMetaData.access$000(this.this$0, this.val$primaryCatalog));
/*      */ 
/* 2365 */                 tuple[1] = (this.val$primarySchema == null ? null : DatabaseMetaData.access$000(this.this$0, this.val$primarySchema));
/*      */ 
/* 2371 */                 if (parsedInfo.referencedTable.compareTo(primaryTableWithCase) != 0)
/*      */                 {
/*      */                   continue;
/*      */                 }
/*      */ 
/* 2376 */                 tuple[2] = DatabaseMetaData.access$000(this.this$0, parsedInfo.referencedTable);
/* 2377 */                 tuple[3] = DatabaseMetaData.access$000(this.this$0, DatabaseMetaData.access$300(this.this$0, referencedColumns.next().toString()));
/*      */ 
/* 2379 */                 tuple[8] = Integer.toString(keySeq).getBytes();
/*      */ 
/* 2382 */                 int[] actions = DatabaseMetaData.access$400(this.this$0, keys);
/*      */ 
/* 2384 */                 tuple[9] = Integer.toString(actions[1]).getBytes();
/*      */ 
/* 2386 */                 tuple[10] = Integer.toString(actions[0]).getBytes();
/*      */ 
/* 2388 */                 tuple[11] = null;
/* 2389 */                 tuple[12] = null;
/* 2390 */                 tuple[13] = Integer.toString(7).getBytes();
/*      */ 
/* 2394 */                 this.val$tuples.add(tuple);
/* 2395 */                 keySeq++;
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     finally {
/* 2403 */       if (fkresults != null) {
/*      */         try {
/* 2405 */           fkresults.close();
/*      */         } catch (Exception sqlEx) {
/* 2407 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */ 
/* 2411 */         fkresults = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.3
 * JD-Core Version:    0.6.0
 */