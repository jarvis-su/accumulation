/*    */ package com.acs.fileChecker;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.SortedMap;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class ReportList
/*    */ {
/*    */   private SortedMap reports;
/*    */ 
/*    */   public ReportList()
/*    */   {
/* 13 */     this.reports = new TreeMap();
/*    */   }
/*    */ 
/*    */   public Report get(String fileName)
/*    */   {
/* 18 */     return (Report)this.reports.get(fileName);
/*    */   }
/*    */ 
/*    */   public boolean add(Report r)
/*    */   {
/* 41 */     Report r2 = (Report)this.reports.get(r.getFileName());
/* 42 */     boolean isNew = r2 == null;
/* 43 */     if (isNew) {
/* 44 */       this.reports.put(r.getFileName(), r);
/*    */     }
/*    */     else {
/* 47 */       if (r.getEndCheck().after(r2.getEndCheck()))
/* 48 */         r2.setEndCheck(r.getEndCheck());
/* 49 */       if (r.getStartCheck().before(r2.getStartCheck()))
/* 50 */         r2.setStartCheck(r.getStartCheck());
/* 51 */       if (r.shouldBeChecked())
/* 52 */         r2.incExpectedCount();
/*    */     }
/* 54 */     return isNew;
/*    */   }
/*    */ 
/*    */   public boolean isEmpty()
/*    */   {
/* 59 */     return this.reports.isEmpty();
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 64 */     return this.reports.size();
/*    */   }
/*    */ 
/*    */   public Map getAll()
/*    */   {
/* 69 */     return this.reports;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 74 */     String result = "";
/* 75 */     Iterator i = this.reports.values().iterator();
/* 76 */     if (i.hasNext())
/* 77 */       result = result + ((Report)i.next()).getID();
/* 78 */     while (i.hasNext())
/*    */     {
/* 80 */       result = result + ",";
/* 81 */       result = result + ((Report)i.next()).getID();
/*    */     }
/* 83 */     return result;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.ReportList
 * JD-Core Version:    0.6.0
 */