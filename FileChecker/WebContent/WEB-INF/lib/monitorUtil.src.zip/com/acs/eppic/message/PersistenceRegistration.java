/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class PersistenceRegistration extends RegistrationData
/*    */ {
/*    */   private static final long serialVersionUID = 8576538088104800173L;
/*    */   private static final String SID = "SID";
/*    */ 
/*    */   public PersistenceRegistration()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PersistenceRegistration(HashMap map)
/*    */   {
/* 18 */     setData(map);
/*    */   }
/*    */ 
/*    */   public PersistenceRegistration(String sid) {
/* 22 */     setData("SID", sid);
/*    */   }
/*    */ 
/*    */   public String getSID() {
/* 26 */     String sid = "";
/* 27 */     if (getData("SID") != null) {
/* 28 */       sid = (String)getData("SID");
/*    */     }
/* 30 */     return sid;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 34 */     return super.toString() + 
/* 35 */       "  SID: " + getSID() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.message.PersistenceRegistration
 * JD-Core Version:    0.6.0
 */