/*    */ package ch.ethz.ssh2.crypto.cipher;
/*    */ 
/*    */ public class NullCipher
/*    */   implements BlockCipher
/*    */ {
/* 11 */   private int blockSize = 8;
/*    */ 
/*    */   public NullCipher()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NullCipher(int blockSize)
/*    */   {
/* 19 */     this.blockSize = blockSize;
/*    */   }
/*    */ 
/*    */   public void init(boolean forEncryption, byte[] key)
/*    */   {
/*    */   }
/*    */ 
/*    */   public int getBlockSize()
/*    */   {
/* 28 */     return this.blockSize;
/*    */   }
/*    */ 
/*    */   public void transformBlock(byte[] src, int srcoff, byte[] dst, int dstoff)
/*    */   {
/* 33 */     System.arraycopy(src, srcoff, dst, dstoff, this.blockSize);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.NullCipher
 * JD-Core Version:    0.6.0
 */