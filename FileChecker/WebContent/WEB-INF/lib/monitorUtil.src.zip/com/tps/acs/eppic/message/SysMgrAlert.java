/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class SysMgrAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = -860838716992057572L;
/*    */   private static final String MEMORY_REMAINING = "MEMORY_REMAINING";
/*    */ 
/*    */   public SysMgrAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public SysMgrAlert(HashMap map)
/*    */   {
/* 18 */     setData(map);
/*    */   }
/*    */ 
/*    */   public SysMgrAlert(String code, String description, int memoryRemaining) {
/* 22 */     super(code, description);
/* 23 */     setData("MEMORY_REMAINING", new Integer(memoryRemaining));
/*    */   }
/*    */ 
/*    */   public int getMemoryRemaining() {
/* 27 */     int retVal = -1;
/* 28 */     if (getData("MEMORY_REMAINING") != null) {
/* 29 */       retVal = ((Integer)getData("MEMORY_REMAINING")).intValue();
/*    */     }
/* 31 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 35 */     return super.toString() + 
/* 36 */       "  Memory Remaining: " + getMemoryRemaining() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.SysMgrAlert
 * JD-Core Version:    0.6.0
 */