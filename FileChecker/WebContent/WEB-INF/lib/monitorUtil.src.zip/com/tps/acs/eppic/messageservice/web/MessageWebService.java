package com.acs.eppic.messageservice.web;

import com.acs.eppic.message.Message;
import java.rmi.Remote;
import java.rmi.RemoteException;

public abstract interface MessageWebService extends Remote
{
  public abstract void sendMessage(Message paramMessage)
    throws RemoteException;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.web.MessageWebService
 * JD-Core Version:    0.6.0
 */