/*     */ package com.acs.eppic.message;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import javax.xml.namespace.QName;
/*     */ import org.apache.axis.description.ElementDesc;
/*     */ import org.apache.axis.description.TypeDesc;
/*     */ import org.apache.axis.encoding.Deserializer;
/*     */ import org.apache.axis.encoding.Serializer;
/*     */ import org.apache.axis.encoding.ser.BeanDeserializer;
/*     */ import org.apache.axis.encoding.ser.BeanSerializer;
/*     */ 
/*     */ public class MessageData
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 5368538426620921693L;
/*     */   private HashMap data;
/*  54 */   private Object __equalsCalc = null;
/*     */ 
/*  73 */   private boolean __hashCodeCalc = false;
/*     */ 
/*  89 */   private static TypeDesc typeDesc = new TypeDesc(MessageData.class, true);
/*     */ 
/*     */   static {
/*  92 */     typeDesc.setXmlType(new QName("http://message.eppic.acs.com", "MessageData"));
/*  93 */     ElementDesc elemField = new ElementDesc();
/*  94 */     elemField.setFieldName("data");
/*  95 */     elemField.setXmlName(new QName("", "data"));
/*  96 */     elemField.setXmlType(new QName("http://xml.apache.org/xml-soap", "Map"));
/*  97 */     elemField.setNillable(true);
/*  98 */     typeDesc.addFieldDesc(elemField);
/*     */   }
/*     */ 
/*     */   public MessageData()
/*     */   {
/*  18 */     this.data = new HashMap();
/*     */   }
/*     */ 
/*     */   public MessageData(HashMap data)
/*     */   {
/*  23 */     this.data = data;
/*     */   }
/*     */ 
/*     */   public HashMap getData()
/*     */   {
/*  33 */     return this.data;
/*     */   }
/*     */ 
/*     */   public void setData(HashMap data)
/*     */   {
/*  43 */     this.data = data;
/*     */   }
/*     */ 
/*     */   public void setData(String key, Object value) {
/*  47 */     this.data.put(key, value);
/*     */   }
/*     */ 
/*     */   public Object getData(String key) {
/*  51 */     return this.data.get(key);
/*     */   }
/*     */ 
/*     */   public synchronized boolean equals(Object obj)
/*     */   {
/*  56 */     if (obj == null) return false;
/*  57 */     if (!(obj instanceof MessageData)) return false;
/*  58 */     MessageData other = (MessageData)obj;
/*  59 */     if (this == obj) return true;
/*  60 */     if (this.__equalsCalc != null) {
/*  61 */       return this.__equalsCalc == obj;
/*     */     }
/*  63 */     this.__equalsCalc = obj;
/*     */ 
/*  65 */     boolean _equals = 
/*  66 */       ((this.data == null) && (other.getData() == null)) || (
/*  67 */       (this.data != null) && 
/*  68 */       (this.data.equals(other.getData())));
/*  69 */     this.__equalsCalc = null;
/*  70 */     return _equals;
/*     */   }
/*     */ 
/*     */   public synchronized int hashCode()
/*     */   {
/*  75 */     if (this.__hashCodeCalc) {
/*  76 */       return 0;
/*     */     }
/*  78 */     this.__hashCodeCalc = true;
/*  79 */     int _hashCode = 1;
/*  80 */     if (getData() != null) {
/*  81 */       _hashCode += getData().hashCode();
/*     */     }
/*  83 */     this.__hashCodeCalc = false;
/*  84 */     return _hashCode;
/*     */   }
/*     */ 
/*     */   public static TypeDesc getTypeDesc()
/*     */   {
/* 105 */     return typeDesc;
/*     */   }
/*     */ 
/*     */   public static Serializer getSerializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 115 */     return 
/* 116 */       new BeanSerializer(
/* 117 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ 
/*     */   public static Deserializer getDeserializer(String mechType, Class _javaType, QName _xmlType)
/*     */   {
/* 127 */     return 
/* 128 */       new BeanDeserializer(
/* 129 */       _javaType, _xmlType, typeDesc);
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 133 */     StringBuffer output = new StringBuffer(100);
/* 134 */     Iterator it = this.data.keySet().iterator();
/*     */ 
/* 136 */     while (it.hasNext()) {
/* 137 */       Object key = it.next();
/* 138 */       Object val = this.data.get(key);
/* 139 */       output.append("  " + key + "=" + val + "\n");
/*     */     }
/*     */ 
/* 142 */     return output.toString();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.MessageData
 * JD-Core Version:    0.6.0
 */