package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.wsdl.Part;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class PartImpl
  implements Part
{
  protected String name = null;
  protected QName elementName = null;
  protected QName typeName = null;
  protected Element docEl = null;
  protected Map extensionAttributes = new HashMap();
  protected List nativeAttributeNames = Arrays.asList(Constants.PART_ATTR_NAMES);
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setElementName(QName paramQName)
  {
    this.elementName = paramQName;
  }

  public QName getElementName()
  {
    return this.elementName;
  }

  public void setTypeName(QName paramQName)
  {
    this.typeName = paramQName;
  }

  public QName getTypeName()
  {
    return this.typeName;
  }

  public void setExtensionAttribute(QName paramQName, Object paramObject)
  {
    if (paramObject != null)
      this.extensionAttributes.put(paramQName, paramObject);
    else
      this.extensionAttributes.remove(paramQName);
  }

  public Object getExtensionAttribute(QName paramQName)
  {
    return this.extensionAttributes.get(paramQName);
  }

  public Map getExtensionAttributes()
  {
    return this.extensionAttributes;
  }

  public List getNativeAttributeNames()
  {
    return this.nativeAttributeNames;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Part: name=" + this.name);
    if (this.elementName != null)
      localStringBuffer.append("\nelementName=" + this.elementName);
    if (this.typeName != null)
      localStringBuffer.append("\ntypeName=" + this.typeName);
    Iterator localIterator = this.extensionAttributes.keySet().iterator();
    while (localIterator.hasNext())
    {
      QName localQName = (QName)localIterator.next();
      localStringBuffer.append("\nextension attribute: " + localQName + "=" + this.extensionAttributes.get(localQName));
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.PartImpl
 * JD-Core Version:    0.6.0
 */