/*   */ package com.smj.dbvariable;
/*   */ 
/*   */  enum DBVar$Status
/*   */ {
/* 9 */   NADA, DIRTY, RESOLVED;
/*   */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.DBVar.Status
 * JD-Core Version:    0.6.0
 */