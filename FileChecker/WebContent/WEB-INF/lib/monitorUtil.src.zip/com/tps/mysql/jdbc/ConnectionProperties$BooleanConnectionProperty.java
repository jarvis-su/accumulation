/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.SQLException;
/*     */ 
/*     */ class ConnectionProperties$BooleanConnectionProperty extends ConnectionProperties.ConnectionProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 2540132501709159404L;
/*     */   private final ConnectionProperties this$0;
/*     */ 
/*     */   ConnectionProperties$BooleanConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, boolean defaultValueToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/*  77 */     super(this$0, propertyNameToSet, new Boolean(defaultValueToSet), null, 0, 0, descriptionToSet, sinceVersionToSet, category, orderInCategory);
/*     */ 
/*  76 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   String[] getAllowableValues()
/*     */   {
/*  86 */     return new String[] { "true", "false", "yes", "no" };
/*     */   }
/*     */ 
/*     */   boolean getValueAsBoolean() {
/*  90 */     return ((Boolean)this.valueAsObject).booleanValue();
/*     */   }
/*     */ 
/*     */   boolean hasValueConstraints()
/*     */   {
/*  97 */     return true;
/*     */   }
/*     */ 
/*     */   void initializeFrom(String extractedValue)
/*     */     throws SQLException
/*     */   {
/* 104 */     if (extractedValue != null) {
/* 105 */       validateStringValues(extractedValue);
/*     */ 
/* 107 */       this.valueAsObject = new Boolean((extractedValue.equalsIgnoreCase("TRUE")) || (extractedValue.equalsIgnoreCase("YES")));
/*     */     }
/*     */     else
/*     */     {
/* 111 */       this.valueAsObject = this.defaultValue;
/*     */     }
/*     */   }
/*     */ 
/*     */   boolean isRangeBased()
/*     */   {
/* 119 */     return false;
/*     */   }
/*     */ 
/*     */   void setValue(boolean valueFlag) {
/* 123 */     this.valueAsObject = new Boolean(valueFlag);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.BooleanConnectionProperty
 * JD-Core Version:    0.6.0
 */