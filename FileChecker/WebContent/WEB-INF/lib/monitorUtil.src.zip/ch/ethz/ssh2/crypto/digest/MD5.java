/*     */ package ch.ethz.ssh2.crypto.digest;
/*     */ 
/*     */ public final class MD5
/*     */   implements Digest
/*     */ {
/*     */   private int state0;
/*     */   private int state1;
/*     */   private int state2;
/*     */   private int state3;
/*     */   private long count;
/*  40 */   private final byte[] block = new byte[64];
/*  41 */   private final int[] x = new int[16];
/*     */ 
/*  43 */   private static final byte[] padding = { -128 };
/*     */ 
/*     */   public MD5()
/*     */   {
/*  49 */     reset();
/*     */   }
/*     */ 
/*     */   private static final int FF(int a, int b, int c, int d, int x, int s, int ac)
/*     */   {
/*  54 */     a += (b & c | (b ^ 0xFFFFFFFF) & d) + x + ac;
/*  55 */     return (a << s | a >>> 32 - s) + b;
/*     */   }
/*     */ 
/*     */   private static final int GG(int a, int b, int c, int d, int x, int s, int ac)
/*     */   {
/*  60 */     a += (b & d | c & (d ^ 0xFFFFFFFF)) + x + ac;
/*  61 */     return (a << s | a >>> 32 - s) + b;
/*     */   }
/*     */ 
/*     */   private static final int HH(int a, int b, int c, int d, int x, int s, int ac)
/*     */   {
/*  66 */     a += (b ^ c ^ d) + x + ac;
/*  67 */     return (a << s | a >>> 32 - s) + b;
/*     */   }
/*     */ 
/*     */   private static final int II(int a, int b, int c, int d, int x, int s, int ac)
/*     */   {
/*  72 */     a += (c ^ (b | d ^ 0xFFFFFFFF)) + x + ac;
/*  73 */     return (a << s | a >>> 32 - s) + b;
/*     */   }
/*     */ 
/*     */   private static final void encode(byte[] dst, int dstoff, int word)
/*     */   {
/*  78 */     dst[dstoff] = (byte)word;
/*  79 */     dst[(dstoff + 1)] = (byte)(word >> 8);
/*  80 */     dst[(dstoff + 2)] = (byte)(word >> 16);
/*  81 */     dst[(dstoff + 3)] = (byte)(word >> 24);
/*     */   }
/*     */ 
/*     */   private final void transform(byte[] src, int pos)
/*     */   {
/*  86 */     int a = this.state0;
/*  87 */     int b = this.state1;
/*  88 */     int c = this.state2;
/*  89 */     int d = this.state3;
/*     */ 
/*  91 */     for (int i = 0; i < 16; pos += 4)
/*     */     {
/*  93 */       this.x[i] = 
/*  94 */         (src[pos] & 0xFF | (src[(pos + 1)] & 0xFF) << 8 | (src[(pos + 2)] & 0xFF) << 16 | 
/*  94 */         (src[(pos + 3)] & 0xFF) << 24);
/*     */ 
/*  91 */       i++;
/*     */     }
/*     */ 
/*  99 */     a = FF(a, b, c, d, this.x[0], 7, -680876936);
/* 100 */     d = FF(d, a, b, c, this.x[1], 12, -389564586);
/* 101 */     c = FF(c, d, a, b, this.x[2], 17, 606105819);
/* 102 */     b = FF(b, c, d, a, this.x[3], 22, -1044525330);
/* 103 */     a = FF(a, b, c, d, this.x[4], 7, -176418897);
/* 104 */     d = FF(d, a, b, c, this.x[5], 12, 1200080426);
/* 105 */     c = FF(c, d, a, b, this.x[6], 17, -1473231341);
/* 106 */     b = FF(b, c, d, a, this.x[7], 22, -45705983);
/* 107 */     a = FF(a, b, c, d, this.x[8], 7, 1770035416);
/* 108 */     d = FF(d, a, b, c, this.x[9], 12, -1958414417);
/* 109 */     c = FF(c, d, a, b, this.x[10], 17, -42063);
/* 110 */     b = FF(b, c, d, a, this.x[11], 22, -1990404162);
/* 111 */     a = FF(a, b, c, d, this.x[12], 7, 1804603682);
/* 112 */     d = FF(d, a, b, c, this.x[13], 12, -40341101);
/* 113 */     c = FF(c, d, a, b, this.x[14], 17, -1502002290);
/* 114 */     b = FF(b, c, d, a, this.x[15], 22, 1236535329);
/*     */ 
/* 117 */     a = GG(a, b, c, d, this.x[1], 5, -165796510);
/* 118 */     d = GG(d, a, b, c, this.x[6], 9, -1069501632);
/* 119 */     c = GG(c, d, a, b, this.x[11], 14, 643717713);
/* 120 */     b = GG(b, c, d, a, this.x[0], 20, -373897302);
/* 121 */     a = GG(a, b, c, d, this.x[5], 5, -701558691);
/* 122 */     d = GG(d, a, b, c, this.x[10], 9, 38016083);
/* 123 */     c = GG(c, d, a, b, this.x[15], 14, -660478335);
/* 124 */     b = GG(b, c, d, a, this.x[4], 20, -405537848);
/* 125 */     a = GG(a, b, c, d, this.x[9], 5, 568446438);
/* 126 */     d = GG(d, a, b, c, this.x[14], 9, -1019803690);
/* 127 */     c = GG(c, d, a, b, this.x[3], 14, -187363961);
/* 128 */     b = GG(b, c, d, a, this.x[8], 20, 1163531501);
/* 129 */     a = GG(a, b, c, d, this.x[13], 5, -1444681467);
/* 130 */     d = GG(d, a, b, c, this.x[2], 9, -51403784);
/* 131 */     c = GG(c, d, a, b, this.x[7], 14, 1735328473);
/* 132 */     b = GG(b, c, d, a, this.x[12], 20, -1926607734);
/*     */ 
/* 135 */     a = HH(a, b, c, d, this.x[5], 4, -378558);
/* 136 */     d = HH(d, a, b, c, this.x[8], 11, -2022574463);
/* 137 */     c = HH(c, d, a, b, this.x[11], 16, 1839030562);
/* 138 */     b = HH(b, c, d, a, this.x[14], 23, -35309556);
/* 139 */     a = HH(a, b, c, d, this.x[1], 4, -1530992060);
/* 140 */     d = HH(d, a, b, c, this.x[4], 11, 1272893353);
/* 141 */     c = HH(c, d, a, b, this.x[7], 16, -155497632);
/* 142 */     b = HH(b, c, d, a, this.x[10], 23, -1094730640);
/* 143 */     a = HH(a, b, c, d, this.x[13], 4, 681279174);
/* 144 */     d = HH(d, a, b, c, this.x[0], 11, -358537222);
/* 145 */     c = HH(c, d, a, b, this.x[3], 16, -722521979);
/* 146 */     b = HH(b, c, d, a, this.x[6], 23, 76029189);
/* 147 */     a = HH(a, b, c, d, this.x[9], 4, -640364487);
/* 148 */     d = HH(d, a, b, c, this.x[12], 11, -421815835);
/* 149 */     c = HH(c, d, a, b, this.x[15], 16, 530742520);
/* 150 */     b = HH(b, c, d, a, this.x[2], 23, -995338651);
/*     */ 
/* 153 */     a = II(a, b, c, d, this.x[0], 6, -198630844);
/* 154 */     d = II(d, a, b, c, this.x[7], 10, 1126891415);
/* 155 */     c = II(c, d, a, b, this.x[14], 15, -1416354905);
/* 156 */     b = II(b, c, d, a, this.x[5], 21, -57434055);
/* 157 */     a = II(a, b, c, d, this.x[12], 6, 1700485571);
/* 158 */     d = II(d, a, b, c, this.x[3], 10, -1894986606);
/* 159 */     c = II(c, d, a, b, this.x[10], 15, -1051523);
/* 160 */     b = II(b, c, d, a, this.x[1], 21, -2054922799);
/* 161 */     a = II(a, b, c, d, this.x[8], 6, 1873313359);
/* 162 */     d = II(d, a, b, c, this.x[15], 10, -30611744);
/* 163 */     c = II(c, d, a, b, this.x[6], 15, -1560198380);
/* 164 */     b = II(b, c, d, a, this.x[13], 21, 1309151649);
/* 165 */     a = II(a, b, c, d, this.x[4], 6, -145523070);
/* 166 */     d = II(d, a, b, c, this.x[11], 10, -1120210379);
/* 167 */     c = II(c, d, a, b, this.x[2], 15, 718787259);
/* 168 */     b = II(b, c, d, a, this.x[9], 21, -343485551);
/*     */ 
/* 170 */     this.state0 += a;
/* 171 */     this.state1 += b;
/* 172 */     this.state2 += c;
/* 173 */     this.state3 += d;
/*     */   }
/*     */ 
/*     */   public final void reset()
/*     */   {
/* 178 */     this.count = 0L;
/*     */ 
/* 180 */     this.state0 = 1732584193;
/* 181 */     this.state1 = -271733879;
/* 182 */     this.state2 = -1732584194;
/* 183 */     this.state3 = 271733878;
/*     */ 
/* 187 */     for (int i = 0; i < 16; i++)
/* 188 */       this.x[i] = 0;
/*     */   }
/*     */ 
/*     */   public final void update(byte b)
/*     */   {
/* 193 */     int space = 64 - (int)(this.count & 0x3F);
/*     */ 
/* 195 */     this.count += 1L;
/*     */ 
/* 197 */     this.block[(64 - space)] = b;
/*     */ 
/* 199 */     if (space == 1)
/* 200 */       transform(this.block, 0);
/*     */   }
/*     */ 
/*     */   public final void update(byte[] buff, int pos, int len)
/*     */   {
/* 205 */     int space = 64 - (int)(this.count & 0x3F);
/*     */ 
/* 207 */     this.count += len;
/*     */ 
/* 209 */     while (len > 0)
/*     */     {
/* 211 */       if (len < space)
/*     */       {
/* 213 */         System.arraycopy(buff, pos, this.block, 64 - space, len);
/* 214 */         break;
/*     */       }
/*     */ 
/* 217 */       if (space == 64)
/*     */       {
/* 219 */         transform(buff, pos);
/*     */       }
/*     */       else
/*     */       {
/* 223 */         System.arraycopy(buff, pos, this.block, 64 - space, space);
/* 224 */         transform(this.block, 0);
/*     */       }
/*     */ 
/* 227 */       pos += space;
/* 228 */       len -= space;
/* 229 */       space = 64;
/*     */     }
/*     */   }
/*     */ 
/*     */   public final void update(byte[] b)
/*     */   {
/* 235 */     update(b, 0, b.length);
/*     */   }
/*     */ 
/*     */   public final void digest(byte[] dst, int pos)
/*     */   {
/* 240 */     byte[] bits = new byte[8];
/*     */ 
/* 242 */     encode(bits, 0, (int)(this.count << 3));
/* 243 */     encode(bits, 4, (int)(this.count >> 29));
/*     */ 
/* 245 */     int idx = (int)this.count & 0x3F;
/* 246 */     int padLen = idx < 56 ? 56 - idx : 120 - idx;
/*     */ 
/* 248 */     update(padding, 0, padLen);
/* 249 */     update(bits, 0, 8);
/*     */ 
/* 251 */     encode(dst, pos, this.state0);
/* 252 */     encode(dst, pos + 4, this.state1);
/* 253 */     encode(dst, pos + 8, this.state2);
/* 254 */     encode(dst, pos + 12, this.state3);
/*     */ 
/* 256 */     reset();
/*     */   }
/*     */ 
/*     */   public final void digest(byte[] dst)
/*     */   {
/* 261 */     digest(dst, 0);
/*     */   }
/*     */ 
/*     */   public final int getDigestLength()
/*     */   {
/* 266 */     return 16;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.MD5
 * JD-Core Version:    0.6.0
 */