/*    */ package ch.ethz.ssh2.channel;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ public final class ChannelOutputStream extends OutputStream
/*    */ {
/*    */   Channel c;
/* 16 */   boolean isClosed = false;
/*    */ 
/*    */   ChannelOutputStream(Channel c)
/*    */   {
/* 20 */     this.c = c;
/*    */   }
/*    */ 
/*    */   public void write(int b) throws IOException
/*    */   {
/* 25 */     byte[] buff = new byte[1];
/*    */ 
/* 27 */     buff[0] = (byte)b;
/*    */ 
/* 29 */     write(buff, 0, 1);
/*    */   }
/*    */ 
/*    */   public void close() throws IOException
/*    */   {
/* 34 */     if (!this.isClosed)
/*    */     {
/* 36 */       this.isClosed = true;
/* 37 */       this.c.cm.sendEOF(this.c);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void flush() throws IOException
/*    */   {
/* 43 */     if (this.isClosed)
/* 44 */       throw new IOException("This OutputStream is closed.");
/*    */   }
/*    */ 
/*    */   public void write(byte[] b, int off, int len)
/*    */     throws IOException
/*    */   {
/* 51 */     if (this.isClosed) {
/* 52 */       throw new IOException("This OutputStream is closed.");
/*    */     }
/* 54 */     if (b == null) {
/* 55 */       throw new NullPointerException();
/*    */     }
/* 57 */     if ((off < 0) || (len < 0) || (off + len > b.length) || (off + len < 0) || (off > b.length)) {
/* 58 */       throw new IndexOutOfBoundsException();
/*    */     }
/* 60 */     if (len == 0) {
/* 61 */       return;
/*    */     }
/* 63 */     this.c.cm.sendData(this.c, b, off, len);
/*    */   }
/*    */ 
/*    */   public void write(byte[] b) throws IOException
/*    */   {
/* 68 */     write(b, 0, b.length);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.ChannelOutputStream
 * JD-Core Version:    0.6.0
 */