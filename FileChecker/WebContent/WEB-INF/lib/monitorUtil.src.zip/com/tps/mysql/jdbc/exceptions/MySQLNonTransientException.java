/*    */ package com.mysql.jdbc.exceptions;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public class MySQLNonTransientException extends SQLException
/*    */ {
/*    */   public MySQLNonTransientException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public MySQLNonTransientException(String reason, String SQLState, int vendorCode)
/*    */   {
/* 35 */     super(reason, SQLState, vendorCode);
/*    */   }
/*    */ 
/*    */   public MySQLNonTransientException(String reason, String SQLState) {
/* 39 */     super(reason, SQLState);
/*    */   }
/*    */ 
/*    */   public MySQLNonTransientException(String reason) {
/* 43 */     super(reason);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.exceptions.MySQLNonTransientException
 * JD-Core Version:    0.6.0
 */