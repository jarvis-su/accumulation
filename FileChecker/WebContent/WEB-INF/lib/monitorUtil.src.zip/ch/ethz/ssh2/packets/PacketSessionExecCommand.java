/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketSessionExecCommand
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public boolean wantReply;
/*    */   public String command;
/*    */ 
/*    */   public PacketSessionExecCommand(int recipientChannelID, boolean wantReply, String command)
/*    */   {
/* 20 */     this.recipientChannelID = recipientChannelID;
/* 21 */     this.wantReply = wantReply;
/* 22 */     this.command = command;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 27 */     if (this.payload == null)
/*    */     {
/* 29 */       TypesWriter tw = new TypesWriter();
/* 30 */       tw.writeByte(98);
/* 31 */       tw.writeUINT32(this.recipientChannelID);
/* 32 */       tw.writeString("exec");
/* 33 */       tw.writeBoolean(this.wantReply);
/* 34 */       tw.writeString(this.command);
/* 35 */       this.payload = tw.getBytes();
/*    */     }
/* 37 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketSessionExecCommand
 * JD-Core Version:    0.6.0
 */