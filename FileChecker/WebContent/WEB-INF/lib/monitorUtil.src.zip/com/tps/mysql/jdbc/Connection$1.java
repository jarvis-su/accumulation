/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.sql.SQLException;
/*      */ import java.util.Map.Entry;
/*      */ 
/*      */ class Connection$1 extends LRUCache
/*      */ {
/*      */   private final Connection this$0;
/*      */ 
/*      */   protected boolean removeEldestEntry(Map.Entry eldest)
/*      */   {
/* 2962 */     if (this.maxElements <= 1) {
/* 2963 */       return false;
/*      */     }
/*      */ 
/* 2966 */     boolean removeIt = super.removeEldestEntry(eldest);
/*      */ 
/* 2968 */     if (removeIt) {
/* 2969 */       ServerPreparedStatement ps = (ServerPreparedStatement)eldest.getValue();
/*      */ 
/* 2971 */       ps.isCached = false;
/* 2972 */       ps.setClosed(false);
/*      */       try
/*      */       {
/* 2975 */         ps.close();
/*      */       }
/*      */       catch (SQLException sqlEx)
/*      */       {
/*      */       }
/*      */     }
/* 2981 */     return removeIt;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Connection.1
 * JD-Core Version:    0.6.0
 */