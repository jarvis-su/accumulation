/*   */ package com.smj.dbvariable;
/*   */ 
/*   */  enum CopyOfDBVar$Status
/*   */ {
/* 8 */   NADA, DIRTY, RESOLVED;
/*   */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.CopyOfDBVar.Status
 * JD-Core Version:    0.6.0
 */