package com.ibm.wsdl.util.xml;

import com.ibm.wsdl.util.ObjectRegistry;
import com.ibm.wsdl.util.StringUtils;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Map;
import org.w3c.dom.Attr;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOM2Writer
{
  private static String NS_URI_XMLNS = "http://www.w3.org/2000/xmlns/";
  private static String NS_URI_XML = "http://www.w3.org/XML/1998/namespace";
  private static Map xmlEncodingMap = new HashMap();

  public static String nodeToString(Node paramNode)
  {
    StringWriter localStringWriter = new StringWriter();
    serializeAsXML(paramNode, localStringWriter);
    return localStringWriter.toString();
  }

  public static void serializeElementAsDocument(Element paramElement, Writer paramWriter)
  {
    PrintWriter localPrintWriter = new PrintWriter(paramWriter);
    String str1 = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    String str2 = java2XMLEncoding(str1);
    if (str2 != null)
      localPrintWriter.println("<?xml version=\"1.0\" encoding=\"" + str2 + "\"?>");
    else
      localPrintWriter.println("<?xml version=\"1.0\"?>");
    serializeAsXML(paramElement, paramWriter);
  }

  public static void serializeAsXML(Node paramNode, Writer paramWriter)
  {
    ObjectRegistry localObjectRegistry = new ObjectRegistry();
    localObjectRegistry.register("xml", NS_URI_XML);
    PrintWriter localPrintWriter = new PrintWriter(paramWriter);
    String str = (paramWriter instanceof OutputStreamWriter) ? ((OutputStreamWriter)paramWriter).getEncoding() : null;
    print(paramNode, localObjectRegistry, localPrintWriter, java2XMLEncoding(str));
  }

  private static void print(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter, String paramString)
  {
    if (paramNode == null)
      return;
    int i = 0;
    int j = paramNode.getNodeType();
    Object localObject;
    int k;
    int m;
    switch (j)
    {
    case 9:
      if (paramString != null)
        paramPrintWriter.println("<?xml version=\"1.0\" encoding=\"" + paramString + "\"?>");
      else
        paramPrintWriter.println("<?xml version=\"1.0\"?>");
      localObject = paramNode.getChildNodes();
      if (localObject == null)
        break;
      k = ((NodeList)localObject).getLength();
      m = 0;
    case 1:
    case 5:
    case 4:
    case 3:
    case 8:
    case 7:
      while (m < k)
      {
        print(((NodeList)localObject).item(m), paramObjectRegistry, paramPrintWriter, paramString);
        m++;
        continue;
        paramObjectRegistry = new ObjectRegistry(paramObjectRegistry);
        paramPrintWriter.print('<' + paramNode.getNodeName());
        localObject = paramNode.getPrefix();
        String str1 = paramNode.getNamespaceURI();
        if ((localObject != null) && (str1 != null))
        {
          m = 0;
          try
          {
            String str2 = (String)paramObjectRegistry.lookup((String)localObject);
            if (str1.equals(str2))
              m = 1;
          }
          catch (IllegalArgumentException localIllegalArgumentException1)
          {
          }
          if (m == 0)
            printNamespaceDecl(paramNode, paramObjectRegistry, paramPrintWriter);
        }
        NamedNodeMap localNamedNodeMap = paramNode.getAttributes();
        int n = localNamedNodeMap != null ? localNamedNodeMap.getLength() : 0;
        for (int i1 = 0; i1 < n; i1++)
        {
          Attr localAttr = (Attr)localNamedNodeMap.item(i1);
          paramPrintWriter.print(' ' + localAttr.getNodeName() + "=\"" + normalize(localAttr.getValue()) + '"');
          String str3 = localAttr.getPrefix();
          String str4 = localAttr.getNamespaceURI();
          if ((str3 == null) || (str4 == null))
            continue;
          int i4 = 0;
          try
          {
            String str5 = (String)paramObjectRegistry.lookup(str3);
            if (str4.equals(str5))
              i4 = 1;
          }
          catch (IllegalArgumentException localIllegalArgumentException2)
          {
          }
          if (i4 != 0)
            continue;
          printNamespaceDecl(localAttr, paramObjectRegistry, paramPrintWriter);
        }
        NodeList localNodeList = paramNode.getChildNodes();
        if (localNodeList != null)
        {
          int i2 = localNodeList.getLength();
          i = i2 > 0 ? 1 : 0;
          if (i != 0)
            paramPrintWriter.print('>');
          for (int i3 = 0; i3 < i2; i3++)
            print(localNodeList.item(i3), paramObjectRegistry, paramPrintWriter, paramString);
        }
        i = 0;
        if (i != 0)
          break;
        paramPrintWriter.print("/>");
        break;
        paramPrintWriter.print('&');
        paramPrintWriter.print(paramNode.getNodeName());
        paramPrintWriter.print(';');
        break;
        paramPrintWriter.print("<![CDATA[");
        paramPrintWriter.print(paramNode.getNodeValue());
        paramPrintWriter.print("]]>");
        break;
        paramPrintWriter.print(normalize(paramNode.getNodeValue()));
        break;
        paramPrintWriter.print("<!--");
        paramPrintWriter.print(paramNode.getNodeValue());
        paramPrintWriter.print("-->");
        break;
        paramPrintWriter.print("<?");
        paramPrintWriter.print(paramNode.getNodeName());
        localObject = paramNode.getNodeValue();
        if ((localObject != null) && (((String)localObject).length() > 0))
        {
          paramPrintWriter.print(' ');
          paramPrintWriter.print((String)localObject);
        }
        paramPrintWriter.println("?>");
      }
    case 2:
    case 6:
    }
    if ((j == 1) && (i == 1))
    {
      paramPrintWriter.print("</");
      paramPrintWriter.print(paramNode.getNodeName());
      paramPrintWriter.print('>');
      i = 0;
    }
  }

  public static String java2XMLEncoding(String paramString)
  {
    return (String)xmlEncodingMap.get(paramString);
  }

  private static void printNamespaceDecl(Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter)
  {
    switch (paramNode.getNodeType())
    {
    case 2:
      printNamespaceDecl(((Attr)paramNode).getOwnerElement(), paramNode, paramObjectRegistry, paramPrintWriter);
      break;
    case 1:
      printNamespaceDecl((Element)paramNode, paramNode, paramObjectRegistry, paramPrintWriter);
    }
  }

  private static void printNamespaceDecl(Element paramElement, Node paramNode, ObjectRegistry paramObjectRegistry, PrintWriter paramPrintWriter)
  {
    String str1 = paramNode.getNamespaceURI();
    String str2 = paramNode.getPrefix();
    if ((!str1.equals(NS_URI_XMLNS)) || (!str2.equals("xmlns")))
    {
      if (DOMUtils.getAttributeNS(paramElement, NS_URI_XMLNS, str2) == null)
        paramPrintWriter.print(" xmlns:" + str2 + "=\"" + str1 + '"');
    }
    else
    {
      str2 = paramNode.getLocalName();
      str1 = paramNode.getNodeValue();
    }
    paramObjectRegistry.register(str2, str1);
  }

  private static String normalize(String paramString)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = paramString != null ? paramString.length() : 0;
    for (int j = 0; j < i; j++)
    {
      char c = paramString.charAt(j);
      switch (c)
      {
      case '<':
        localStringBuffer.append("&lt;");
        break;
      case '>':
        localStringBuffer.append("&gt;");
        break;
      case '&':
        localStringBuffer.append("&amp;");
        break;
      case '"':
        localStringBuffer.append("&quot;");
        break;
      case '\n':
        if (j > 0)
        {
          int k = localStringBuffer.charAt(localStringBuffer.length() - 1);
          if (k != 13)
            localStringBuffer.append(StringUtils.lineSeparator);
          else
            localStringBuffer.append('\n');
        }
        else
        {
          localStringBuffer.append(StringUtils.lineSeparator);
        }
        break;
      default:
        localStringBuffer.append(c);
      }
    }
    return localStringBuffer.toString();
  }

  static
  {
    xmlEncodingMap.put(null, "UTF-8");
    xmlEncodingMap.put(System.getProperty("file.encoding"), "UTF-8");
    xmlEncodingMap.put("UTF8", "UTF-8");
    xmlEncodingMap.put("UTF-16", "UTF-16");
    xmlEncodingMap.put("UnicodeBig", "UTF-16");
    xmlEncodingMap.put("UnicodeLittle", "UTF-16");
    xmlEncodingMap.put("ASCII", "US-ASCII");
    xmlEncodingMap.put("ISO8859_1", "ISO-8859-1");
    xmlEncodingMap.put("ISO8859_2", "ISO-8859-2");
    xmlEncodingMap.put("ISO8859_3", "ISO-8859-3");
    xmlEncodingMap.put("ISO8859_4", "ISO-8859-4");
    xmlEncodingMap.put("ISO8859_5", "ISO-8859-5");
    xmlEncodingMap.put("ISO8859_6", "ISO-8859-6");
    xmlEncodingMap.put("ISO8859_7", "ISO-8859-7");
    xmlEncodingMap.put("ISO8859_8", "ISO-8859-8");
    xmlEncodingMap.put("ISO8859_9", "ISO-8859-9");
    xmlEncodingMap.put("ISO8859_13", "ISO-8859-13");
    xmlEncodingMap.put("ISO8859_15_FDIS", "ISO-8859-15");
    xmlEncodingMap.put("GBK", "GBK");
    xmlEncodingMap.put("Big5", "Big5");
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.xml.DOM2Writer
 * JD-Core Version:    0.6.0
 */