/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.TimerTask;
/*     */ 
/*     */ class Statement$CancelTask extends TimerTask
/*     */ {
/*     */   long connectionId;
/*     */   private final Statement this$0;
/*     */ 
/*     */   Statement$CancelTask(Statement this$0)
/*     */     throws SQLException
/*     */   {
/*  89 */     this.this$0 = this$0;
/*     */ 
/*  87 */     this.connectionId = 0L;
/*     */ 
/*  90 */     this.connectionId = this$0.connection.getIO().getThreadId();
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  95 */     Thread cancelThread = new Statement.1(this);
/*     */ 
/* 128 */     cancelThread.start();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Statement.CancelTask
 * JD-Core Version:    0.6.0
 */