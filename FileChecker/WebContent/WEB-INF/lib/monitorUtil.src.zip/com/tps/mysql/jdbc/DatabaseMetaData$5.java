/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.StringTokenizer;
/*      */ 
/*      */ class DatabaseMetaData$5 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final String val$table;
/*      */   private final Statement val$stmt;
/*      */   private final ArrayList val$rows;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 2882 */     ResultSet fkresults = null;
/*      */     try
/*      */     {
/* 2889 */       if (this.this$0.conn.versionMeetsMinimum(3, 23, 50))
/*      */       {
/* 2892 */         fkresults = this.this$0.extractForeignKeyFromCreateTable(catalogStr.toString(), this.val$table);
/*      */       }
/*      */       else {
/* 2895 */         StringBuffer queryBuf = new StringBuffer("SHOW TABLE STATUS ");
/*      */ 
/* 2897 */         queryBuf.append(" FROM ");
/* 2898 */         queryBuf.append(this.this$0.quotedId);
/* 2899 */         queryBuf.append(catalogStr.toString());
/* 2900 */         queryBuf.append(this.this$0.quotedId);
/* 2901 */         queryBuf.append(" LIKE '");
/* 2902 */         queryBuf.append(this.val$table);
/* 2903 */         queryBuf.append("'");
/*      */ 
/* 2905 */         fkresults = this.val$stmt.executeQuery(queryBuf.toString());
/*      */       }
/*      */ 
/* 2913 */       while (fkresults.next()) {
/* 2914 */         String tableType = fkresults.getString("Type");
/*      */ 
/* 2916 */         if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
/*      */         {
/* 2920 */           String comment = fkresults.getString("Comment").trim();
/*      */ 
/* 2923 */           if (comment != null) {
/* 2924 */             StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
/*      */ 
/* 2927 */             if (commentTokens.hasMoreTokens()) {
/* 2928 */               commentTokens.nextToken();
/*      */ 
/* 2933 */               while (commentTokens.hasMoreTokens()) {
/* 2934 */                 String keys = commentTokens.nextToken();
/*      */ 
/* 2936 */                 DatabaseMetaData.access$600(this.this$0, catalogStr.toString(), this.val$table, keys, this.val$rows);
/*      */               }
/*      */             }
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 2945 */       if (fkresults != null) {
/*      */         try {
/* 2947 */           fkresults.close();
/*      */         } catch (SQLException sqlEx) {
/* 2949 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */ 
/* 2953 */         fkresults = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.5
 * JD-Core Version:    0.6.0
 */