/*     */ package com.mysql.jdbc.integration.jboss;
/*     */ 
/*     */ import com.mysql.jdbc.SQLError;
/*     */ import com.mysql.jdbc.jdbc2.optional.ConnectionWrapper;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Method;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Statement;
/*     */ import org.jboss.resource.adapter.jdbc.ValidConnectionChecker;
/*     */ 
/*     */ public final class MysqlValidConnectionChecker
/*     */   implements ValidConnectionChecker, Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 3258689922776119348L;
/*     */   private Method pingMethod;
/*     */   private Method pingMethodWrapped;
/*  50 */   private static final Object[] NO_ARGS_OBJECT_ARRAY = new Object[0];
/*     */ 
/*     */   public MysqlValidConnectionChecker()
/*     */   {
/*     */     try {
/*  55 */       Class mysqlConnection = Thread.currentThread().getContextClassLoader().loadClass("com.mysql.jdbc.Connection");
/*     */ 
/*  59 */       this.pingMethod = mysqlConnection.getMethod("ping", null);
/*     */ 
/*  61 */       Class mysqlConnectionWrapper = Thread.currentThread().getContextClassLoader().loadClass("com.mysql.jdbc.jdbc2.optional.ConnectionWrapper");
/*     */ 
/*  65 */       this.pingMethodWrapped = mysqlConnectionWrapper.getMethod("ping", null);
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public SQLException isValidConnection(java.sql.Connection conn)
/*     */   {
/*  77 */     if ((conn instanceof com.mysql.jdbc.Connection)) {
/*  78 */       if (this.pingMethod == null) break label134; try {
/*  80 */         this.pingMethod.invoke(conn, NO_ARGS_OBJECT_ARRAY);
/*     */ 
/*  82 */         return null;
/*     */       } catch (Exception ex) {
/*  84 */         if ((ex instanceof SQLException)) {
/*  85 */           return (SQLException)ex;
/*     */         }
/*     */ 
/*  88 */         return SQLError.createSQLException("Ping failed: " + ex.toString());
/*     */       }
/*     */     }
/*  91 */     if (((conn instanceof ConnectionWrapper)) && 
/*  92 */       (this.pingMethodWrapped != null)) {
/*     */       try {
/*  94 */         this.pingMethodWrapped.invoke(conn, NO_ARGS_OBJECT_ARRAY);
/*     */ 
/*  96 */         return null;
/*     */       } catch (Exception ex) {
/*  98 */         if ((ex instanceof SQLException)) {
/*  99 */           return (SQLException)ex;
/*     */         }
/*     */ 
/* 102 */         return SQLError.createSQLException("Ping failed: " + ex.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 109 */     label134: Statement pingStatement = null;
/*     */     try
/*     */     {
/* 112 */       pingStatement.executeQuery("SELECT 1").close();
/*     */ 
/* 114 */       localObject1 = null;
/*     */     }
/*     */     catch (SQLException sqlEx)
/*     */     {
/*     */       Object localObject1;
/* 116 */       return sqlEx;
/*     */     } finally {
/* 118 */       if (pingStatement != null)
/*     */         try {
/* 120 */           pingStatement.close();
/*     */         }
/*     */         catch (SQLException sqlEx)
/*     */         {
/*     */         }
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.integration.jboss.MysqlValidConnectionChecker
 * JD-Core Version:    0.6.0
 */