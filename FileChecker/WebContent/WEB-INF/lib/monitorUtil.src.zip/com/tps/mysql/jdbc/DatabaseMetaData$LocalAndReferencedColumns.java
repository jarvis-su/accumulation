/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ class DatabaseMetaData$LocalAndReferencedColumns
/*     */ {
/*     */   String constraintName;
/*     */   List localColumnsList;
/*     */   String referencedCatalog;
/*     */   List referencedColumnsList;
/*     */   String referencedTable;
/*     */   private final DatabaseMetaData this$0;
/*     */ 
/*     */   DatabaseMetaData$LocalAndReferencedColumns(DatabaseMetaData this$0, List localColumns, List refColumns, String constName, String refCatalog, String refTable)
/*     */   {
/* 106 */     this.this$0 = this$0;
/* 107 */     this.localColumnsList = localColumns;
/* 108 */     this.referencedColumnsList = refColumns;
/* 109 */     this.constraintName = constName;
/* 110 */     this.referencedTable = refTable;
/* 111 */     this.referencedCatalog = refCatalog;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.LocalAndReferencedColumns
 * JD-Core Version:    0.6.0
 */