package com.ibm.wsdl.extensions.mime;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import com.ibm.wsdl.util.xml.XPathUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.mime.MIMEMultipartRelated;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class MIMEMultipartRelatedSerializer
  implements ExtensionSerializer, ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    MIMEMultipartRelated localMIMEMultipartRelated = (MIMEMultipartRelated)paramExtensibilityElement;
    if (localMIMEMultipartRelated != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/mime/", "multipartRelated", paramDefinition);
      if ((paramClass != null) && (MIMEPart.class.isAssignableFrom(paramClass)))
        paramPrintWriter.print("    ");
      paramPrintWriter.print("        <" + str);
      Boolean localBoolean = localMIMEMultipartRelated.getRequired();
      if (localBoolean != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println('>');
      printMIMEParts(localMIMEMultipartRelated.getMIMEParts(), paramPrintWriter, paramDefinition, paramExtensionRegistry);
      if ((paramClass != null) && (MIMEPart.class.isAssignableFrom(paramClass)))
        paramPrintWriter.print("    ");
      paramPrintWriter.println("        </" + str + '>');
    }
  }

  private void printMIMEParts(List paramList, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    if (paramList != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/mime/", "part", paramDefinition);
      Iterator localIterator1 = paramList.iterator();
      while (localIterator1.hasNext())
      {
        MIMEPart localMIMEPart = (MIMEPart)localIterator1.next();
        if (localMIMEPart == null)
          continue;
        paramPrintWriter.print("          <" + str);
        Boolean localBoolean = localMIMEPart.getRequired();
        if (localBoolean != null)
          DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
        paramPrintWriter.println('>');
        List localList = localMIMEPart.getExtensibilityElements();
        if (localList != null)
        {
          Iterator localIterator2 = localList.iterator();
          while (localIterator2.hasNext())
          {
            ExtensibilityElement localExtensibilityElement = (ExtensibilityElement)localIterator2.next();
            QName localQName = localExtensibilityElement.getElementType();
            ExtensionSerializer localExtensionSerializer = paramExtensionRegistry.querySerializer(MIMEPart.class, localQName);
            localExtensionSerializer.marshall(MIMEPart.class, localQName, localExtensibilityElement, paramPrintWriter, paramDefinition, paramExtensionRegistry);
          }
        }
        paramPrintWriter.println("          </" + str + '>');
      }
    }
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    MIMEMultipartRelated localMIMEMultipartRelated = (MIMEMultipartRelated)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      if (QNameUtils.matches(MIMEConstants.Q_ELEM_MIME_PART, localElement))
        localMIMEMultipartRelated.addMIMEPart(parseMIMEPart(MIMEMultipartRelated.class, MIMEConstants.Q_ELEM_MIME_PART, localElement, paramDefinition, paramExtensionRegistry));
      else
        DOMUtils.throwWSDLException(localElement);
    if (str != null)
      localMIMEMultipartRelated.setRequired(new Boolean(str));
    return localMIMEMultipartRelated;
  }

  private MIMEPart parseMIMEPart(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    MIMEPart localMIMEPart = (MIMEPart)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str != null)
      localMIMEPart.setRequired(new Boolean(str));
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
      try
      {
        QName localQName = QNameUtils.newQName(localElement);
        ExtensionDeserializer localExtensionDeserializer = paramExtensionRegistry.queryDeserializer(MIMEPart.class, localQName);
        ExtensibilityElement localExtensibilityElement = localExtensionDeserializer.unmarshall(MIMEPart.class, localQName, localElement, paramDefinition, paramExtensionRegistry);
        localMIMEPart.addExtensibilityElement(localExtensibilityElement);
      }
      catch (WSDLException localWSDLException)
      {
        if (localWSDLException.getLocation() == null)
          localWSDLException.setLocation(XPathUtils.getXPathExprFromNode(localElement));
        throw localWSDLException;
      }
    return localMIMEPart;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.extensions.mime.MIMEMultipartRelatedSerializer
 * JD-Core Version:    0.6.0
 */