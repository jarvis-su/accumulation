/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.util.Vector;
/*    */ 
/*    */ public abstract class CopyOfDBVar
/*    */ {
/*  6 */   private String _initialVal = null;
/*  7 */   private Vector<String> _values = new Vector();
/*    */ 
/*  9 */   private Status _status = Status.NADA;
/*    */ 
/*    */   public CopyOfDBVar() {
/* 12 */     this(null);
/*    */   }
/*    */ 
/*    */   public CopyOfDBVar(String s) {
/* 16 */     setInitialValue(s);
/*    */   }
/*    */ 
/*    */   public final void setInitialValue(String val) {
/* 20 */     this._initialVal = val;
/*    */   }
/*    */ 
/*    */   public final String getInitialValue() {
/* 24 */     return this._initialVal;
/*    */   }
/*    */ 
/*    */   public final boolean isResolved() {
/* 28 */     return this._status == Status.RESOLVED;
/*    */   }
/*    */ 
/*    */   public final boolean isDirty() {
/* 32 */     return this._status == Status.DIRTY;
/*    */   }
/*    */ 
/*    */   public final Vector<String> getValues() {
/* 36 */     return this._values;
/*    */   }
/*    */ 
/*    */   protected final void addValue(String val) {
/* 40 */     this._values.add(val);
/*    */   }
/*    */ 
/*    */   protected final void deleteValue(String val) {
/* 44 */     this._values.remove(val);
/*    */   }
/*    */ 
/*    */   protected final void updateValue(int loc, String val) {
/* 48 */     this._values.set(loc, val);
/*    */   }
/*    */ 
/*    */   public final Vector<String> resolve(VarCache c) throws Exception {
/* 52 */     this._status = Status.DIRTY;
/* 53 */     Vector ret = resolveInternal(c);
/* 54 */     this._status = Status.RESOLVED;
/* 55 */     return ret;
/*    */   }
/*    */ 
/*    */   protected abstract Vector<String> resolveInternal(VarCache paramVarCache)
/*    */     throws Exception;
/*    */ 
/*    */   private static enum Status
/*    */   {
/*  8 */     NADA, DIRTY, RESOLVED;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.smj.dbvariable.CopyOfDBVar
 * JD-Core Version:    0.6.0
 */