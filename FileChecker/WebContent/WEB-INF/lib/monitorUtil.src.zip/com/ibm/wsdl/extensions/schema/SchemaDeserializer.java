package com.ibm.wsdl.extensions.schema;

import com.ibm.wsdl.util.xml.DOMUtils;
import com.ibm.wsdl.util.xml.QNameUtils;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.schema.Schema;
import javax.wsdl.extensions.schema.SchemaImport;
import javax.wsdl.extensions.schema.SchemaReference;
import javax.wsdl.xml.WSDLLocator;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SchemaDeserializer
  implements ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;
  private final Map allReferencedSchemas = new Hashtable();
  private static ThreadLocal wsdlLocator = new ThreadLocal();

  public static void setLocator(WSDLLocator paramWSDLLocator)
  {
    wsdlLocator.set(paramWSDLLocator);
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    Schema localSchema = (Schema)paramExtensionRegistry.createExtension(paramClass, paramQName);
    localSchema.setElementType(paramQName);
    localSchema.setElement(paramElement);
    localSchema.setDocumentBaseURI(paramDefinition.getDocumentBaseURI());
    for (Element localElement = DOMUtils.getFirstChildElement(paramElement); localElement != null; localElement = DOMUtils.getNextSiblingElement(localElement))
    {
      QName localQName = QNameUtils.newQName(localElement);
      SchemaReference localSchemaReference = null;
      String str = null;
      if (SchemaConstants.XSD_IMPORT_QNAME_LIST.contains(localQName))
      {
        SchemaImport localSchemaImport = localSchema.createImport();
        localSchemaImport.setId(DOMUtils.getAttribute(localElement, "id"));
        localSchemaImport.setNamespaceURI(DOMUtils.getAttribute(localElement, "namespace"));
        str = DOMUtils.getAttribute(localElement, "schemaLocation");
        localSchemaImport.setSchemaLocationURI(str);
        localSchema.addImport(localSchemaImport);
      }
      else if (SchemaConstants.XSD_INCLUDE_QNAME_LIST.contains(localQName))
      {
        localSchemaReference = localSchema.createInclude();
        localSchemaReference.setId(DOMUtils.getAttribute(localElement, "id"));
        str = DOMUtils.getAttribute(localElement, "schemaLocation");
        localSchemaReference.setSchemaLocationURI(str);
        localSchema.addInclude(localSchemaReference);
      }
      else
      {
        if (!SchemaConstants.XSD_REDEFINE_QNAME_LIST.contains(localQName))
          continue;
        localSchemaReference = localSchema.createRedefine();
        localSchemaReference.setId(DOMUtils.getAttribute(localElement, "id"));
        str = DOMUtils.getAttribute(localElement, "schemaLocation");
        localSchemaReference.setSchemaLocationURI(str);
        localSchema.addRedefine(localSchemaReference);
      }
    }
    return localSchema;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.schema.SchemaDeserializer
 * JD-Core Version:    0.6.0
 */