/*    */ package com.acs.fileChecker.incoming;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.util.Properties;
/*    */ import javax.mail.Message.RecipientType;
/*    */ import javax.mail.MessagingException;
/*    */ import javax.mail.Session;
/*    */ import javax.mail.Transport;
/*    */ import javax.mail.internet.InternetAddress;
/*    */ import javax.mail.internet.MimeMessage;
/*    */ 
/*    */ public class Jmail
/*    */ {
/* 15 */   protected String _propertyPath = "./config/com/tps/config";
/*    */ 
/*    */   protected static String format(int i, String pattern)
/*    */   {
/* 31 */     String strI = Integer.toString(i);
/* 32 */     StringBuffer sb = new StringBuffer();
/* 33 */     for (int cnt = 0; cnt < pattern.length() - strI.length(); cnt++)
/*    */     {
/* 35 */       sb.append(pattern.substring(cnt, cnt + 1));
/*    */     }
/* 37 */     sb.append(strI);
/* 38 */     return sb.toString();
/*    */   }
/*    */ 
/*    */   public void sendMail(String sub, String msg)
/*    */   {
/* 43 */     Properties props = new Properties();
/* 44 */     FileInputStream in = null;
/* 45 */     int tonum = 0;
/*    */     try {
/* 47 */       in = new FileInputStream(this._propertyPath + "/" + "jmail.properties");
/* 48 */       props.load(in);
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 52 */       e.printStackTrace();
/*    */     }
/* 54 */     Session s = Session.getInstance(props, null);
/*    */ 
/* 56 */     InternetAddress from = null;
/* 57 */     InternetAddress to = null;
/* 58 */     MimeMessage message = new MimeMessage(s);
/*    */     try
/*    */     {
/* 61 */       String top = props.getProperty("mail.msg.top");
/* 62 */       from = new InternetAddress(props.getProperty("mail.from"));
/* 63 */       message.setFrom(from);
/* 64 */       tonum = Integer.parseInt(props.getProperty("mail.to.num"));
/* 65 */       for (int i = 0; i < tonum; i++)
/*    */       {
/* 67 */         to = new InternetAddress(props.getProperty("mail." + format(i, "000") + ".to"));
/* 68 */         message.addRecipient(Message.RecipientType.TO, to);
/*    */       }
/* 70 */       message.setSubject(sub);
/* 71 */       message.setText(top + msg);
/* 72 */       Transport.send(message);
/*    */     }
/*    */     catch (MessagingException me)
/*    */     {
/* 80 */       me.printStackTrace();
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.incoming.Jmail
 * JD-Core Version:    0.6.0
 */