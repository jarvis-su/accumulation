package ch.ethz.ssh2.sftp;

public class AttrTextHints
{
  public static final int SSH_FILEXFER_ATTR_KNOWN_TEXT = 0;
  public static final int SSH_FILEXFER_ATTR_GUESSED_TEXT = 1;
  public static final int SSH_FILEXFER_ATTR_KNOWN_BINARY = 2;
  public static final int SSH_FILEXFER_ATTR_GUESSED_BINARY = 3;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.sftp.AttrTextHints
 * JD-Core Version:    0.6.0
 */