/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketServiceAccept
/*    */ {
/*    */   byte[] payload;
/*    */   String serviceName;
/*    */ 
/*    */   public PacketServiceAccept(String serviceName)
/*    */   {
/* 19 */     this.serviceName = serviceName;
/*    */   }
/*    */ 
/*    */   public PacketServiceAccept(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 24 */     this.payload = new byte[len];
/* 25 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 27 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 29 */     int packet_type = tr.readByte();
/*    */ 
/* 31 */     if (packet_type != 6) {
/* 32 */       throw new IOException("This is not a SSH_MSG_SERVICE_ACCEPT! (" + 
/* 33 */         packet_type + ")");
/*    */     }
/* 35 */     this.serviceName = tr.readString();
/*    */ 
/* 37 */     if (tr.remain() != 0)
/* 38 */       throw new IOException("Padding in SSH_MSG_SERVICE_ACCEPT packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 43 */     if (this.payload == null)
/*    */     {
/* 45 */       TypesWriter tw = new TypesWriter();
/* 46 */       tw.writeByte(6);
/* 47 */       tw.writeString(this.serviceName);
/* 48 */       this.payload = tw.getBytes();
/*    */     }
/* 50 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketServiceAccept
 * JD-Core Version:    0.6.0
 */