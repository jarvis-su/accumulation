/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.log.Log;
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.util.ReadAheadInputStream;
/*      */ import com.mysql.jdbc.util.ResultSetUtil;
/*      */ import java.io.BufferedInputStream;
/*      */ import java.io.BufferedOutputStream;
/*      */ import java.io.ByteArrayOutputStream;
/*      */ import java.io.EOFException;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStreamWriter;
/*      */ import java.lang.ref.SoftReference;
/*      */ import java.math.BigInteger;
/*      */ import java.net.MalformedURLException;
/*      */ import java.net.Socket;
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.security.NoSuchAlgorithmException;
/*      */ import java.sql.SQLException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Properties;
/*      */ import java.util.zip.Deflater;
/*      */ 
/*      */ class MysqlIO
/*      */ {
/*      */   protected static final int NULL_LENGTH = -1;
/*      */   protected static final int COMP_HEADER_LENGTH = 3;
/*      */   protected static final int MIN_COMPRESS_LEN = 50;
/*      */   protected static final int HEADER_LENGTH = 4;
/*   79 */   private static int maxBufferSize = 65535;
/*      */   private static final int CLIENT_COMPRESS = 32;
/*      */   protected static final int CLIENT_CONNECT_WITH_DB = 8;
/*      */   private static final int CLIENT_FOUND_ROWS = 2;
/*      */   private static final int CLIENT_LOCAL_FILES = 128;
/*      */   private static final int CLIENT_LONG_FLAG = 4;
/*      */   private static final int CLIENT_LONG_PASSWORD = 1;
/*      */   private static final int CLIENT_PROTOCOL_41 = 512;
/*      */   private static final int CLIENT_INTERACTIVE = 1024;
/*      */   protected static final int CLIENT_SSL = 2048;
/*      */   private static final int CLIENT_TRANSACTIONS = 8192;
/*      */   protected static final int CLIENT_RESERVED = 16384;
/*      */   protected static final int CLIENT_SECURE_CONNECTION = 32768;
/*      */   private static final int CLIENT_MULTI_QUERIES = 65536;
/*      */   private static final int CLIENT_MULTI_RESULTS = 131072;
/*      */   private static final int SERVER_STATUS_IN_TRANS = 1;
/*      */   private static final int SERVER_STATUS_AUTOCOMMIT = 2;
/*      */   private static final int SERVER_MORE_RESULTS_EXISTS = 8;
/*      */   private static final int SERVER_QUERY_NO_GOOD_INDEX_USED = 16;
/*      */   private static final int SERVER_QUERY_NO_INDEX_USED = 32;
/*      */   private static final int SERVER_STATUS_CURSOR_EXISTS = 64;
/*      */   private static final String FALSE_SCRAMBLE = "xxxxxxxx";
/*      */   protected static final int MAX_QUERY_SIZE_TO_LOG = 1024;
/*      */   protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
/*  114 */   private static String jvmPlatformCharset = null;
/*      */ 
/*  119 */   private boolean binaryResultsAreUnpacked = true;
/*      */   protected static final String ZERO_DATE_VALUE_MARKER = "0000-00-00";
/*      */   protected static final String ZERO_DATETIME_VALUE_MARKER = "0000-00-00 00:00:00";
/*      */   private static final int MAX_PACKET_DUMP_LENGTH = 1024;
/*  152 */   private boolean packetSequenceReset = false;
/*      */   protected int serverCharsetIndex;
/*  160 */   private Buffer reusablePacket = null;
/*  161 */   private Buffer sendPacket = null;
/*  162 */   private Buffer sharedSendPacket = null;
/*      */ 
/*  165 */   protected BufferedOutputStream mysqlOutput = null;
/*      */   protected Connection connection;
/*  167 */   private Deflater deflater = null;
/*  168 */   protected InputStream mysqlInput = null;
/*  169 */   private LinkedList packetDebugRingBuffer = null;
/*  170 */   private RowData streamingData = null;
/*      */ 
/*  173 */   protected Socket mysqlConnection = null;
/*  174 */   private SocketFactory socketFactory = null;
/*      */   private SoftReference loadFileBufRef;
/*      */   private SoftReference splitBufRef;
/*  190 */   protected String host = null;
/*      */   protected String seed;
/*  192 */   private String serverVersion = null;
/*  193 */   private String socketFactoryClassName = null;
/*  194 */   private byte[] packetHeaderBuf = new byte[4];
/*  195 */   private boolean colDecimalNeedsBump = false;
/*  196 */   private boolean hadWarnings = false;
/*  197 */   private boolean has41NewNewProt = false;
/*      */ 
/*  200 */   private boolean hasLongColumnInfo = false;
/*  201 */   private boolean isInteractiveClient = false;
/*  202 */   private boolean logSlowQueries = false;
/*      */ 
/*  208 */   private boolean platformDbCharsetMatches = true;
/*  209 */   private boolean profileSql = false;
/*  210 */   private boolean queryBadIndexUsed = false;
/*  211 */   private boolean queryNoIndexUsed = false;
/*      */ 
/*  214 */   private boolean use41Extensions = false;
/*  215 */   private boolean useCompression = false;
/*  216 */   private boolean useNewLargePackets = false;
/*  217 */   private boolean useNewUpdateCounts = false;
/*  218 */   private byte packetSequence = 0;
/*  219 */   private byte readPacketSequence = -1;
/*  220 */   private boolean checkPacketSequence = false;
/*  221 */   byte protocolVersion = 0;
/*  222 */   private int maxAllowedPacket = 1048576;
/*  223 */   protected int maxThreeBytes = 16581375;
/*  224 */   protected int port = 3306;
/*      */   protected int serverCapabilities;
/*  226 */   private int serverMajorVersion = 0;
/*  227 */   private int serverMinorVersion = 0;
/*  228 */   private int serverStatus = 0;
/*  229 */   private int serverSubMinorVersion = 0;
/*  230 */   private int warningCount = 0;
/*  231 */   protected long clientParam = 0L;
/*  232 */   protected long lastPacketSentTimeMs = 0L;
/*  233 */   private boolean traceProtocol = false;
/*  234 */   private boolean enablePacketDebug = false;
/*      */   private ByteBuffer channelClearBuf;
/*      */   private Calendar sessionCalendar;
/*      */   private boolean useConnectWithDb;
/*      */   private boolean needToGrabQueryFromPacket;
/*      */   private boolean autoGenerateTestcaseScript;
/*      */   private long threadId;
/*      */ 
/*      */   public MysqlIO(String host, int port, Properties props, String socketFactoryClassName, Connection conn, int socketTimeout)
/*      */     throws IOException, SQLException
/*      */   {
/*  259 */     this.connection = conn;
/*      */ 
/*  261 */     if (this.connection.getEnablePacketDebug()) {
/*  262 */       this.packetDebugRingBuffer = new LinkedList();
/*      */     }
/*      */ 
/*  265 */     this.logSlowQueries = this.connection.getLogSlowQueries();
/*      */ 
/*  267 */     this.reusablePacket = new Buffer(this.connection.getNetBufferLength());
/*      */ 
/*  270 */     this.port = port;
/*  271 */     this.host = host;
/*      */ 
/*  273 */     this.socketFactoryClassName = socketFactoryClassName;
/*  274 */     this.socketFactory = createSocketFactory();
/*      */ 
/*  276 */     this.mysqlConnection = this.socketFactory.connect(this.host, this.port, props);
/*      */ 
/*  279 */     if (socketTimeout != 0) {
/*      */       try {
/*  281 */         this.mysqlConnection.setSoTimeout(socketTimeout);
/*      */       }
/*      */       catch (Exception ex)
/*      */       {
/*      */       }
/*      */     }
/*      */ 
/*  288 */     this.mysqlConnection = this.socketFactory.beforeHandshake();
/*      */ 
/*  290 */     if (this.connection.getUseReadAheadInput()) {
/*  291 */       this.mysqlInput = new ReadAheadInputStream(this.mysqlConnection.getInputStream(), 16384, this.connection.getTraceProtocol(), this.connection.getLog());
/*      */     }
/*  294 */     else if (this.connection.useUnbufferedInput())
/*  295 */       this.mysqlInput = this.mysqlConnection.getInputStream();
/*      */     else {
/*  297 */       this.mysqlInput = new BufferedInputStream(this.mysqlConnection.getInputStream(), 16384);
/*      */     }
/*      */ 
/*  301 */     this.mysqlOutput = new BufferedOutputStream(this.mysqlConnection.getOutputStream(), 16384);
/*      */ 
/*  305 */     this.isInteractiveClient = this.connection.getInteractiveClient();
/*  306 */     this.profileSql = this.connection.getProfileSql();
/*  307 */     this.sessionCalendar = Calendar.getInstance();
/*  308 */     this.autoGenerateTestcaseScript = this.connection.getAutoGenerateTestcaseScript();
/*      */ 
/*  310 */     this.needToGrabQueryFromPacket = ((this.profileSql) || (this.logSlowQueries) || (this.autoGenerateTestcaseScript));
/*      */   }
/*      */ 
/*      */   public boolean hasLongColumnInfo()
/*      */   {
/*  321 */     return this.hasLongColumnInfo;
/*      */   }
/*      */ 
/*      */   protected boolean isDataAvailable() throws SQLException {
/*      */     try {
/*  326 */       return this.mysqlInput.available() > 0; } catch (IOException ioEx) {
/*      */     }
/*  328 */     throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ioEx);
/*      */   }
/*      */ 
/*      */   protected long getLastPacketSentTimeMs()
/*      */   {
/*  339 */     return this.lastPacketSentTimeMs;
/*      */   }
/*      */ 
/*      */   protected ResultSet getResultSet(Statement callingStatement, long columnCount, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean isBinaryEncoded, boolean unpackFieldInfo)
/*      */     throws SQLException
/*      */   {
/*  369 */     Field[] fields = null;
/*      */ 
/*  371 */     if (unpackFieldInfo) {
/*  372 */       fields = new Field[(int)columnCount];
/*      */     }
/*      */ 
/*  376 */     for (int i = 0; i < columnCount; i++) {
/*  377 */       Buffer fieldPacket = null;
/*      */ 
/*  379 */       fieldPacket = readPacket();
/*      */ 
/*  381 */       if (unpackFieldInfo) {
/*  382 */         fields[i] = unpackField(fieldPacket, false);
/*      */       }
/*      */     }
/*      */ 
/*  386 */     Buffer packet = reuseAndReadPacket(this.reusablePacket);
/*      */ 
/*  388 */     readServerStatusForResultSets(packet);
/*      */ 
/*  394 */     if ((this.connection.versionMeetsMinimum(5, 0, 2)) && (isBinaryEncoded) && (callingStatement != null) && (callingStatement.getFetchSize() != 0) && (callingStatement.getResultSetType() == 1003))
/*      */     {
/*  399 */       ServerPreparedStatement prepStmt = (ServerPreparedStatement)callingStatement;
/*      */ 
/*  401 */       Field[] fieldMetadata = ((ResultSetMetaData)prepStmt.getMetaData()).fields;
/*      */ 
/*  403 */       boolean usingCursor = true;
/*      */ 
/*  411 */       if (this.connection.versionMeetsMinimum(5, 0, 5)) {
/*  412 */         usingCursor = (this.serverStatus & 0x40) != 0;
/*      */       }
/*      */ 
/*  416 */       if (usingCursor) {
/*  417 */         RowData rows = new CursorRowProvider(this, prepStmt, ((ResultSetMetaData)prepStmt.getMetaData()).fields);
/*      */ 
/*  422 */         ResultSet rs = buildResultSetWithRows(callingStatement, catalog, ((ResultSetMetaData)prepStmt.getMetaData()).fields, rows, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */ 
/*  428 */         if (usingCursor) {
/*  429 */           rs.setFetchSize(callingStatement.getFetchSize());
/*      */         }
/*      */ 
/*  432 */         return rs;
/*      */       }
/*      */     }
/*      */ 
/*  436 */     RowData rowData = null;
/*      */ 
/*  438 */     if (!streamResults) {
/*  439 */       rowData = readSingleRowSet(columnCount, maxRows, resultSetConcurrency, isBinaryEncoded, fields);
/*      */     }
/*      */     else {
/*  442 */       rowData = new RowDataDynamic(this, (int)columnCount, fields, isBinaryEncoded);
/*      */ 
/*  444 */       this.streamingData = rowData;
/*      */     }
/*      */ 
/*  447 */     ResultSet rs = buildResultSetWithRows(callingStatement, catalog, fields, rowData, resultSetType, resultSetConcurrency, isBinaryEncoded);
/*      */ 
/*  452 */     return rs;
/*      */   }
/*      */ 
/*      */   protected final void forceClose()
/*      */   {
/*      */     try
/*      */     {
/*  460 */       if (this.mysqlInput != null) {
/*  461 */         this.mysqlInput.close();
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  466 */       this.mysqlInput = null;
/*      */     }
/*      */     try
/*      */     {
/*  470 */       if (this.mysqlOutput != null) {
/*  471 */         this.mysqlOutput.close();
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  476 */       this.mysqlOutput = null;
/*      */     }
/*      */     try
/*      */     {
/*  480 */       if (this.mysqlConnection != null) {
/*  481 */         this.mysqlConnection.close();
/*      */       }
/*      */     }
/*      */     catch (IOException ioEx)
/*      */     {
/*  486 */       this.mysqlConnection = null; }  } 
/*      */   // ERROR //
/*      */   protected final Buffer readPacket() throws SQLException { // Byte code:
/*      */     //   0: aload_0
/*      */     //   1: aload_0
/*      */     //   2: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   5: aload_0
/*      */     //   6: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   9: iconst_0
/*      */     //   10: iconst_4
/*      */     //   11: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   14: istore_1
/*      */     //   15: iload_1
/*      */     //   16: iconst_4
/*      */     //   17: if_icmpge +20 -> 37
/*      */     //   20: aload_0
/*      */     //   21: invokevirtual 109	com/mysql/jdbc/MysqlIO:forceClose	()V
/*      */     //   24: new 83	java/io/IOException
/*      */     //   27: dup
/*      */     //   28: ldc 110
/*      */     //   30: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   33: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   36: athrow
/*      */     //   37: aload_0
/*      */     //   38: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   41: iconst_0
/*      */     //   42: baload
/*      */     //   43: sipush 255
/*      */     //   46: iand
/*      */     //   47: aload_0
/*      */     //   48: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   51: iconst_1
/*      */     //   52: baload
/*      */     //   53: sipush 255
/*      */     //   56: iand
/*      */     //   57: bipush 8
/*      */     //   59: ishl
/*      */     //   60: iadd
/*      */     //   61: aload_0
/*      */     //   62: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   65: iconst_2
/*      */     //   66: baload
/*      */     //   67: sipush 255
/*      */     //   70: iand
/*      */     //   71: bipush 16
/*      */     //   73: ishl
/*      */     //   74: iadd
/*      */     //   75: istore_2
/*      */     //   76: aload_0
/*      */     //   77: getfield 48	com/mysql/jdbc/MysqlIO:traceProtocol	Z
/*      */     //   80: ifeq +66 -> 146
/*      */     //   83: new 113	java/lang/StringBuffer
/*      */     //   86: dup
/*      */     //   87: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   90: astore_3
/*      */     //   91: aload_3
/*      */     //   92: ldc 115
/*      */     //   94: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   97: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   100: pop
/*      */     //   101: aload_3
/*      */     //   102: iload_2
/*      */     //   103: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   106: pop
/*      */     //   107: aload_3
/*      */     //   108: ldc 118
/*      */     //   110: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   113: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   116: pop
/*      */     //   117: aload_3
/*      */     //   118: aload_0
/*      */     //   119: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   122: iconst_4
/*      */     //   123: invokestatic 119	com/mysql/jdbc/StringUtils:dumpAsHex	([BI)Ljava/lang/String;
/*      */     //   126: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   129: pop
/*      */     //   130: aload_0
/*      */     //   131: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   134: invokevirtual 67	com/mysql/jdbc/Connection:getLog	()Lcom/mysql/jdbc/log/Log;
/*      */     //   137: aload_3
/*      */     //   138: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   141: invokeinterface 121 2 0
/*      */     //   146: aload_0
/*      */     //   147: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   150: iconst_3
/*      */     //   151: baload
/*      */     //   152: istore_3
/*      */     //   153: aload_0
/*      */     //   154: getfield 3	com/mysql/jdbc/MysqlIO:packetSequenceReset	Z
/*      */     //   157: ifne +25 -> 182
/*      */     //   160: aload_0
/*      */     //   161: getfield 49	com/mysql/jdbc/MysqlIO:enablePacketDebug	Z
/*      */     //   164: ifeq +23 -> 187
/*      */     //   167: aload_0
/*      */     //   168: getfield 34	com/mysql/jdbc/MysqlIO:checkPacketSequence	Z
/*      */     //   171: ifeq +16 -> 187
/*      */     //   174: aload_0
/*      */     //   175: iload_3
/*      */     //   176: invokespecial 122	com/mysql/jdbc/MysqlIO:checkPacketSequencing	(B)V
/*      */     //   179: goto +8 -> 187
/*      */     //   182: aload_0
/*      */     //   183: iconst_0
/*      */     //   184: putfield 3	com/mysql/jdbc/MysqlIO:packetSequenceReset	Z
/*      */     //   187: aload_0
/*      */     //   188: iload_3
/*      */     //   189: putfield 33	com/mysql/jdbc/MysqlIO:readPacketSequence	B
/*      */     //   192: iload_2
/*      */     //   193: iconst_1
/*      */     //   194: iadd
/*      */     //   195: newarray byte
/*      */     //   197: astore 4
/*      */     //   199: aload_0
/*      */     //   200: aload_0
/*      */     //   201: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   204: aload 4
/*      */     //   206: iconst_0
/*      */     //   207: iload_2
/*      */     //   208: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   211: istore 5
/*      */     //   213: iload 5
/*      */     //   215: iload_2
/*      */     //   216: if_icmpeq +40 -> 256
/*      */     //   219: new 83	java/io/IOException
/*      */     //   222: dup
/*      */     //   223: new 113	java/lang/StringBuffer
/*      */     //   226: dup
/*      */     //   227: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   230: ldc 123
/*      */     //   232: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   235: iload_2
/*      */     //   236: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   239: ldc 124
/*      */     //   241: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   244: iload 5
/*      */     //   246: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   249: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   252: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   255: athrow
/*      */     //   256: aload 4
/*      */     //   258: iload_2
/*      */     //   259: iconst_0
/*      */     //   260: bastore
/*      */     //   261: new 55	com/mysql/jdbc/Buffer
/*      */     //   264: dup
/*      */     //   265: aload 4
/*      */     //   267: invokespecial 125	com/mysql/jdbc/Buffer:<init>	([B)V
/*      */     //   270: astore 6
/*      */     //   272: aload 6
/*      */     //   274: iload_2
/*      */     //   275: iconst_1
/*      */     //   276: iadd
/*      */     //   277: invokevirtual 126	com/mysql/jdbc/Buffer:setBufLength	(I)V
/*      */     //   280: aload_0
/*      */     //   281: getfield 48	com/mysql/jdbc/MysqlIO:traceProtocol	Z
/*      */     //   284: ifeq +52 -> 336
/*      */     //   287: new 113	java/lang/StringBuffer
/*      */     //   290: dup
/*      */     //   291: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   294: astore 7
/*      */     //   296: aload 7
/*      */     //   298: ldc 127
/*      */     //   300: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   303: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   306: pop
/*      */     //   307: aload 7
/*      */     //   309: aload 6
/*      */     //   311: iload_2
/*      */     //   312: invokestatic 128	com/mysql/jdbc/MysqlIO:getPacketDumpToLog	(Lcom/mysql/jdbc/Buffer;I)Ljava/lang/String;
/*      */     //   315: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   318: pop
/*      */     //   319: aload_0
/*      */     //   320: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   323: invokevirtual 67	com/mysql/jdbc/Connection:getLog	()Lcom/mysql/jdbc/log/Log;
/*      */     //   326: aload 7
/*      */     //   328: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   331: invokeinterface 121 2 0
/*      */     //   336: aload_0
/*      */     //   337: getfield 49	com/mysql/jdbc/MysqlIO:enablePacketDebug	Z
/*      */     //   340: ifeq +16 -> 356
/*      */     //   343: aload_0
/*      */     //   344: iconst_0
/*      */     //   345: iconst_0
/*      */     //   346: iconst_0
/*      */     //   347: aload_0
/*      */     //   348: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   351: aload 6
/*      */     //   353: invokespecial 129	com/mysql/jdbc/MysqlIO:enqueuePacketForDebugging	(ZZI[BLcom/mysql/jdbc/Buffer;)V
/*      */     //   356: aload 6
/*      */     //   358: areturn
/*      */     //   359: astore_1
/*      */     //   360: new 84	com/mysql/jdbc/CommunicationsException
/*      */     //   363: dup
/*      */     //   364: aload_0
/*      */     //   365: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   368: aload_0
/*      */     //   369: getfield 47	com/mysql/jdbc/MysqlIO:lastPacketSentTimeMs	J
/*      */     //   372: aload_1
/*      */     //   373: invokespecial 85	com/mysql/jdbc/CommunicationsException:<init>	(Lcom/mysql/jdbc/Connection;JLjava/lang/Exception;)V
/*      */     //   376: athrow
/*      */     //   377: astore_1
/*      */     //   378: aload_0
/*      */     //   379: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   382: iconst_0
/*      */     //   383: iconst_0
/*      */     //   384: iconst_1
/*      */     //   385: aload_1
/*      */     //   386: invokevirtual 131	com/mysql/jdbc/Connection:realClose	(ZZZLjava/lang/Throwable;)V
/*      */     //   389: aload_1
/*      */     //   390: athrow
/*      */     //   391: astore 8
/*      */     //   393: aload_1
/*      */     //   394: athrow
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	358	359	java/io/IOException
/*      */     //   0	358	377	java/lang/OutOfMemoryError
/*      */     //   378	389	391	finally
/*      */     //   391	393	391	finally } 
/*  593 */   protected final Field unpackField(Buffer packet, boolean extractDefaultValues) throws SQLException { if (this.use41Extensions)
/*      */     {
/*  596 */       if (this.has41NewNewProt)
/*      */       {
/*  598 */         int catalogNameStart = packet.getPosition() + 1;
/*  599 */         int catalogNameLength = packet.fastSkipLenString();
/*  600 */         catalogNameStart = adjustStartForFieldLength(catalogNameStart, catalogNameLength);
/*      */       }
/*      */ 
/*  603 */       int databaseNameStart = packet.getPosition() + 1;
/*  604 */       int databaseNameLength = packet.fastSkipLenString();
/*  605 */       databaseNameStart = adjustStartForFieldLength(databaseNameStart, databaseNameLength);
/*      */ 
/*  607 */       int tableNameStart = packet.getPosition() + 1;
/*  608 */       int tableNameLength = packet.fastSkipLenString();
/*  609 */       tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */ 
/*  612 */       int originalTableNameStart = packet.getPosition() + 1;
/*  613 */       int originalTableNameLength = packet.fastSkipLenString();
/*  614 */       originalTableNameStart = adjustStartForFieldLength(originalTableNameStart, originalTableNameLength);
/*      */ 
/*  617 */       int nameStart = packet.getPosition() + 1;
/*  618 */       int nameLength = packet.fastSkipLenString();
/*      */ 
/*  620 */       nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */ 
/*  623 */       int originalColumnNameStart = packet.getPosition() + 1;
/*  624 */       int originalColumnNameLength = packet.fastSkipLenString();
/*  625 */       originalColumnNameStart = adjustStartForFieldLength(originalColumnNameStart, originalColumnNameLength);
/*      */ 
/*  627 */       packet.readByte();
/*      */ 
/*  629 */       short charSetNumber = (short)packet.readInt();
/*      */ 
/*  631 */       long colLength = 0L;
/*      */ 
/*  633 */       if (this.has41NewNewProt)
/*  634 */         colLength = packet.readLong();
/*      */       else {
/*  636 */         colLength = packet.readLongInt();
/*      */       }
/*      */ 
/*  639 */       int colType = packet.readByte() & 0xFF;
/*      */ 
/*  641 */       short colFlag = 0;
/*      */ 
/*  643 */       if (this.hasLongColumnInfo)
/*  644 */         colFlag = (short)packet.readInt();
/*      */       else {
/*  646 */         colFlag = (short)(packet.readByte() & 0xFF);
/*      */       }
/*      */ 
/*  649 */       int colDecimals = packet.readByte() & 0xFF;
/*      */ 
/*  651 */       int defaultValueStart = -1;
/*  652 */       int defaultValueLength = -1;
/*      */ 
/*  654 */       if (extractDefaultValues) {
/*  655 */         defaultValueStart = packet.getPosition() + 1;
/*  656 */         defaultValueLength = packet.fastSkipLenString();
/*      */       }
/*      */ 
/*  659 */       Field field = new Field(this.connection, packet.getByteBuffer(), databaseNameStart, databaseNameLength, tableNameStart, tableNameLength, originalTableNameStart, originalTableNameLength, nameStart, nameLength, originalColumnNameStart, originalColumnNameLength, colLength, colType, colFlag, colDecimals, defaultValueStart, defaultValueLength, charSetNumber);
/*      */ 
/*  667 */       return field;
/*      */     }
/*      */ 
/*  670 */     int tableNameStart = packet.getPosition() + 1;
/*  671 */     int tableNameLength = packet.fastSkipLenString();
/*  672 */     tableNameStart = adjustStartForFieldLength(tableNameStart, tableNameLength);
/*      */ 
/*  674 */     int nameStart = packet.getPosition() + 1;
/*  675 */     int nameLength = packet.fastSkipLenString();
/*  676 */     nameStart = adjustStartForFieldLength(nameStart, nameLength);
/*      */ 
/*  678 */     int colLength = packet.readnBytes();
/*  679 */     int colType = packet.readnBytes();
/*  680 */     packet.readByte();
/*      */ 
/*  682 */     short colFlag = 0;
/*      */ 
/*  684 */     if (this.hasLongColumnInfo)
/*  685 */       colFlag = (short)packet.readInt();
/*      */     else {
/*  687 */       colFlag = (short)(packet.readByte() & 0xFF);
/*      */     }
/*      */ 
/*  690 */     int colDecimals = packet.readByte() & 0xFF;
/*      */ 
/*  692 */     if (this.colDecimalNeedsBump) {
/*  693 */       colDecimals++;
/*      */     }
/*      */ 
/*  696 */     Field field = new Field(this.connection, packet.getByteBuffer(), nameStart, nameLength, tableNameStart, tableNameLength, colLength, colType, colFlag, colDecimals);
/*      */ 
/*  700 */     return field; }
/*      */ 
/*      */   private int adjustStartForFieldLength(int nameStart, int nameLength)
/*      */   {
/*  704 */     if (nameLength < 251) {
/*  705 */       return nameStart;
/*      */     }
/*      */ 
/*  708 */     if ((nameLength >= 251) && (nameLength < 65536)) {
/*  709 */       return nameStart + 2;
/*      */     }
/*      */ 
/*  712 */     if ((nameLength >= 65536) && (nameLength < 16777216)) {
/*  713 */       return nameStart + 3;
/*      */     }
/*      */ 
/*  716 */     return nameStart + 8;
/*      */   }
/*      */ 
/*      */   protected boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag) {
/*  720 */     if ((this.use41Extensions) && (this.connection.getElideSetAutoCommits())) {
/*  721 */       boolean autoCommitModeOnServer = (this.serverStatus & 0x2) != 0;
/*      */ 
/*  724 */       if (!autoCommitFlag)
/*      */       {
/*  728 */         boolean inTransactionOnServer = (this.serverStatus & 0x1) != 0;
/*      */ 
/*  731 */         return !inTransactionOnServer;
/*      */       }
/*      */ 
/*  734 */       return !autoCommitModeOnServer;
/*      */     }
/*      */ 
/*  737 */     return true;
/*      */   }
/*      */ 
/*      */   protected void changeUser(String userName, String password, String database)
/*      */     throws SQLException
/*      */   {
/*  751 */     this.packetSequence = -1;
/*      */ 
/*  753 */     int passwordLength = 16;
/*  754 */     int userLength = 0;
/*      */ 
/*  756 */     if (userName != null) {
/*  757 */       userLength = userName.length();
/*      */     }
/*      */ 
/*  760 */     int packLength = userLength + passwordLength + 7 + 4;
/*      */ 
/*  762 */     if ((this.serverCapabilities & 0x8000) != 0) {
/*  763 */       Buffer changeUserPacket = new Buffer(packLength + 1);
/*  764 */       changeUserPacket.writeByte(17);
/*      */ 
/*  766 */       if (versionMeetsMinimum(4, 1, 1)) {
/*  767 */         secureAuth411(changeUserPacket, packLength, userName, password, database, false);
/*      */       }
/*      */       else {
/*  770 */         secureAuth(changeUserPacket, packLength, userName, password, database, false);
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  775 */       Buffer packet = new Buffer(packLength);
/*  776 */       packet.writeByte(17);
/*      */ 
/*  779 */       packet.writeString(userName);
/*      */ 
/*  781 */       if (this.protocolVersion > 9)
/*  782 */         packet.writeString(Util.newCrypt(password, this.seed));
/*      */       else {
/*  784 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       }
/*      */ 
/*  787 */       boolean localUseConnectWithDb = (this.useConnectWithDb) && (database != null) && (database.length() > 0);
/*      */ 
/*  790 */       if (localUseConnectWithDb) {
/*  791 */         packet.writeString(database);
/*      */       }
/*      */ 
/*  794 */       send(packet, packet.getPosition());
/*  795 */       checkErrorPacket();
/*      */ 
/*  797 */       if (!localUseConnectWithDb)
/*  798 */         changeDatabaseTo(database);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected Buffer checkErrorPacket()
/*      */     throws SQLException
/*      */   {
/*  812 */     return checkErrorPacket(-1);
/*      */   }
/*      */ 
/*      */   protected void checkForCharsetMismatch()
/*      */   {
/*  819 */     if ((this.connection.getUseUnicode()) && (this.connection.getEncoding() != null))
/*      */     {
/*  821 */       String encodingToCheck = jvmPlatformCharset;
/*      */ 
/*  823 */       if (encodingToCheck == null) {
/*  824 */         encodingToCheck = System.getProperty("file.encoding");
/*      */       }
/*      */ 
/*  827 */       if (encodingToCheck == null)
/*  828 */         this.platformDbCharsetMatches = false;
/*      */       else
/*  830 */         this.platformDbCharsetMatches = encodingToCheck.equals(this.connection.getEncoding());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void clearInputStream() throws SQLException
/*      */   {
/*      */     try
/*      */     {
/*  838 */       int len = this.mysqlInput.available();
/*      */ 
/*  840 */       while (len > 0) {
/*  841 */         this.mysqlInput.skip(len);
/*  842 */         len = this.mysqlInput.available();
/*      */       }
/*      */     } catch (IOException ioEx) {
/*  845 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ioEx);
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void resetReadPacketSequence()
/*      */   {
/*  851 */     this.readPacketSequence = 0;
/*      */   }
/*      */ 
/*      */   protected void dumpPacketRingBuffer() throws SQLException {
/*  855 */     if ((this.packetDebugRingBuffer != null) && (this.connection.getEnablePacketDebug()))
/*      */     {
/*  857 */       StringBuffer dumpBuffer = new StringBuffer();
/*      */ 
/*  859 */       dumpBuffer.append("Last " + this.packetDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
/*      */ 
/*  861 */       dumpBuffer.append("\n");
/*      */ 
/*  863 */       Iterator ringBufIter = this.packetDebugRingBuffer.iterator();
/*  864 */       while (ringBufIter.hasNext()) {
/*  865 */         dumpBuffer.append((StringBuffer)ringBufIter.next());
/*  866 */         dumpBuffer.append("\n");
/*      */       }
/*      */ 
/*  869 */       this.connection.getLog().logTrace(dumpBuffer.toString());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void explainSlowQuery(byte[] querySQL, String truncatedQuery)
/*      */     throws SQLException
/*      */   {
/*  883 */     if (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT"))
/*      */     {
/*  885 */       PreparedStatement stmt = null;
/*  886 */       java.sql.ResultSet rs = null;
/*      */       try
/*      */       {
/*  889 */         stmt = this.connection.clientPrepareStatement("EXPLAIN ?");
/*  890 */         stmt.setBytesNoEscapeNoQuotes(1, querySQL);
/*  891 */         rs = stmt.executeQuery();
/*      */ 
/*  893 */         StringBuffer explainResults = new StringBuffer(Messages.getString("MysqlIO.8") + truncatedQuery + Messages.getString("MysqlIO.9"));
/*      */ 
/*  897 */         ResultSetUtil.appendResultSetSlashGStyle(explainResults, rs);
/*      */ 
/*  899 */         this.connection.getLog().logWarn(explainResults.toString());
/*      */       } catch (SQLException sqlEx) {
/*      */       } finally {
/*  902 */         if (rs != null) {
/*  903 */           rs.close();
/*      */         }
/*      */ 
/*  906 */         if (stmt != null)
/*  907 */           stmt.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   static int getMaxBuf()
/*      */   {
/*  915 */     return maxBufferSize;
/*      */   }
/*      */ 
/*      */   final int getServerMajorVersion()
/*      */   {
/*  924 */     return this.serverMajorVersion;
/*      */   }
/*      */ 
/*      */   final int getServerMinorVersion()
/*      */   {
/*  933 */     return this.serverMinorVersion;
/*      */   }
/*      */ 
/*      */   final int getServerSubMinorVersion()
/*      */   {
/*  942 */     return this.serverSubMinorVersion;
/*      */   }
/*      */ 
/*      */   String getServerVersion()
/*      */   {
/*  951 */     return this.serverVersion;
/*      */   }
/*      */ 
/*      */   void doHandshake(String user, String password, String database)
/*      */     throws SQLException
/*      */   {
/*  968 */     this.checkPacketSequence = false;
/*  969 */     this.readPacketSequence = 0;
/*      */ 
/*  971 */     Buffer buf = readPacket();
/*      */ 
/*  974 */     this.protocolVersion = buf.readByte();
/*      */ 
/*  976 */     if (this.protocolVersion == -1) {
/*      */       try {
/*  978 */         this.mysqlConnection.close();
/*      */       }
/*      */       catch (Exception e)
/*      */       {
/*      */       }
/*  983 */       int errno = 2000;
/*      */ 
/*  985 */       errno = buf.readInt();
/*      */ 
/*  987 */       String serverErrorMessage = buf.readString();
/*      */ 
/*  989 */       StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.10"));
/*      */ 
/*  991 */       errorBuf.append(serverErrorMessage);
/*  992 */       errorBuf.append("\"");
/*      */ 
/*  994 */       String xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */ 
/*  997 */       throw SQLError.createSQLException(SQLError.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno);
/*      */     }
/*      */ 
/* 1001 */     this.serverVersion = buf.readString();
/*      */ 
/* 1004 */     int point = this.serverVersion.indexOf(".");
/*      */ 
/* 1006 */     if (point != -1) {
/*      */       try {
/* 1008 */         int n = Integer.parseInt(this.serverVersion.substring(0, point));
/* 1009 */         this.serverMajorVersion = n;
/*      */       }
/*      */       catch (NumberFormatException NFE1)
/*      */       {
/*      */       }
/* 1014 */       String remaining = this.serverVersion.substring(point + 1, this.serverVersion.length());
/*      */ 
/* 1016 */       point = remaining.indexOf(".");
/*      */ 
/* 1018 */       if (point != -1) {
/*      */         try {
/* 1020 */           int n = Integer.parseInt(remaining.substring(0, point));
/* 1021 */           this.serverMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe)
/*      */         {
/*      */         }
/* 1026 */         remaining = remaining.substring(point + 1, remaining.length());
/*      */ 
/* 1028 */         int pos = 0;
/*      */ 
/* 1030 */         while ((pos < remaining.length()) && 
/* 1031 */           (remaining.charAt(pos) >= '0') && (remaining.charAt(pos) <= '9'))
/*      */         {
/* 1036 */           pos++;
/*      */         }
/*      */         try
/*      */         {
/* 1040 */           int n = Integer.parseInt(remaining.substring(0, pos));
/* 1041 */           this.serverSubMinorVersion = n;
/*      */         }
/*      */         catch (NumberFormatException nfe)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/* 1048 */     if (versionMeetsMinimum(4, 0, 8)) {
/* 1049 */       this.maxThreeBytes = 16777215;
/* 1050 */       this.useNewLargePackets = true;
/*      */     } else {
/* 1052 */       this.maxThreeBytes = 16581375;
/* 1053 */       this.useNewLargePackets = false;
/*      */     }
/*      */ 
/* 1056 */     this.colDecimalNeedsBump = versionMeetsMinimum(3, 23, 0);
/* 1057 */     this.colDecimalNeedsBump = (!versionMeetsMinimum(3, 23, 15));
/* 1058 */     this.useNewUpdateCounts = versionMeetsMinimum(3, 22, 5);
/*      */ 
/* 1060 */     this.threadId = buf.readLong();
/* 1061 */     this.seed = buf.readString();
/*      */ 
/* 1063 */     this.serverCapabilities = 0;
/*      */ 
/* 1065 */     if (buf.getPosition() < buf.getBufLength()) {
/* 1066 */       this.serverCapabilities = buf.readInt();
/*      */     }
/*      */ 
/* 1069 */     if (versionMeetsMinimum(4, 1, 1)) {
/* 1070 */       int position = buf.getPosition();
/*      */ 
/* 1073 */       this.serverCharsetIndex = (buf.readByte() & 0xFF);
/* 1074 */       this.serverStatus = buf.readInt();
/* 1075 */       buf.setPosition(position + 16);
/*      */ 
/* 1077 */       String seedPart2 = buf.readString();
/* 1078 */       StringBuffer newSeed = new StringBuffer(20);
/* 1079 */       newSeed.append(this.seed);
/* 1080 */       newSeed.append(seedPart2);
/* 1081 */       this.seed = newSeed.toString();
/*      */     }
/*      */ 
/* 1084 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()))
/*      */     {
/* 1086 */       this.clientParam |= 32L;
/*      */     }
/*      */ 
/* 1089 */     this.useConnectWithDb = ((database != null) && (database.length() > 0) && (!this.connection.getCreateDatabaseIfNotExist()));
/*      */ 
/* 1093 */     if (this.useConnectWithDb) {
/* 1094 */       this.clientParam |= 8L;
/*      */     }
/*      */ 
/* 1097 */     if (((this.serverCapabilities & 0x800) == 0) && (this.connection.getUseSSL()))
/*      */     {
/* 1099 */       if (this.connection.getRequireSSL()) {
/* 1100 */         this.connection.close();
/* 1101 */         forceClose();
/* 1102 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.15"), "08001");
/*      */       }
/*      */ 
/* 1106 */       this.connection.setUseSSL(false);
/*      */     }
/*      */ 
/* 1109 */     if ((this.serverCapabilities & 0x4) != 0)
/*      */     {
/* 1111 */       this.clientParam |= 4L;
/* 1112 */       this.hasLongColumnInfo = true;
/*      */     }
/*      */ 
/* 1116 */     this.clientParam |= 2L;
/*      */ 
/* 1118 */     if (this.connection.getAllowLoadLocalInfile()) {
/* 1119 */       this.clientParam |= 128L;
/*      */     }
/*      */ 
/* 1122 */     if (this.isInteractiveClient) {
/* 1123 */       this.clientParam |= 1024L;
/*      */     }
/*      */ 
/* 1127 */     if (this.protocolVersion > 9)
/* 1128 */       this.clientParam |= 1L;
/*      */     else {
/* 1130 */       this.clientParam &= -2L;
/*      */     }
/*      */ 
/* 1136 */     if (versionMeetsMinimum(4, 1, 0)) {
/* 1137 */       if (versionMeetsMinimum(4, 1, 1)) {
/* 1138 */         this.clientParam |= 512L;
/* 1139 */         this.has41NewNewProt = true;
/*      */ 
/* 1142 */         this.clientParam |= 8192L;
/*      */ 
/* 1145 */         this.clientParam |= 131072L;
/*      */ 
/* 1150 */         if (this.connection.getAllowMultiQueries())
/* 1151 */           this.clientParam |= 65536L;
/*      */       }
/*      */       else {
/* 1154 */         this.clientParam |= 16384L;
/* 1155 */         this.has41NewNewProt = false;
/*      */       }
/*      */ 
/* 1158 */       this.use41Extensions = true;
/*      */     }
/*      */ 
/* 1161 */     int passwordLength = 16;
/* 1162 */     int userLength = 0;
/* 1163 */     int databaseLength = 0;
/*      */ 
/* 1165 */     if (user != null) {
/* 1166 */       userLength = user.length();
/*      */     }
/*      */ 
/* 1169 */     if (database != null) {
/* 1170 */       databaseLength = database.length();
/*      */     }
/*      */ 
/* 1173 */     int packLength = userLength + passwordLength + databaseLength + 7 + 4;
/*      */ 
/* 1175 */     Buffer packet = null;
/*      */ 
/* 1177 */     if (!this.connection.getUseSSL()) {
/* 1178 */       if ((this.serverCapabilities & 0x8000) != 0) {
/* 1179 */         this.clientParam |= 32768L;
/*      */ 
/* 1181 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 1182 */           secureAuth411(null, packLength, user, password, database, true);
/*      */         }
/*      */         else
/* 1185 */           secureAuth(null, packLength, user, password, database, true);
/*      */       }
/*      */       else
/*      */       {
/* 1189 */         packet = new Buffer(packLength);
/*      */ 
/* 1191 */         if ((this.clientParam & 0x4000) != 0L) {
/* 1192 */           if (versionMeetsMinimum(4, 1, 1)) {
/* 1193 */             packet.writeLong(this.clientParam);
/* 1194 */             packet.writeLong(this.maxThreeBytes);
/*      */ 
/* 1199 */             packet.writeByte(8);
/*      */ 
/* 1202 */             packet.writeBytesNoNull(new byte[23]);
/*      */           } else {
/* 1204 */             packet.writeLong(this.clientParam);
/* 1205 */             packet.writeLong(this.maxThreeBytes);
/*      */           }
/*      */         } else {
/* 1208 */           packet.writeInt((int)this.clientParam);
/* 1209 */           packet.writeLongInt(this.maxThreeBytes);
/*      */         }
/*      */ 
/* 1213 */         packet.writeString(user, "Cp1252", this.connection);
/*      */ 
/* 1215 */         if (this.protocolVersion > 9)
/* 1216 */           packet.writeString(Util.newCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         else {
/* 1218 */           packet.writeString(Util.oldCrypt(password, this.seed), "Cp1252", this.connection);
/*      */         }
/*      */ 
/* 1221 */         if (this.useConnectWithDb) {
/* 1222 */           packet.writeString(database, "Cp1252", this.connection);
/*      */         }
/*      */ 
/* 1225 */         send(packet, packet.getPosition());
/*      */       }
/*      */     }
/* 1228 */     else negotiateSSLConnection(user, password, database, packLength);
/*      */ 
/* 1234 */     if (!versionMeetsMinimum(4, 1, 1)) {
/* 1235 */       checkErrorPacket();
/*      */     }
/*      */ 
/* 1241 */     if (((this.serverCapabilities & 0x20) != 0) && (this.connection.getUseCompression()))
/*      */     {
/* 1245 */       this.deflater = new Deflater();
/* 1246 */       this.useCompression = true;
/* 1247 */       this.mysqlInput = new CompressedInputStream(this.connection, this.mysqlInput);
/*      */     }
/*      */ 
/* 1251 */     if (!this.useConnectWithDb)
/* 1252 */       changeDatabaseTo(database);
/*      */   }
/*      */ 
/*      */   private void changeDatabaseTo(String database) throws SQLException, CommunicationsException
/*      */   {
/* 1257 */     if ((database == null) || (database.length() == 0)) {
/* 1258 */       return;
/*      */     }
/*      */     try
/*      */     {
/* 1262 */       sendCommand(2, database, null, false, null);
/*      */     } catch (Exception ex) {
/* 1264 */       if (this.connection.getCreateDatabaseIfNotExist()) {
/* 1265 */         sendCommand(3, "CREATE DATABASE IF NOT EXISTS " + database, null, false, null);
/*      */ 
/* 1268 */         sendCommand(2, database, null, false, null);
/*      */       } else {
/* 1270 */         throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ex);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   final Object[] nextRow(Field[] fields, int columnCount, boolean isBinaryEncoded, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 1295 */     Buffer rowPacket = checkErrorPacket();
/*      */ 
/* 1297 */     if (!isBinaryEncoded)
/*      */     {
/* 1302 */       rowPacket.setPosition(rowPacket.getPosition() - 1);
/*      */ 
/* 1304 */       if (!rowPacket.isLastDataPacket()) {
/* 1305 */         byte[][] rowData = new byte[columnCount][];
/*      */ 
/* 1307 */         int offset = 0;
/*      */ 
/* 1309 */         for (int i = 0; i < columnCount; i++) {
/* 1310 */           rowData[i] = rowPacket.readLenByteArray(offset);
/*      */         }
/*      */ 
/* 1313 */         return rowData;
/*      */       }
/*      */ 
/* 1316 */       readServerStatusForResultSets(rowPacket);
/*      */ 
/* 1318 */       return null;
/*      */     }
/*      */ 
/* 1325 */     if (!rowPacket.isLastDataPacket()) {
/* 1326 */       return unpackBinaryResultSetRow(fields, rowPacket, resultSetConcurrency);
/*      */     }
/*      */ 
/* 1330 */     rowPacket.setPosition(rowPacket.getPosition() - 1);
/* 1331 */     readServerStatusForResultSets(rowPacket);
/*      */ 
/* 1333 */     return null;
/*      */   }
/*      */ 
/*      */   final void quit()
/*      */     throws SQLException
/*      */   {
/* 1342 */     Buffer packet = new Buffer(6);
/* 1343 */     this.packetSequence = -1;
/* 1344 */     packet.writeByte(1);
/* 1345 */     send(packet, packet.getPosition());
/* 1346 */     forceClose();
/*      */   }
/*      */ 
/*      */   Buffer getSharedSendPacket()
/*      */   {
/* 1356 */     if (this.sharedSendPacket == null) {
/* 1357 */       this.sharedSendPacket = new Buffer(this.connection.getNetBufferLength());
/*      */     }
/*      */ 
/* 1361 */     return this.sharedSendPacket;
/*      */   }
/*      */ 
/*      */   void closeStreamer(RowData streamer) throws SQLException {
/* 1365 */     if (this.streamingData == null) {
/* 1366 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"));
/*      */     }
/*      */ 
/* 1370 */     if (streamer != this.streamingData) {
/* 1371 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"));
/*      */     }
/*      */ 
/* 1377 */     this.streamingData = null;
/*      */   }
/*      */ 
/*      */   ResultSet readAllResults(Statement callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, boolean unpackFieldInfo)
/*      */     throws SQLException
/*      */   {
/* 1385 */     resultPacket.setPosition(resultPacket.getPosition() - 1);
/*      */ 
/* 1387 */     ResultSet topLevelResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, isBinaryEncoded, preSentColumnCount, unpackFieldInfo);
/*      */ 
/* 1392 */     ResultSet currentResultSet = topLevelResultSet;
/*      */ 
/* 1394 */     boolean checkForMoreResults = (this.clientParam & 0x20000) != 0L;
/*      */ 
/* 1397 */     boolean serverHasMoreResults = (this.serverStatus & 0x8) != 0;
/*      */ 
/* 1403 */     if ((serverHasMoreResults) && (streamResults)) {
/* 1404 */       clearInputStream();
/*      */ 
/* 1406 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.23"), "S1C00");
/*      */     }
/*      */ 
/* 1410 */     boolean moreRowSetsExist = checkForMoreResults & serverHasMoreResults;
/*      */ 
/* 1412 */     while (moreRowSetsExist) {
/* 1413 */       Buffer fieldPacket = checkErrorPacket();
/* 1414 */       fieldPacket.setPosition(0);
/*      */ 
/* 1416 */       if ((fieldPacket.readByte(0) == 0) && (fieldPacket.readByte(1) == 0) && (fieldPacket.readByte(2) == 0))
/*      */       {
/*      */         break;
/*      */       }
/*      */ 
/* 1422 */       ResultSet newResultSet = readResultsForQueryOrUpdate(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, fieldPacket, isBinaryEncoded, preSentColumnCount, unpackFieldInfo);
/*      */ 
/* 1427 */       currentResultSet.setNextResultSet(newResultSet);
/*      */ 
/* 1429 */       currentResultSet = newResultSet;
/*      */ 
/* 1431 */       moreRowSetsExist = (this.serverStatus & 0x8) != 0;
/*      */     }
/*      */ 
/* 1434 */     if (!streamResults) {
/* 1435 */       clearInputStream();
/*      */     }
/*      */ 
/* 1438 */     reclaimLargeReusablePacket();
/*      */ 
/* 1440 */     return topLevelResultSet;
/*      */   }
/*      */ 
/*      */   void resetMaxBuf()
/*      */   {
/* 1447 */     this.maxAllowedPacket = this.connection.getMaxAllowedPacket();
/*      */   }
/*      */ 
/*      */   final Buffer sendCommand(int command, String extraData, Buffer queryPacket, boolean skipCheck, String extraDataCharEncoding)
/*      */     throws SQLException
/*      */   {
/* 1478 */     this.enablePacketDebug = this.connection.getEnablePacketDebug();
/* 1479 */     this.traceProtocol = this.connection.getTraceProtocol();
/* 1480 */     this.readPacketSequence = 0;
/*      */     try
/*      */     {
/* 1484 */       checkForOutstandingStreamingData();
/*      */ 
/* 1489 */       this.serverStatus = 0;
/* 1490 */       this.hadWarnings = false;
/* 1491 */       this.warningCount = 0;
/*      */ 
/* 1493 */       this.queryNoIndexUsed = false;
/* 1494 */       this.queryBadIndexUsed = false;
/*      */ 
/* 1500 */       if (this.useCompression) {
/* 1501 */         int bytesLeft = this.mysqlInput.available();
/*      */ 
/* 1503 */         if (bytesLeft > 0) {
/* 1504 */           this.mysqlInput.skip(bytesLeft);
/*      */         }
/*      */       }
/*      */       try
/*      */       {
/* 1509 */         clearInputStream();
/*      */ 
/* 1518 */         if (queryPacket == null) {
/* 1519 */           int packLength = 8 + (extraData != null ? extraData.length() : 0) + 2;
/*      */ 
/* 1522 */           if (this.sendPacket == null) {
/* 1523 */             this.sendPacket = new Buffer(packLength);
/*      */           }
/*      */ 
/* 1526 */           this.packetSequence = -1;
/* 1527 */           this.readPacketSequence = 0;
/* 1528 */           this.checkPacketSequence = true;
/* 1529 */           this.sendPacket.clear();
/*      */ 
/* 1531 */           this.sendPacket.writeByte((byte)command);
/*      */ 
/* 1533 */           if ((command == 2) || (command == 5) || (command == 6) || (command == 3) || (command == 22))
/*      */           {
/* 1538 */             if (extraDataCharEncoding == null)
/* 1539 */               this.sendPacket.writeStringNoNull(extraData);
/*      */             else {
/* 1541 */               this.sendPacket.writeStringNoNull(extraData, extraDataCharEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */             }
/*      */ 
/*      */           }
/* 1546 */           else if (command == 12) {
/* 1547 */             long id = new Long(extraData).longValue();
/* 1548 */             this.sendPacket.writeLong(id);
/*      */           }
/*      */ 
/* 1551 */           send(this.sendPacket, this.sendPacket.getPosition());
/*      */         } else {
/* 1553 */           this.packetSequence = -1;
/* 1554 */           send(queryPacket, queryPacket.getPosition());
/*      */         }
/*      */       }
/*      */       catch (SQLException sqlEx) {
/* 1558 */         throw sqlEx;
/*      */       } catch (Exception ex) {
/* 1560 */         throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ex);
/*      */       }
/*      */ 
/* 1564 */       Buffer returnPacket = null;
/*      */ 
/* 1566 */       if (!skipCheck) {
/* 1567 */         if ((command == 23) || (command == 26))
/*      */         {
/* 1569 */           this.readPacketSequence = 0;
/* 1570 */           this.packetSequenceReset = true;
/*      */         }
/*      */ 
/* 1573 */         returnPacket = checkErrorPacket(command);
/*      */       }
/*      */ 
/* 1576 */       return returnPacket; } catch (IOException ioEx) {
/*      */     }
/* 1578 */     throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ioEx);
/*      */   }
/*      */ 
/*      */   final ResultSet sqlQueryDirect(Statement callingStatement, String query, String characterEncoding, Buffer queryPacket, int maxRows, Connection conn, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, boolean unpackFieldInfo)
/*      */     throws Exception
/*      */   {
/* 1607 */     long queryStartTime = 0L;
/* 1608 */     long queryEndTime = 0L;
/*      */ 
/* 1610 */     if (query != null)
/*      */     {
/* 1616 */       int packLength = 5 + query.length() * 2 + 2;
/*      */ 
/* 1618 */       if (this.sendPacket == null)
/* 1619 */         this.sendPacket = new Buffer(packLength);
/*      */       else {
/* 1621 */         this.sendPacket.clear();
/*      */       }
/*      */ 
/* 1624 */       this.sendPacket.writeByte(3);
/*      */ 
/* 1626 */       if (characterEncoding != null) {
/* 1627 */         if (this.platformDbCharsetMatches) {
/* 1628 */           this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */         }
/* 1633 */         else if (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA"))
/* 1634 */           this.sendPacket.writeBytesNoNull(query.getBytes());
/*      */         else {
/* 1636 */           this.sendPacket.writeStringNoNull(query, characterEncoding, this.connection.getServerCharacterEncoding(), this.connection.parserKnowsUnicode(), this.connection);
/*      */         }
/*      */ 
/*      */       }
/*      */       else
/*      */       {
/* 1644 */         this.sendPacket.writeStringNoNull(query);
/*      */       }
/*      */ 
/* 1647 */       queryPacket = this.sendPacket;
/*      */     }
/*      */ 
/* 1650 */     byte[] queryBuf = null;
/* 1651 */     int oldPacketPosition = 0;
/*      */ 
/* 1655 */     if (this.needToGrabQueryFromPacket) {
/* 1656 */       queryBuf = queryPacket.getByteBuffer();
/*      */ 
/* 1659 */       oldPacketPosition = queryPacket.getPosition();
/*      */ 
/* 1661 */       queryStartTime = System.currentTimeMillis();
/*      */     }
/*      */ 
/* 1665 */     Buffer resultPacket = sendCommand(3, null, queryPacket, false, null);
/*      */ 
/* 1668 */     long fetchBeginTime = 0L;
/* 1669 */     long fetchEndTime = 0L;
/*      */ 
/* 1671 */     String profileQueryToLog = null;
/*      */ 
/* 1673 */     boolean queryWasSlow = false;
/*      */ 
/* 1675 */     if ((this.profileSql) || (this.logSlowQueries)) {
/* 1676 */       queryEndTime = System.currentTimeMillis();
/*      */ 
/* 1678 */       boolean shouldExtractQuery = false;
/*      */ 
/* 1680 */       if (this.profileSql) {
/* 1681 */         shouldExtractQuery = true;
/* 1682 */       } else if ((this.logSlowQueries) && (queryEndTime - queryStartTime > this.connection.getSlowQueryThresholdMillis()))
/*      */       {
/* 1684 */         shouldExtractQuery = true;
/* 1685 */         queryWasSlow = true;
/*      */       }
/*      */ 
/* 1688 */       if (shouldExtractQuery)
/*      */       {
/* 1690 */         boolean truncated = false;
/*      */ 
/* 1692 */         int extractPosition = oldPacketPosition;
/*      */ 
/* 1694 */         if (oldPacketPosition > this.connection.getMaxQuerySizeToLog()) {
/* 1695 */           extractPosition = this.connection.getMaxQuerySizeToLog() + 5;
/* 1696 */           truncated = true;
/*      */         }
/*      */ 
/* 1699 */         profileQueryToLog = new String(queryBuf, 5, extractPosition - 5);
/*      */ 
/* 1702 */         if (truncated) {
/* 1703 */           profileQueryToLog = profileQueryToLog + Messages.getString("MysqlIO.25");
/*      */         }
/*      */       }
/*      */ 
/* 1707 */       fetchBeginTime = queryEndTime;
/*      */     }
/*      */ 
/* 1710 */     if (this.autoGenerateTestcaseScript) {
/* 1711 */       String testcaseQuery = null;
/*      */ 
/* 1713 */       if (query != null)
/* 1714 */         testcaseQuery = query;
/*      */       else {
/* 1716 */         testcaseQuery = new String(queryBuf, 5, oldPacketPosition - 5);
/*      */       }
/*      */ 
/* 1720 */       StringBuffer debugBuf = new StringBuffer(testcaseQuery.length() + 32);
/* 1721 */       this.connection.generateConnectionCommentBlock(debugBuf);
/* 1722 */       debugBuf.append(testcaseQuery);
/* 1723 */       debugBuf.append(';');
/* 1724 */       this.connection.dumpTestcaseQuery(debugBuf.toString());
/*      */     }
/*      */ 
/* 1727 */     ResultSet rs = readAllResults(callingStatement, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, resultPacket, false, -1L, unpackFieldInfo);
/*      */ 
/* 1731 */     if (queryWasSlow) {
/* 1732 */       StringBuffer mesgBuf = new StringBuffer(48 + profileQueryToLog.length());
/*      */ 
/* 1734 */       mesgBuf.append(Messages.getString("MysqlIO.26"));
/* 1735 */       mesgBuf.append(this.connection.getSlowQueryThresholdMillis());
/* 1736 */       mesgBuf.append(Messages.getString("MysqlIO.26a"));
/* 1737 */       mesgBuf.append(queryEndTime - queryStartTime);
/* 1738 */       mesgBuf.append(Messages.getString("MysqlIO.27"));
/* 1739 */       mesgBuf.append(profileQueryToLog);
/*      */ 
/* 1741 */       ProfileEventSink eventSink = ProfileEventSink.getInstance(this.connection);
/*      */ 
/* 1743 */       eventSink.consumeEvent(new ProfilerEvent(3, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, rs.resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), null, new Throwable(), profileQueryToLog));
/*      */ 
/* 1752 */       if (this.connection.getExplainSlowQueries()) {
/* 1753 */         if (oldPacketPosition < 1048576) {
/* 1754 */           explainSlowQuery(queryPacket.getBytes(5, oldPacketPosition - 5), profileQueryToLog);
/*      */         }
/*      */         else {
/* 1757 */           this.connection.getLog().logWarn(Messages.getString("MysqlIO.28") + 1048576 + Messages.getString("MysqlIO.29"));
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1765 */     if (this.profileSql) {
/* 1766 */       fetchEndTime = System.currentTimeMillis();
/*      */ 
/* 1768 */       ProfileEventSink eventSink = ProfileEventSink.getInstance(this.connection);
/*      */ 
/* 1770 */       eventSink.consumeEvent(new ProfilerEvent(3, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, rs.resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), null, new Throwable(), profileQueryToLog));
/*      */ 
/* 1777 */       eventSink.consumeEvent(new ProfilerEvent(5, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, rs.resultId, System.currentTimeMillis(), (int)(fetchEndTime - fetchBeginTime), null, new Throwable(), null));
/*      */ 
/* 1784 */       if (this.queryBadIndexUsed) {
/* 1785 */         eventSink.consumeEvent(new ProfilerEvent(0, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, rs.resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), null, new Throwable(), Messages.getString("MysqlIO.33") + profileQueryToLog));
/*      */       }
/*      */ 
/* 1797 */       if (this.queryNoIndexUsed) {
/* 1798 */         eventSink.consumeEvent(new ProfilerEvent(0, "", catalog, this.connection.getId(), callingStatement != null ? callingStatement.getId() : 999, rs.resultId, System.currentTimeMillis(), (int)(queryEndTime - queryStartTime), null, new Throwable(), Messages.getString("MysqlIO.35") + profileQueryToLog));
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1811 */     if (this.hadWarnings) {
/* 1812 */       scanForAndThrowDataTruncation();
/*      */     }
/*      */ 
/* 1815 */     return rs;
/*      */   }
/*      */ 
/*      */   String getHost()
/*      */   {
/* 1824 */     return this.host;
/*      */   }
/*      */ 
/*      */   boolean isVersion(int major, int minor, int subminor)
/*      */   {
/* 1839 */     return (major == getServerMajorVersion()) && (minor == getServerMinorVersion()) && (subminor == getServerSubMinorVersion());
/*      */   }
/*      */ 
/*      */   boolean versionMeetsMinimum(int major, int minor, int subminor)
/*      */   {
/* 1855 */     if (getServerMajorVersion() >= major) {
/* 1856 */       if (getServerMajorVersion() == major) {
/* 1857 */         if (getServerMinorVersion() >= minor) {
/* 1858 */           if (getServerMinorVersion() == minor) {
/* 1859 */             return getServerSubMinorVersion() >= subminor;
/*      */           }
/*      */ 
/* 1863 */           return true;
/*      */         }
/*      */ 
/* 1867 */         return false;
/*      */       }
/*      */ 
/* 1871 */       return true;
/*      */     }
/*      */ 
/* 1874 */     return false;
/*      */   }
/*      */ 
/*      */   private static final String getPacketDumpToLog(Buffer packetToDump, int packetLength)
/*      */   {
/* 1888 */     if (packetLength < 1024) {
/* 1889 */       return packetToDump.dump(packetLength);
/*      */     }
/*      */ 
/* 1892 */     StringBuffer packetDumpBuf = new StringBuffer(4096);
/* 1893 */     packetDumpBuf.append(packetToDump.dump(1024));
/* 1894 */     packetDumpBuf.append(Messages.getString("MysqlIO.36"));
/* 1895 */     packetDumpBuf.append(1024);
/* 1896 */     packetDumpBuf.append(Messages.getString("MysqlIO.37"));
/*      */ 
/* 1898 */     return packetDumpBuf.toString();
/*      */   }
/*      */ 
/*      */   private final int readFully(InputStream in, byte[] b, int off, int len) throws IOException
/*      */   {
/* 1903 */     if (len < 0) {
/* 1904 */       throw new IndexOutOfBoundsException();
/*      */     }
/*      */ 
/* 1907 */     int n = 0;
/*      */ 
/* 1909 */     while (n < len) {
/* 1910 */       int count = in.read(b, off + n, len - n);
/*      */ 
/* 1912 */       if (count < 0) {
/* 1913 */         throw new EOFException();
/*      */       }
/*      */ 
/* 1916 */       n += count;
/*      */     }
/*      */ 
/* 1919 */     return n;
/*      */   }
/*      */ 
/*      */   private final ResultSet readResultsForQueryOrUpdate(Statement callingStatement, int maxRows, int resultSetType, int resultSetConcurrency, boolean streamResults, String catalog, Buffer resultPacket, boolean isBinaryEncoded, long preSentColumnCount, boolean unpackFieldInfo)
/*      */     throws SQLException
/*      */   {
/* 1947 */     long columnCount = resultPacket.readFieldLength();
/*      */ 
/* 1949 */     if (columnCount == 0L)
/* 1950 */       return buildResultSetWithUpdates(callingStatement, resultPacket);
/* 1951 */     if (columnCount == -1L) {
/* 1952 */       String charEncoding = null;
/*      */ 
/* 1954 */       if (this.connection.getUseUnicode()) {
/* 1955 */         charEncoding = this.connection.getEncoding();
/*      */       }
/*      */ 
/* 1958 */       String fileName = null;
/*      */ 
/* 1960 */       if (this.platformDbCharsetMatches) {
/* 1961 */         fileName = charEncoding != null ? resultPacket.readString(charEncoding) : resultPacket.readString();
/*      */       }
/*      */       else
/*      */       {
/* 1965 */         fileName = resultPacket.readString();
/*      */       }
/*      */ 
/* 1968 */       return sendFileToServer(callingStatement, fileName);
/*      */     }
/* 1970 */     ResultSet results = getResultSet(callingStatement, columnCount, maxRows, resultSetType, resultSetConcurrency, streamResults, catalog, isBinaryEncoded, unpackFieldInfo);
/*      */ 
/* 1974 */     return results;
/*      */   }
/*      */ 
/*      */   private int alignPacketSize(int a, int l)
/*      */   {
/* 1979 */     return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
/*      */   }
/*      */ 
/*      */   private ResultSet buildResultSetWithRows(Statement callingStatement, String catalog, Field[] fields, RowData rows, int resultSetType, int resultSetConcurrency, boolean isBinaryEncoded)
/*      */     throws SQLException
/*      */   {
/* 1987 */     ResultSet rs = null;
/*      */ 
/* 1989 */     switch (resultSetConcurrency) {
/*      */     case 1007:
/* 1991 */       rs = new ResultSet(catalog, fields, rows, this.connection, callingStatement);
/*      */ 
/* 1994 */       if (!isBinaryEncoded) break;
/* 1995 */       rs.setBinaryEncoded(); break;
/*      */     case 1008:
/* 2001 */       rs = new UpdatableResultSet(catalog, fields, rows, this.connection, callingStatement);
/*      */ 
/* 2004 */       break;
/*      */     default:
/* 2007 */       return new ResultSet(catalog, fields, rows, this.connection, callingStatement);
/*      */     }
/*      */ 
/* 2011 */     rs.setResultSetType(resultSetType);
/* 2012 */     rs.setResultSetConcurrency(resultSetConcurrency);
/*      */ 
/* 2014 */     return rs;
/*      */   }
/*      */ 
/*      */   private ResultSet buildResultSetWithUpdates(Statement callingStatement, Buffer resultPacket)
/*      */     throws SQLException
/*      */   {
/* 2020 */     long updateCount = -1L;
/* 2021 */     long updateID = -1L;
/* 2022 */     String info = null;
/*      */     try
/*      */     {
/* 2025 */       if (this.useNewUpdateCounts) {
/* 2026 */         updateCount = resultPacket.newReadLength();
/* 2027 */         updateID = resultPacket.newReadLength();
/*      */       } else {
/* 2029 */         updateCount = resultPacket.readLength();
/* 2030 */         updateID = resultPacket.readLength();
/*      */       }
/*      */ 
/* 2033 */       if (this.use41Extensions) {
/* 2034 */         this.serverStatus = resultPacket.readInt();
/*      */ 
/* 2036 */         this.warningCount = resultPacket.readInt();
/*      */ 
/* 2038 */         if (this.warningCount > 0) {
/* 2039 */           this.hadWarnings = true;
/*      */         }
/*      */ 
/* 2042 */         resultPacket.readByte();
/*      */ 
/* 2044 */         if (this.profileSql) {
/* 2045 */           this.queryNoIndexUsed = ((this.serverStatus & 0x10) != 0);
/*      */ 
/* 2047 */           this.queryBadIndexUsed = ((this.serverStatus & 0x20) != 0);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 2052 */       if (this.connection.isReadInfoMsgEnabled())
/* 2053 */         info = resultPacket.readString();
/*      */     }
/*      */     catch (Exception ex) {
/* 2056 */       throw SQLError.createSQLException(SQLError.get("S1000") + ": " + ex.getClass().getName(), "S1000", -1);
/*      */     }
/*      */ 
/* 2061 */     ResultSet updateRs = new ResultSet(updateCount, updateID, this.connection, callingStatement);
/*      */ 
/* 2064 */     if (info != null) {
/* 2065 */       updateRs.setServerInfo(info);
/*      */     }
/*      */ 
/* 2068 */     return updateRs;
/*      */   }
/*      */ 
/*      */   private void checkForOutstandingStreamingData() throws SQLException {
/* 2072 */     if (this.streamingData != null) {
/* 2073 */       if (!this.connection.getClobberStreamingResults()) {
/* 2074 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.39") + this.streamingData + Messages.getString("MysqlIO.40") + Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"));
/*      */       }
/*      */ 
/* 2082 */       this.streamingData.getOwner().realClose(false);
/*      */ 
/* 2085 */       clearInputStream();
/*      */     }
/*      */   }
/*      */ 
/*      */   private Buffer compressPacket(Buffer packet, int offset, int packetLen, int headerLength) throws SQLException
/*      */   {
/* 2091 */     packet.writeLongInt(packetLen - headerLength);
/* 2092 */     packet.writeByte(0);
/*      */ 
/* 2094 */     int lengthToWrite = 0;
/* 2095 */     int compressedLength = 0;
/* 2096 */     byte[] bytesToCompress = packet.getByteBuffer();
/* 2097 */     byte[] compressedBytes = null;
/* 2098 */     int offsetWrite = 0;
/*      */ 
/* 2100 */     if (packetLen < 50) {
/* 2101 */       lengthToWrite = packetLen;
/* 2102 */       compressedBytes = packet.getByteBuffer();
/* 2103 */       compressedLength = 0;
/* 2104 */       offsetWrite = offset;
/*      */     } else {
/* 2106 */       compressedBytes = new byte[bytesToCompress.length * 2];
/*      */ 
/* 2108 */       this.deflater.reset();
/* 2109 */       this.deflater.setInput(bytesToCompress, offset, packetLen);
/* 2110 */       this.deflater.finish();
/*      */ 
/* 2112 */       int compLen = this.deflater.deflate(compressedBytes);
/*      */ 
/* 2114 */       if (compLen > packetLen) {
/* 2115 */         lengthToWrite = packetLen;
/* 2116 */         compressedBytes = packet.getByteBuffer();
/* 2117 */         compressedLength = 0;
/* 2118 */         offsetWrite = offset;
/*      */       } else {
/* 2120 */         lengthToWrite = compLen;
/* 2121 */         headerLength += 3;
/* 2122 */         compressedLength = packetLen;
/*      */       }
/*      */     }
/*      */ 
/* 2126 */     Buffer compressedPacket = new Buffer(packetLen + headerLength);
/*      */ 
/* 2128 */     compressedPacket.setPosition(0);
/* 2129 */     compressedPacket.writeLongInt(lengthToWrite);
/* 2130 */     compressedPacket.writeByte(this.packetSequence);
/* 2131 */     compressedPacket.writeLongInt(compressedLength);
/* 2132 */     compressedPacket.writeBytesNoNull(compressedBytes, offsetWrite, lengthToWrite);
/*      */ 
/* 2135 */     return compressedPacket;
/*      */   }
/*      */ 
/*      */   private final void readServerStatusForResultSets(Buffer rowPacket) throws SQLException
/*      */   {
/* 2140 */     if (this.use41Extensions) {
/* 2141 */       rowPacket.readByte();
/*      */ 
/* 2143 */       this.warningCount = rowPacket.readInt();
/*      */ 
/* 2145 */       if (this.warningCount > 0) {
/* 2146 */         this.hadWarnings = true;
/*      */       }
/*      */ 
/* 2149 */       this.serverStatus = rowPacket.readInt();
/*      */ 
/* 2151 */       if (this.profileSql) {
/* 2152 */         this.queryNoIndexUsed = ((this.serverStatus & 0x10) != 0);
/*      */ 
/* 2154 */         this.queryBadIndexUsed = ((this.serverStatus & 0x20) != 0);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private SocketFactory createSocketFactory() throws SQLException
/*      */   {
/*      */     try {
/* 2162 */       if (this.socketFactoryClassName == null) {
/* 2163 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.75"), "08001");
/*      */       }
/*      */ 
/* 2167 */       return (SocketFactory)Class.forName(this.socketFactoryClassName).newInstance();
/*      */     }
/*      */     catch (Exception ex) {
/* 2170 */       if (this.connection.getParanoid()) tmpTernaryOp = ""; 
/* 2170 */     }throw SQLError.createSQLException(Messages.getString("MysqlIO.76") + this.socketFactoryClassName + Messages.getString("MysqlIO.77") + ex.toString() + Util.stackTraceToString(ex), "08001");
/*      */   }
/*      */ 
/*      */   private void enqueuePacketForDebugging(boolean isPacketBeingSent, boolean isPacketReused, int sendLength, byte[] header, Buffer packet)
/*      */     throws SQLException
/*      */   {
/* 2182 */     if (this.packetDebugRingBuffer.size() + 1 > this.connection.getPacketDebugBufferSize()) {
/* 2183 */       this.packetDebugRingBuffer.removeFirst();
/*      */     }
/*      */ 
/* 2186 */     StringBuffer packetDump = null;
/*      */ 
/* 2188 */     if (!isPacketBeingSent) {
/* 2189 */       int bytesToDump = Math.min(1024, packet.getBufLength());
/*      */ 
/* 2192 */       Buffer packetToDump = new Buffer(4 + bytesToDump);
/*      */ 
/* 2194 */       packetToDump.setPosition(0);
/* 2195 */       packetToDump.writeBytesNoNull(header);
/* 2196 */       packetToDump.writeBytesNoNull(packet.getBytes(0, bytesToDump));
/*      */ 
/* 2198 */       String packetPayload = packetToDump.dump(bytesToDump);
/*      */ 
/* 2200 */       packetDump = new StringBuffer(96 + packetPayload.length());
/*      */ 
/* 2202 */       packetDump.append("Server ");
/*      */ 
/* 2204 */       if (isPacketReused)
/* 2205 */         packetDump.append("(re-used)");
/*      */       else {
/* 2207 */         packetDump.append("(new)");
/*      */       }
/*      */ 
/* 2210 */       packetDump.append(" ");
/* 2211 */       packetDump.append(packet.toSuperString());
/* 2212 */       packetDump.append(" --------------------> Client\n");
/* 2213 */       packetDump.append("\nPacket payload:\n\n");
/* 2214 */       packetDump.append(packetPayload);
/*      */ 
/* 2216 */       if (bytesToDump == 1024) {
/* 2217 */         packetDump.append("\nNote: Packet of " + packet.getBufLength() + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/* 2222 */       int bytesToDump = Math.min(1024, sendLength);
/*      */ 
/* 2224 */       String packetPayload = packet.dump(bytesToDump);
/*      */ 
/* 2226 */       packetDump = new StringBuffer(68 + packetPayload.length());
/*      */ 
/* 2228 */       packetDump.append("Client ");
/* 2229 */       packetDump.append(packet.toSuperString());
/* 2230 */       packetDump.append("--------------------> Server\n");
/* 2231 */       packetDump.append("\nPacket payload:\n\n");
/* 2232 */       packetDump.append(packetPayload);
/*      */ 
/* 2234 */       if (bytesToDump == 1024) {
/* 2235 */         packetDump.append("\nNote: Packet of " + sendLength + " bytes truncated to " + 1024 + " bytes.\n");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2241 */     this.packetDebugRingBuffer.addLast(packetDump);
/*      */   }
/*      */ 
/*      */   private RowData readSingleRowSet(long columnCount, int maxRows, int resultSetConcurrency, boolean isBinaryEncoded, Field[] fields)
/*      */     throws SQLException
/*      */   {
/* 2248 */     ArrayList rows = new ArrayList();
/*      */ 
/* 2251 */     Object rowBytes = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency);
/*      */ 
/* 2254 */     int rowCount = 0;
/*      */ 
/* 2256 */     if (rowBytes != null) {
/* 2257 */       rows.add(rowBytes);
/* 2258 */       rowCount = 1;
/*      */     }
/*      */ 
/* 2261 */     while (rowBytes != null) {
/* 2262 */       rowBytes = nextRow(fields, (int)columnCount, isBinaryEncoded, resultSetConcurrency);
/*      */ 
/* 2265 */       if ((rowBytes == null) || (
/* 2266 */         (maxRows != -1) && (rowCount >= maxRows))) continue;
/* 2267 */       rows.add(rowBytes);
/* 2268 */       rowCount++;
/*      */     }
/*      */ 
/* 2273 */     RowData rowData = new RowDataStatic(rows);
/*      */ 
/* 2275 */     return rowData;
/*      */   }
/*      */ 
/*      */   private void reclaimLargeReusablePacket()
/*      */   {
/* 2282 */     if ((this.reusablePacket != null) && (this.reusablePacket.getCapacity() > 1048576))
/*      */     {
/* 2284 */       this.reusablePacket = new Buffer(this.connection.getNetBufferLength()); }  } 
/*      */   // ERROR //
/*      */   private final Buffer reuseAndReadPacket(Buffer reuse) throws SQLException { // Byte code:
/*      */     //   0: aload_1
/*      */     //   1: iconst_0
/*      */     //   2: invokevirtual 403	com/mysql/jdbc/Buffer:setWasMultiPacket	(Z)V
/*      */     //   5: aload_0
/*      */     //   6: aload_0
/*      */     //   7: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   10: aload_0
/*      */     //   11: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   14: iconst_0
/*      */     //   15: iconst_4
/*      */     //   16: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   19: istore_2
/*      */     //   20: iload_2
/*      */     //   21: iconst_4
/*      */     //   22: if_icmpge +21 -> 43
/*      */     //   25: aload_0
/*      */     //   26: invokevirtual 109	com/mysql/jdbc/MysqlIO:forceClose	()V
/*      */     //   29: new 83	java/io/IOException
/*      */     //   32: dup
/*      */     //   33: ldc_w 404
/*      */     //   36: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   39: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   42: athrow
/*      */     //   43: aload_0
/*      */     //   44: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   47: iconst_0
/*      */     //   48: baload
/*      */     //   49: sipush 255
/*      */     //   52: iand
/*      */     //   53: aload_0
/*      */     //   54: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   57: iconst_1
/*      */     //   58: baload
/*      */     //   59: sipush 255
/*      */     //   62: iand
/*      */     //   63: bipush 8
/*      */     //   65: ishl
/*      */     //   66: iadd
/*      */     //   67: aload_0
/*      */     //   68: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   71: iconst_2
/*      */     //   72: baload
/*      */     //   73: sipush 255
/*      */     //   76: iand
/*      */     //   77: bipush 16
/*      */     //   79: ishl
/*      */     //   80: iadd
/*      */     //   81: istore_3
/*      */     //   82: aload_0
/*      */     //   83: getfield 48	com/mysql/jdbc/MysqlIO:traceProtocol	Z
/*      */     //   86: ifeq +74 -> 160
/*      */     //   89: new 113	java/lang/StringBuffer
/*      */     //   92: dup
/*      */     //   93: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   96: astore 4
/*      */     //   98: aload 4
/*      */     //   100: ldc_w 405
/*      */     //   103: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   106: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   109: pop
/*      */     //   110: aload 4
/*      */     //   112: iload_3
/*      */     //   113: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   116: pop
/*      */     //   117: aload 4
/*      */     //   119: ldc_w 406
/*      */     //   122: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   125: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   128: pop
/*      */     //   129: aload 4
/*      */     //   131: aload_0
/*      */     //   132: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   135: iconst_4
/*      */     //   136: invokestatic 119	com/mysql/jdbc/StringUtils:dumpAsHex	([BI)Ljava/lang/String;
/*      */     //   139: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   142: pop
/*      */     //   143: aload_0
/*      */     //   144: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   147: invokevirtual 67	com/mysql/jdbc/Connection:getLog	()Lcom/mysql/jdbc/log/Log;
/*      */     //   150: aload 4
/*      */     //   152: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   155: invokeinterface 121 2 0
/*      */     //   160: aload_0
/*      */     //   161: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   164: iconst_3
/*      */     //   165: baload
/*      */     //   166: istore 4
/*      */     //   168: aload_0
/*      */     //   169: getfield 3	com/mysql/jdbc/MysqlIO:packetSequenceReset	Z
/*      */     //   172: ifne +26 -> 198
/*      */     //   175: aload_0
/*      */     //   176: getfield 49	com/mysql/jdbc/MysqlIO:enablePacketDebug	Z
/*      */     //   179: ifeq +24 -> 203
/*      */     //   182: aload_0
/*      */     //   183: getfield 34	com/mysql/jdbc/MysqlIO:checkPacketSequence	Z
/*      */     //   186: ifeq +17 -> 203
/*      */     //   189: aload_0
/*      */     //   190: iload 4
/*      */     //   192: invokespecial 122	com/mysql/jdbc/MysqlIO:checkPacketSequencing	(B)V
/*      */     //   195: goto +8 -> 203
/*      */     //   198: aload_0
/*      */     //   199: iconst_0
/*      */     //   200: putfield 3	com/mysql/jdbc/MysqlIO:packetSequenceReset	Z
/*      */     //   203: aload_0
/*      */     //   204: iload 4
/*      */     //   206: putfield 33	com/mysql/jdbc/MysqlIO:readPacketSequence	B
/*      */     //   209: aload_1
/*      */     //   210: iconst_0
/*      */     //   211: invokevirtual 210	com/mysql/jdbc/Buffer:setPosition	(I)V
/*      */     //   214: aload_1
/*      */     //   215: invokevirtual 139	com/mysql/jdbc/Buffer:getByteBuffer	()[B
/*      */     //   218: arraylength
/*      */     //   219: iload_3
/*      */     //   220: if_icmpgt +12 -> 232
/*      */     //   223: aload_1
/*      */     //   224: iload_3
/*      */     //   225: iconst_1
/*      */     //   226: iadd
/*      */     //   227: newarray byte
/*      */     //   229: invokevirtual 407	com/mysql/jdbc/Buffer:setByteBuffer	([B)V
/*      */     //   232: aload_1
/*      */     //   233: iload_3
/*      */     //   234: invokevirtual 126	com/mysql/jdbc/Buffer:setBufLength	(I)V
/*      */     //   237: aload_0
/*      */     //   238: aload_0
/*      */     //   239: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   242: aload_1
/*      */     //   243: invokevirtual 139	com/mysql/jdbc/Buffer:getByteBuffer	()[B
/*      */     //   246: iconst_0
/*      */     //   247: iload_3
/*      */     //   248: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   251: istore 5
/*      */     //   253: iload 5
/*      */     //   255: iload_3
/*      */     //   256: if_icmpeq +40 -> 296
/*      */     //   259: new 83	java/io/IOException
/*      */     //   262: dup
/*      */     //   263: new 113	java/lang/StringBuffer
/*      */     //   266: dup
/*      */     //   267: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   270: ldc 123
/*      */     //   272: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   275: iload_3
/*      */     //   276: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   279: ldc 124
/*      */     //   281: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   284: iload 5
/*      */     //   286: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   289: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   292: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   295: athrow
/*      */     //   296: aload_0
/*      */     //   297: getfield 48	com/mysql/jdbc/MysqlIO:traceProtocol	Z
/*      */     //   300: ifeq +52 -> 352
/*      */     //   303: new 113	java/lang/StringBuffer
/*      */     //   306: dup
/*      */     //   307: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   310: astore 6
/*      */     //   312: aload 6
/*      */     //   314: ldc_w 408
/*      */     //   317: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   320: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   323: pop
/*      */     //   324: aload 6
/*      */     //   326: aload_1
/*      */     //   327: iload_3
/*      */     //   328: invokestatic 128	com/mysql/jdbc/MysqlIO:getPacketDumpToLog	(Lcom/mysql/jdbc/Buffer;I)Ljava/lang/String;
/*      */     //   331: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   334: pop
/*      */     //   335: aload_0
/*      */     //   336: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   339: invokevirtual 67	com/mysql/jdbc/Connection:getLog	()Lcom/mysql/jdbc/log/Log;
/*      */     //   342: aload 6
/*      */     //   344: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   347: invokeinterface 121 2 0
/*      */     //   352: aload_0
/*      */     //   353: getfield 49	com/mysql/jdbc/MysqlIO:enablePacketDebug	Z
/*      */     //   356: ifeq +15 -> 371
/*      */     //   359: aload_0
/*      */     //   360: iconst_0
/*      */     //   361: iconst_1
/*      */     //   362: iconst_0
/*      */     //   363: aload_0
/*      */     //   364: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   367: aload_1
/*      */     //   368: invokespecial 129	com/mysql/jdbc/MysqlIO:enqueuePacketForDebugging	(ZZI[BLcom/mysql/jdbc/Buffer;)V
/*      */     //   371: iconst_0
/*      */     //   372: istore 6
/*      */     //   374: iload_3
/*      */     //   375: aload_0
/*      */     //   376: getfield 39	com/mysql/jdbc/MysqlIO:maxThreeBytes	I
/*      */     //   379: if_icmpne +558 -> 937
/*      */     //   382: aload_1
/*      */     //   383: aload_0
/*      */     //   384: getfield 39	com/mysql/jdbc/MysqlIO:maxThreeBytes	I
/*      */     //   387: invokevirtual 210	com/mysql/jdbc/Buffer:setPosition	(I)V
/*      */     //   390: iload_3
/*      */     //   391: istore 7
/*      */     //   393: iconst_1
/*      */     //   394: istore 6
/*      */     //   396: aload_0
/*      */     //   397: aload_0
/*      */     //   398: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   401: aload_0
/*      */     //   402: iconst_4
/*      */     //   403: newarray byte
/*      */     //   405: dup_x1
/*      */     //   406: putfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   409: iconst_0
/*      */     //   410: iconst_4
/*      */     //   411: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   414: istore_2
/*      */     //   415: iload_2
/*      */     //   416: iconst_4
/*      */     //   417: if_icmpge +21 -> 438
/*      */     //   420: aload_0
/*      */     //   421: invokevirtual 109	com/mysql/jdbc/MysqlIO:forceClose	()V
/*      */     //   424: new 83	java/io/IOException
/*      */     //   427: dup
/*      */     //   428: ldc_w 409
/*      */     //   431: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   434: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   437: athrow
/*      */     //   438: aload_0
/*      */     //   439: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   442: iconst_0
/*      */     //   443: baload
/*      */     //   444: sipush 255
/*      */     //   447: iand
/*      */     //   448: aload_0
/*      */     //   449: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   452: iconst_1
/*      */     //   453: baload
/*      */     //   454: sipush 255
/*      */     //   457: iand
/*      */     //   458: bipush 8
/*      */     //   460: ishl
/*      */     //   461: iadd
/*      */     //   462: aload_0
/*      */     //   463: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   466: iconst_2
/*      */     //   467: baload
/*      */     //   468: sipush 255
/*      */     //   471: iand
/*      */     //   472: bipush 16
/*      */     //   474: ishl
/*      */     //   475: iadd
/*      */     //   476: istore_3
/*      */     //   477: new 55	com/mysql/jdbc/Buffer
/*      */     //   480: dup
/*      */     //   481: iload_3
/*      */     //   482: invokespecial 57	com/mysql/jdbc/Buffer:<init>	(I)V
/*      */     //   485: astore 8
/*      */     //   487: iconst_1
/*      */     //   488: istore 9
/*      */     //   490: iload 9
/*      */     //   492: ifne +87 -> 579
/*      */     //   495: aload_0
/*      */     //   496: aload_0
/*      */     //   497: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   500: aload_0
/*      */     //   501: iconst_4
/*      */     //   502: newarray byte
/*      */     //   504: dup_x1
/*      */     //   505: putfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   508: iconst_0
/*      */     //   509: iconst_4
/*      */     //   510: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   513: istore_2
/*      */     //   514: iload_2
/*      */     //   515: iconst_4
/*      */     //   516: if_icmpge +21 -> 537
/*      */     //   519: aload_0
/*      */     //   520: invokevirtual 109	com/mysql/jdbc/MysqlIO:forceClose	()V
/*      */     //   523: new 83	java/io/IOException
/*      */     //   526: dup
/*      */     //   527: ldc_w 410
/*      */     //   530: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   533: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   536: athrow
/*      */     //   537: aload_0
/*      */     //   538: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   541: iconst_0
/*      */     //   542: baload
/*      */     //   543: sipush 255
/*      */     //   546: iand
/*      */     //   547: aload_0
/*      */     //   548: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   551: iconst_1
/*      */     //   552: baload
/*      */     //   553: sipush 255
/*      */     //   556: iand
/*      */     //   557: bipush 8
/*      */     //   559: ishl
/*      */     //   560: iadd
/*      */     //   561: aload_0
/*      */     //   562: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   565: iconst_2
/*      */     //   566: baload
/*      */     //   567: sipush 255
/*      */     //   570: iand
/*      */     //   571: bipush 16
/*      */     //   573: ishl
/*      */     //   574: iadd
/*      */     //   575: istore_3
/*      */     //   576: goto +6 -> 582
/*      */     //   579: iconst_0
/*      */     //   580: istore 9
/*      */     //   582: aload_0
/*      */     //   583: getfield 30	com/mysql/jdbc/MysqlIO:useNewLargePackets	Z
/*      */     //   586: ifne +15 -> 601
/*      */     //   589: iload_3
/*      */     //   590: iconst_1
/*      */     //   591: if_icmpne +10 -> 601
/*      */     //   594: aload_0
/*      */     //   595: invokevirtual 275	com/mysql/jdbc/MysqlIO:clearInputStream	()V
/*      */     //   598: goto +329 -> 927
/*      */     //   601: iload_3
/*      */     //   602: aload_0
/*      */     //   603: getfield 39	com/mysql/jdbc/MysqlIO:maxThreeBytes	I
/*      */     //   606: if_icmpge +162 -> 768
/*      */     //   609: aload_0
/*      */     //   610: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   613: iconst_3
/*      */     //   614: baload
/*      */     //   615: istore 10
/*      */     //   617: iload 10
/*      */     //   619: iload 4
/*      */     //   621: iconst_1
/*      */     //   622: iadd
/*      */     //   623: if_icmpeq +17 -> 640
/*      */     //   626: new 83	java/io/IOException
/*      */     //   629: dup
/*      */     //   630: ldc_w 411
/*      */     //   633: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   636: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   639: athrow
/*      */     //   640: iload 10
/*      */     //   642: istore 4
/*      */     //   644: aload 8
/*      */     //   646: iconst_0
/*      */     //   647: invokevirtual 210	com/mysql/jdbc/Buffer:setPosition	(I)V
/*      */     //   650: aload 8
/*      */     //   652: iload_3
/*      */     //   653: invokevirtual 126	com/mysql/jdbc/Buffer:setBufLength	(I)V
/*      */     //   656: aload 8
/*      */     //   658: invokevirtual 139	com/mysql/jdbc/Buffer:getByteBuffer	()[B
/*      */     //   661: astore 11
/*      */     //   663: iload_3
/*      */     //   664: istore 12
/*      */     //   666: aload_0
/*      */     //   667: aload_0
/*      */     //   668: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   671: aload 11
/*      */     //   673: iconst_0
/*      */     //   674: iload_3
/*      */     //   675: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   678: istore 13
/*      */     //   680: iload 13
/*      */     //   682: iload 12
/*      */     //   684: if_icmpeq +65 -> 749
/*      */     //   687: new 84	com/mysql/jdbc/CommunicationsException
/*      */     //   690: dup
/*      */     //   691: aload_0
/*      */     //   692: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   695: aload_0
/*      */     //   696: getfield 47	com/mysql/jdbc/MysqlIO:lastPacketSentTimeMs	J
/*      */     //   699: new 113	java/lang/StringBuffer
/*      */     //   702: dup
/*      */     //   703: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   706: ldc_w 412
/*      */     //   709: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   712: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   715: iload 12
/*      */     //   717: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   720: ldc_w 413
/*      */     //   723: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   726: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   729: iload 13
/*      */     //   731: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   734: ldc 200
/*      */     //   736: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   739: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   742: invokestatic 269	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   745: invokespecial 85	com/mysql/jdbc/CommunicationsException:<init>	(Lcom/mysql/jdbc/Connection;JLjava/lang/Exception;)V
/*      */     //   748: athrow
/*      */     //   749: aload_1
/*      */     //   750: aload 11
/*      */     //   752: iconst_0
/*      */     //   753: iload 12
/*      */     //   755: invokevirtual 370	com/mysql/jdbc/Buffer:writeBytesNoNull	([BII)V
/*      */     //   758: iload 7
/*      */     //   760: iload 12
/*      */     //   762: iadd
/*      */     //   763: istore 7
/*      */     //   765: goto +162 -> 927
/*      */     //   768: aload_0
/*      */     //   769: getfield 17	com/mysql/jdbc/MysqlIO:packetHeaderBuf	[B
/*      */     //   772: iconst_3
/*      */     //   773: baload
/*      */     //   774: istore 10
/*      */     //   776: iload 10
/*      */     //   778: iload 4
/*      */     //   780: iconst_1
/*      */     //   781: iadd
/*      */     //   782: if_icmpeq +17 -> 799
/*      */     //   785: new 83	java/io/IOException
/*      */     //   788: dup
/*      */     //   789: ldc_w 414
/*      */     //   792: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   795: invokespecial 112	java/io/IOException:<init>	(Ljava/lang/String;)V
/*      */     //   798: athrow
/*      */     //   799: iload 10
/*      */     //   801: istore 4
/*      */     //   803: aload 8
/*      */     //   805: iconst_0
/*      */     //   806: invokevirtual 210	com/mysql/jdbc/Buffer:setPosition	(I)V
/*      */     //   809: aload 8
/*      */     //   811: iload_3
/*      */     //   812: invokevirtual 126	com/mysql/jdbc/Buffer:setBufLength	(I)V
/*      */     //   815: aload 8
/*      */     //   817: invokevirtual 139	com/mysql/jdbc/Buffer:getByteBuffer	()[B
/*      */     //   820: astore 11
/*      */     //   822: iload_3
/*      */     //   823: istore 12
/*      */     //   825: aload_0
/*      */     //   826: aload_0
/*      */     //   827: getfield 9	com/mysql/jdbc/MysqlIO:mysqlInput	Ljava/io/InputStream;
/*      */     //   830: aload 11
/*      */     //   832: iconst_0
/*      */     //   833: iload_3
/*      */     //   834: invokespecial 108	com/mysql/jdbc/MysqlIO:readFully	(Ljava/io/InputStream;[BII)I
/*      */     //   837: istore 13
/*      */     //   839: iload 13
/*      */     //   841: iload 12
/*      */     //   843: if_icmpeq +65 -> 908
/*      */     //   846: new 84	com/mysql/jdbc/CommunicationsException
/*      */     //   849: dup
/*      */     //   850: aload_0
/*      */     //   851: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   854: aload_0
/*      */     //   855: getfield 47	com/mysql/jdbc/MysqlIO:lastPacketSentTimeMs	J
/*      */     //   858: new 113	java/lang/StringBuffer
/*      */     //   861: dup
/*      */     //   862: invokespecial 114	java/lang/StringBuffer:<init>	()V
/*      */     //   865: ldc_w 415
/*      */     //   868: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   871: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   874: iload 12
/*      */     //   876: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   879: ldc_w 416
/*      */     //   882: invokestatic 111	com/mysql/jdbc/Messages:getString	(Ljava/lang/String;)Ljava/lang/String;
/*      */     //   885: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   888: iload 13
/*      */     //   890: invokevirtual 117	java/lang/StringBuffer:append	(I)Ljava/lang/StringBuffer;
/*      */     //   893: ldc 200
/*      */     //   895: invokevirtual 116	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
/*      */     //   898: invokevirtual 120	java/lang/StringBuffer:toString	()Ljava/lang/String;
/*      */     //   901: invokestatic 269	com/mysql/jdbc/SQLError:createSQLException	(Ljava/lang/String;)Ljava/sql/SQLException;
/*      */     //   904: invokespecial 85	com/mysql/jdbc/CommunicationsException:<init>	(Lcom/mysql/jdbc/Connection;JLjava/lang/Exception;)V
/*      */     //   907: athrow
/*      */     //   908: aload_1
/*      */     //   909: aload 11
/*      */     //   911: iconst_0
/*      */     //   912: iload 12
/*      */     //   914: invokevirtual 370	com/mysql/jdbc/Buffer:writeBytesNoNull	([BII)V
/*      */     //   917: iload 7
/*      */     //   919: iload 12
/*      */     //   921: iadd
/*      */     //   922: istore 7
/*      */     //   924: goto -434 -> 490
/*      */     //   927: aload_1
/*      */     //   928: iconst_0
/*      */     //   929: invokevirtual 210	com/mysql/jdbc/Buffer:setPosition	(I)V
/*      */     //   932: aload_1
/*      */     //   933: iconst_1
/*      */     //   934: invokevirtual 403	com/mysql/jdbc/Buffer:setWasMultiPacket	(Z)V
/*      */     //   937: iload 6
/*      */     //   939: ifne +10 -> 949
/*      */     //   942: aload_1
/*      */     //   943: invokevirtual 139	com/mysql/jdbc/Buffer:getByteBuffer	()[B
/*      */     //   946: iload_3
/*      */     //   947: iconst_0
/*      */     //   948: bastore
/*      */     //   949: aload_1
/*      */     //   950: areturn
/*      */     //   951: astore_2
/*      */     //   952: new 84	com/mysql/jdbc/CommunicationsException
/*      */     //   955: dup
/*      */     //   956: aload_0
/*      */     //   957: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   960: aload_0
/*      */     //   961: getfield 47	com/mysql/jdbc/MysqlIO:lastPacketSentTimeMs	J
/*      */     //   964: aload_2
/*      */     //   965: invokespecial 85	com/mysql/jdbc/CommunicationsException:<init>	(Lcom/mysql/jdbc/Connection;JLjava/lang/Exception;)V
/*      */     //   968: athrow
/*      */     //   969: astore_2
/*      */     //   970: aload_0
/*      */     //   971: invokevirtual 275	com/mysql/jdbc/MysqlIO:clearInputStream	()V
/*      */     //   974: jsr +14 -> 988
/*      */     //   977: goto +30 -> 1007
/*      */     //   980: astore 14
/*      */     //   982: jsr +6 -> 988
/*      */     //   985: aload 14
/*      */     //   987: athrow
/*      */     //   988: astore 15
/*      */     //   990: aload_0
/*      */     //   991: getfield 50	com/mysql/jdbc/MysqlIO:connection	Lcom/mysql/jdbc/Connection;
/*      */     //   994: iconst_0
/*      */     //   995: iconst_0
/*      */     //   996: iconst_1
/*      */     //   997: aload_2
/*      */     //   998: invokevirtual 131	com/mysql/jdbc/Connection:realClose	(ZZZLjava/lang/Throwable;)V
/*      */     //   1001: aload_2
/*      */     //   1002: athrow
/*      */     //   1003: astore 16
/*      */     //   1005: aload_2
/*      */     //   1006: athrow
/*      */     //   1007: goto +0 -> 1007
/*      */     //
/*      */     // Exception table:
/*      */     //   from	to	target	type
/*      */     //   0	950	951	java/io/IOException
/*      */     //   0	950	969	java/lang/OutOfMemoryError
/*      */     //   970	977	980	finally
/*      */     //   980	985	980	finally
/*      */     //   990	1001	1003	finally
/*      */     //   1003	1005	1003	finally } 
/* 2538 */   private void checkPacketSequencing(byte multiPacketSeq) throws CommunicationsException { if ((multiPacketSeq == -128) && (this.readPacketSequence != 127)) {
/* 2539 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, new IOException("Packets out of order, expected packet # -128, but received packet # " + multiPacketSeq));
/*      */     }
/*      */ 
/* 2545 */     if ((this.readPacketSequence == -1) && (multiPacketSeq != 0)) {
/* 2546 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, new IOException("Packets out of order, expected packet # -1, but received packet # " + multiPacketSeq));
/*      */     }
/*      */ 
/* 2552 */     if ((multiPacketSeq != -128) && (this.readPacketSequence != -1) && (multiPacketSeq != this.readPacketSequence + 1))
/*      */     {
/* 2554 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, new IOException("Packets out of order, expected packet # " + (this.readPacketSequence + 1) + ", but received packet # " + multiPacketSeq));
/*      */     }
/*      */   }
/*      */ 
/*      */   void enableMultiQueries()
/*      */     throws SQLException
/*      */   {
/* 2563 */     Buffer buf = getSharedSendPacket();
/*      */ 
/* 2565 */     buf.clear();
/* 2566 */     buf.writeByte(27);
/* 2567 */     buf.writeInt(0);
/* 2568 */     sendCommand(27, null, buf, false, null);
/*      */   }
/*      */ 
/*      */   void disableMultiQueries() throws SQLException {
/* 2572 */     Buffer buf = getSharedSendPacket();
/*      */ 
/* 2574 */     buf.clear();
/* 2575 */     buf.writeByte(27);
/* 2576 */     buf.writeInt(1);
/* 2577 */     sendCommand(27, null, buf, false, null);
/*      */   }
/*      */ 
/*      */   private final void send(Buffer packet, int packetLen) throws SQLException
/*      */   {
/*      */     try {
/* 2583 */       if (packetLen > this.maxAllowedPacket) {
/* 2584 */         throw new PacketTooBigException(packetLen, this.maxAllowedPacket);
/*      */       }
/*      */ 
/* 2587 */       if (this.connection.getMaintainTimeStats()) {
/* 2588 */         this.lastPacketSentTimeMs = System.currentTimeMillis();
/*      */       }
/*      */ 
/* 2591 */       if ((this.serverMajorVersion >= 4) && (packetLen >= this.maxThreeBytes))
/*      */       {
/* 2593 */         sendSplitPackets(packet);
/*      */       } else {
/* 2595 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */ 
/* 2597 */         Buffer packetToSend = packet;
/*      */ 
/* 2599 */         packetToSend.setPosition(0);
/*      */ 
/* 2601 */         if (this.useCompression) {
/* 2602 */           int originalPacketLen = packetLen;
/*      */ 
/* 2604 */           packetToSend = compressPacket(packet, 0, packetLen, 4);
/*      */ 
/* 2606 */           packetLen = packetToSend.getPosition();
/*      */ 
/* 2608 */           if (this.traceProtocol) {
/* 2609 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */ 
/* 2611 */             traceMessageBuf.append(Messages.getString("MysqlIO.57"));
/* 2612 */             traceMessageBuf.append(getPacketDumpToLog(packetToSend, packetLen));
/*      */ 
/* 2614 */             traceMessageBuf.append(Messages.getString("MysqlIO.58"));
/* 2615 */             traceMessageBuf.append(getPacketDumpToLog(packet, originalPacketLen));
/*      */ 
/* 2618 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */         } else {
/* 2621 */           packetToSend.writeLongInt(packetLen - 4);
/* 2622 */           packetToSend.writeByte(this.packetSequence);
/*      */ 
/* 2624 */           if (this.traceProtocol) {
/* 2625 */             StringBuffer traceMessageBuf = new StringBuffer();
/*      */ 
/* 2627 */             traceMessageBuf.append(Messages.getString("MysqlIO.59"));
/* 2628 */             traceMessageBuf.append(packetToSend.dump(packetLen));
/*      */ 
/* 2630 */             this.connection.getLog().logTrace(traceMessageBuf.toString());
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/* 2635 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */ 
/* 2637 */         this.mysqlOutput.flush();
/*      */       }
/*      */ 
/* 2640 */       if (this.enablePacketDebug) {
/* 2641 */         enqueuePacketForDebugging(true, false, packetLen + 5, this.packetHeaderBuf, packet);
/*      */       }
/*      */ 
/* 2648 */       if (packet == this.sharedSendPacket)
/* 2649 */         reclaimLargeSharedSendPacket();
/*      */     }
/*      */     catch (IOException ioEx) {
/* 2652 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ioEx);
/*      */     }
/*      */   }
/*      */ 
/*      */   private final ResultSet sendFileToServer(Statement callingStatement, String fileName)
/*      */     throws SQLException
/*      */   {
/* 2670 */     Buffer filePacket = this.loadFileBufRef == null ? null : (Buffer)this.loadFileBufRef.get();
/*      */ 
/* 2673 */     int bigPacketLength = Math.min(this.connection.getMaxAllowedPacket() - 12, alignPacketSize(this.connection.getMaxAllowedPacket() - 16, 4096) - 12);
/*      */ 
/* 2678 */     int oneMeg = 1048576;
/*      */ 
/* 2680 */     int smallerPacketSizeAligned = Math.min(oneMeg - 12, alignPacketSize(oneMeg - 16, 4096) - 12);
/*      */ 
/* 2683 */     int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
/*      */ 
/* 2685 */     if (filePacket == null) {
/*      */       try {
/* 2687 */         filePacket = new Buffer(packetLength + 4);
/* 2688 */         this.loadFileBufRef = new SoftReference(filePacket);
/*      */       } catch (OutOfMemoryError oom) {
/* 2690 */         throw SQLError.createSQLException("Could not allocate packet of " + packetLength + " bytes required for LOAD DATA LOCAL INFILE operation." + " Try increasing max heap allocation for JVM or decreasing server variable " + "'max_allowed_packet'", "S1001");
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2698 */     filePacket.clear();
/* 2699 */     send(filePacket, 0);
/*      */ 
/* 2701 */     byte[] fileBuf = new byte[packetLength];
/*      */ 
/* 2703 */     BufferedInputStream fileIn = null;
/*      */     try
/*      */     {
/* 2706 */       if (!this.connection.getAllowUrlInLocalInfile()) {
/* 2707 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       }
/* 2710 */       else if (fileName.indexOf(":") != -1) {
/*      */         try {
/* 2712 */           URL urlFromFileName = new URL(fileName);
/* 2713 */           fileIn = new BufferedInputStream(urlFromFileName.openStream());
/*      */         }
/*      */         catch (MalformedURLException badUrlEx) {
/* 2716 */           fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */         }
/*      */       }
/*      */       else {
/* 2720 */         fileIn = new BufferedInputStream(new FileInputStream(fileName));
/*      */       }
/*      */ 
/* 2725 */       int bytesRead = 0;
/*      */ 
/* 2727 */       while ((bytesRead = fileIn.read(fileBuf)) != -1) {
/* 2728 */         filePacket.clear();
/* 2729 */         filePacket.writeBytesNoNull(fileBuf, 0, bytesRead);
/* 2730 */         send(filePacket, filePacket.getPosition());
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 2733 */       StringBuffer messageBuf = new StringBuffer(Messages.getString("MysqlIO.60"));
/*      */ 
/* 2736 */       if (!this.connection.getParanoid()) {
/* 2737 */         messageBuf.append("'");
/*      */ 
/* 2739 */         if (fileName != null) {
/* 2740 */           messageBuf.append(fileName);
/*      */         }
/*      */ 
/* 2743 */         messageBuf.append("'");
/*      */       }
/*      */ 
/* 2746 */       messageBuf.append(Messages.getString("MysqlIO.63"));
/*      */ 
/* 2748 */       if (!this.connection.getParanoid()) {
/* 2749 */         messageBuf.append(Messages.getString("MysqlIO.64"));
/* 2750 */         messageBuf.append(Util.stackTraceToString(ioEx));
/*      */       }
/*      */ 
/* 2753 */       throw SQLError.createSQLException(messageBuf.toString(), "S1009");
/*      */     }
/*      */     finally {
/* 2756 */       if (fileIn != null) {
/*      */         try {
/* 2758 */           fileIn.close();
/*      */         } catch (Exception ex) {
/* 2760 */           throw SQLError.createSQLException(Messages.getString("MysqlIO.65"), "S1000");
/*      */         }
/*      */ 
/* 2764 */         fileIn = null;
/*      */       }
/*      */       else {
/* 2767 */         filePacket.clear();
/* 2768 */         send(filePacket, filePacket.getPosition());
/* 2769 */         checkErrorPacket();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 2774 */     filePacket.clear();
/* 2775 */     send(filePacket, filePacket.getPosition());
/*      */ 
/* 2777 */     Buffer resultPacket = checkErrorPacket();
/*      */ 
/* 2779 */     return buildResultSetWithUpdates(callingStatement, resultPacket);
/*      */   }
/*      */ 
/*      */   private Buffer checkErrorPacket(int command)
/*      */     throws SQLException
/*      */   {
/* 2794 */     int statusCode = 0;
/* 2795 */     Buffer resultPacket = null;
/* 2796 */     this.serverStatus = 0;
/*      */     try
/*      */     {
/* 2803 */       resultPacket = reuseAndReadPacket(this.reusablePacket);
/* 2804 */       statusCode = resultPacket.readByte();
/*      */     }
/*      */     catch (SQLException sqlEx) {
/* 2807 */       throw sqlEx;
/*      */     } catch (Exception fallThru) {
/* 2809 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, fallThru);
/*      */     }
/*      */ 
/* 2814 */     if (statusCode == -1)
/*      */     {
/* 2816 */       int errno = 2000;
/*      */ 
/* 2818 */       if (this.protocolVersion > 9) {
/* 2819 */         errno = resultPacket.readInt();
/*      */ 
/* 2821 */         String xOpen = null;
/*      */ 
/* 2823 */         String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding());
/*      */ 
/* 2826 */         if (serverErrorMessage.startsWith("#"))
/*      */         {
/* 2829 */           if (serverErrorMessage.length() > 6) {
/* 2830 */             xOpen = serverErrorMessage.substring(1, 6);
/* 2831 */             serverErrorMessage = serverErrorMessage.substring(6);
/*      */ 
/* 2833 */             if (xOpen.equals("HY000"))
/* 2834 */               xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           }
/*      */           else
/*      */           {
/* 2838 */             xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */           }
/*      */         }
/*      */         else {
/* 2842 */           xOpen = SQLError.mysqlToSqlState(errno, this.connection.getUseSqlStateCodes());
/*      */         }
/*      */ 
/* 2846 */         clearInputStream();
/*      */ 
/* 2848 */         StringBuffer errorBuf = new StringBuffer();
/*      */ 
/* 2850 */         String xOpenErrorMessage = SQLError.get(xOpen);
/*      */ 
/* 2852 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 2853 */           (xOpenErrorMessage != null)) {
/* 2854 */           errorBuf.append(xOpenErrorMessage);
/* 2855 */           errorBuf.append(Messages.getString("MysqlIO.68"));
/*      */         }
/*      */ 
/* 2859 */         errorBuf.append(serverErrorMessage);
/*      */ 
/* 2861 */         if ((!this.connection.getUseOnlyServerErrorMessages()) && 
/* 2862 */           (xOpenErrorMessage != null)) {
/* 2863 */           errorBuf.append("\"");
/*      */         }
/*      */ 
/* 2867 */         if ((xOpen != null) && (xOpen.startsWith("22"))) {
/* 2868 */           throw new MysqlDataTruncation(errorBuf.toString(), 0, true, false, 0, 0);
/*      */         }
/* 2870 */         throw SQLError.createSQLException(errorBuf.toString(), xOpen, errno);
/*      */       }
/*      */ 
/* 2874 */       String serverErrorMessage = resultPacket.readString(this.connection.getErrorMessageEncoding());
/*      */ 
/* 2876 */       clearInputStream();
/*      */ 
/* 2878 */       if (serverErrorMessage.indexOf(Messages.getString("MysqlIO.70")) != -1) {
/* 2879 */         throw SQLError.createSQLException(SQLError.get("S0022") + ", " + serverErrorMessage, "S0022", -1);
/*      */       }
/*      */ 
/* 2886 */       StringBuffer errorBuf = new StringBuffer(Messages.getString("MysqlIO.72"));
/*      */ 
/* 2888 */       errorBuf.append(serverErrorMessage);
/* 2889 */       errorBuf.append("\"");
/*      */ 
/* 2891 */       throw SQLError.createSQLException(SQLError.get("S1000") + ", " + errorBuf.toString(), "S1000", -1);
/*      */     }
/*      */ 
/* 2896 */     return resultPacket;
/*      */   }
/*      */ 
/*      */   private final void sendSplitPackets(Buffer packet)
/*      */     throws SQLException
/*      */   {
/*      */     try
/*      */     {
/* 2919 */       Buffer headerPacket = this.splitBufRef == null ? null : (Buffer)this.splitBufRef.get();
/*      */ 
/* 2927 */       if (headerPacket == null) {
/* 2928 */         headerPacket = new Buffer(this.maxThreeBytes + 4);
/*      */ 
/* 2930 */         this.splitBufRef = new SoftReference(headerPacket);
/*      */       }
/*      */ 
/* 2933 */       int len = packet.getPosition();
/* 2934 */       int splitSize = this.maxThreeBytes;
/* 2935 */       int originalPacketPos = 4;
/* 2936 */       byte[] origPacketBytes = packet.getByteBuffer();
/* 2937 */       byte[] headerPacketBytes = headerPacket.getByteBuffer();
/*      */ 
/* 2939 */       while (len >= this.maxThreeBytes) {
/* 2940 */         this.packetSequence = (byte)(this.packetSequence + 1);
/*      */ 
/* 2942 */         headerPacket.setPosition(0);
/* 2943 */         headerPacket.writeLongInt(splitSize);
/*      */ 
/* 2945 */         headerPacket.writeByte(this.packetSequence);
/* 2946 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, splitSize);
/*      */ 
/* 2949 */         int packetLen = splitSize + 4;
/*      */ 
/* 2955 */         if (!this.useCompression) {
/* 2956 */           this.mysqlOutput.write(headerPacketBytes, 0, splitSize + 4);
/*      */ 
/* 2958 */           this.mysqlOutput.flush();
/*      */         }
/*      */         else
/*      */         {
/* 2962 */           headerPacket.setPosition(0);
/* 2963 */           Buffer packetToSend = compressPacket(headerPacket, 4, splitSize, 4);
/*      */ 
/* 2965 */           packetLen = packetToSend.getPosition();
/*      */ 
/* 2967 */           this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */ 
/* 2969 */           this.mysqlOutput.flush();
/*      */         }
/*      */ 
/* 2972 */         originalPacketPos += splitSize;
/* 2973 */         len -= splitSize;
/*      */       }
/*      */ 
/* 2979 */       headerPacket.clear();
/* 2980 */       headerPacket.setPosition(0);
/* 2981 */       headerPacket.writeLongInt(len - 4);
/* 2982 */       this.packetSequence = (byte)(this.packetSequence + 1);
/* 2983 */       headerPacket.writeByte(this.packetSequence);
/*      */ 
/* 2985 */       if (len != 0) {
/* 2986 */         System.arraycopy(origPacketBytes, originalPacketPos, headerPacketBytes, 4, len - 4);
/*      */       }
/*      */ 
/* 2990 */       int packetLen = len - 4;
/*      */ 
/* 2996 */       if (!this.useCompression) {
/* 2997 */         this.mysqlOutput.write(headerPacket.getByteBuffer(), 0, len);
/* 2998 */         this.mysqlOutput.flush();
/*      */       }
/*      */       else
/*      */       {
/* 3002 */         headerPacket.setPosition(0);
/* 3003 */         Buffer packetToSend = compressPacket(headerPacket, 4, packetLen, 4);
/*      */ 
/* 3005 */         packetLen = packetToSend.getPosition();
/*      */ 
/* 3007 */         this.mysqlOutput.write(packetToSend.getByteBuffer(), 0, packetLen);
/*      */ 
/* 3009 */         this.mysqlOutput.flush();
/*      */       }
/*      */     } catch (IOException ioEx) {
/* 3012 */       throw new CommunicationsException(this.connection, this.lastPacketSentTimeMs, ioEx);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void reclaimLargeSharedSendPacket()
/*      */   {
/* 3018 */     if ((this.sharedSendPacket != null) && (this.sharedSendPacket.getCapacity() > 1048576))
/*      */     {
/* 3020 */       this.sharedSendPacket = new Buffer(this.connection.getNetBufferLength());
/*      */     }
/*      */   }
/*      */ 
/*      */   boolean hadWarnings() {
/* 3025 */     return this.hadWarnings;
/*      */   }
/*      */ 
/*      */   void scanForAndThrowDataTruncation() throws SQLException {
/* 3029 */     if ((this.streamingData == null) && (versionMeetsMinimum(4, 1, 0)) && (this.connection.getJdbcCompliantTruncation()))
/*      */     {
/* 3031 */       SQLError.convertShowWarningsToSQLWarnings(this.connection, this.warningCount, true);
/*      */     }
/*      */   }
/*      */ 
/*      */   private void secureAuth(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 3052 */     if (packet == null) {
/* 3053 */       packet = new Buffer(packLength);
/*      */     }
/*      */ 
/* 3056 */     if (writeClientParams) {
/* 3057 */       if (this.use41Extensions) {
/* 3058 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 3059 */           packet.writeLong(this.clientParam);
/* 3060 */           packet.writeLong(this.maxThreeBytes);
/*      */ 
/* 3065 */           packet.writeByte(8);
/*      */ 
/* 3068 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 3070 */           packet.writeLong(this.clientParam);
/* 3071 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 3074 */         packet.writeInt((int)this.clientParam);
/* 3075 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3080 */     packet.writeString(user, "Cp1252", this.connection);
/*      */ 
/* 3082 */     if (password.length() != 0)
/*      */     {
/* 3084 */       packet.writeString("xxxxxxxx", "Cp1252", this.connection);
/*      */     }
/*      */     else {
/* 3087 */       packet.writeString("", "Cp1252", this.connection);
/*      */     }
/*      */ 
/* 3090 */     if (this.useConnectWithDb) {
/* 3091 */       packet.writeString(database, "Cp1252", this.connection);
/*      */     }
/*      */ 
/* 3094 */     send(packet, packet.getPosition());
/*      */ 
/* 3099 */     if (password.length() > 0) {
/* 3100 */       Buffer b = readPacket();
/*      */ 
/* 3102 */       b.setPosition(0);
/*      */ 
/* 3104 */       byte[] replyAsBytes = b.getByteBuffer();
/*      */ 
/* 3106 */       if ((replyAsBytes.length == 25) && (replyAsBytes[0] != 0))
/*      */       {
/* 3108 */         if (replyAsBytes[0] != 42) {
/*      */           try
/*      */           {
/* 3111 */             byte[] buff = Security.passwordHashStage1(password);
/*      */ 
/* 3114 */             byte[] passwordHash = new byte[buff.length];
/* 3115 */             System.arraycopy(buff, 0, passwordHash, 0, buff.length);
/*      */ 
/* 3118 */             passwordHash = Security.passwordHashStage2(passwordHash, replyAsBytes);
/*      */ 
/* 3121 */             byte[] packetDataAfterSalt = new byte[replyAsBytes.length - 5];
/*      */ 
/* 3124 */             System.arraycopy(replyAsBytes, 4, packetDataAfterSalt, 0, replyAsBytes.length - 5);
/*      */ 
/* 3127 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/* 3130 */             Security.passwordCrypt(packetDataAfterSalt, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/* 3134 */             Security.passwordCrypt(mysqlScrambleBuff, buff, buff, 20);
/*      */ 
/* 3136 */             Buffer packet2 = new Buffer(25);
/* 3137 */             packet2.writeBytesNoNull(buff);
/*      */ 
/* 3139 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */ 
/* 3141 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 3143 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.91") + Messages.getString("MysqlIO.92"), "S1000");
/*      */           }
/*      */         }
/*      */         else
/*      */         {
/*      */           try
/*      */           {
/* 3150 */             byte[] passwordHash = Security.createKeyFromOldPassword(password);
/*      */ 
/* 3153 */             byte[] netReadPos4 = new byte[replyAsBytes.length - 5];
/*      */ 
/* 3155 */             System.arraycopy(replyAsBytes, 4, netReadPos4, 0, replyAsBytes.length - 5);
/*      */ 
/* 3158 */             byte[] mysqlScrambleBuff = new byte[20];
/*      */ 
/* 3161 */             Security.passwordCrypt(netReadPos4, mysqlScrambleBuff, passwordHash, 20);
/*      */ 
/* 3165 */             String scrambledPassword = Util.scramble(new String(mysqlScrambleBuff), password);
/*      */ 
/* 3168 */             Buffer packet2 = new Buffer(packLength);
/* 3169 */             packet2.writeString(scrambledPassword, "Cp1252", this.connection);
/* 3170 */             this.packetSequence = (byte)(this.packetSequence + 1);
/*      */ 
/* 3172 */             send(packet2, 24);
/*      */           } catch (NoSuchAlgorithmException nse) {
/* 3174 */             throw SQLError.createSQLException(Messages.getString("MysqlIO.93") + Messages.getString("MysqlIO.94"), "S1000");
/*      */           }
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   void secureAuth411(Buffer packet, int packLength, String user, String password, String database, boolean writeClientParams)
/*      */     throws SQLException
/*      */   {
/* 3216 */     if (packet == null) {
/* 3217 */       packet = new Buffer(packLength);
/*      */     }
/*      */ 
/* 3220 */     if (writeClientParams) {
/* 3221 */       if (this.use41Extensions) {
/* 3222 */         if (versionMeetsMinimum(4, 1, 1)) {
/* 3223 */           packet.writeLong(this.clientParam);
/* 3224 */           packet.writeLong(this.maxThreeBytes);
/*      */ 
/* 3229 */           packet.writeByte(8);
/*      */ 
/* 3232 */           packet.writeBytesNoNull(new byte[23]);
/*      */         } else {
/* 3234 */           packet.writeLong(this.clientParam);
/* 3235 */           packet.writeLong(this.maxThreeBytes);
/*      */         }
/*      */       } else {
/* 3238 */         packet.writeInt((int)this.clientParam);
/* 3239 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 3244 */     packet.writeString(user);
/*      */ 
/* 3246 */     if (password.length() != 0) {
/* 3247 */       packet.writeByte(20);
/*      */       try
/*      */       {
/* 3250 */         packet.writeBytesNoNull(Security.scramble411(password, this.seed));
/*      */       } catch (NoSuchAlgorithmException nse) {
/* 3252 */         throw SQLError.createSQLException(Messages.getString("MysqlIO.95") + Messages.getString("MysqlIO.96"), "S1000");
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 3258 */       packet.writeByte(0);
/*      */     }
/*      */ 
/* 3261 */     if (this.useConnectWithDb) {
/* 3262 */       packet.writeString(database);
/*      */     }
/*      */ 
/* 3265 */     send(packet, packet.getPosition());
/*      */ 
/* 3267 */     byte savePacketSequence = this.packetSequence++;
/*      */ 
/* 3269 */     Buffer reply = checkErrorPacket();
/*      */ 
/* 3271 */     if (reply.isLastDataPacket())
/*      */     {
/* 3276 */       savePacketSequence = (byte)(savePacketSequence + 1); this.packetSequence = savePacketSequence;
/* 3277 */       packet.clear();
/*      */ 
/* 3279 */       String seed323 = this.seed.substring(0, 8);
/* 3280 */       packet.writeString(Util.newCrypt(password, seed323));
/* 3281 */       send(packet, packet.getPosition());
/*      */ 
/* 3284 */       checkErrorPacket();
/*      */     }
/*      */   }
/*      */ 
/*      */   private final Object[] unpackBinaryResultSetRow(Field[] fields, Buffer binaryData, int resultSetConcurrency)
/*      */     throws SQLException
/*      */   {
/* 3301 */     int numFields = fields.length;
/*      */ 
/* 3303 */     Object[] unpackedRowData = new Object[numFields];
/*      */ 
/* 3310 */     int nullCount = (numFields + 9) / 8;
/*      */ 
/* 3312 */     byte[] nullBitMask = new byte[nullCount];
/*      */ 
/* 3314 */     for (int i = 0; i < nullCount; i++) {
/* 3315 */       nullBitMask[i] = binaryData.readByte();
/*      */     }
/*      */ 
/* 3318 */     int nullMaskPos = 0;
/* 3319 */     int bit = 4;
/*      */ 
/* 3326 */     for (int i = 0; i < numFields; i++) {
/* 3327 */       if ((nullBitMask[nullMaskPos] & bit) != 0) {
/* 3328 */         unpackedRowData[i] = null;
/*      */       }
/* 3330 */       else if (resultSetConcurrency != 1008) {
/* 3331 */         extractNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       }
/*      */       else {
/* 3334 */         unpackNativeEncodedColumn(binaryData, fields, i, unpackedRowData);
/*      */       }
/*      */ 
/* 3339 */       if ((bit <<= 1 & 0xFF) == 0) {
/* 3340 */         bit = 1;
/*      */ 
/* 3342 */         nullMaskPos++;
/*      */       }
/*      */     }
/*      */ 
/* 3346 */     return unpackedRowData;
/*      */   }
/*      */ 
/*      */   private final void extractNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, Object[] unpackedRowData)
/*      */     throws SQLException
/*      */   {
/* 3352 */     Field curField = fields[columnIndex];
/*      */ 
/* 3354 */     switch (curField.getMysqlType()) {
/*      */     case 6:
/* 3356 */       break;
/*      */     case 1:
/* 3360 */       unpackedRowData[columnIndex] = { binaryData.readByte() };
/* 3361 */       break;
/*      */     case 2:
/*      */     case 13:
/* 3366 */       unpackedRowData[columnIndex] = binaryData.getBytes(2);
/* 3367 */       break;
/*      */     case 3:
/*      */     case 9:
/* 3371 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 3372 */       break;
/*      */     case 8:
/* 3375 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 3376 */       break;
/*      */     case 4:
/* 3379 */       unpackedRowData[columnIndex] = binaryData.getBytes(4);
/* 3380 */       break;
/*      */     case 5:
/* 3383 */       unpackedRowData[columnIndex] = binaryData.getBytes(8);
/* 3384 */       break;
/*      */     case 11:
/* 3387 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3389 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/* 3391 */       break;
/*      */     case 10:
/* 3394 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3396 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/*      */ 
/* 3398 */       break;
/*      */     case 7:
/*      */     case 12:
/* 3401 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3403 */       unpackedRowData[columnIndex] = binaryData.getBytes(length);
/* 3404 */       break;
/*      */     case 0:
/*      */     case 15:
/*      */     case 246:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/*      */     case 255:
/* 3415 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */ 
/* 3417 */       break;
/*      */     case 16:
/* 3419 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */ 
/* 3421 */       break;
/*      */     default:
/* 3423 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000");
/*      */     }
/*      */   }
/*      */ 
/*      */   private final void unpackNativeEncodedColumn(Buffer binaryData, Field[] fields, int columnIndex, Object[] unpackedRowData)
/*      */     throws SQLException
/*      */   {
/* 3435 */     Field curField = fields[columnIndex];
/*      */ 
/* 3437 */     switch (curField.getMysqlType()) {
/*      */     case 6:
/* 3439 */       break;
/*      */     case 1:
/* 3443 */       byte tinyVal = binaryData.readByte();
/*      */ 
/* 3445 */       if (!curField.isUnsigned()) {
/* 3446 */         unpackedRowData[columnIndex] = String.valueOf(tinyVal).getBytes();
/*      */       }
/*      */       else {
/* 3449 */         short unsignedTinyVal = (short)(tinyVal & 0xFF);
/*      */ 
/* 3451 */         unpackedRowData[columnIndex] = String.valueOf(unsignedTinyVal).getBytes();
/*      */       }
/*      */ 
/* 3455 */       break;
/*      */     case 2:
/*      */     case 13:
/* 3460 */       short shortVal = (short)binaryData.readInt();
/*      */ 
/* 3462 */       if (!curField.isUnsigned()) {
/* 3463 */         unpackedRowData[columnIndex] = String.valueOf(shortVal).getBytes();
/*      */       }
/*      */       else {
/* 3466 */         int unsignedShortVal = shortVal & 0xFFFF;
/*      */ 
/* 3468 */         unpackedRowData[columnIndex] = String.valueOf(unsignedShortVal).getBytes();
/*      */       }
/*      */ 
/* 3472 */       break;
/*      */     case 3:
/*      */     case 9:
/* 3477 */       int intVal = (int)binaryData.readLong();
/*      */ 
/* 3479 */       if (!curField.isUnsigned()) {
/* 3480 */         unpackedRowData[columnIndex] = String.valueOf(intVal).getBytes();
/*      */       }
/*      */       else {
/* 3483 */         long longVal = intVal & 0xFFFFFFFF;
/*      */ 
/* 3485 */         unpackedRowData[columnIndex] = String.valueOf(longVal).getBytes();
/*      */       }
/*      */ 
/* 3489 */       break;
/*      */     case 8:
/* 3493 */       long longVal = binaryData.readLongLong();
/*      */ 
/* 3495 */       if (!curField.isUnsigned()) {
/* 3496 */         unpackedRowData[columnIndex] = String.valueOf(longVal).getBytes();
/*      */       }
/*      */       else {
/* 3499 */         BigInteger asBigInteger = ResultSet.convertLongToUlong(longVal);
/*      */ 
/* 3501 */         unpackedRowData[columnIndex] = asBigInteger.toString().getBytes();
/*      */       }
/*      */ 
/* 3505 */       break;
/*      */     case 4:
/* 3509 */       float floatVal = Float.intBitsToFloat(binaryData.readIntAsLong());
/*      */ 
/* 3511 */       unpackedRowData[columnIndex] = String.valueOf(floatVal).getBytes();
/*      */ 
/* 3513 */       break;
/*      */     case 5:
/* 3517 */       double doubleVal = Double.longBitsToDouble(binaryData.readLongLong());
/*      */ 
/* 3519 */       unpackedRowData[columnIndex] = String.valueOf(doubleVal).getBytes();
/*      */ 
/* 3521 */       break;
/*      */     case 11:
/* 3525 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3527 */       int hour = 0;
/* 3528 */       int minute = 0;
/* 3529 */       int seconds = 0;
/*      */ 
/* 3531 */       if (length != 0) {
/* 3532 */         binaryData.readByte();
/* 3533 */         binaryData.readLong();
/* 3534 */         hour = binaryData.readByte();
/* 3535 */         minute = binaryData.readByte();
/* 3536 */         seconds = binaryData.readByte();
/*      */ 
/* 3538 */         if (length > 8) {
/* 3539 */           binaryData.readLong();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3544 */       byte[] timeAsBytes = new byte[8];
/*      */ 
/* 3546 */       timeAsBytes[0] = (byte)Character.forDigit(hour / 10, 10);
/* 3547 */       timeAsBytes[1] = (byte)Character.forDigit(hour % 10, 10);
/*      */ 
/* 3549 */       timeAsBytes[2] = 58;
/*      */ 
/* 3551 */       timeAsBytes[3] = (byte)Character.forDigit(minute / 10, 10);
/*      */ 
/* 3553 */       timeAsBytes[4] = (byte)Character.forDigit(minute % 10, 10);
/*      */ 
/* 3556 */       timeAsBytes[5] = 58;
/*      */ 
/* 3558 */       timeAsBytes[6] = (byte)Character.forDigit(seconds / 10, 10);
/*      */ 
/* 3560 */       timeAsBytes[7] = (byte)Character.forDigit(seconds % 10, 10);
/*      */ 
/* 3563 */       unpackedRowData[columnIndex] = timeAsBytes;
/*      */ 
/* 3566 */       break;
/*      */     case 10:
/* 3569 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3571 */       int year = 0;
/* 3572 */       int month = 0;
/* 3573 */       int day = 0;
/*      */ 
/* 3575 */       int hour = 0;
/* 3576 */       int minute = 0;
/* 3577 */       int seconds = 0;
/*      */ 
/* 3579 */       if (length != 0) {
/* 3580 */         year = binaryData.readInt();
/* 3581 */         month = binaryData.readByte();
/* 3582 */         day = binaryData.readByte();
/*      */       }
/*      */ 
/* 3585 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 3586 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 3588 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 3591 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 3593 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Date", "S1009");
/*      */           }
/*      */ 
/* 3597 */           year = 1;
/* 3598 */           month = 1;
/* 3599 */           day = 1;
/*      */         }
/*      */       }
/*      */       else {
/* 3603 */         byte[] dateAsBytes = new byte[10];
/*      */ 
/* 3605 */         dateAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */ 
/* 3608 */         int after1000 = year % 1000;
/*      */ 
/* 3610 */         dateAsBytes[1] = (byte)Character.forDigit(after1000 / 100, 10);
/*      */ 
/* 3613 */         int after100 = after1000 % 100;
/*      */ 
/* 3615 */         dateAsBytes[2] = (byte)Character.forDigit(after100 / 10, 10);
/*      */ 
/* 3617 */         dateAsBytes[3] = (byte)Character.forDigit(after100 % 10, 10);
/*      */ 
/* 3620 */         dateAsBytes[4] = 45;
/*      */ 
/* 3622 */         dateAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/*      */ 
/* 3624 */         dateAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */ 
/* 3627 */         dateAsBytes[7] = 45;
/*      */ 
/* 3629 */         dateAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/* 3630 */         dateAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */ 
/* 3632 */         unpackedRowData[columnIndex] = dateAsBytes;
/*      */       }
/*      */ 
/* 3635 */       break;
/*      */     case 7:
/*      */     case 12:
/* 3639 */       int length = (int)binaryData.readFieldLength();
/*      */ 
/* 3641 */       int year = 0;
/* 3642 */       int month = 0;
/* 3643 */       int day = 0;
/*      */ 
/* 3645 */       int hour = 0;
/* 3646 */       int minute = 0;
/* 3647 */       int seconds = 0;
/*      */ 
/* 3649 */       int nanos = 0;
/*      */ 
/* 3651 */       if (length != 0) {
/* 3652 */         year = binaryData.readInt();
/* 3653 */         month = binaryData.readByte();
/* 3654 */         day = binaryData.readByte();
/*      */ 
/* 3656 */         if (length > 4) {
/* 3657 */           hour = binaryData.readByte();
/* 3658 */           minute = binaryData.readByte();
/* 3659 */           seconds = binaryData.readByte();
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 3667 */       if ((year == 0) && (month == 0) && (day == 0)) {
/* 3668 */         if ("convertToNull".equals(this.connection.getZeroDateTimeBehavior()))
/*      */         {
/* 3670 */           unpackedRowData[columnIndex] = null;
/*      */         }
/*      */         else {
/* 3673 */           if ("exception".equals(this.connection.getZeroDateTimeBehavior()))
/*      */           {
/* 3675 */             throw SQLError.createSQLException("Value '0000-00-00' can not be represented as java.sql.Timestamp", "S1009");
/*      */           }
/*      */ 
/* 3679 */           year = 1;
/* 3680 */           month = 1;
/* 3681 */           day = 1;
/*      */         }
/*      */       }
/*      */       else {
/* 3685 */         int stringLength = 19;
/*      */ 
/* 3687 */         byte[] nanosAsBytes = Integer.toString(nanos).getBytes();
/*      */ 
/* 3689 */         stringLength += 1 + nanosAsBytes.length;
/*      */ 
/* 3691 */         byte[] datetimeAsBytes = new byte[stringLength];
/*      */ 
/* 3693 */         datetimeAsBytes[0] = (byte)Character.forDigit(year / 1000, 10);
/*      */ 
/* 3696 */         int after1000 = year % 1000;
/*      */ 
/* 3698 */         datetimeAsBytes[1] = (byte)Character.forDigit(after1000 / 100, 10);
/*      */ 
/* 3701 */         int after100 = after1000 % 100;
/*      */ 
/* 3703 */         datetimeAsBytes[2] = (byte)Character.forDigit(after100 / 10, 10);
/*      */ 
/* 3705 */         datetimeAsBytes[3] = (byte)Character.forDigit(after100 % 10, 10);
/*      */ 
/* 3708 */         datetimeAsBytes[4] = 45;
/*      */ 
/* 3710 */         datetimeAsBytes[5] = (byte)Character.forDigit(month / 10, 10);
/*      */ 
/* 3712 */         datetimeAsBytes[6] = (byte)Character.forDigit(month % 10, 10);
/*      */ 
/* 3715 */         datetimeAsBytes[7] = 45;
/*      */ 
/* 3717 */         datetimeAsBytes[8] = (byte)Character.forDigit(day / 10, 10);
/*      */ 
/* 3719 */         datetimeAsBytes[9] = (byte)Character.forDigit(day % 10, 10);
/*      */ 
/* 3722 */         datetimeAsBytes[10] = 32;
/*      */ 
/* 3724 */         datetimeAsBytes[11] = (byte)Character.forDigit(hour / 10, 10);
/*      */ 
/* 3726 */         datetimeAsBytes[12] = (byte)Character.forDigit(hour % 10, 10);
/*      */ 
/* 3729 */         datetimeAsBytes[13] = 58;
/*      */ 
/* 3731 */         datetimeAsBytes[14] = (byte)Character.forDigit(minute / 10, 10);
/*      */ 
/* 3733 */         datetimeAsBytes[15] = (byte)Character.forDigit(minute % 10, 10);
/*      */ 
/* 3736 */         datetimeAsBytes[16] = 58;
/*      */ 
/* 3738 */         datetimeAsBytes[17] = (byte)Character.forDigit(seconds / 10, 10);
/*      */ 
/* 3740 */         datetimeAsBytes[18] = (byte)Character.forDigit(seconds % 10, 10);
/*      */ 
/* 3743 */         datetimeAsBytes[19] = 46;
/*      */ 
/* 3745 */         int nanosOffset = 20;
/*      */ 
/* 3747 */         for (int j = 0; j < nanosAsBytes.length; j++) {
/* 3748 */           datetimeAsBytes[(nanosOffset + j)] = nanosAsBytes[j];
/*      */         }
/*      */ 
/* 3751 */         unpackedRowData[columnIndex] = datetimeAsBytes;
/*      */       }
/*      */ 
/* 3754 */       break;
/*      */     case 0:
/*      */     case 15:
/*      */     case 16:
/*      */     case 246:
/*      */     case 249:
/*      */     case 250:
/*      */     case 251:
/*      */     case 252:
/*      */     case 253:
/*      */     case 254:
/* 3766 */       unpackedRowData[columnIndex] = binaryData.readLenByteArray(0);
/*      */ 
/* 3768 */       break;
/*      */     default:
/* 3771 */       throw SQLError.createSQLException(Messages.getString("MysqlIO.97") + curField.getMysqlType() + Messages.getString("MysqlIO.98") + columnIndex + Messages.getString("MysqlIO.99") + fields.length + Messages.getString("MysqlIO.100"), "S1000");
/*      */     }
/*      */   }
/*      */ 
/*      */   private Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 3785 */     if (this.connection.getDynamicCalendars()) {
/* 3786 */       return Calendar.getInstance();
/*      */     }
/* 3788 */     return this.sessionCalendar;
/*      */   }
/*      */ 
/*      */   private void negotiateSSLConnection(String user, String password, String database, int packLength)
/*      */     throws SQLException, CommunicationsException
/*      */   {
/* 3806 */     if (!ExportControlled.enabled()) {
/* 3807 */       throw new ConnectionFeatureNotAvailableException(this.connection, this.lastPacketSentTimeMs, null);
/*      */     }
/*      */ 
/* 3811 */     boolean doSecureAuth = false;
/*      */ 
/* 3813 */     if ((this.serverCapabilities & 0x8000) != 0) {
/* 3814 */       this.clientParam |= 32768L;
/* 3815 */       doSecureAuth = true;
/*      */     }
/*      */ 
/* 3818 */     this.clientParam |= 2048L;
/*      */ 
/* 3820 */     Buffer packet = new Buffer(packLength);
/*      */ 
/* 3822 */     if ((this.clientParam & 0x4000) != 0L)
/* 3823 */       packet.writeLong(this.clientParam);
/*      */     else {
/* 3825 */       packet.writeInt((int)this.clientParam);
/*      */     }
/*      */ 
/* 3828 */     send(packet, packet.getPosition());
/*      */ 
/* 3830 */     ExportControlled.transformSocketToSSLSocket(this);
/*      */ 
/* 3832 */     packet.clear();
/*      */ 
/* 3834 */     if (doSecureAuth) {
/* 3835 */       if (versionMeetsMinimum(4, 1, 1))
/* 3836 */         secureAuth411(null, packLength, user, password, database, true);
/*      */       else
/* 3838 */         secureAuth411(null, packLength, user, password, database, true);
/*      */     }
/*      */     else {
/* 3841 */       if ((this.clientParam & 0x4000) != 0L) {
/* 3842 */         packet.writeLong(this.clientParam);
/* 3843 */         packet.writeLong(this.maxThreeBytes);
/*      */       } else {
/* 3845 */         packet.writeInt((int)this.clientParam);
/* 3846 */         packet.writeLongInt(this.maxThreeBytes);
/*      */       }
/*      */ 
/* 3850 */       packet.writeString(user);
/*      */ 
/* 3852 */       if (this.protocolVersion > 9)
/* 3853 */         packet.writeString(Util.newCrypt(password, this.seed));
/*      */       else {
/* 3855 */         packet.writeString(Util.oldCrypt(password, this.seed));
/*      */       }
/*      */ 
/* 3858 */       if (((this.serverCapabilities & 0x8) != 0) && (database != null) && (database.length() > 0))
/*      */       {
/* 3860 */         packet.writeString(database);
/*      */       }
/*      */ 
/* 3863 */       send(packet, packet.getPosition());
/*      */     }
/*      */   }
/*      */ 
/*      */   protected int getServerStatus() {
/* 3868 */     return this.serverStatus;
/*      */   }
/*      */ 
/*      */   protected List fetchRowsViaCursor(List fetchedRows, long statementId, Field[] columnTypes, int fetchSize)
/*      */     throws SQLException
/*      */   {
/* 3874 */     if (fetchedRows == null)
/* 3875 */       fetchedRows = new ArrayList(fetchSize);
/*      */     else {
/* 3877 */       fetchedRows.clear();
/*      */     }
/*      */ 
/* 3880 */     this.sharedSendPacket.clear();
/*      */ 
/* 3882 */     this.sharedSendPacket.writeByte(28);
/* 3883 */     this.sharedSendPacket.writeLong(statementId);
/* 3884 */     this.sharedSendPacket.writeLong(fetchSize);
/*      */ 
/* 3886 */     sendCommand(28, null, this.sharedSendPacket, true, null);
/*      */ 
/* 3889 */     Object[] row = null;
/*      */ 
/* 3892 */     while ((row = nextRow(columnTypes, columnTypes.length, true, 1007)) != null) {
/* 3893 */       fetchedRows.add(row);
/*      */     }
/*      */ 
/* 3896 */     return fetchedRows;
/*      */   }
/*      */ 
/*      */   protected long getThreadId() {
/* 3900 */     return this.threadId;
/*      */   }
/*      */ 
/*      */   static
/*      */   {
/*  129 */     OutputStreamWriter outWriter = null;
/*      */     try
/*      */     {
/*  137 */       outWriter = new OutputStreamWriter(new ByteArrayOutputStream());
/*  138 */       jvmPlatformCharset = outWriter.getEncoding();
/*      */     } finally {
/*      */       try {
/*  141 */         if (outWriter != null)
/*  142 */           outWriter.close();
/*      */       }
/*      */       catch (IOException ioEx)
/*      */       {
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.MysqlIO
 * JD-Core Version:    0.6.0
 */