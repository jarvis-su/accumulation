/*    */ package com.acs.eppic.messageservice.web;
/*    */ 
/*    */ import com.acs.eppic.message.Message;
/*    */ import java.rmi.RemoteException;
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Hashtable;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import javax.xml.namespace.QName;
/*    */ import org.apache.axis.description.OperationDesc;
/*    */ import org.apache.axis.description.ParameterDesc;
/*    */ import org.apache.axis.wsdl.Skeleton;
/*    */ 
/*    */ public class MessageWebServiceSoapBindingSkeleton
/*    */   implements MessageWebService, Skeleton
/*    */ {
/*    */   private static final long serialVersionUID = 3325265240444461644L;
/*    */   private MessageWebService impl;
/* 16 */   private static Map _myOperations = new Hashtable();
/* 17 */   private static Collection _myOperationsList = new ArrayList();
/*    */ 
/*    */   static
/*    */   {
/* 37 */     ParameterDesc[] _params = { 
/* 38 */       new ParameterDesc(new QName("", "in0"), 1, new QName("http://message.eppic.acs.com", "Message"), Message.class, false, false) };
/*    */ 
/* 40 */     OperationDesc _oper = new OperationDesc("sendMessage", _params, null);
/* 41 */     _oper.setElementQName(new QName("urn:MessageWebService", "sendMessage"));
/* 42 */     _oper.setSoapAction("");
/* 43 */     _myOperationsList.add(_oper);
/* 44 */     if (_myOperations.get("sendMessage") == null) {
/* 45 */       _myOperations.put("sendMessage", new ArrayList());
/*    */     }
/* 47 */     ((List)_myOperations.get("sendMessage")).add(_oper);
/*    */   }
/*    */ 
/*    */   public static List getOperationDescByName(String methodName)
/*    */   {
/* 23 */     return (List)_myOperations.get(methodName);
/*    */   }
/*    */ 
/*    */   public static Collection getOperationDescs()
/*    */   {
/* 30 */     return _myOperationsList;
/*    */   }
/*    */ 
/*    */   public MessageWebServiceSoapBindingSkeleton()
/*    */   {
/* 51 */     this.impl = new MessageWebServiceSoapBindingImpl();
/*    */   }
/*    */ 
/*    */   public MessageWebServiceSoapBindingSkeleton(MessageWebService impl) {
/* 55 */     this.impl = impl;
/*    */   }
/*    */ 
/*    */   public void sendMessage(Message in0) throws RemoteException {
/* 59 */     this.impl.sendMessage(in0);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.eppic.messageservice.web.MessageWebServiceSoapBindingSkeleton
 * JD-Core Version:    0.6.0
 */