/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import java.io.IOException;
/*    */ 
/*    */ public class PacketChannelWindowAdjust
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public int windowChange;
/*    */ 
/*    */   public PacketChannelWindowAdjust(int recipientChannelID, int windowChange)
/*    */   {
/* 20 */     this.recipientChannelID = recipientChannelID;
/* 21 */     this.windowChange = windowChange;
/*    */   }
/*    */ 
/*    */   public PacketChannelWindowAdjust(byte[] payload, int off, int len) throws IOException
/*    */   {
/* 26 */     this.payload = new byte[len];
/* 27 */     System.arraycopy(payload, off, this.payload, 0, len);
/*    */ 
/* 29 */     TypesReader tr = new TypesReader(payload, off, len);
/*    */ 
/* 31 */     int packet_type = tr.readByte();
/*    */ 
/* 33 */     if (packet_type != 93) {
/* 34 */       throw new IOException(
/* 35 */         "This is not a SSH_MSG_CHANNEL_WINDOW_ADJUST! (" + 
/* 36 */         packet_type + ")");
/*    */     }
/* 38 */     this.recipientChannelID = tr.readUINT32();
/* 39 */     this.windowChange = tr.readUINT32();
/*    */ 
/* 41 */     if (tr.remain() != 0)
/* 42 */       throw new IOException("Padding in SSH_MSG_CHANNEL_WINDOW_ADJUST packet!");
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 47 */     if (this.payload == null)
/*    */     {
/* 49 */       TypesWriter tw = new TypesWriter();
/* 50 */       tw.writeByte(93);
/* 51 */       tw.writeUINT32(this.recipientChannelID);
/* 52 */       tw.writeUINT32(this.windowChange);
/* 53 */       this.payload = tw.getBytes();
/*    */     }
/* 55 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketChannelWindowAdjust
 * JD-Core Version:    0.6.0
 */