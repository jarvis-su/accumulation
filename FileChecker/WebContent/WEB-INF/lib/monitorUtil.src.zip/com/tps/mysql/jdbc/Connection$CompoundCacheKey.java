/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ class Connection$CompoundCacheKey
/*     */ {
/*     */   String componentOne;
/*     */   String componentTwo;
/*     */   int hashCode;
/*     */   private final Connection this$0;
/*     */ 
/*     */   Connection$CompoundCacheKey(Connection this$0, String partOne, String partTwo)
/*     */   {
/* 100 */     this.this$0 = this$0;
/* 101 */     this.componentOne = partOne;
/* 102 */     this.componentTwo = partTwo;
/*     */ 
/* 106 */     this.hashCode = ((this.componentOne != null ? this.componentOne : "") + this.componentTwo).hashCode();
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 116 */     if ((obj instanceof CompoundCacheKey)) {
/* 117 */       CompoundCacheKey another = (CompoundCacheKey)obj;
/*     */ 
/* 119 */       boolean firstPartEqual = false;
/*     */ 
/* 121 */       if (this.componentOne == null)
/* 122 */         firstPartEqual = another.componentOne == null;
/*     */       else {
/* 124 */         firstPartEqual = this.componentOne.equals(another.componentOne);
/*     */       }
/*     */ 
/* 128 */       return (firstPartEqual) && (this.componentTwo.equals(another.componentTwo));
/*     */     }
/*     */ 
/* 132 */     return false;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 141 */     return this.hashCode;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Connection.CompoundCacheKey
 * JD-Core Version:    0.6.0
 */