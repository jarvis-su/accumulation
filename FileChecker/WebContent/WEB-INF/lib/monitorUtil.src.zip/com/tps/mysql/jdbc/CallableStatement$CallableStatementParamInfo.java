/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ class CallableStatement$CallableStatementParamInfo
/*     */ {
/*     */   String catalogInUse;
/*     */   boolean isFunctionCall;
/*     */   String nativeSql;
/*     */   int numParameters;
/*     */   List parameterList;
/*     */   Map parameterMap;
/*     */   private final CallableStatement this$0;
/*     */ 
/*     */   CallableStatement$CallableStatementParamInfo(CallableStatement this$0, CallableStatementParamInfo fullParamInfo)
/*     */   {
/* 130 */     this.this$0 = this$0;
/* 131 */     this.nativeSql = this$0.originalSql;
/* 132 */     this.catalogInUse = this$0.currentCatalog;
/* 133 */     this.isFunctionCall = fullParamInfo.isFunctionCall;
/* 134 */     int[] localParameterMap = CallableStatement.access$000(this$0);
/* 135 */     int parameterMapLength = localParameterMap.length;
/*     */ 
/* 137 */     this.parameterList = new ArrayList(fullParamInfo.numParameters);
/* 138 */     this.parameterMap = new HashMap(fullParamInfo.numParameters);
/*     */ 
/* 140 */     if (this.isFunctionCall)
/*     */     {
/* 142 */       this.parameterList.add(fullParamInfo.parameterList.get(0));
/*     */     }
/*     */ 
/* 145 */     int offset = this.isFunctionCall ? 1 : 0;
/*     */ 
/* 147 */     for (int i = 0; i < parameterMapLength; i++) {
/* 148 */       if (localParameterMap[i] != 0) {
/* 149 */         CallableStatement.CallableStatementParam param = (CallableStatement.CallableStatementParam)fullParamInfo.parameterList.get(localParameterMap[i] + offset);
/*     */ 
/* 151 */         this.parameterList.add(param);
/* 152 */         this.parameterMap.put(param.paramName, param);
/*     */       }
/*     */     }
/*     */ 
/* 156 */     this.numParameters = this.parameterList.size();
/*     */   }
/*     */ 
/*     */   CallableStatement$CallableStatementParamInfo(CallableStatement this$0, ResultSet paramTypesRs) throws SQLException {
/* 160 */     this.this$0 = this$0;
/* 161 */     boolean hadRows = paramTypesRs.last();
/*     */ 
/* 163 */     this.nativeSql = this$0.originalSql;
/* 164 */     this.catalogInUse = this$0.currentCatalog;
/* 165 */     this.isFunctionCall = CallableStatement.access$100(this$0);
/*     */ 
/* 167 */     if (hadRows) {
/* 168 */       this.numParameters = paramTypesRs.getRow();
/*     */ 
/* 170 */       this.parameterList = new ArrayList(this.numParameters);
/* 171 */       this.parameterMap = new HashMap(this.numParameters);
/*     */ 
/* 173 */       paramTypesRs.beforeFirst();
/*     */ 
/* 175 */       addParametersFromDBMD(paramTypesRs);
/*     */     } else {
/* 177 */       this.numParameters = 0;
/*     */     }
/*     */ 
/* 180 */     if (this.isFunctionCall)
/* 181 */       this.numParameters += 1;
/*     */   }
/*     */ 
/*     */   private void addParametersFromDBMD(ResultSet paramTypesRs)
/*     */     throws SQLException
/*     */   {
/* 187 */     int i = 0;
/*     */ 
/* 189 */     while (paramTypesRs.next()) {
/* 190 */       String paramName = paramTypesRs.getString(4);
/* 191 */       int inOutModifier = paramTypesRs.getInt(5);
/*     */ 
/* 193 */       boolean isOutParameter = false;
/* 194 */       boolean isInParameter = false;
/*     */ 
/* 196 */       if ((i == 0) && (this.isFunctionCall)) {
/* 197 */         isOutParameter = true;
/* 198 */         isInParameter = false;
/* 199 */       } else if (inOutModifier == 2) {
/* 200 */         isOutParameter = true;
/* 201 */         isInParameter = true;
/* 202 */       } else if (inOutModifier == 1) {
/* 203 */         isOutParameter = false;
/* 204 */         isInParameter = true;
/* 205 */       } else if (inOutModifier == 4) {
/* 206 */         isOutParameter = true;
/* 207 */         isInParameter = false;
/*     */       }
/*     */ 
/* 210 */       int jdbcType = paramTypesRs.getInt(6);
/* 211 */       String typeName = paramTypesRs.getString(7);
/* 212 */       int precision = paramTypesRs.getInt(8);
/* 213 */       int scale = paramTypesRs.getInt(10);
/* 214 */       short nullability = paramTypesRs.getShort(12);
/*     */ 
/* 216 */       CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(this.this$0, paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
/*     */ 
/* 221 */       this.parameterList.add(paramInfoToAdd);
/* 222 */       this.parameterMap.put(paramName, paramInfoToAdd);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void checkBounds(int paramIndex) throws SQLException {
/* 227 */     int localParamIndex = paramIndex - 1;
/*     */ 
/* 229 */     if ((paramIndex < 0) || (localParamIndex >= this.numParameters))
/* 230 */       throw SQLError.createSQLException(Messages.getString("CallableStatement.11") + paramIndex + Messages.getString("CallableStatement.12") + this.numParameters + Messages.getString("CallableStatement.13"), "S1009");
/*     */   }
/*     */ 
/*     */   protected Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 244 */     return super.clone();
/*     */   }
/*     */ 
/*     */   CallableStatement.CallableStatementParam getParameter(int index) {
/* 248 */     return (CallableStatement.CallableStatementParam)this.parameterList.get(index);
/*     */   }
/*     */ 
/*     */   CallableStatement.CallableStatementParam getParameter(String name) {
/* 252 */     return (CallableStatement.CallableStatementParam)this.parameterMap.get(name);
/*     */   }
/*     */ 
/*     */   public String getParameterClassName(int arg0) throws SQLException {
/* 256 */     String mysqlTypeName = getParameterTypeName(arg0);
/*     */ 
/* 258 */     boolean isBinaryOrBlob = (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BLOB") != -1) || (StringUtils.indexOfIgnoreCase(mysqlTypeName, "BINARY") != -1);
/*     */ 
/* 261 */     boolean isUnsigned = StringUtils.indexOfIgnoreCase(mysqlTypeName, "UNSIGNED") != -1;
/*     */ 
/* 263 */     int mysqlTypeIfKnown = 0;
/*     */ 
/* 265 */     if (StringUtils.startsWithIgnoreCase(mysqlTypeName, "MEDIUMINT")) {
/* 266 */       mysqlTypeIfKnown = 9;
/*     */     }
/*     */ 
/* 269 */     return ResultSetMetaData.getClassNameForJavaType(getParameterType(arg0), isUnsigned, mysqlTypeIfKnown, isBinaryOrBlob, false);
/*     */   }
/*     */ 
/*     */   public int getParameterCount() throws SQLException
/*     */   {
/* 274 */     if (this.parameterList == null) {
/* 275 */       return 0;
/*     */     }
/*     */ 
/* 278 */     return this.parameterList.size();
/*     */   }
/*     */ 
/*     */   public int getParameterMode(int arg0) throws SQLException {
/* 282 */     checkBounds(arg0);
/*     */ 
/* 284 */     return getParameter(arg0 - 1).inOutModifier;
/*     */   }
/*     */ 
/*     */   public int getParameterType(int arg0) throws SQLException {
/* 288 */     checkBounds(arg0);
/*     */ 
/* 290 */     return getParameter(arg0 - 1).jdbcType;
/*     */   }
/*     */ 
/*     */   public String getParameterTypeName(int arg0) throws SQLException {
/* 294 */     checkBounds(arg0);
/*     */ 
/* 296 */     return getParameter(arg0 - 1).typeName;
/*     */   }
/*     */ 
/*     */   public int getPrecision(int arg0) throws SQLException {
/* 300 */     checkBounds(arg0);
/*     */ 
/* 302 */     return getParameter(arg0 - 1).precision;
/*     */   }
/*     */ 
/*     */   public int getScale(int arg0) throws SQLException {
/* 306 */     checkBounds(arg0);
/*     */ 
/* 308 */     return getParameter(arg0 - 1).scale;
/*     */   }
/*     */ 
/*     */   public int isNullable(int arg0) throws SQLException {
/* 312 */     checkBounds(arg0);
/*     */ 
/* 314 */     return getParameter(arg0 - 1).nullability;
/*     */   }
/*     */ 
/*     */   public boolean isSigned(int arg0) throws SQLException {
/* 318 */     checkBounds(arg0);
/*     */ 
/* 320 */     return false;
/*     */   }
/*     */ 
/*     */   Iterator iterator() {
/* 324 */     return this.parameterList.iterator();
/*     */   }
/*     */ 
/*     */   int numberOfParameters() {
/* 328 */     return this.numParameters;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.CallableStatement.CallableStatementParamInfo
 * JD-Core Version:    0.6.0
 */