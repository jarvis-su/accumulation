/*     */ package com.acs.fileChecker.fileserver;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.FilenameFilter;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.PrintStream;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.regex.Pattern;
/*     */ 
/*     */ public class FileCheckerMain3
/*     */ {
/*     */   private Validate val;
/*     */   private Date date;
/*     */   private boolean HTML;
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  17 */     FileCheckerMain3 fcm = new FileCheckerMain3(false);
/*  18 */     BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
/*  19 */     if (fcm.outputHTML())
/*     */     {
/*  21 */       System.out.println("<td width=60%><H4>File Name</H4></td><td width=10%><H4>Size</H4></td><td width=15%><H4>Modified</H4></td><td width=15%><H4>Error</H4></td>");
/*  22 */       System.err.println("<td width=60%><H4>File Name</H4></td><td width=10%><H4>Size</H4></td><td width=15%><H4>Modified</H4></td><td width=15%><H4>Error</H4></td>");
/*     */     }
/*     */     try
/*     */     {
/*     */       String line;
/*     */       do {
/*  29 */         String line = stripQuotes(line);
/*  30 */         String base = fcm.baseName(line);
/*  31 */         String name = fcm.fileName(line);
/*  32 */         String[] test = fcm.getFilesRegExp(new File(base), name);
/*  33 */         if (fcm.outputHTML())
/*     */         {
/*  40 */           for (int j = 0; j < test.length; j++)
/*     */           {
/*  42 */             System.out.println("<td width=60%>" + base + test[j] + "</td><td width=10%>" + fcm.check(new StringBuilder(String.valueOf(base)).append(test[j]).toString()) + "</td>");
/*  43 */             System.err.println("<td width=60%>" + base + test[j] + "</td><td width=10%>" + fcm.check(new StringBuilder(String.valueOf(base)).append(test[j]).toString()) + "</td>");
/*     */           }
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*  53 */           for (int j = 0; j < test.length; j++)
/*     */           {
/*  55 */             System.out.println(base + test[j] + "\t" + fcm.check(new StringBuilder(String.valueOf(base)).append(test[j]).toString()));
/*  56 */             System.err.println(base + test[j] + "\t" + fcm.check(new StringBuilder(String.valueOf(base)).append(test[j]).toString()));
/*     */           }
/*     */         }
/*  27 */         if ((line = br.readLine()) == null) break; 
/*  27 */       }while (!line.equals("."));
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  64 */       e.printStackTrace();
/*  65 */       System.err.println(e.toString());
/*     */     }
/*  67 */     System.out.println("Session Closed.");
/*  68 */     System.err.println("Session Closed.");
/*     */   }
/*     */ 
/*     */   public FileCheckerMain3()
/*     */   {
/*  73 */     this.date = new Date();
/*  74 */     this.HTML = false;
/*     */   }
/*     */ 
/*     */   public FileCheckerMain3(boolean html)
/*     */   {
/*  79 */     this.HTML = html;
/*  80 */     this.date = new Date();
/*     */   }
/*     */ 
/*     */   public boolean outputHTML()
/*     */   {
/*  85 */     return this.HTML;
/*     */   }
/*     */ 
/*     */   public FileCheckerMain3(String s)
/*     */   {
/*  90 */     SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
/*     */     try
/*     */     {
/*  93 */       this.date = sdf.parse(s);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*  97 */       e.printStackTrace();
/*     */     }
/*     */   }
/*     */ 
/*     */   public String check(String s)
/*     */   {
/* 103 */     this.val = new Validate(s);
/* 104 */     StringBuffer stb = new StringBuffer(String.valueOf(this.val.getFileSize()));
/* 105 */     if (outputHTML())
/* 106 */       stb.append("</td><td width=15%>");
/*     */     else
/* 108 */       stb.append("\t");
/* 109 */     stb.append(this.val.getFileMod());
/* 110 */     if (outputHTML())
/* 111 */       stb.append("</td><td width=15%>");
/*     */     else
/* 113 */       stb.append("\t");
/* 114 */     String error = this.val.validateFile();
/* 115 */     if (!error.equals(""))
/* 116 */       stb.append("Error " + error);
/* 117 */     return stb.toString();
/*     */   }
/*     */ 
/*     */   public String[] getFilesRegExp(File dir, String regexp)
/*     */   {
/* 122 */     FilenameFilter filter = new FilenameFilter(regexp)
/*     */     {
/*     */       public boolean accept(File dir, String name) {
/* 125 */         return Pattern.matches(this.val$regexp, name);
/*     */       }
/*     */     };
/* 128 */     return dir.list(filter);
/*     */   }
/*     */ 
/*     */   protected static String stripQuotes(String a)
/*     */   {
/* 133 */     if (a.startsWith("\""))
/* 134 */       a = a.substring(1, a.length());
/* 135 */     if (a.endsWith("\""))
/* 136 */       a = a.substring(0, a.length() - 1);
/* 137 */     return a;
/*     */   }
/*     */ 
/*     */   public String baseName(String a)
/*     */   {
/* 142 */     int base_len = a.lastIndexOf('/');
/* 143 */     if (base_len == -1) {
/* 144 */       return "./";
/*     */     }
/* 146 */     return a.substring(0, base_len + 1);
/*     */   }
/*     */ 
/*     */   public String fileName(String a)
/*     */   {
/* 151 */     int base_len = a.lastIndexOf('/');
/* 152 */     if (base_len == -1) {
/* 153 */       return a;
/*     */     }
/* 155 */     return a.substring(base_len + 1, a.length());
/*     */   }
/*     */ 
/*     */   public String replaceDate(String source)
/*     */   {
/* 160 */     char first = '{';
/* 161 */     char last = '}';
/* 162 */     if (source != null)
/*     */     {
/* 164 */       int found = -1;
/* 165 */       int found2 = -1;
/* 166 */       int cur = 0;
/* 167 */       StringBuffer sb = new StringBuffer();
/* 168 */       while ((found = source.indexOf(first, cur)) != -1)
/* 169 */         if ((found2 = source.indexOf(last, cur)) != -1)
/*     */         {
/* 171 */           int subLen = found2 - found - 1;
/* 172 */           sb.append(source.substring(cur, found));
/* 173 */           SimpleDateFormat sdf = new SimpleDateFormat(source.substring(found + 1, found + subLen + 1));
/* 174 */           sb.append(sdf.format(this.date));
/* 175 */           cur = found2 + 1;
/*     */         }
/*     */         else {
/* 178 */           return null;
/*     */         }
/* 180 */       sb.append(source.substring(cur));
/* 181 */       return sb.toString();
/*     */     }
/*     */ 
/* 184 */     return null;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.acs.fileChecker.fileserver.FileCheckerMain3
 * JD-Core Version:    0.6.0
 */