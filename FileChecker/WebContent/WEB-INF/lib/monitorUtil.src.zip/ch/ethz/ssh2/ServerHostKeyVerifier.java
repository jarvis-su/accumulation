package ch.ethz.ssh2;

public abstract interface ServerHostKeyVerifier
{
  public abstract boolean verifyServerHostKey(String paramString1, int paramInt, String paramString2, byte[] paramArrayOfByte)
    throws Exception;
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.ServerHostKeyVerifier
 * JD-Core Version:    0.6.0
 */