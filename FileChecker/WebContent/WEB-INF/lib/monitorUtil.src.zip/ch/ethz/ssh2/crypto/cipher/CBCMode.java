/*    */ package ch.ethz.ssh2.crypto.cipher;
/*    */ 
/*    */ public class CBCMode
/*    */   implements BlockCipher
/*    */ {
/*    */   BlockCipher tc;
/*    */   int blockSize;
/*    */   boolean doEncrypt;
/*    */   byte[] cbc_vector;
/*    */   byte[] tmp_vector;
/*    */ 
/*    */   public void init(boolean forEncryption, byte[] key)
/*    */   {
/*    */   }
/*    */ 
/*    */   public CBCMode(BlockCipher tc, byte[] iv, boolean doEncrypt)
/*    */     throws IllegalArgumentException
/*    */   {
/* 25 */     this.tc = tc;
/* 26 */     this.blockSize = tc.getBlockSize();
/* 27 */     this.doEncrypt = doEncrypt;
/*    */ 
/* 29 */     if (this.blockSize != iv.length) {
/* 30 */       throw new IllegalArgumentException("IV must be " + this.blockSize + 
/* 31 */         " bytes long! (currently " + iv.length + ")");
/*    */     }
/* 33 */     this.cbc_vector = new byte[this.blockSize];
/* 34 */     this.tmp_vector = new byte[this.blockSize];
/* 35 */     System.arraycopy(iv, 0, this.cbc_vector, 0, this.blockSize);
/*    */   }
/*    */ 
/*    */   public int getBlockSize()
/*    */   {
/* 40 */     return this.blockSize;
/*    */   }
/*    */ 
/*    */   private void encryptBlock(byte[] src, int srcoff, byte[] dst, int dstoff)
/*    */   {
/* 45 */     for (int i = 0; i < this.blockSize; i++)
/*    */     {
/*    */       int tmp12_10 = i;
/*    */       byte[] tmp12_7 = this.cbc_vector; tmp12_7[tmp12_10] = (byte)(tmp12_7[tmp12_10] ^ src[(srcoff + i)]);
/*    */     }
/* 48 */     this.tc.transformBlock(this.cbc_vector, 0, dst, dstoff);
/*    */ 
/* 50 */     System.arraycopy(dst, dstoff, this.cbc_vector, 0, this.blockSize);
/*    */   }
/*    */ 
/*    */   private void decryptBlock(byte[] src, int srcoff, byte[] dst, int dstoff)
/*    */   {
/* 57 */     System.arraycopy(src, srcoff, this.tmp_vector, 0, this.blockSize);
/*    */ 
/* 59 */     this.tc.transformBlock(src, srcoff, dst, dstoff);
/*    */ 
/* 61 */     for (int i = 0; i < this.blockSize; i++)
/*    */     {
/*    */       int tmp40_39 = (dstoff + i);
/*    */       byte[] tmp40_34 = dst; tmp40_34[tmp40_39] = (byte)(tmp40_34[tmp40_39] ^ this.cbc_vector[i]);
/*    */     }
/*    */ 
/* 66 */     byte[] swap = this.cbc_vector;
/* 67 */     this.cbc_vector = this.tmp_vector;
/* 68 */     this.tmp_vector = swap;
/*    */   }
/*    */ 
/*    */   public void transformBlock(byte[] src, int srcoff, byte[] dst, int dstoff)
/*    */   {
/* 73 */     if (this.doEncrypt)
/* 74 */       encryptBlock(src, srcoff, dst, dstoff);
/*    */     else
/* 76 */       decryptBlock(src, srcoff, dst, dstoff);
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.cipher.CBCMode
 * JD-Core Version:    0.6.0
 */