/*     */ package ch.ethz.ssh2.channel;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ 
/*     */ public class LocalAcceptThread extends Thread
/*     */   implements IChannelWorkerThread
/*     */ {
/*     */   ChannelManager cm;
/*     */   int local_port;
/*     */   String host_to_connect;
/*     */   int port_to_connect;
/*     */   final ServerSocket ss;
/*     */ 
/*     */   public LocalAcceptThread(ChannelManager cm, int local_port, String host_to_connect, int port_to_connect)
/*     */     throws IOException
/*     */   {
/*  26 */     this.cm = cm;
/*  27 */     this.local_port = local_port;
/*  28 */     this.host_to_connect = host_to_connect;
/*  29 */     this.port_to_connect = port_to_connect;
/*     */ 
/*  31 */     this.ss = new ServerSocket(local_port);
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*     */     try
/*     */     {
/*  38 */       this.cm.registerThread(this);
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/*  42 */       stopWorking();
/*  43 */       return;
/*     */     }
/*     */ 
/*     */     while (true)
/*     */     {
/*  48 */       Socket s = null;
/*     */       try
/*     */       {
/*  52 */         s = this.ss.accept();
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*  56 */         stopWorking();
/*  57 */         return;
/*     */       }
/*     */ 
/*  60 */       Channel cn = null;
/*  61 */       StreamForwarder r2l = null;
/*  62 */       StreamForwarder l2r = null;
/*     */       try
/*     */       {
/*  68 */         cn = this.cm.openDirectTCPIPChannel(this.host_to_connect, this.port_to_connect, s.getInetAddress().getHostAddress(), 
/*  69 */           s.getPort());
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */         try
/*     */         {
/*  78 */           s.close();
/*     */         }
/*     */         catch (IOException localIOException1)
/*     */         {
/*     */         }
/*     */       }
/*  84 */       continue;
/*     */       try
/*     */       {
/*  89 */         r2l = new StreamForwarder(cn, null, null, cn.stdoutStream, s.getOutputStream(), "RemoteToLocal");
/*  90 */         l2r = new StreamForwarder(cn, r2l, s, s.getInputStream(), cn.stdinStream, "LocalToRemote");
/*     */       }
/*     */       catch (IOException e)
/*     */       {
/*     */         try
/*     */         {
/*  97 */           cn.cm.closeChannel(cn, "Weird error during creation of StreamForwarder (" + e.getMessage() + ")", 
/*  98 */             true);
/*     */         }
/*     */         catch (IOException localIOException2)
/*     */         {
/*     */         }
/*     */       }
/* 104 */       continue;
/*     */ 
/* 107 */       r2l.setDaemon(true);
/* 108 */       l2r.setDaemon(true);
/* 109 */       r2l.start();
/* 110 */       l2r.start();
/*     */     }
/*     */   }
/*     */ 
/*     */   public void stopWorking()
/*     */   {
/*     */     try
/*     */     {
/* 119 */       this.ss.close();
/*     */     }
/*     */     catch (IOException localIOException)
/*     */     {
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.LocalAcceptThread
 * JD-Core Version:    0.6.0
 */