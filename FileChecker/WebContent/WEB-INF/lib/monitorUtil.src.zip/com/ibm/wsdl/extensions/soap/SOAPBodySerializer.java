package com.ibm.wsdl.extensions.soap;

import com.ibm.wsdl.Constants;
import com.ibm.wsdl.util.StringUtils;
import com.ibm.wsdl.util.xml.DOMUtils;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionDeserializer;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.mime.MIMEPart;
import javax.wsdl.extensions.soap.SOAPBody;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class SOAPBodySerializer
  implements ExtensionSerializer, ExtensionDeserializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPBody localSOAPBody = (SOAPBody)paramExtensibilityElement;
    if (localSOAPBody != null)
    {
      String str = DOMUtils.getQualifiedValue("http://schemas.xmlsoap.org/wsdl/soap/", "body", paramDefinition);
      if ((paramClass != null) && (MIMEPart.class.isAssignableFrom(paramClass)))
        paramPrintWriter.print("    ");
      paramPrintWriter.print("        <" + str);
      DOMUtils.printAttribute("parts", StringUtils.getNMTokens(localSOAPBody.getParts()), paramPrintWriter);
      DOMUtils.printAttribute("use", localSOAPBody.getUse(), paramPrintWriter);
      DOMUtils.printAttribute("encodingStyle", StringUtils.getNMTokens(localSOAPBody.getEncodingStyles()), paramPrintWriter);
      DOMUtils.printAttribute("namespace", localSOAPBody.getNamespaceURI(), paramPrintWriter);
      Boolean localBoolean = localSOAPBody.getRequired();
      if (localBoolean != null)
        DOMUtils.printQualifiedAttribute(Constants.Q_ATTR_REQUIRED, localBoolean.toString(), paramDefinition, paramPrintWriter);
      paramPrintWriter.println("/>");
    }
  }

  public ExtensibilityElement unmarshall(Class paramClass, QName paramQName, Element paramElement, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    SOAPBody localSOAPBody = (SOAPBody)paramExtensionRegistry.createExtension(paramClass, paramQName);
    String str1 = DOMUtils.getAttribute(paramElement, "parts");
    String str2 = DOMUtils.getAttribute(paramElement, "use");
    String str3 = DOMUtils.getAttribute(paramElement, "encodingStyle");
    String str4 = DOMUtils.getAttribute(paramElement, "namespace");
    String str5 = DOMUtils.getAttributeNS(paramElement, "http://schemas.xmlsoap.org/wsdl/", "required");
    if (str1 != null)
      localSOAPBody.setParts(StringUtils.parseNMTokens(str1));
    if (str2 != null)
      localSOAPBody.setUse(str2);
    if (str3 != null)
      localSOAPBody.setEncodingStyles(StringUtils.parseNMTokens(str3));
    if (str4 != null)
      localSOAPBody.setNamespaceURI(str4);
    if (str5 != null)
      localSOAPBody.setRequired(new Boolean(str5));
    return localSOAPBody;
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.soap.SOAPBodySerializer
 * JD-Core Version:    0.6.0
 */