/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketGlobalCancelForwardRequest
/*    */ {
/*    */   byte[] payload;
/*    */   public boolean wantReply;
/*    */   public String bindAddress;
/*    */   public int bindPort;
/*    */ 
/*    */   public PacketGlobalCancelForwardRequest(boolean wantReply, String bindAddress, int bindPort)
/*    */   {
/* 20 */     this.wantReply = wantReply;
/* 21 */     this.bindAddress = bindAddress;
/* 22 */     this.bindPort = bindPort;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 27 */     if (this.payload == null)
/*    */     {
/* 29 */       TypesWriter tw = new TypesWriter();
/* 30 */       tw.writeByte(80);
/*    */ 
/* 32 */       tw.writeString("cancel-tcpip-forward");
/* 33 */       tw.writeBoolean(this.wantReply);
/* 34 */       tw.writeString(this.bindAddress);
/* 35 */       tw.writeUINT32(this.bindPort);
/*    */ 
/* 37 */       this.payload = tw.getBytes();
/*    */     }
/* 39 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketGlobalCancelForwardRequest
 * JD-Core Version:    0.6.0
 */