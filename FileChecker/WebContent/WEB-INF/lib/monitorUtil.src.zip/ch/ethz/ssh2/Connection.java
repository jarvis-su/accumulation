/*      */ package ch.ethz.ssh2;
/*      */ 
/*      */ import ch.ethz.ssh2.auth.AuthenticationManager;
/*      */ import ch.ethz.ssh2.channel.ChannelManager;
/*      */ import ch.ethz.ssh2.crypto.CryptoWishList;
/*      */ import ch.ethz.ssh2.crypto.cipher.BlockCipherFactory;
/*      */ import ch.ethz.ssh2.crypto.digest.MAC;
/*      */ import ch.ethz.ssh2.transport.KexManager;
/*      */ import ch.ethz.ssh2.transport.TransportManager;
/*      */ import ch.ethz.ssh2.util.TimeoutService;
/*      */ import ch.ethz.ssh2.util.TimeoutService.TimeoutToken;
/*      */ import java.io.CharArrayWriter;
/*      */ import java.io.File;
/*      */ import java.io.FileReader;
/*      */ import java.io.IOException;
/*      */ import java.net.SocketTimeoutException;
/*      */ import java.security.SecureRandom;
/*      */ import java.util.Vector;
/*      */ 
/*      */ public class Connection
/*      */ {
/*      */   public static final String identification = "Ganymed Build_210";
/*      */   private SecureRandom generator;
/*      */   private AuthenticationManager am;
/*   84 */   private boolean authenticated = false;
/*      */   private ChannelManager cm;
/*   87 */   private CryptoWishList cryptoWishList = new CryptoWishList();
/*      */ 
/*   89 */   private DHGexParameters dhgexpara = new DHGexParameters();
/*      */   private final String hostname;
/*      */   private final int port;
/*      */   private TransportManager tm;
/*   97 */   private boolean tcpNoDelay = false;
/*      */ 
/*   99 */   private ProxyData proxyData = null;
/*      */ 
/*  101 */   private Vector connectionMonitors = new Vector();
/*      */ 
/*      */   public static synchronized String[] getAvailableCiphers()
/*      */   {
/*   59 */     return BlockCipherFactory.getDefaultCipherList();
/*      */   }
/*      */ 
/*      */   public static synchronized String[] getAvailableMACs()
/*      */   {
/*   69 */     return MAC.getMacList();
/*      */   }
/*      */ 
/*      */   public static synchronized String[] getAvailableServerHostKeyAlgorithms()
/*      */   {
/*   79 */     return KexManager.getDefaultServerHostkeyAlgorithmList();
/*      */   }
/*      */ 
/*      */   public Connection(String hostname)
/*      */   {
/*  113 */     this(hostname, 22);
/*      */   }
/*      */ 
/*      */   public Connection(String hostname, int port)
/*      */   {
/*  127 */     this.hostname = hostname;
/*  128 */     this.port = port;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public synchronized boolean authenticateWithDSA(String user, String pem, String password)
/*      */     throws IOException
/*      */   {
/*  164 */     if (this.tm == null) {
/*  165 */       throw new IllegalStateException("Connection is not established!");
/*      */     }
/*  167 */     if (this.authenticated) {
/*  168 */       throw new IllegalStateException("Connection is already authenticated!");
/*      */     }
/*  170 */     if (this.am == null) {
/*  171 */       this.am = new AuthenticationManager(this.tm);
/*      */     }
/*  173 */     if (this.cm == null) {
/*  174 */       this.cm = new ChannelManager(this.tm);
/*      */     }
/*  176 */     if (user == null) {
/*  177 */       throw new IllegalArgumentException("user argument is null");
/*      */     }
/*  179 */     if (pem == null) {
/*  180 */       throw new IllegalArgumentException("pem argument is null");
/*      */     }
/*  182 */     this.authenticated = this.am.authenticatePublicKey(user, pem.toCharArray(), password, getOrCreateSecureRND());
/*      */ 
/*  184 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public synchronized boolean authenticateWithKeyboardInteractive(String user, InteractiveCallback cb)
/*      */     throws IOException
/*      */   {
/*  202 */     return authenticateWithKeyboardInteractive(user, null, cb);
/*      */   }
/*      */ 
/*      */   public synchronized boolean authenticateWithKeyboardInteractive(String user, String[] submethods, InteractiveCallback cb)
/*      */     throws IOException
/*      */   {
/*  242 */     if (cb == null) {
/*  243 */       throw new IllegalArgumentException("Callback may not ne NULL!");
/*      */     }
/*  245 */     if (this.tm == null) {
/*  246 */       throw new IllegalStateException("Connection is not established!");
/*      */     }
/*  248 */     if (this.authenticated) {
/*  249 */       throw new IllegalStateException("Connection is already authenticated!");
/*      */     }
/*  251 */     if (this.am == null) {
/*  252 */       this.am = new AuthenticationManager(this.tm);
/*      */     }
/*  254 */     if (this.cm == null) {
/*  255 */       this.cm = new ChannelManager(this.tm);
/*      */     }
/*  257 */     if (user == null) {
/*  258 */       throw new IllegalArgumentException("user argument is null");
/*      */     }
/*  260 */     this.authenticated = this.am.authenticateInteractive(user, submethods, cb);
/*      */ 
/*  262 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public synchronized boolean authenticateWithPassword(String user, String password)
/*      */     throws IOException
/*      */   {
/*  291 */     if (this.tm == null) {
/*  292 */       throw new IllegalStateException("Connection is not established!");
/*      */     }
/*  294 */     if (this.authenticated) {
/*  295 */       throw new IllegalStateException("Connection is already authenticated!");
/*      */     }
/*  297 */     if (this.am == null) {
/*  298 */       this.am = new AuthenticationManager(this.tm);
/*      */     }
/*  300 */     if (this.cm == null) {
/*  301 */       this.cm = new ChannelManager(this.tm);
/*      */     }
/*  303 */     if (user == null) {
/*  304 */       throw new IllegalArgumentException("user argument is null");
/*      */     }
/*  306 */     if (password == null) {
/*  307 */       throw new IllegalArgumentException("password argument is null");
/*      */     }
/*  309 */     this.authenticated = this.am.authenticatePassword(user, password);
/*      */ 
/*  311 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public synchronized boolean authenticateWithPublicKey(String user, char[] pemPrivateKey, String password)
/*      */     throws IOException
/*      */   {
/*  359 */     if (this.tm == null) {
/*  360 */       throw new IllegalStateException("Connection is not established!");
/*      */     }
/*  362 */     if (this.authenticated) {
/*  363 */       throw new IllegalStateException("Connection is already authenticated!");
/*      */     }
/*  365 */     if (this.am == null) {
/*  366 */       this.am = new AuthenticationManager(this.tm);
/*      */     }
/*  368 */     if (this.cm == null) {
/*  369 */       this.cm = new ChannelManager(this.tm);
/*      */     }
/*  371 */     if (user == null) {
/*  372 */       throw new IllegalArgumentException("user argument is null");
/*      */     }
/*  374 */     if (pemPrivateKey == null) {
/*  375 */       throw new IllegalArgumentException("pemPrivateKey argument is null");
/*      */     }
/*  377 */     this.authenticated = this.am.authenticatePublicKey(user, pemPrivateKey, password, getOrCreateSecureRND());
/*      */ 
/*  379 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public synchronized boolean authenticateWithPublicKey(String user, File pemFile, String password)
/*      */     throws IOException
/*      */   {
/*  409 */     if (pemFile == null) {
/*  410 */       throw new IllegalArgumentException("pemFile argument is null");
/*      */     }
/*  412 */     char[] buff = new char[256];
/*      */ 
/*  414 */     CharArrayWriter cw = new CharArrayWriter();
/*      */ 
/*  416 */     FileReader fr = new FileReader(pemFile);
/*      */     while (true)
/*      */     {
/*  420 */       int len = fr.read(buff);
/*  421 */       if (len < 0)
/*      */         break;
/*  423 */       cw.write(buff, 0, len);
/*      */     }
/*      */ 
/*  426 */     fr.close();
/*      */ 
/*  428 */     return authenticateWithPublicKey(user, cw.toCharArray(), password);
/*      */   }
/*      */ 
/*      */   public synchronized void addConnectionMonitor(ConnectionMonitor cmon)
/*      */   {
/*  446 */     if (cmon == null) {
/*  447 */       throw new IllegalArgumentException("cmon argument is null");
/*      */     }
/*  449 */     this.connectionMonitors.addElement(cmon);
/*      */ 
/*  451 */     if (this.tm != null)
/*  452 */       this.tm.setConnectionMonitors(this.connectionMonitors);
/*      */   }
/*      */ 
/*      */   public synchronized void close()
/*      */   {
/*  463 */     Throwable t = new Throwable("Closed due to user request.");
/*  464 */     close(t, false);
/*      */   }
/*      */ 
/*      */   private void close(Throwable t, boolean hard)
/*      */   {
/*  469 */     if (this.cm != null) {
/*  470 */       this.cm.closeAllChannels();
/*      */     }
/*  472 */     if (this.tm != null)
/*      */     {
/*  474 */       this.tm.close(t, !hard);
/*  475 */       this.tm = null;
/*      */     }
/*  477 */     this.am = null;
/*  478 */     this.cm = null;
/*  479 */     this.authenticated = false;
/*      */   }
/*      */ 
/*      */   public synchronized ConnectionInfo connect()
/*      */     throws IOException
/*      */   {
/*  490 */     return connect(null, 0, 0);
/*      */   }
/*      */ 
/*      */   public synchronized ConnectionInfo connect(ServerHostKeyVerifier verifier)
/*      */     throws IOException
/*      */   {
/*  501 */     return connect(verifier, 0, 0);
/*      */   }
/*      */ 
/*      */   public synchronized ConnectionInfo connect(ServerHostKeyVerifier verifier, int connectTimeout, int kexTimeout)
/*      */     throws IOException
/*      */   {
/*  584 */     if (this.tm != null) {
/*  585 */       throw new IOException("Connection to " + this.hostname + " is already in connected state!");
/*      */     }
/*  587 */     if (connectTimeout < 0) {
/*  588 */       throw new IllegalArgumentException("connectTimeout must be non-negative!");
/*      */     }
/*  590 */     if (kexTimeout < 0) {
/*  591 */       throw new IllegalArgumentException("kexTimeout must be non-negative!");
/*      */     }
/*  593 */     Connection.1.TimeoutState state = new Connection.1.TimeoutState(this);
/*      */ 
/*  595 */     this.tm = new TransportManager(this.hostname, this.port);
/*      */ 
/*  597 */     this.tm.setConnectionMonitors(this.connectionMonitors);
/*      */ 
/*  611 */     synchronized (this.tm)
/*      */     {
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  618 */       TimeoutService.TimeoutToken token = null;
/*      */ 
/*  620 */       if (kexTimeout > 0)
/*      */       {
/*  622 */         Runnable timeoutHandler = new Runnable(state) {
/*      */           private final Connection.1.TimeoutState val$state;
/*      */ 
/*  626 */           public void run() { synchronized (this.val$state)
/*      */             {
/*  628 */               if (this.val$state.isCancelled)
/*  629 */                 return;
/*  630 */               this.val$state.timeoutSocketClosed = true;
/*  631 */               Connection.this.tm.close(new SocketTimeoutException("The connect timeout expired"), false);
/*      */             }
/*      */           }
/*      */         };
/*  636 */         long timeoutHorizont = System.currentTimeMillis() + kexTimeout;
/*      */ 
/*  638 */         token = TimeoutService.addTimeoutHandler(timeoutHorizont, timeoutHandler);
/*      */       }
/*      */ 
/*      */       try
/*      */       {
/*  643 */         this.tm.initialize(this.cryptoWishList, verifier, this.dhgexpara, connectTimeout, getOrCreateSecureRND(), this.proxyData);
/*      */       }
/*      */       catch (SocketTimeoutException se)
/*      */       {
/*  647 */         throw ((SocketTimeoutException)new SocketTimeoutException(
/*  648 */           "The connect() operation on the socket timed out.").initCause(se));
/*      */       }
/*      */ 
/*  651 */       this.tm.setTcpNoDelay(this.tcpNoDelay);
/*      */ 
/*  655 */       ConnectionInfo ci = this.tm.getConnectionInfo(1);
/*      */ 
/*  659 */       if (token != null)
/*      */       {
/*  661 */         TimeoutService.cancelTimeoutHandler(token);
/*      */ 
/*  665 */         synchronized (state)
/*      */         {
/*  667 */           if (state.timeoutSocketClosed) {
/*  668 */             throw new IOException("This exception will be replaced by the one below =)");
/*      */           }
/*      */ 
/*  673 */           state.isCancelled = true;
/*      */         }
/*      */       }
/*      */ 
/*  677 */       return ci;
/*      */     }
/*      */     catch (SocketTimeoutException ste)
/*      */     {
/*  681 */       throw ste;
/*      */     }
/*      */     catch (IOException e1)
/*      */     {
/*  686 */       close(new Throwable("There was a problem during connect."), false);
/*      */ 
/*  688 */       synchronized (state)
/*      */       {
/*  691 */         if (state.timeoutSocketClosed) {
/*  692 */           throw new SocketTimeoutException("The kexTimeout (" + kexTimeout + " ms) expired.");
/*      */         }
/*      */       }
/*      */ 
/*  696 */       if ((e1 instanceof HTTPProxyException))
/*  697 */         throw e1;
/*      */     }
/*  699 */     throw ((IOException)new IOException("There was a problem while connecting to " + this.hostname + ":" + this.port)
/*  700 */       .initCause(e1));
/*      */   }
/*      */ 
/*      */   public synchronized LocalPortForwarder createLocalPortForwarder(int local_port, String host_to_connect, int port_to_connect)
/*      */     throws IOException
/*      */   {
/*  722 */     if (this.tm == null) {
/*  723 */       throw new IllegalStateException("Cannot forward ports, you need to establish a connection first.");
/*      */     }
/*  725 */     if (!this.authenticated) {
/*  726 */       throw new IllegalStateException("Cannot forward ports, connection is not authenticated.");
/*      */     }
/*  728 */     return new LocalPortForwarder(this.cm, local_port, host_to_connect, port_to_connect);
/*      */   }
/*      */ 
/*      */   public synchronized LocalStreamForwarder createLocalStreamForwarder(String host_to_connect, int port_to_connect)
/*      */     throws IOException
/*      */   {
/*  745 */     if (this.tm == null) {
/*  746 */       throw new IllegalStateException("Cannot forward, you need to establish a connection first.");
/*      */     }
/*  748 */     if (!this.authenticated) {
/*  749 */       throw new IllegalStateException("Cannot forward, connection is not authenticated.");
/*      */     }
/*  751 */     return new LocalStreamForwarder(this.cm, host_to_connect, port_to_connect);
/*      */   }
/*      */ 
/*      */   public synchronized SCPClient createSCPClient()
/*      */     throws IOException
/*      */   {
/*  768 */     if (this.tm == null) {
/*  769 */       throw new IllegalStateException("Cannot create SCP client, you need to establish a connection first.");
/*      */     }
/*  771 */     if (!this.authenticated) {
/*  772 */       throw new IllegalStateException("Cannot create SCP client, connection is not authenticated.");
/*      */     }
/*  774 */     return new SCPClient(this);
/*      */   }
/*      */ 
/*      */   public synchronized void forceKeyExchange()
/*      */     throws IOException
/*      */   {
/*  792 */     if (this.tm == null) {
/*  793 */       throw new IllegalStateException("You need to establish a connection first.");
/*      */     }
/*  795 */     this.tm.forceKeyExchange(this.cryptoWishList, this.dhgexpara);
/*      */   }
/*      */ 
/*      */   public synchronized String getHostname()
/*      */   {
/*  805 */     return this.hostname;
/*      */   }
/*      */ 
/*      */   public synchronized int getPort()
/*      */   {
/*  815 */     return this.port;
/*      */   }
/*      */ 
/*      */   public synchronized ConnectionInfo getConnectionInfo()
/*      */     throws IOException
/*      */   {
/*  829 */     if (this.tm == null)
/*  830 */       throw new IllegalStateException(
/*  831 */         "Cannot get details of connection, you need to establish a connection first.");
/*  832 */     return this.tm.getConnectionInfo(1);
/*      */   }
/*      */ 
/*      */   public synchronized String[] getRemainingAuthMethods(String user)
/*      */     throws IOException
/*      */   {
/*  861 */     if (user == null) {
/*  862 */       throw new IllegalArgumentException("user argument may not be NULL!");
/*      */     }
/*  864 */     if (this.tm == null) {
/*  865 */       throw new IllegalStateException("Connection is not established!");
/*      */     }
/*  867 */     if (this.authenticated) {
/*  868 */       throw new IllegalStateException("Connection is already authenticated!");
/*      */     }
/*  870 */     if (this.am == null) {
/*  871 */       this.am = new AuthenticationManager(this.tm);
/*      */     }
/*  873 */     if (this.cm == null) {
/*  874 */       this.cm = new ChannelManager(this.tm);
/*      */     }
/*  876 */     return this.am.getRemainingMethods(user);
/*      */   }
/*      */ 
/*      */   public synchronized boolean isAuthenticationComplete()
/*      */   {
/*  888 */     return this.authenticated;
/*      */   }
/*      */ 
/*      */   public synchronized boolean isAuthenticationPartialSuccess()
/*      */   {
/*  906 */     if (this.am == null) {
/*  907 */       return false;
/*      */     }
/*  909 */     return this.am.getPartialSuccess();
/*      */   }
/*      */ 
/*      */   public synchronized boolean isAuthMethodAvailable(String user, String method)
/*      */     throws IOException
/*      */   {
/*  927 */     if (method == null) {
/*  928 */       throw new IllegalArgumentException("method argument may not be NULL!");
/*      */     }
/*  930 */     String[] methods = getRemainingAuthMethods(user);
/*      */ 
/*  932 */     for (int i = 0; i < methods.length; i++)
/*      */     {
/*  934 */       if (methods[i].compareTo(method) == 0) {
/*  935 */         return true;
/*      */       }
/*      */     }
/*  938 */     return false;
/*      */   }
/*      */ 
/*      */   private final SecureRandom getOrCreateSecureRND()
/*      */   {
/*  943 */     if (this.generator == null) {
/*  944 */       this.generator = new SecureRandom();
/*      */     }
/*  946 */     return this.generator;
/*      */   }
/*      */ 
/*      */   public synchronized Session openSession()
/*      */     throws IOException
/*      */   {
/*  959 */     if (this.tm == null) {
/*  960 */       throw new IllegalStateException("Cannot open session, you need to establish a connection first.");
/*      */     }
/*  962 */     if (!this.authenticated) {
/*  963 */       throw new IllegalStateException("Cannot open session, connection is not authenticated.");
/*      */     }
/*  965 */     return new Session(this.cm, getOrCreateSecureRND());
/*      */   }
/*      */ 
/*      */   private String[] removeDuplicates(String[] list)
/*      */   {
/*  978 */     if ((list == null) || (list.length < 2)) {
/*  979 */       return list;
/*      */     }
/*  981 */     String[] list2 = new String[list.length];
/*      */ 
/*  983 */     int count = 0;
/*      */ 
/*  985 */     for (int i = 0; i < list.length; i++)
/*      */     {
/*  987 */       boolean duplicate = false;
/*      */ 
/*  989 */       String element = list[i];
/*      */ 
/*  991 */       for (int j = 0; j < count; j++)
/*      */       {
/*  993 */         if (((element != null) || (list2[j] != null)) && ((element == null) || (!element.equals(list2[j]))))
/*      */           continue;
/*  995 */         duplicate = true;
/*  996 */         break;
/*      */       }
/*      */ 
/* 1000 */       if (duplicate) {
/*      */         continue;
/*      */       }
/* 1003 */       list2[(count++)] = list[i];
/*      */     }
/*      */ 
/* 1006 */     if (count == list2.length) {
/* 1007 */       return list2;
/*      */     }
/* 1009 */     String[] tmp = new String[count];
/* 1010 */     System.arraycopy(list2, 0, tmp, 0, count);
/*      */ 
/* 1012 */     return tmp;
/*      */   }
/*      */ 
/*      */   public synchronized void setClient2ServerCiphers(String[] ciphers)
/*      */   {
/* 1022 */     if ((ciphers == null) || (ciphers.length == 0))
/* 1023 */       throw new IllegalArgumentException();
/* 1024 */     ciphers = removeDuplicates(ciphers);
/* 1025 */     BlockCipherFactory.checkCipherList(ciphers);
/* 1026 */     this.cryptoWishList.c2s_enc_algos = ciphers;
/*      */   }
/*      */ 
/*      */   public synchronized void setClient2ServerMACs(String[] macs)
/*      */   {
/* 1036 */     if ((macs == null) || (macs.length == 0))
/* 1037 */       throw new IllegalArgumentException();
/* 1038 */     macs = removeDuplicates(macs);
/* 1039 */     MAC.checkMacList(macs);
/* 1040 */     this.cryptoWishList.c2s_mac_algos = macs;
/*      */   }
/*      */ 
/*      */   public synchronized void setDHGexParameters(DHGexParameters dgp)
/*      */   {
/* 1053 */     if (dgp == null) {
/* 1054 */       throw new IllegalArgumentException();
/*      */     }
/* 1056 */     this.dhgexpara = dgp;
/*      */   }
/*      */ 
/*      */   public synchronized void setServer2ClientCiphers(String[] ciphers)
/*      */   {
/* 1066 */     if ((ciphers == null) || (ciphers.length == 0))
/* 1067 */       throw new IllegalArgumentException();
/* 1068 */     ciphers = removeDuplicates(ciphers);
/* 1069 */     BlockCipherFactory.checkCipherList(ciphers);
/* 1070 */     this.cryptoWishList.s2c_enc_algos = ciphers;
/*      */   }
/*      */ 
/*      */   public synchronized void setServer2ClientMACs(String[] macs)
/*      */   {
/* 1080 */     if ((macs == null) || (macs.length == 0)) {
/* 1081 */       throw new IllegalArgumentException();
/*      */     }
/* 1083 */     macs = removeDuplicates(macs);
/* 1084 */     MAC.checkMacList(macs);
/* 1085 */     this.cryptoWishList.s2c_mac_algos = macs;
/*      */   }
/*      */ 
/*      */   public synchronized void setServerHostKeyAlgorithms(String[] algos)
/*      */   {
/* 1102 */     if ((algos == null) || (algos.length == 0)) {
/* 1103 */       throw new IllegalArgumentException();
/*      */     }
/* 1105 */     algos = removeDuplicates(algos);
/* 1106 */     KexManager.checkServerHostkeyAlgorithmsList(algos);
/* 1107 */     this.cryptoWishList.serverHostKeyAlgorithms = algos;
/*      */   }
/*      */ 
/*      */   public synchronized void setTCPNoDelay(boolean enable)
/*      */     throws IOException
/*      */   {
/* 1122 */     this.tcpNoDelay = enable;
/*      */ 
/* 1124 */     if (this.tm != null)
/* 1125 */       this.tm.setTcpNoDelay(enable);
/*      */   }
/*      */ 
/*      */   public synchronized void setProxyData(ProxyData proxyData)
/*      */   {
/* 1145 */     this.proxyData = proxyData;
/*      */   }
/*      */ 
/*      */   public synchronized void requestRemotePortForwarding(String bindAddress, int bindPort, String targetAddress, int targetPort)
/*      */     throws IOException
/*      */   {
/* 1188 */     if (this.tm == null) {
/* 1189 */       throw new IllegalStateException("You need to establish a connection first.");
/*      */     }
/* 1191 */     if (!this.authenticated) {
/* 1192 */       throw new IllegalStateException("The connection is not authenticated.");
/*      */     }
/* 1194 */     if ((bindAddress == null) || (targetAddress == null) || (bindPort <= 0) || (targetPort <= 0)) {
/* 1195 */       throw new IllegalArgumentException();
/*      */     }
/* 1197 */     this.cm.requestGlobalForward(bindAddress, bindPort, targetAddress, targetPort);
/*      */   }
/*      */ 
/*      */   public synchronized void cancelRemotePortForwarding(int bindPort)
/*      */     throws IOException
/*      */   {
/* 1212 */     if (this.tm == null) {
/* 1213 */       throw new IllegalStateException("You need to establish a connection first.");
/*      */     }
/* 1215 */     if (!this.authenticated) {
/* 1216 */       throw new IllegalStateException("The connection is not authenticated.");
/*      */     }
/* 1218 */     this.cm.requestCancelGlobalForward(bindPort);
/*      */   }
/*      */ 
/*      */   public synchronized void setSecureRandom(SecureRandom rnd)
/*      */   {
/* 1232 */     if (rnd == null) {
/* 1233 */       throw new IllegalArgumentException();
/*      */     }
/* 1235 */     this.generator = rnd;
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.Connection
 * JD-Core Version:    0.6.0
 */