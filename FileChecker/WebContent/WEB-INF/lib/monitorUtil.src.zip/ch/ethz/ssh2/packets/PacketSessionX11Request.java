/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketSessionX11Request
/*    */ {
/*    */   byte[] payload;
/*    */   public int recipientChannelID;
/*    */   public boolean wantReply;
/*    */   public boolean singleConnection;
/*    */   String x11AuthenticationProtocol;
/*    */   String x11AuthenticationCookie;
/*    */   int x11ScreenNumber;
/*    */ 
/*    */   public PacketSessionX11Request(int recipientChannelID, boolean wantReply, boolean singleConnection, String x11AuthenticationProtocol, String x11AuthenticationCookie, int x11ScreenNumber)
/*    */   {
/* 25 */     this.recipientChannelID = recipientChannelID;
/* 26 */     this.wantReply = wantReply;
/*    */ 
/* 28 */     this.singleConnection = singleConnection;
/* 29 */     this.x11AuthenticationProtocol = x11AuthenticationProtocol;
/* 30 */     this.x11AuthenticationCookie = x11AuthenticationCookie;
/* 31 */     this.x11ScreenNumber = x11ScreenNumber;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 36 */     if (this.payload == null)
/*    */     {
/* 38 */       TypesWriter tw = new TypesWriter();
/* 39 */       tw.writeByte(98);
/* 40 */       tw.writeUINT32(this.recipientChannelID);
/* 41 */       tw.writeString("x11-req");
/* 42 */       tw.writeBoolean(this.wantReply);
/*    */ 
/* 44 */       tw.writeBoolean(this.singleConnection);
/* 45 */       tw.writeString(this.x11AuthenticationProtocol);
/* 46 */       tw.writeString(this.x11AuthenticationCookie);
/* 47 */       tw.writeUINT32(this.x11ScreenNumber);
/*    */ 
/* 49 */       this.payload = tw.getBytes();
/*    */     }
/* 51 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketSessionX11Request
 * JD-Core Version:    0.6.0
 */