/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ class PreparedStatement$EndPoint
/*     */ {
/*     */   int begin;
/*     */   int end;
/*     */   private final PreparedStatement this$0;
/*     */ 
/*     */   PreparedStatement$EndPoint(PreparedStatement this$0, int b, int e)
/*     */   {
/* 122 */     this.this$0 = this$0;
/* 123 */     this.begin = b;
/* 124 */     this.end = e;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.PreparedStatement.EndPoint
 * JD-Core Version:    0.6.0
 */