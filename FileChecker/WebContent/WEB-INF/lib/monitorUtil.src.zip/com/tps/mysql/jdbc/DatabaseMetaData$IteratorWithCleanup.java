/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ import java.sql.SQLException;
/*    */ 
/*    */ public abstract class DatabaseMetaData$IteratorWithCleanup
/*    */ {
/*    */   private final DatabaseMetaData this$0;
/*    */ 
/*    */   protected DatabaseMetaData$IteratorWithCleanup(DatabaseMetaData this$0)
/*    */   {
/* 86 */     this.this$0 = this$0;
/*    */   }
/*    */ 
/*    */   abstract void close()
/*    */     throws SQLException;
/*    */ 
/*    */   abstract boolean hasNext()
/*    */     throws SQLException;
/*    */ 
/*    */   abstract Object next()
/*    */     throws SQLException;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.IteratorWithCleanup
 * JD-Core Version:    0.6.0
 */