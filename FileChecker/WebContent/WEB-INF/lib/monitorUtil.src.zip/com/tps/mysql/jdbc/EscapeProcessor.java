/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Calendar;
/*     */ import java.util.Collections;
/*     */ import java.util.GregorianCalendar;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.NoSuchElementException;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ class EscapeProcessor
/*     */ {
/*     */   private static Map JDBC_CONVERT_TO_MYSQL_TYPE_MAP;
/*     */   private static Map JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP;
/*     */ 
/*     */   public static final Object escapeSQL(String sql, boolean serverSupportsConvertFn, Connection conn)
/*     */     throws SQLException
/*     */   {
/* 105 */     boolean replaceEscapeSequence = false;
/* 106 */     String escapeSequence = null;
/*     */ 
/* 108 */     if (sql == null) {
/* 109 */       return null;
/*     */     }
/*     */ 
/* 116 */     int beginBrace = sql.indexOf('{');
/* 117 */     int nextEndBrace = beginBrace == -1 ? -1 : sql.indexOf('}', beginBrace);
/*     */ 
/* 120 */     if (nextEndBrace == -1) {
/* 121 */       return sql;
/*     */     }
/*     */ 
/* 124 */     StringBuffer newSql = new StringBuffer();
/*     */ 
/* 126 */     EscapeTokenizer escapeTokenizer = new EscapeTokenizer(sql);
/*     */ 
/* 128 */     byte usesVariables = 0;
/* 129 */     boolean callingStoredFunction = false;
/*     */ 
/* 131 */     while (escapeTokenizer.hasMoreTokens()) {
/* 132 */       String token = escapeTokenizer.nextToken();
/*     */ 
/* 134 */       if (token.length() != 0) {
/* 135 */         if (token.charAt(0) == '{')
/*     */         {
/* 137 */           if (!token.endsWith("}")) {
/* 138 */             throw SQLError.createSQLException("Not a valid escape sequence: " + token);
/*     */           }
/*     */ 
/* 142 */           if (token.length() > 2) {
/* 143 */             int nestedBrace = token.indexOf('{', 2);
/*     */ 
/* 145 */             if (nestedBrace != -1) {
/* 146 */               StringBuffer buf = new StringBuffer(token.substring(0, 1));
/*     */ 
/* 149 */               Object remainingResults = escapeSQL(token.substring(1, token.length() - 1), serverSupportsConvertFn, conn);
/*     */ 
/* 153 */               String remaining = null;
/*     */ 
/* 155 */               if ((remainingResults instanceof String)) {
/* 156 */                 remaining = (String)remainingResults;
/*     */               } else {
/* 158 */                 remaining = ((EscapeProcessorResult)remainingResults).escapedSql;
/*     */ 
/* 160 */                 if (usesVariables != 1) {
/* 161 */                   usesVariables = ((EscapeProcessorResult)remainingResults).usesVariables;
/*     */                 }
/*     */               }
/*     */ 
/* 165 */               buf.append(remaining);
/*     */ 
/* 167 */               buf.append('}');
/*     */ 
/* 169 */               token = buf.toString();
/*     */             }
/*     */ 
/*     */           }
/*     */ 
/* 175 */           String collapsedToken = removeWhitespace(token);
/*     */ 
/* 180 */           if (StringUtils.startsWithIgnoreCase(collapsedToken, "{escape"))
/*     */           {
/*     */             try {
/* 183 */               StringTokenizer st = new StringTokenizer(token, " '");
/*     */ 
/* 185 */               st.nextToken();
/* 186 */               escapeSequence = st.nextToken();
/*     */ 
/* 188 */               if (escapeSequence.length() < 3) {
/* 189 */                 throw SQLError.createSQLException("Syntax error for escape sequence '" + token + "'", "42000");
/*     */               }
/*     */ 
/* 194 */               escapeSequence = escapeSequence.substring(1, escapeSequence.length() - 1);
/*     */ 
/* 196 */               replaceEscapeSequence = true;
/*     */             } catch (NoSuchElementException e) {
/* 198 */               throw SQLError.createSQLException("Syntax error for escape sequence '" + token + "'", "42000");
/*     */             }
/*     */ 
/*     */           }
/* 202 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{fn"))
/*     */           {
/* 204 */             int startPos = token.toLowerCase().indexOf("fn ") + 3;
/* 205 */             int endPos = token.length() - 1;
/*     */ 
/* 207 */             String fnToken = token.substring(startPos, endPos);
/*     */ 
/* 211 */             if (StringUtils.startsWithIgnoreCaseAndWs(fnToken, "convert"))
/*     */             {
/* 213 */               newSql.append(processConvertToken(fnToken, serverSupportsConvertFn));
/*     */             }
/*     */             else
/*     */             {
/* 217 */               newSql.append(fnToken);
/*     */             }
/* 219 */           } else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{d"))
/*     */           {
/* 221 */             int startPos = token.indexOf('\'') + 1;
/* 222 */             int endPos = token.lastIndexOf('\'');
/*     */ 
/* 224 */             if ((startPos == -1) || (endPos == -1)) {
/* 225 */               throw SQLError.createSQLException("Syntax error for DATE escape sequence '" + token + "'", "42000");
/*     */             }
/*     */ 
/* 230 */             String argument = token.substring(startPos, endPos);
/*     */             try
/*     */             {
/* 233 */               StringTokenizer st = new StringTokenizer(argument, " -");
/*     */ 
/* 235 */               String year4 = st.nextToken();
/* 236 */               String month2 = st.nextToken();
/* 237 */               String day2 = st.nextToken();
/* 238 */               String dateString = "'" + year4 + "-" + month2 + "-" + day2 + "'";
/*     */ 
/* 240 */               newSql.append(dateString);
/*     */             } catch (NoSuchElementException e) {
/* 242 */               throw SQLError.createSQLException("Syntax error for DATE escape sequence '" + argument + "'", "42000");
/*     */             }
/*     */ 
/*     */           }
/* 246 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{ts"))
/*     */           {
/* 248 */             int startPos = token.indexOf('\'') + 1;
/* 249 */             int endPos = token.lastIndexOf('\'');
/*     */ 
/* 251 */             if ((startPos == -1) || (endPos == -1)) {
/* 252 */               throw SQLError.createSQLException("Syntax error for TIMESTAMP escape sequence '" + token + "'", "42000");
/*     */             }
/*     */ 
/* 257 */             String argument = token.substring(startPos, endPos);
/*     */             try
/*     */             {
/* 260 */               StringTokenizer st = new StringTokenizer(argument, " .-:");
/*     */ 
/* 262 */               String year4 = st.nextToken();
/* 263 */               String month2 = st.nextToken();
/* 264 */               String day2 = st.nextToken();
/* 265 */               String hour = st.nextToken();
/* 266 */               String minute = st.nextToken();
/* 267 */               String second = st.nextToken();
/*     */ 
/* 293 */               if ((!conn.getUseTimezone()) && (!conn.getUseJDBCCompliantTimezoneShift())) {
/* 294 */                 newSql.append("'").append(year4).append("-").append(month2).append("-").append(day2).append(" ").append(hour).append(":").append(minute).append(":").append(second).append("'");
/*     */               }
/*     */               else
/*     */               {
/*     */                 Calendar sessionCalendar;
/*     */                 Calendar sessionCalendar;
/* 302 */                 if (conn != null) {
/* 303 */                   sessionCalendar = conn.getCalendarInstanceForSessionOrNew();
/*     */                 } else {
/* 305 */                   sessionCalendar = new GregorianCalendar();
/* 306 */                   sessionCalendar.setTimeZone(TimeZone.getTimeZone("GMT"));
/*     */                 }
/*     */                 try
/*     */                 {
/* 310 */                   int year4Int = Integer.parseInt(year4);
/* 311 */                   int month2Int = Integer.parseInt(month2);
/* 312 */                   int day2Int = Integer.parseInt(day2);
/* 313 */                   int hourInt = Integer.parseInt(hour);
/* 314 */                   int minuteInt = Integer.parseInt(minute);
/* 315 */                   int secondInt = Integer.parseInt(second);
/*     */ 
/* 317 */                   synchronized (sessionCalendar) {
/* 318 */                     boolean useGmtMillis = conn.getUseGmtMillisForDatetimes();
/*     */ 
/* 320 */                     Timestamp toBeAdjusted = TimeUtil.fastTimestampCreate(useGmtMillis, useGmtMillis ? Calendar.getInstance(TimeZone.getTimeZone("GMT")) : null, sessionCalendar, year4Int, month2Int, day2Int, hourInt, minuteInt, secondInt, 0);
/*     */ 
/* 331 */                     Timestamp inServerTimezone = TimeUtil.changeTimezone(conn, sessionCalendar, null, toBeAdjusted, sessionCalendar.getTimeZone(), conn.getServerTimezoneTZ(), false);
/*     */ 
/* 341 */                     newSql.append("'");
/*     */ 
/* 343 */                     String timezoneLiteral = inServerTimezone.toString();
/*     */ 
/* 345 */                     int indexOfDot = timezoneLiteral.indexOf(".");
/*     */ 
/* 347 */                     if (indexOfDot != -1) {
/* 348 */                       timezoneLiteral = timezoneLiteral.substring(0, indexOfDot);
/*     */                     }
/*     */ 
/* 351 */                     newSql.append(timezoneLiteral);
/*     */                   }
/*     */ 
/* 354 */                   newSql.append("'");
/*     */                 }
/*     */                 catch (NumberFormatException nfe)
/*     */                 {
/* 358 */                   throw SQLError.createSQLException("Syntax error in TIMESTAMP escape sequence '" + token + "'.", "S1009");
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (NoSuchElementException e)
/*     */             {
/* 364 */               throw SQLError.createSQLException("Syntax error for TIMESTAMP escape sequence '" + argument + "'", "42000");
/*     */             }
/*     */ 
/*     */           }
/* 368 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{t"))
/*     */           {
/* 370 */             int startPos = token.indexOf('\'') + 1;
/* 371 */             int endPos = token.lastIndexOf('\'');
/*     */ 
/* 373 */             if ((startPos == -1) || (endPos == -1)) {
/* 374 */               throw SQLError.createSQLException("Syntax error for TIME escape sequence '" + token + "'", "42000");
/*     */             }
/*     */ 
/* 379 */             String argument = token.substring(startPos, endPos);
/*     */             try
/*     */             {
/* 382 */               StringTokenizer st = new StringTokenizer(argument, " :");
/*     */ 
/* 384 */               String hour = st.nextToken();
/* 385 */               String minute = st.nextToken();
/* 386 */               String second = st.nextToken();
/*     */ 
/* 388 */               if (!conn.getUseTimezone()) {
/* 389 */                 String timeString = "'" + hour + ":" + minute + ":" + second + "'";
/*     */ 
/* 391 */                 newSql.append(timeString);
/*     */               } else {
/* 393 */                 Calendar sessionCalendar = null;
/*     */ 
/* 395 */                 if (conn != null)
/* 396 */                   sessionCalendar = conn.getCalendarInstanceForSessionOrNew();
/*     */                 else {
/* 398 */                   sessionCalendar = new GregorianCalendar();
/*     */                 }
/*     */                 try
/*     */                 {
/* 402 */                   int hourInt = Integer.parseInt(hour);
/* 403 */                   int minuteInt = Integer.parseInt(minute);
/* 404 */                   int secondInt = Integer.parseInt(second);
/*     */ 
/* 406 */                   synchronized (sessionCalendar) {
/* 407 */                     Time toBeAdjusted = TimeUtil.fastTimeCreate(sessionCalendar, hourInt, minuteInt, secondInt);
/*     */ 
/* 413 */                     Time inServerTimezone = TimeUtil.changeTimezone(conn, sessionCalendar, null, toBeAdjusted, sessionCalendar.getTimeZone(), conn.getServerTimezoneTZ(), false);
/*     */ 
/* 422 */                     newSql.append("'");
/* 423 */                     newSql.append(inServerTimezone.toString());
/* 424 */                     newSql.append("'");
/*     */                   }
/*     */                 }
/*     */                 catch (NumberFormatException nfe) {
/* 428 */                   throw SQLError.createSQLException("Syntax error in TIMESTAMP escape sequence '" + token + "'.", "S1009");
/*     */                 }
/*     */               }
/*     */             }
/*     */             catch (NoSuchElementException e)
/*     */             {
/* 434 */               throw SQLError.createSQLException("Syntax error for escape sequence '" + argument + "'", "42000");
/*     */             }
/*     */ 
/*     */           }
/* 438 */           else if ((StringUtils.startsWithIgnoreCase(collapsedToken, "{call")) || (StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call")))
/*     */           {
/* 443 */             int startPos = StringUtils.indexOfIgnoreCase(token, "CALL") + 5;
/*     */ 
/* 445 */             int endPos = token.length() - 1;
/*     */ 
/* 447 */             if (StringUtils.startsWithIgnoreCase(collapsedToken, "{?=call"))
/*     */             {
/* 449 */               callingStoredFunction = true;
/* 450 */               newSql.append("SELECT ");
/* 451 */               newSql.append(token.substring(startPos, endPos));
/*     */             } else {
/* 453 */               callingStoredFunction = false;
/* 454 */               newSql.append("CALL ");
/* 455 */               newSql.append(token.substring(startPos, endPos));
/*     */             }
/*     */ 
/* 458 */             for (int i = endPos - 1; i >= startPos; i--) {
/* 459 */               char c = token.charAt(i);
/*     */ 
/* 461 */               if (Character.isWhitespace(c))
/*     */               {
/*     */                 continue;
/*     */               }
/* 465 */               if (c == ')') break;
/* 466 */               newSql.append("()"); break;
/*     */             }
/*     */ 
/*     */           }
/* 472 */           else if (StringUtils.startsWithIgnoreCase(collapsedToken, "{oj"))
/*     */           {
/* 476 */             newSql.append(token);
/*     */           }
/*     */         } else {
/* 479 */           newSql.append(token);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 484 */     String escapedSql = newSql.toString();
/*     */ 
/* 490 */     if (replaceEscapeSequence) {
/* 491 */       String currentSql = escapedSql;
/*     */ 
/* 493 */       while (currentSql.indexOf(escapeSequence) != -1) {
/* 494 */         int escapePos = currentSql.indexOf(escapeSequence);
/* 495 */         String lhs = currentSql.substring(0, escapePos);
/* 496 */         String rhs = currentSql.substring(escapePos + 1, currentSql.length());
/*     */ 
/* 498 */         currentSql = lhs + "\\" + rhs;
/*     */       }
/*     */ 
/* 501 */       escapedSql = currentSql;
/*     */     }
/*     */ 
/* 504 */     EscapeProcessorResult epr = new EscapeProcessorResult();
/* 505 */     epr.escapedSql = escapedSql;
/* 506 */     epr.callingStoredFunction = callingStoredFunction;
/*     */ 
/* 508 */     if (usesVariables != 1) {
/* 509 */       if (escapeTokenizer.sawVariableUse())
/* 510 */         epr.usesVariables = 1;
/*     */       else {
/* 512 */         epr.usesVariables = 0;
/*     */       }
/*     */     }
/*     */ 
/* 516 */     return epr;
/*     */   }
/*     */ 
/*     */   private static String processConvertToken(String functionToken, boolean serverSupportsConvertFn)
/*     */     throws SQLException
/*     */   {
/* 559 */     int firstIndexOfParen = functionToken.indexOf("(");
/*     */ 
/* 561 */     if (firstIndexOfParen == -1) {
/* 562 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing opening parenthesis in token '" + functionToken + "'.", "42000");
/*     */     }
/*     */ 
/* 568 */     int tokenLength = functionToken.length();
/*     */ 
/* 570 */     int indexOfComma = functionToken.lastIndexOf(",");
/*     */ 
/* 572 */     if (indexOfComma == -1) {
/* 573 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing comma in token '" + functionToken + "'.", "42000");
/*     */     }
/*     */ 
/* 579 */     int indexOfCloseParen = functionToken.indexOf(')', indexOfComma);
/*     */ 
/* 581 */     if (indexOfCloseParen == -1) {
/* 582 */       throw SQLError.createSQLException("Syntax error while processing {fn convert (... , ...)} token, missing closing parenthesis in token '" + functionToken + "'.", "42000");
/*     */     }
/*     */ 
/* 589 */     String expression = functionToken.substring(firstIndexOfParen + 1, indexOfComma);
/*     */ 
/* 591 */     String type = functionToken.substring(indexOfComma + 1, indexOfCloseParen);
/*     */ 
/* 594 */     String newType = null;
/*     */ 
/* 596 */     String trimmedType = type.trim();
/*     */ 
/* 598 */     if (StringUtils.startsWithIgnoreCase(trimmedType, "SQL_")) {
/* 599 */       trimmedType = trimmedType.substring(4, trimmedType.length());
/*     */     }
/*     */ 
/* 602 */     if (serverSupportsConvertFn) {
/* 603 */       newType = (String)JDBC_CONVERT_TO_MYSQL_TYPE_MAP.get(trimmedType.toUpperCase(Locale.ENGLISH));
/*     */     }
/*     */     else {
/* 606 */       newType = (String)JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP.get(trimmedType.toUpperCase(Locale.ENGLISH));
/*     */ 
/* 616 */       if (newType == null) {
/* 617 */         throw SQLError.createSQLException("Can't find conversion re-write for type '" + type + "' that is applicable for this server version while processing escape tokens.", "S1000");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 625 */     if (newType == null) {
/* 626 */       throw SQLError.createSQLException("Unsupported conversion type '" + type.trim() + "' found while processing escape token.", "S1000");
/*     */     }
/*     */ 
/* 631 */     int replaceIndex = newType.indexOf("?");
/*     */ 
/* 633 */     if (replaceIndex != -1) {
/* 634 */       StringBuffer convertRewrite = new StringBuffer(newType.substring(0, replaceIndex));
/*     */ 
/* 636 */       convertRewrite.append(expression);
/* 637 */       convertRewrite.append(newType.substring(replaceIndex + 1, newType.length()));
/*     */ 
/* 640 */       return convertRewrite.toString();
/*     */     }
/*     */ 
/* 643 */     StringBuffer castRewrite = new StringBuffer("CAST(");
/* 644 */     castRewrite.append(expression);
/* 645 */     castRewrite.append(" AS ");
/* 646 */     castRewrite.append(newType);
/* 647 */     castRewrite.append(")");
/*     */ 
/* 649 */     return castRewrite.toString();
/*     */   }
/*     */ 
/*     */   private static String removeWhitespace(String toCollapse)
/*     */   {
/* 663 */     if (toCollapse == null) {
/* 664 */       return null;
/*     */     }
/*     */ 
/* 667 */     int length = toCollapse.length();
/*     */ 
/* 669 */     StringBuffer collapsed = new StringBuffer(length);
/*     */ 
/* 671 */     for (int i = 0; i < length; i++) {
/* 672 */       char c = toCollapse.charAt(i);
/*     */ 
/* 674 */       if (!Character.isWhitespace(c)) {
/* 675 */         collapsed.append(c);
/*     */       }
/*     */     }
/*     */ 
/* 679 */     return collapsed.toString();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  51 */     Map tempMap = new HashMap();
/*     */ 
/*  53 */     tempMap.put("BIGINT", "0 + ?");
/*  54 */     tempMap.put("BINARY", "BINARY");
/*  55 */     tempMap.put("BIT", "0 + ?");
/*  56 */     tempMap.put("CHAR", "CHAR");
/*  57 */     tempMap.put("DATE", "DATE");
/*  58 */     tempMap.put("DECIMAL", "0.0 + ?");
/*  59 */     tempMap.put("DOUBLE", "0.0 + ?");
/*  60 */     tempMap.put("FLOAT", "0.0 + ?");
/*  61 */     tempMap.put("INTEGER", "0 + ?");
/*  62 */     tempMap.put("LONGVARBINARY", "BINARY");
/*  63 */     tempMap.put("LONGVARCHAR", "CONCAT(?)");
/*  64 */     tempMap.put("REAL", "0.0 + ?");
/*  65 */     tempMap.put("SMALLINT", "CONCAT(?)");
/*  66 */     tempMap.put("TIME", "TIME");
/*  67 */     tempMap.put("TIMESTAMP", "DATETIME");
/*  68 */     tempMap.put("TINYINT", "CONCAT(?)");
/*  69 */     tempMap.put("VARBINARY", "BINARY");
/*  70 */     tempMap.put("VARCHAR", "CONCAT(?)");
/*     */ 
/*  72 */     JDBC_CONVERT_TO_MYSQL_TYPE_MAP = Collections.unmodifiableMap(tempMap);
/*     */ 
/*  74 */     tempMap = new HashMap(JDBC_CONVERT_TO_MYSQL_TYPE_MAP);
/*     */ 
/*  76 */     tempMap.put("BINARY", "CONCAT(?)");
/*  77 */     tempMap.put("CHAR", "CONCAT(?)");
/*  78 */     tempMap.remove("DATE");
/*  79 */     tempMap.put("LONGVARBINARY", "CONCAT(?)");
/*  80 */     tempMap.remove("TIME");
/*  81 */     tempMap.remove("TIMESTAMP");
/*  82 */     tempMap.put("VARBINARY", "CONCAT(?)");
/*     */ 
/*  84 */     JDBC_NO_CONVERT_TO_MYSQL_EXPRESSION_MAP = Collections.unmodifiableMap(tempMap);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.EscapeProcessor
 * JD-Core Version:    0.6.0
 */