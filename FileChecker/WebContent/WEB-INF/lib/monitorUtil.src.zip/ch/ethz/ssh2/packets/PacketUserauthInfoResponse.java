/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ public class PacketUserauthInfoResponse
/*    */ {
/*    */   byte[] payload;
/*    */   String[] responses;
/*    */ 
/*    */   public PacketUserauthInfoResponse(String[] responses)
/*    */   {
/* 18 */     this.responses = responses;
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 23 */     if (this.payload == null)
/*    */     {
/* 25 */       TypesWriter tw = new TypesWriter();
/* 26 */       tw.writeByte(61);
/* 27 */       tw.writeUINT32(this.responses.length);
/* 28 */       for (int i = 0; i < this.responses.length; i++) {
/* 29 */         tw.writeString(this.responses[i]);
/*    */       }
/* 31 */       this.payload = tw.getBytes();
/*    */     }
/* 33 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketUserauthInfoResponse
 * JD-Core Version:    0.6.0
 */