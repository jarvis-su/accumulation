package com.ibm.wsdl.extensions.schema;

import com.ibm.wsdl.util.xml.DOM2Writer;
import java.io.PrintWriter;
import java.io.Serializable;
import javax.wsdl.Definition;
import javax.wsdl.WSDLException;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.wsdl.extensions.ExtensionRegistry;
import javax.wsdl.extensions.ExtensionSerializer;
import javax.wsdl.extensions.schema.Schema;
import javax.xml.namespace.QName;

public class SchemaSerializer
  implements ExtensionSerializer, Serializable
{
  public static final long serialVersionUID = 1L;

  public void marshall(Class paramClass, QName paramQName, ExtensibilityElement paramExtensibilityElement, PrintWriter paramPrintWriter, Definition paramDefinition, ExtensionRegistry paramExtensionRegistry)
    throws WSDLException
  {
    Schema localSchema = (Schema)paramExtensibilityElement;
    paramPrintWriter.print("    ");
    DOM2Writer.serializeAsXML(localSchema.getElement(), paramPrintWriter);
    paramPrintWriter.println();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.schema.SchemaSerializer
 * JD-Core Version:    0.6.0
 */