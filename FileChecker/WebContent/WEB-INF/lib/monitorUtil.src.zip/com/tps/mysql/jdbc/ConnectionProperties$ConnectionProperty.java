/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.DriverPropertyInfo;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.RefAddr;
/*     */ import javax.naming.Reference;
/*     */ import javax.naming.StringRefAddr;
/*     */ 
/*     */ abstract class ConnectionProperties$ConnectionProperty
/*     */   implements Serializable
/*     */ {
/*     */   String[] allowableValues;
/*     */   String categoryName;
/*     */   Object defaultValue;
/*     */   int lowerBound;
/*     */   int order;
/*     */   String propertyName;
/*     */   String sinceVersion;
/*     */   int upperBound;
/*     */   Object valueAsObject;
/*     */   boolean required;
/*     */   String description;
/*     */   private final ConnectionProperties this$0;
/*     */ 
/*     */   public ConnectionProperties$ConnectionProperty(ConnectionProperties this$0)
/*     */   {
/* 150 */     this.this$0 = this$0;
/*     */   }
/*     */ 
/*     */   ConnectionProperties$ConnectionProperty(ConnectionProperties this$0, String propertyNameToSet, Object defaultValueToSet, String[] allowableValuesToSet, int lowerBoundToSet, int upperBoundToSet, String descriptionToSet, String sinceVersionToSet, String category, int orderInCategory)
/*     */   {
/* 155 */     this.this$0 = this$0;
/*     */ 
/* 157 */     this.description = descriptionToSet;
/* 158 */     this.propertyName = propertyNameToSet;
/* 159 */     this.defaultValue = defaultValueToSet;
/* 160 */     this.valueAsObject = defaultValueToSet;
/* 161 */     this.allowableValues = allowableValuesToSet;
/* 162 */     this.lowerBound = lowerBoundToSet;
/* 163 */     this.upperBound = upperBoundToSet;
/* 164 */     this.required = false;
/* 165 */     this.sinceVersion = sinceVersionToSet;
/* 166 */     this.categoryName = category;
/* 167 */     this.order = orderInCategory;
/*     */   }
/*     */ 
/*     */   String[] getAllowableValues() {
/* 171 */     return this.allowableValues;
/*     */   }
/*     */ 
/*     */   String getCategoryName()
/*     */   {
/* 178 */     return this.categoryName;
/*     */   }
/*     */ 
/*     */   Object getDefaultValue() {
/* 182 */     return this.defaultValue;
/*     */   }
/*     */ 
/*     */   int getLowerBound() {
/* 186 */     return this.lowerBound;
/*     */   }
/*     */ 
/*     */   int getOrder()
/*     */   {
/* 193 */     return this.order;
/*     */   }
/*     */ 
/*     */   String getPropertyName() {
/* 197 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   int getUpperBound() {
/* 201 */     return this.upperBound;
/*     */   }
/*     */ 
/*     */   Object getValueAsObject() {
/* 205 */     return this.valueAsObject;
/*     */   }
/*     */   abstract boolean hasValueConstraints();
/*     */ 
/*     */   void initializeFrom(Properties extractFrom) throws SQLException {
/* 211 */     String extractedValue = extractFrom.getProperty(getPropertyName());
/* 212 */     extractFrom.remove(getPropertyName());
/* 213 */     initializeFrom(extractedValue);
/*     */   }
/*     */ 
/*     */   void initializeFrom(Reference ref) throws SQLException {
/* 217 */     RefAddr refAddr = ref.get(getPropertyName());
/*     */ 
/* 219 */     if (refAddr != null) {
/* 220 */       String refContentAsString = (String)refAddr.getContent();
/*     */ 
/* 222 */       initializeFrom(refContentAsString);
/*     */     }
/*     */   }
/*     */ 
/*     */   abstract void initializeFrom(String paramString)
/*     */     throws SQLException;
/*     */ 
/*     */   abstract boolean isRangeBased();
/*     */ 
/*     */   void setCategoryName(String categoryName)
/*     */   {
/* 235 */     this.categoryName = categoryName;
/*     */   }
/*     */ 
/*     */   void setOrder(int order)
/*     */   {
/* 243 */     this.order = order;
/*     */   }
/*     */ 
/*     */   void setValueAsObject(Object obj) {
/* 247 */     this.valueAsObject = obj;
/*     */   }
/*     */ 
/*     */   void storeTo(Reference ref) {
/* 251 */     if (getValueAsObject() != null)
/* 252 */       ref.add(new StringRefAddr(getPropertyName(), getValueAsObject().toString()));
/*     */   }
/*     */ 
/*     */   DriverPropertyInfo getAsDriverPropertyInfo()
/*     */   {
/* 258 */     DriverPropertyInfo dpi = new DriverPropertyInfo(this.propertyName, null);
/* 259 */     dpi.choices = getAllowableValues();
/* 260 */     dpi.value = (this.valueAsObject != null ? this.valueAsObject.toString() : null);
/* 261 */     dpi.required = this.required;
/* 262 */     dpi.description = this.description;
/*     */ 
/* 264 */     return dpi;
/*     */   }
/*     */ 
/*     */   void validateStringValues(String valueToValidate) throws SQLException
/*     */   {
/* 269 */     String[] validateAgainst = getAllowableValues();
/*     */ 
/* 271 */     if (valueToValidate == null) {
/* 272 */       return;
/*     */     }
/*     */ 
/* 275 */     if ((validateAgainst == null) || (validateAgainst.length == 0)) {
/* 276 */       return;
/*     */     }
/*     */ 
/* 279 */     for (int i = 0; i < validateAgainst.length; i++) {
/* 280 */       if ((validateAgainst[i] != null) && (validateAgainst[i].equalsIgnoreCase(valueToValidate)))
/*     */       {
/* 282 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 286 */     StringBuffer errorMessageBuf = new StringBuffer();
/*     */ 
/* 288 */     errorMessageBuf.append("The connection property '");
/* 289 */     errorMessageBuf.append(getPropertyName());
/* 290 */     errorMessageBuf.append("' only accepts values of the form: ");
/*     */ 
/* 292 */     if (validateAgainst.length != 0) {
/* 293 */       errorMessageBuf.append("'");
/* 294 */       errorMessageBuf.append(validateAgainst[0]);
/* 295 */       errorMessageBuf.append("'");
/*     */ 
/* 297 */       for (int i = 1; i < validateAgainst.length - 1; i++) {
/* 298 */         errorMessageBuf.append(", ");
/* 299 */         errorMessageBuf.append("'");
/* 300 */         errorMessageBuf.append(validateAgainst[i]);
/* 301 */         errorMessageBuf.append("'");
/*     */       }
/*     */ 
/* 304 */       errorMessageBuf.append(" or '");
/* 305 */       errorMessageBuf.append(validateAgainst[(validateAgainst.length - 1)]);
/*     */ 
/* 307 */       errorMessageBuf.append("'");
/*     */     }
/*     */ 
/* 310 */     errorMessageBuf.append(". The value '");
/* 311 */     errorMessageBuf.append(valueToValidate);
/* 312 */     errorMessageBuf.append("' is not in this set.");
/*     */ 
/* 314 */     throw SQLError.createSQLException(errorMessageBuf.toString(), "S1009");
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ConnectionProperties.ConnectionProperty
 * JD-Core Version:    0.6.0
 */