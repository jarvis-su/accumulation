package com.ibm.wsdl;

import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import javax.wsdl.Binding;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Operation;
import javax.wsdl.OperationType;
import javax.wsdl.PortType;
import javax.wsdl.extensions.ExtensibilityElement;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class BindingImpl
  implements Binding
{
  protected QName name = null;
  protected PortType portType = null;
  protected List bindingOperations = new Vector();
  protected Element docEl = null;
  protected List extElements = new Vector();
  protected boolean isUndefined = true;
  public static final long serialVersionUID = 1L;

  public void setQName(QName paramQName)
  {
    this.name = paramQName;
  }

  public QName getQName()
  {
    return this.name;
  }

  public void setPortType(PortType paramPortType)
  {
    this.portType = paramPortType;
  }

  public PortType getPortType()
  {
    return this.portType;
  }

  public void addBindingOperation(BindingOperation paramBindingOperation)
  {
    this.bindingOperations.add(paramBindingOperation);
  }

  public BindingOperation getBindingOperation(String paramString1, String paramString2, String paramString3)
  {
    int i = 0;
    Object localObject1 = null;
    Iterator localIterator = this.bindingOperations.iterator();
    while (localIterator.hasNext())
    {
      BindingOperation localBindingOperation = (BindingOperation)localIterator.next();
      String str1 = localBindingOperation.getName();
      if ((paramString1 != null) && (str1 != null))
      {
        if (!paramString1.equals(str1))
          localBindingOperation = null;
      }
      else if ((paramString1 != null) || (str1 != null))
        localBindingOperation = null;
      PortType localPortType;
      OperationType localOperationType;
      Object localObject2;
      boolean bool;
      Object localObject3;
      String str2;
      if ((localBindingOperation != null) && (paramString2 != null))
      {
        localPortType = getPortType();
        localOperationType = null;
        if (localPortType != null)
        {
          localObject2 = localPortType.getOperation(paramString1, paramString2, paramString3);
          if (localObject2 != null)
            localOperationType = ((Operation)localObject2).getStyle();
        }
        localObject2 = str1;
        if (localOperationType == OperationType.REQUEST_RESPONSE)
          localObject2 = str1 + "Request";
        else if (localOperationType == OperationType.SOLICIT_RESPONSE)
          localObject2 = str1 + "Solicit";
        bool = paramString2.equals(localObject2);
        localObject3 = localBindingOperation.getBindingInput();
        if (localObject3 != null)
        {
          str2 = ((BindingInput)localObject3).getName();
          if (str2 == null)
          {
            if (!bool)
              localBindingOperation = null;
          }
          else if (!str2.equals(paramString2))
            localBindingOperation = null;
        }
        else
        {
          localBindingOperation = null;
        }
      }
      if ((localBindingOperation != null) && (paramString3 != null))
      {
        localPortType = getPortType();
        localOperationType = null;
        if (localPortType != null)
        {
          localObject2 = localPortType.getOperation(paramString1, paramString2, paramString3);
          if (localObject2 != null)
            localOperationType = ((Operation)localObject2).getStyle();
        }
        localObject2 = str1;
        if ((localOperationType == OperationType.REQUEST_RESPONSE) || (localOperationType == OperationType.SOLICIT_RESPONSE))
          localObject2 = str1 + "Response";
        bool = paramString3.equals(localObject2);
        localObject3 = localBindingOperation.getBindingOutput();
        if (localObject3 != null)
        {
          str2 = ((BindingOutput)localObject3).getName();
          if (str2 == null)
          {
            if (!bool)
              localBindingOperation = null;
          }
          else if (!str2.equals(paramString3))
            localBindingOperation = null;
        }
        else
        {
          localBindingOperation = null;
        }
      }
      if (localBindingOperation == null)
        continue;
      if (i != 0)
        throw new IllegalArgumentException("Duplicate operation with name=" + paramString1 + (paramString2 != null ? ", inputName=" + paramString2 : "") + (paramString3 != null ? ", outputName=" + paramString3 : "") + ", found in portType '" + getQName() + "'.");
      i = 1;
      localObject1 = localBindingOperation;
    }
    return (BindingOperation)(BindingOperation)localObject1;
  }

  public List getBindingOperations()
  {
    return this.bindingOperations;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public void setUndefined(boolean paramBoolean)
  {
    this.isUndefined = paramBoolean;
  }

  public boolean isUndefined()
  {
    return this.isUndefined;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Binding: name=" + this.name);
    if (this.portType != null)
      localStringBuffer.append("\n" + this.portType);
    Iterator localIterator;
    if (this.bindingOperations != null)
    {
      localIterator = this.bindingOperations.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.extElements != null)
    {
      localIterator = this.extElements.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.BindingImpl
 * JD-Core Version:    0.6.0
 */