package com.ibm.wsdl;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.wsdl.BindingFault;
import javax.wsdl.BindingInput;
import javax.wsdl.BindingOperation;
import javax.wsdl.BindingOutput;
import javax.wsdl.Operation;
import javax.wsdl.extensions.ExtensibilityElement;
import org.w3c.dom.Element;

public class BindingOperationImpl
  implements BindingOperation
{
  protected String name = null;
  protected Operation operation = null;
  protected BindingInput bindingInput = null;
  protected BindingOutput bindingOutput = null;
  protected Map bindingFaults = new HashMap();
  protected Element docEl = null;
  protected List extElements = new Vector();
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setOperation(Operation paramOperation)
  {
    this.operation = paramOperation;
  }

  public Operation getOperation()
  {
    return this.operation;
  }

  public void setBindingInput(BindingInput paramBindingInput)
  {
    this.bindingInput = paramBindingInput;
  }

  public BindingInput getBindingInput()
  {
    return this.bindingInput;
  }

  public void setBindingOutput(BindingOutput paramBindingOutput)
  {
    this.bindingOutput = paramBindingOutput;
  }

  public BindingOutput getBindingOutput()
  {
    return this.bindingOutput;
  }

  public void addBindingFault(BindingFault paramBindingFault)
  {
    this.bindingFaults.put(paramBindingFault.getName(), paramBindingFault);
  }

  public BindingFault getBindingFault(String paramString)
  {
    return (BindingFault)this.bindingFaults.get(paramString);
  }

  public Map getBindingFaults()
  {
    return this.bindingFaults;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void addExtensibilityElement(ExtensibilityElement paramExtensibilityElement)
  {
    this.extElements.add(paramExtensibilityElement);
  }

  public List getExtensibilityElements()
  {
    return this.extElements;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("BindingOperation: name=" + this.name);
    if (this.bindingInput != null)
      localStringBuffer.append("\n" + this.bindingInput);
    if (this.bindingOutput != null)
      localStringBuffer.append("\n" + this.bindingOutput);
    Iterator localIterator;
    if (this.bindingFaults != null)
    {
      localIterator = this.bindingFaults.values().iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    if (this.extElements != null)
    {
      localIterator = this.extElements.iterator();
      while (localIterator.hasNext())
        localStringBuffer.append("\n" + localIterator.next());
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.BindingOperationImpl
 * JD-Core Version:    0.6.0
 */