/*    */ package com.acs.fileChecker;
/*    */ 
/*    */ import java.util.Calendar;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class ReportList
/*    */ {
/*    */   private Map<String, Report> reports;
/*    */ 
/*    */   public ReportList()
/*    */   {
/* 10 */     this.reports = new HashMap(100);
/*    */   }
/*    */ 
/*    */   public Report get(String fileName) {
/* 14 */     return (Report)this.reports.get(fileName);
/*    */   }
/*    */ 
/*    */   public boolean add(Report r) {
/* 18 */     Report r2 = (Report)this.reports.get(r.getFileName());
/* 19 */     boolean isNew = r2 == null;
/* 20 */     if ((isNew) && (r.shouldBeChecked())) {
/* 21 */       this.reports.put(r.getFileName(), r);
/*    */     }
/* 23 */     else if (r.shouldBeChecked()) {
/* 24 */       if (r.getEndCheck().after(r2.getEndCheck()))
/* 25 */         r2.setEndCheck(r.getEndCheck());
/* 26 */       if (r.getStartCheck().before(r2.getStartCheck()))
/* 27 */         r2.setStartCheck(r.getStartCheck());
/* 28 */       r2.incExpectedCount();
/*    */     }
/* 30 */     return isNew;
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 34 */     return this.reports.isEmpty();
/*    */   }
/*    */ 
/*    */   public int size() {
/* 38 */     return this.reports.size();
/*    */   }
/*    */ 
/*    */   public Map<String, Report> getAll() {
/* 42 */     return this.reports;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 47 */     StringBuffer st = new StringBuffer();
/* 48 */     for (Report r : this.reports.values()) {
/* 49 */       st.append("\"");
/* 50 */       st.append(r.toString());
/* 51 */       st.append("\" ");
/*    */     }
/* 53 */     return st.toString();
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.ReportList
 * JD-Core Version:    0.6.0
 */