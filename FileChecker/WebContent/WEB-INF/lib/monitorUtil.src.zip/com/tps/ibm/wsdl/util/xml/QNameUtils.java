package com.ibm.wsdl.util.xml;

import javax.xml.namespace.QName;
import org.w3c.dom.Node;

public class QNameUtils
{
  public static boolean matches(QName paramQName, Node paramNode)
  {
    return (paramNode != null) && (paramQName.equals(newQName(paramNode)));
  }

  public static QName newQName(Node paramNode)
  {
    if (paramNode != null)
      return new QName(paramNode.getNamespaceURI(), paramNode.getLocalName());
    return new QName(null, null);
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.util.xml.QNameUtils
 * JD-Core Version:    0.6.0
 */