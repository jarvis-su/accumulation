package com.ibm.wsdl.extensions.http;

import javax.wsdl.extensions.http.HTTPUrlEncoded;
import javax.xml.namespace.QName;

public class HTTPUrlEncodedImpl
  implements HTTPUrlEncoded
{
  protected QName elementType = HTTPConstants.Q_ELEM_HTTP_URL_ENCODED;
  protected Boolean required = null;
  public static final long serialVersionUID = 1L;

  public void setElementType(QName paramQName)
  {
    this.elementType = paramQName;
  }

  public QName getElementType()
  {
    return this.elementType;
  }

  public void setRequired(Boolean paramBoolean)
  {
    this.required = paramBoolean;
  }

  public Boolean getRequired()
  {
    return this.required;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("HTTPUrlEncoded (" + this.elementType + "):");
    localStringBuffer.append("\nrequired=" + this.required);
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.ibm.wsdl.extensions.http.HTTPUrlEncodedImpl
 * JD-Core Version:    0.6.0
 */