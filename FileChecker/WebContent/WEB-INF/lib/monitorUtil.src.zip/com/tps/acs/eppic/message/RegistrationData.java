/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class RegistrationData extends MessageData
/*    */ {
/*    */   private static final long serialVersionUID = -619469986399681190L;
/*    */   private static final String INTERVAL = "INTERVAL";
/*    */ 
/*    */   public RegistrationData()
/*    */   {
/*    */   }
/*    */ 
/*    */   public RegistrationData(HashMap map)
/*    */   {
/* 17 */     setData(map);
/*    */   }
/*    */ 
/*    */   public RegistrationData(int interval) {
/* 21 */     setInterval(interval);
/*    */   }
/*    */ 
/*    */   public void setInterval(int interval) {
/* 25 */     super.setData("INTERVAL", new Integer(interval));
/*    */   }
/*    */ 
/*    */   public int getInterval() {
/* 29 */     int retVal = -1;
/* 30 */     if (getData("INTERVAL") != null) {
/* 31 */       retVal = ((Integer)getData("INTERVAL")).intValue();
/*    */     }
/* 33 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 37 */     return "  Interval: " + getInterval() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.RegistrationData
 * JD-Core Version:    0.6.0
 */