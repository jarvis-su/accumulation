/*    */ package ch.ethz.ssh2;
/*    */ 
/*    */ public class SFTPv3FileHandle
/*    */ {
/*    */   final SFTPv3Client client;
/*    */   final byte[] fileHandle;
/* 15 */   boolean isClosed = false;
/*    */ 
/*    */   SFTPv3FileHandle(SFTPv3Client client, byte[] h)
/*    */   {
/* 21 */     this.client = client;
/* 22 */     this.fileHandle = h;
/*    */   }
/*    */ 
/*    */   public SFTPv3Client getClient()
/*    */   {
/* 32 */     return this.client;
/*    */   }
/*    */ 
/*    */   public boolean isClosed()
/*    */   {
/* 43 */     return this.isClosed;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.SFTPv3FileHandle
 * JD-Core Version:    0.6.0
 */