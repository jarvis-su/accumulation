/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ class ServerPreparedStatement$BindValue
/*     */ {
/*  85 */   long boundBeforeExecutionNum = 0L;
/*     */   long bindLength;
/*     */   int bufferType;
/*     */   byte byteBinding;
/*     */   double doubleBinding;
/*     */   float floatBinding;
/*     */   int intBinding;
/*     */   boolean isLongData;
/*     */   boolean isNull;
/* 103 */   boolean isSet = false;
/*     */   long longBinding;
/*     */   short shortBinding;
/*     */   Object value;
/*     */ 
/*     */   ServerPreparedStatement$BindValue()
/*     */   {
/*     */   }
/*     */ 
/*     */   ServerPreparedStatement$BindValue(BindValue copyMe)
/*     */   {
/* 115 */     this.value = copyMe.value;
/* 116 */     this.isSet = copyMe.isSet;
/* 117 */     this.isLongData = copyMe.isLongData;
/* 118 */     this.isNull = copyMe.isNull;
/* 119 */     this.bufferType = copyMe.bufferType;
/* 120 */     this.bindLength = copyMe.bindLength;
/* 121 */     this.byteBinding = copyMe.byteBinding;
/* 122 */     this.shortBinding = copyMe.shortBinding;
/* 123 */     this.intBinding = copyMe.intBinding;
/* 124 */     this.longBinding = copyMe.longBinding;
/* 125 */     this.floatBinding = copyMe.floatBinding;
/* 126 */     this.doubleBinding = copyMe.doubleBinding;
/*     */   }
/*     */ 
/*     */   void reset() {
/* 130 */     this.isSet = false;
/* 131 */     this.value = null;
/* 132 */     this.isLongData = false;
/*     */ 
/* 134 */     this.byteBinding = 0;
/* 135 */     this.shortBinding = 0;
/* 136 */     this.intBinding = 0;
/* 137 */     this.longBinding = 0L;
/* 138 */     this.floatBinding = 0.0F;
/* 139 */     this.doubleBinding = 0.0D;
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 143 */     return toString(false);
/*     */   }
/*     */ 
/*     */   public String toString(boolean quoteIfNeeded) {
/* 147 */     if (this.isLongData) {
/* 148 */       return "' STREAM DATA '";
/*     */     }
/*     */ 
/* 151 */     switch (this.bufferType) {
/*     */     case 1:
/* 153 */       return String.valueOf(this.byteBinding);
/*     */     case 2:
/* 155 */       return String.valueOf(this.shortBinding);
/*     */     case 3:
/* 157 */       return String.valueOf(this.intBinding);
/*     */     case 8:
/* 159 */       return String.valueOf(this.longBinding);
/*     */     case 4:
/* 161 */       return String.valueOf(this.floatBinding);
/*     */     case 5:
/* 163 */       return String.valueOf(this.doubleBinding);
/*     */     case 7:
/*     */     case 10:
/*     */     case 11:
/*     */     case 12:
/*     */     case 15:
/*     */     case 253:
/*     */     case 254:
/* 171 */       if (quoteIfNeeded) {
/* 172 */         return "'" + String.valueOf(this.value) + "'";
/*     */       }
/* 174 */       return String.valueOf(this.value);
/*     */     }
/*     */ 
/* 177 */     if ((this.value instanceof byte[])) {
/* 178 */       return "byte data";
/*     */     }
/*     */ 
/* 181 */     if (quoteIfNeeded) {
/* 182 */       return "'" + String.valueOf(this.value) + "'";
/*     */     }
/* 184 */     return String.valueOf(this.value);
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.ServerPreparedStatement.BindValue
 * JD-Core Version:    0.6.0
 */