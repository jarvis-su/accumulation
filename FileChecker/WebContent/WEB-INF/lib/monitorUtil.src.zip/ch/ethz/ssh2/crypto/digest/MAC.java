/*    */ package ch.ethz.ssh2.crypto.digest;
/*    */ 
/*    */ public final class MAC
/*    */ {
/*    */   Digest mac;
/*    */   int size;
/*    */ 
/*    */   public static final String[] getMacList()
/*    */   {
/* 19 */     return new String[] { "hmac-sha1-96", "hmac-sha1", "hmac-md5-96", "hmac-md5" };
/*    */   }
/*    */ 
/*    */   public static final void checkMacList(String[] macs)
/*    */   {
/* 24 */     for (int i = 0; i < macs.length; i++)
/* 25 */       getKeyLen(macs[i]);
/*    */   }
/*    */ 
/*    */   public static final int getKeyLen(String type)
/*    */   {
/* 30 */     if (type.equals("hmac-sha1"))
/* 31 */       return 20;
/* 32 */     if (type.equals("hmac-sha1-96"))
/* 33 */       return 20;
/* 34 */     if (type.equals("hmac-md5"))
/* 35 */       return 16;
/* 36 */     if (type.equals("hmac-md5-96"))
/* 37 */       return 16;
/* 38 */     throw new IllegalArgumentException("Unkown algorithm " + type);
/*    */   }
/*    */ 
/*    */   public MAC(String type, byte[] key)
/*    */   {
/* 43 */     if (type.equals("hmac-sha1"))
/*    */     {
/* 45 */       this.mac = new HMAC(new SHA1(), key, 20);
/*    */     }
/* 47 */     else if (type.equals("hmac-sha1-96"))
/*    */     {
/* 49 */       this.mac = new HMAC(new SHA1(), key, 12);
/*    */     }
/* 51 */     else if (type.equals("hmac-md5"))
/*    */     {
/* 53 */       this.mac = new HMAC(new MD5(), key, 16);
/*    */     }
/* 55 */     else if (type.equals("hmac-md5-96"))
/*    */     {
/* 57 */       this.mac = new HMAC(new MD5(), key, 12);
/*    */     }
/*    */     else {
/* 60 */       throw new IllegalArgumentException("Unkown algorithm " + type);
/*    */     }
/* 62 */     this.size = this.mac.getDigestLength();
/*    */   }
/*    */ 
/*    */   public final void initMac(int seq)
/*    */   {
/* 67 */     this.mac.reset();
/* 68 */     this.mac.update((byte)(seq >> 24));
/* 69 */     this.mac.update((byte)(seq >> 16));
/* 70 */     this.mac.update((byte)(seq >> 8));
/* 71 */     this.mac.update((byte)seq);
/*    */   }
/*    */ 
/*    */   public final void update(byte[] packetdata, int off, int len)
/*    */   {
/* 76 */     this.mac.update(packetdata, off, len);
/*    */   }
/*    */ 
/*    */   public final void getMac(byte[] out, int off)
/*    */   {
/* 81 */     this.mac.digest(out, off);
/*    */   }
/*    */ 
/*    */   public final int size()
/*    */   {
/* 86 */     return this.size;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.crypto.digest.MAC
 * JD-Core Version:    0.6.0
 */