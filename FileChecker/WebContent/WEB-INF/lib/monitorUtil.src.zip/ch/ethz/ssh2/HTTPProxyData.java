/*    */ package ch.ethz.ssh2;
/*    */ 
/*    */ public class HTTPProxyData
/*    */   implements ProxyData
/*    */ {
/*    */   public final String proxyHost;
/*    */   public final int proxyPort;
/*    */   public final String proxyUser;
/*    */   public final String proxyPass;
/*    */   public final String[] requestHeaderLines;
/*    */ 
/*    */   public HTTPProxyData(String proxyHost, int proxyPort)
/*    */   {
/* 30 */     this(proxyHost, proxyPort, null, null);
/*    */   }
/*    */ 
/*    */   public HTTPProxyData(String proxyHost, int proxyPort, String proxyUser, String proxyPass)
/*    */   {
/* 43 */     this(proxyHost, proxyPort, proxyUser, proxyPass, null);
/*    */   }
/*    */ 
/*    */   public HTTPProxyData(String proxyHost, int proxyPort, String proxyUser, String proxyPass, String[] requestHeaderLines)
/*    */   {
/* 71 */     if (proxyHost == null) {
/* 72 */       throw new IllegalArgumentException("proxyHost must be non-null");
/*    */     }
/* 74 */     if (proxyPort < 0) {
/* 75 */       throw new IllegalArgumentException("proxyPort must be non-negative");
/*    */     }
/* 77 */     this.proxyHost = proxyHost;
/* 78 */     this.proxyPort = proxyPort;
/* 79 */     this.proxyUser = proxyUser;
/* 80 */     this.proxyPass = proxyPass;
/* 81 */     this.requestHeaderLines = requestHeaderLines;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.HTTPProxyData
 * JD-Core Version:    0.6.0
 */