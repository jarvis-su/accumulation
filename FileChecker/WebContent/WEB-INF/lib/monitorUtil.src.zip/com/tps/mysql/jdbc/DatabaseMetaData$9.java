/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import java.sql.ResultSet;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.Statement;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.Iterator;
/*      */ import java.util.TreeMap;
/*      */ 
/*      */ class DatabaseMetaData$9 extends DatabaseMetaData.IterateBlock
/*      */ {
/*      */   private final Statement val$stmt;
/*      */   private final String val$tableNamePat;
/*      */   private final String[] val$types;
/*      */   private final ArrayList val$tuples;
/*      */   private final DatabaseMetaData this$0;
/*      */ 
/*      */   void forEach(Object catalogStr)
/*      */     throws SQLException
/*      */   {
/* 4359 */     ResultSet results = null;
/*      */     try
/*      */     {
/* 4363 */       if (!this.this$0.conn.versionMeetsMinimum(5, 0, 2))
/*      */         try {
/* 4365 */           results = this.val$stmt.executeQuery("SHOW TABLES FROM " + this.this$0.quotedId + catalogStr.toString() + this.this$0.quotedId + " LIKE '" + this.val$tableNamePat + "'");
/*      */         }
/*      */         catch (SQLException sqlEx)
/*      */         {
/* 4371 */           if ("08S01".equals(sqlEx.getSQLState())) {
/* 4372 */             throw sqlEx;
/*      */           }
/*      */ 
/* 4375 */           jsr 631;
/*      */         }
/*      */       else {
/*      */         try {
/* 4379 */           results = this.val$stmt.executeQuery("SHOW FULL TABLES FROM " + this.this$0.quotedId + catalogStr.toString() + this.this$0.quotedId + " LIKE '" + this.val$tableNamePat + "'");
/*      */         }
/*      */         catch (SQLException sqlEx)
/*      */         {
/* 4385 */           if ("08S01".equals(sqlEx.getSQLState())) {
/* 4386 */             throw sqlEx;
/*      */           }
/*      */ 
/* 4389 */           jsr 540;
/*      */         }
/*      */       }
/*      */ 
/* 4393 */       boolean shouldReportTables = false;
/* 4394 */       boolean shouldReportViews = false;
/*      */ 
/* 4396 */       if ((this.val$types == null) || (this.val$types.length == 0)) {
/* 4397 */         shouldReportTables = true;
/* 4398 */         shouldReportViews = true;
/*      */       } else {
/* 4400 */         for (int i = 0; i < this.val$types.length; i++) {
/* 4401 */           if ("TABLE".equalsIgnoreCase(this.val$types[i])) {
/* 4402 */             shouldReportTables = true;
/*      */           }
/*      */ 
/* 4405 */           if ("VIEW".equalsIgnoreCase(this.val$types[i])) {
/* 4406 */             shouldReportViews = true;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 4411 */       int typeColumnIndex = 0;
/* 4412 */       boolean hasTableTypes = false;
/*      */ 
/* 4414 */       if (this.this$0.conn.versionMeetsMinimum(5, 0, 2))
/*      */       {
/*      */         try
/*      */         {
/* 4419 */           typeColumnIndex = results.findColumn("table_type");
/*      */ 
/* 4421 */           hasTableTypes = true;
/*      */         }
/*      */         catch (SQLException sqlEx)
/*      */         {
/*      */           try
/*      */           {
/* 4433 */             typeColumnIndex = results.findColumn("Type");
/*      */ 
/* 4435 */             hasTableTypes = true;
/*      */           } catch (SQLException sqlEx2) {
/* 4437 */             hasTableTypes = false;
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/* 4442 */       TreeMap tablesOrderedByName = null;
/* 4443 */       TreeMap viewsOrderedByName = null;
/*      */ 
/* 4445 */       while (results.next()) {
/* 4446 */         byte[][] row = new byte[5][];
/* 4447 */         row[0] = (catalogStr.toString() == null ? null : DatabaseMetaData.access$000(this.this$0, catalogStr.toString()));
/*      */ 
/* 4449 */         row[1] = null;
/* 4450 */         row[2] = results.getBytes(1);
/* 4451 */         row[4] = new byte[0];
/*      */ 
/* 4453 */         if (hasTableTypes) {
/* 4454 */           String tableType = results.getString(typeColumnIndex);
/*      */ 
/* 4457 */           if ((("table".equalsIgnoreCase(tableType)) || ("base table".equalsIgnoreCase(tableType))) && (shouldReportTables))
/*      */           {
/* 4460 */             row[3] = DatabaseMetaData.access$900();
/*      */ 
/* 4462 */             if (tablesOrderedByName == null) {
/* 4463 */               tablesOrderedByName = new TreeMap();
/*      */             }
/*      */ 
/* 4466 */             tablesOrderedByName.put(results.getString(1), row);
/*      */           }
/* 4468 */           else if (("view".equalsIgnoreCase(tableType)) && (shouldReportViews))
/*      */           {
/* 4470 */             row[3] = DatabaseMetaData.access$1000();
/*      */ 
/* 4472 */             if (viewsOrderedByName == null) {
/* 4473 */               viewsOrderedByName = new TreeMap();
/*      */             }
/*      */ 
/* 4476 */             viewsOrderedByName.put(results.getString(1), row);
/*      */           }
/* 4478 */           else if (!hasTableTypes)
/*      */           {
/* 4480 */             row[3] = DatabaseMetaData.access$900();
/*      */ 
/* 4482 */             if (tablesOrderedByName == null) {
/* 4483 */               tablesOrderedByName = new TreeMap();
/*      */             }
/*      */ 
/* 4486 */             tablesOrderedByName.put(results.getString(1), row);
/*      */           }
/*      */ 
/*      */         }
/* 4490 */         else if (shouldReportTables)
/*      */         {
/* 4492 */           row[3] = DatabaseMetaData.access$900();
/*      */ 
/* 4494 */           if (tablesOrderedByName == null) {
/* 4495 */             tablesOrderedByName = new TreeMap();
/*      */           }
/*      */ 
/* 4498 */           tablesOrderedByName.put(results.getString(1), row);
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/* 4507 */       if (tablesOrderedByName != null) {
/* 4508 */         Iterator tablesIter = tablesOrderedByName.values().iterator();
/*      */ 
/* 4511 */         while (tablesIter.hasNext()) {
/* 4512 */           this.val$tuples.add(tablesIter.next());
/*      */         }
/*      */       }
/*      */ 
/* 4516 */       if (viewsOrderedByName != null) {
/* 4517 */         Iterator viewsIter = viewsOrderedByName.values().iterator();
/*      */ 
/* 4520 */         while (viewsIter.hasNext())
/* 4521 */           this.val$tuples.add(viewsIter.next());
/*      */       }
/*      */     }
/*      */     finally
/*      */     {
/* 4526 */       if (results != null) {
/*      */         try {
/* 4528 */           results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 4533 */         results = null;
/*      */       }
/*      */     }
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.DatabaseMetaData.9
 * JD-Core Version:    0.6.0
 */