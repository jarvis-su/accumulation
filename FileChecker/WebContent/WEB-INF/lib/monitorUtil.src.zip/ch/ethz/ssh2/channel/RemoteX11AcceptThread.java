/*    */ package ch.ethz.ssh2.channel;
/*    */ 
/*    */ import ch.ethz.ssh2.log.Logger;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ import java.net.Socket;
/*    */ 
/*    */ public class RemoteX11AcceptThread extends Thread
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(RemoteX11AcceptThread.class);
/*    */   Channel c;
/*    */   String remoteOriginatorAddress;
/*    */   int remoteOriginatorPort;
/*    */   Socket s;
/*    */ 
/*    */   public RemoteX11AcceptThread(Channel c, String remoteOriginatorAddress, int remoteOriginatorPort)
/*    */   {
/* 30 */     this.c = c;
/* 31 */     this.remoteOriginatorAddress = remoteOriginatorAddress;
/* 32 */     this.remoteOriginatorPort = remoteOriginatorPort;
/*    */   }
/*    */ 
/*    */   public void run()
/*    */   {
/*    */     try
/*    */     {
/* 41 */       this.c.cm.sendOpenConfirmation(this.c);
/*    */ 
/* 45 */       OutputStream remote_os = this.c.getStdinStream();
/* 46 */       InputStream remote_is = this.c.getStdoutStream();
/*    */ 
/* 82 */       byte[] header = new byte[6];
/*    */ 
/* 84 */       if (remote_is.read(header) != 6) {
/* 85 */         throw new IOException("Unexpected EOF on X11 startup!");
/*    */       }
/* 87 */       if ((header[0] != 66) && (header[0] != 108)) {
/* 88 */         throw new IOException("Unknown endian format in X11 message!");
/*    */       }
/*    */ 
/* 92 */       int idxMSB = header[0] == 66 ? 0 : 1;
/*    */ 
/* 96 */       byte[] auth_buff = new byte[6];
/*    */ 
/* 98 */       if (remote_is.read(auth_buff) != 6) {
/* 99 */         throw new IOException("Unexpected EOF on X11 startup!");
/*    */       }
/* 101 */       int authProtocolNameLength = (auth_buff[idxMSB] & 0xFF) << 8 | auth_buff[(1 - idxMSB)] & 0xFF;
/* 102 */       int authProtocolDataLength = (auth_buff[(2 + idxMSB)] & 0xFF) << 8 | auth_buff[(3 - idxMSB)] & 0xFF;
/*    */ 
/* 104 */       if ((authProtocolNameLength > 256) || (authProtocolDataLength > 256)) {
/* 105 */         throw new IOException("Buggy X11 authorization data");
/*    */       }
/* 107 */       int authProtocolNamePadding = (4 - authProtocolNameLength % 4) % 4;
/* 108 */       int authProtocolDataPadding = (4 - authProtocolDataLength % 4) % 4;
/*    */ 
/* 110 */       byte[] authProtocolName = new byte[authProtocolNameLength];
/* 111 */       byte[] authProtocolData = new byte[authProtocolDataLength];
/*    */ 
/* 113 */       byte[] paddingBuffer = new byte[4];
/*    */ 
/* 115 */       if (remote_is.read(authProtocolName) != authProtocolNameLength) {
/* 116 */         throw new IOException("Unexpected EOF on X11 startup! (authProtocolName)");
/*    */       }
/* 118 */       if (remote_is.read(paddingBuffer, 0, authProtocolNamePadding) != authProtocolNamePadding) {
/* 119 */         throw new IOException("Unexpected EOF on X11 startup! (authProtocolNamePadding)");
/*    */       }
/* 121 */       if (remote_is.read(authProtocolData) != authProtocolDataLength) {
/* 122 */         throw new IOException("Unexpected EOF on X11 startup! (authProtocolData)");
/*    */       }
/* 124 */       if (remote_is.read(paddingBuffer, 0, authProtocolDataPadding) != authProtocolDataPadding) {
/* 125 */         throw new IOException("Unexpected EOF on X11 startup! (authProtocolDataPadding)");
/*    */       }
/* 127 */       if (!"MIT-MAGIC-COOKIE-1".equals(new String(authProtocolName))) {
/* 128 */         throw new IOException("Unknown X11 authorization protocol!");
/*    */       }
/* 130 */       if (authProtocolDataLength != 16) {
/* 131 */         throw new IOException("Wrong data length for X11 authorization data!");
/*    */       }
/* 133 */       StringBuffer tmp = new StringBuffer(32);
/* 134 */       for (int i = 0; i < authProtocolData.length; i++)
/*    */       {
/* 136 */         String digit2 = Integer.toHexString(authProtocolData[i] & 0xFF);
/* 137 */         tmp.append("0" + digit2);
/*    */       }
/* 139 */       String hexEncodedFakeCookie = tmp.toString();
/*    */ 
/* 145 */       synchronized (this.c)
/*    */       {
/* 148 */         this.c.hexX11FakeCookie = hexEncodedFakeCookie;
/*    */       }
/*    */ 
/* 153 */       X11ServerData sd = this.c.cm.checkX11Cookie(hexEncodedFakeCookie);
/*    */ 
/* 155 */       if (sd == null) {
/* 156 */         throw new IOException("Invalid X11 cookie received.");
/*    */       }
/*    */ 
/* 163 */       this.s = new Socket(sd.hostname, sd.port);
/*    */ 
/* 165 */       OutputStream x11_os = this.s.getOutputStream();
/* 166 */       InputStream x11_is = this.s.getInputStream();
/*    */ 
/* 170 */       x11_os.write(header);
/*    */ 
/* 172 */       if (sd.x11_magic_cookie == null)
/*    */       {
/* 174 */         byte[] emptyAuthData = new byte[6];
/*    */ 
/* 176 */         x11_os.write(emptyAuthData);
/*    */       }
/*    */       else
/*    */       {
/* 180 */         if (sd.x11_magic_cookie.length != 16) {
/* 181 */           throw new IOException("The real X11 cookie has an invalid length!");
/*    */         }
/*    */ 
/* 184 */         x11_os.write(auth_buff);
/* 185 */         x11_os.write(authProtocolName);
/* 186 */         x11_os.write(paddingBuffer, 0, authProtocolNamePadding);
/* 187 */         x11_os.write(sd.x11_magic_cookie);
/* 188 */         x11_os.write(paddingBuffer, 0, authProtocolDataPadding);
/*    */       }
/*    */ 
/* 191 */       x11_os.flush();
/*    */ 
/* 195 */       StreamForwarder r2l = new StreamForwarder(this.c, null, null, remote_is, x11_os, "RemoteToX11");
/* 196 */       StreamForwarder l2r = new StreamForwarder(this.c, null, null, x11_is, remote_os, "X11ToRemote");
/*    */ 
/* 200 */       r2l.setDaemon(true);
/* 201 */       r2l.start();
/* 202 */       l2r.run();
/*    */ 
/* 204 */       while (r2l.isAlive())
/*    */       {
/*    */         try
/*    */         {
/* 208 */           r2l.join();
/*    */         }
/*    */         catch (InterruptedException localInterruptedException)
/*    */         {
/*    */         }
/*    */ 
/*    */       }
/*    */ 
/* 217 */       this.c.cm.closeChannel(this.c, "EOF on both X11 streams reached.", true);
/* 218 */       this.s.close();
/*    */     }
/*    */     catch (IOException e)
/*    */     {
/* 222 */       log.log(50, "IOException in X11 proxy code: " + e.getMessage());
/*    */       try
/*    */       {
/* 226 */         this.c.cm.closeChannel(this.c, "IOException in X11 proxy code (" + e.getMessage() + ")", true);
/*    */       }
/*    */       catch (IOException localIOException1)
/*    */       {
/*    */       }
/*    */       try
/*    */       {
/* 233 */         if (this.s != null)
/* 234 */           this.s.close();
/*    */       }
/*    */       catch (IOException localIOException2)
/*    */       {
/*    */       }
/*    */     }
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.channel.RemoteX11AcceptThread
 * JD-Core Version:    0.6.0
 */