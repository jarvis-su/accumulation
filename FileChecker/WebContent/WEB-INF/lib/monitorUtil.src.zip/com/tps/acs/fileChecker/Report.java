/*     */ package com.acs.fileChecker;
/*     */ 
/*     */ import java.util.Calendar;
/*     */ 
/*     */ public class Report
/*     */ {
/*     */   private String _fileName;
/*     */   private int _expectedCount;
/*   9 */   private Calendar _startCheck = Calendar.getInstance();
/*  10 */   private Calendar _endCheck = Calendar.getInstance();
/*     */ 
/*     */   public Report(String file, Calendar start, Calendar end) {
/*  13 */     if (start != null) { this._startCheck = start;
/*     */     } else {
/*  15 */       this._startCheck.set(11, 0);
/*  16 */       this._startCheck.set(12, 0);
/*  17 */       this._startCheck.set(13, 0);
/*     */     }
/*  19 */     if (end != null) { this._endCheck = end;
/*     */     } else {
/*  21 */       this._endCheck.set(11, 23);
/*  22 */       this._endCheck.set(12, 59);
/*  23 */       this._endCheck.set(13, 59);
/*     */     }
/*  25 */     this._fileName = file;
/*  26 */     this._expectedCount = 1;
/*     */   }
/*     */ 
/*     */   public Calendar getStartCheck() {
/*  30 */     return this._startCheck;
/*     */   }
/*     */ 
/*     */   public Calendar getEndCheck() {
/*  34 */     return this._endCheck;
/*     */   }
/*     */ 
/*     */   public void setStartCheck(Calendar c) {
/*  38 */     this._startCheck = ((Calendar)c.clone());
/*     */   }
/*     */ 
/*     */   public void setEndCheck(Calendar c) {
/*  42 */     this._endCheck = ((Calendar)c.clone());
/*     */   }
/*     */ 
/*     */   public Report(String file) {
/*  46 */     this(file, null, null);
/*     */   }
/*     */ 
/*     */   public String getFileName() {
/*  50 */     return this._fileName;
/*     */   }
/*     */ 
/*     */   public void setFileName(String name) {
/*  54 */     this._fileName = name;
/*     */   }
/*     */ 
/*     */   public int getExpectedCount() {
/*  58 */     return this._expectedCount;
/*     */   }
/*     */ 
/*     */   public void incExpectedCount() {
/*  62 */     this._expectedCount += 1;
/*     */   }
/*     */ 
/*     */   public static Calendar normalizeDate(Calendar c) {
/*  66 */     c.set(0, 0, 1);
/*  67 */     return c;
/*     */   }
/*     */ 
/*     */   public boolean shouldBeChecked() {
/*  71 */     Calendar now = Calendar.getInstance();
/*  72 */     Calendar start = this._startCheck;
/*  73 */     Calendar end = this._endCheck;
/*     */ 
/*  82 */     if ((now.before(this._startCheck)) && (this._endCheck.before(this._startCheck)) && 
/*  83 */       (now.before(this._endCheck))) {
/*  84 */       return true;
/*     */     }
/*  86 */     return now.after(this._startCheck);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/*  91 */     return this._fileName;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args) {
/*  95 */     Calendar start = Calendar.getInstance();
/*  96 */     Calendar end = (Calendar)start.clone();
/*  97 */     start.set(11, 11);
/*  98 */     end.set(11, 3);
/*  99 */     Report r = new Report("blah", start, end);
/* 100 */     r.shouldBeChecked();
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.fileChecker.Report
 * JD-Core Version:    0.6.0
 */