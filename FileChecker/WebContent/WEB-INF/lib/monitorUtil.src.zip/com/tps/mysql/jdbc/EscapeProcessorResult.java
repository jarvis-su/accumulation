/*    */ package com.mysql.jdbc;
/*    */ 
/*    */ class EscapeProcessorResult
/*    */ {
/* 38 */   boolean callingStoredFunction = false;
/*    */   String escapedSql;
/* 42 */   byte usesVariables = 0;
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.EscapeProcessorResult
 * JD-Core Version:    0.6.0
 */