/*    */ package ch.ethz.ssh2.packets;
/*    */ 
/*    */ import ch.ethz.ssh2.DHGexParameters;
/*    */ 
/*    */ public class PacketKexDhGexRequestOld
/*    */ {
/*    */   byte[] payload;
/*    */   int n;
/*    */ 
/*    */   public PacketKexDhGexRequestOld(DHGexParameters para)
/*    */   {
/* 20 */     this.n = para.getPref_group_len();
/*    */   }
/*    */ 
/*    */   public byte[] getPayload()
/*    */   {
/* 25 */     if (this.payload == null)
/*    */     {
/* 27 */       TypesWriter tw = new TypesWriter();
/* 28 */       tw.writeByte(30);
/* 29 */       tw.writeUINT32(this.n);
/* 30 */       this.payload = tw.getBytes();
/*    */     }
/* 32 */     return this.payload;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.packets.PacketKexDhGexRequestOld
 * JD-Core Version:    0.6.0
 */