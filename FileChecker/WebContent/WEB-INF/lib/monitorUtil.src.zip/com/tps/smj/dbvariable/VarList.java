/*    */ package com.smj.dbvariable;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import java.util.StringTokenizer;
/*    */ import java.util.Vector;
/*    */ 
/*    */ public class VarList extends DBVar
/*    */ {
/*    */   public VarList()
/*    */   {
/*    */   }
/*    */ 
/*    */   public VarList(String s)
/*    */   {
/* 44 */     super(s);
/*    */   }
/*    */ 
/*    */   protected Vector<String> resolveInternal(VarCache c, Properties env)
/*    */     throws Exception
/*    */   {
/* 50 */     Vector v = new Vector();
/* 51 */     StringTokenizer st = new StringTokenizer(getInitialValue(), ",");
/* 52 */     while (st.hasMoreTokens()) {
/* 53 */       VarString vs = new VarString(st.nextToken());
/* 54 */       for (String s : vs.resolve(c, env))
/* 55 */         v.add(s);
/*    */     }
/* 57 */     return v;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.smj.dbvariable.VarList
 * JD-Core Version:    0.6.0
 */