/*     */ package com.acs.eppic.messageservice;
/*     */ 
/*     */ import com.acs.eppic.message.Message;
/*     */ import com.acs.eppic.message.MessageType;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.management.MBeanServer;
/*     */ import javax.management.MBeanServerFactory;
/*     */ import javax.management.ObjectName;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.apache.log4j.jmx.LoggerDynamicMBean;
/*     */ 
/*     */ public class MessageService
/*     */   implements MessageServiceMBean
/*     */ {
/*  33 */   private static MessageService soleInstance = null;
/*  34 */   protected static final Logger logger = Logger.getLogger("MessageService");
/*     */ 
/*  36 */   private String systemId = "MONITOR";
/*  37 */   private String systemPort = "8080";
/*     */   protected static final String CONFIG_SOURCE_FILENAME = "com_acs_eppic_messagingservice_properties";
/*  41 */   private boolean monitorMode = false;
/*     */   private String monitorHost;
/*     */   private String monitorPort;
/*     */   private String monitorUrl;
/*  49 */   private boolean serviceEnabled = false;
/*     */ 
/*  52 */   private int registration_timeout = 300;
/*  53 */   private int heartbeat_interval = 30;
/*  54 */   private int resend_interval = 30;
/*  55 */   private int maxSendingQueueSize = 25;
/*  56 */   private int maxAlertQueueSize = 0;
/*  57 */   private int maxMessageQueueSize = 0;
/*  58 */   private int messageNotificationQueueSize = 0;
/*     */   private int serverIndex;
/*  64 */   private boolean isStarted = false;
/*     */   private boolean connected;
/*     */   private Map handles;
/*     */   private Thread heartBeater;
/*     */   private MessageService.IncomingQueue incomingQueue;
/*     */   private MessageService.OutgoingQueue outgoingQueue;
/*     */ 
/*     */   public static MessageService getSoleInstance()
/*     */   {
/*  73 */     if (soleInstance == null)
/*     */     {
/*  75 */       synchronized (MessageService.class)
/*     */       {
/*  77 */         if (soleInstance == null)
/*     */         {
/*  79 */           soleInstance = new MessageService();
/*     */         }
/*     */       }
/*     */     }
/*  83 */     return soleInstance;
/*     */   }
/*     */ 
/*     */   public MessageService()
/*     */   {
/*  88 */     ArrayList list = MBeanServerFactory.findMBeanServer(null);
/*     */ 
/*  90 */     synchronized (list) {
/*  91 */       if (!list.isEmpty()) {
/*     */         try
/*     */         {
/*  94 */           ObjectName objectName = new ObjectName("log4j:name=" + logger.getClass().getName());
/*  95 */           ((MBeanServer)list.get(0)).registerMBean(new LoggerDynamicMBean(logger), objectName);
/*     */         } catch (Exception e) {
/*  97 */           logger.error("Error registering with MBeanServer", e);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 102 */     this.serverIndex = 0;
/* 103 */     this.handles = new HashMap();
/*     */     try
/*     */     {
/* 106 */       ConfigFileReader pfr = new ConfigFileReader("com_acs_eppic_messagingservice_properties");
/* 107 */       this.monitorMode = (pfr.readConfigValueString("monitor.mode").compareToIgnoreCase("true") == 0);
/* 108 */       this.monitorHost = pfr.readConfigValueString("service.host");
/* 109 */       this.monitorPort = pfr.readConfigValueString("service.port");
/* 110 */       this.monitorUrl = pfr.readConfigValueString("service.urlpath");
/* 111 */       this.systemId = pfr.readConfigValueString("system.name");
/* 112 */       this.systemPort = pfr.readConfigValueString("system.port");
/* 113 */       this.registration_timeout = pfr.readConfigValueInteger("registration.timeout");
/* 114 */       this.heartbeat_interval = pfr.readConfigValueInteger("heartbeat.interval");
/* 115 */       this.resend_interval = pfr.readConfigValueInteger("resend.interval");
/* 116 */       this.serviceEnabled = (pfr.readConfigValueString("service.enabled").compareToIgnoreCase("true") == 0);
/* 117 */       this.maxSendingQueueSize = pfr.readConfigValueInteger("max.send.queueSize");
/* 118 */       this.maxAlertQueueSize = pfr.readConfigValueInteger("max.alert.queueSize");
/* 119 */       this.maxMessageQueueSize = pfr.readConfigValueInteger("max.message.queueSize");
/* 120 */       this.messageNotificationQueueSize = pfr.readConfigValueInteger("message.notify.queueSize");
/*     */     } catch (Exception e) {
/* 122 */       logger.error("ERROR Starting Messaging Service.", e);
/*     */     }
/*     */ 
/* 125 */     if ((this.monitorMode) || (this.serviceEnabled)) {
/* 126 */       this.outgoingQueue = new MessageService.OutgoingQueue(this);
/* 127 */       this.incomingQueue = new MessageService.IncomingQueue(this);
/* 128 */       if ((!this.monitorMode) && (this.heartbeat_interval > 0)) {
/* 129 */         this.heartBeater = new Thread(new MessageService.HeartBeat(this, this.heartbeat_interval));
/* 130 */         this.heartBeater.start();
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getConfigName()
/*     */   {
/* 137 */     return "com.acs.eppic.messagservice.MessageService";
/*     */   }
/*     */ 
/*     */   public void setServerIndex(int index)
/*     */   {
/* 145 */     this.serverIndex = index;
/*     */   }
/*     */ 
/*     */   public int getServerIndex()
/*     */   {
/* 150 */     return this.serverIndex;
/*     */   }
/*     */ 
/*     */   public boolean isStarted()
/*     */   {
/* 155 */     return this.isStarted;
/*     */   }
/*     */ 
/*     */   public String getSystemId()
/*     */   {
/* 160 */     return this.systemId;
/*     */   }
/*     */ 
/*     */   public MessageServiceHandle findServiceHandle(String serviceId)
/*     */   {
/* 172 */     MessageService ms = getSoleInstance();
/* 173 */     MessageServiceHandle handle = null;
/* 174 */     if (ms.handles.get(serviceId) != null) {
/* 175 */       handle = (MessageServiceHandle)ms.handles.get(serviceId);
/*     */     }
/* 177 */     return handle;
/*     */   }
/*     */ 
/*     */   public static MessageServiceHandle getServiceHandle(MessageRecipient recipient, boolean createHandle)
/*     */   {
/* 191 */     MessageService ms = getSoleInstance();
/* 192 */     MessageServiceHandle handle = ms.findServiceHandle("MONITOR");
/* 193 */     if ((handle == null) && (createHandle)) {
/* 194 */       handle = ms.newServiceHandle("MONITOR", recipient);
/*     */     }
/* 196 */     return handle;
/*     */   }
/*     */ 
/*     */   public static MessageServiceHandle getServiceHandle(String serviceId, MessageRecipient recipient, boolean createHandle)
/*     */   {
/* 211 */     MessageService ms = getSoleInstance();
/* 212 */     MessageServiceHandle handle = null;
/*     */ 
/* 214 */     if (((handle = ms.findServiceHandle(serviceId)) == null) && (createHandle)) {
/* 215 */       handle = ms.newServiceHandle(serviceId, recipient);
/*     */     }
/* 217 */     return handle;
/*     */   }
/*     */ 
/*     */   protected MessageServiceHandle newServiceHandle(String serviceId, MessageRecipient recipient)
/*     */   {
/* 230 */     MessageServiceHandle handle = null;
/* 231 */     synchronized (this.handles) {
/* 232 */       handle = new MessageServiceHandle(getSystemId(), serviceId, getSystemPort(), recipient);
/* 233 */       this.handles.put(serviceId, handle);
/*     */     }
/* 235 */     return handle;
/*     */   }
/*     */ 
/*     */   public void enqueue(Message message)
/*     */   {
/* 240 */     if (isServiceEnabled())
/* 241 */       this.outgoingQueue.enqueue(message);
/*     */   }
/*     */ 
/*     */   public String getOutgoingQueue()
/*     */   {
/* 246 */     return this.outgoingQueue.toString();
/*     */   }
/*     */ 
/*     */   public String getIncomingQueue() {
/* 250 */     return this.incomingQueue.toString();
/*     */   }
/*     */ 
/*     */   public void receive(Message message)
/*     */   {
/* 255 */     if (isServiceEnabled())
/* 256 */       this.incomingQueue.enqueue(message);
/*     */   }
/*     */ 
/*     */   public int getRegistration_timeout()
/*     */   {
/* 511 */     return this.registration_timeout;
/*     */   }
/*     */ 
/*     */   public boolean isServiceEnabled()
/*     */   {
/* 516 */     return this.serviceEnabled;
/*     */   }
/*     */ 
/*     */   public boolean isMonitorMode()
/*     */   {
/* 521 */     return this.monitorMode;
/*     */   }
/*     */ 
/*     */   public boolean isConnected()
/*     */   {
/* 526 */     return this.connected;
/*     */   }
/*     */ 
/*     */   protected void setConnected(boolean connected)
/*     */   {
/* 535 */     this.connected = connected;
/*     */   }
/*     */ 
/*     */   public String getSystemPort()
/*     */   {
/* 542 */     return this.systemPort;
/*     */   }
/*     */ 
/*     */   public int getResend_interval()
/*     */   {
/* 549 */     return this.resend_interval;
/*     */   }
/*     */ 
/*     */   private String createURL() {
/* 553 */     return createURL(this.monitorHost, this.monitorPort);
/*     */   }
/*     */ 
/*     */   private String createURL(String host, String port) {
/* 557 */     return "http://" + host.trim() + ":" + port.trim() + "/" + this.monitorUrl;
/*     */   }
/*     */ 
/*     */   public String getMonitorHost() {
/* 561 */     return this.monitorHost;
/*     */   }
/*     */   public String getMonitorPort() {
/* 564 */     return this.monitorPort;
/*     */   }
/*     */   public String getMonitorUrlPath() {
/* 567 */     return this.monitorUrl;
/*     */   }
/*     */ 
/*     */   public void setMonitorHost(String host) {
/* 571 */     this.monitorHost = host.trim();
/* 572 */     setConnected(false);
/*     */   }
/*     */   public void setMonitorPort(String port) {
/* 575 */     this.monitorPort = port.trim();
/* 576 */     setConnected(false);
/*     */   }
/*     */   public void setMonitorUrlPath(String path) {
/* 579 */     this.monitorUrl = path.trim();
/* 580 */     setConnected(false);
/*     */   }
/*     */ 
/*     */   public void receiveIncoming(Message message)
/*     */   {
/* 592 */     switch (message.getType().getTypeId()) {
/*     */     case 0:
/* 594 */       logger.info("SystemId: " + getSystemId() + " is connected to the monitor");
/* 595 */       setConnected(true);
/* 596 */       break;
/*     */     case 1:
/*     */     case 2:
/*     */     case 3:
/*     */     case 4:
/*     */     case 5:
/* 602 */       logger.error("UNABLE TO PROCESS MESSAGES OF THIS TYPE.\n" + message);
/* 603 */       break;
/*     */     default:
/* 605 */       logger.error("INVALID MESSAGE TYPE.\n" + message);
/*     */     }
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.messageservice.MessageService
 * JD-Core Version:    0.6.0
 */