/*    */ package com.acs.eppic.message;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ 
/*    */ public class PersistenceAlert extends AlertData
/*    */ {
/*    */   private static final long serialVersionUID = 4757200355631521668L;
/*    */   private static final String NUM_SQL_ERRORS = "NUM_SQL_ERRORS";
/*    */   private static final String NUM_TIMEOUTS = "NUM_TIMEOUTS";
/*    */ 
/*    */   public PersistenceAlert()
/*    */   {
/*    */   }
/*    */ 
/*    */   public PersistenceAlert(HashMap map)
/*    */   {
/* 19 */     setData(map);
/*    */   }
/*    */ 
/*    */   public PersistenceAlert(String code, String description, int numSqlErrors, int numTimeouts) {
/* 23 */     super(code, description);
/* 24 */     setData("NUM_SQL_ERRORS", new Integer(numSqlErrors));
/* 25 */     setData("NUM_TIMEOUTS", new Integer(numTimeouts));
/*    */   }
/*    */ 
/*    */   public int getNumSqlErrors() {
/* 29 */     int retVal = -1;
/* 30 */     if (getData("NUM_SQL_ERRORS") != null) {
/* 31 */       retVal = ((Integer)getData("NUM_SQL_ERRORS")).intValue();
/*    */     }
/* 33 */     return retVal;
/*    */   }
/*    */ 
/*    */   public int getNumTimeouts() {
/* 37 */     int retVal = -1;
/* 38 */     if (getData("NUM_TIMEOUTS") != null) {
/* 39 */       retVal = ((Integer)getData("NUM_TIMEOUTS")).intValue();
/*    */     }
/* 41 */     return retVal;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 45 */     return super.toString() + 
/* 46 */       "  # SQL Errors: + " + getNumSqlErrors() + "\n" + 
/* 47 */       "  # Timeouts: + " + getNumTimeouts() + "\n";
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.eppic.message.PersistenceAlert
 * JD-Core Version:    0.6.0
 */