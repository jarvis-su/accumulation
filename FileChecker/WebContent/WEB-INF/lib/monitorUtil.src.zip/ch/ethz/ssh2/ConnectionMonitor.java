package ch.ethz.ssh2;

public abstract interface ConnectionMonitor
{
  public abstract void connectionLost(Throwable paramThrowable);
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.ConnectionMonitor
 * JD-Core Version:    0.6.0
 */