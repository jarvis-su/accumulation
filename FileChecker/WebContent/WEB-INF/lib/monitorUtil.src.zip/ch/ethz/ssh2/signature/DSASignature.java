/*    */ package ch.ethz.ssh2.signature;
/*    */ 
/*    */ import java.math.BigInteger;
/*    */ 
/*    */ public class DSASignature
/*    */ {
/*    */   private BigInteger r;
/*    */   private BigInteger s;
/*    */ 
/*    */   public DSASignature(BigInteger r, BigInteger s)
/*    */   {
/* 18 */     this.r = r;
/* 19 */     this.s = s;
/*    */   }
/*    */ 
/*    */   public BigInteger getR()
/*    */   {
/* 24 */     return this.r;
/*    */   }
/*    */ 
/*    */   public BigInteger getS()
/*    */   {
/* 29 */     return this.s;
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     ch.ethz.ssh2.signature.DSASignature
 * JD-Core Version:    0.6.0
 */