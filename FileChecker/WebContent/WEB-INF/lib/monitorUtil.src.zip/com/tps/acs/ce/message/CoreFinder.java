/*    */ package com.acs.ce.message;
/*    */ 
/*    */ import com.acs.eppic.message.AlertData;
/*    */ import com.acs.eppic.message.Message;
/*    */ import com.acs.eppic.messageservice.MessageSender;
/*    */ import java.io.File;
/*    */ import java.io.FilenameFilter;
/*    */ import java.io.PrintStream;
/*    */ import java.util.Calendar;
/*    */ 
/*    */ public class CoreFinder
/*    */   implements Runnable
/*    */ {
/* 15 */   private long sendInterval = 1800000L;
/* 16 */   private long checkInterval = 10000L;
/*    */   private String user;
/*    */   private String folder;
/*    */   private String msg;
/*    */   private MessageSender ms;
/*    */ 
/*    */   public CoreFinder(String user)
/*    */   {
/* 23 */     this.user = user;
/* 24 */     this.folder = ("/home/" + user + "/" + user);
/* 25 */     StringBuffer sb = new StringBuffer(user);
/* 26 */     sb.append(" is CoreDumping!!!  Contact the on-call CE immediately!\n");
/* 27 */     sb.append("Move the core files out of ");
/* 28 */     sb.append(this.folder);
/* 29 */     sb.append(" to discontinue these alerts.");
/* 30 */     this.msg = sb.toString();
/* 31 */     this.ms = new MessageSender();
/*    */   }
/*    */ 
/*    */   public void sendMessage(String system, String msg) {
/* 35 */     Message m = new Message(system, "_GENERIC_1", 1, "");
/* 36 */     m.setM_MessageData(new AlertData("_GENERIC_1", msg));
/* 37 */     this.ms.enqueue(m);
/* 38 */     System.out.println(
/* 39 */       String.format("(%1$s) Sent an alert at: %2$tD %2$tl:%2$tM:%2$tS %2$tp", new Object[] { 
/* 39 */       system.toUpperCase(), Calendar.getInstance() }));
/*    */   }
/*    */ 
/*    */   public void run() {
/* 43 */     StringBuffer sb = new StringBuffer(String.format("Starting CoreFinder for %1$s at: %2$tD %2$tl:%2$tM:%2$tS %2$tp", new Object[] { this.user, Calendar.getInstance() }));
/* 44 */     sb.append("\nCheckInterval = ");
/* 45 */     sb.append(this.checkInterval / 1000L);
/* 46 */     sb.append(" s\nSendInterval  = ");
/* 47 */     sb.append(this.sendInterval / 1000L);
/* 48 */     sb.append(" s\n----------------\n");
/* 49 */     System.out.println(sb.toString());
/*    */     try {
/*    */       while (true) {
/* 52 */         String[] files = getFilesRegex(this.folder, "javacore.*");
/* 53 */         if (files.length != 0) {
/* 54 */           sendMessage(this.user.toUpperCase(), this.msg);
/* 55 */           Thread.sleep(this.sendInterval); continue;
/*    */         }
/*    */ 
/* 58 */         Thread.sleep(this.checkInterval);
/*    */       }
/*    */     } catch (InterruptedException e) {
/* 61 */       e.printStackTrace();
/*    */ 
/* 63 */       if (this.ms != null)
/* 64 */         this.ms.setServiceEnabled(false); 
/*    */     }
/*    */   }
/*    */ 
/*    */   private String[] getFilesRegex(String folder, String regexp) {
/* 68 */     File dir = new File(folder);
/* 69 */     FilenameFilter filter = new CoreFinder.1(this, regexp);
/*    */ 
/* 74 */     if (dir.isDirectory())
/* 75 */       return dir.list(filter);
/* 76 */     return new String[0];
/*    */   }
/*    */ 
/*    */   public static void main(String[] args) {
/* 80 */     String user = "sjohnson";
/* 81 */     if (args.length > 0)
/* 82 */       user = args[0];
/*    */     else
/* 84 */       user = System.getenv("USER");
/* 85 */     new Thread(new CoreFinder(user)).run();
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.acs.ce.message.CoreFinder
 * JD-Core Version:    0.6.0
 */