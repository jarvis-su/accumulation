/*      */ package com.mysql.jdbc;
/*      */ 
/*      */ import com.mysql.jdbc.exceptions.MySQLTimeoutException;
/*      */ import com.mysql.jdbc.profiler.ProfileEventSink;
/*      */ import com.mysql.jdbc.profiler.ProfilerEvent;
/*      */ import com.mysql.jdbc.util.LRUCache;
/*      */ import java.sql.BatchUpdateException;
/*      */ import java.sql.SQLException;
/*      */ import java.sql.SQLWarning;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.GregorianCalendar;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Timer;
/*      */ 
/*      */ public class Statement
/*      */   implements java.sql.Statement
/*      */ {
/*  133 */   protected static int statementCounter = 1;
/*      */   public static final byte USES_VARIABLES_FALSE = 0;
/*      */   public static final byte USES_VARIABLES_TRUE = 1;
/*      */   public static final byte USES_VARIABLES_UNKNOWN = -1;
/*  141 */   protected boolean wasCancelled = false;
/*      */   protected List batchedArgs;
/*  147 */   protected SingleByteCharsetConverter charConverter = null;
/*      */ 
/*  150 */   protected String charEncoding = null;
/*      */ 
/*  153 */   protected Connection connection = null;
/*      */ 
/*  155 */   protected long connectionId = 0L;
/*      */ 
/*  158 */   protected String currentCatalog = null;
/*      */ 
/*  161 */   protected boolean doEscapeProcessing = true;
/*      */ 
/*  164 */   protected ProfileEventSink eventSink = null;
/*      */ 
/*  167 */   private int fetchSize = 0;
/*      */ 
/*  170 */   protected boolean isClosed = false;
/*      */ 
/*  173 */   protected long lastInsertId = -1L;
/*      */ 
/*  176 */   protected int maxFieldSize = MysqlIO.getMaxBuf();
/*      */ 
/*  182 */   protected int maxRows = -1;
/*      */ 
/*  185 */   protected boolean maxRowsChanged = false;
/*      */ 
/*  188 */   protected List openResults = new ArrayList();
/*      */ 
/*  191 */   protected boolean pedantic = false;
/*      */   protected Throwable pointOfOrigin;
/*  200 */   protected boolean profileSQL = false;
/*      */ 
/*  203 */   protected ResultSet results = null;
/*      */ 
/*  206 */   protected int resultSetConcurrency = 0;
/*      */   protected LRUCache resultSetMetadataCache;
/*  212 */   protected int resultSetType = 0;
/*      */   protected int statementId;
/*  218 */   protected int timeoutInMillis = 0;
/*      */ 
/*  221 */   protected long updateCount = -1L;
/*      */ 
/*  224 */   protected boolean useUsageAdvisor = false;
/*      */ 
/*  227 */   protected SQLWarning warningChain = null;
/*      */ 
/*  233 */   protected boolean holdResultsOpenOverClose = false;
/*      */ 
/*  235 */   protected ArrayList batchedGeneratedKeys = null;
/*      */ 
/*  237 */   protected boolean retrieveGeneratedKeys = false;
/*      */ 
/*  239 */   protected boolean continueBatchOnError = false;
/*      */ 
/*      */   public Statement(Connection c, String catalog)
/*      */     throws SQLException
/*      */   {
/*  253 */     if ((c == null) || (c.isClosed())) {
/*  254 */       throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003");
/*      */     }
/*      */ 
/*  259 */     this.connection = c;
/*  260 */     this.connectionId = this.connection.getId();
/*      */ 
/*  262 */     this.currentCatalog = catalog;
/*  263 */     this.pedantic = this.connection.getPedantic();
/*  264 */     this.continueBatchOnError = this.connection.getContinueBatchOnError();
/*      */ 
/*  266 */     if (!this.connection.getDontTrackOpenResources()) {
/*  267 */       this.connection.registerStatement(this);
/*      */     }
/*      */ 
/*  274 */     if (this.connection != null) {
/*  275 */       this.maxFieldSize = this.connection.getMaxAllowedPacket();
/*      */ 
/*  277 */       int defaultFetchSize = this.connection.getDefaultFetchSize();
/*      */ 
/*  279 */       if (defaultFetchSize != 0) {
/*  280 */         setFetchSize(defaultFetchSize);
/*      */       }
/*      */     }
/*      */ 
/*  284 */     if (this.connection.getUseUnicode()) {
/*  285 */       this.charEncoding = this.connection.getEncoding();
/*      */ 
/*  287 */       this.charConverter = this.connection.getCharsetConverter(this.charEncoding);
/*      */     }
/*      */ 
/*  291 */     boolean profiling = (this.connection.getProfileSql()) || (this.connection.getUseUsageAdvisor());
/*      */ 
/*  294 */     if ((this.connection.getAutoGenerateTestcaseScript()) || (profiling)) {
/*  295 */       this.statementId = (statementCounter++);
/*      */     }
/*      */ 
/*  298 */     if (profiling) {
/*  299 */       this.pointOfOrigin = new Throwable();
/*  300 */       this.profileSQL = this.connection.getProfileSql();
/*  301 */       this.useUsageAdvisor = this.connection.getUseUsageAdvisor();
/*  302 */       this.eventSink = ProfileEventSink.getInstance(this.connection);
/*      */     }
/*      */ 
/*  305 */     int maxRowsConn = this.connection.getMaxRows();
/*      */ 
/*  307 */     if (maxRowsConn != -1)
/*  308 */       setMaxRows(maxRowsConn);
/*      */   }
/*      */ 
/*      */   public synchronized void addBatch(String sql)
/*      */     throws SQLException
/*      */   {
/*  322 */     if (this.batchedArgs == null) {
/*  323 */       this.batchedArgs = new ArrayList();
/*      */     }
/*      */ 
/*  326 */     if (sql != null)
/*  327 */       this.batchedArgs.add(sql);
/*      */   }
/*      */ 
/*      */   public void cancel()
/*      */     throws SQLException
/*      */   {
/*  337 */     if ((!this.isClosed) && (this.connection != null) && (this.connection.versionMeetsMinimum(5, 0, 0)))
/*      */     {
/*  340 */       Connection cancelConn = null;
/*  341 */       java.sql.Statement cancelStmt = null;
/*      */       try
/*      */       {
/*  344 */         cancelConn = this.connection.duplicate();
/*  345 */         cancelStmt = cancelConn.createStatement();
/*  346 */         cancelStmt.execute("KILL QUERY " + this.connection.getIO().getThreadId());
/*      */ 
/*  348 */         this.wasCancelled = true;
/*      */       } finally {
/*  350 */         if (cancelStmt != null) {
/*  351 */           cancelStmt.close();
/*      */         }
/*      */ 
/*  354 */         if (cancelConn != null)
/*  355 */           cancelConn.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void checkClosed()
/*      */     throws SQLException
/*      */   {
/*  371 */     if (this.isClosed)
/*  372 */       throw SQLError.createSQLException(Messages.getString("Statement.49"), "08003");
/*      */   }
/*      */ 
/*      */   protected void checkForDml(String sql, char firstStatementChar)
/*      */     throws SQLException
/*      */   {
/*  392 */     if ((firstStatementChar == 'I') || (firstStatementChar == 'U') || (firstStatementChar == 'D') || (firstStatementChar == 'A') || (firstStatementChar == 'C'))
/*      */     {
/*  395 */       if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "UPDATE")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "DROP")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "CREATE")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "ALTER")))
/*      */       {
/*  401 */         throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void checkNullOrEmptyQuery(String sql)
/*      */     throws SQLException
/*      */   {
/*  418 */     if (sql == null) {
/*  419 */       throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009");
/*      */     }
/*      */ 
/*  424 */     if (sql.length() == 0)
/*  425 */       throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009");
/*      */   }
/*      */ 
/*      */   public synchronized void clearBatch()
/*      */     throws SQLException
/*      */   {
/*  440 */     if (this.batchedArgs != null)
/*  441 */       this.batchedArgs.clear();
/*      */   }
/*      */ 
/*      */   public void clearWarnings()
/*      */     throws SQLException
/*      */   {
/*  453 */     this.warningChain = null;
/*      */   }
/*      */ 
/*      */   public void close()
/*      */     throws SQLException
/*      */   {
/*  472 */     realClose(true, true);
/*      */   }
/*      */ 
/*      */   protected void closeAllOpenResults()
/*      */   {
/*  479 */     if (this.openResults != null) {
/*  480 */       for (Iterator iter = this.openResults.iterator(); iter.hasNext(); ) {
/*  481 */         ResultSet element = (ResultSet)iter.next();
/*      */         try
/*      */         {
/*  484 */           element.realClose(false);
/*      */         } catch (SQLException sqlEx) {
/*  486 */           AssertionFailedException.shouldNotHappen(sqlEx);
/*      */         }
/*      */       }
/*      */ 
/*  490 */       this.openResults.clear();
/*      */     }
/*      */   }
/*      */ 
/*      */   private ResultSet createResultSetUsingServerFetch(String sql)
/*      */     throws SQLException
/*      */   {
/*  500 */     java.sql.PreparedStatement pStmt = this.connection.prepareStatement(sql, this.resultSetType, this.resultSetConcurrency);
/*      */ 
/*  503 */     pStmt.setFetchSize(this.fetchSize);
/*      */ 
/*  505 */     pStmt.execute();
/*      */ 
/*  511 */     ResultSet rs = ((Statement)pStmt).getResultSetInternal();
/*      */ 
/*  514 */     rs.setStatementUsedForFetchingRows((PreparedStatement)pStmt);
/*      */ 
/*  517 */     this.results = rs;
/*      */ 
/*  519 */     return rs;
/*      */   }
/*      */ 
/*      */   protected boolean createStreamingResultSet()
/*      */   {
/*  530 */     return (this.resultSetType == 1003) && (this.resultSetConcurrency == 1007) && (this.fetchSize == -2147483648);
/*      */   }
/*      */ 
/*      */   public void enableStreamingResults()
/*      */     throws SQLException
/*      */   {
/*  541 */     setFetchSize(-2147483648);
/*  542 */     setResultSetType(1003);
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql)
/*      */     throws SQLException
/*      */   {
/*  560 */     checkClosed();
/*      */ 
/*  563 */     Connection locallyScopedConn = this.connection;
/*      */ 
/*  565 */     synchronized (locallyScopedConn.getMutex()) {
/*  566 */       this.wasCancelled = false;
/*      */ 
/*  568 */       checkNullOrEmptyQuery(sql);
/*      */ 
/*  570 */       checkClosed();
/*      */ 
/*  572 */       char firstNonWsChar = StringUtils.firstNonWsCharUc(sql);
/*      */ 
/*  574 */       boolean isSelect = true;
/*      */ 
/*  576 */       if (firstNonWsChar != 'S') {
/*  577 */         isSelect = false;
/*      */ 
/*  579 */         if (locallyScopedConn.isReadOnly()) {
/*  580 */           throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009");
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  587 */       if (this.doEscapeProcessing) {
/*  588 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), locallyScopedConn);
/*      */ 
/*  591 */         if ((escapedSqlResult instanceof String))
/*  592 */           sql = (String)escapedSqlResult;
/*      */         else {
/*  594 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */ 
/*  598 */       if ((this.results != null) && 
/*  599 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/*  600 */         this.results.realClose(false);
/*      */       }
/*      */ 
/*  604 */       Statement.CachedResultSetMetaData cachedMetaData = null;
/*      */ 
/*  606 */       ResultSet rs = null;
/*      */ 
/*  615 */       this.batchedGeneratedKeys = null;
/*      */ 
/*  617 */       if (useServerFetch()) {
/*  618 */         rs = createResultSetUsingServerFetch(sql);
/*      */       } else {
/*  620 */         Statement.CancelTask timeoutTask = null;
/*      */         try
/*      */         {
/*  623 */           if ((this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */           {
/*  625 */             timeoutTask = new Statement.CancelTask(this);
/*  626 */             Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */           }
/*      */ 
/*  630 */           String oldCatalog = null;
/*      */ 
/*  632 */           if (!locallyScopedConn.getCatalog().equals(this.currentCatalog))
/*      */           {
/*  634 */             oldCatalog = locallyScopedConn.getCatalog();
/*  635 */             locallyScopedConn.setCatalog(this.currentCatalog);
/*      */           }
/*      */ 
/*  641 */           if (locallyScopedConn.getCacheResultSetMetadata()) {
/*  642 */             cachedMetaData = getCachedMetaData(sql);
/*      */           }
/*      */ 
/*  648 */           if (locallyScopedConn.useMaxRows()) {
/*  649 */             int rowLimit = -1;
/*      */ 
/*  651 */             if (isSelect) {
/*  652 */               if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/*  653 */                 rowLimit = this.maxRows;
/*      */               }
/*  655 */               else if (this.maxRows <= 0) {
/*  656 */                 locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */               }
/*      */               else
/*      */               {
/*  666 */                 locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */               }
/*      */ 
/*      */             }
/*      */             else
/*      */             {
/*  679 */               locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */             }
/*      */ 
/*  690 */             rs = locallyScopedConn.execSQL(this, sql, rowLimit, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedMetaData == null);
/*      */           }
/*      */           else
/*      */           {
/*  695 */             rs = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedMetaData == null);
/*      */           }
/*      */ 
/*  701 */           if (timeoutTask != null) {
/*  702 */             timeoutTask.cancel();
/*  703 */             timeoutTask = null;
/*      */           }
/*      */ 
/*  706 */           if (oldCatalog != null) {
/*  707 */             locallyScopedConn.setCatalog(oldCatalog);
/*      */           }
/*      */ 
/*  710 */           if (this.wasCancelled) {
/*  711 */             this.wasCancelled = false;
/*  712 */             throw new MySQLTimeoutException();
/*      */           }
/*      */         } finally {
/*  715 */           if (timeoutTask != null) {
/*  716 */             timeoutTask.cancel();
/*      */           }
/*      */         }
/*      */       }
/*      */ 
/*  721 */       this.lastInsertId = rs.getUpdateID();
/*      */ 
/*  723 */       if (rs != null) {
/*  724 */         this.results = rs;
/*      */ 
/*  726 */         rs.setFirstCharOfQuery(firstNonWsChar);
/*      */ 
/*  728 */         if (rs.reallyResult()) {
/*  729 */           if (cachedMetaData != null) {
/*  730 */             initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */           }
/*  733 */           else if (this.connection.getCacheResultSetMetadata()) {
/*  734 */             initializeResultsMetadataFromCache(sql, null, this.results);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*  741 */       return (rs != null) && (rs.reallyResult());
/*      */     }
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/*  752 */     if (returnGeneratedKeys == 1) {
/*  753 */       checkClosed();
/*      */ 
/*  755 */       Connection locallyScopedConn = this.connection;
/*      */ 
/*  757 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/*  761 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */ 
/*  763 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  766 */           boolean bool1 = execute(sql);
/*      */ 
/*  768 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return bool1; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  773 */     return execute(sql);
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/*  781 */     if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0)) {
/*  782 */       checkClosed();
/*      */ 
/*  784 */       Connection locallyScopedConn = this.connection;
/*      */ 
/*  786 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/*  790 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */ 
/*  792 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  795 */           boolean bool1 = execute(sql);
/*      */ 
/*  797 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return bool1; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  802 */     return execute(sql);
/*      */   }
/*      */ 
/*      */   public boolean execute(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/*  810 */     if ((generatedKeyNames != null) && (generatedKeyNames.length > 0)) {
/*  811 */       checkClosed();
/*      */ 
/*  813 */       Connection locallyScopedConn = this.connection;
/*      */ 
/*  815 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/*  819 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */ 
/*  821 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/*  824 */           boolean bool1 = execute(sql);
/*      */ 
/*  826 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return bool1; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/*  831 */     return execute(sql);
/*      */   }
/*      */ 
/*      */   public synchronized int[] executeBatch()
/*      */     throws SQLException
/*      */   {
/*  849 */     checkClosed();
/*      */ 
/*  851 */     Connection locallyScopedConn = this.connection;
/*      */ 
/*  853 */     if (locallyScopedConn.isReadOnly()) {
/*  854 */       throw SQLError.createSQLException(Messages.getString("Statement.34") + Messages.getString("Statement.35"), "S1009");
/*      */     }
/*      */ 
/*  860 */     if ((this.results != null) && 
/*  861 */       (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/*  862 */       this.results.realClose(false);
/*      */     }
/*      */ 
/*  866 */     synchronized (locallyScopedConn.getMutex()) {
/*      */       try {
/*  868 */         this.retrieveGeneratedKeys = true;
/*      */ 
/*  870 */         int[] updateCounts = null;
/*      */ 
/*  872 */         if (this.batchedArgs != null) {
/*  873 */           nbrCommands = this.batchedArgs.size();
/*      */ 
/*  875 */           this.batchedGeneratedKeys = new ArrayList(this.batchedArgs.size());
/*      */ 
/*  877 */           boolean multiQueriesEnabled = locallyScopedConn.getAllowMultiQueries();
/*      */ 
/*  879 */           if ((locallyScopedConn.versionMeetsMinimum(4, 1, 1)) && ((multiQueriesEnabled) || ((locallyScopedConn.getRewriteBatchedStatements()) && (nbrCommands > 4))))
/*      */           {
/*  883 */             int[] arrayOfInt1 = executeBatchUsingMultiQueries(multiQueriesEnabled, nbrCommands);
/*      */ 
/*  927 */             this.retrieveGeneratedKeys = false;
/*      */ 
/*  929 */             clearBatch(); return arrayOfInt1;
/*      */           }
/*  886 */           updateCounts = new int[nbrCommands];
/*      */ 
/*  888 */           for (int i = 0; i < nbrCommands; i++) {
/*  889 */             updateCounts[i] = -3;
/*      */           }
/*      */ 
/*  892 */           SQLException sqlEx = null;
/*      */ 
/*  894 */           int commandIndex = 0;
/*      */ 
/*  896 */           for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*      */             try {
/*  898 */               updateCounts[commandIndex] = executeUpdate((String)this.batchedArgs.get(commandIndex), true);
/*      */ 
/*  900 */               getBatchedGeneratedKeys();
/*      */             } catch (SQLException ex) {
/*  902 */               updateCounts[commandIndex] = -3;
/*      */ 
/*  904 */               if (this.continueBatchOnError) {
/*  905 */                 sqlEx = ex;
/*      */               } else {
/*  907 */                 int[] newUpdateCounts = new int[commandIndex];
/*  908 */                 System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
/*      */ 
/*  911 */                 throw new BatchUpdateException(ex.getMessage(), ex.getSQLState(), ex.getErrorCode(), newUpdateCounts);
/*      */               }
/*      */ 
/*      */             }
/*      */ 
/*      */           }
/*      */ 
/*  918 */           if (sqlEx != null) {
/*  919 */             throw new BatchUpdateException(sqlEx.getMessage(), sqlEx.getSQLState(), sqlEx.getErrorCode(), updateCounts);
/*      */           }
/*      */ 
/*      */         }
/*      */ 
/*  925 */         int nbrCommands = updateCounts != null ? updateCounts : new int[0];
/*      */ 
/*  927 */         this.retrieveGeneratedKeys = false;
/*      */ 
/*  929 */         clearBatch(); return nbrCommands;
/*      */       }
/*      */       finally
/*      */       {
/*  927 */         this.retrieveGeneratedKeys = false;
/*      */ 
/*  929 */         clearBatch();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private int[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands)
/*      */     throws SQLException
/*      */   {
/*  945 */     Connection locallyScopedConn = this.connection;
/*      */ 
/*  947 */     if (!multiQueriesEnabled) {
/*  948 */       locallyScopedConn.getIO().enableMultiQueries();
/*      */     }
/*      */     try
/*      */     {
/*  952 */       int[] updateCounts = new int[nbrCommands];
/*      */ 
/*  954 */       for (int i = 0; i < nbrCommands; i++) {
/*  955 */         updateCounts[i] = -3;
/*      */       }
/*      */ 
/*  958 */       int commandIndex = 0;
/*      */ 
/*  960 */       StringBuffer queryBuf = new StringBuffer();
/*      */ 
/*  962 */       java.sql.Statement batchStmt = locallyScopedConn.createStatement();
/*      */ 
/*  964 */       int counter = 0;
/*      */ 
/*  966 */       int numberOfBytesPerChar = 1;
/*      */ 
/*  968 */       String connectionEncoding = locallyScopedConn.getEncoding();
/*      */ 
/*  970 */       if (StringUtils.startsWithIgnoreCase(connectionEncoding, "utf"))
/*  971 */         numberOfBytesPerChar = 3;
/*  972 */       else if (CharsetMapping.isMultibyteCharset(connectionEncoding)) {
/*  973 */         numberOfBytesPerChar = 2;
/*      */       }
/*      */ 
/*  976 */       int escapeAdjust = 1;
/*      */ 
/*  978 */       if (this.doEscapeProcessing) {
/*  979 */         escapeAdjust = 2;
/*      */       }
/*      */ 
/*  984 */       for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
/*  985 */         String nextQuery = (String)this.batchedArgs.get(commandIndex);
/*      */ 
/*  987 */         if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > this.connection.getMaxAllowedPacket())
/*      */         {
/*  991 */           batchStmt.execute(queryBuf.toString());
/*      */ 
/*  993 */           updateCounts[(counter++)] = batchStmt.getUpdateCount();
/*  994 */           long generatedKeyStart = ((Statement)batchStmt).getLastInsertID();
/*  995 */           byte[][] row = new byte[1][];
/*  996 */           row[0] = Long.toString(generatedKeyStart++).getBytes();
/*  997 */           this.batchedGeneratedKeys.add(row);
/*      */ 
/* 1000 */           while ((batchStmt.getMoreResults()) || (batchStmt.getUpdateCount() != -1)) {
/* 1001 */             updateCounts[(counter++)] = batchStmt.getUpdateCount();
/* 1002 */             row = new byte[1][];
/* 1003 */             row[0] = Long.toString(generatedKeyStart++).getBytes();
/* 1004 */             this.batchedGeneratedKeys.add(row);
/*      */           }
/*      */ 
/* 1007 */           queryBuf = new StringBuffer();
/*      */         }
/*      */ 
/* 1010 */         queryBuf.append(nextQuery);
/* 1011 */         queryBuf.append(";");
/*      */       }
/*      */ 
/* 1014 */       if (queryBuf.length() > 0) {
/* 1015 */         batchStmt.execute(queryBuf.toString());
/*      */ 
/* 1017 */         generatedKeyStart = ((Statement)batchStmt).getLastInsertID();
/* 1018 */         byte[][] row = new byte[1][];
/* 1019 */         row[0] = Long.toString(generatedKeyStart++).getBytes();
/* 1020 */         this.batchedGeneratedKeys.add(row);
/*      */ 
/* 1022 */         updateCounts[(counter++)] = batchStmt.getUpdateCount();
/*      */ 
/* 1025 */         while ((batchStmt.getMoreResults()) || (batchStmt.getUpdateCount() != -1)) {
/* 1026 */           updateCounts[(counter++)] = batchStmt.getUpdateCount();
/* 1027 */           row = new byte[1][];
/* 1028 */           row[0] = Long.toString(generatedKeyStart++).getBytes();
/* 1029 */           this.batchedGeneratedKeys.add(row);
/*      */         }
/*      */       }
/*      */ 
/* 1033 */       long generatedKeyStart = updateCounts != null ? updateCounts : new int[0];
/*      */       return generatedKeyStart;
/*      */     }
/*      */     finally
/*      */     {
/* 1035 */       if (!multiQueriesEnabled)
/* 1036 */         locallyScopedConn.getIO().disableMultiQueries(); 
/* 1036 */     }throw localObject;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet executeQuery(String sql)
/*      */     throws SQLException
/*      */   {
/* 1054 */     checkClosed();
/*      */ 
/* 1056 */     Connection locallyScopedConn = this.connection;
/*      */ 
/* 1058 */     synchronized (locallyScopedConn.getMutex()) {
/* 1059 */       this.wasCancelled = false;
/*      */ 
/* 1061 */       checkNullOrEmptyQuery(sql);
/*      */ 
/* 1065 */       if (this.doEscapeProcessing) {
/* 1066 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, locallyScopedConn.serverSupportsConvertFn(), this.connection);
/*      */ 
/* 1069 */         if ((escapedSqlResult instanceof String))
/* 1070 */           sql = (String)escapedSqlResult;
/*      */         else {
/* 1072 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */ 
/* 1076 */       char firstStatementChar = StringUtils.firstNonWsCharUc(sql);
/*      */ 
/* 1078 */       checkForDml(sql, firstStatementChar);
/*      */ 
/* 1080 */       if ((this.results != null) && 
/* 1081 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1082 */         this.results.realClose(false);
/*      */       }
/*      */ 
/* 1086 */       Statement.CachedResultSetMetaData cachedMetaData = null;
/*      */ 
/* 1095 */       if (useServerFetch()) {
/* 1096 */         this.results = createResultSetUsingServerFetch(sql);
/*      */ 
/* 1098 */         return this.results;
/*      */       }
/*      */ 
/* 1101 */       Statement.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1104 */         if ((this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/* 1106 */           timeoutTask = new Statement.CancelTask(this);
/* 1107 */           Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */ 
/* 1111 */         String oldCatalog = null;
/*      */ 
/* 1113 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1114 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1115 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */ 
/* 1121 */         if (locallyScopedConn.getCacheResultSetMetadata()) {
/* 1122 */           cachedMetaData = getCachedMetaData(sql);
/*      */         }
/*      */ 
/* 1125 */         if (locallyScopedConn.useMaxRows())
/*      */         {
/* 1130 */           if (StringUtils.indexOfIgnoreCase(sql, "LIMIT") != -1) {
/* 1131 */             this.results = locallyScopedConn.execSQL(this, sql, this.maxRows, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedMetaData == null);
/*      */           }
/*      */           else
/*      */           {
/* 1137 */             if (this.maxRows <= 0) {
/* 1138 */               locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */             }
/*      */             else
/*      */             {
/* 1147 */               locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=" + this.maxRows, -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */             }
/*      */ 
/* 1158 */             this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedMetaData == null);
/*      */ 
/* 1164 */             if (oldCatalog != null)
/* 1165 */               locallyScopedConn.setCatalog(oldCatalog);
/*      */           }
/*      */         }
/*      */         else {
/* 1169 */           this.results = locallyScopedConn.execSQL(this, sql, -1, null, this.resultSetType, this.resultSetConcurrency, createStreamingResultSet(), this.currentCatalog, cachedMetaData == null);
/*      */         }
/*      */ 
/* 1175 */         if (timeoutTask != null) {
/* 1176 */           timeoutTask.cancel();
/* 1177 */           timeoutTask = null;
/*      */         }
/*      */ 
/* 1180 */         if (oldCatalog != null) {
/* 1181 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */ 
/* 1184 */         if (this.wasCancelled) {
/* 1185 */           this.wasCancelled = false;
/*      */ 
/* 1187 */           throw new MySQLTimeoutException();
/*      */         }
/*      */       } finally {
/* 1190 */         if (timeoutTask != null) {
/* 1191 */           timeoutTask.cancel();
/*      */         }
/*      */       }
/*      */ 
/* 1195 */       this.lastInsertId = this.results.getUpdateID();
/*      */ 
/* 1205 */       if (cachedMetaData != null) {
/* 1206 */         initializeResultsMetadataFromCache(sql, cachedMetaData, this.results);
/*      */       }
/* 1209 */       else if (this.connection.getCacheResultSetMetadata()) {
/* 1210 */         initializeResultsMetadataFromCache(sql, null, this.results);
/*      */       }
/*      */ 
/* 1215 */       return this.results;
/*      */     }
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql)
/*      */     throws SQLException
/*      */   {
/* 1235 */     return executeUpdate(sql, false);
/*      */   }
/*      */ 
/*      */   protected int executeUpdate(String sql, boolean isBatch) throws SQLException
/*      */   {
/* 1240 */     checkClosed();
/*      */ 
/* 1242 */     Connection locallyScopedConn = this.connection;
/*      */ 
/* 1244 */     char firstStatementChar = StringUtils.firstNonWsCharUc(sql);
/*      */ 
/* 1246 */     ResultSet rs = null;
/*      */ 
/* 1248 */     synchronized (locallyScopedConn.getMutex()) {
/* 1249 */       this.wasCancelled = false;
/*      */ 
/* 1251 */       checkNullOrEmptyQuery(sql);
/*      */ 
/* 1253 */       if (this.doEscapeProcessing) {
/* 1254 */         Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, this.connection.serverSupportsConvertFn(), this.connection);
/*      */ 
/* 1257 */         if ((escapedSqlResult instanceof String))
/* 1258 */           sql = (String)escapedSqlResult;
/*      */         else {
/* 1260 */           sql = ((EscapeProcessorResult)escapedSqlResult).escapedSql;
/*      */         }
/*      */       }
/*      */ 
/* 1264 */       if (locallyScopedConn.isReadOnly()) {
/* 1265 */         throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009");
/*      */       }
/*      */ 
/* 1271 */       if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
/* 1272 */         throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03");
/*      */       }
/*      */ 
/* 1277 */       if ((this.results != null) && 
/* 1278 */         (!locallyScopedConn.getHoldResultsOpenOverStatementClose())) {
/* 1279 */         this.results.realClose(false);
/*      */       }
/*      */ 
/* 1287 */       Statement.CancelTask timeoutTask = null;
/*      */       try
/*      */       {
/* 1290 */         if ((this.timeoutInMillis != 0) && (locallyScopedConn.versionMeetsMinimum(5, 0, 0)))
/*      */         {
/* 1292 */           timeoutTask = new Statement.CancelTask(this);
/* 1293 */           Connection.getCancelTimer().schedule(timeoutTask, this.timeoutInMillis);
/*      */         }
/*      */ 
/* 1297 */         String oldCatalog = null;
/*      */ 
/* 1299 */         if (!locallyScopedConn.getCatalog().equals(this.currentCatalog)) {
/* 1300 */           oldCatalog = locallyScopedConn.getCatalog();
/* 1301 */           locallyScopedConn.setCatalog(this.currentCatalog);
/*      */         }
/*      */ 
/* 1307 */         if (locallyScopedConn.useMaxRows()) {
/* 1308 */           locallyScopedConn.execSQL(this, "SET OPTION SQL_SELECT_LIMIT=DEFAULT", -1, null, 1003, 1007, false, this.currentCatalog, true);
/*      */         }
/*      */ 
/* 1316 */         rs = locallyScopedConn.execSQL(this, sql, -1, null, 1003, 1007, false, this.currentCatalog, true, isBatch);
/*      */ 
/* 1323 */         if (timeoutTask != null) {
/* 1324 */           timeoutTask.cancel();
/* 1325 */           timeoutTask = null;
/*      */         }
/*      */ 
/* 1328 */         if (oldCatalog != null) {
/* 1329 */           locallyScopedConn.setCatalog(oldCatalog);
/*      */         }
/*      */ 
/* 1332 */         if (this.wasCancelled) {
/* 1333 */           this.wasCancelled = false;
/* 1334 */           throw new MySQLTimeoutException();
/*      */         }
/*      */       } finally {
/* 1337 */         if (timeoutTask != null) {
/* 1338 */           timeoutTask.cancel();
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1343 */     this.results = rs;
/*      */ 
/* 1345 */     rs.setFirstCharOfQuery(firstStatementChar);
/*      */ 
/* 1347 */     this.updateCount = rs.getUpdateCount();
/*      */ 
/* 1349 */     int truncatedUpdateCount = 0;
/*      */ 
/* 1351 */     if (this.updateCount > 2147483647L)
/* 1352 */       truncatedUpdateCount = 2147483647;
/*      */     else {
/* 1354 */       truncatedUpdateCount = (int)this.updateCount;
/*      */     }
/*      */ 
/* 1357 */     this.lastInsertId = rs.getUpdateID();
/*      */ 
/* 1359 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int returnGeneratedKeys)
/*      */     throws SQLException
/*      */   {
/* 1367 */     if (returnGeneratedKeys == 1) {
/* 1368 */       checkClosed();
/*      */ 
/* 1370 */       Connection locallyScopedConn = this.connection;
/*      */ 
/* 1372 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/* 1376 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */ 
/* 1378 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1381 */           int i = executeUpdate(sql);
/*      */ 
/* 1383 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return i; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1388 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, int[] generatedKeyIndices)
/*      */     throws SQLException
/*      */   {
/* 1396 */     if ((generatedKeyIndices != null) && (generatedKeyIndices.length > 0)) {
/* 1397 */       checkClosed();
/*      */ 
/* 1399 */       Connection locallyScopedConn = this.connection;
/*      */ 
/* 1401 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/* 1405 */         boolean readInfoMsgState = locallyScopedConn.isReadInfoMsgEnabled();
/*      */ 
/* 1407 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1410 */           int i = executeUpdate(sql);
/*      */ 
/* 1412 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return i; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1417 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */   public int executeUpdate(String sql, String[] generatedKeyNames)
/*      */     throws SQLException
/*      */   {
/* 1425 */     if ((generatedKeyNames != null) && (generatedKeyNames.length > 0)) {
/* 1426 */       checkClosed();
/*      */ 
/* 1428 */       Connection locallyScopedConn = this.connection;
/*      */ 
/* 1430 */       synchronized (locallyScopedConn.getMutex())
/*      */       {
/* 1434 */         boolean readInfoMsgState = this.connection.isReadInfoMsgEnabled();
/*      */ 
/* 1436 */         locallyScopedConn.setReadInfoMsgEnabled(true);
/*      */         try
/*      */         {
/* 1439 */           int i = executeUpdate(sql);
/*      */ 
/* 1441 */           locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState); return i; } finally { locallyScopedConn.setReadInfoMsgEnabled(readInfoMsgState);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1446 */     return executeUpdate(sql);
/*      */   }
/*      */ 
/*      */   protected Statement.CachedResultSetMetaData getCachedMetaData(String sql)
/*      */   {
/* 1461 */     if (this.resultSetMetadataCache != null) {
/* 1462 */       return (Statement.CachedResultSetMetaData)this.resultSetMetadataCache.get(sql);
/*      */     }
/*      */ 
/* 1466 */     return null;
/*      */   }
/*      */ 
/*      */   protected Calendar getCalendarInstanceForSessionOrNew()
/*      */   {
/* 1474 */     if (this.connection != null) {
/* 1475 */       return this.connection.getCalendarInstanceForSessionOrNew();
/*      */     }
/*      */ 
/* 1478 */     return new GregorianCalendar();
/*      */   }
/*      */ 
/*      */   public java.sql.Connection getConnection()
/*      */     throws SQLException
/*      */   {
/* 1491 */     return this.connection;
/*      */   }
/*      */ 
/*      */   public int getFetchDirection()
/*      */     throws SQLException
/*      */   {
/* 1503 */     return 1000;
/*      */   }
/*      */ 
/*      */   public int getFetchSize()
/*      */     throws SQLException
/*      */   {
/* 1515 */     return this.fetchSize;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getGeneratedKeys()
/*      */     throws SQLException
/*      */   {
/* 1528 */     if (this.batchedGeneratedKeys == null) {
/* 1529 */       return getGeneratedKeysInternal();
/*      */     }
/*      */ 
/* 1532 */     Field[] fields = new Field[1];
/* 1533 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1534 */     fields[0].setConnection(this.connection);
/*      */ 
/* 1536 */     return new ResultSet(this.currentCatalog, fields, new RowDataStatic(this.batchedGeneratedKeys), this.connection, this);
/*      */   }
/*      */ 
/*      */   protected java.sql.ResultSet getGeneratedKeysInternal()
/*      */     throws SQLException
/*      */   {
/* 1548 */     Field[] fields = new Field[1];
/* 1549 */     fields[0] = new Field("", "GENERATED_KEY", -5, 17);
/* 1550 */     fields[0].setConnection(this.connection);
/*      */ 
/* 1552 */     ArrayList rowSet = new ArrayList();
/*      */ 
/* 1554 */     long beginAt = getLastInsertID();
/* 1555 */     int numKeys = getUpdateCount();
/*      */ 
/* 1557 */     if (this.results != null) {
/* 1558 */       String serverInfo = this.results.getServerInfo();
/*      */ 
/* 1564 */       if ((numKeys > 0) && (this.results.getFirstCharOfQuery() == 'R') && (serverInfo != null) && (serverInfo.length() > 0))
/*      */       {
/* 1566 */         numKeys = getRecordCountFromInfo(serverInfo);
/*      */       }
/*      */ 
/* 1569 */       if ((beginAt > 0L) && (numKeys > 0)) {
/* 1570 */         for (int i = 0; i < numKeys; i++) {
/* 1571 */           byte[][] row = new byte[1][];
/* 1572 */           row[0] = Long.toString(beginAt++).getBytes();
/* 1573 */           rowSet.add(row);
/*      */         }
/*      */       }
/*      */     }
/*      */ 
/* 1578 */     return new ResultSet(this.currentCatalog, fields, new RowDataStatic(rowSet), this.connection, this);
/*      */   }
/*      */ 
/*      */   protected int getId()
/*      */   {
/* 1588 */     return this.statementId;
/*      */   }
/*      */ 
/*      */   public long getLastInsertID()
/*      */   {
/* 1605 */     return this.lastInsertId;
/*      */   }
/*      */ 
/*      */   public long getLongUpdateCount()
/*      */   {
/* 1621 */     if (this.results == null) {
/* 1622 */       return -1L;
/*      */     }
/*      */ 
/* 1625 */     if (this.results.reallyResult()) {
/* 1626 */       return -1L;
/*      */     }
/*      */ 
/* 1629 */     return this.updateCount;
/*      */   }
/*      */ 
/*      */   public int getMaxFieldSize()
/*      */     throws SQLException
/*      */   {
/* 1644 */     return this.maxFieldSize;
/*      */   }
/*      */ 
/*      */   public int getMaxRows()
/*      */     throws SQLException
/*      */   {
/* 1658 */     if (this.maxRows <= 0) {
/* 1659 */       return 0;
/*      */     }
/*      */ 
/* 1662 */     return this.maxRows;
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults()
/*      */     throws SQLException
/*      */   {
/* 1675 */     return getMoreResults(1);
/*      */   }
/*      */ 
/*      */   public boolean getMoreResults(int current)
/*      */     throws SQLException
/*      */   {
/* 1683 */     if (this.results == null) {
/* 1684 */       return false;
/*      */     }
/*      */ 
/* 1687 */     ResultSet nextResultSet = this.results.getNextResultSet();
/*      */ 
/* 1689 */     switch (current)
/*      */     {
/*      */     case 1:
/* 1692 */       if (this.results == null) break;
/* 1693 */       this.results.close();
/* 1694 */       this.results.clearNextResult(); break;
/*      */     case 3:
/* 1701 */       if (this.results != null) {
/* 1702 */         this.results.close();
/* 1703 */         this.results.clearNextResult();
/*      */       }
/*      */ 
/* 1706 */       closeAllOpenResults();
/*      */ 
/* 1708 */       break;
/*      */     case 2:
/* 1711 */       if (!this.connection.getDontTrackOpenResources()) {
/* 1712 */         this.openResults.add(this.results);
/*      */       }
/*      */ 
/* 1715 */       this.results.clearNextResult();
/*      */ 
/* 1717 */       break;
/*      */     default:
/* 1720 */       throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009");
/*      */     }
/*      */ 
/* 1725 */     this.results = nextResultSet;
/*      */ 
/* 1727 */     if (this.results == null) {
/* 1728 */       this.updateCount = -1L;
/* 1729 */       this.lastInsertId = -1L;
/* 1730 */     } else if (this.results.reallyResult()) {
/* 1731 */       this.updateCount = -1L;
/* 1732 */       this.lastInsertId = -1L;
/*      */     } else {
/* 1734 */       this.updateCount = this.results.getUpdateCount();
/* 1735 */       this.lastInsertId = this.results.getUpdateID();
/*      */     }
/*      */ 
/* 1738 */     return (this.results != null) && (this.results.reallyResult());
/*      */   }
/*      */ 
/*      */   public int getQueryTimeout()
/*      */     throws SQLException
/*      */   {
/* 1753 */     return this.timeoutInMillis / 1000;
/*      */   }
/*      */ 
/*      */   private int getRecordCountFromInfo(String serverInfo)
/*      */   {
/* 1765 */     StringBuffer recordsBuf = new StringBuffer();
/* 1766 */     int recordsCount = 0;
/* 1767 */     int duplicatesCount = 0;
/*      */ 
/* 1769 */     char c = '\000';
/*      */ 
/* 1771 */     int length = serverInfo.length();
/* 1772 */     int i = 0;
/*      */ 
/* 1774 */     for (; i < length; i++) {
/* 1775 */       c = serverInfo.charAt(i);
/*      */ 
/* 1777 */       if (Character.isDigit(c))
/*      */       {
/*      */         break;
/*      */       }
/*      */     }
/* 1782 */     recordsBuf.append(c);
/* 1783 */     i++;
/*      */ 
/* 1785 */     for (; i < length; i++) {
/* 1786 */       c = serverInfo.charAt(i);
/*      */ 
/* 1788 */       if (!Character.isDigit(c))
/*      */       {
/*      */         break;
/*      */       }
/* 1792 */       recordsBuf.append(c);
/*      */     }
/*      */ 
/* 1795 */     recordsCount = Integer.parseInt(recordsBuf.toString());
/*      */ 
/* 1797 */     StringBuffer duplicatesBuf = new StringBuffer();
/*      */ 
/* 1799 */     for (; i < length; i++) {
/* 1800 */       c = serverInfo.charAt(i);
/*      */ 
/* 1802 */       if (Character.isDigit(c))
/*      */       {
/*      */         break;
/*      */       }
/*      */     }
/* 1807 */     duplicatesBuf.append(c);
/* 1808 */     i++;
/*      */ 
/* 1810 */     for (; i < length; i++) {
/* 1811 */       c = serverInfo.charAt(i);
/*      */ 
/* 1813 */       if (!Character.isDigit(c))
/*      */       {
/*      */         break;
/*      */       }
/* 1817 */       duplicatesBuf.append(c);
/*      */     }
/*      */ 
/* 1820 */     duplicatesCount = Integer.parseInt(duplicatesBuf.toString());
/*      */ 
/* 1822 */     return recordsCount - duplicatesCount;
/*      */   }
/*      */ 
/*      */   public java.sql.ResultSet getResultSet()
/*      */     throws SQLException
/*      */   {
/* 1835 */     return (this.results != null) && (this.results.reallyResult()) ? this.results : null;
/*      */   }
/*      */ 
/*      */   public int getResultSetConcurrency()
/*      */     throws SQLException
/*      */   {
/* 1848 */     return this.resultSetConcurrency;
/*      */   }
/*      */ 
/*      */   public int getResultSetHoldability()
/*      */     throws SQLException
/*      */   {
/* 1855 */     return 1;
/*      */   }
/*      */ 
/*      */   protected ResultSet getResultSetInternal() {
/* 1859 */     return this.results;
/*      */   }
/*      */ 
/*      */   public int getResultSetType()
/*      */     throws SQLException
/*      */   {
/* 1871 */     return this.resultSetType;
/*      */   }
/*      */ 
/*      */   public int getUpdateCount()
/*      */     throws SQLException
/*      */   {
/* 1885 */     if (this.results == null) {
/* 1886 */       return -1;
/*      */     }
/*      */ 
/* 1889 */     if (this.results.reallyResult()) {
/* 1890 */       return -1;
/*      */     }
/*      */ 
/* 1893 */     int truncatedUpdateCount = 0;
/*      */ 
/* 1895 */     if (this.results.getUpdateCount() > 2147483647L)
/* 1896 */       truncatedUpdateCount = 2147483647;
/*      */     else {
/* 1898 */       truncatedUpdateCount = (int)this.results.getUpdateCount();
/*      */     }
/*      */ 
/* 1901 */     return truncatedUpdateCount;
/*      */   }
/*      */ 
/*      */   public SQLWarning getWarnings()
/*      */     throws SQLException
/*      */   {
/* 1926 */     checkClosed();
/*      */ 
/* 1928 */     if ((this.connection != null) && (!this.connection.isClosed()) && (this.connection.versionMeetsMinimum(4, 1, 0)))
/*      */     {
/* 1930 */       SQLWarning pendingWarningsFromServer = SQLError.convertShowWarningsToSQLWarnings(this.connection);
/*      */ 
/* 1933 */       if (this.warningChain != null)
/* 1934 */         this.warningChain.setNextWarning(pendingWarningsFromServer);
/*      */       else {
/* 1936 */         this.warningChain = pendingWarningsFromServer;
/*      */       }
/*      */ 
/* 1939 */       return this.warningChain;
/*      */     }
/*      */ 
/* 1942 */     return this.warningChain;
/*      */   }
/*      */ 
/*      */   protected void initializeResultsMetadataFromCache(String sql, Statement.CachedResultSetMetaData cachedMetaData, ResultSet resultSet)
/*      */     throws SQLException
/*      */   {
/* 1962 */     synchronized (resultSet) {
/* 1963 */       if (cachedMetaData == null)
/*      */       {
/* 1965 */         cachedMetaData = new Statement.CachedResultSetMetaData(this);
/* 1966 */         cachedMetaData.fields = this.results.fields;
/*      */ 
/* 1970 */         resultSet.buildIndexMapping();
/*      */ 
/* 1972 */         cachedMetaData.columnNameToIndex = resultSet.columnNameToIndex;
/* 1973 */         cachedMetaData.fullColumnNameToIndex = resultSet.fullColumnNameToIndex;
/*      */ 
/* 1975 */         cachedMetaData.metadata = resultSet.getMetaData();
/*      */ 
/* 1977 */         if (this.resultSetMetadataCache == null) {
/* 1978 */           this.resultSetMetadataCache = new LRUCache(this.connection.getMetadataCacheSize());
/*      */         }
/*      */ 
/* 1982 */         this.resultSetMetadataCache.put(sql, cachedMetaData);
/*      */       }
/*      */       else {
/* 1985 */         resultSet.fields = cachedMetaData.fields;
/* 1986 */         resultSet.columnNameToIndex = cachedMetaData.columnNameToIndex;
/* 1987 */         resultSet.fullColumnNameToIndex = cachedMetaData.fullColumnNameToIndex;
/* 1988 */         resultSet.hasBuiltIndexMapping = true;
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
/*      */     throws SQLException
/*      */   {
/* 2006 */     if (this.isClosed) {
/* 2007 */       return;
/*      */     }
/*      */ 
/* 2010 */     if ((this.useUsageAdvisor) && 
/* 2011 */       (!calledExplicitly)) {
/* 2012 */       String message = Messages.getString("Statement.63") + Messages.getString("Statement.64");
/*      */ 
/* 2015 */       this.eventSink.consumeEvent(new ProfilerEvent(0, "", this.currentCatalog, this.connectionId, getId(), -1, System.currentTimeMillis(), 0, null, this.pointOfOrigin, message));
/*      */     }
/*      */ 
/* 2024 */     if (this.results != null) {
/* 2025 */       if (closeOpenResults) {
/* 2026 */         closeOpenResults = !this.holdResultsOpenOverClose;
/*      */       }
/*      */ 
/* 2029 */       if ((closeOpenResults) && (this.connection != null) && (!this.connection.getHoldResultsOpenOverStatementClose()))
/*      */       {
/*      */         try {
/* 2032 */           this.results.close();
/*      */         }
/*      */         catch (Exception ex)
/*      */         {
/*      */         }
/* 2037 */         closeAllOpenResults();
/*      */       }
/*      */     }
/*      */ 
/* 2041 */     if (this.connection != null) {
/* 2042 */       if (this.maxRowsChanged) {
/* 2043 */         this.connection.unsetMaxRows(this);
/*      */       }
/*      */ 
/* 2046 */       if (!this.connection.getDontTrackOpenResources()) {
/* 2047 */         this.connection.unregisterStatement(this);
/*      */       }
/*      */     }
/*      */ 
/* 2051 */     this.results = null;
/* 2052 */     this.connection = null;
/* 2053 */     this.warningChain = null;
/* 2054 */     this.openResults = null;
/* 2055 */     this.batchedGeneratedKeys = null;
/* 2056 */     this.isClosed = true;
/*      */   }
/*      */ 
/*      */   public void setCursorName(String name)
/*      */     throws SQLException
/*      */   {
/*      */   }
/*      */ 
/*      */   public void setEscapeProcessing(boolean enable)
/*      */     throws SQLException
/*      */   {
/* 2092 */     this.doEscapeProcessing = enable;
/*      */   }
/*      */ 
/*      */   public void setFetchDirection(int direction)
/*      */     throws SQLException
/*      */   {
/* 2109 */     switch (direction) {
/*      */     case 1000:
/*      */     case 1001:
/*      */     case 1002:
/* 2113 */       break;
/*      */     default:
/* 2116 */       throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setFetchSize(int rows)
/*      */     throws SQLException
/*      */   {
/* 2137 */     if (((rows < 0) && (rows != -2147483648)) || ((this.maxRows != 0) && (this.maxRows != -1) && (rows > getMaxRows())))
/*      */     {
/* 2140 */       throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009");
/*      */     }
/*      */ 
/* 2145 */     this.fetchSize = rows;
/*      */   }
/*      */ 
/*      */   protected void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose) {
/* 2149 */     this.holdResultsOpenOverClose = holdResultsOpenOverClose;
/*      */   }
/*      */ 
/*      */   public void setMaxFieldSize(int max)
/*      */     throws SQLException
/*      */   {
/* 2162 */     if (max < 0) {
/* 2163 */       throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009");
/*      */     }
/*      */ 
/* 2168 */     int maxBuf = this.connection != null ? this.connection.getMaxAllowedPacket() : MysqlIO.getMaxBuf();
/*      */ 
/* 2171 */     if (max > maxBuf) {
/* 2172 */       throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { new Long(maxBuf) }), "S1009");
/*      */     }
/*      */ 
/* 2178 */     this.maxFieldSize = max;
/*      */   }
/*      */ 
/*      */   public void setMaxRows(int max)
/*      */     throws SQLException
/*      */   {
/* 2193 */     if ((max > 50000000) || (max < 0)) {
/* 2194 */       throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009");
/*      */     }
/*      */ 
/* 2201 */     if (max == 0) {
/* 2202 */       max = -1;
/*      */     }
/*      */ 
/* 2205 */     this.maxRows = max;
/* 2206 */     this.maxRowsChanged = true;
/*      */ 
/* 2208 */     if (this.maxRows == -1) {
/* 2209 */       this.connection.unsetMaxRows(this);
/* 2210 */       this.maxRowsChanged = false;
/*      */     }
/*      */     else
/*      */     {
/* 2217 */       this.connection.maxRowsChanged(this);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setQueryTimeout(int seconds)
/*      */     throws SQLException
/*      */   {
/* 2231 */     if (seconds < 0) {
/* 2232 */       throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009");
/*      */     }
/*      */ 
/* 2237 */     this.timeoutInMillis = (seconds * 1000);
/*      */   }
/*      */ 
/*      */   void setResultSetConcurrency(int concurrencyFlag)
/*      */   {
/* 2247 */     this.resultSetConcurrency = concurrencyFlag;
/*      */   }
/*      */ 
/*      */   void setResultSetType(int typeFlag)
/*      */   {
/* 2257 */     this.resultSetType = typeFlag;
/*      */   }
/*      */ 
/*      */   protected void getBatchedGeneratedKeys(java.sql.Statement batchedStatement) throws SQLException {
/* 2261 */     if (this.retrieveGeneratedKeys) {
/* 2262 */       java.sql.ResultSet rs = null;
/*      */       try
/*      */       {
/* 2265 */         rs = batchedStatement.getGeneratedKeys();
/*      */ 
/* 2267 */         while (rs.next())
/* 2268 */           this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
/*      */       }
/*      */       finally
/*      */       {
/* 2272 */         if (rs != null)
/* 2273 */           rs.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   protected void getBatchedGeneratedKeys() throws SQLException
/*      */   {
/* 2280 */     if (this.retrieveGeneratedKeys) {
/* 2281 */       java.sql.ResultSet rs = null;
/*      */       try
/*      */       {
/* 2284 */         rs = getGeneratedKeysInternal();
/*      */ 
/* 2286 */         while (rs.next())
/* 2287 */           this.batchedGeneratedKeys.add(new byte[][] { rs.getBytes(1) });
/*      */       }
/*      */       finally
/*      */       {
/* 2291 */         if (rs != null)
/* 2292 */           rs.close();
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   private boolean useServerFetch()
/*      */     throws SQLException
/*      */   {
/* 2303 */     return (this.connection.isCursorFetchEnabled()) && (this.fetchSize > 0) && (this.resultSetConcurrency == 1007) && (this.resultSetType == 1003);
/*      */   }
/*      */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.Statement
 * JD-Core Version:    0.6.0
 */