/*    */ package com.smj.db;
/*    */ 
/*    */ import java.sql.Connection;
/*    */ import java.sql.DriverManager;
/*    */ import java.sql.Statement;
/*    */ 
/*    */ public class SQLTest
/*    */ {
/*    */   public static void main(String[] args)
/*    */     throws Exception
/*    */   {
/* 14 */     Class.forName("org.sqlite.JDBC");
/* 15 */     Connection conn = DriverManager.getConnection("jdbc:sqlite:fileChecker.db");
/* 16 */     Statement stat = conn.createStatement();
/*    */   }
/*    */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.smj.db.SQLTest
 * JD-Core Version:    0.6.0
 */