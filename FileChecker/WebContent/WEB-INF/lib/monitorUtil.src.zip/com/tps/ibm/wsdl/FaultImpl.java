package com.ibm.wsdl;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.wsdl.Fault;
import javax.wsdl.Message;
import javax.xml.namespace.QName;
import org.w3c.dom.Element;

public class FaultImpl
  implements Fault
{
  protected String name = null;
  protected Message message = null;
  protected Element docEl = null;
  protected Map extensionAttributes = new HashMap();
  protected List nativeAttributeNames = Arrays.asList(Constants.FAULT_ATTR_NAMES);
  public static final long serialVersionUID = 1L;

  public void setName(String paramString)
  {
    this.name = paramString;
  }

  public String getName()
  {
    return this.name;
  }

  public void setMessage(Message paramMessage)
  {
    this.message = paramMessage;
  }

  public Message getMessage()
  {
    return this.message;
  }

  public void setDocumentationElement(Element paramElement)
  {
    this.docEl = paramElement;
  }

  public Element getDocumentationElement()
  {
    return this.docEl;
  }

  public void setExtensionAttribute(QName paramQName, Object paramObject)
  {
    if (paramObject != null)
      this.extensionAttributes.put(paramQName, paramObject);
    else
      this.extensionAttributes.remove(paramQName);
  }

  public Object getExtensionAttribute(QName paramQName)
  {
    return this.extensionAttributes.get(paramQName);
  }

  public Map getExtensionAttributes()
  {
    return this.extensionAttributes;
  }

  public List getNativeAttributeNames()
  {
    return this.nativeAttributeNames;
  }

  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("Fault: name=" + this.name);
    if (this.message != null)
      localStringBuffer.append("\n" + this.message);
    Iterator localIterator = this.extensionAttributes.keySet().iterator();
    while (localIterator.hasNext())
    {
      QName localQName = (QName)localIterator.next();
      localStringBuffer.append("\nextension attribute: " + localQName + "=" + this.extensionAttributes.get(localQName));
    }
    return localStringBuffer.toString();
  }
}

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.ibm.wsdl.FaultImpl
 * JD-Core Version:    0.6.0
 */