/*     */ package com.mysql.jdbc;
/*     */ 
/*     */ import java.sql.SQLException;
/*     */ import java.util.List;
/*     */ 
/*     */ class VersionedStringProperty
/*     */ {
/*     */   int majorVersion;
/*     */   int minorVersion;
/*     */   int subminorVersion;
/* 731 */   boolean preferredValue = false;
/*     */   String propertyInfo;
/*     */ 
/*     */   VersionedStringProperty(String property)
/*     */   {
/* 736 */     property = property.trim();
/*     */ 
/* 738 */     if (property.startsWith("*")) {
/* 739 */       property = property.substring(1);
/* 740 */       this.preferredValue = true;
/*     */     }
/*     */ 
/* 743 */     if (property.startsWith(">")) {
/* 744 */       property = property.substring(1);
/*     */ 
/* 746 */       int charPos = 0;
/*     */ 
/* 748 */       for (charPos = 0; charPos < property.length(); charPos++) {
/* 749 */         char c = property.charAt(charPos);
/*     */ 
/* 751 */         if ((!Character.isWhitespace(c)) && (!Character.isDigit(c)) && (c != '.'))
/*     */         {
/*     */           break;
/*     */         }
/*     */       }
/*     */ 
/* 757 */       String versionInfo = property.substring(0, charPos);
/* 758 */       List versionParts = StringUtils.split(versionInfo, ".", true);
/*     */ 
/* 760 */       this.majorVersion = Integer.parseInt(versionParts.get(0).toString());
/*     */ 
/* 762 */       if (versionParts.size() > 1)
/* 763 */         this.minorVersion = Integer.parseInt(versionParts.get(1).toString());
/*     */       else {
/* 765 */         this.minorVersion = 0;
/*     */       }
/*     */ 
/* 768 */       if (versionParts.size() > 2) {
/* 769 */         this.subminorVersion = Integer.parseInt(versionParts.get(2).toString());
/*     */       }
/*     */       else {
/* 772 */         this.subminorVersion = 0;
/*     */       }
/*     */ 
/* 775 */       this.propertyInfo = property.substring(charPos);
/*     */     } else {
/* 777 */       this.majorVersion = (this.minorVersion = this.subminorVersion = 0);
/* 778 */       this.propertyInfo = property;
/*     */     }
/*     */   }
/*     */ 
/*     */   VersionedStringProperty(String property, int major, int minor, int subminor) {
/* 783 */     this.propertyInfo = property;
/* 784 */     this.majorVersion = major;
/* 785 */     this.minorVersion = minor;
/* 786 */     this.subminorVersion = subminor;
/*     */   }
/*     */ 
/*     */   boolean isOkayForVersion(Connection conn) throws SQLException {
/* 790 */     return conn.versionMeetsMinimum(this.majorVersion, this.minorVersion, this.subminorVersion);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 795 */     return this.propertyInfo;
/*     */   }
/*     */ }

/* Location:           D:\DEV\workspace_kepler\FileChecker\lib\monitorUtil.jar
 * Qualified Name:     com.tps.mysql.jdbc.VersionedStringProperty
 * JD-Core Version:    0.6.0
 */